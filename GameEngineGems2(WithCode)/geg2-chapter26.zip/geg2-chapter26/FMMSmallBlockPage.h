//-------------------
// FMMSmallBlockPage.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef FMMSMALLBLOCKPAGE_H
#define FMMSMALLBLOCKPAGE_H

//-------------------

#include "MyTypes.h"

//-------------------
// This is a full page worth of allocations of equal sized blocks.
// The basic layout of a small block page goes something like this:
// [start of page]
// [...][...][...][alloc][...][...][alloc][...][...]
// [possible wasted space too small to alloc]
// [allocation bit mask]
// [page tail struct]
// [end of page]
template <uint TPageSize>
struct FMMSmallBlockPage
{
public:
	// This is called only when a new one is allocated.
	void Initialize(uint blockSize);

	// The page literally has no place to store any data except a bitmask 
	// and a pointer at the end of the page, so we calculate where the tail
	// is based on the cache line length and size of the page and tell this class
	// how to work based on that.  The LAST thing we want is to require a cache
	// line fetch in each small block page just to read a few silly configuration
	// variables, anyway.
	// The isFull bool is filled out so that the system knows when the page should
	// be moved to the full pages bucket.
	void              *Alloc(uint blockSize, bool *isFull);	

	// The hard part of figuring out what page this pointer came from is handled 
	// at a higher level, mainly because all that depends on the policy the user creates.
	// It could be a bitmask of addresses, a simple masking operation on the address
	// itself, or a binary search over a sorted array of addresses, etc.
	// Returns true if the whole page is free, meaning the system can release the whole page.
	// Also fills out whether the page was full before the free occurred, so the system
	// can know which kind of page it came from.
	bool Free(void *ptr, bool *wasFull);

	// During the free operation when a page is being removed, we need to figure out the
	// block size so we can pass in the head pointer of the page list, otherwise if a page
	// needs to be freed, it will unlink stuff without the system knowing about it and it
	// will lose track of the page list.
	uint GetBlockSize(void) const;

	// When a new page is added by the system, it asks us to handle the pointer handling.
	void InsertNewHeadPage(FMMSmallBlockPage **headPtr);

	// Easy function to untangle the prev/next pointers from the current list.
	void RemoveFromList(FMMSmallBlockPage **headPtr);

	// Debugging aid to verify that pointers make sense and bits agree with counts.
	void SanityCheck(void);

protected:
	// This will be found at the end of each page.
	struct PageTail
	{
		// immediately following PRIOR TO this begins the allocation bitmask,
		// which are used as bitwise markers for which chunks in the page are allocated.
		// Note, a FREE block has a SET bit.	
		uint16             mFreeCount;  // improves alloc and free speed, both.
		uint16             mBlockSize;  // necessary for Free() to be fast
		FMMSmallBlockPage *mPrev;		// makes restructuring the list faster
		FMMSmallBlockPage *mNext;
	};

	enum
	{
		// we can't precompute how large the bitmask will be because that varies with the
		// size of the block being allocated.  But we can precompute the offset to the
		// start of the tail structure in each page.
		kTailOffset = TPageSize - sizeof(PageTail),		
	};
	
	// Simple address translation to get to the tail
	PageTail *GetPageTail (void) const { return (PageTail *)((char *)this + kTailOffset); }
};

//-------------------

template <uint TPageSize>
inline uint FMMSmallBlockPage<TPageSize>::GetBlockSize() const
{
	return GetPageTail()->mBlockSize;
}

//-------------------

template <uint TPageSize>
void FMMSmallBlockPage<TPageSize>::Initialize(uint blockSize)
{
	// get a pointer to the tail so we can initialize it
	PageTail *tail = GetPageTail();

	// figure out how many allocatable blocks are actually in this page, 
	// taking into account the size of the tail structure (which includes 
	// a bitmask that depends on the number of blocks in this page!)
	uint const maxAllocsPerPage     = (TPageSize - sizeof(PageTail))/blockSize;
	uint const bytesRequiredForTail = (maxAllocsPerPage+31)/32*4 + sizeof(PageTail);  // in bytes.  Rounded to nearest 32-bit value for performance.
	uint const numBlocks            = (TPageSize - bytesRequiredForTail) / blockSize;
	uint const numBytesInBitmask    = (numBlocks+31)/32*4;

	tail->mBlockSize = (uint16)blockSize;
	tail->mFreeCount = (uint16)numBlocks;
	tail->mNext = NULL;
	tail->mPrev = NULL;

	unsigned char *bitmask = (unsigned char*)tail - numBytesInBitmask;
	SetBitRangeTo1(bitmask, 0, numBlocks-1);  // mark all block alloc masks as FREE
}

//-------------------
// This function never fails.  It is assumed the system knows there is space available before calling.
template <uint TPageSize>
void *FMMSmallBlockPage<TPageSize>::Alloc(uint blockSize, bool *isFull)
{
	// treat this as a block of memory with a piece of data at the end that we want to access
	PageTail *tail = GetPageTail();
	assert(tail->mFreeCount>0);

	// figure out how many allocatable blocks are actually in this page, 
	// taking into account the size of the tail structure (which includes 
	// a bitmask that depends on the number of blocks in this page!)
	uint const maxAllocsPerPage     = (TPageSize - sizeof(PageTail))/blockSize;
	uint const bytesRequiredForTail = (maxAllocsPerPage+31)/32*4 + sizeof(PageTail);  // in bytes.  Rounded to nearest 32-bit value for performance.
	uint const numBlocks            = (TPageSize - bytesRequiredForTail) / blockSize;
	uint const numBytesInBitmask    = (numBlocks+31)/32*4;

	// scan for a free bit, which absolutely should be there
	unsigned char *bitmask = (unsigned char*)tail - numBytesInBitmask;
	uint oneBitIndex = FindFirst1BitInRange(bitmask, 0, numBlocks-1);
	assert(oneBitIndex!=numBlocks);

	// clear the free bit
	SetBitTo0(bitmask, oneBitIndex);

	void *ptr = (unsigned char *)this + oneBitIndex * blockSize;

	// move this page to the head of the small list if there's anything left to allocate in it.
	tail->mFreeCount--;
	*isFull = (tail->mFreeCount==0);
	return ptr;
}

//-------------------

template <uint TPageSize>
bool FMMSmallBlockPage<TPageSize>::Free(void *ptr, bool *wasFull)
{
	// treat this as a block of memory with a piece of data at the end that we want to access
	PageTail *tail = GetPageTail();

	uint const blockSize            = tail->mBlockSize;  // MEMORY ACCESS at the end of the page.  Fetches an L2 cache line.
	uint const maxAllocsPerPage     = (TPageSize - sizeof(PageTail))/blockSize;
	uint const bytesRequiredForTail = (maxAllocsPerPage+31)/32*4 + sizeof(PageTail);  // in bytes.  Rounded to nearest 32-bit value for performance.
	uint const numBlocks            = (TPageSize - bytesRequiredForTail) / blockSize;
	uint const numBytesInBitmask    = (numBlocks+31)/32*4;

	assert(tail->mFreeCount<numBlocks);  // should be at least one allocated block in this page, or something's broke!
	assert((((uint)ptr - (uint)this) % blockSize) == 0);  // the address of our pointer should line up evenly on a block start, or something's broke!
	unsigned char *bitmask = (unsigned char*)tail - numBytesInBitmask;  // the bitmask comes right BEFORE the tail structure	
	uint const blockNumber = ((uint)ptr - (uint)this) / blockSize;

	assert(FindFirst0BitInRange(bitmask, blockNumber, blockNumber)==blockNumber);  // make sure this block is currently free
	SetBitTo1(bitmask, blockNumber);  // mark this block as used
	tail->mFreeCount++;             // keep account

	*wasFull = (tail->mFreeCount == 1);  // if there's only one free block, this used to be a full page

	// release any page that becomes completely freed
	return (tail->mFreeCount == numBlocks);
}

//-------------------

template <uint TPageSize>
void FMMSmallBlockPage<TPageSize>::InsertNewHeadPage(FMMSmallBlockPage **headPtr)
{
	// very simply, insert 'newPage' ahead of this, fixing up both sets of pointers, then assign newPage to *headPtr.
	PageTail *tail = GetPageTail();
	FMMSmallBlockPage *headPage = *headPtr;
	if (headPage)
	{
		PageTail *pageTail = headPage->GetPageTail();
		pageTail->mPrev = this;
	}

	tail->mNext = headPage;
	*headPtr = this;
}

//-------------------

template <uint TPageSize>
void FMMSmallBlockPage<TPageSize>::SanityCheck(void)
{
	FMMSmallBlockPage *currentPage = this;
	while (currentPage)
	{
		PageTail *tail = currentPage->GetPageTail();
		assert(tail->mPrev==NULL || tail->mPrev->GetPageTail()->mNext==currentPage);  // prev page must point to us	
		assert(tail->mNext==NULL || tail->mNext->GetPageTail()->mPrev==currentPage);  // next page must point to us
	
		// count the bits that are marked as FREE and make sure they match the count in the tail
		uint const blockSize            = tail->mBlockSize;  // MEMORY ACCESS at the end of the page.  Fetches an L2 cache line.
		uint const maxAllocsPerPage     = (TPageSize - sizeof(PageTail))/blockSize;
		uint const bytesRequiredForTail = (maxAllocsPerPage+31)/32*4 + sizeof(PageTail);  // in bytes.  Rounded to nearest 32-bit value for performance.
		uint const numBlocks            = (TPageSize - bytesRequiredForTail) / blockSize;
		uint const numBytesInBitmask    = (numBlocks+31)/32*4;		

		unsigned char *bitmask = (unsigned char*)tail - numBytesInBitmask;  // the bitmask comes right BEFORE the tail structure
		uint bitsSet = 0;
		for (uint i=0; i<numBlocks; i++)
		{
			if (FindFirst1BitInRange(bitmask, i, i)==i)
			{
				bitsSet++;
			}
		}
		assert(bitsSet==tail->mFreeCount);  // bits don't match counter
	
		currentPage = tail->mNext;  // check the next page in this list
	}
}

//-------------------

template <uint TPageSize>
void FMMSmallBlockPage<TPageSize>::RemoveFromList(FMMSmallBlockPage **headPtr)
{
	// very simply, insert this ahead of the head page.
	PageTail *tail = GetPageTail();
	if (*headPtr == this)
	{
		*headPtr = tail->mNext;  // fixup the head of the list, in case it was us
	}	
	if (tail->mPrev)
	{
		PageTail *prevTail = tail->mPrev->GetPageTail();
		prevTail->mNext = tail->mNext;
	}
	if (tail->mNext)
	{
		PageTail *nextTail = tail->mNext->GetPageTail();
		nextTail->mPrev = tail->mPrev;	
	}
	tail->mNext = NULL;
	tail->mPrev = NULL;
}

//-------------------

#endif
