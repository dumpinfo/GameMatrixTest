//-------------------
// FMMTest.cpp
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include "FMM.h"
#include "OSAPIForWindows.h"
#include "OSAPIFastForWindows.h"
#include "BitHelpers.h"
#include <vector>

//-------------------

static void TestFMM(void)
{
	FMM<32, 32, 128, 256, 4096, OSAPIFastForWindows> fmm;
//	FMM<32, 8, 512, 128, 4096, OSAPIFastForWindows> fmm;
//	FMM<32, 16, 512, 128, 4096, OSAPIFastForWindows> fmm;

	{
		void *p0 = fmm.Alloc(512);	
		void *p1 = fmm.Alloc(512);		
		void *p2 = fmm.Alloc(512);		
		void *p3 = fmm.Alloc(512);
//		fmm.SanityCheck();
		fmm.Free(p0);		
		fmm.Free(p1);		
		fmm.Free(p2);		
		fmm.Free(p3);
//		fmm.SanityCheck();		
	}

	{
		void *p0 = fmm.Alloc(285);	
		void *p1 = fmm.Alloc(372);		
		void *p2 = fmm.Alloc(468);		
		void *p3 = fmm.Alloc(601);
		fmm.Free(p3);		
		fmm.Free(p2);		
		fmm.Free(p1);		
		fmm.Free(p0);
	}

	{
		void *p0 = fmm.Alloc(512);	
		void *p1 = fmm.Alloc(512);		
		void *p2 = fmm.Alloc(512);		
		void *p3 = fmm.Alloc(512);
		fmm.Free(p3);		
		fmm.Free(p2);		
		fmm.Free(p1);		
		fmm.Free(p0);
	}

//	fmm.SanityCheck();
	srand(2112);
	std::vector<void *> ptrs;
	for (int i=0; i<1000000; i++)
	{
		int sz = rand() % 2500;
		void *a = fmm.Alloc(sz);
		if (!a)
		{
			assert(a!=NULL);
		}
		memset(a, 0, sz);
		ptrs.push_back(a);

		if (rand() % 500 < 250)
		{
			uint x = rand() % ptrs.size();
			fmm.Free(ptrs[x]);
			ptrs[x] = ptrs.back();
			ptrs.pop_back();
		}
//		fmm.SanityCheck();
	}

	for (uint i=0; i<ptrs.size(); i++)
	{
		fmm.Free(ptrs[i]);
	}
//	fmm.SanityCheck();
}

//-------------------

extern "C" void* dlmalloc(size_t);
extern "C" void  dlfree(void*);

static void TestDLMalloc(void)
{
	{
		void *p0 = dlmalloc(512);	
		void *p1 = dlmalloc(512);		
		void *p2 = dlmalloc(512);		
		void *p3 = dlmalloc(512);
		dlfree(p0);		
		dlfree(p1);		
		dlfree(p2);		
		dlfree(p3);
	}

	{
		void *p0 = dlmalloc(285);	
		void *p1 = dlmalloc(372);		
		void *p2 = dlmalloc(468);		
		void *p3 = dlmalloc(601);
		dlfree(p3);		
		dlfree(p2);		
		dlfree(p1);		
		dlfree(p0);
	}

	{
		void *p0 = dlmalloc(512);	
		void *p1 = dlmalloc(512);		
		void *p2 = dlmalloc(512);		
		void *p3 = dlmalloc(512);
		dlfree(p3);		
		dlfree(p2);		
		dlfree(p1);		
		dlfree(p0);
	}

	srand(2112);
	std::vector<void *> ptrs;
	for (int i=0; i<1000000; i++)
	{
		int sz = rand() % 2500;	
		void *a = dlmalloc(sz);
		if (!a)
		{
			assert(a!=NULL);
		}
		memset(a, 0, sz);
		ptrs.push_back(a);

		if (rand() % 500 < 250)
		{
			uint x = rand() % ptrs.size();
			dlfree(ptrs[x]);
			ptrs[x] = ptrs.back();
			ptrs.pop_back();			
		}		
	}
	
	for (uint i=0; i<ptrs.size(); i++)
	{
		dlfree(ptrs[i]);
	}
}

//-------------------

static void TestCRT(void)
{
	{
		void *p0 = malloc(512);	
		void *p1 = malloc(512);		
		void *p2 = malloc(512);		
		void *p3 = malloc(512);
		free(p0);		
		free(p1);		
		free(p2);		
		free(p3);
	}

	{
		void *p0 = malloc(285);	
		void *p1 = malloc(372);		
		void *p2 = malloc(468);		
		void *p3 = malloc(601);
		free(p3);		
		free(p2);		
		free(p1);		
		free(p0);
	}

	{
		void *p0 = malloc(512);	
		void *p1 = malloc(512);		
		void *p2 = malloc(512);		
		void *p3 = malloc(512);
		free(p3);		
		free(p2);		
		free(p1);		
		free(p0);
	}

	srand(2112);
	std::vector<void *> ptrs;
	for (int i=0; i<1000000; i++)
	{
		int sz = rand() % 2500;	
		void *a = malloc(sz);
		if (!a)
		{
			assert(a!=NULL);
		}
		memset(a, 0, sz);
		ptrs.push_back(a);

		if (rand() % 500 < 250)
		{
			uint x = rand() % ptrs.size();
			free(ptrs[x]);
			ptrs[x] = ptrs.back();
			ptrs.pop_back();			
		}		
	}
	
	for (uint i=0; i<ptrs.size(); i++)
	{
		free(ptrs[i]);
	}
}

//-------------------

static void TestBits(void)
{
	uint const v0 = 0x00000001;
	assert(FindFirst0BitInRange(&v0, 0, 31)==1);	
	assert(FindFirst1BitInRange(&v0, 0, 31)==0);	
	assert(FindFirst1BitInRange(&v0, 0, 5)==0);	
	assert(FindFirst0BitInRange(&v0, 3, 8)==3);

	uint const v1 = 0xffff0010;
	assert(FindFirst0BitInRange(&v1, 0, 31)==0);	
	assert(FindFirst1BitInRange(&v1, 0, 31)==4);	
	assert(FindFirst1BitInRange(&v1, 1, 5)==4);	
	assert(FindFirst0BitInRange(&v1, 3, 8)==3);

	uint const v2 = 0x0fffffff;
	assert(FindFirst0BitInRange(&v2, 0, 31)==28);	
	assert(FindFirst1BitInRange(&v2, 0, 31)==0);	
	assert(FindFirst1BitInRange(&v2, 1, 5)==1);	
	assert(FindFirst0BitInRange(&v2, 3, 8)==9);  // won't find one
}

//-------------------

void main(void)
{
	TestBits();

	LARGE_INTEGER freq;
	QueryPerformanceFrequency(&freq);

	LARGE_INTEGER beforeFMM, afterFMM;
	QueryPerformanceCounter(&beforeFMM);
	TestFMM();
	QueryPerformanceCounter(&afterFMM);	

	LARGE_INTEGER beforeDLMalloc, afterDLMalloc;	
	QueryPerformanceCounter(&beforeDLMalloc);	
	TestDLMalloc();
	QueryPerformanceCounter(&afterDLMalloc);		

	LARGE_INTEGER beforeCRT, afterCRT;	
	QueryPerformanceCounter(&beforeCRT);	
	TestCRT();
	QueryPerformanceCounter(&afterCRT);			

	printf("FMM Time: %f\n", (afterFMM.QuadPart - beforeFMM.QuadPart) / (float)freq.QuadPart);
	printf("DLMalloc Time: %f\n", (afterDLMalloc.QuadPart - beforeDLMalloc.QuadPart) / (float)freq.QuadPart);
	printf("CRT Time: %f\n", (afterCRT.QuadPart - beforeCRT.QuadPart) / (float)freq.QuadPart);
}

//-------------------
