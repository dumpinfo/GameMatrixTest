//-------------------
// BitHelpers.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef BITHELPERS_H
#define BITHELPERS_H

//-------------------

#include "MyTypes.h"

//-------------------
// FindSetBitInRange will return the first bit in the specified range that is on, or will return bitEnd+1.
uint FindFirst1BitInRange(void const *root, uint bitStart, uint bitEnd);
uint FindFirst0BitInRange(void const *root, uint bitStart, uint bitEnd);

// These functions are specially optimized to work in 32-bits at all times, with good memory alignment performance.
// NOT endian-safe at the moment.  However, if you only use these functions to access bits rather than calculating
// them directly, it's not important.
void SetBitRangeTo1(void *root, uint bitStart, uint bitEnd);
void SetBitRangeTo0(void *root, uint bitStart, uint bitEnd);

//-------------------
// These always work in 32-bit aligned memory, specifically so we don't have to worry about endianness when porting.
// If all memory is 32-bit aligned, and you access it as 32-bits always, the byte order doesn't really matter.
// It does matter if you treat the memory as bytes sometimes and 32-bit other times.
inline void SetBitTo1(void *root, uint bitStart)
{
	// we require root to be 4-byte address aligned, for memory performance reasons.
	assert(((uint)root & 3)==0);

	// Now, we operate entirely in 32-bit space. (which means Endian-ness matters)
	unsigned      *currentWord = (unsigned*)root + bitStart/32;
	*currentWord |= 1<<(bitStart & 31);
}

//-------------------

inline void SetBitTo0(void *root, uint bitStart)
{
	// we require root to be 4-byte address aligned, for memory performance reasons.
	assert(((uint)root & 3)==0);

	// Now, we operate entirely in 32-bit space. (which means Endian-ness matters)
	unsigned      *currentWord = (unsigned*)root + bitStart/32;
	*currentWord &= ~(1<<(bitStart & 31));
}

//-------------------

#endif
