//-------------------
// FMMMediumBlockPage.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef FMMMEDIUMBLOCKPAGE_H
#define FMMMEDIUMBLOCKPAGE_H

//-------------------

#include "MyTypes.h"

//-------------------
// The basic layout of a medium block page is different because it accommodates larger, variable-sized allocations.
// It has a bit mask to identify which blocks (in equal-sized intervals specified by granularity) are free, plus
// another bit mask that indicates the last block in an allocation, so that we can tell how long allocations are when
// we're only given a starting pointer during the Free operation.
// [start of page]
// ...allocations...
// [AllocEnd Bitmask]
// [Free Bitmask]
// [Tail]
// [end of page]
//-------------------

template <uint TPageSize, uint TGranularity>
class FMMMediumBlockPage
{
public:
	void Initialize(void);
	
	// When an allocation occurs, we push the page it allocated from to the head. 
	// Generally this will cause allocations to be close together in time and space,
	// but also open space tends to flock together and get used together with fewer traversals.
	void *Alloc(uint sz);

	// allocSize is filled out with the number of bytes the allocation ACTUALLY took.
	// This returns true if the entire page is freed now.  That indicates the system should release the page back to the OSAPI.
	bool Free (void *ptr, uint *allocSize);
	
	// When a new page is added by the system, this function manages the pointers.
	void InsertNewHeadPage(FMMMediumBlockPage **headPtr);

	// When a page needs to be alloc/freed from, we remove it from the list first since it often will change lists
	void RemoveFromList(FMMMediumBlockPage **headPtr);

	// fast accessor for the number of bits in the big block
	uint GetBigBlockSize(void) { return GetPageTail()->mBigBlockSize; }
	
	// This makes sure everything checks out internally.
	void SanityCheck(void);
 
private:
	// This struct situated as the very last few bytes in the allocated page.
	struct Tail
	{
		uint                mBigBlockIndex; // index in blocks, not bytes
		uint                mBigBlockSize;  // counted in blocks, not bytes
		uint                mFreeBits;
		FMMMediumBlockPage *mNext;
		FMMMediumBlockPage *mPrev;
	};

	enum
	{
		kIdealNumGranules = (TPageSize+TGranularity-1)/TGranularity,  // this is only used as an interim for computation
		kTotalTailSize = (kIdealNumGranules+31)/32*4 * 2 + sizeof(Tail),  // there are TWO bitmasks (rounded to an even 32-bits), so count it twice.  Also only used as an interim.

		kNumGranules = (TPageSize - kTotalTailSize) / TGranularity,
		kBitmaskSize = (kNumGranules+31)/32*4,  // size in bytes.  round up to an even 32 bits for each mask, for performance	
		kTailOffset = TPageSize - sizeof(Tail),		
		kStartFreeOffset = kTailOffset - kBitmaskSize,		
		kStartAllocFreeOffset = kTailOffset - kBitmaskSize - kBitmaskSize,
	};
	
	// shortcuts to clean up a bunch of messy code
	Tail *GetPageTail     (void) const { return (Tail*)((char *)this + kTailOffset); }	
	void *GetStartFree    (void) const { return (char *)this + kStartFreeOffset; }
	void *GetStartAllocEnd(void) const { return (char *)this + kStartAllocFreeOffset; }	

	// This updates the tail so it has correct information about the big block size.
	// We have to do this after every alloc and free.
	void UpdateBigBlock(void);
};
 
//-------------------

template <uint TPageSize, uint TGranularity>
void FMMMediumBlockPage<TPageSize, TGranularity>::Initialize(void)
{
	Tail *tail = GetPageTail();

	// mark no bits in the end-of-allocation mask
	SetBitRangeTo0(GetStartAllocEnd(), 0, kNumGranules-1);

	// mark everything as free
	SetBitRangeTo1(GetStartFree(), 0, kNumGranules-1);

	// init the tail
	tail->mBigBlockIndex = 0;            // big block in a new page is at the start of the page	
	tail->mBigBlockSize = kNumGranules;
	tail->mFreeBits = kNumGranules;      // tracks exactly how many granules are free within the page.
	tail->mNext = NULL;
	tail->mPrev = NULL;
}
 
//-------------------

template <uint TPageSize, uint TGranularity>
void *FMMMediumBlockPage<TPageSize, TGranularity>::Alloc(uint sz)
{
	// The algorithm for allocation is pretty straightforward.
	// 1. Compute how many blocks this allocation requires.
	// 2. Scan forward through pages until we find one with at least that many free.
	// 3. Scan the bits in that page and see if there's a block of bits that is long enough.
	// 4. If so, mark those bits as zero, reduce the free bits count, move that page to the head of the list, and return the pointer.
	// 5. If not, go to #2 and continue the scan for good pages.
	uint const allocBitsRequired = (sz + TGranularity - 1) / TGranularity;
	
	Tail *tail = GetPageTail();
	assert(tail->mFreeBits >= allocBitsRequired);
	assert(tail->mBigBlockSize >= allocBitsRequired);
	
	void *bitmaskStartFree     = GetStartFree();	
	void *bitmaskStartAllocEnd = GetStartAllocEnd();

	// since we are always maintaining the location of the big block, and we know that the FMM internally manages it so that
	// we always are allocating from a page whose big block is as close-fitting to the allocation as possible, we will simply
	// allocate from the big block directly and then recompute it.
	void *ptr = (char *)this + tail->mBigBlockIndex * TGranularity;

	// mark the blocks as being ALLOCATED now
	SetBitRangeTo0(bitmaskStartFree, tail->mBigBlockIndex, tail->mBigBlockIndex+allocBitsRequired-1);

	// mark the end of the allocation
	SetBitTo1(bitmaskStartAllocEnd, tail->mBigBlockIndex+allocBitsRequired-1);

	// now, figure out how big the bigblock on this page is now that we've taken a bite out of it
	UpdateBigBlock();
	tail->mFreeBits -= allocBitsRequired;
	
	return ptr;
}

//-------------------

template <uint TPageSize, uint TGranularity>
bool FMMMediumBlockPage<TPageSize, TGranularity>::Free(void *ptr, uint *allocSize)
{
	assert((((uint)ptr - (uint)this) % TGranularity) == 0);  // if this is false, it means we're trying to delete some random address in a page.

	// Freeing an object is as simple as walking a bit mask and marking allocated granules as free, until we find the end of the alloc in the AllocEnd mask.
	// We can also tell if there is corruption of some sort by asserting that bits are marked allocated when they should be.
	uint const startingBit = ((uint)ptr - (uint)this) / TGranularity;

	Tail *tail                 = GetPageTail();
	void *bitmaskStartFree     = GetStartFree();	
	void *bitmaskStartAllocEnd = GetStartAllocEnd();

	// find the end of the allocation by scanning the bitmask for a 1 bit
	uint const endOfAlloc = FindFirst1BitInRange(bitmaskStartAllocEnd, startingBit, kNumGranules);
	assert(endOfAlloc<kNumGranules);  // never found the end of the allocation.  That means something is busted.

	// mark the region of memory as free
	SetBitRangeTo1(bitmaskStartFree, startingBit, endOfAlloc);

	// mark the end-of-allocation to false again
	SetBitTo0(bitmaskStartAllocEnd, endOfAlloc);

	// update the free bit count
	tail->mFreeBits += endOfAlloc - startingBit + 1;
	assert(tail->mFreeBits <= kNumGranules);  // if this exceeds the expected number of granules, we've got an accounting problem

	// return the size that this allocation took up
	*allocSize = (endOfAlloc - startingBit + 1) * TGranularity;

	// now that we've added some memory back to the page, maybe the bigblock is larger now?
	UpdateBigBlock();

	return (tail->mFreeBits == kNumGranules);
}

//-------------------

template <uint TPageSize, uint TGranularity>
void FMMMediumBlockPage<TPageSize, TGranularity>::UpdateBigBlock(void)
{
	Tail *tail             = GetPageTail();
	void *bitmaskStartFree = GetStartFree();

	// note, as biggest block gets bigger, it becomes less important to check every last 
	// bit because beyond some point, no block CAN be bigger than what we already have.
	uint biggestBlock = 0;
	uint biggestBlockIndex = 0;
	for (uint bit=0; bit<kNumGranules - biggestBlock; )  
	{
		// scan forward to find the first free bit, then scan to find where the next allocated bit is
		uint const oneBitIndex = FindFirst1BitInRange(bitmaskStartFree, bit, kNumGranules-1);	
		if (oneBitIndex==kNumGranules)  // no more free space
		{
			break;
		}

		// found an allocated region, so let's scan for the end of it
		uint const zeroBitIndex = FindFirst0BitInRange(bitmaskStartFree, oneBitIndex+1, kNumGranules-1);
		uint const currentBlockLength = zeroBitIndex - oneBitIndex;
		if (currentBlockLength > biggestBlock)
		{
			biggestBlock      = currentBlockLength;
			biggestBlockIndex = oneBitIndex;
		}

		bit = zeroBitIndex + 1;
	}

	tail->mBigBlockIndex = biggestBlockIndex;  // update our records
	tail->mBigBlockSize  = biggestBlock;
}

//-------------------

template <uint TPageSize, uint TGranularity>
void FMMMediumBlockPage<TPageSize, TGranularity>::RemoveFromList(FMMMediumBlockPage **headPtr)
{
	// very simply, insert this ahead of the head page.
	Tail *tail = GetPageTail();
	if (*headPtr == this)
	{
		*headPtr = tail->mNext;  // fixup the head of the list, in case it was us
	}	
	if (tail->mPrev)
	{
		Tail *prevTail = tail->mPrev->GetPageTail();
		prevTail->mNext = tail->mNext;
	}
	if (tail->mNext)
	{
		Tail *nextTail = tail->mNext->GetPageTail();
		nextTail->mPrev = tail->mPrev;	
	}
	tail->mNext = NULL;
	tail->mPrev = NULL;
}

//-------------------

template <uint TPageSize, uint TGranularity>
void FMMMediumBlockPage<TPageSize, TGranularity>::InsertNewHeadPage(FMMMediumBlockPage **headPtr)
{
	// insert this ahead of the head page.
	Tail *tail = GetPageTail();
	assert(tail->mNext == NULL && tail->mPrev == NULL);  // should only be doing this on a page not in a list already
	if (*headPtr)
	{
		Tail *nextTail = (*headPtr)->GetPageTail();
		nextTail->mPrev = this;
	}
	tail->mNext = *headPtr;
	*headPtr = this;
}

//-------------------

template <uint TPageSize, uint TGranularity>
void FMMMediumBlockPage<TPageSize, TGranularity>::SanityCheck(void)
{
	FMMMediumBlockPage *currentPage = this;
	while (currentPage)
	{
		Tail *tail = currentPage->GetPageTail();	
		assert(tail->mPrev==NULL || tail->mPrev->GetPageTail()->mNext==currentPage);  // prev page must point to us	
		assert(tail->mNext==NULL || tail->mNext->GetPageTail()->mPrev==currentPage);  // next page must point to us	
		assert(tail->mFreeBits >= tail->mBigBlockSize);  // the free bit count should always be at least as high or higher than the big block size
	
		// we're going to walk ALL the free bits and see if the count matches the tail's count.
		void *bitmaskStartFree = GetStartFree();
		uint bitsSet = 0;
		for (uint i=0; i<kNumGranules; i++)
		{
			if (FindFirst1BitInRange(bitmaskStartFree, i, i)==i)
				bitsSet++;
		}
		assert(bitsSet==tail->mFreeBits);
	
		// now, if we know how many bits are FREE, we can also tell what the upper limit of end-of-allocations there should be (numGranules - freeBits).
		void *bitmaskStartAllocEnd = GetStartAllocEnd();		
		uint allocBits = 0;
		for (uint i=0; i<kNumGranules; i++)
		{
			if (FindFirst1BitInRange(bitmaskStartAllocEnd, i, i)==i)
			{
				allocBits++;
			}
		}
		assert(allocBits <=k numGranules - tail->mFreeBits);
		currentPage = tail->mNext;  // iterate to the next page in the list and check it
	}
}

//-------------------

#endif
