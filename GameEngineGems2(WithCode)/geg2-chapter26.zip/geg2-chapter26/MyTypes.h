//-------------------
// MyTypes.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include <stddef.h>
#include <assert.h>
#include <memory.h>
typedef unsigned int uint;
typedef unsigned short uint16;
