//-------------------
// OSAPIFastForWindows.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef OSAPIFASTFORWINDOWS_H
#define OSAPIFASTFORWINDOWS_H

//-------------------

#include "FMM.h"
#include <vector>
#include <hash_map>
#include <algorithm>
#include <windows.h>

//-------------------
// This is a reimagined API for windows.  The idea is primarily to REMOVE, as much
// as possible, calls to the kernel to allocate pages of memory and to limit the
// amount of searching and scanning required to identify pointers as small/medium/large.
// To do this, we have to make some concessions about the flexibility of the memory manager.
class OSAPIFastForWindows
{
public:
	OSAPIFastForWindows(void);
	~OSAPIFastForWindows(void);

	// This is very important to be implemented in a fast way, so free is quick.
	void *IsSmallBlock (void *ptr) const;	
	void *IsMediumBlock(void *ptr) const;
	bool  IsLargeBlock (void *ptr) const;

	// these functions need to be overridden to change where and how 
	// the memory manager gets small pages.
	void *AllocSmallPage(void);
	void  FreeSmallPage (void *ptr);

	// these functions need to be overridden to change where and how
	// the memory manager gets medium pages.
	void *AllocMediumPage(void);
	void  FreeMediumPage (void *ptr);

	// these functions are called whenever the FMM needs a very large
	// single allocation.  Generally, in Windows this is better to just
	// map to VirtualAlloc, which guarantees no fragmentation but may
	// waste some memory between the end of the allocation and the end
	// of the physical memory page mapped to the address space.  Consoles
	// may direct this to a traditional linked list allocator or manually 
	// handle VirtualAlloc-like behavior by mapping memory blocks.
	void *AllocLarge(uint sz);
	
	// AllocSize is returned so the system can track how much memory is out in each type.
	void  FreeLarge (void *ptr, uint *allocSize);	

	// definitions that the FMM will use
	enum
	{
		// This allocation scheme requires small and medium page size to be equal, since we just
		// use a bit to determine which type of page it was.
		kSmallPageSize  = 16*1024,
		kMediumPageSize = 16*1024,

		kGiantBlockSize = 1024*1024*1024,  // 256mb of memory is the upper-limit of our allocator
		kTotalPages     = kGiantBlockSize / kSmallPageSize,
	};

private:
	// The best way to make this fast is to allocate a ton of memory at the start and dole it out
	// in pages, just remembering which pages are small and which are medium.  Any address that is
	// not in the giant allocation range is clearly going to be large.
	void *mGiantBlock;
	std::vector<bool> mIsFreePage;	
	std::vector<bool> mIsSmallPage;

	stdext::hash_map<void *, uint> mLargeAllocs;  // pair of pointers and sizes, which isn't fast but is easiest to implement for now

	// We fetch this from the OS, and make sure it's what our page sizes are set to.
	uint mNaturalPageSize;

	// this is a simple cache that prevents us from searching most of the time when looking for a free page.
	uint mLastPageFreed;
};

//-------------------

OSAPIFastForWindows::OSAPIFastForWindows(void)
	: mIsFreePage(kTotalPages, true), mIsSmallPage(kTotalPages, false)
{
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	mNaturalPageSize = info.dwPageSize;

	// If this triggers, you are running in an inoptimal way and should change your 
	// size to match or be a multiple of natural page size of the OS.
	assert(kSmallPageSize % mNaturalPageSize == 0 && kMediumPageSize % mNaturalPageSize == 0);	

	// page sizes must be identical to use this allocation policy
	assert(kSmallPageSize == kMediumPageSize);

	mGiantBlock = VirtualAlloc(NULL, kGiantBlockSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	mLastPageFreed = 0;
}

//-------------------

OSAPIFastForWindows::~OSAPIFastForWindows(void)
{
	VirtualFree(mGiantBlock, 0, MEM_RELEASE);
}

//-------------------

void *OSAPIFastForWindows::IsSmallBlock (void *ptr) const
{
	// fail if it's not within the giant block of doom
	if ((uint)ptr < (uint)mGiantBlock || (uint)ptr >= (uint)mGiantBlock + kGiantBlockSize)
		return false;

	uint const pageIndex = ((uint)ptr - (uint)mGiantBlock) / kSmallPageSize;
	assert(!mIsFreePage[pageIndex]);
	if (mIsSmallPage[pageIndex])
	{
		return ((char *)mGiantBlock + pageIndex * kSmallPageSize);
	}
	return NULL;  // no, it's a medium block
}

//-------------------

void *OSAPIFastForWindows::IsMediumBlock(void *ptr) const
{
	// fail if it's not within the giant block of doom
	if ((uint)ptr < (uint)mGiantBlock || (uint)ptr >= (uint)mGiantBlock + kGiantBlockSize)
		return false;

	uint const pageIndex = ((uint)ptr - (uint)mGiantBlock) / kSmallPageSize;
	assert(!mIsFreePage[pageIndex]);
	if (!mIsSmallPage[pageIndex])
	{
		return ((char *)mGiantBlock + pageIndex * kMediumPageSize);
	}
	return NULL;  // no, it's a medium block	
}

//-------------------

bool OSAPIFastForWindows::IsLargeBlock (void *ptr) const
{
	// if it's not inside our block, it must be a large allocation
	if ((uint)ptr < (uint)mGiantBlock || (uint)ptr >= (uint)mGiantBlock + kGiantBlockSize)
		return true;
	return false;
}

//-------------------
// these functions need to be overridden to change where and how 
// the memory manager gets small pages.
void *OSAPIFastForWindows::AllocSmallPage(void)
{
	// first iteration searches starting at the cached value
	for (uint pageIndex = mLastPageFreed; pageIndex<kTotalPages; pageIndex++)
	{
		if (mIsFreePage[pageIndex])
		{
			mIsFreePage[pageIndex] = false;
			mIsSmallPage[pageIndex] = true;
			mLastPageFreed = pageIndex+1;
			return ((char *)mGiantBlock + pageIndex*kSmallPageSize);
		}
	}

	// second half of loop starts at the beginning
	for (uint pageIndex = 0; pageIndex<mLastPageFreed; pageIndex++)
	{
		if (mIsFreePage[pageIndex])
		{
			mIsFreePage[pageIndex] = false;
			mIsSmallPage[pageIndex] = true;
			mLastPageFreed = pageIndex+1;			
			return ((char *)mGiantBlock + pageIndex*kSmallPageSize);
		}
	}

	assert(false);  // major fail here... can't allocate any new pages
	return NULL;
}

//-------------------

void OSAPIFastForWindows::FreeSmallPage (void *ptr)
{
	// fail if it's not within the giant block of doom
	assert((uint)ptr >= (uint)mGiantBlock && (uint)ptr < (uint)mGiantBlock + kGiantBlockSize);
	assert((((uint)ptr - (uint)mGiantBlock) % kSmallPageSize) == 0);  // must be the start of a page address or something is wrong.

	uint const pageIndex = ((uint)ptr - (uint)mGiantBlock) / kSmallPageSize;
	assert(!mIsFreePage[pageIndex]);
	assert(mIsSmallPage[pageIndex]);
	mIsFreePage[pageIndex] = true;
	mLastPageFreed = pageIndex;
}

//-------------------

void *OSAPIFastForWindows::AllocMediumPage(void)
{
	// first iteration searches starting at the cached value
	for (uint pageIndex = mLastPageFreed; pageIndex<kTotalPages; pageIndex++)
	{
		if (mIsFreePage[pageIndex])
		{
			mIsFreePage[pageIndex] = false;
			mIsSmallPage[pageIndex] = false;
			mLastPageFreed = pageIndex+1;			
			return ((char *)mGiantBlock + pageIndex*kMediumPageSize);
		}
	}

	// second half of loop starts at the beginning
	for (uint pageIndex = 0; pageIndex<mLastPageFreed; pageIndex++)
	{
		if (mIsFreePage[pageIndex])
		{
			mIsFreePage[pageIndex] = false;
			mIsSmallPage[pageIndex] = false;
			mLastPageFreed = pageIndex+1;			
			return ((char *)mGiantBlock + pageIndex*kMediumPageSize);
		}
	}

	assert(false);  // major fail here... can't allocate any new pages
	return NULL;
}

//-------------------

void OSAPIFastForWindows::FreeMediumPage (void *ptr)
{
	// fail if it's not within the giant block of doom
	assert((uint)ptr >= (uint)mGiantBlock && (uint)ptr < (uint)mGiantBlock + kGiantBlockSize);
	assert((((uint)ptr - (uint)mGiantBlock) % kMediumPageSize) == 0);  // must be the start of a page address or something is wrong.

	uint const pageIndex = ((uint)ptr - (uint)mGiantBlock) / kMediumPageSize;
	assert(!mIsFreePage[pageIndex]);
	assert(!mIsSmallPage[pageIndex]);
	mIsFreePage[pageIndex] = true;
	mLastPageFreed = pageIndex;	
}

//-------------------

void *OSAPIFastForWindows::AllocLarge(uint sz)
{
//	void *addr = VirtualAlloc(NULL, sz, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	void *addr = malloc(sz);
	mLargeAllocs.insert(std::make_pair(addr, sz));
	return addr;
}

//-------------------
// AllocSize is returned so the system can track how much memory is out in each type.
void OSAPIFastForWindows::FreeLarge (void *ptr, uint *allocSize)
{
	stdext::hash_map<void *, uint>::iterator i = mLargeAllocs.find(ptr);

	assert(i!=mLargeAllocs.end());  // didn't find it, didn't free it
	if (i!=mLargeAllocs.end())
	{
		if (allocSize)
			*allocSize = i->second;
//		VirtualFree(ptr, 0, MEM_RELEASE);
		free(ptr);		

		mLargeAllocs.erase(i);
		return;	
	}
}

//-------------------

#endif
