//-------------------
// FMM.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef FMM_H
#define FMM_H

//-------------------

#include "MyTypes.h"
#include "FMMSmallBlockPage.h"
#include "FMMMediumBlockPage.h"

//-------------------
// This is the interface to the Fast Memory Manager.  To change the 
// behavior of it, simply derive from it and override the virtual 
// methods that interact with the operating system's memory manager.
//
// The first three arguments define the crossover points between
// allocation types.  Particularly, minSmallAlloc is the minimum
// allocation size in the system.  These alloc sizes must be powers
// of 2 for allocation alignment to work correctly, but you
// can set them any way you like if that doesn't matter.  Cache 
// performance may suffer.
//
// SmallPageSize should be a natural-sized (for the OS/memory architecture)
// length like 4096 (for Win32).  Larger is fine, but only if you know 
// there will be tons of allocations at each interval so it's not wastefully
// reserved.  Also consider that the address of a pointer being freed can 
// ideally be able to identify whether it is a small block or not and if so,
// what page it came from.  Some of that can be done entirely with bit masking
// if all small blocks are allocated 4k aligned and 4k long, for instance.
//
// MediumPageSize has similar issues to the SmallPageSize, only with bigger 
// pages, and larger allocation granularity.  MediumPageSize should be larger
// than kMinLargeAlloc, otherwise the largest medium allocation cannot fit in
// a brand new Medium Page.  That'd be an infinite loop until you run out of RAM.
//
// OSAPI is a traits class that handles allocating pages for the memory manager.
// That's an important job, and one that can be done many ways.
template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
class FMM
{
public:
	FMM(void);
	~FMM(void);

	void *Alloc(uint sz);
	bool  Free (void *ptr);  // returns false if this was not our pointer!

	void  SanityCheck(void);  // This is SLOW.  Don't use it unless you're tracking a bug of some sort.

private:
	// This declares how many small pages we will have, stepping in 
	// kSmallAllocStepSize intervals
	enum 
	{
		kSmallPageSize  = OSAPI::kSmallPageSize,
		kMediumPageSize = OSAPI::kMediumPageSize,

		// this is how many different allocation sizes can be requested from small blocks
		kNumSmallPages  = (kMinMediumAlloc-kMinSmallAlloc + kSmallAllocStepSize - 1)/kSmallAllocStepSize,  

		// this is how many different blocks in a row are free on a completely new page
		kNumMediumPages = kMediumPageSize/kMediumAllocStepSize,  
	};
	typedef FMMMediumBlockPage<kMediumPageSize, kMediumAllocStepSize> TMediumBlockPage;	
	typedef FMMSmallBlockPage<kSmallPageSize>                         TSmallBlockPage;

	// This is effectively a hash-table where each page pointer is a
	// linked list of pages full of BLOCKS, serving as allocation pools.
	// They may be NULL if no page is currently available serving that
	// sized allocation.  NB: all allocations on a single page are
	// the same size, so pages do not move between lists.
	TSmallBlockPage  *mSmallPages[kNumSmallPages];		

	// these are pages that are simply out of space, so we don't want to search them.
	// When something frees up in one of these pages, it gets moved to the mSmallPages lists.
	TSmallBlockPage  *mSmallPagesFull[kNumSmallPages];  

	// This is effectively a hash-table where these are effectively
	// heads of linked-lists of pages that guarantee there is a big-block
	// of the given size on each page in that list.  Obviously, medium
	// pages serve any kind of allocation size within the allowable range
	// and the big-block changes, so one page may move from the largest
	// (kNumMediumPages-1) down to the smallest (0 free)
	TMediumBlockPage  *mMediumPages[kNumMediumPages];

	// This is a simple bitmask that tells whether or not the corresponding entry
	// in mMediumPages has a pointer or is null.  This way, we can do a really fast
	// bit scan to search for a pointer rather than read in a bunch of pointers in a loop.
	uint mMediumPagesBitmask[(kNumMediumPages+31)/32];

	// This is our interface to the OS's memory, and also the page sizes.  The
	// interface MUST implement the following class definition:
	OSAPI                mOSAPI;

	// Basic tracking
	uint mSmallMemoryAllocated;   // total memory allocated per type
	uint mMediumMemoryAllocated;
	uint mLargeMemoryAllocated;

	uint mSmallAllocations;       // number of allocations per type
	uint mMediumAllocations;	
	uint mLargeAllocations;		
};

//-------------------
// Implement the template.  Remember, the main reason for creating this as a template is 
// to PREVENT reading data from all over the place, rather we embed it directly in the 
// code cache.
template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
FMM<kMinSmallAlloc, kSmallAllocStepSize, kMinMediumAlloc, kMediumAllocStepSize, kMinLargeAlloc, OSAPI>::FMM(void)
{
	for (uint i=0; i<kNumSmallPages; i++)
	{
		mSmallPages[i] = NULL;
		mSmallPagesFull[i] = NULL;
	}
	for (uint i=0; i<kNumMediumPages; i++)
	{
		mMediumPages[i] = NULL;
	}	

	// mark all the pages as missing
	SetBitRangeTo0(&mMediumPagesBitmask, 0, kNumMediumPages-1);

	mSmallMemoryAllocated = 0;
	mMediumMemoryAllocated = 0;
	mLargeMemoryAllocated = 0;
	mSmallAllocations = 0;
	mMediumAllocations = 0;
	mLargeAllocations = 0;
}

//-------------------

template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
FMM<kMinSmallAlloc, kSmallAllocStepSize, kMinMediumAlloc, kMediumAllocStepSize, kMinLargeAlloc, OSAPI>::~FMM(void)
{
	// if any of these asserts trip, it's because there's memory leaks
	for (uint i=0; i<kNumSmallPages; i++)
	{
		assert(mSmallPages[i]==NULL);
		assert(mSmallPagesFull[i]==NULL);
	}
	for (uint i=0; i<kNumMediumPages; i++)
	{
		assert(mMediumPages[i]==NULL);
	}
	// check to see if the bitmask is correctly tracked
	assert(FindFirst1BitInRange(&mMediumPagesBitmask, 0, kNumMediumPages-1)==kNumMediumPages);
}

//-------------------

template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
void *FMM<kMinSmallAlloc, kSmallAllocStepSize, kMinMediumAlloc, kMediumAllocStepSize, kMinLargeAlloc, OSAPI>::Alloc(uint sz)
{
	sz = (sz < kMinSmallAlloc ? kMinSmallAlloc : sz);  // clamp to at least min alloc size

	uint const smallListIndex = (sz - kMinSmallAlloc + kSmallAllocStepSize - 1) / kSmallAllocStepSize;  // round up to next step size, if necessary
	uint const smallSz = smallListIndex * kSmallAllocStepSize + kMinSmallAlloc;
	
	if (smallSz < kMinMediumAlloc)  // small allocation
	{
		TSmallBlockPage *page = mSmallPages[smallListIndex];
		if (!page)
		{
			// allocate a new page, initialize it and assign it to the head of the list
			page = (TSmallBlockPage*)mOSAPI.AllocSmallPage();
			page->Initialize(smallSz);
			mSmallPages[smallListIndex] = page;
		}

		// attempt allocating a block from the correctly-sized linked list of small block pages.  It may fail if all of them are full.
		bool isFull = false;
		void *ret = page->Alloc(smallSz, &isFull);

		// move this page if it has no free space left
		if (isFull)
		{
			page->RemoveFromList(&mSmallPages[smallListIndex]);
			page->InsertNewHeadPage(&mSmallPagesFull[smallListIndex]);
		}

		mSmallMemoryAllocated += smallSz;
		mSmallAllocations++;
#if defined(_DEBUG)
		memset(ret, 0xcd, smallSz);  // mark new memory as uninitialized
#endif
		return ret;
	}
	else if (sz < kMinLargeAlloc)  // medium sized allocation
	{
		// round up to an even granularity in medium pages.  Special case is if sz was less than the minimum allocation size,
		// because the rounded-up smallSz may not have the same modulus as kMinMediumAlloc...
		uint const mediumSz = sz < kMinMediumAlloc ? kMinMediumAlloc : ((sz - kMinMediumAlloc + kMediumAllocStepSize - 1) / kMediumAllocStepSize) * kMediumAllocStepSize + kMinMediumAlloc;
		uint const contiguousBlocksRequired = (mediumSz + kMediumAllocStepSize - 1) / kMediumAllocStepSize;  // round up since we might need a partial block
		assert(contiguousBlocksRequired<kNumMediumPages);  // make sure we can use this to index our table of pages
		assert(contiguousBlocksRequired>0);

		// so, if we can't find EXACTLY the big-block size we want, that's ok.  We can always take a larger one.
		TMediumBlockPage *mediumPage = NULL;
		uint const pageIndex = FindFirst1BitInRange(&mMediumPagesBitmask, contiguousBlocksRequired, kNumMediumPages-1);	
		if (pageIndex==kNumMediumPages)  // no page is available with enough space for our needs, so create one
		{
			mediumPage = (TMediumBlockPage*)mOSAPI.AllocMediumPage();
			assert(mediumPage);
			mediumPage->Initialize();		
		}
		else
		{
			mediumPage = mMediumPages[pageIndex];
			assert(mediumPage!=NULL);
			mediumPage->RemoveFromList(&mMediumPages[pageIndex]);

			if (!mMediumPages[pageIndex])  // if this was the last page in the list, we have to update the bit to reflect that
			{
				SetBitTo0(&mMediumPagesBitmask, pageIndex);
			}
		}

		// allocate memory from the page first
		void *ret = mediumPage->Alloc(mediumSz);

		// next, figure out how big the big-block is on this page and add it to the right list.
		uint const bigBlockBitsInARow = mediumPage->GetBigBlockSize();
		assert(bigBlockBitsInARow < kNumMediumPages);  // again, make sure this makes sense.
		if (!mMediumPages[bigBlockBitsInARow])  // if this page list is just now acquiring a page, set its bit to reflect that
		{
			SetBitTo1(&mMediumPagesBitmask, bigBlockBitsInARow);
		}
		mediumPage->InsertNewHeadPage(&mMediumPages[bigBlockBitsInARow]);

		mMediumMemoryAllocated += mediumSz;
		mMediumAllocations++;
#if defined(_DEBUG)
		memset(ret, 0xcd, mediumSz);  // mark new memory as uninitialized
#endif		
		return ret;
	}
	else  // large allocation
	{
		mLargeMemoryAllocated += sz;
		mLargeAllocations++;	
		void *ret = mOSAPI.AllocLarge(sz);
#if defined(_DEBUG)
		memset(ret, 0xcd, sz);  // mark new memory as uninitialized
#endif				
		return ret;
	}
}

//-------------------

template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
bool FMM<kMinSmallAlloc, kSmallAllocStepSize, kMinMediumAlloc, kMediumAllocStepSize, kMinLargeAlloc, OSAPI>::Free(void *ptr)
{
	TSmallBlockPage *smallPage = (TSmallBlockPage*)mOSAPI.IsSmallBlock(ptr);
	if (smallPage)
	{
		uint const blockSize = smallPage->GetBlockSize();
		uint const listIndex = (blockSize - kMinSmallAlloc) / kSmallAllocStepSize;  // figure out what list it's on

		// we need to 
		TSmallBlockPage **pageHead     = &mSmallPages[listIndex];		
		TSmallBlockPage **pageHeadFull = &mSmallPagesFull[listIndex];
		assert(*pageHead!=NULL || *pageHeadFull!=NULL);  // there should definitely be SOME page in this list from which to free memory.

		mSmallMemoryAllocated -= blockSize;  // update tracking
		mSmallAllocations--;

#if defined(_DEBUG)
		memset(ptr, 0xfe, blockSize);  // mark free memory
#endif				
		// free the allocation.  if it's a completely empty page now, remove it from the list and release it back to the OS.
		bool wasFull = false;
		bool isNowEmpty = smallPage->Free(ptr, &wasFull);
		if (wasFull)  // switch back to the the normal list that has memory available for allocation
		{
			smallPage->RemoveFromList(pageHeadFull);
			smallPage->InsertNewHeadPage(pageHead);
		}
		if (isNowEmpty)
		{
			smallPage->RemoveFromList(pageHead);
			mOSAPI.FreeSmallPage(smallPage);
		}
		return true;				
	}
	else
	{
		TMediumBlockPage *mediumPage = (TMediumBlockPage*)mOSAPI.IsMediumBlock(ptr);
		if (mediumPage)
		{
			// we have to figure out how big the big block is, which then tells us which list the page is on.
			// Then, we remove it from that list, free the memory, measure the big block again, and either delete
			// the page (if it's completely free) or insert it at the head of the right list.
			uint const bigBlockBitsInARow = mediumPage->GetBigBlockSize();
			assert(bigBlockBitsInARow < kNumMediumPages);  // page cannot be completely free AND on a list

			// take this page out of its current page list
			mediumPage->RemoveFromList(&mMediumPages[bigBlockBitsInARow]);
			if (!mMediumPages[bigBlockBitsInARow])  // clear the bit if this list is empty now
			{
				SetBitTo0(&mMediumPagesBitmask, bigBlockBitsInARow);			
			}

			// free the memory
			uint allocSize = 0;
			if (mediumPage->Free(ptr, &allocSize))
			{
				// since the page is completely empty now, free the page
				mOSAPI.FreeMediumPage(mediumPage);
			}
			else  // otherwise insert it back at the head of the appropriate-sized list
			{
#if defined(_DEBUG)
				memset(ptr, 0xfe, allocSize);  // mark free memory
#endif							
				uint const newBigBlockSize = mediumPage->GetBigBlockSize();

				if (!mMediumPages[newBigBlockSize])  // if this list is just getting a page, set the bit
				{
					SetBitTo1(&mMediumPagesBitmask, newBigBlockSize);			
				}
				mediumPage->InsertNewHeadPage(&mMediumPages[newBigBlockSize]);
			}

			mMediumMemoryAllocated -= allocSize;  // update general tracking
			mMediumAllocations--;
			
			return true;				
		}	
		else  // must be a large block
		{
			assert(mOSAPI.IsLargeBlock(ptr));  // if it's not this, we have to assume that someone allocated this pointer elsewhere and it's an error to free it here.
			uint allocSize = 0;
			mOSAPI.FreeLarge(ptr, &allocSize);
			
			mLargeMemoryAllocated -= allocSize;  // update tracking
			mLargeAllocations--;
#if defined(_DEBUG)
//			memset(ptr, 0xfe, allocSize);  // In a protected memory model OS, this would crash because the memory has already been freed back to the OS.
#endif							
			return true;
		}
	}
}

//-------------------

template <uint kMinSmallAlloc, uint kSmallAllocStepSize, uint kMinMediumAlloc, uint kMediumAllocStepSize, uint kMinLargeAlloc, class OSAPI>
void FMM<kMinSmallAlloc, kSmallAllocStepSize, kMinMediumAlloc, kMediumAllocStepSize, kMinLargeAlloc, OSAPI>::SanityCheck(void)
{
	for (uint i=0; i<kNumSmallPages; i++)
	{
		if (mSmallPages[i])
		{
			assert(mOSAPI.IsSmallBlock(mSmallPages[i])!=NULL);  // a page on the small page list doesn't show up as being small.. that's bad.
			mSmallPages[i]->SanityCheck();
		}
	}
	for (uint i=0; i<kNumMediumPages; i++)
	{
		if (mMediumPages[i])
		{
			assert(mOSAPI.IsMediumBlock(mMediumPages[i])!=NULL);
			mMediumPages[i]->SanityCheck();
		}
	}	
}

//-------------------

#endif
