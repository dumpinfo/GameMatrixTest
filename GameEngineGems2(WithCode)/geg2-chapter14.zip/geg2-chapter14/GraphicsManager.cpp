/*  ************************************************************************************************
 *  GraphicsManager.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "GraphicsManager.h"
#include "RenderHelper.h"
#include <sstream>
#include "Mesh/TextureMesh.h"
#include "Mesh/TextureMeshModifierLight.h"
#include "GraphicObjects.h"
#include "Demo.h"

/////////////////////////////////////////////////////////////////////////////////////////

// used in drawing text
static GLvoid * gFontStyle = GLUT_BITMAP_HELVETICA_12;

BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/// constructor
/////////////////////////////////////////////////////////////////////////////////////////
GraphicsManager::GraphicsManager(void)
: mWidth(GetDefaultWindowWidth()), mHeight(GetDefaultWindowHeight()), mFrameID(0)
{

}


/////////////////////////////////////////////////////////////////////////////////////////
/// destructor
/////////////////////////////////////////////////////////////////////////////////////////
GraphicsManager::~GraphicsManager(void)
{

}


/////////////////////////////////////////////////////////////////////////////////////////
/// adds an item
/////////////////////////////////////////////////////////////////////////////////////////
void GraphicsManager::AddItem(GraphicObject* inObj)
{
    mGraphics.push_back(inObj);
}


/////////////////////////////////////////////////////////////////////////////////////////
/// draw our framerate
/////////////////////////////////////////////////////////////////////////////////////////
void GraphicsManager::DrawFPS(void)
{
	mFPSFrameID++;
	mFPSTimeTrack = glutGet(GLUT_ELAPSED_TIME);
	if (mFPSTimeTrack - mFPSTimeBase > 1000) 
	{
		mFPS            = mFPSFrameID * 1000.0 / (mFPSTimeTrack - mFPSTimeBase);
		mFPSTimeBase    = mFPSTimeTrack;		
		mFPSFrameID     = 0;
	}

	std::stringstream theStream;
    theStream << "FPS: " << mFPS << "    [ press space bar to advance to next demo ]";
	DrawText(theStream.str(), 10, 18, mLastVisibleDebugTextColor.GetRed(), mLastVisibleDebugTextColor.GetGreen(), mLastVisibleDebugTextColor.GetBlue());
}

/////////////////////////////////////////////////////////////////////////////////////////
/// draw our text
/////////////////////////////////////////////////////////////////////////////////////////
void GraphicsManager::DrawText(const std::string& inText, float inX, float inY, float inR, float inG, float inB)
{            
    // set our rendering position
    glRasterPos2f(inX, inY);
    
    // choose the color
	glColor3f(inR, inG, inB);
    
    // loop over each char
    size_t theMax = inText.size();
    for (size_t theLoop = 0; theLoop < theMax; ++theLoop)
	{
        glutBitmapCharacter(gFontStyle, inText[theLoop]);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////
/// sets width/height
/////////////////////////////////////////////////////////////////////////////////////////
void GraphicsManager::SetWidthHeight(int32 inW, int32 inH)
{
    mWidth = inW; mHeight = inH;
    
    glViewport (0, 0, (GLsizei)inW, (GLsizei)inH);
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    gluPerspective (60, (GLfloat)inW / (GLfloat)inH, 1.0, 100.0);
    glMatrixMode (GL_MODELVIEW);

}


/////////////////////////////////////////////////////////////////////////////////////////
/// render our graphics
/////////////////////////////////////////////////////////////////////////////////////////
void GraphicsManager::Render(void)
{
    // increment our frame ID
    mFrameID++;
    
    glViewport(0, 0, mWidth, mHeight);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0F, (float)mWidth, (float)mHeight, 0.0F, -10000000.0f, 10000000.0f);   
    glMatrixMode(GL_MODELVIEW);    
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    
    // setup our blending. 
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
     
    RenderStates ioRenderStates;
    ioRenderStates.SetFrameID(mFrameID);
    ioRenderStates.SetCurrentTime(Demo::Instance()->GetCurrentTime());

    // render all the items
    GraphicsList::const_iterator theIter;
    for(theIter = mGraphics.begin(); theIter != mGraphics.end(); ++theIter)
    {
        if((*theIter)->IsVisible())
        {
            (*theIter)->Render(ioRenderStates);
            mLastVisibleDebugTextColor = (*theIter)->GetDebugTextColor();
        }
    }
    ioRenderStates.Flush();

    DrawFPS();
    glutSwapBuffers();
}

/////////////////////////////////////////////////////////////////////////////////////////
END_NAMESPACE(LunchtimeStudios)
