2D Magic Demo
By: Dan Higgins
http://www.lunchtimestudios.com
------------------------------------------

This demo is intended to provide a basic texture mesh (ready to go) and modifier object examples to get you using it right away.

Included are 3 examples from the article, "2D Magic" in Game Engine Gems 2
1) Colored Quad - point lights move around a colored quad, and blend each vertex color.
2) Texture Mesh - Here we dent a texture by morphing the UV and texture positions, as well as coloring them. (very basic example)
3) Flashlight - In this demo, we color an image black, and use point lights to reveal it.

NOTE: To build, you may need to add a libPNG framework
Premade mac libs for libpng can be found: http://ethan.tira-thompson.org/Mac_OS_X_Ports.html
otherwise, go to http://www.libpng.org/pub/png/libpng.html

This was created on a Mac OS 10.6, XCode 3.2.4

If this demo is useful, drop us a line at code@lunchtimestudios.com
 


