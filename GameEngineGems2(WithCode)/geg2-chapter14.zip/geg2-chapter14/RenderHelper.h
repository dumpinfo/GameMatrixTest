/*  ************************************************************************************************
 *  RenderHelper.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Wrapper to help in rendering.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/
#pragma once

#include "CommonTypes.h"

BEGIN_NAMESPACE(LunchtimeStudios)

// this is a vertex, rgba, xy, and uv
#pragma pack(push, 1) 
struct RenderDataCVT 
{ 
    GLubyte r; 
    GLubyte g; 
    GLubyte b;
    GLubyte a;
    GLfloat x; 
    GLfloat y;
    GLfloat u;
    GLfloat v;
}; 
#pragma pack(pop)

// used in colored quads. rgba, xy
#pragma pack(push, 1) 
struct RenderDataCV 
{ 
    GLubyte r; 
    GLubyte g; 
    GLubyte b;
    GLubyte a;
    GLfloat x; 
    GLfloat y;
}; 
#pragma pack(pop)

#pragma pack(push, 1) 
struct RenderDataXY 
{ 
    RenderDataXY(float inX = 0, float inY = 0) : x(inX), y(inY) { }
    GLfloat x; 
    GLfloat y;
}; 
#pragma pack(pop)

const size_t kRenderQueueBufferMax = 60;

///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////

class RenderStates
{
    friend class GraphicsManager;
public:
                RenderStates(void)
                    :   mTextureID(0), 
                        mCurrentTime(0),
                        mEnabledVertexArray(false), 
                        mEnabledColorArray(false),
                        mEnabledGlobColor(false)
                    { 
                    }
    
                ~RenderStates(void)
                    { }
    
    bool        ShouldFlushCV(void) const
                    { return (mGlobCV.size() >= kRenderQueueBufferMax); }
    bool        ShouldFlushLineCV(void) const
                    { return (mLineGlobCV.size() >= kRenderQueueBufferMax); }
    bool        ShouldFlushCVT(void) const
                    { return (mGlobCVT.size() >= kRenderQueueBufferMax); }  
    bool        ShouldFlushXY(void) const
                    { return (mGlobXY.size() >= kRenderQueueBufferMax); }  

       
    void        AddGlobVC(const RenderDataCV& inData)
                    {
                        ASSERT_BRK(mGlobCVT.empty());
                        mGlobCV.push_back(inData);
                        if(ShouldFlushCV())
                            DrawAndReset();
                    }

    void        AddGlobXY(const RenderDataXY& inData)
                    {
                        ASSERT_BRK(mGlobCVT.empty());
                        ASSERT_BRK(mGlobCV.empty());
                        mGlobXY.push_back(inData);
                        if(ShouldFlushXY())
                            DrawAndReset();
                    }
    
    void        AddLineGlobVC(const RenderDataCV& inData)
                    {
                        ASSERT_BRK(mGlobCVT.empty() && mGlobCV.empty());
                        mLineGlobCV.push_back(inData);
                        if(ShouldFlushLineCV())
                            DrawAndReset();
                    }
                    
    void        AddGlobVTC(const RenderDataCVT& inData)
                    {
                        ASSERT_BRK(mGlobCV.empty());
                        mGlobCVT.push_back(inData);
                        if(ShouldFlushCVT())
                            DrawAndReset();
                    }
    
    void        AddGlobVTC(const RenderDataCVT& inData1, const RenderDataCVT& inData2, const RenderDataCVT& inData3, const RenderDataCVT& inData4)
                    {
                        mGlobCVT.push_back(inData1);
                        mGlobCVT.push_back(inData2);
                        mGlobCVT.push_back(inData3);
                        mGlobCVT.push_back(inData4);
                        if(ShouldFlushCVT())
                            DrawAndReset();                        
                    }

    void        AddGlobVC(const RenderDataCV& inData1, const RenderDataCV& inData2, const RenderDataCV& inData3, const RenderDataCV& inData4)
                    {
                        mGlobCV.push_back(inData1);
                        mGlobCV.push_back(inData2);
                        mGlobCV.push_back(inData3);
                        mGlobCV.push_back(inData4);
                        if(ShouldFlushCV())
                            DrawAndReset();                        
                    }
    
    void        AddGlobXY(GLubyte inColors[4], const RenderDataXY& inData1, const RenderDataXY& inData2, const RenderDataXY& inData3, const RenderDataXY& inData4);
                  
    void        AddLineGlobVC(const RenderDataCV& inData1, const RenderDataCV& inData2)
                    {
                        mLineGlobCV.push_back(inData1);
                        mLineGlobCV.push_back(inData2);
                        if(ShouldFlushLineCV())
                            DrawAndReset();    
                    }
    
    void        Clear(bool inDrawFirst = true)
                    {
                        DrawAndReset(inDrawFirst);
                        
                        SetTexture2D(0);
                        SetVertexColorArray(false);
                        SetHasVertices(false);
                    }
    
    void        DrawAndReset(bool inDrawFirst = true);
        
                // render whatever we have.
    void        Flush(void)
                    { DrawAndReset(); }
    
                // return our frame id
    uint32      GetFrameID(void) const
                    { return mFrameID; }
                    
    uint32      GetCurrentTime(void) const { return mCurrentTime; }
    void        SetCurrentTime(uint32 inTime) { mCurrentTime = inTime; }
                
                // sets our frame ID
    void        SetFrameID(uint32 inFrame)
                    { Flush(); mFrameID = inFrame; }
    
                // sets our texture id
    void        SetTexture2D(GLuint inTextureID)
                    {
                        if(mTextureID != inTextureID)
                        {
                            DrawAndReset();
                            mTextureID = inTextureID;
                            if(inTextureID == 0)
                            {
                                glDisable( GL_TEXTURE_2D);
                                glDisableClientState(GL_TEXTURE_COORD_ARRAY);                    
                            }
                            else
                            {
                                glEnable(GL_TEXTURE_2D);
                                glBindTexture(GL_TEXTURE_2D, mTextureID);
                                glEnableClientState(GL_TEXTURE_COORD_ARRAY);
                            }
                        }
                    }
                
                // has vertex coloring
    void        SetVertexColorArray(bool inEnabled)
                    {
                        if(mEnabledColorArray != inEnabled)
                        {
                            DrawAndReset();
                            mEnabledColorArray = inEnabled;
                            if(inEnabled == true)
                                glEnableClientState(GL_COLOR_ARRAY);            
                            else
                                glDisableClientState(GL_COLOR_ARRAY);
                        }
                    }
    
                // sets if we have verts
    void        SetHasVertices(bool inEnabled)
                    {
                        if(mEnabledVertexArray != inEnabled)
                        {
                            DrawAndReset();
                            mEnabledVertexArray = inEnabled;
                            if(inEnabled == true)
                                glEnableClientState(GL_VERTEX_ARRAY);            
                            else
                                glDisableClientState(GL_VERTEX_ARRAY);
                        }
                    }
private:
    // prefer to use boost::noncopyable instead
    RenderStates(const RenderStates& notImplemented);
    RenderStates& operator=(const RenderStates& notImplemented);

protected:
    
    std::vector< RenderDataXY >     mGlobXY;  // globs of vertex, texture, color    
    std::vector< RenderDataCVT >    mGlobCVT;  // globs of vertex, texture, color    
    std::vector< RenderDataCV >     mGlobCV;    // globs of vertex, color
    std::vector< RenderDataCV >     mLineGlobCV; // for lines
    GLubyte     mGlobColors[4];
    GLuint      mTextureID;
    uint32      mFrameID;
    uint32      mCurrentTime;
    bool        mEnabledVertexArray;
    bool        mEnabledColorArray;
    bool        mEnabledGlobColor;
 };

END_NAMESPACE(LunchtimeStudios)

