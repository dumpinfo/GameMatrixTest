/*  ************************************************************************************************
 *  GraphicObjects.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/


#include "GraphicObjects.h"
#include "RenderHelper.h"
#include "Mesh/TextureMeshUV.h"
#include <sstream>
#include "GraphicsManager.h"

BEGIN_NAMESPACE(LunchtimeStudios)


//////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicObject::GraphicObject(const std::string& inName, uint32 inVertsPerRow, const ColorF& inDebugTextColor)
: mDebugTextColor(inDebugTextColor)
, mName(inName)
, mMesh(NULL)
, mBounds(0.0F, 0.0F, (float)GraphicsManager::Instance().GetWidth(), (float)GraphicsManager::Instance().GetHeight())  
, mVisible(true)
{
    mMesh = new LunchtimeStudios::Mesh();
 
    // cap our verts per row
    inVertsPerRow = std::min(inVertsPerRow, std::min((uint32)GraphicsManager::Instance().GetWidth(), (uint32)GraphicsManager::Instance().GetHeight()));

    // build our mesh
    mMesh->Resize(inVertsPerRow, mBounds.GetWidth(), mBounds.GetHeight());

    // default color
    const float kBaseColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    mMesh->SetColor(kBaseColor);    
    mMesh->SetRenderLines(false);
}

//////////////////////////////////////////////////////////////////////////////////////////////
/// destructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicObject::~GraphicObject(void)
{
    delete mMesh;
}


//////////////////////////////////////////////////////////////////////////////////////////////
/// render text
//////////////////////////////////////////////////////////////////////////////////////////////
void GraphicObject::RenderDebugText(void)
{
    std::stringstream theStr;
    theStr << "Demo: " << mName << std::endl 
           << "test";
           
    // output text
    GraphicsManager::Instance().DrawText(theStr.str(), 10, GraphicsManager::Instance().GetHeight() - 18, 
                                        mDebugTextColor.GetRed(), mDebugTextColor.GetGreen(), mDebugTextColor.GetBlue());

}


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicQuad::GraphicQuad(const std::string& inName, uint32 inVertsPerRow, const ColorF& inDebugTextColor)
: GraphicObject(inName, inVertsPerRow, inDebugTextColor)
{
    const float kBaseColor[4] = {0.0f, 0.0f, 0.5f, 1.0f};
    mMesh->SetColor(kBaseColor);    
}

//////////////////////////////////////////////////////////////////////////////////////////////
/// destructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicQuad::~GraphicQuad(void)
{

}

//////////////////////////////////////////////////////////////////////////////////////////////
/// render the quad
//////////////////////////////////////////////////////////////////////////////////////////////
void GraphicQuad::Render(RenderStates& ioRenderStates)
{
    ioRenderStates.SetHasVertices(true);
    ioRenderStates.SetVertexColorArray(true);
    ioRenderStates.SetTexture2D(0);
 
    LunchtimeStudios::RenderDataCV theV1, theV2, theV3, theV4;
    
    // top left
    theV1.x = mBounds.left;
    theV1.y = mBounds.top;
    mColorTL.CopyToRawUint8((uint8*)&theV1.r);
    
    // bottom left
    theV2.x = mBounds.left;
    theV2.y = mBounds.bottom;
    mColorBL.CopyToRawUint8((uint8*)&theV2.r);
    
    // top right
    theV3.x = mBounds.right;
    theV3.y = mBounds.top;
    mColorTR.CopyToRawUint8((uint8*)&theV3.r);
    
    // bottom right
    theV4.x = mBounds.right;
    theV4.y = mBounds.bottom;
    mColorBR.CopyToRawUint8((uint8*)&theV4.r);
    
    // queue it up for rendering.
    ioRenderStates.AddGlobVC(theV1, theV2, theV3, theV4);  
    ioRenderStates.Flush();
    
    if(mMesh)
    {
        //uint32 theStart = ComputeCurrentTime();
        
        mMesh->UpdateMesh(ioRenderStates.GetFrameID(), ioRenderStates.GetCurrentTime());
        mMesh->Render(ioRenderStates);

        //uint32 theEnd = ComputeCurrentTime();
        //uint32 theDiff = theEnd - theStart;
        //std::cerr << "Render time: " << theDiff << std::endl;
    }
    
    RenderDebugText();
}

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicTexture::GraphicTexture(const std::string& inName, uint32 inVertsPerRow, const ColorF& inDebugTextColor)
: GraphicObject(inName, inVertsPerRow, inDebugTextColor)
{
    delete mMesh;
    mMesh = new LunchtimeStudios::MeshUV();
    
    // cap our verts per row
    inVertsPerRow = std::min(inVertsPerRow, std::min((uint32)GraphicsManager::Instance().GetWidth(), (uint32)GraphicsManager::Instance().GetHeight()));

    // build our mesh
    mMesh->Resize(inVertsPerRow, mBounds.GetWidth(), mBounds.GetHeight());

    const float kBaseColor[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    mMesh->SetColor(kBaseColor);     
    mMesh->SetRenderLines(true);
}

//////////////////////////////////////////////////////////////////////////////////////////////
/// destructor
//////////////////////////////////////////////////////////////////////////////////////////////
GraphicTexture::~GraphicTexture(void)
{

}


//////////////////////////////////////////////////////////////////////////////////////////////
/// load our file
//////////////////////////////////////////////////////////////////////////////////////////////
bool GraphicTexture::Load(const std::string& inFile)
{
    return (mTexture.load(inFile) != 0);
}

//////////////////////////////////////////////////////////////////////////////////////////////
/// render the texture
//////////////////////////////////////////////////////////////////////////////////////////////
void GraphicTexture::Render(RenderStates& ioRenderStates)
{
    ioRenderStates.SetHasVertices(true);
    ioRenderStates.SetVertexColorArray(true);
    ioRenderStates.SetTexture2D(mTexture.getGLID());

    
    RenderDataCVT theV1, theV2, theV3, theV4;

    // top left
    theV1.x = mBounds.left;
    theV1.y = mBounds.top;
    mColorTL.CopyToRawUint8((uint8*)&theV1.r);
    theV1.u = 0.0F;
    theV1.v = 0.0F;
    
    // bottom left
    theV2.x = mBounds.left;
    theV2.y = mBounds.bottom;
    mColorBL.CopyToRawUint8((uint8*)&theV2.r);
    theV2.u = 0.0F;
    theV2.v = 1.0F;
    
    // top right
    theV3.x = mBounds.right;
    theV3.y = mBounds.top;
    mColorTR.CopyToRawUint8((uint8*)&theV3.r);
    theV3.u = 1.0F;
    theV3.v = 0.0F;
    
    // bottom right
    theV4.x = mBounds.right;
    theV4.y = mBounds.bottom;
    mColorBR.CopyToRawUint8((uint8*)&theV4.r);
    theV4.u = 1.0F;
    theV4.v = 1.0F;
      
    // queue it up for rendering.
    ioRenderStates.AddGlobVTC(theV1, theV2, theV3, theV4);  
    ioRenderStates.Flush();
    
    if(mMesh)
    {
        //uint32 theStart = ComputeCurrentTime();
        
        mMesh->UpdateMesh(ioRenderStates.GetFrameID(), ioRenderStates.GetCurrentTime());
        mMesh->Render(ioRenderStates);

        //uint32 theEnd = ComputeCurrentTime();
        //uint32 theDiff = theEnd - theStart;
        //std::cerr << "Render time: " << theDiff << std::endl;
    }    

    RenderDebugText();
}


END_NAMESPACE(LunchtimeStudios)


