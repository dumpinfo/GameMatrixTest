/*  ************************************************************************************************
 *  RenderHelper.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "RenderHelper.h"

BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////////////////
/// adds our xy and color
///////////////////////////////////////////////////////////////////////////////////////////////
void RenderStates::AddGlobXY(GLubyte inColor[4], const RenderDataXY& inData1, const RenderDataXY& inData2, const RenderDataXY& inData3, const RenderDataXY& inData4)
{
    if(mEnabledGlobColor == false || mGlobColors[0] != inColor[0] || 
                                     mGlobColors[1] != inColor[1] || 
                                     mGlobColors[2] != inColor[2] ||
                                     mGlobColors[3] != inColor[3])
    {
        DrawAndReset();
    }
    
    mEnabledGlobColor = true;
    mGlobColors[0] = inColor[0];
    mGlobColors[1] = inColor[1];
    mGlobColors[2] = inColor[2];
    mGlobColors[3] = inColor[3];
    
    mGlobXY.push_back(inData1);
    mGlobXY.push_back(inData2);
    mGlobXY.push_back(inData3);
    mGlobXY.push_back(inData4);
    if(ShouldFlushXY())
        DrawAndReset();                        
}    

//////////////////////////////////////////////////////////////////////////////////////////////    
/// draw and fush
//////////////////////////////////////////////////////////////////////////////////////////////    
void RenderStates::DrawAndReset(bool inDrawFirst)
{
    static std::vector< GLubyte > sGlobVTCTriangles;   
    
    if(sGlobVTCTriangles.empty())
    {
        uint32 theLoop;
        GLubyte theCounter;    
        GLubyte theMaxLoop = (GLubyte)64;
        for(theLoop = 0, theCounter = 0; theLoop < theMaxLoop; theLoop++, theCounter += 4)
        {
            sGlobVTCTriangles.push_back(theCounter);
            sGlobVTCTriangles.push_back(theCounter + 1);
            sGlobVTCTriangles.push_back(theCounter + 2);
            
            sGlobVTCTriangles.push_back(theCounter + 1);
            sGlobVTCTriangles.push_back(theCounter + 2);
            sGlobVTCTriangles.push_back(theCounter + 3);
        }
    }
        
    // draw globs
    if(inDrawFirst && mGlobCVT.empty() == false)
    {
        glColorPointer(4, GL_UNSIGNED_BYTE, sizeof(RenderDataCVT), (void*)&mGlobCVT[0].r);
        glVertexPointer(2, GL_FLOAT, sizeof(RenderDataCVT), (void*)&mGlobCVT[0].x);
        glTexCoordPointer(2, GL_FLOAT, sizeof(RenderDataCVT), (void*)&mGlobCVT[0].u);
        
        ASSERT_BRK(6 * (mGlobCVT.size() / 4) < 256);
        glDrawElements(GL_TRIANGLES, 6 * (mGlobCVT.size() / 4), GL_UNSIGNED_BYTE, &sGlobVTCTriangles[0]);
    }
    mGlobCVT.resize(0);
    
    
    // draw globs
    if(inDrawFirst && mGlobXY.empty() == false)
    {
        glShadeModel(GL_FLAT);
        glColorPointer(4, GL_UNSIGNED_BYTE, 0, (void*)mGlobColors);
        glVertexPointer(2, GL_FLOAT, sizeof(RenderDataXY), (void*)&mGlobXY[0].x);
        
        ASSERT_BRK(6 * (mGlobCVT.size() / 4) < 256);
        glDrawElements(GL_TRIANGLES, 6 * (mGlobXY.size() / 4), GL_UNSIGNED_BYTE, &sGlobVTCTriangles[0]);
        glShadeModel(GL_SMOOTH);
    }
    mEnabledGlobColor = false;
    mGlobXY.resize(0);
    
    /////////////////////////////////////////////////////////
    // draw globs
    if(inDrawFirst && mGlobCV.empty() == false)
    {
        glColorPointer(4, GL_UNSIGNED_BYTE, sizeof(RenderDataCV), (void*)&mGlobCV[0].r);
        glVertexPointer(2, GL_FLOAT, sizeof(RenderDataCV), (void*)&mGlobCV[0].x);
        ASSERT_BRK(6 * (mGlobCV.size() / 4) < 256);
        glDrawElements(GL_TRIANGLES, 6 * (mGlobCV.size() / 4), GL_UNSIGNED_BYTE, &sGlobVTCTriangles[0]);
    }
    mGlobCV.resize(0);   
    
    /////////////////////////////////////////////////////////
    // draw globs
    if(inDrawFirst && mLineGlobCV.empty() == false)
    {
        glColorPointer(4, GL_UNSIGNED_BYTE, sizeof(RenderDataCV), (void*)&mLineGlobCV[0].r);
        glVertexPointer(2, GL_FLOAT, sizeof(RenderDataCV), (void*)&mLineGlobCV[0].x);
        ASSERT_BRK(6 * (mGlobCV.size() / 4) < 256);
        glDrawElements(GL_LINES, 6 * (mLineGlobCV.size() / 4), GL_UNSIGNED_BYTE, &sGlobVTCTriangles[0]);
    }
    mGlobCV.resize(0);      
}


END_NAMESPACE(LunchtimeStudios)


