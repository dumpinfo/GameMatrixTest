/*  ************************************************************************************************
 *  Demo.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Our demo object
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

#include "Helpers/CommonTypes.h"
#include "GraphicObjects.h"
#include "Helpers/Point.h"

BEGIN_NAMESPACE(LunchtimeStudios)
class GraphicObject;
class Light2DPhysics;

class Demo
{
public:
                    Demo(void);
    virtual         ~Demo(void);
    
                    // return our singleton
    static Demo*    Instance(void)
                        { static Demo sInst; return &sInst; }
                        
                    // return our current update time
    uint32          GetCurrentTime(void) const
                        { return mCurrentTime; }
    
                    // input
    virtual void    OnMouseDown(bool inIsLeft, int inX, int inY);
    virtual void    OnMouseUp(bool inIsLeft, int inX, int inY);
    virtual void    OnMouseMove(int inX, int inY);
    virtual void    OnKeyDown(char inKey);

                    // setup our demo data
    virtual void    SetupDemo(void);

                    // update and render
    virtual void    Update(void);
    
protected:

    typedef std::vector< Light2DPhysics* > LightMorphList;
    
                    // adds a light on the quad
    void            BuildNewLightOnQuad(const PointF& inPoint = PointF(-1.0F, -1.0F));
    
                    // fire away on textures
    void            BuildNewTextureEffect(const PointF& inPoint);
    
                    // fire away on textures
    void            BuildNewTextureEffectFlashLight(const PointF& inPoint);    
    
                    // removes a light
    bool            DoKillLightOverMax(Light2DPhysics* inMorph, bool inIsStillOverMax);
    
                    // cap our lights
    void            EnsureOnlyMaxLights(uint32 inTargetMax, uint32 inAbsMax);
    
                    // change visiblities
    void            ToggleScene(void);
    
                    // updates our lights
    void            UpdateLights(uint32 inCurrentTime);

    struct MouseStats
    {
        MouseStats(void) : mIsDown(false) { }
        PointF          mLastPoint;
        PointF          mStart;
        bool            mIsDown;
    };
        
    MouseStats      mLeftMouse;
    MouseStats      mRightMouse;
    uint32          mCurrentTime;
    GraphicQuad     mQuadTest;
    GraphicTexture  mTextureTest;
    GraphicTexture  mTextureTestFlashlight;
    LightMorphList  mLightMorphs;
    uint32          mNextUpdateTime;
        

};


END_NAMESPACE(LunchtimeStudios)
