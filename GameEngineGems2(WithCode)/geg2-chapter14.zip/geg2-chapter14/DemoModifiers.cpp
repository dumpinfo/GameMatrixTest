/*  ************************************************************************************************
 *  DemoModifiers.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "DemoModifiers.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
Light2DPhysics::Light2DPhysics(void)
:	mColorTimeRange(1600, 3800),
    mPixelTimeRange(6900, 12800),
    mFallOffTimeRange(2600, 5800),
    mRadiusTimeRange(3600, 6800),
    mPixelPercentRangeX(0.0F, 1.0F),
    mPixelPercentRangeY(0.0F, 1.0F),
    mFallOffRange(0.02F, 0.2F),
    mRadiusRange(0.1F, 0.7F),
    mNextColorTime(0), 
    mStartColorTime(0), 
    mNextPointTime(0), 
    mStartPointTime(0), 
    mNextFallOffTime(0), 
    mStartFallOffTime(0), 
    mNextRadiusTime(0), 
    mStartRadiusTime(0), 
    mFlags(eLightSourceMorphFlags::kUpdateAll)
{
    mMeshResult = NULL;
    mMesh = NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// remove our mesh items
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Light2DPhysics::ClearMeshItems(void)
{
    if(mMesh && mMeshResult)
    {
        mMesh->RemoveLight(mMeshResult);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// returns a new color
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
ColorF Light2DPhysics::GetNewColor(float inRed, float inGreen, float inBlue, float inAlpha)
{
    ColorF theResult;
    
  	// cache the app 
    theResult.SetRed  ((inRed   < 0.0F) ? GetRandomPercentage() : inRed);
    theResult.SetGreen((inGreen < 0.0F) ? GetRandomPercentage() : inGreen);
    theResult.SetBlue ((inBlue  < 0.0F) ? GetRandomPercentage() : inBlue);
    theResult.SetAlpha((inAlpha < 0.0F) ? GetRandomPercentage() : inAlpha);
    return theResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// shrink our time left.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Light2DPhysics::ShrinkTimeToKill(uint32 inAmount)
{
    if(mNextRadiusTime - inAmount > 0)
        mNextRadiusTime -= inAmount;
    else
        mNextRadiusTime = 0;
}

// =============================================================================================================
// Update - update this item
bool Light2DPhysics::Update(uint32 inTime, LightSource& outResult)
{
	bool theResult = false;
    
    
	/////////////////////////////////////////////////////////////
	// TWEAK! 
	if(eLightSourceMorphFlags::HasFlag(mFlags, eLightSourceMorphFlags::UpdateColor))
	{
		if(mNextColorTime < inTime)
		{
			mStart.SetColor(mEnd.GetColor());
			mNextColorTime = inTime + GetRandomInt(mColorTimeRange);
			mStartColorTime = inTime;
            mEnd.SetColor(GetNewColor(-1.0F, -1.0F, -1.0F, mEnd.GetColor().GetAlpha()));
        }
        
		float thePercent = (float)(1.0 - (((double)mNextColorTime - (double)inTime) / ((double)mNextColorTime - (double)mStartColorTime)));
		ASSERT_BRK(thePercent >= 0.0F && thePercent <= 1.0F);
		outResult.SetColor(ColorF::Lerp(mStart.GetColor(), mEnd.GetColor(), thePercent));
        
		// we modified things, so return dirty 
		theResult = true;
	}
    else
    {
        outResult.SetColor(mEnd.GetColor());
    }
    
	/////////////////////////////////////////////////////////////
	// Position
	if(eLightSourceMorphFlags::HasFlag(mFlags, eLightSourceMorphFlags::UpdatePoint))
	{
		if(mNextPointTime < inTime)
		{
			mStart.SetXY(mEnd.GetXY());
			mNextPointTime = inTime + GetRandomInt(mPixelTimeRange);
			mStartPointTime = inTime;
			mEnd.SetXY((float)GraphicsManager::Instance().ConvertScreenCoordIntoPixel(GetRandomFloat(mPixelPercentRangeX), true),
			           (float)GraphicsManager::Instance().ConvertScreenCoordIntoPixel(GetRandomFloat(mPixelPercentRangeY), false));
		}
        
		float thePercent = (float)(1.0 - (((double)mNextPointTime - (double)inTime) / ((double)mNextPointTime - (double)mStartPointTime)));
		ASSERT_BRK(thePercent >= 0.0F && thePercent <= 1.0F);
		outResult.SetXY(mStart.GetXY().Lerp(mEnd.GetXY(), thePercent));
                         
        
		// we modified things, so return dirty 
		theResult = true;
	}
    else
    {
        outResult.SetXY(mEnd.GetXY());
    }
    
	/////////////////////////////////////////////////////////////
	// falloff
	if(eLightSourceMorphFlags::HasFlag(mFlags, eLightSourceMorphFlags::UpdateFallOff))
	{
		if(mNextFallOffTime < inTime)
		{
			mStart.SetFallOffPercent( mEnd.GetFallOffPercent());
			mNextFallOffTime = inTime + GetRandomInt(mFallOffTimeRange);
			mStartFallOffTime = inTime;
			mEnd.SetFallOffPercent( GetRandomFloat(mFallOffRange));
		}
        
		float thePercent = (float)(1.0 - (((double)mNextFallOffTime - (double)inTime) / ((double)mNextFallOffTime - (double)mStartFallOffTime)));
		ASSERT_BRK(thePercent >= 0.0F && thePercent <= 1.0F);
		outResult.SetFallOffPercent( Lerp(mStart.GetFallOffPercent(), mEnd.GetFallOffPercent(), thePercent));
        
		// we modified things, so return dirty 
		theResult = true;
	}
    else
    {
        outResult.SetFallOffPercent( mEnd.GetFallOffPercent());
    }
    
	/////////////////////////////////////////////////////////////
	// Radius
	if(eLightSourceMorphFlags::HasFlag(mFlags, eLightSourceMorphFlags::UpdateRadius))
	{
		if(mNextRadiusTime < inTime)
		{
            mStart.SetScreenRadius( mEnd.GetScreenRadius());
            mNextRadiusTime = inTime + GetRandomInt(mRadiusTimeRange);
            mStartRadiusTime = inTime;
            
            if(HasFlag(eLightSourceMorphFlags::DieNow))
            {
                // die.
                SetFlag(eLightSourceMorphFlags::Dead, true);
            }
            else
            {               
                if(HasFlag(eLightSourceMorphFlags::QueueDeath))
                {
                    mEnd.SetScreenRadius( 0.01F);                
                    SetFlag(eLightSourceMorphFlags::DieNow, true);
                }
                else
                    mEnd.SetScreenRadius( GetRandomFloat(mRadiusRange));
            }
        }
        
		float thePercent = (float)(1.0 - (((double)mNextRadiusTime - (double)inTime) / ((double)mNextRadiusTime - (double)mStartRadiusTime)));
		ASSERT_BRK(thePercent >= 0.0F && thePercent <= 1.0F);
		outResult.SetScreenRadius( Lerp(mStart.GetScreenRadius(), mEnd.GetScreenRadius(), thePercent));
        
		// we modified things, so return dirty 
		theResult = true;
	}	
    else
    {
        outResult.SetScreenRadius( mEnd.GetScreenRadius());
    }
    
	return theResult;
}

// =============================================================================================================
// Update - update this item
bool Light2DPhysics::UpdateToMeshResult(uint32 inCurrentTime)
{
    LightSource theTemp;
    bool theResult = Update(inCurrentTime, theTemp);   

    if(mMeshResult)
    {
        // convert it.
        mMeshResult->SetColor(theTemp.GetColor().GetRaw());
        mMeshResult->SetXY(theTemp.GetXY());
        mMeshResult->SetScreenRadius(theTemp.GetScreenRadius());
        mMeshResult->SetFallOffPercent(theTemp.GetFallOffPercent());
        mMesh->MarkDirty();
    }
  
    return theResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// returns a new color
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
ColorF Light2DPhysicsConstrainedRGBA::GetNewColor(float inRed, float inGreen, float inBlue, float inAlpha)
{
    ColorF theResult;
    
  	// cache the app 
    theResult.SetRed  ((inRed   < 0.0F) ? GetRandomFloat(mRangeRed) : inRed);
    theResult.SetGreen((inGreen < 0.0F) ? GetRandomFloat(mRangeGreen) : inGreen);
    theResult.SetBlue ((inBlue  < 0.0F) ? GetRandomFloat(mRangeBlue) : inBlue);
    theResult.SetAlpha((inAlpha < 0.0F) ? GetRandomFloat(mRangeAlpha) : inAlpha);
    return theResult;
}


END_NAMESPACE(LunchtimeStudios)

