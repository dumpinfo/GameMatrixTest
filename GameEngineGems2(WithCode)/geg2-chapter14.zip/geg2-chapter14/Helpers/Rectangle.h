/*  ************************************************************************************************
 *  Rectangle.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Very simple Rectangle class
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "Helpers/CommonTypes.h"
#include "Helpers/Point.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////////////////
// Simple Rectangle class (templatized)
////////////////////////////////////////////////////////////////////////////////////////////////////
template< typename T >
class Rectangle
{
public:				
                                Rectangle(void) : top(0), left(0), bottom(0), right(0) { }

                                Rectangle(const Point< T >& inTopLeft,	const Point< T >& inBottomRight)
                                        { top = inTopLeft.GetY(); left = inTopLeft.GetX();
                                          bottom = inBottomRight.GetY(); right = inBottomRight.GetX(); }
        
                                Rectangle(const Point< T >& inPoint)
                                        { top = inPoint.GetY(); left = inPoint.GetX();
                                          bottom = inPoint.GetY(); right = inPoint.GetX(); }
        
                                Rectangle(T inLeft, T inTop, T inRight, T inBottom)
                                        { left = inLeft; top = inTop; right = inRight; bottom = inBottom; }
        
                               ~Rectangle(void)
                                        { }
								
	 bool                       operator== (const Rectangle< T >& inRect) const
									{ return (top    == inRect.top   && 
											  left   == inRect.left  && 
											  right  == inRect.right &&
											  bottom == inRect.bottom); }

	 bool                       operator!= (const Rectangle< T >& inRect) const
									{ return (top    != inRect.top   ||
											  left   != inRect.left  ||
											  right  != inRect.right ||
											  bottom != inRect.bottom); }

	 Rectangle< T >&            operator= (const Rectangle< T >& inRect)
									{ top = inRect.top; left = inRect.left;
									  bottom = inRect.bottom; right = inRect.right; return *this; }

	 void                       ClearRectangle(void)
									{ top = (T)0; left = (T)0; bottom = (T)0; right = (T)0;	}
    
                                // clear this rect
     void                       Clear(void)
                                    { bottom = 0; right = 0; top = 0; left = 0; }

	 bool                       Contains(const Point< T >& inPoint) const
									{ return (inPoint.GetX() >= left && inPoint.GetX() <= right &&
											  inPoint.GetY() >= top && inPoint.GetY() <= bottom); }

	 bool                       Contains(T inX, T inY) const
									{ return (inX >= left && inX <= right &&
											  inY >= top && inY <= bottom); }

	 bool                       Contains(const Rectangle& inRect) const
									{ return ((inRect.left >= left) && (inRect.right <= right) &&
											  (inRect.top >= top) && (inRect.bottom <= bottom)); }


	 void                       Expand(T inAmount, bool inBoundToZero = true)
									{	left		-= inAmount;
										top		-= inAmount;
										right	+= inAmount;
										bottom	+= inAmount;

										if(inBoundToZero)
										{
											left	= std::max(left, (T)0);
											top	= std::max(top, (T)0);
										}
									}

	 void                       Expand(T inX, T inY, bool inBoundToZero = true)
									{	left	-= inX;
										top		-= inY;
										right	+= inX;
										bottom	+= inY;

										if(inBoundToZero)
										{
											left = std::max(left, (T)0);
											top	= std::max(top, (T)0);
										}
									}

	 void                       Expand(const Point< T >& inPoint, bool inBoundToZero = true)
									{	left	-= inPoint.x;
										top		-= inPoint.y;
										right	+= inPoint.x;
										bottom	+= inPoint.y;

										if(inBoundToZero)
										{
											left	= std::max(left, (T)0);
											top		= std::max(top, (T)0);
										}
									}

	 void                       Extend(const Point< T >& inPoint)
									{	left	= std::min(left, inPoint.GetX());
										right	= std::max(right, inPoint.GetX());
										top		= std::min(top, inPoint.GetY());
										bottom	= std::max(bottom, inPoint.GetY()); }

	void						Extend(const Rectangle< T >& inBox)
									{
										Extend(inBox.GetTopLeft());
										Extend(inBox.GetBottomRight());
									}
    
    static Rectangle< T >      FromPointAndWidthHeight(const Point< T >& inTL, const Point< T >& inWH)
                                    { return Rectangle< T >(inTL, inTL + inWH); }

    T                          GetBottom(void) const
									{ return bottom; }
	
    Point< T >                 GetBottomLeft(void) const
									{ Point< T > thePoint(left, bottom); return thePoint; }	
	
    Point< T >                 GetBottomRight(void) const
									{ Point< T > thePoint(right, bottom); return thePoint; }	

    Point< T >                  GetCenter(void) const 
									{	return Point< T >(left + (GetWidth() / (T)2), top + (GetHeight() / (T)2)); }

	 T                          GetHeight(void) const
									{ return bottom - top; }
	
	 T                          GetLeft(void) const
									{ return left; }

	 T                          GetRight(void) const
									{ return right; }

	 T                          GetTop(void) const
									{ return top; }
	
	 Point< T >                 GetTopLeft(void) const
									{ Point< T > thePoint(left, top); return thePoint; }	
                                    
     const Point< T >&          GetFastTopLeft(void) const
                                    { return *((const Point< T >*)(&left)); }
     const Point< T >&          GetFastBottomRight(void) const
                                    { return *((const Point< T >*)(&right)); }
	
	 Point< T >                 GetTopRight(void) const
									{ Point< T > thePoint(right, top); return thePoint; }	

	 T                          GetWidth(void) const
									{ return right - left; }

	 Point< T >                 GetWidthHeight(void) const 
									{ return Point< T >(GetWidth(), GetHeight()); }

	 bool                       IsZero(void) const 
									{ return ((right-left == (T)0) && (bottom-top == (T)0)); }
    
    void                        TranslateTo(const Point< T >& inPt)
                                    {
                                        T theW = GetWidth();
                                        T theH = GetHeight();
                                        left = inPt.x;
                                        top = inPt.y;
                                        right = left + theW;
                                        bottom = top + theH;
                                    }

	 void                       SetAsSinglePoint(const Point< T >& inPoint)
									{
										top = inPoint.GetY();	bottom = inPoint.GetY(); 
										left = inPoint.GetX();	right = inPoint.GetX();
									}

	 void                       SetAsSinglePoint(T inX, T inY)
									{	top = inY; bottom = inY;
										left = inX; right = inX;
									}

	 void                       Set(T inLeft, T inTop, T inRight, T inBottom)
									{
										left = inLeft;
										top = inTop;
										right = inRight;
										bottom = inBottom;
									}

	 void                       SetBottom(T inBottom)
									{ bottom = inBottom; }

	 void                       SetBottomRight(const Point< T >& inPoint)
									{ bottom = inPoint.GetY(); right = inPoint.GetX(); }
	
	 void                       SetLeft(T inLeft)
									{ left = inLeft; }
	
	 void                       SetRight(T inRight)
									{ right = inRight; }
	
	 void                       SetTop(T inTop)
									{ top = inTop; }

	 void                       SetTopLeft(const Point< T >& inPoint)
									{ top = inPoint.GetY(); left = inPoint.GetX(); }
		

	T							left;		// left
	T							top;		// top
	T							right;		// right
	T							bottom;		// bottom
};

typedef Rectangle< float > RectangleF;
typedef Rectangle< double > RectangleD;
typedef Rectangle< int32 > RectangleI;

END_NAMESPACE(LunchtimeStudios)

