/*  ************************************************************************************************
 *  Point.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Simple point class
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "Helpers/CommonTypes.h"
#include "Helpers/CommonHelpers.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

template < class T >
class Point 
{
public:
    typedef T           value_type;
	
						Point(T inX, T inY) : x(inX), y(inY) { }
    					Point(const T& inX, const T& inY, bool inNormalize) : x(inX), y(inY) { if(inNormalize) { VectorNormalize(); } }
						Point(const Point< T >& inPoint) : x(inPoint.x), y(inPoint.y) { } 
 						Point(void) : x(0), y(0) { }
                        Point(float inYaw)   { x = (T)cos((float)inYaw + kHalfPI); y = (T)sin((float)inYaw + kHalfPI); }
						~Point(void) { }
                        
   const T*             AsArray(void) const { return (const T*)&x; }
	
	void				Clear(void) { x = 0; y = 0; }

    Point< float >      ComputeVectorTo2D(const Point< T >& inThat, bool inNormalize) const 
                            { return Point< float >(((float)inThat.x - (float)x), ((float)inThat.y - (float)y), inNormalize); }

	T                   DistanceTo(const Point< T >& inPoint) const
                            { return (T)(sqrtf((float)Square(x - inPoint.x) + Square(y - inPoint.y))); }

	T                   DistanceToSquared(const Point< T >& inPoint) const
                            { return Square(x - inPoint.x) + Square(y - inPoint.y); }
    
	T                   DistanceToSquared(T inX, T inY) const
                            { return Square(x - inX) + Square(y - inY); }    
   
    T                   GetX(void) const
                            { return x; }

	T                   GetY(void) const
                            { return y; }
   
	float               GetYawTo(const Point< T >& inPoint) const
                            { return atan2f(((float)x - (float)inPoint.x), ((float)inPoint.y - (float)y)); }

    template< typename K >
    Point< K >          GetPointAt(const Point< float >& inDirection, K inT) const
                            { return Point< K >(x + (inT * (K)inDirection.x), y + (inT * (K)inDirection.y)); }

                        // returns true if we're almost equal
    bool                IsAlmostZero(T inThreshold = (T)kEpsilon) const
                            {
                                return (std::abs(x) <= inThreshold && std::abs(y) <= inThreshold);
                            } 
    
    Point< T >           Lerp(const Point< T >& inEnd, float inPercent) const
                                {
                                    ASSERT_BRK(inPercent <= 1.0F);
                                    float theDistance = DistanceTo(inEnd);
                                    if(fabs(theDistance) <= kEpsilon)
                                        return *this;
                                    
                                    Point theVector = ComputeVectorTo2D(inEnd, true);
                                    return GetPointAt(theVector, theDistance * inPercent);
                                }
      
	void					Normalize(T inValue);
    
                            // fill in our array
    void                    ToArray2(T* ioArray) const
                                {
                                    if(ioArray == NULL)
                                        return;

                                    ioArray[0] = x;
                                    ioArray[1] = y;
                                }


	void                    SetX(const T& inX)
								{ x = inX; }

	void                    SetY(const T& inY) 
								{ y = inY; }

	void                    SetXY(const T& inX, const T& inY)
								{ x = inX;
								  y = inY; }
                                  
    float                   GetMagnitude(void) const
                                { return sqrtf(Square((float)x) + Square((float)y)); }

    void				    VectorNormalize(void)
                                {   float theMagnitude;
                                    VectorNormalize(theMagnitude); }

    void					VectorNormalize(float& outMagnitude)
                                {	outMagnitude = GetMagnitude();
                                    float theInvMagnitude;

                                    if (NOT_ZERO(outMagnitude))
                                    {
                                        theInvMagnitude = 1.0F / outMagnitude;
                                        x *= theInvMagnitude; 
                                        y *= theInvMagnitude; 
                                    }
                                    else
                                    {
                                        x = 0.0F;
                                        y = 0.0F;
                                    }
                                }


	Point<T>&           operator= (const Point<T>& inPoint)
								{ x = inPoint.x; 
							      y = inPoint.y; 
								  return *this; }

	bool				operator== (const Point<T>& inPoint) const
								{ return ((x == inPoint.x) && 
										  (y == inPoint.y)); }

	bool				operator!= (const Point<T>& inPoint) const
								{ return ((x != inPoint.x) || 
										  (y != inPoint.y)); }

	Point<T>&           operator+= (const Point<T>& inPoint)
								{ x += inPoint.x; 
								  y += inPoint.y; 
								  return *this; }

    Point<T>&           operator*= (T inAmt)
								{ x *= inAmt; y *= inAmt; return *this; }
    
	Point<T>&           operator-= (const Point<T>& inPoint)
								{ x -= inPoint.x; 
								  y -= inPoint.y; 
								  return *this; }

    Point<T>            operator- (const Point<T>& inThat)
								{ return Point<T>(x - inThat.x, y - inThat.y); }

    Point<T>            operator+ (const Point<T>& inThat)
								{ return Point<T>(x + inThat.x, y + inThat.y); }

    Point<T>            operator* (const Point<T>& inThat)
								{ return Point<T>(x * inThat.x, y * inThat.y); }

	Point<T>            operator/ (const Point<T>& inThat)
								{ return Point<T>(x / inThat.x, y / inThat.y); }

	bool				operator< (const Point<T>& inPoint) const
								{ return ((y < inPoint.y) || ((y == inPoint.y) && (x > inPoint.x))); }

	bool				operator> (const Point<T>& inPoint) const
								{ return ((y > inPoint.y) || ((y == inPoint.y) && (x < inPoint.x))); }

	// Streaming operators. 
	friend std::istream&    operator >> ( std::istream &iStream, Point< T >& outItem )
	                            { return iStream >> outItem.x >> outItem.y; }

	friend std::ostream&    operator << ( std::ostream &oStream, const Point< T >& inItem )
	                            { return oStream << inItem.x << inItem.y; }

	T						x;	/* X position */
	T						y;	/* Y position */

};

template< class T >
Point< T >	operator+ (const Point< T >& inFirst, const Point< T >& inSecond) 
{ 
	return Point< T >(inFirst.x + inSecond.x, inFirst.y + inSecond.y); 
}

template< class T >
Point< T >	operator- (const Point< T >& inFirst, const Point< T >& inSecond) 
{ 
	return Point< T >(inFirst.x - inSecond.x, inFirst.y - inSecond.y); 
}

template< class T >
Point< T >	operator* (const Point< T >& inFirst, const Point< T >& inSecond) 
{ 
	return Point< T >(inFirst.x * inSecond.x, inFirst.y * inSecond.y); 
}

template< class T >
Point< T >	operator/ (const Point< T >& inFirst, const Point< T >& inSecond) 
{ 
	return Point< T >(inFirst.x / inSecond.x, inFirst.y / inSecond.y); 
}

typedef Point< float > PointF;
typedef Point< int32 > PointI;
typedef Point< double > PointD;


END_NAMESPACE(LunchtimeStudios)

