/*  ************************************************************************************************
 *  Color.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Simple color wrapper
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "Helpers/CommonTypes.h"

// avoid namespace collision
BEGIN_NAMESPACE(LunchtimeStudios)

class ColorF 
{
public:
                                        ColorF(float inRed = 1.0F, float inGreen = 1.0F, float inBlue = 1.0F, float inAlpha = 1.0F) : r(inRed), g(inGreen), b(inBlue), a(inAlpha) { }
                                        ColorF(const ColorF& inColor) : r(inColor.r), g(inColor.g), b(inColor.b), a(inColor.a) { }
                                        ~ColorF(void) { }
                                        
    float                               GetRed(void) const        { return r; }
    float                               GetGreen(void) const      { return g; }
    float                               GetBlue(void) const       { return b; }
    float                               GetAlpha(void) const      { return a; }
    void                                clear(void)               { a = 1.0F; r= 1.0F; g = 1.0F; b = 1.0F; }
    const float*                        GetRaw(void) const        { return (float*)&r; }
    void                                SetRaw(const float* inRGBA) { r = inRGBA[0]; g = inRGBA[1]; b = inRGBA[2]; a = inRGBA[3]; }
    void                                SetRed(float inValue)      { r = inValue; }
    void                                SetGreen(float inValue)    { g = inValue;  }
    void                                SetBlue(float inValue)     { b = inValue; }
    void                                SetAlpha(float inValue)    { a = inValue; }
    bool                                Eq(const ColorF& inOther) const     { return (r == inOther.r && g == inOther.g && b == inOther.b && a == inOther.a);  }
    bool                                NotEq(const ColorF& inOther) const  { return (r != inOther.r || g != inOther.g || b != inOther.b || a != inOther.a); }
    void                                SetRGBA(float inRed, float inGreen, float inBlue, float inAlpha) { r = inRed; g = inGreen; b = inBlue; a = inAlpha; }
    void                                CopyToRawUint8(uint8* inRGBA) const
                                            {
                                                inRGBA[0] = (uint8)(r * 255.0F);
                                                inRGBA[1] = (uint8)(g * 255.0F);
                                                inRGBA[2] = (uint8)(b * 255.0F);
                                                inRGBA[3] = (uint8)(a * 255.0F);
                                            }
    
    static const ColorF&                GetEmptyColor(void) { static ColorF sColor; return sColor; }
    ColorF                              Lerp(const ColorF& inEnd, GLfloat inPercent) const { return Lerp(*this, inEnd, inPercent); }
    static ColorF                       Lerp(const ColorF& inStart, const ColorF& inEnd, GLfloat inPercent)
                                            {
                                                return ColorF(LERP_ITEM(inStart.r, inEnd.r, inPercent),
                                                              LERP_ITEM(inStart.g, inEnd.g, inPercent),
                                                              LERP_ITEM(inStart.b, inEnd.b, inPercent),
                                                              LERP_ITEM(inStart.a, inEnd.a, inPercent));
                                            }

    void                                LerpInto(const ColorF& inEnd, GLfloat inPercent, ColorF& outResult) const
                                            {
                                                outResult.r = LERP_ITEM(r, inEnd.r, inPercent);
                                                outResult.g = LERP_ITEM(g, inEnd.g, inPercent);
                                                outResult.b = LERP_ITEM(b, inEnd.b, inPercent);
                                                outResult.a = LERP_ITEM(a, inEnd.a, inPercent);
                                                
                                            }
    
	bool                                operator==(const ColorF& inOther) const { return (r == inOther.r && g == inOther.g && b == inOther.b && a == inOther.a); }
    bool                                operator!=(const ColorF& inOther) const { return (r != inOther.r || g != inOther.g || b != inOther.b || a != inOther.a); }
    
    bool                                operator< (const ColorF& inColor) const
                                            {
                                                return  (   (r < inColor.r) ||
                                                         (r == inColor.r && g < inColor.g)  || 
                                                         (r == inColor.r && g == inColor.g && b < inColor.b) || 
                                                         (r == inColor.r && g == inColor.g && b == inColor.b && a < inColor.a));
                                            }
    
    ColorF&                             operator=(const ColorF& inA)
                                            {
                                                r = inA.r;
                                                g = inA.g;
                                                b = inA.b;
                                                a = inA.a;
                                                return *this;
                                            }
        
private:
    
    float                               r;
    float                               g;
    float                               b;
    float                               a;
    
};




END_NAMESPACE(LunchtimeStudios)

