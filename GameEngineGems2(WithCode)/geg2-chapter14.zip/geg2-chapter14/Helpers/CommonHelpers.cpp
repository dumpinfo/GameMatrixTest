/*  ************************************************************************************************
 *  CommonHelpers.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include <time.h>
#include <sys/time.h>
#include "CommonHelpers.h"
#include "Point.h"
#include "Rectangle.h"

// premade mac libs for libpng can be found: http://ethan.tira-thompson.org/Mac_OS_X_Ports.html
// otherwise, go to http://www.libpng.org/pub/png/libpng.html

BEGIN_NAMESPACE(LunchtimeStudios)

#define PNG_HEADER_SIZE 8


////////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////////
PNGFile::PNGFile(const std::string& inFileName)
:   mFileName(inFileName)
,   mWidth(0)
,   mHeight(0)
,   mGLID(0)
,   mBits(NULL)
,   mArraySize(0)
,   mBitValue(4) 
{
    
}

////////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////////
PNGFile::~PNGFile(void)
{
    doClearBitsAndGLTextureID();
}

////////////////////////////////////////////////////////////////////////////////////////////
/// builds our openGL ID
////////////////////////////////////////////////////////////////////////////////////////////
void PNGFile::doBuildGLID(void)
{
    glGenTextures( 1, &mGLID );
    glBindTexture( GL_TEXTURE_2D, mGLID );
    
    //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    
    // The new 'glTexImage2D' function, the prime difference
    // being that it gets the width, height and pixel information
    // from 'bits', which is the RGB pixel data..
    ASSERT_BRK(mBits != NULL);
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, mWidth, mHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, mBits);

    // finished with this texture. 
    glBindTexture( GL_TEXTURE_2D, 0 );
    
    // finished with our data
    delete mBits;
    mBits = NULL;
}


////////////////////////////////////////////////////////////////////////////////////////////
/// removes our GL Items and bits if we still have them
////////////////////////////////////////////////////////////////////////////////////////////
void PNGFile::doClearBitsAndGLTextureID(void)
{
    if(mGLID != 0)
    {
        glDeleteTextures(1, &mGLID );
        mGLID = 0;
    }
    
    if(mBits != NULL)
    {
        delete[] mBits;
        mBits = NULL;
    }
    
}

////////////////////////////////////////////////////////////////////////////////////////////
/// flip our pixels
////////////////////////////////////////////////////////////////////////////////////////////
void PNGFile::doImageFlip( void )
{
	unsigned int theY = 0;
    unsigned int theSize = mWidth * mHeight * mBitValue;
    unsigned int theRows = mWidth * mBitValue;
	unsigned char* theBuffer = ( unsigned char * ) malloc( theSize );
    
	while( theY != mHeight )
	{
		memcpy( theBuffer + ( theY * theRows ), mBits + ( ( ( mHeight - theY ) - 1 ) * theRows ), theRows );
		++theY;
	}
	
	memcpy( &mBits[ 0 ], &theBuffer[ 0 ], theSize );    
	free( theBuffer );
} 

////////////////////////////////////////////////////////////////////////////////////////////
/// load and return our GL texture ID
////////////////////////////////////////////////////////////////////////////////////////////
GLuint PNGFile::load(void)
{
    // ensure we're not loaded
    ASSERT_BRK(mGLID == 0);
    
    mWidth = 0;
    mHeight = 0;
    
    int keep_rgb = 1;
    int keep_alpha = 1;
    int pixel_size = 4;
           
    // needs a file name
    if(mFileName.empty())
        return 0;
    
    FILE *PNG_file = fopen(mFileName.c_str(), "rb");
    if (PNG_file == NULL)
    {
        ASSERT_BRK("No texture to load" == NULL);
        return 0;
    }
    
    GLubyte PNG_header[PNG_HEADER_SIZE];
    
    fread(PNG_header, 1, PNG_HEADER_SIZE, PNG_file);
    if (png_sig_cmp(PNG_header, 0, PNG_HEADER_SIZE) != 0)
    {
        ASSERT_BRK(false);
        return false;
    }
    
    png_structp PNG_reader = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (PNG_reader == NULL)
    {
        ASSERT_BRK(false);
        fclose(PNG_file);
        return false;
    }
    
    png_infop PNG_info = png_create_info_struct(PNG_reader);
    if (PNG_info == NULL)
    {
        ASSERT_BRK(false);
        png_destroy_read_struct(&PNG_reader, NULL, NULL);
        fclose(PNG_file);
        return false;
    }
    
    png_infop PNG_end_info = png_create_info_struct(PNG_reader);
    if (PNG_end_info == NULL)
    {
        ASSERT_BRK(false);
        png_destroy_read_struct(&PNG_reader, &PNG_info, NULL);
        fclose(PNG_file);
        return false;
    }
    
    if (setjmp(png_jmpbuf(PNG_reader)))
    {
        ASSERT_BRK(false);
        png_destroy_read_struct(&PNG_reader, &PNG_info, &PNG_end_info);
        fclose(PNG_file);
        return false;
    }
    
    png_init_io(PNG_reader, PNG_file);
    png_set_sig_bytes(PNG_reader, PNG_HEADER_SIZE);
    
    png_read_info(PNG_reader, PNG_info);

    // get our width/height
    mWidth = png_get_image_width(PNG_reader, PNG_info);
    mHeight = png_get_image_height(PNG_reader, PNG_info);
    
    png_uint_32 bit_depth, color_type;
    bit_depth = png_get_bit_depth(PNG_reader, PNG_info);
    color_type = png_get_color_type(PNG_reader, PNG_info);
    
    if (color_type == PNG_COLOR_TYPE_PALETTE)
    {
        ASSERT_BRK(keep_rgb);
        png_set_palette_to_rgb(PNG_reader);
    }
       
    if (keep_rgb)
    {
        if (color_type == PNG_COLOR_TYPE_GRAY ||
            color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
        {
            png_set_gray_to_rgb(PNG_reader);
        }
    }
    else
    {
        if (color_type == PNG_COLOR_TYPE_RGB ||
            color_type == PNG_COLOR_TYPE_RGB_ALPHA)
        {
            png_set_rgb_to_gray_fixed(PNG_reader, 1, 0, 0);
        }
    }
    
    if (keep_alpha)
    {
        if (png_get_valid(PNG_reader, PNG_info, PNG_INFO_tRNS))
        {
            png_set_tRNS_to_alpha(PNG_reader);
        }
        else
        {
            png_set_filler(PNG_reader, 0xff, PNG_FILLER_AFTER);
        }
    }
    else
    {
        if (color_type & PNG_COLOR_MASK_ALPHA)
        {
            png_set_strip_alpha(PNG_reader);
        }
    }
    
    if (bit_depth == 16)
    {
        png_set_strip_16(PNG_reader);
    }
    
    png_read_update_info(PNG_reader, PNG_info);
    
    // make our post-load data 
    mBitValue = pixel_size;
    mArraySize = mWidth * mHeight * mBitValue;
    ASSERT_BRK(mBits == NULL);
    mBits = new GLubyte[mArraySize];  
    
    png_byte** PNG_rows = (png_byte**)malloc(mHeight * sizeof(png_byte*));   
    unsigned int row;
    for (row = 0; row < mHeight; ++row)
    {
        PNG_rows[mHeight - 1 - row] = mBits + (row * pixel_size * mWidth);
    }
    
    png_read_image(PNG_reader, PNG_rows);
    free(PNG_rows);
    
    png_destroy_read_struct(&PNG_reader, &PNG_info, &PNG_end_info);
    fclose(PNG_file);
    
    // flip our data.
    doImageFlip(); 
    
    // build our GL ID
    doBuildGLID();
    
    // return our openGL texture ID
    return mGLID;
}

////////////////////////////////////////////////////////////////////////////////////////////
/// unload our png
////////////////////////////////////////////////////////////////////////////////////////////
void PNGFile::unload(void)
{
    doClearBitsAndGLTextureID();
}


////////////////////////////////////////////////////////////////////////////////////////////
/// return the current time of day in milliseconds
////////////////////////////////////////////////////////////////////////////////////////////
uint32 ComputeCurrentTime(void)
{
    struct timeval theTime;
    gettimeofday(&theTime, NULL);
    return (uint32)((theTime.tv_sec * 1000) + (theTime.tv_usec / 1000));
    
}


END_NAMESPACE(LunchtimeStudios)

