/*  ************************************************************************************************
 *  CommonTypes.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Handles 
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/
#pragma once

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <GLUT/glut.h>
#include <OpenGL/glext.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <assert.h>
#include <libpng/png.h>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

// namespace macro
#define BEGIN_NAMESPACE(x)  namespace x {
#define END_NAMESPACE(x) }

// bit flags macro
#define ENUM_HASFLAG() static bool	HasFlag(Type inFlags, Type inHasThisFlag) { return ((inFlags & inHasThisFlag) != 0); }
#define ENUM_SETFLAG() static void	SetFlag(Type& ioFlags, Type inFlagToSet, bool inSetTrue) { if(inSetTrue) { ioFlags |= inFlagToSet; } else if(HasFlag(ioFlags, inFlagToSet) == true) { ioFlags &= ~(inFlagToSet); }}
#define ENUM_BITFLAGS() \
    ENUM_HASFLAG() \
    ENUM_SETFLAG()

// lerp macro
#define LERP_ITEM(Astart, Aend, Apercent) (Astart + (Aend - Astart) * Apercent)


// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////////
// data types
////////////////////////////////////////////////////////////////////////////////////////////
typedef signed char		int8;
typedef signed short	int16;
typedef signed int		int32;
typedef unsigned char   uint8;
typedef unsigned short  uint16;
typedef unsigned int    uint32;
typedef unsigned char	memory;

// namespaces wrap enums
namespace eVertexCorner
{
    // our eVertexCorner::Type is a uint8
	typedef uint8 Type;
	enum
	{
		BottomLeft	= 0,
		BottomRight	= 1,
		TopRight	= 2, 
		TopLeft		= 3,
		Max			= TopLeft + 1
	};
}

const float kTwoPI						= 6.283185307F;				/* 2 * pi */
const float kPI							= 3.141592654F;				/* pi */
const float kHalfPI						= 1.570796326F;				/* pi / 2 */
const float kPIOverTwo					= kHalfPI;
const float kEpsilon                    = 0.0001F;

extern int32 GetDefaultWindowWidth(void);
extern int32 GetDefaultWindowHeight(void);

END_NAMESPACE(LunchtimeStudios)

#define NOT_ZERO(n)						((n) < -kEpsilon  || (n) >  kEpsilon)
#define IS_ZERO(n)						((n) >= -kEpsilon && (n) <= kEpsilon)

////////////////////////////////////////////////////////////////////////////////////////////
// Assert helpers
////////////////////////////////////////////////////////////////////////////////////////////

// this stops directly here in the debugger
#if defined( _MSC_VER )
    // windows version
#define LTSBREAK_CODE() __asm { int 3 }
#else
    // MAC version
#define LTSBREAK_CODE() asm("int3");
#endif

BEGIN_NAMESPACE(LunchtimeStudios)
extern void AssertDump(const char* inFile, unsigned long inLine, const char* inCondition);
END_NAMESPACE(LunchtimeStudios)

// do this in debug
#if !defined(NDEBUG)
#define DEBUG_ONLY_CODE(x)			x
#define ASSERT_BRK(inCondition)		{ if(!(inCondition)) { LunchtimeStudios::AssertDump(__FILE__, __LINE__, #inCondition); LTSBREAK_CODE() }}
#endif


BEGIN_NAMESPACE(LunchtimeStudios)
extern void AssertDump(const char* inFile, unsigned long inLine, const char* inCondition);

// does a dynamic_cast in debug, normal static_cast in release
template< typename TRESULT, typename TORIGINAL >
inline TRESULT* CheckedCast(TORIGINAL* inObject)
{
	ASSERT_BRK(inObject == NULL || dynamic_cast<TRESULT*>(inObject) != NULL);
	return static_cast<TRESULT*>(inObject);
}

END_NAMESPACE(LunchtimeStudios)




