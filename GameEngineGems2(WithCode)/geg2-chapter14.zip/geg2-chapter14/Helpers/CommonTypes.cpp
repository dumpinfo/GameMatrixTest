/*  ************************************************************************************************
 *  CommonTypes.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "CommonTypes.h"

BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
// AssertDump - Dump to our log file, but don't crash.
/////////////////////////////////////////////////////////////////////////////////////////
void AssertDump(const char* inFile, unsigned long inLine, const char* inCondition)
{
    // output it.
    std::cout << inFile << " (" << inLine << ")  : Assertion failure (" << inCondition << ")" << std::endl;
}

int32 GetDefaultWindowWidth(void)
{
    return 512;
}

int32 GetDefaultWindowHeight(void)
{ 
    return 512; 
}
  

END_NAMESPACE(LunchtimeStudios)

