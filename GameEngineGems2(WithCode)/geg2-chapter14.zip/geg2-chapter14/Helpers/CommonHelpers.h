/*  ************************************************************************************************
 *  
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Desc
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// premade mac libs for libpng can be found: http://ethan.tira-thompson.org/Mac_OS_X_Ports.html
// otherwise, go to http://www.libpng.org/pub/png/libpng.html

// includes
#include "CommonTypes.h"

// avoid namespace collision
BEGIN_NAMESPACE(LunchtimeStudios)

class PNGFile
{
public:
                            PNGFile(const std::string& inFileName = std::string());
    virtual                 ~PNGFile(void);

                            // return our openGL ID
    GLuint                  getGLID(void) const
                                { return mGLID; }
    
                            // return our width/height
    int32                   getWidth(void) const
                                { return mWidth; }
    int32                   getHeight(void) const
                                { return mHeight; }
  
                            // returns GL Texture ID on successful load
    virtual GLuint          load(void);
    virtual GLuint          load(const std::string& inName)
                                { mFileName = inName; return load(); }
    
                            // unload this png from graphics
    virtual void            unload(void);

protected:
    
                            PNGFile(const PNGFile& notImplSoNoCopyingAllowed);
                            PNGFile& operator= (const PNGFile& notImplSoNoCopyingAllowed);
    
                            // flip our pixels
    virtual void            doImageFlip(void);
    virtual void            doBuildGLID(void);
    void                    doClearBitsAndGLTextureID(void);
    
    std::string             mFileName;
    GLubyte*                mBits;
    size_t                  mArraySize;
    unsigned char           mBitValue;
    int32                   mWidth;
    int32                   mHeight;
    GLuint                  mGLID;
    
};

// return our current path
static std::string GetCurrentPath(void)
{
    char theBuffer[1024];
    getcwd(theBuffer, 1024);
    return std::string(theBuffer);
}

// normal percentage 
static float GetRandomPercentage(void)
{
    return (rand() % 100) / 100.0F; 
}

// get a random int between two numbers
static long	GetRandomIntegerBetween(long inMin, long inMax)
{	float theGeneratedNum;
    long theRandomNumber;
    long theTempMaximum = inMax + 1;
    theGeneratedNum = GetRandomPercentage();
    theRandomNumber = (long)(floorf(inMin + (theGeneratedNum * (theTempMaximum - inMin))));
    if (theRandomNumber == theTempMaximum)
        theRandomNumber = inMax;

    return theRandomNumber;
}	

// return a random bool
static bool	GetRandomBool(void)
{ 
    return (GetRandomPercentage() <= 0.5F); 
}


// return a random number between floats
static float GetRandomFloatBetween(float inMin, float inMax)
{	
    return (inMin + (GetRandomPercentage() * (inMax - inMin))); 
}

// return random integers
static int32 GetRandomInt(const std::pair< int32, int32 >& inMinMax)
{
    return GetRandomIntegerBetween(inMinMax.first, inMinMax.second);
}

// return random float
static float GetRandomFloat(const std::pair< float, float >& inMinMax)
{
    return GetRandomFloatBetween(inMinMax.first, inMinMax.second);
}

// DO THE LERP!
template< typename T >
T Lerp(T inStart, T inEnd, T inPercent)
{
    return LERP_ITEM(inStart, inEnd, inPercent);
}

// Math Helpers
template < typename T > inline T Square(T inData)  { return (inData * inData); }	

/// returns true if these are equal (enough)
static inline bool equals(const float a, const float b, const float tolerance = kEpsilon)
{
    return (a + tolerance >= b) && (a - tolerance <= b);
}

// returns the current time in milliseconds
extern uint32 ComputeCurrentTime(void);

END_NAMESPACE(LunchtimeStudios)

