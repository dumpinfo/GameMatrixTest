/*  ************************************************************************************************
 *  GraphicObjects.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  simple impl of a graphic object base, and derived graphic quad and graphic texture
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

#include "Helpers/CommonHelpers.h"
#include "Mesh/TextureMesh.h"
#include "Mesh/TextureMeshModifierLight.h"

BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

class GraphicObject
{
public:
                            GraphicObject(const std::string& inName, uint32 inVertsPerRow = 96, const ColorF& inDebugTextColor = ColorF());
    virtual                 ~GraphicObject(void);

                            // render
    virtual void            Render(RenderStates& ioStates) = 0;
    
                            // returns true if we're visible
    bool                    IsVisible(void) const
                                { return mVisible; }
                            
                            // sets our visible
    virtual void            SetVisible(bool inVisible)
                                { mVisible = inVisible; }
    
                            // returns our bounds in world space
    const RectangleF&       GetBounds(void) const
                                { return mBounds; }
                            
                            // returns our debug text color
    const ColorF&           GetDebugTextColor(void) const
                                { return mDebugTextColor; }
    
                            // return our mesh
    Mesh*                   GetMesh(void) const
                                { return mMesh; }
    
                            // return our width
    float                   GetWidth(void) const
                                { return mBounds.GetWidth(); }
    
                            // returns our height
    float                   GetHeight(void) const
                                { return mBounds.GetHeight(); }
       
                            // set our debug text coloring
    void                    SetDebugTextColor(const ColorF& inColor)
                                { mDebugTextColor = inColor; }
    virtual void            SetColorTL(const ColorF& inColor)
                                { mColorTL = inColor; }
    virtual void            SetColorTR(const ColorF& inColor)
                                { mColorTR = inColor; }
    virtual void            SetColorBL(const ColorF& inColor)
                                { mColorBL = inColor; }
    virtual void            SetColorBR(const ColorF& inColor)
                                { mColorBR = inColor; }
    virtual void            SetColors(const ColorF& inColor)
                                {
                                    mColorTL = inColor;
                                    mColorTR = inColor;
                                    mColorBL = inColor;
                                    mColorBR = inColor;
                                }
                    
    virtual void            SetBounds(float inLeft, float inTop, float inWidth, float inHeight)
                                {
                                    mBounds.Set(inLeft, inTop, inLeft + inWidth, inTop + inHeight);
                                }
    
    virtual void            SetBounds(const RectangleF& inBounds)
                                {
                                    mBounds = inBounds;
                                }    
    
        
    
protected:

    virtual void            RenderDebugText(void);

    ColorF                  mColorTL; // normally, combine this into a smarter object (all 4)
    ColorF                  mColorTR;
    ColorF                  mColorBL;
    ColorF                  mColorBR;
    ColorF                  mDebugTextColor;
    std::string             mName;
    Mesh*                   mMesh;
    RectangleF              mBounds;
    bool                    mVisible;
};

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

class GraphicQuad : public GraphicObject
{
public:
                            GraphicQuad(const std::string& inName, uint32 inVertsPerRow = 96, const ColorF& inDebugTextColor = ColorF());
    virtual                 ~GraphicQuad(void);
    
                            // render
    virtual void            Render(RenderStates& ioStates);
   

protected:

};

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

class GraphicTexture : public GraphicObject
{
public:
                            GraphicTexture(const std::string& inName, uint32 inVertsPerRow = 96, const ColorF& inDebugTextColor = ColorF());
    virtual                 ~GraphicTexture(void);
        
                            // render
    virtual void            Render(RenderStates& ioStates);

                            // load up our texture
    virtual bool            Load(const std::string& inFileName);

protected:

    PNGFile                 mTexture;

};

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

END_NAMESPACE(LunchtimeStudios)

