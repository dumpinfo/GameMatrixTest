/*  ************************************************************************************************
 *  DemoModifiers.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  used to update our point lights (light source) for the demo. Not part of the mesh, but used
 *  to build the data our mesh will use.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "Helpers/CommonHelpers.h"
#include "Mesh/TextureMeshModifierLight.h"
#include "Mesh/TextureMesh.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

// =============================================================================================================
// eCIP2DLightSourceMorphFlags - 
namespace eLightSourceMorphFlags
{
	typedef uint32 Type;
	enum
	{
		None			= 0,
		UpdateColor		= 1 << 1,
		UpdateFallOff	= 1 << 2,
		UpdateRadius	= 1 << 3,
		UpdatePoint		= 1 << 4,
        Dead            = 1 << 5,
        QueueDeath      = 1 << 6,
        DieNow          = 1 << 7
	};

	const Type kUpdateAll = UpdateColor | UpdateFallOff | UpdateRadius | UpdatePoint;

    // makes bit flag helpers (HasFlag and SetFlag) usage example:
    // if ( eLightSourceMorphFlags::HasFlag(allFlags, eLightSourceMorphFlags::UpdateRadius) )
	ENUM_HASFLAG()
	ENUM_SETFLAG()
}

// =============================================================================================================
// LightSourceMorph - morph our colors in and out.
class Light2DPhysics
{
public:
                                Light2DPhysics(void);
    virtual                     ~Light2DPhysics(void) 
                                    { }
    
    LightSource&                GetStartModifiable(void) { return mStart; }
    LightSource&                GetEndModifiable(void) { return mEnd; }
    
    std::pair< int32, int32 >&         GetColorTimeRangeModifiable(void)       { return mColorTimeRange; }
    std::pair< int32, int32 >&         GetPixelTimeRangeModifiable(void)       { return mPixelTimeRange; }
    std::pair< int32, int32 >&         GetFallOffTimeRangeModifiable(void)     { return mFallOffTimeRange; }
    std::pair< int32, int32 >&         GetRadiusTimeRangeModifiable(void)      { return mRadiusTimeRange; }
    std::pair< float, float >&         GetPixelPercentRangeXModifiable(void)   { return mPixelPercentRangeX; }
    std::pair< float, float >&         GetPixelPercentRangeYModifiable(void)   { return mPixelPercentRangeY; }
    std::pair< float, float >&         GetFallOffModifiable(void)              { return mFallOffRange; }
    std::pair< float, float >&         GetRadiusRangeModifiable(void)          { return mRadiusRange; }

    
                                // returns true if we have this flag.
    bool                        HasFlag(eLightSourceMorphFlags::Type inFlag) const
                                    { return eLightSourceMorphFlags::HasFlag(mFlags, inFlag); }
    
                                // kill this off.
    bool                        IsAlive(void) const
                                    { return (eLightSourceMorphFlags::HasFlag(mFlags, eLightSourceMorphFlags::Dead) == false); }
    
                                // returns true if we're marked for death
    bool                        IsMarkedForDeath(void) const
                                    { return (HasFlag(eLightSourceMorphFlags::Dead) || HasFlag(eLightSourceMorphFlags::QueueDeath) || HasFlag(eLightSourceMorphFlags::DieNow)); }
    
                                // kill this.
    void                        Kill(bool inInstantKill)
                                    {
                                        if(inInstantKill == true)
                                            eLightSourceMorphFlags::SetFlag(mFlags, eLightSourceMorphFlags::Dead, true);
                                        else
                                            eLightSourceMorphFlags::SetFlag(mFlags, eLightSourceMorphFlags::QueueDeath, true);
                                    }
    
                                // set a flag
    void                        SetFlag(eLightSourceMorphFlags::Type inFlag, bool inValue)
                                    { eLightSourceMorphFlags::SetFlag(mFlags, inFlag, inValue); }
    
                                // this is our light source
    LightSource*                GetMeshResult(void) const { return mMeshResult; }
    MeshModifierLightGroup*     GetMesh(void) const { return mMesh; }
    void                        SetMeshResult(LightSource* inLight)  { mMeshResult = inLight; }
    void                        SetMesh(MeshModifierLightGroup* inMesh) { mMesh = inMesh; }
    void                        ClearMeshItems(void);
    
                                // kill at a more rapid pace.
    void                        ShrinkTimeToKill(uint32 inAmount);
    
                                // update this morpher 
	virtual bool                Update(uint32 inCurrentTime, LightSource& outResult);
    virtual bool                UpdateToMeshResult(uint32 inCurrentTime);
    
                                // build a new color
    virtual ColorF              GetNewColor(float inRed = -1.0F, float inGreen = -1.0F, float inBlue = -1.0F, float inAlpha = -1.0F);

    
protected:
    
    MeshModifierLightGroup*         mMesh;
	LightSource                     mStart;					// starting light source 
	LightSource                     mEnd;					// end light source 
    LightSource*                    mMeshResult;    
    std::pair< int32, int32 >       mColorTimeRange;
    std::pair< int32, int32 >       mPixelTimeRange;
    std::pair< int32, int32 >       mFallOffTimeRange;
    std::pair< int32, int32 >       mRadiusTimeRange;
    std::pair< float, float >       mPixelPercentRangeX;
    std::pair< float, float >       mPixelPercentRangeY;
    std::pair< float, float >       mFallOffRange;
    std::pair< float, float >       mRadiusRange;
	
    uint32                          mNextColorTime;			
	uint32                          mStartColorTime;		
	uint32                          mNextPointTime;			
	uint32                          mStartPointTime;		
    uint32                          mNextFallOffTime;		
	uint32                          mStartFallOffTime;		
    uint32                          mNextRadiusTime;		
	uint32                          mStartRadiusTime;		
	
    eLightSourceMorphFlags::Type    mFlags;			// our update flags 
    
};

// =============================================================================================================
// Light2DPhysicsConstrained - morph our colors in and out.
class Light2DPhysicsConstrained : public Light2DPhysics
{
public:
                                Light2DPhysicsConstrained(void)
                                    { }
    
    virtual                     ~Light2DPhysicsConstrained(void) 
                                    { }
    
                                // build a new color
    virtual ColorF              GetNewColor(float inRed = -1.0F, float inGreen = -1.0F, float inBlue = -1.0F, float inAlpha = -1.0F) = 0;
    
};

// =============================================================================================================
// Light2DPhysicsConstrainedRGBA - morph our colors using RGBA
class Light2DPhysicsConstrainedRGBA : public Light2DPhysicsConstrained
{
public:
                                Light2DPhysicsConstrainedRGBA(void)
                                    :   mRangeRed(std::make_pair(0.0F, 1.0F)),   
                                        mRangeGreen(std::make_pair(0.0F, 1.0F)),   
                                        mRangeBlue(std::make_pair(0.0F, 1.0F)),   
                                        mRangeAlpha(std::make_pair(0.0F, 1.0F))
                                    { }
    
    virtual                     ~Light2DPhysicsConstrainedRGBA(void) 
                                    { }
    
                                // build a new color
    virtual ColorF              GetNewColor(float inRed = -1.0F, float inGreen = -1.0F, float inBlue = -1.0F, float inAlpha = -1.0F);

    
    std::pair< float, float >   mRangeRed;
    std::pair< float, float >   mRangeGreen;
    std::pair< float, float >   mRangeBlue;
    std::pair< float, float >   mRangeAlpha;
    
};


END_NAMESPACE(LunchtimeStudios)

