/*  ************************************************************************************************
 *  Demo.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "Demo.h"
#include "RenderHelper.h"
#include "GraphicObjects.h"
#include "DemoModifiers.h"
#include "Mesh/TextureMeshModifierDent.h"

BEGIN_NAMESPACE(LunchtimeStudios)

const size_t kMaxLightsAllowed = 3;
const size_t kMaxTotalLightsAllowed = 32;
const uint32 kMinTimeBetweenFrames = (uint32)(1000.0F / 120.0f);

//////////////////////////////////////////////////////////////////////
/// constructor
//////////////////////////////////////////////////////////////////////
Demo::Demo(void)
:   mQuadTest("Colored Quad Demo"), 
    mTextureTest("Dent Texture - (mesh lines visible). Change mesh size in Demo constructor", 42, ColorF(0.2F, 0.2F, 0.2F, 1.0F)), 
    mTextureTestFlashlight("Textured Flashlight - (mesh lines visible). Change mesh size in Demo constructor ", 42)
{
    mCurrentTime = 0;
    mNextUpdateTime = 0;
}


//////////////////////////////////////////////////////////////////////
/// destructor
//////////////////////////////////////////////////////////////////////
Demo::~Demo(void)
{
    size_t theLoop;
    for(theLoop = 0; theLoop < mLightMorphs.size(); ++theLoop)
    {
        delete mLightMorphs[theLoop];
    }
    mLightMorphs.clear();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// apply a texture effect
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Demo::BuildNewTextureEffectFlashLight(const PointF& inPoint)
{
    /* **************] Flashlight [***************** */
    // make a light
    MeshModifierFlashLight* theLightMod = mTextureTestFlashlight.GetMesh()->GetModifierAs< MeshModifierFlashLight >("flashlight");
    if(theLightMod == NULL)
    {
        float theBlack[4] = {0.0F, 0.0F, 0.0F, 1.0F };
        theLightMod = new MeshModifierFlashLight(mTextureTestFlashlight.GetMesh(), "flashlight");
        theLightMod->SetDarknessColor(theBlack);
        mTextureTestFlashlight.GetMesh()->AddModifier(theLightMod);
    }            
    
    PointF thePoint(inPoint.x < 0.0F ? GetRandomFloatBetween(0.0F, mTextureTestFlashlight.GetWidth()) : inPoint.x,
                    inPoint.y < 0.0F ? GetRandomFloatBetween(0.0F, mTextureTestFlashlight.GetHeight()) : inPoint.y);
 
    
    LightSource* theSource = new LightSource();
    theSource->SetXY(thePoint.x, thePoint.y);
    theSource->SetScreenRadius(0.15F);
    theSource->SetFallOffPercent(0.21F);
    theSource->SetColor(1.0F, 1.0F, 1.0F, 1.0F);

    theLightMod->AddLightSource(theSource);
    delete theSource;
     
         
    theLightMod->MarkDirty();    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// apply a texture effect
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Demo::BuildNewTextureEffect(const PointF& inPoint)
{
    /* **************] DENT [***************** */
    // make a light
    MeshModifierDent* theLightMod = mTextureTest.GetMesh()->GetModifierAs< MeshModifierDent >("dent");
    if(theLightMod == NULL)
    {
        theLightMod = new MeshModifierDent(mTextureTest.GetMesh(), "dent");
        mTextureTest.GetMesh()->AddModifier(theLightMod);
    }            
    
    PointF thePoint(inPoint.x < 0.0F ? GetRandomFloatBetween(0.0F, mTextureTest.GetWidth()) : inPoint.x,
                    inPoint.y < 0.0F ? GetRandomFloatBetween(0.0F, mTextureTest.GetHeight()) : inPoint.y);
 
    
    DentSource* theSource = new DentSource();
    theSource->SetXY(thePoint.x, thePoint.y);
    theSource->SetScreenRadius(0.2F);
    theSource->SetFallOffPercent(0.215F);
    theSource->SetColor(0.3F, 0.3F, 0.3F, 1.0F);

    if(theLightMod->GetLightSources().size() > 0)
    {
        theLightMod->RemoveLight(theLightMod->GetLightSources().back());
    }
    theLightMod->AddLightSource(theSource);
    delete theSource;  
         
    theLightMod->MarkDirty();    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// makes a new light
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Demo::BuildNewLightOnQuad(const PointF& inPoint)
{
    // make a light
    MeshModifierLightGroup* theLightMod = mQuadTest.GetMesh()->GetModifierAs< MeshModifierLightGroup >("light");
    if(theLightMod == NULL)
    {
        theLightMod = new MeshModifierLightGroup(mQuadTest.GetMesh(), "light");
        mQuadTest.GetMesh()->AddModifier(theLightMod);
    }            
    
    PointF thePoint(inPoint.x < 0.0F ? GetRandomFloatBetween(0.0F, mQuadTest.GetWidth()) : inPoint.x,
                    inPoint.y < 0.0F ? GetRandomFloatBetween(0.0F, mQuadTest.GetHeight()) : inPoint.y);
    
    Light2DPhysicsConstrainedRGBA* theLightPhysics = new Light2DPhysicsConstrainedRGBA();
    
    theLightPhysics->GetStartModifiable().SetXY(thePoint);
    theLightPhysics->GetStartModifiable().SetScreenRadius(GetRandomFloatBetween(0.05F, 0.25F));
    theLightPhysics->GetStartModifiable().SetFallOffPercent(GetRandomFloatBetween(0.02F, 0.1F));
        
    // copy it to the end
    theLightPhysics->GetEndModifiable() = theLightPhysics->GetStartModifiable();

    LightSource* theSource = new LightSource();
    theLightPhysics->GetStartModifiable() = *theSource;
        
    // add the mesh result
    theLightPhysics->SetMesh(theLightMod);
    theLightPhysics->SetMeshResult(theLightMod->AddLightSource(theSource));
    delete theSource;
    
    // append this new light
    mLightMorphs.push_back(theLightPhysics);

    // prune away excess
    EnsureOnlyMaxLights(kMaxLightsAllowed, kMaxTotalLightsAllowed);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// returns true if we should kill this right away, otherwise shrink it away
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool Demo::DoKillLightOverMax(Light2DPhysics* inMorph, bool inIsStillOverMax)
{
    if(inIsStillOverMax || inMorph == NULL)
        return true;
    
    // shrink it
    inMorph->ShrinkTimeToKill(GetRandomIntegerBetween(100, 400));

    // done
    return false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// make sure we don't have too many lights
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Demo::EnsureOnlyMaxLights(uint32 inTargetMax, uint32 inAbsMax)
{
    if(mLightMorphs.size() > inTargetMax)
    {
        size_t theTotalOver = (mLightMorphs.size() >= inAbsMax) ? mLightMorphs.size() - inAbsMax : 0; 
        LightMorphList::iterator theIter;
        for(theIter = mLightMorphs.begin(); theIter != mLightMorphs.end(); )
        {
            Light2DPhysics* theMorph = (*theIter);
            if(theMorph->IsMarkedForDeath() == false)
            {
                // optimization
                theMorph->Kill(false);
                break;
            }
            else if(theTotalOver > 0)
            {
                if(DoKillLightOverMax(theMorph, theTotalOver >= inAbsMax))
                {
                    (*theIter)->ClearMeshItems();
                    theIter = mLightMorphs.erase(theIter);
                }
                else
                    ++theIter;
                theTotalOver--;
            }
            else
                ++theIter;
        }
    }
}

//////////////////////////////////////////////////////////////////////
/// Mouse Event
//////////////////////////////////////////////////////////////////////
void Demo::OnMouseDown(bool inIsLeft, int inX, int inY)
{
    if(inIsLeft)
    {
        mLeftMouse.mIsDown = true;
        mLeftMouse.mStart.SetXY((float)inX, (float)inY);
        mLeftMouse.mLastPoint = mLeftMouse.mStart;
       
        // hit the background, SPAWN!
        if(mQuadTest.IsVisible())
        {
            BuildNewLightOnQuad(mLeftMouse.mStart);        
        }
        else if(mTextureTest.IsVisible())
        {
            BuildNewTextureEffect(mLeftMouse.mStart);
        }
        else
        {
            BuildNewTextureEffectFlashLight(mLeftMouse.mStart);
        }
    }
    else
    {
        mRightMouse.mIsDown = true;
        mRightMouse.mStart.SetXY((float)inX, (float)inY);
        mRightMouse.mLastPoint = mRightMouse.mStart;        
    }
}

//////////////////////////////////////////////////////////////////////
/// Mouse Event
//////////////////////////////////////////////////////////////////////
void Demo::OnMouseUp(bool inIsLeft, int inX, int inY)
{
    if(inIsLeft)
    {
        mLeftMouse.mIsDown = false;
    }
    else
    {
        mRightMouse.mIsDown = false;
        ToggleScene();
    }
}


//////////////////////////////////////////////////////////////////////
/// Mouse Event
//////////////////////////////////////////////////////////////////////
void Demo::OnMouseMove(int inX, int inY)
{
    if(mLeftMouse.mIsDown)
    {
        PointF theNew((float)inX, (float)inY);
        
        // add light to quad test?
        if(mQuadTest.IsVisible())
        {
            if(mLeftMouse.mLastPoint.DistanceTo(theNew) > 10.0F)
            {
                mLeftMouse.mLastPoint = theNew;
            
                // hit the background, SPAWN!
                BuildNewLightOnQuad(theNew);
            }
        }
        else if(mTextureTest.IsVisible())
        {
            // forward to our texture effect
            BuildNewTextureEffect(theNew);
        }
        else
        {
            BuildNewTextureEffectFlashLight(theNew);
        }
    }
}


//////////////////////////////////////////////////////////////////////
/// Mouse Event
//////////////////////////////////////////////////////////////////////
void Demo::OnKeyDown(char inKey)
{
	switch (inKey)
	{
        // escape: exit
        case 27:   
            exit(0);
            break;
        case ' ':
            ToggleScene();
            break;
	}
}


//////////////////////////////////////////////////////////////////////
/// which scene should we show now?
//////////////////////////////////////////////////////////////////////
void Demo::ToggleScene(void)
{
    if(mTextureTestFlashlight.IsVisible())
    {
        mTextureTest.SetVisible(false);
        mTextureTestFlashlight.SetVisible(false);
        mQuadTest.SetVisible(true);
    }
    else if(mTextureTest.IsVisible())
    {
        mTextureTestFlashlight.SetVisible(true);
        mTextureTest.SetVisible(false);
        mQuadTest.SetVisible(false); 
        
        MeshModifierFlashLight* theLightMod = mTextureTestFlashlight.GetMesh()->GetModifierAs< MeshModifierFlashLight >("flashlight");
        while(theLightMod && theLightMod->GetLightSources().size() > 0)
        {
            theLightMod->RemoveLight(theLightMod->GetLightSources().back());
        }
    }        
    else if(mQuadTest.IsVisible())
    {
        mTextureTest.SetVisible(true);
        mTextureTestFlashlight.SetVisible(false);
        mQuadTest.SetVisible(false);
    }
}

//////////////////////////////////////////////////////////////////////
/// do our demo
//////////////////////////////////////////////////////////////////////
void Demo::SetupDemo(void)
{
    // add our quad test
    GraphicsManager::Instance().AddItem(&mQuadTest);

    // add our texture
    std::string thePath = LunchtimeStudios::GetCurrentPath();
    std::string theName = thePath + "/../../texture.png";
    mTextureTest.Load(theName);
    mTextureTestFlashlight.Load(theName);
    
    GraphicsManager::Instance().AddItem(&mTextureTest);
    mTextureTest.SetVisible(false);
    
    GraphicsManager::Instance().AddItem(&mTextureTestFlashlight);
    mTextureTestFlashlight.SetVisible(false);    
    
    mQuadTest.SetColorTL(ColorF(1.0F, 0.0F, 0.0F, 1.0F));
    mQuadTest.SetColorTR(ColorF(1.0F, 1.0F, 0.0F, 1.0F));
    mQuadTest.SetColorBL(ColorF(0.0F, 1.0F, 0.0F, 1.0F));
    mQuadTest.SetColorBR(ColorF(0.0F, 0.0F, 1.0F, 1.0F));
    
    // build default lights
    BuildNewLightOnQuad();
    BuildNewLightOnQuad();
    BuildNewLightOnQuad();
}


//////////////////////////////////////////////////////////////////////
/// update our lights
//////////////////////////////////////////////////////////////////////
void Demo::UpdateLights(uint32 inCurrentTime)
{
    MeshModifierLightGroup* theLightMod = (mQuadTest.GetMesh()) ? mQuadTest.GetMesh()->GetModifierAs< MeshModifierLightGroup >("light") : NULL;
    
    LightSource theColorLight;
    LightMorphList::iterator theIter;
    for(theIter = mLightMorphs.begin(); theIter != mLightMorphs.end(); /* blank */)
    {        
        // update this? 
        if(theLightMod)
            (*theIter)->UpdateToMeshResult(inCurrentTime);
        else
            (*theIter)->Update(inCurrentTime, theColorLight);
                   
        if((*theIter)->IsAlive() == false)
        {
            (*theIter)->ClearMeshItems();
            theIter = mLightMorphs.erase(theIter);
        }
        else
            ++theIter;
    }   
}

//////////////////////////////////////////////////////////////////////
/// Update and Render
//////////////////////////////////////////////////////////////////////
void Demo::Update(void)
{
    uint32 theTime = ComputeCurrentTime();
    if(theTime >= mNextUpdateTime)
    {
        //uint32 theDelta = theTime - mCurrentTime;
        mCurrentTime = theTime;
        
        // update our light movement
        UpdateLights(mCurrentTime);
        
        // tell our graphics engine to render!
        GraphicsManager::Instance().Render();
        
        // throttle our updates, no need to go over 60 FPS here.
        mNextUpdateTime = theTime + kMinTimeBetweenFrames;
    }
}

END_NAMESPACE(LunchtimeStudios)

