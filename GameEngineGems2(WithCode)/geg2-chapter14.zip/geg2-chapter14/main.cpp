/*  ************************************************************************************************
 *  main.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Demo which gives examples on how to use the texture mesh. space bar, or right click through demos
 *  *) Colored Quad
 *  *) Mesh (with debug rendering lines on) showing a dent
 *  *) Mesh (with debug rendering lines on) showing flashlight
 *
 *  To build, you may need to add a libPNG framework
 *  premade mac libs for libpng can be found: http://ethan.tira-thompson.org/Mac_OS_X_Ports.html
 *  otherwise, go to http://www.libpng.org/pub/png/libpng.html
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "CommonTypes.h"
#include "CommonHelpers.h"
#include "GraphicsManager.h"
#include <sstream>
#include "RenderHelper.h"
#include "Demo.h"
#include <ApplicationServices/ApplicationServices.h>

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// forward on rendering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doRender(void)
{
    Demo::Instance()->Update();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// window resize
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doReshape(int inW, int inH)
{
    GraphicsManager::Instance().SetWidthHeight(inW, inH);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// update!
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doIdle(void)
{	
    Demo::Instance()->Update();
	glutPostRedisplay();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// forward on keyboard
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doKeyboard(unsigned char key, int x, int y)
{
    Demo::Instance()->OnKeyDown(key);                                
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// forward on mouse clicks
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doMouse(int button, int state, int x, int z)
{
	switch(button)
	{
        case GLUT_LEFT_BUTTON:
            if (state == GLUT_DOWN) 
                Demo::Instance()->OnMouseDown(true, x, z);
            else if(state == GLUT_UP)
                Demo::Instance()->OnMouseUp(true, x, z);
            break;
            
        case GLUT_RIGHT_BUTTON:
            if (state == GLUT_DOWN) 
                Demo::Instance()->OnMouseDown(false, x, z);
            else if(state == GLUT_UP)
                Demo::Instance()->OnMouseUp(false, x, z);
            break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// forward on mouse move
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void doMouseMove(int x, int z)
{
    Demo::Instance()->OnMouseMove(x, z);
}

// end our namespace
END_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// our entry point
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
    // see random number
    srand(LunchtimeStudios::ComputeCurrentTime());
    
    // normal init and mapping methods
    glutInit(&argc,argv);   
    glutInitDisplayMode (GLUT_DOUBLE);
    glutInitWindowSize (LunchtimeStudios::GetDefaultWindowWidth(), LunchtimeStudios::GetDefaultWindowHeight());
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("A basic OpenGL Window");
    glutKeyboardFunc(LunchtimeStudios::doKeyboard);
    glutMouseFunc(LunchtimeStudios::doMouse);
    glutMotionFunc(LunchtimeStudios::doMouseMove);
	glutDisplayFunc(LunchtimeStudios::doRender);
    glutIdleFunc(LunchtimeStudios::doRender);
    
    // init our demo
    LunchtimeStudios::Demo::Instance()->SetupDemo();
    
    // run until ESCAPE is hit.
	glutMainLoop();

}

