/*  ************************************************************************************************
 *  GraphicsManager.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Singleton version of a graphics hub. Handles rendering, owning our graphics objects.
 *  VERY simple impl, just for the demo.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

#include "CommonTypes.h"
#include "CommonHelpers.h"
#include "Helpers/Point.h"
#include "Helpers/Color.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)
/////////////////////////////////////////////////////////////////////////////////////////

class GraphicObject;
class GraphicsManager /* : boost::noncopyable */
{
public:

                                    GraphicsManager(void);
    virtual                         ~GraphicsManager(void);
    
                                    // adds an item
    void                            AddItem(GraphicObject* inObj);

                                    // used to draw text
    void                            DrawText(const std::string& inText, float inX, float inY, float inR = 1.0f, float inG = 1.0F, float inB = 1.0F);

                                    // width / height
    int32                           GetWidth(void) const
                                        { return mWidth; }                                        
    int32                           GetHeight(void) const
                                        { return mHeight; }
    uint32                          GetFrameID(void) const 
                                        { return mFrameID; }
                                        
                                    // converts from our internal pixel coords to the rendering coords
    void                            ConvertNormalPixelsToRenderingPixels(float inX, float inY, float& outX, float& outY) const
                                        {
                                            // some applications may have a different rendering coordinate system.
                                            outX = inX; outY = inY;
                                        }
                                    
                                    // given screen coords, make pixel coords
    PointF                          ConvertScreenCoordsIntoPixels(const PointF& inScreenCoords) const
                                        {
                                            return PointF(inScreenCoords.GetX() * GetWidth(), inScreenCoords.GetY() * GetHeight());
                                        }

                                    // given screen coord, make a pixel coord
    float                           ConvertScreenCoordIntoPixel(float inScreenCoords, bool inIsX) const
                                        {
                                            return (inIsX) ? inScreenCoords * GetWidth() : inScreenCoords * GetHeight();
                                        }
    
                                    // singleton
    static GraphicsManager&         Instance(void)
                                        { static GraphicsManager sMgr; return sMgr; }

                                    // do our render
    void                            Render(void);

                                    // sets our width height
    void                            SetWidthHeight(int32 inW, int32 inH);

protected:

    typedef std::vector< GraphicObject* > GraphicsList;
    
                                    // render text
    void                            DrawFPS(void);
    
                                    // not implemented, we don't want to allow copying
                                    GraphicsManager(const GraphicsManager& inMgr);  
    GraphicsManager&                operator=(const GraphicsManager& inMgr);       
                     
    GraphicsList                    mGraphics;
    int32                           mWidth;     // our window width
    int32                           mHeight;    // our window height
    uint32                          mFrameID;
    ColorF                          mLastVisibleDebugTextColor;
    
    int32                           mFPSFrameID; // used for FPS
    float                           mFPS;           // our FPS
    int32                           mFPSTimeBase;
    int32                           mFPSTimeTrack;
};


/////////////////////////////////////////////////////////////////////////////////////////
END_NAMESPACE(LunchtimeStudios)


