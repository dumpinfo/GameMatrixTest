/*  ************************************************************************************************
 *  TextureMeshHelpers.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Collection of helper functions used throughout our texture mesh code.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

#include "TextureMeshTypes.h"
#include "RenderHelper.h"
#include "CommonHelpers.h"
#include "Helpers/Color.h"
#include "GraphicsManager.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

//////////////////////////////////////////////////////////////////////
// does a faster form of Sqrt
// See: http://en.wikipedia.org/wiki/Fast_inverse_square_root
//////////////////////////////////////////////////////////////////////
inline static float InvSqrt (float inX)
{
    float theX2 = 0.5f * inX;
    
    int theInt = *(int*)&inX;
    theInt = 0x5f3759df - (theInt >> 1);
    
    inX = *(float*)&theInt;
    inX = inX * (1.5f - theX2 * inX * inX);
    return inX;
}

//////////////////////////////////////////////////////////////////////
// does a faster form of Sqrt
// See: http://en.wikipedia.org/wiki/Fast_inverse_square_root
//////////////////////////////////////////////////////////////////////
inline static float FastSqrt(float inF)
{
    return 1.0F / InvSqrt(inF);
}


////////////////////////////////////////////////////////////////////
/// extract colors from a mesh vertex
////////////////////////////////////////////////////////////////////
extern void ToArray4Color(MeshVertex& ioVertex, GLubyte* outColors, uint32 inFrameID);

// return distance sqrd.
static float DistanceSquaredTo(float inFromX, float inFromY, float inToX, float inToY) 
{ 
    return Square(inFromX - inToX) + Square(inFromY - inToY); 
}  

///////////////////////////////////////////////////////////////////////////////////
/// return our distance
///////////////////////////////////////////////////////////////////////////////////
static float DistanceTo(float inFromX, float inFromY, float inToX, float inToY) 
{ 
    return sqrtf(DistanceSquaredTo(inFromX, inFromY, inToX, inToY));
} 

///////////////////////////////////////////////////////////////////////////////////
/// return our distance
///////////////////////////////////////////////////////////////////////////////////
static float DistanceToFastApprox(float inFromX, float inFromY, float inToX, float inToY) 
{ 
    return FastSqrt(DistanceSquaredTo(inFromX, inFromY, inToX, inToY));
} 

////////////////////////////////////////////////////////////////////
/// LERP into a new color
////////////////////////////////////////////////////////////////////
static void LerpColors(const float* startRGBA, const float* endRGBA, float inPercent, float* outRGBA)
{
    outRGBA[0] = LERP_ITEM(startRGBA[0], endRGBA[0], inPercent);
    outRGBA[1] = LERP_ITEM(startRGBA[1], endRGBA[1], inPercent);
    outRGBA[2] = LERP_ITEM(startRGBA[2], endRGBA[2], inPercent);
    outRGBA[3] = LERP_ITEM(startRGBA[3], endRGBA[3], inPercent);
}

////////////////////////////////////////////////////////////////////
/// Returns a screen dimension * our screen
////////////////////////////////////////////////////////////////////
static float GetScreenDimensionDistance(float inScreenRadius)
{
    return inScreenRadius * (((float)GraphicsManager::Instance().GetWidth() + (float)GraphicsManager::Instance().GetHeight()) * 0.5F);
}


END_NAMESPACE(LunchtimeStudios)


