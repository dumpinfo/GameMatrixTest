/*  ************************************************************************************************
 *  TextureMeshUV.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Use this mesh when applying to a texture so that it supports UV coordinates. class Mesh does not
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "TextureMesh.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/// A type of mesh that supports texture coordinates
/////////////////////////////////////////////////////////////////////////////////////////
class MeshUV : public Mesh
{
public:
                                    MeshUV(bool inEnsureUniqueIDS = true);
    virtual                         ~MeshUV(void);

                                    // given our percent, computes our UV
    float                           ComputeWorldU(float inUPercent) const { return mTopLeftU + (inUPercent * (mBottomRightU - mTopLeftU)); }
    float                           ComputeWorldV(float inVPercent) const { return mTopLeftV + (inVPercent * (mBottomRightV - mTopLeftV)); }
    
                                    // returns the correct position for X/Y
    float                           ComputeLocalHomeU(uint32 inX) const { return inX * mUCountInv; }
    float                           ComputeLocalHomeV(uint32 inY) const { return inY * mVCountInv; }
    
                                    // returns the correct position for X/Y
    float                           ComputeWorldHomeU(uint32 inX) const { return ComputeWorldU(inX * mUCountInv); }
    float                           ComputeWorldHomeV(uint32 inY) const { return ComputeWorldV(inY * mVCountInv); }
    
                                    // render our mesh
    virtual void                    Render(RenderStates& ioRenderStates);
    
                                    // setup our UVS
    virtual void                    SetRenderUVS(float inTopLeftU, float inTopLeftV, float inBottomRightU, float inBottomRightV);
    
protected:
    
                                    // builds our mesh
    virtual void                    DoBuildMesh(uint32 inItemsPerRow, float inWidth, float inHeight);
    
                                    // called on dirty
    virtual bool                    DoOnDirty(void);
       
                                    // setup the vertex
    virtual void                    DoSetupVertex(MeshVertex& ioVertex, uint32 inX, uint32 inY);

    // NOTE: Assuming a rectangle UV portion. We can be crazy inside this mesh, but for simplicity and speed here
    // we'll assume its a rectangle. We could make this 4 corners, but our uv position algorithm would be trickier.
    float                           mTopLeftU;
    float                           mTopLeftV; 
    float                           mBottomRightU; 
    float                           mBottomRightV;
    float                           mUCountInv;         // inverse for U
    float                           mVCountInv;         // inverse for V
};


END_NAMESPACE(LunchtimeStudios)


