/*  ************************************************************************************************
 *  TextureMeshModifierDent.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  This modifier will alter the position of each vertex to collapse (or expand) them, as well
 *  as apply coloring. This is a very simple dent, a better job with light direction would yield
 *  more realistic lighting.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once 

// includes
#include "TextureMeshModifierLight.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/// data for our dents
/////////////////////////////////////////////////////////////////////////////////////////
class DentSource : public LightSource
{   
public:
                                    DentSource(float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~DentSource(void) { }     
    
                                    // copy this (covariant virtual)
    virtual DentSource*             Duplicate(void) const
                                        {   DentSource* theResult = new DentSource(); 
                                            theResult->CopyFrom(this); 
                                            return theResult;
                                        }
protected:
    
                                    // copy from this light
    virtual void                    CopyFrom(const LightSource* inSource);
    
};

/////////////////////////////////////////////////////////////////////////////////
/// Dent modifier
/////////////////////////////////////////////////////////////////////////////////
class MeshModifierDent : public MeshModifierLightGroup
{
public:
                                    MeshModifierDent(Mesh* inParentMesh, const ID& inID, bool inEnabled = true, float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~MeshModifierDent(void);

protected:
       
                                    // light this specific vertex
    virtual bool                    LightVertex(uint32 inFrameID, uint32 inCurrentTime, MeshVertex& ioVertex, const LightSource* inSource);
    
};


END_NAMESPACE(LunchtimeStudios)


