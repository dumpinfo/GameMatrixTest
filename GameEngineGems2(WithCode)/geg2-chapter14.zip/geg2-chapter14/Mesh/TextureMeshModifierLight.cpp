/*  ************************************************************************************************
 *  TextureMeshModifierLight.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshModifierLight.h"
#include "TextureMeshHelpers.h"
#include "TextureMesh.h"
#include "GraphicsManager.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
LightSource::LightSource(float inRadius, float inFallOffPercent)
:   mID(0)
,   mScreenRadius(inRadius)
,   mFallOffPercent(inFallOffPercent)
{
    mScreenRadiusAsDistance = GetScreenDimensionDistance(mScreenRadius); 
}

////////////////////////////////////////////////////////////////////////////////////////
/// copy it
////////////////////////////////////////////////////////////////////////////////////////
void LightSource::CopyFrom(const LightSource* inLight)
{
    mColor                  = inLight->mColor;
    mXY                     = inLight->mXY;
    mFallOffPercent         = inLight->mFallOffPercent; 
    mID                     = inLight->mID;
    mScreenRadius           = inLight->mScreenRadius;
    mScreenRadiusAsDistance = inLight->mScreenRadiusAsDistance;
}


////////////////////////////////////////////////////////////////////////////////////////
/// sets our screen radius
////////////////////////////////////////////////////////////////////////////////////////
void LightSource::SetScreenRadius(float inRadius)
{
    mScreenRadius = inRadius;
    mScreenRadiusAsDistance = GetScreenDimensionDistance(mScreenRadius); 
}


//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierLightBase                                   //
//                                                                                      //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////
/// returns our mesh's RGBA value
////////////////////////////////////////////////////////////////////////////////////////
const float* MeshModifierLightBase::GetBaseColor(void) const
{ 
    return mMesh->GetRGBA(); 
}

////////////////////////////////////////////////////////////////////////////////////////
/// Update
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierLightBase::LightVertex(uint32 inFrameID, uint32 inCurrentTime, MeshVertex& ioVertex, const LightSource* inSource)
{
    // NOTE: Our bounds check earlier would have tripped the mesh flags to recompute position if needed.

    // get our distance sq, another closer check.
    float theDistSq = DistanceSquaredTo(inSource->GetX(), inSource->GetY(), ioVertex.GetRiskyWorldX(), ioVertex.GetRiskyWorldY());
    float theScreenRadiusDistSq = inSource->GetScreenRadiusAsDistance() * inSource->GetScreenRadiusAsDistance();
    if(theDistSq > theScreenRadiusDistSq)
        return false;
    
    // now we need the real distance. We use an optimized version (less accurate than sqrtf)
    float theDist = FastSqrt(theDistSq);
    
    // compute our fall off. 
    float theFallOffDist = inSource->GetScreenRadiusAsDistance() * inSource->GetFallOffPercent();
    
    // find our strength. 
    float thePercentStrength;
    if(theDist >= theFallOffDist)
    {
        float theLeftOverFallOff = (inSource->GetScreenRadiusAsDistance() - theFallOffDist);
        thePercentStrength = (1.0F - ((theDist - theFallOffDist) / theLeftOverFallOff));
        if(thePercentStrength > 1.0F)
            thePercentStrength = 1.0F;
        else if(thePercentStrength < 0.0F)
            thePercentStrength = 0.0F;
    }
    else
        thePercentStrength = 1.0F;
    
    // Blending. 
    if(!ioVertex.TouchedThisColorFrame(inFrameID))
    {
        LerpColors(mMesh->GetRGBA(), inSource->GetRGBA(), thePercentStrength, ioVertex.GetRGBA());

        // mark this vertex as having it's color changed this frame
        ioVertex.MarkColorFrameID(inFrameID);
    }
    else
    {
        LerpColors((const float*)ioVertex.GetRGBA(), inSource->GetRGBA(), thePercentStrength, ioVertex.GetRGBA());
    }
    

    return true;
}



//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierSingleLight                                 //
//                                                                                      //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierSingleLight::MeshModifierSingleLight(Mesh* inParentMesh, const ID& inID, bool inEnabled, float inRadius, float inFallOffPercent)
:   MeshModifierLightBase(inParentMesh, inID, inEnabled)
,   mLight(inRadius, inFallOffPercent) 
{ 
    
}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierSingleLight::~MeshModifierSingleLight(void)
{
    
}

////////////////////////////////////////////////////////////////////////////////////////
/// dirty!
////////////////////////////////////////////////////////////////////////////////////////
void MeshModifierSingleLight::DoOnDirty(void)
{
    mBoundsRect.SetAsSinglePoint(PointF(mLight.GetX(), mLight.GetY()));
    mBoundsRect.Expand(mLight.GetScreenRadiusAsDistance());    
    mPosition = mBoundsRect.GetTopLeft();
}

////////////////////////////////////////////////////////////////////////////////////////
/// Update
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierSingleLight::ProcessMesh(uint32 inFrameID, uint32 inCurrentTime)
{
    ASSERT_BRK(mMesh);
    bool theResult = false;
    int theCount = 0;    
   
    // Loop over each and process it.
    uint32 theXLoop, theYLoop;
    uint32 theRowSize = mMesh->GetRowSize();
    for(theXLoop = 0; theXLoop < theRowSize; ++theXLoop)
    {
        for(theYLoop = 0; theYLoop < theRowSize; ++theYLoop)
        {
            // modify this vertex by the modifier object
            MeshVertex& theVertex = mMesh->GetVertex(theXLoop,theYLoop);
            
            // is it in the bounds?
            if(!ContainsInBounds(theVertex.GetSafeWorldX(), theVertex.GetSafeWorldY()))
                continue;
            
            // light the vertex!
            if(LightVertex(inFrameID, inCurrentTime, theVertex, &mLight))
            {
                theCount++;
            }
        }
    }
    
    return theResult;
}


////////////////////////////////////////////////////////////////////////////////////////
/// Update this
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierSingleLight::Update(uint32 inFrameID, uint32 inCurrentTime)
{
    if(!MeshModifier::Update(inFrameID, inCurrentTime))
        return false;
 
    return true;
}




//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierLightGroup                                  //
//                                                                                      //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////





////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierLightGroup::MeshModifierLightGroup(Mesh* inParentMesh, const ID& inID, bool inEnabled, float inRadius, float inFallOffPercent)
:   MeshModifierLightBase(inParentMesh, inID, inEnabled), mProtectLightList(false)
{ 
}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierLightGroup::~MeshModifierLightGroup(void)
{
    // NOTE: be sure you items who held onto pointers to these know they are invalid.
    // If you use boost::shared_ptr< LightSource > instead, this loop will be unneccessary,
    // just be sure clients of these light sources hold onto the smart pointers and add
    // an invalid flag (thread safe if needed) on light source
    LightArray::iterator theIter;
    for(theIter = mLights.begin(); theIter != mLights.end(); ++theIter)
    {
        delete (*theIter);
    }
    mLights.clear();
}

////////////////////////////////////////////////////////////////////////////////////////
/// dirty!
////////////////////////////////////////////////////////////////////////////////////////
void MeshModifierLightGroup::DoOnDirty(void)
{
    if(mLights.empty())
    {
        mBoundsRect.Clear();
        mPosition.Clear();
    }
    else 
    {
        mBoundsRect.Clear();
        bool theFirst = false;
        
        RectangleF theTemp;
        
        // loop over each item and use it's bounds
        for(LightArray::const_iterator theIter = mLights.begin(); theIter != mLights.end(); ++theIter)
        {
            theTemp.SetAsSinglePoint(PointF((*theIter)->GetX(), (*theIter)->GetY()));
            theTemp.Expand((*theIter)->GetScreenRadiusAsDistance());    
            
            // did we complete the first?
            if(theFirst)
            {
                mBoundsRect = theTemp;
                theFirst = true;
            }
            else
            {
                // encompass this rectangle.
                mBoundsRect.Extend(theTemp);
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////
// add a light, return it's ID
////////////////////////////////////////////////////////////////////////////////////////
LightSource* MeshModifierLightGroup::AddLightSource(const LightSource* inLight)
{    
     // lock our list
    ListLocker theLock(mProtectLightList);
    
    // add the light
    LightSource* theLight = inLight->Duplicate();
    theLight->SetID(++mLightStamp);
    
    // add it.
    mLights.push_back(theLight);
    
    return theLight;
}

////////////////////////////////////////////////////////////////////////////////////////
/// Returns true if we found / removed a light
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierLightGroup::RemoveLight(LightSource* inLightSource) 
{
    ListLocker theLock(mProtectLightList);
    
    // this does a slow erase, but keeps the ordering.
    LightArray::iterator theIter = std::find(mLights.begin(), mLights.end(), inLightSource);
    if(theIter == mLights.end())
        return false;

    // remove it.
    delete (*theIter);
    mLights.erase(theIter);
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////
/// Update
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierLightGroup::ProcessMesh(uint32 inFrameID, uint32 inCurrentTime)
{
    ASSERT_BRK(mMesh);
    bool theResult = false;
    
    // update dirty
    UpdateDirtyIfNeeded();
    
    ListLocker theLock(mProtectLightList);

    size_t theLightMax = mLights.size();
    const float* theBaseColor = GetBaseColor();
    
    // if this is a unique base color, mark this as having a different color
    bool theDifferentBaseColor = (theBaseColor[0] != mMesh->GetRGBA()[0] ||
                                  theBaseColor[1] != mMesh->GetRGBA()[1] ||
                                  theBaseColor[2] != mMesh->GetRGBA()[2] ||
                                  theBaseColor[3] != mMesh->GetRGBA()[3]);
    
      
    // Loop over each and process it.
    uint32 theXLoop, theYLoop;
    uint32 theRowSize = mMesh->GetRowSize();
    for(theXLoop = 0; theXLoop < theRowSize; ++theXLoop)
    {
        for(theYLoop = 0; theYLoop < theRowSize; ++theYLoop)
        {
            // modify this vertex by the modifier object
            MeshVertex& theVertex = mMesh->GetVertex(theXLoop,theYLoop); 
            theVertex.SetRGBA(theBaseColor[0], theBaseColor[1], theBaseColor[2], theBaseColor[3]);
            if(theDifferentBaseColor)
            {
                theVertex.MarkColorFrameID(inFrameID);
            }
            
            // is it in the bounds?
            if(!ContainsInBounds(theVertex.GetSafeWorldX(), theVertex.GetSafeWorldY()))
                continue;

            // changes will be happening
            theResult = true;
            
            // loop in reverse order for speed.
            for(size_t theLightLoop = 0; theLightLoop < theLightMax; ++theLightLoop)
            {
                // light the vertex!
                theResult = LightVertex(inFrameID, inCurrentTime, theVertex, mLights[theLightLoop]) || theResult;
            }
        }
    }
    
    return theResult;
}



////////////////////////////////////////////////////////////////////////////////////////
/// Update this
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierLightGroup::Update(uint32 inFrameID, uint32 inCurrentTime)
{
    if(!MeshModifier::Update(inFrameID, inCurrentTime))
        return false;
    
    return true;
}

//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierFlashLight                                  //
//                                                                                      //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierFlashLight::MeshModifierFlashLight(Mesh* inParentMesh, const ID& inID, bool inEnabled, float inRadius, float inFallOffPercent)
:   MeshModifierLightGroup(inParentMesh, inID, inEnabled)
{ 
}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierFlashLight::~MeshModifierFlashLight(void)
{
    
}

////////////////////////////////////////////////////////////////////////////////////////
/// sets our darkness coloring
////////////////////////////////////////////////////////////////////////////////////////
void MeshModifierFlashLight::SetDarknessColor(const float* inColor)
{
    // sets our darkness color
    if(mDarknessColor[0] != inColor[0] ||
       mDarknessColor[1] != inColor[1] ||
       mDarknessColor[2] != inColor[2] ||
       mDarknessColor[3] != inColor[3])
    {
        mDarknessColor[0] = inColor[0];
        mDarknessColor[1] = inColor[1];
        mDarknessColor[2] = inColor[2];
        mDarknessColor[3] = inColor[3];
        
        // TODO: later we may want to mark as dirty.
    }
    
}

END_NAMESPACE(LunchtimeStudios)







