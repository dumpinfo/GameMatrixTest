/*  ************************************************************************************************
 *  TextureMesh.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Base mesh class. Holds our vertices, and mesh modifiers. 
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once

// includes
#include "TextureMeshTypes.h"
#include "TextureMeshVertex.h"
#include "TextureMeshModifier.h"

// prevent namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/// Contains vertices in a mesh. Modifiers traverse the mesh and alter it.
/////////////////////////////////////////////////////////////////////////////////////////
class Mesh /*: suggest making this derive from boost::noncopyable*/
{
public:
    // list of modifiers
    typedef std::vector< MeshModifier* > ModifierList;

                                    // constructor / destructor
                                    Mesh(bool inEnsureUniqueIDS = true);
    virtual                         ~Mesh(void);
    
                                    // add this modifier
    void                            AddModifier(MeshModifier* inModifier)
                                        {
                                            ASSERT_BRK(inModifier != NULL);
                                            ASSERT_BRK(std::find_if(mModifiers.begin(), mModifiers.end(), EnsureUniqueModifier(inModifier)) == mModifiers.end());
                                            mModifiers.push_back(inModifier);
                                            mNeedsSort = true;
                                        }
                                        
                                    // given our percent, computes our XY
    float                           ComputeWorldX(float inXPercent) const { return mBounds.left + (inXPercent * mBounds.GetWidth()); }
    float                           ComputeWorldY(float inYPercent) const { return mBounds.top  + (inYPercent * mBounds.GetHeight()); }

                                    // compute local
    float                           ComputeLocalX(float inXWorld) const { return ((inXWorld - mBounds.left) / mBounds.GetWidth()); } 
    float                           ComputeLocalY(float inYWorld) const { return ((inYWorld - mBounds.top)  / mBounds.GetHeight());  }

                                    // returns the correct position for X/Y
    float                           ComputeLocalHomeX(uint32 inX) const { return inX * mWidthCountInv; }
    float                           ComputeLocalHomeY(uint32 inY) const { return inY * mHeightCountInv; }
    
                                    // returns the correct position for X/Y
    float                           ComputeWorldHomeX(uint32 inX) const { return ComputeWorldX(inX * mWidthCountInv); }
    float                           ComputeWorldHomeY(uint32 inY) const { return ComputeWorldY(inY * mHeightCountInv); }
    
                                    // returns how visible our lines are (used in debugging)
    float                           GetDebugOpacity(void) const
                                        { return mDebugOpacity; }
   
                                    // return our row size
    uint32                          GetRowSize(void) const
                                        { return mAmtPerRow; }
    
                                    // returns our RGBA color as a float[4]
    const float*                    GetRGBA(void) const
                                        { return mRGBA; }
    
                                    // returns a ref to the list of our modifiers
    const ModifierList&             GetModifiers(void) const
                                        { return mModifiers; }
    
                                    // find a modifier
    MeshModifier*                   GetModifier(const MeshModifier::ID& inKey) const;

                            
    template< typename T >          // casts it to this object (static cast, assert if not null, but wrong type)
    T*                              GetModifierAs(const MeshModifier::ID& inKey) const
                                        {
                                            MeshModifier* theResult = GetModifier(inKey);
                                            return CheckedCast< T >(theResult);
                                        }
    
                                    // returns our top left point
    PointF                          GetPosition(void) const
                                        {
                                            ASSERT_BRK(mBounds.GetTopLeft() == mBounds.GetFastTopLeft());
                                            ASSERT_BRK(mBounds.GetBottomRight() == mBounds.GetFastBottomRight());
                                            return mBounds.GetTopLeft(); 
                                        }
    
                                    // returns our vertex
    inline MeshVertex&              GetVertex(uint32 inX, uint32 inY)
                                        {
                                            ASSERT_BRK(inX < mAmtPerRow && inY < mAmtPerRow); 
                                            return *(mMesh + ((inY * mAmtPerRow) + inX));  
                                        }
    
                                    // returns our vertex
    inline const MeshVertex&        GetVertex(uint32 inX, uint32 inY) const
                                        {
                                            ASSERT_BRK(inX < mAmtPerRow && inY < mAmtPerRow); 
                                            return *(mMesh + ((inY * mAmtPerRow) + inX));  
                                        }
    
                                    // returns our width
    float                           GetWidth(void) const
                                        { return mBounds.GetWidth(); }
    
                                    // returns our height
    float                           GetHeight(void) const
                                        { return mBounds.GetHeight(); }
    
                                    // returns our width per quad
    float                           GetWidthPerQuad(void) const
                                        { return mWidthPerQuad; }
    
                                    // returns our height per quad
    float                           GetHeightPerQuad(void) const
                                        { return mHeightPerQuad; }
    
                                    // mark us dirty
    virtual void                    MarkDirty(eMeshDirtyFlags::Type inDirtyType, bool inForceDirtyRecomputeNow = false)
                                        {
                                            // queue up that we're dirty
                                            eMeshDirtyFlags::SetFlag(mDirtyFlags, inDirtyType, true);
                                            if(inForceDirtyRecomputeNow)
                                                UpdateDirtyIfNeeded();
                                        }
                                        
                                    // size or position change
    virtual void                    OnSizePositionChange(const PointF& inXY, const PointF& inWH)
                                        {
                                            SetWorldPosition(inXY.x, inXY.y);
                                            SetSize(inWH.x, inWH.y);
                                        }
    
                                    // reset the size of our mesh
    virtual void                    Resize(uint32 inItemsPerRow, float inWidth, float inHeight)
                                        { DoBuildMesh(inItemsPerRow, inWidth, inHeight); }
    void                            Resize(uint32 inItemsPerRow, const PointF& inPosition, const PointF& inWH, bool inLocalSpace)
                                        { SetWorldPosition(inPosition.x, inPosition.y); Resize(inItemsPerRow, inWH.x, inWH.y); }
    
                                    // render our mesh
    virtual void                    Render(RenderStates& ioRenderStates);
    
    void                            SetRenderLines(bool inRenderLines)
                                        { mRenderLines = inRenderLines; }

                                    // set our world position
    virtual void                    SetWorldPosition(float inX, float inY);
    virtual void                    SetSize(float inW, float inH);
    virtual void                    SetColor(const float* inRGBA);
    virtual void                    SetColor(const uint8* inRGBA);
    void                            SetDebugOpacity(float inOpacity) 
                                        { mDebugOpacity = inOpacity; }
    
                                    // update this mesh and modifiers on top of it.
    virtual void                    UpdateModifiers(uint32 inFrameID, uint32 inCurrentTime);
    virtual bool                    UpdateMesh(uint32 inFrameID, uint32 inCurrentTime);
    
protected:
    typedef ScopedFlagLock< volatile uint8 > ModifierListLock;
    
                                    // builds our mesh
    virtual void                    DoBuildMesh(uint32 inItemsPerRow, float inWidth, float inHeight);
    
                                    // on dirty, this is called.
    virtual bool                    DoOnDirty(void);
        
                                    // if we're dirty, we'll update. returns true if we were dirty
    virtual bool                    UpdateDirtyIfNeeded(void);
    
                                    // builds our vertex objects
    virtual void                    DoCreateVertexObjects(void);    
    
                                    // setup our vertex
    virtual void                    DoSetupVertex(MeshVertex& ioVertex, uint32 inX, uint32 inY);
    
                                    // sort these
    virtual void                    DoSortModifiers(void);
    
                                    // render any debug we need
    virtual void                    RenderDebugging(RenderStates& ioRenderStates);
    
    ModifierList                    mModifiers;         // our modifiers
    MeshVertex*                     mMesh;              // -> to our mesh
    RectangleF                      mBounds;            // our bounds
    uint32                          mAmtPerRow;         // how many items per row, and how many per col.
    float                           mRGBA[4];           // rgba
    float                           mWidthCountInv;     // mWidth / mAmtPerRow
    float                           mHeightCountInv;    // mHeight / mAmtPerRow
    float                           mDebugOpacity;      // level of debugging opacity
    float                           mWidthPerQuad;      // X dist per quad
    float                           mHeightPerQuad;     // Y dist per quad
    bool                            mRenderLines;       // render mesh lines?
    bool                            mNeedsSort;         // == true, sort our modifiers
    bool                            mEnsureUniqueModifierIDS; // == true, our modifiers must have unique IDS
    volatile uint8                  mPreventModifierListChanges; // == true, we're doing something with our modifier lists
    eMeshDirtyFlags::Type           mDirtyFlags;             // == true, we're dirty
};


END_NAMESPACE(LunchtimeStudios)



