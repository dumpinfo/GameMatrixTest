/*  ************************************************************************************************
 *  TextureMeshVertex.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Holds the properties for a vertex in the mesh
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once 

// includes
#include "TextureMeshTypes.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////////////////////
// Basic mesh vertex. In this article's mesh, we'll be simple, and keep it as mostly just data
///////////////////////////////////////////////////////////////////////////////////////////////////
class MeshVertex
{
    friend class Mesh;
public:
                MeshVertex(void);
                
                // extend this class at will, BUT... in mesh, you'll need an array of pointers, not a MeshVetex*  since each item will need
                // to be of a derived class. Can't just point the head of an array and expect polymorphism to work.
    virtual     ~MeshVertex(void);
    
                // make this flag dirty
    void        DirtyFlag(eMeshVertexFlags::Type inFlag)
                    { eMeshVertexFlags::SetFlag(mFlags, inFlag, true); }

                // returns true if we have the passed in flag set
    bool        HasFlag(eMeshVertexFlags::Type inFlag) const
                    { return eMeshVertexFlags::HasFlag(mFlags, inFlag); }
    
                // sets our vertex flag
    void        SetFlag(eMeshVertexFlags::Type inFlag, bool inValue)
                    { eMeshVertexFlags::SetFlag(mFlags, inFlag, inValue); }
    
                // get our X, modify it if needed
    float       GetSafeWorldX(void) const 
                    { if(eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate)) { DoUpdatePosition(); } return mWorldXY[0]; }
    float       GetSafeWorldY(void) const 
                    { if(eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate)) { DoUpdatePosition(); } return mWorldXY[1]; }
    
                // assume it's in the correct world space. ASSERT if we need to update our position. Then we'll know we have a bug
                // to fix, or we need to call SafeWorld versions instead.
    float       GetRiskyWorldX(void) const 
                    { ASSERT_BRK(!eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate)); return mWorldXY[0]; }
    float       GetRiskyWorldY(void) const 
                    { ASSERT_BRK(!eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate)); return mWorldXY[1]; }
    
                // sets our local UV
    void        SetLocalU(float inU) { if(mLocalUV[0] != inU) { mLocalUV[0] = inU; DirtyFlag(eMeshVertexFlags::UVNeedsUpdate); } }
    void        SetLocalV(float inV) { if(mLocalUV[1] != inV) { mLocalUV[1] = inV; DirtyFlag(eMeshVertexFlags::UVNeedsUpdate); } }
    
                // get our U, modify it if needed
    float       GetSafeWorldU(void) const 
                    { if(eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::UVNeedsUpdate)) { DoUpdateUV(); } return mWorldUV[0]; }
    float       GetSafeWorldV(void) const 
                    { if(eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::UVNeedsUpdate)) { DoUpdateUV(); } return mWorldUV[1]; }
    
                // assume it's in the correct world space. ASSERT if we need to update our position. Then we'll know we have a bug
                // to fix, or we need to call SafeWorld versions instead.
    float       GetRiskyWorldU(void) const 
                    { ASSERT_BRK(!eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::UVNeedsUpdate)); return mWorldUV[0]; }
    float       GetRiskyWorldV(void) const 
                    { ASSERT_BRK(!eMeshVertexFlags::HasFlag(mFlags, eMeshVertexFlags::UVNeedsUpdate)); return mWorldUV[1]; }
    
                // marks this as touched this frame
    uint32      GetFrameID(void) const { return mFrameID; }
    uint32      GetColorFrameID(void) const { return mColorFrameID; }
    void        MarkFrameID(uint32 inFrameID) { mFrameID = inFrameID; }
    void        MarkColorFrameID(uint32 inFrameID) { mColorFrameID = inFrameID; mFrameID = inFrameID; }
    
                // returns us to our local XY
    void        ReturnToLocalXY(void);
    
                // return our color
    float*      GetRGBA(void)
                    { return mRGBA; }
            
                // returns our const color
    const float* GetRGBA(void) const
                    { return mRGBA; }
    
                // returns our X Coordinate
    uint16      GetXCoord(void) const
                    { return mXcoord; }
    
                // return Y coordinate
    uint16      GetYCoord(void) const
                    { return mYcoord; }
    
                // returns true if this was touched this frame (or within epsilon frames)
    bool        TouchedThisFrame(uint32 inFrameID, uint32 inEpsilon = 0) const
                    { return (inFrameID == mFrameID || std::abs((int32)(inFrameID - mFrameID)) <= inEpsilon); } 

    bool        TouchedThisColorFrame(uint32 inColorFrameID, uint32 inEpsilon = 0) const
                    { return (inColorFrameID == mColorFrameID || std::abs((int32)(inColorFrameID - mColorFrameID)) <= inEpsilon); } 
    
    void        SetWorldXY(float inX, float inY);
    void        SetRGBA(float inR, float inG, float inB, float inA)
                    { mRGBA[0] = inR; mRGBA[1] = inG; mRGBA[2] = inB; mRGBA[3] = inA; }
    
    
protected: 
    
                // go from local to world.
    void        DoUpdatePosition(void) const;
    
                // go from local to world.
    void        DoUpdateUV(void) const;    
    
    mutable float mWorldXY[2];
    mutable eMeshVertexFlags::Type mFlags;  // use this 
    Mesh*           mParentMesh; 
    float           mLocalXY[2];
    float           mRGBA[4];
    mutable float   mWorldUV[2];
    float           mLocalUV[2];    
    uint32          mFrameID;
    uint32          mColorFrameID;
    uint16          mXcoord;
    uint16          mYcoord;
    
};


END_NAMESPACE(LunchtimeStudios)

