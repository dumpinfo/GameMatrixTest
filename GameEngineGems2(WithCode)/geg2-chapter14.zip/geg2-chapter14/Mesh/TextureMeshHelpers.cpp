/*  ************************************************************************************************
 *  TextureMeshHelpers.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshHelpers.h"
#include "TextureMesh.h"
#include "GraphicsManager.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////////////////
/// convert to color
///////////////////////////////////////////////////////////////////////////////////////////////
void ToArray4Color(MeshVertex& ioVertex, GLubyte* outColors, uint32 inFrameID)
{
    outColors[0] = (GLubyte)(ioVertex.GetRGBA()[0] * 255.0F);
    outColors[1] = (GLubyte)(ioVertex.GetRGBA()[1] * 255.0F);
    outColors[2] = (GLubyte)(ioVertex.GetRGBA()[2] * 255.0F);
    outColors[3] = (GLubyte)(ioVertex.GetRGBA()[3] * 255.0F);
}


END_NAMESPACE(LunchtimeStudios)


