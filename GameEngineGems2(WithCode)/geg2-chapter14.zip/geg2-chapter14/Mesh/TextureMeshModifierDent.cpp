/*  ************************************************************************************************
 *  TextureMeshModifierDent.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshModifierDent.h"
#include "TextureMeshHelpers.h"
#include "TextureMesh.h"
#include "GraphicsManager.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
DentSource::DentSource(float inRadius, float inFallOffPercent)
:  LightSource(inRadius, inFallOffPercent)
{
}

////////////////////////////////////////////////////////////////////////////////////////
/// copy it
////////////////////////////////////////////////////////////////////////////////////////
void DentSource::CopyFrom(const LightSource* inLight)
{
    LightSource::CopyFrom(inLight);

    // dent
    const DentSource* theDent = dynamic_cast< const DentSource* >(inLight);
    if(theDent)
    {
        // copy our dent items
    }
}


//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierDent                                        //
//                                                                                      //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierDent::MeshModifierDent(Mesh* inParentMesh, const ID& inID, bool inEnabled, float inRadius, float inFallOffPercent)
:   MeshModifierLightGroup(inParentMesh, inID, inEnabled)
{ 
}


////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifierDent::~MeshModifierDent(void)
{
     
}

////////////////////////////////////////////////////////////////////////////////////////
/// Update
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifierDent::LightVertex(uint32 inFrameID, uint32 inCurrentTime, MeshVertex& ioVertex, const LightSource* inSource)
{
    ioVertex.ReturnToLocalXY();
    ioVertex.GetSafeWorldX();
        
    // NOTE: Our bounds check earlier would have tripped the mesh flags to recompute position if needed.
    if(MeshModifierLightBase::LightVertex(inFrameID, inCurrentTime, ioVertex, inSource) == false)
        return false;

    // compute our position from the home spot.
    PointF theHomeSpot(mMesh->ComputeWorldHomeX(ioVertex.GetXCoord()), mMesh->ComputeWorldHomeY(ioVertex.GetYCoord()));
    
    // get our distance sq, another closer check.
    float theDistSq = DistanceSquaredTo(inSource->GetX(), inSource->GetY(), theHomeSpot.x, theHomeSpot.y);
    float theScreenRadiusDistSq = inSource->GetScreenRadiusAsDistance() * inSource->GetScreenRadiusAsDistance();
    if(theDistSq > theScreenRadiusDistSq)
        return false;
  
    // now we need the real distance. We use an optimized version (less accurate than sqrtf)
    float theDist = FastSqrt(theDistSq);
    
    // move the verts closer in.
    PointF theSourceXY(inSource->GetX(), inSource->GetY());
    
    // no shifting
    if(theSourceXY == theHomeSpot)
        return true;
    
    PointF theDirection = theSourceXY.ComputeVectorTo2D(theHomeSpot, true);
        
    // compute our percent
    float thePercent = (float)(1.0 - (((double)inSource->GetScreenRadiusAsDistance() - (double)theDist) / (double)inSource->GetScreenRadiusAsDistance())); 
    float theAmt = inSource->GetScreenRadiusAsDistance() * (thePercent * thePercent);
    
    PointF thePt = theSourceXY.GetPointAt(theDirection, theAmt);
        
    // add in our difference
    ioVertex.SetWorldXY(thePt.x, thePt.y);
    
    return true;
}

END_NAMESPACE(LunchtimeStudios)



