/*  ************************************************************************************************
 *  TextureMeshTypes.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshTypes.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

END_NAMESPACE(LunchtimeStudios)

