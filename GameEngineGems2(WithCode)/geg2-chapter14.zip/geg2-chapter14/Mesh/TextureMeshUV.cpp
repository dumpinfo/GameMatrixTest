/*  ************************************************************************************************
 *  TextureMeshUV.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshUV.h"
#include "GraphicsManager.h"
#include "TextureMeshHelpers.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

///////////////////////////////////////////////////////////////////////////////////////////////
/// convert to graphics
///////////////////////////////////////////////////////////////////////////////////////////////
bool ToGraphics(MeshVertex& ioVertex, RenderDataCVT& ioGraphics, uint32 inFrameID, MeshUV* inMesh)
{
    
    bool theResult = (ioVertex.TouchedThisFrame(inFrameID, 2));
    ToArray4Color(ioVertex, (GLubyte*)&(ioGraphics.r), inFrameID);
    
    // convert into graphics space
    GraphicsManager::Instance().ConvertNormalPixelsToRenderingPixels(ioVertex.GetSafeWorldX(), 
                                                                         ioVertex.GetSafeWorldY(), 
                                                                         ioGraphics.x, ioGraphics.y);    

    // local space UV
    ioGraphics.u = ioVertex.GetSafeWorldU();
    ioGraphics.v = ioVertex.GetSafeWorldV();
    
    return theResult;
}

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshUV::MeshUV(bool inEnsureUniqueIDS)
:   Mesh(inEnsureUniqueIDS)
,   mTopLeftU(0.0F)
,   mTopLeftV(0.0F)
,   mBottomRightU(1.0F) 
,   mBottomRightV(1.0F)
,   mUCountInv(1.0F)         // inverse for U
,   mVCountInv(1.0F)         // inverse for V
{

}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshUV::~MeshUV(void)
{
    
}

////////////////////////////////////////////////////////////////////////////////////////
/// build our mesh
////////////////////////////////////////////////////////////////////////////////////////
void MeshUV::DoBuildMesh(uint32 inItemsPerRow, float inWidth, float inHeight)
{
    // get our X interval
    mUCountInv  = 1.0F / (inItemsPerRow - 1);
    mVCountInv = 1.0F / (inItemsPerRow - 1);
    
    // build our mesh
    Mesh::DoBuildMesh(inItemsPerRow, inWidth, inHeight);
}

////////////////////////////////////////////////////////////////////////////////////////
/// update our dirty, returns true if we rebuilt the mesh
////////////////////////////////////////////////////////////////////////////////////////
bool MeshUV::DoOnDirty(void)
{
    bool theResult = Mesh::DoOnDirty();
    if(!theResult)
    {
        // stored as local UV, nothing to do.
    }    
    
    return theResult;
}


////////////////////////////////////////////////////////////////////////////////////////
/// setup our vertex
////////////////////////////////////////////////////////////////////////////////////////
void MeshUV::DoSetupVertex(MeshVertex& ioVertex, uint32 inX, uint32 inY)
{
    // base class version first
    Mesh::DoSetupVertex(ioVertex, inX, inY);
       
    ioVertex.SetLocalU(ComputeLocalHomeU(inX));
    ioVertex.SetLocalV(ComputeLocalHomeV(inY));
    ioVertex.DirtyFlag(eMeshVertexFlags::UVNeedsUpdate);
}

////////////////////////////////////////////////////////////////////////////////////////
/// render our mesh
////////////////////////////////////////////////////////////////////////////////////////
void MeshUV::Render(RenderStates& ioRenderStates)
{   
    // update if needed.
    UpdateDirtyIfNeeded();
    
    if(mAmtPerRow > 1)
    {
        RenderDataCVT theRenderTL;
        RenderDataCVT theRenderTR;
        RenderDataCVT theRenderBL;
        RenderDataCVT theRenderBR;
        
        uint32 theFrame = ioRenderStates.GetFrameID();
        uint32 theX, theY;
        uint32 theMax = mAmtPerRow - 1;
        
        for(theY = 0; theY < theMax; theY++)
        {
            for(theX = 0; theX < theMax; ++theX)
            {
                MeshVertex*   theVert = &GetVertex(theX, theY); 
                
                // convert to graphics
                ToGraphics(*theVert, theRenderTL, theFrame, this);
                
                // go to our top right, convert to graphics
                theVert = &GetVertex(theX + 1, theY);
                ToGraphics(*theVert, theRenderTR, theFrame, this);
                
                // fetch our bottom left, convert to graphics
                theVert = &GetVertex(theX, theY + 1);
                ToGraphics(*theVert, theRenderBL, theFrame, this);
                
                // go to our bottom right, convert to graphics
                theVert = &GetVertex(theX + 1, theY + 1); 
                ToGraphics(*theVert, theRenderBR, theFrame, this);              

                // if everything is "normal", then skip rendering.
                // NOTE: If you detect that MOST of the mesh is covered (in updates, track percent covered)
                // then render everything and don't render the underneath quad and get the fill rate hit.
                // however, if most of your mesh isn't changing, render the big quad, then only overlay quads on things that
                // are different
                ioRenderStates.AddGlobVTC(theRenderTL, theRenderTR, theRenderBL, theRenderBR); 
            }
        }
        
        // do our debug rendering
        if(mRenderLines)
        {
            RenderDebugging(ioRenderStates);       
        }
    }
    else
    {
        // draw our color
        ASSERT_BRK(false);
    }
    
    // dump it to graphics
    ioRenderStates.Flush();
}

////////////////////////////////////////////////////////////////////////////////////////
/// setup our UVS
////////////////////////////////////////////////////////////////////////////////////////
void MeshUV::SetRenderUVS(float inTopLeftU, float inTopLeftV, float inBottomRightU, float inBottomRightV)
{
    // NOTE: For now, this mesh example is in local space UV.
    mTopLeftU = inTopLeftU;
    mTopLeftV = inTopLeftV;
    mBottomRightU = inBottomRightU;
    mBottomRightV = inBottomRightV;
}



END_NAMESPACE(LunchtimeStudios)
