/*  ************************************************************************************************
 *  TextureMeshTypes.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Defines, types, enums, and other helpers our mesh will use.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once 

// includes
#include "RenderHelper.h"
#include "Helpers/Rectangle.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

typedef Point< float > PointF;
typedef Point< int32 > PointI;
typedef Rectangle< float > RectangleF;
typedef Rectangle< int32 > RectangleI;
struct LightSource;
class MeshModifier;
class MeshModifierLightBase;
class MeshModifierSingleLight;
class MeshModifierLightGroup;
class Mesh;
class MeshUV;
class MeshVertex;
class MeshTextureVertex;


// holds onto our dirty change type
namespace eMeshDirtyFlags
{
    typedef uint16 Type;
    enum 
    {
        None            = 0,        // not dirty
        Position        = 1 << 1,   // position changed
        Tessellation    = 1 << 2,   // Tessellation
        Color           = 1 << 3,   // base colors
        Modifiers       = 1 << 4,   // modifiers
        UV              = 1 << 5,   // UV coordinates
        Size            = 1 << 6    // size of our mesh
    };
    
    // build in has and set flag functions
    ENUM_BITFLAGS();
}


namespace eMeshVertexFlags
{
    typedef uint16 Type;
    enum 
    {
        None                    = 0,        // not dirty
        PositionNeedsUpdate     = 1 << 1,   // local expired, update it
        UVNeedsUpdate           = 1 << 2,   // UV coords
        NeedsBasePosition       = 1 << 3,   // our position's been altered
    };
    
    // build in has and set flag functions
    ENUM_BITFLAGS();
}

/////////////////////////////////////////////////////////////////////////////////////////
/// Exception safe thread locking (This version isn't atomic and doesn't use a mutex!)
/////////////////////////////////////////////////////////////////////////////////////////
template< typename T >
class ScopedFlagLock
{
public:
    
    ScopedFlagLock(T& ioData, bool inEnsureIsUnlockedFirst = true) 
    : mLock(ioData)
    {
        ASSERT_BRK(inEnsureIsUnlockedFirst == false || ioData == 0);
        
        // Note: This is not thread safe
        ++mLock;
    }
    
    // unlock it
    ~ScopedFlagLock(void) { --mLock; }
    
private:

    // since no boost::noncopyable, we'll do this trick
    ScopedFlagLock(void);
    ScopedFlagLock(const ScopedFlagLock& inLock);
    ScopedFlagLock& operator=(const ScopedFlagLock& inLock);
    
    T&  mLock;
    
};

END_NAMESPACE(LunchtimeStudios)

