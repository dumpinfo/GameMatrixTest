/*  ************************************************************************************************
 *  TextureMeshModifier.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Base class for our mesh modifiers. These interact with our mesh and alter properties of
 *  the vertices.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#pragma once 

// includes
#include "TextureMeshTypes.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////

class MeshModifier
{
public:
    typedef std::string ID;
    
                                    MeshModifier(Mesh* inParentMesh, const ID& inID, bool inEnabled = true);
    virtual                         ~MeshModifier(void);

                                    // returns true if we are contained in our bounding box (rough approx)
    bool                            ContainsInBounds(float inX, float inY) const
                                        { return (mBoundsRect.Contains(inX, inY)); }
    
                                    // enable this modifier
    void                            Enable(void)
                                        {
                                            if(!mEnabled)
                                            {
                                                mEnabled = true;
                                                OnEnableChange(true);
                                            }
                                        }
    
                                    // unique ID
    const ID&                       GetID(void) const
                                        { return mID; }
    
                                    // returns our position
    const PointF&                   GetPosition(void) const
                                        { return mPosition; }
    
                                    // for sorting
    uint16                          GetPriority(void) const
                                        { return mPriority; }
    
                                    // returns true if we're enabled
    bool                            IsEnabled(void) const
                                        { return mEnabled; }
    
                                    // returns true if we're dead.
    bool                            IsDead(uint32 inCurrentTime) const
                                        { return (mDeathTime < inCurrentTime); }
    
                                    // mark us dirty
    virtual void                    MarkDirty(bool inForceDirtyRecomputeNow = false)
                                        {
                                            // queue up that we're dirty
                                            mDirty = true;
                                            if(inForceDirtyRecomputeNow)
                                                UpdateDirtyIfNeeded();
                                        }
        
                                    // processes our mesh
    virtual bool                    ProcessMesh(uint32 inFrameID, uint32 inCurrentTime) = 0;
    
                                    // set our priority
    void                            SetPriority(uint32 inPriority)
                                        { mPriority = inPriority; }
    
                                    // returns true if our position changed
    virtual bool                    SetPosition(float inX, float inY);
    
                                    // update our mesh, and return false when we're done.
    virtual bool                    Update(uint32 inFrameID, uint32 inCurrentTime);
    
protected:
    
                                    // update our dirty
    virtual void                    DoOnDirty(void) = 0;
    
                                    // override this if your modifier needs to know when things get enabled
    virtual void                    OnEnableChange(bool inNewValue) { }
    
                                    // if we're dirty, we'll update. returns true if we were dirty
    virtual bool                    UpdateDirtyIfNeeded(void);
    
    ID                              mID;            // unique ID for this modifier
    PointF                          mPosition;      // 2D position (in world space)
    RectangleF                      mBoundsRect;    // bounding rect (extreme bounds)
    Mesh*                           mMesh;          // our parent mesh
    uint32                          mDeathTime;     // world time we're scheduled to perish
    uint16                          mPriority;      // used to sort our modifiers
    bool                            mEnabled;       // == true, this is on and ready!
    bool                            mDirty;         // == true, we'll need to recheck our params
    
};

// Function object used in our find_if operations
struct EnsureUniqueModifier
{
                                    EnsureUniqueModifier(const MeshModifier* inModifier, bool inCheckForID = true) : mModifier(inModifier), mID(inCheckForID) { }

                                    // checks for ID also (optional)
    bool                            operator() (const MeshModifier* inMod) const
                                        { return (inMod == mModifier || (mID && inMod != NULL && inMod->GetID() == mModifier->GetID())); }   

    const MeshModifier*             mModifier;
    bool                            mID;
};

END_NAMESPACE(LunchtimeStudios)

