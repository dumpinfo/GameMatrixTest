/*  ************************************************************************************************
 *  TextureMeshModifier.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshModifier.h"
#include "TextureMesh.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifier::MeshModifier(Mesh* inParentMesh, const MeshModifier::ID& inID, bool inEnabled)
: mID(inID)
, mMesh(inParentMesh)
, mDeathTime(~0)
, mPriority(0)
, mEnabled(inEnabled)
, mDirty(false)
{
    
}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
MeshModifier::~MeshModifier(void)
{

}


////////////////////////////////////////////////////////////////////////////////////////
/// set our position
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifier::SetPosition(float inX, float inY)
{
    // same position?
    if(!equals(mPosition.x, inX) && !equals(mPosition.y, inY))
        return false;
    
    mPosition.SetXY(inX, inY);
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////
/// Updates our dirty, returns true if we were dirty
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifier::UpdateDirtyIfNeeded(void)
{ 
    if(!mDirty)
        return false;

    // update our mesh
    DoOnDirty();
    
    // clean!
    mDirty = false; 
    
    // yes, we were dirty
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////
/// update our mesh, and return false when we're done.
////////////////////////////////////////////////////////////////////////////////////////
bool MeshModifier::Update(uint32 inFrameID, uint32 inCurrentTime)
{ 
    UpdateDirtyIfNeeded(); 
    return (mDeathTime >= inCurrentTime);
}


END_NAMESPACE(LunchtimeStudios)

