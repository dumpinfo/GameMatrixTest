/*  ************************************************************************************************
 *  TextureMesh.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMesh.h"
#include "GraphicsManager.h"
#include "TextureMeshHelpers.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)


////////////////////////////////////////////////////////////////////////////////////////
/// used for sorting
////////////////////////////////////////////////////////////////////////////////////////
static bool ShouldSortSwap(const MeshModifier* inA, const MeshModifier* inB)
{ 
    return (inA && inB && inA->GetPriority() < inB->GetPriority()); 
}

///////////////////////////////////////////////////////////////////////////////////////////////
/// convert to graphics
///////////////////////////////////////////////////////////////////////////////////////////////
bool ToGraphics(MeshVertex& ioVertex, RenderDataCV& ioGraphics, uint32 inFrameID)
{
    bool theResult = (ioVertex.TouchedThisFrame(inFrameID, 2));
    ToArray4Color(ioVertex, (GLubyte*)&(ioGraphics.r), inFrameID);
    
    // convert into graphics space
    GraphicsManager::Instance().ConvertNormalPixelsToRenderingPixels(ioVertex.GetSafeWorldX(), 
                                                                         ioVertex.GetSafeWorldY(), 
                                                                         ioGraphics.x, ioGraphics.y);    
    return theResult;
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////////////
Mesh::Mesh(bool inEnsureUniqueIDS)
: mMesh(NULL)
, mAmtPerRow(0)
, mWidthCountInv(1.0F)
, mHeightCountInv(1.0F)
, mDebugOpacity(0.33333F) // repeating, of course - leroy
, mRenderLines(false)
, mEnsureUniqueModifierIDS(inEnsureUniqueIDS)
, mPreventModifierListChanges(false)
, mDirtyFlags(eMeshDirtyFlags::None)
{
    memset(mRGBA, 0, sizeof(float) * 4);
    mNeedsSort = true;
}

////////////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////////////
Mesh::~Mesh(void)
{
    delete[] mMesh;
}

////////////////////////////////////////////////////////////////////////////////////////
/// build our mesh
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::DoBuildMesh(uint32 inItemsPerRow, float inWidth, float inHeight)
{
    ModifierListLock theLock(mPreventModifierListChanges);
    
    mAmtPerRow  = inItemsPerRow;
    mBounds     = RectangleF::FromPointAndWidthHeight(mBounds.GetTopLeft(), PointF(inWidth, inHeight));
    ASSERT_BRK(mBounds.GetWidth() == inWidth && mBounds.GetHeight() == inHeight);
    
    // build our vertex objects
    DoCreateVertexObjects();
    
    // get our X interval
    mWidthCountInv  = 1.0F / (inItemsPerRow - 1);
    mHeightCountInv = 1.0F / (inItemsPerRow - 1);
    
    mWidthPerQuad = mWidthCountInv * mBounds.GetWidth();
    mHeightPerQuad = mHeightCountInv * mBounds.GetHeight();
    
    
    uint32 theXLoop, theYLoop;
    for(theXLoop = 0; theXLoop < inItemsPerRow; ++theXLoop)
    {
        for(theYLoop = 0; theYLoop < inItemsPerRow; ++theYLoop)
        {
            DoSetupVertex(GetVertex(theXLoop, theYLoop), theXLoop, theYLoop);
        }
    }
}


////////////////////////////////////////////////////////////////////////////////////////
/// update our dirty, returns true if we rebuilt the mesh
////////////////////////////////////////////////////////////////////////////////////////
bool Mesh::DoOnDirty(void)
{
    // 1) if this has tessellation changed, we need to rebuild the mesh.
    // 2) if this is NOT a local mesh, and our world space changed, we need to update
    // NOTE: That can be done without changing the whole mesh. Done here for simplicity.
    if( eMeshDirtyFlags::HasFlag(mDirtyFlags, eMeshDirtyFlags::Tessellation))
    {
        DoBuildMesh(mAmtPerRow, GetWidth(), GetHeight());
        return true;
    }
    
    // set our position
    if(eMeshDirtyFlags::HasFlag(mDirtyFlags, eMeshDirtyFlags::Position) ||
       eMeshDirtyFlags::HasFlag(mDirtyFlags, eMeshDirtyFlags::Size))
    {
       // notify each item to be dirty
       if(mAmtPerRow != 0)
       {
           uint32 theX, theY;
           uint32 theMax = mAmtPerRow;
           for(theY = 0; theY < theMax; theY++)
           {
               for(theX = 0; theX < theMax; ++theX)
               {
                   // marked as needing a world position update
                   GetVertex(theX, theY).SetFlag(eMeshVertexFlags::PositionNeedsUpdate, true);
               }
           }
       }
    }

    return false;
}

////////////////////////////////////////////////////////////////////////////////////////
/// sort our modifiers
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::DoSortModifiers(void)
{
    if(mNeedsSort)
    {
        // lock our lists
        ModifierListLock theLock(mPreventModifierListChanges);
    
        std::sort(mModifiers.begin(), mModifiers.end(), ShouldSortSwap);
        mNeedsSort = false;
    }
}



////////////////////////////////////////////////////////////////////////////////////////
/// setup our vertex
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::DoSetupVertex(MeshVertex& ioVertex, uint32 inX, uint32 inY)
{
    ioVertex.mParentMesh = this;
       
    // record the XY position in the array (optional, but can be useful)
    ioVertex.mXcoord = (uint16)inX;
    ioVertex.mYcoord = (uint16)inY;
       
    // XY position
    ioVertex.mLocalXY[0] = ComputeLocalHomeX(inX);
    ioVertex.mLocalXY[1] = ComputeLocalHomeY(inY);
    
    // recompute our world flags
    ioVertex.DirtyFlag(eMeshVertexFlags::PositionNeedsUpdate);
    
    // sets our color
    ioVertex.mRGBA[0] = mRGBA[0];
    ioVertex.mRGBA[1] = mRGBA[1];
    ioVertex.mRGBA[2] = mRGBA[2];
    ioVertex.mRGBA[3] = mRGBA[3];
}


////////////////////////////////////////////////////////////////////////////////////////
/// makes our vertex objects
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::DoCreateVertexObjects(void)
{
    // remove the old
    delete[] mMesh;
    
    // build our new mesh
    mMesh = new MeshVertex[(mAmtPerRow * mAmtPerRow) + 1];
}

////////////////////////////////////////////////////////////////////////////////////////
/// returns a mesh modifier
////////////////////////////////////////////////////////////////////////////////////////
MeshModifier* Mesh::GetModifier(const MeshModifier::ID& inKey) const
{
    // this could be a map if you end up with lots of modifiers. 
    // track your data and see what your worst cases are.
    ModifierList::const_iterator theIter;
    for(theIter = mModifiers.begin(); theIter != mModifiers.end(); ++theIter)
    {
        if((*theIter)->GetID() == inKey)
            return (*theIter);
    }
    return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////
/// render our mesh
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::Render(RenderStates& ioRenderStates)
{   
    // update if needed.
    UpdateDirtyIfNeeded();

    if(mAmtPerRow > 1)
    {
        RenderDataCV theRenderTL;
        RenderDataCV theRenderTR;
        RenderDataCV theRenderBL;
        RenderDataCV theRenderBR;
        
        uint32 theFrame = ioRenderStates.GetFrameID();
        uint32 theX, theY;
        uint32 theMax = mAmtPerRow - 1;
        bool theDraw;
        
        for(theY = 0; theY < theMax; theY++)
        {
            for(theX = 0; theX < theMax; ++theX)
            {
                MeshVertex*   theVert = &GetVertex(theX, theY); 
                
                // convert to graphics
                theDraw = ToGraphics(*theVert, theRenderTL, theFrame);
                            
                // go to our top right, convert to graphics
                theVert = &GetVertex(theX + 1, theY);
                theDraw = ToGraphics(*theVert, theRenderTR, theFrame) || theDraw;
                
                // fetch our bottom left, convert to graphics
                theVert = &GetVertex(theX, theY + 1);
                theDraw = ToGraphics(*theVert, theRenderBL, theFrame) || theDraw;           
                
                // go to our bottom right, convert to graphics
                theVert = &GetVertex(theX + 1, theY + 1); 
                theDraw = ToGraphics(*theVert, theRenderBR, theFrame) || theDraw;       

                // if everything is "normal", then skip rendering.
                // NOTE: If you detect that MOST of the mesh is covered (in updates, track percent covered)
                // then render everything and don't render the underneath quad and get the fill rate hit.
                // however, if most of your mesh isn't changing, render the big quad, then only overlay quads on things that
                // are different
                //if(theDraw)  
                {
                    ioRenderStates.AddGlobVC(theRenderTL, theRenderTR, theRenderBL, theRenderBR); 
                }
            }
        }
        
        // do our debug rendering
        if(mRenderLines)
        {
            RenderDebugging(ioRenderStates);       
        }
    }
    else
    {
        // draw our color
        ASSERT_BRK(false);
    }
    
    // dump it to graphics
    ioRenderStates.Flush();
}

////////////////////////////////////////////////////////////////////////////////////////
/// render our mesh
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::RenderDebugging(RenderStates& ioRenderStates)
{   
    ioRenderStates.Flush();
    ioRenderStates.SetHasVertices(true);
    ioRenderStates.SetVertexColorArray(true);
    ioRenderStates.SetTexture2D(0);
    
    ASSERT_BRK(mAmtPerRow > 1);
    
    uint32 theX, theY;
    uint32 theMax = (int32)mAmtPerRow - 1;
    
    // render CV
    float thePointsConverted[4];
    float theColorArray[8] = {1.0F, 1.0F, 0.0F, mDebugOpacity, 
                                1.0F, 1.0F, 0.0F, mDebugOpacity};
    

    // cache our gfx manager
    GraphicsManager& theMgr = GraphicsManager::Instance();
    
    for(theY = 0; theY < theMax; theY++)
    {
        for(theX = 0; theX < theMax; ++theX)
        {
            // convert to graphics
            const MeshVertex& theVertA = GetVertex(theX, theY); 
            const MeshVertex& theVertB = GetVertex(theX + 1, theY); 
            const MeshVertex& theVertC = GetVertex(theX, theY + 1); 

            theMgr.ConvertNormalPixelsToRenderingPixels(theVertA.GetSafeWorldX(), theVertA.GetSafeWorldY(), thePointsConverted[0], thePointsConverted[1]);
            theMgr.ConvertNormalPixelsToRenderingPixels(theVertB.GetSafeWorldX(), theVertB.GetSafeWorldY(), thePointsConverted[2], thePointsConverted[3]);
            
            // draw them
            //glEnableClientState(GL_VERTEX_ARRAY);
            glVertexPointer(2, GL_FLOAT, 0, thePointsConverted);
            glColorPointer(4, GL_FLOAT, 0, theColorArray);
            glDrawArrays(GL_LINES, 0, 2);
            
            
            theMgr.ConvertNormalPixelsToRenderingPixels(theVertA.GetSafeWorldX(), theVertA.GetSafeWorldY(), thePointsConverted[0], thePointsConverted[1]);
            theMgr.ConvertNormalPixelsToRenderingPixels(theVertC.GetSafeWorldX(), theVertC.GetSafeWorldY(), thePointsConverted[2], thePointsConverted[3]);
            glVertexPointer(2, GL_FLOAT, 0, thePointsConverted);
            glColorPointer(4, GL_FLOAT, 0, theColorArray);
            glDrawArrays(GL_LINES, 0, 2);
            
        }
    }
    
    
    // dump it to graphics
    ioRenderStates.Flush();
}

////////////////////////////////////////////////////////////////////////////////////////
/// sets our world position
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::SetSize(float inW, float inH)
{
    bool theDimensionChanged = !equals(mBounds.GetWidth(), inW) || !equals(mBounds.GetHeight(), inH);    
    if(theDimensionChanged)
    {
        MarkDirty(eMeshDirtyFlags::Size);        
        mBounds = RectangleF::FromPointAndWidthHeight(mBounds.GetTopLeft(), PointF(inW, inH));
        
        mWidthPerQuad = mWidthCountInv * mBounds.GetWidth();
        mHeightPerQuad = mHeightCountInv * mBounds.GetHeight();
    }
}


////////////////////////////////////////////////////////////////////////////////////////
/// Sets our color
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::SetColor(const float* inRGBA)
{
    if( mRGBA[0] != inRGBA[0] || 
        mRGBA[1] != inRGBA[1] ||
        mRGBA[2] != inRGBA[2] ||
        mRGBA[3] != inRGBA[3])
    {
        mRGBA[0] = inRGBA[0];
        mRGBA[1] = inRGBA[1];
        mRGBA[2] = inRGBA[2];
        mRGBA[3] = inRGBA[3];

        // copy it.
        MarkDirty(eMeshDirtyFlags::Color);        
    }
}

////////////////////////////////////////////////////////////////////////////////////////
/// Sets our color
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::SetColor(const uint8* inRGBA)
{
    float theRGBA[4] = { inRGBA[0] / 255.0F, inRGBA[1] / 255.0F, inRGBA[2] / 255.0F, inRGBA[3] / 255.0F };

    // copy the color
    if( mRGBA[0] != theRGBA[0] || 
        mRGBA[1] != theRGBA[1] ||
        mRGBA[2] != theRGBA[2] ||
        mRGBA[3] != theRGBA[3])
    {
        mRGBA[0] = theRGBA[0];
        mRGBA[1] = theRGBA[1];
        mRGBA[2] = theRGBA[2];
        mRGBA[3] = theRGBA[3];
        
        // copy it.
        MarkDirty(eMeshDirtyFlags::Color);        
    }
}


////////////////////////////////////////////////////////////////////////////////////////
/// sets our world position
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::SetWorldPosition(float inX, float inY)
{
    mBounds = RectangleF::FromPointAndWidthHeight(PointF(inX, inY), mBounds.GetWidthHeight());
    MarkDirty(eMeshDirtyFlags::Position);

    if(mAmtPerRow == 0)
        return;
    
    uint32 theX, theY;
    uint32 theMax = mAmtPerRow;
    for(theY = 0; theY < theMax; theY++)
    {
        for(theX = 0; theX < theMax; ++theX)
        {
            // marked as needing a world position update
            GetVertex(theX, theY).SetFlag(eMeshVertexFlags::PositionNeedsUpdate, true);
        }
    }
}
           
////////////////////////////////////////////////////////////////////////////////////////
/// Update
////////////////////////////////////////////////////////////////////////////////////////
void Mesh::UpdateModifiers(uint32 inFrameID, uint32 inCurrentTime)
{
    // ensure we're not already locked
    ASSERT_BRK(mPreventModifierListChanges == 0);
    
    // lock our lists
    ModifierListLock theLock(mPreventModifierListChanges);
    
    ModifierList::iterator theIter;
    for(theIter = mModifiers.begin(); theIter != mModifiers.end(); )
    {
        // update our modifier. If it returns true, all is well, otherwise remove it
        if((*theIter)->Update(inFrameID, inCurrentTime))
            ++theIter;
        else
            theIter = mModifiers.erase(theIter);
    }    
}


////////////////////////////////////////////////////////////////////////////////////////
/// update all our modifiers per vertex
////////////////////////////////////////////////////////////////////////////////////////
bool Mesh::UpdateMesh(uint32 inFrameID, uint32 inCurrentTime)
{
    // update if needed.
    UpdateDirtyIfNeeded();
    
    ModifierListLock theLock(mPreventModifierListChanges);
    
    bool theResult = false;
    
    // loop over our modifiers
    ModifierList::iterator theIter;
    for(theIter = mModifiers.begin(); theIter != mModifiers.end(); ++theIter)
    {
        if((*theIter)->IsDead(inCurrentTime) == false)
        {
            // process our mesh, and record the result. We want anything that is true.
            theResult = (*theIter)->ProcessMesh(inFrameID, inCurrentTime) || theResult;
        }
    }
    
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////
/// Updates our dirty, returns true if we were dirty
////////////////////////////////////////////////////////////////////////////////////////
bool Mesh::UpdateDirtyIfNeeded(void)
{ 
    if(mDirtyFlags == eMeshDirtyFlags::None)
        return false;
    
    // update our mesh
    DoOnDirty();
    
    // clean!
    mDirtyFlags = eMeshDirtyFlags::None; 
    
    // yes, we were dirty
    return true;
}


END_NAMESPACE(LunchtimeStudios)


