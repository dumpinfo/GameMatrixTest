/*  ************************************************************************************************
 *  TextureMeshModifierLight.h
 *  from 2D Magic in Game Engine Gems 2
 *
 *  A very commonly used item in the mesh is light sources. This are like point lights, or location
 *  based behavior sources.
 *
 *  Note: This code base was written with simplicity in mind, without libraries, such as boost.
 *  I recommend reviewing the code for memory leaks and other performance issues.
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/
#pragma once 

// includes
#include "TextureMeshTypes.h"
#include "TextureMeshModifier.h"
#include "TextureMeshHelpers.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)

/////////////////////////////////////////////////////////////////////////////////////////
/// data for our lights
/////////////////////////////////////////////////////////////////////////////////////////
class LightSource
{   
public:
                                    LightSource(float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~LightSource(void) { }
    
                                    // copy this
    virtual LightSource*            Duplicate(void) const
                                        {   LightSource* theResult = new LightSource(); 
                                            theResult->CopyFrom(this); 
                                            return theResult;
                                        }
        
                                    // returns our ID
    uint32                          GetID(void) const
                                        { return mID; }
    
                                    // returns our color
    const float*                    GetRGBA(void) const
                                        { return mColor.GetRaw(); }
    const ColorF&                   GetColor(void) const 
                                        { return mColor; }
    
                                    // returns our screen radius
    float                           GetScreenRadius(void) const
                                        { return mScreenRadius; }
    
                                    // returns our screen radius in world distance
    float                           GetScreenRadiusAsDistance(void) const
                                        { return mScreenRadiusAsDistance; }
        
                                    // returns our fall off percentage
    float                           GetFallOffPercent(void) const
                                        { return mFallOffPercent; }
    
                                    // returns our XY position
    const float*                    GetXYArray(void) const
                                        { return mXY.AsArray(); }
    const PointF&                   GetXY(void) const
                                        { return mXY; }
    float                           GetX(void) const
                                        { return mXY.x; }
    float                           GetY(void) const
                                        { return mXY.y; }
    
                                    // also computes distance radius
    void                            SetScreenRadius(float inRadius);
    void                            SetColor(const float* inRGBA)
                                        { mColor.SetRaw(inRGBA); }
    void                            SetColor(float inR, float inG, float inB, float inA) 
                                        { mColor.SetRGBA(inR, inG, inB, inA); }
    void                            SetColor(const ColorF& inColor)
                                        { mColor = inColor; }
    void                            SetFallOffPercent(float inPercent)
                                        { mFallOffPercent = inPercent; }
    void                            SetID(uint32 inID)
                                        { mID = inID; }
    void                            SetXY(float inX, float inY)
                                        { mXY.SetXY(inX, inY); }
    void                            SetXY(const PointF& inXY) 
                                        { mXY = inXY; }
    
                                    // copy operator
    LightSource&                    operator=(const LightSource& inLight)
                                        {
                                            mColor          = inLight.mColor;
                                            mXY             = inLight.mXY;
                                            mScreenRadius   = inLight.mScreenRadius;
                                            mFallOffPercent = inLight.mFallOffPercent;
                                            mID             = inLight.mID;
                                            mScreenRadiusAsDistance = inLight.mScreenRadiusAsDistance;
                                            return *this;
                                        }
    
protected:
    
                                    // copy
    virtual void                    CopyFrom(const LightSource* inSource);
                                                 
    ColorF                          mColor;                     // what to color
    PointF                          mXY;                        // our position
	float                           mScreenRadius;              // 0-1 
    float                           mScreenRadiusAsDistance;    // radius in distance (not screen)
	float                           mFallOffPercent;            // how fast it falls off (0-1) 
    uint32                          mID;                        // our ID
};


/////////////////////////////////////////////////////////////////////////////////////////
/// find_if helper
/////////////////////////////////////////////////////////////////////////////////////////
struct MatchesLightSourceID
{
    MatchesLightSourceID(uint32 inID) : mID(inID) { }
    bool operator()(const LightSource* inLight) const
    {
        return (mID == inLight->GetID());
    }
    uint32 mID;
};


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

class MeshModifierLightBase : public MeshModifier
{
public:
                                    MeshModifierLightBase(Mesh* inParentMesh, const ID& inID, bool inEnabled = true)
                                        : MeshModifier(inParentMesh, inID, inEnabled)
                                        { }
    virtual                         ~MeshModifierLightBase(void)
                                        { }
    
protected:
    
                                    // get our base color
    virtual const float*            GetBaseColor(void) const;
    
                                    // light this specific vertex
    virtual bool                    LightVertex(uint32 inFrameID, uint32 inCurrentTime, MeshVertex& ioVertex, const LightSource* inSource);
    
};

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

// Lighting Source
class MeshModifierSingleLight : public MeshModifierLightBase
{
public:
                                    MeshModifierSingleLight(Mesh* inParentMesh, const ID& inID, bool inEnabled = true, float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~MeshModifierSingleLight(void);
    
                                    // returns our light source
    LightSource&                    GetLightSource(void)
                                        { return mLight; }
    
                                    // modify the vertices on this mesh
    virtual bool                    ProcessMesh(uint32 inFrameID, uint32 inCurrentTime);
    
                                    // update our mesh, and return false when we're done.
    virtual bool                    Update(uint32 inFrameID, uint32 inCurrentTime);
    
protected:
    
                                    // this is dirty now.
    virtual void                    DoOnDirty(void);

    LightSource                     mLight;
    
};

/////////////////////////////////////////////////////////////////////////////////
/// Multiple lights
/////////////////////////////////////////////////////////////////////////////////
class MeshModifierLightGroup : public MeshModifierLightBase
{
public:
    typedef std::vector< LightSource* >      LightArray;

                                    MeshModifierLightGroup(Mesh* inParentMesh, const ID& inID, bool inEnabled = true, float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~MeshModifierLightGroup(void);

                                    // add a light
    virtual LightSource*            AddLightSource(const LightSource* inLight);

                                    // returns our a lightsource of this ID
    const LightSource*              GetLightSource(uint32 inID) const
                                        {
                                            ListLocker theLock(mProtectLightList);
                                            
                                            // find it, linear search. 
                                            LightArray::const_iterator theIter = std::find_if(mLights.begin(), mLights.end(), MatchesLightSourceID(inID));
                                            return (theIter != mLights.end()) ? (*theIter) : NULL;
                                        }
    
                                    // returns our a lightsource of this ID
    LightSource*                    GetLightSource(uint32 inID)
                                        {
                                            ListLocker theLock(mProtectLightList);
                                            
                                            // find it, linear search. 
                                            LightArray::iterator theIter = std::find_if(mLights.begin(), mLights.end(), MatchesLightSourceID(inID));
                                            return (theIter != mLights.end()) ? (*theIter) : NULL;
                                        }
    
    const LightArray&               GetLightSources(void) const
                                        { return mLights; }
       
                                    // returns true if we found / removed the light
    bool                            RemoveLight(LightSource* inLightSource);    
    
                                    // modify the vertices on this mesh
    virtual bool                    ProcessMesh(uint32 inFrameID, uint32 inCurrentTime);
    
                                    // update our mesh, and return false when we're done.
    virtual bool                    Update(uint32 inFrameID, uint32 inCurrentTime);
    
protected:
    typedef ScopedFlagLock< volatile uint8 > ListLocker;

                                    // this is dirty now.
    virtual void                    DoOnDirty(void);
    
   
    LightArray                      mLights;
    uint32                          mLightStamp;        // used to unique ID our lights
    mutable volatile uint8          mProtectLightList;  // a lock, without it being a lock. (assert type lock)
    
};


//////////////////////////////////////////////////////////////////////////////////////////
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//                                                                                      //
//                              MeshModifierFlashLight                                  //
//                                                                                      //
// Desc: Give the look of a flash light. Color the texture (dark), and light it.        //
// *    *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   //
//////////////////////////////////////////////////////////////////////////////////////////

class MeshModifierFlashLight : public MeshModifierLightGroup
{
public:
                                    MeshModifierFlashLight(Mesh* inParentMesh, const ID& inID, bool inEnabled = true, float inRadius = 0.5F, float inFallOffPercent = 1.0F);
    virtual                         ~MeshModifierFlashLight(void);
    
                                    // returns our darkness coloring RGBA
    const float*                    GetDarknessColor(void) const
                                        { return mDarknessColor; }
    
                                    // set our darkness coloring as RGBA
    virtual void                    SetDarknessColor(const float* inRGBA);
        
    
protected:

                                    // get our base color
    virtual const float*            GetBaseColor(void) const
                                        { return mDarknessColor; }
    
    float                           mDarknessColor[4]; // in RGBA
};



END_NAMESPACE(LunchtimeStudios)

