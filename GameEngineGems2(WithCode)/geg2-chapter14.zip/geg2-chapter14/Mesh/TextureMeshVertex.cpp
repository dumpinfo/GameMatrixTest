/*  ************************************************************************************************
 *  TextureMeshVertex.cpp
 *  from 2D Magic in Game Engine Gems 2
 *
 *  Implementation - see .h for details
 * 
 *  Created by Dan Higgins ( code@lunchtimestudios.com )
 *  Copyright 2010 Lunchtime Studios, LLC. All rights reserved.
 *  http://www.lunchtimestudios.com
 *  ***********************************************************************************************/

#include "TextureMeshVertex.h"
#include "TextureMeshUV.h"

// avoid namespace collisions
BEGIN_NAMESPACE(LunchtimeStudios)


////////////////////////////////////////////////////////////////////////////////
/// constructor
////////////////////////////////////////////////////////////////////////////////
MeshVertex::MeshVertex(void) 
: mFlags(0), mFrameID(0), mColorFrameID(0), mXcoord(~0), mYcoord(~0)
{
    mWorldXY[0] = 0;        mWorldXY[1] = 0;
    mLocalXY[0] = 0;        mLocalXY[1] = 0;
    mRGBA[0]    = 1.0F;     mRGBA[1] = 1.0F; 
    mRGBA[2]    = 1.0F;     mRGBA[3] = 1.0F;
    mLocalUV[0] = 0.0F;     mLocalUV[1] = 0.0F;
    mWorldUV[0] = 0.0F;     mWorldUV[1] = 0.0F;    
    
    // ensure we recompute data first tick
    SetFlag(eMeshVertexFlags::PositionNeedsUpdate, true);
    SetFlag(eMeshVertexFlags::UVNeedsUpdate, true);
}

////////////////////////////////////////////////////////////////////////////////
/// destructor
////////////////////////////////////////////////////////////////////////////////
MeshVertex::~MeshVertex(void)
{
    
}

////////////////////////////////////////////////////////////////////////////////
/// transform from local to world
////////////////////////////////////////////////////////////////////////////////
void MeshVertex::DoUpdatePosition(void) const
{
    mWorldXY[0] = mParentMesh->ComputeWorldX(mLocalXY[0]);
    mWorldXY[1] = mParentMesh->ComputeWorldY(mLocalXY[1]);
    
    // no longer dirty
    eMeshVertexFlags::SetFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate, false);
}

////////////////////////////////////////////////////////////////////////////////
/// transform from local to world
////////////////////////////////////////////////////////////////////////////////
void MeshVertex::DoUpdateUV(void) const
{
    mWorldUV[0] = CheckedCast<MeshUV>(mParentMesh)->ComputeWorldU(mLocalUV[0]);
    mWorldUV[1] = static_cast<MeshUV*>(mParentMesh)->ComputeWorldV(mLocalUV[1]);
    
    // no longer dirty
    eMeshVertexFlags::SetFlag(mFlags, eMeshVertexFlags::UVNeedsUpdate, false);
}


////////////////////////////////////////////////////////////////////////////////
/// return us to our local XY
////////////////////////////////////////////////////////////////////////////////
void MeshVertex::ReturnToLocalXY(void)
{
    mLocalXY[0] = mParentMesh->ComputeLocalHomeX(mXcoord);
    mLocalXY[1] = mParentMesh->ComputeLocalHomeY(mYcoord);
    eMeshVertexFlags::SetFlag(mFlags, eMeshVertexFlags::PositionNeedsUpdate, true);

}

////////////////////////////////////////////////////////////////////////////////
/// sets our world XY
////////////////////////////////////////////////////////////////////////////////
void MeshVertex::SetWorldXY(float inX, float inY)
{
    if(mWorldXY[0] == inX && mWorldXY[1] == inY)
        return;
    
    // copy the world position
    mWorldXY[0] = inX; 
    mWorldXY[1] = inY;
    
    // convert it to local space for future use
    mLocalXY[0] = mParentMesh->ComputeLocalX(inX);
    mLocalXY[1] = mParentMesh->ComputeLocalY(inY);
    
    // position changed
    eMeshVertexFlags::SetFlag(mFlags, eMeshVertexFlags::NeedsBasePosition, true);
}



END_NAMESPACE(LunchtimeStudios)

