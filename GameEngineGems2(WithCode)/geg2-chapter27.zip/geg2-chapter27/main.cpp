//-------------------
// main.cpp
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include "RemoteHeapBitwise.h"
#include "RemoteHeapBlockwise.h"
#include <math.h>
#include <vector>
#include <windows.h>

//-------------------

static void TestHeapBitwise(void *heapMem, unsigned heapSize, unsigned granularity)
{
	uint const trackingMemoryLength = CRemoteHeapBitwise::GetLocalMemoryRequirements(heapSize, granularity);
	unsigned char *trackingMemory = (unsigned char *)malloc(trackingMemoryLength);
	{
		CRemoteHeapBitwise heap((uint)heapMem, heapSize, granularity, trackingMemory, trackingMemoryLength);

		uint allocFailures = 0;
		srand(2112);
		std::vector<uint> allocs;
		for (uint i=0; i<1000000; i++)
		{
			// allocate something
			if (rand() & (1|2|4|8|16))
			{
				uint const sz = rand() % (int)sqrtf((float)heapSize);  // no giant allocations.. causes too many failures and screws up the test
				uint const addr = heap.Alloc(sz);
				if (addr)
				{
					allocs.push_back(addr);
				}
				else
				{
					allocFailures++;
				}
			}

			// half the time, delete something
			if (allocs.size() && (rand() & (2|4|8|16)))  // some random bit, but not the lowest ones
			{
				uint const killIndex = (rand() % allocs.size());
				heap.Free(allocs[killIndex]);
				allocs[killIndex] = allocs.back();  // swap delete trick--order is not important in this vector
				allocs.pop_back();
			}
		}

		// free them now
		while (allocs.size())
		{
			heap.Free(allocs.back());
			allocs.pop_back();
		}

		printf("Alloc Failures = %d\n", allocFailures);
	}
	free(trackingMemory);
}

//-------------------

static void TestHeapBlockwise(void *heapMem, unsigned heapSize, unsigned maxAllocs)
{
	uint const trackingMemoryLength = CRemoteHeapBlockwise::GetLocalMemoryRequirements(heapSize, maxAllocs);
	unsigned char *trackingMemory = (unsigned char *)malloc(trackingMemoryLength);
	{
		CRemoteHeapBlockwise heap((uint)heapMem, heapSize, maxAllocs, 8, trackingMemory, trackingMemoryLength);

		uint allocFailures = 0;
		srand(2112);
		std::vector<uint> allocs;
		for (uint i=0; i<1000000; i++)
		{
			// allocate something
			if (rand() & (1|2|4|8|16))
			{
				uint const sz = rand() % (int)sqrtf((float)heapSize);  // no giant allocations.. causes too many failures and screws up the test
				uint const addr = heap.Alloc(sz);
				if (addr)
				{
					allocs.push_back(addr);
				}
				else
				{
					allocFailures++;
				}
			}
			heap.SanityCheck();			

			// half the time, delete something
			if (allocs.size() && (rand() & (2|4|8|16)))  // some random bit, but not the lowest ones
			{
				uint const killIndex = (rand() % allocs.size());
				heap.Free(allocs[killIndex]);
				allocs[killIndex] = allocs.back();  // swap delete trick--order is not important in this vector
				allocs.pop_back();
			}

			heap.SanityCheck();
		}

		// free them now
		while (allocs.size())
		{
			heap.Free(allocs.back());
			allocs.pop_back();
		}

		printf("Alloc Failures = %d\n", allocFailures);
	}
	free(trackingMemory);
}

//-------------------
// These test out how the heaps work, their performance, and give some idea of scalability.  The results basically tell us that
// the Bitwise method is great for ensuring allocations succeed as much as possible with decent performance, regardless of the
// granularity, but does not scale very well, since the allocations are rounded up to ever-larger block sizes to maintain performance.
// 
// These results also show that the Blockwise method is fastest (due to the lazy-updated hash table) and is very quick when the number of
// allocations in the heap will be minimal.  However, this implementation is a poor replacement for a generalized heap as performance 
// degrades as the max number of allocs increases, because the full traversal searching for memory can be very slow.
void main(void)
{
	unsigned const kHeapSize = 1024*1024 * 8;  // 8mb
	void *heapBlock = malloc(kHeapSize);

	//-------------------
	// Bitwise heaps
	LARGE_INTEGER freq;
	QueryPerformanceFrequency(&freq);

	LARGE_INTEGER beforeHeap0, afterHeap0;
	QueryPerformanceCounter(&beforeHeap0);
	TestHeapBitwise(heapBlock, kHeapSize, 8);
	QueryPerformanceCounter(&afterHeap0);	

	LARGE_INTEGER beforeHeap1, afterHeap1;
	QueryPerformanceCounter(&beforeHeap1);
	TestHeapBitwise(heapBlock, kHeapSize, 32);
	QueryPerformanceCounter(&afterHeap1);	

	LARGE_INTEGER beforeHeap2, afterHeap2;
	QueryPerformanceCounter(&beforeHeap2);
	TestHeapBitwise(heapBlock, kHeapSize, 128);
	QueryPerformanceCounter(&afterHeap2);	

	printf("Heap0 (8   byte granularity) Time: %f\n", (afterHeap0.QuadPart - beforeHeap0.QuadPart) / (float)freq.QuadPart);	
	printf("Heap1 (32  byte granularity) Time: %f\n", (afterHeap1.QuadPart - beforeHeap1.QuadPart) / (float)freq.QuadPart);
	printf("Heap2 (128 byte granularity) Time: %f\n", (afterHeap2.QuadPart - beforeHeap2.QuadPart) / (float)freq.QuadPart);

	//-------------------
	// Blockwise heaps
	LARGE_INTEGER beforeHeap3, afterHeap3;
	QueryPerformanceCounter(&beforeHeap3);
	TestHeapBlockwise(heapBlock, kHeapSize, 4096);
	QueryPerformanceCounter(&afterHeap3);	

	LARGE_INTEGER beforeHeap4, afterHeap4;
	QueryPerformanceCounter(&beforeHeap4);
	TestHeapBlockwise(heapBlock, kHeapSize, 1048);
	QueryPerformanceCounter(&afterHeap4);	

	LARGE_INTEGER beforeHeap5, afterHeap5;
	QueryPerformanceCounter(&beforeHeap5);
	TestHeapBlockwise(heapBlock, kHeapSize, 256);
	QueryPerformanceCounter(&afterHeap5);	

	printf("Heap3 (4096 allocs) Time: %f\n", (afterHeap3.QuadPart - beforeHeap3.QuadPart) / (float)freq.QuadPart);	
	printf("Heap4 (1024 allocs) Time: %f\n", (afterHeap4.QuadPart - beforeHeap4.QuadPart) / (float)freq.QuadPart);
	printf("Heap5 (256  allocs) Time: %f\n", (afterHeap5.QuadPart - beforeHeap5.QuadPart) / (float)freq.QuadPart);

	free(heapBlock);
}

//-------------------
