//-------------------
// RemoteHeapBitwise.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef REMOTEHEAPBITWISE_H
#define REMOTEHEAPBITWISE_H

//-------------------

#include "BitHelpers.h"

//-------------------

class CRemoteHeapBitwise
{
public:
	CRemoteHeapBitwise(uint startAddr, uint length, uint granularity, unsigned char *localMemory, uint localMemoryLength)
		: mStart(startAddr), mLength(length), mGranularity(granularity), mFirstBitToCheck(0), mCurrentAllocs(0), mLocalMemory(localMemory)
	{
		// double-check that the user is doing his job
		assert(GetLocalMemoryRequirements(length, granularity) == localMemoryLength && localMemory!=NULL);

		// configure the local memory pointers
		uint const bytesPerMask = (length / mGranularity / 8 + 3) & ~3;  // round up length to the next even word address
		mFreeMask       = (unsigned char *)(((uint)mLocalMemory + 3) & ~3);                 // round up start of mask to next even word address
		mEndOfAllocMask = mFreeMask + bytesPerMask;                      // start this mask immediately after the alloc 

		// initialize the masks so everything is free and no end-of-allocations are marked
		memset(mFreeMask, 0xff, bytesPerMask);
		memset(mEndOfAllocMask, 0, bytesPerMask);
	}
	~CRemoteHeapBitwise(void)
	{
		assert(mCurrentAllocs==0);  // should balance, or you have leaks
	}

	uint     Alloc(uint sizeInBytes);
	void     Free (uint addr);

	// Simple function to determine if a specific remote pointer plausibly could belong to this heap or not.
	bool     IsFromHeap(uint addr) { return (addr >= mStart && addr < mStart + mLength); }

	// Simple accessors, to allow user to clean up later
	uint           GetHeapAddress(void) const { return mStart;       }
	unsigned char *GetLocalMemory(void) const { return mLocalMemory; }

	// Before you can construct the heap, you first have to give it some LOCAL memory to track the heap with.
	static uint GetLocalMemoryRequirements(uint length, uint granularity)
	{
		uint const bytesPerMask = (length / granularity / 8 + 3) & ~3;  // round up length to the next even word
		return 2*bytesPerMask + 3;  // extra bytes to ensure initial address alignment;
	}
	
protected:
private:
	uint mStart;           // This is the address to the start of the remote heap's memory
	uint mLength;          // This is how long the block is in the remote heap that we're managing.
	uint mGranularity;     // This is the 'atomic size' that will be used when allocating and searching for chunks of memory in the heap.
	uint mFirstBitToCheck; // Remembers the first possible available block, saves time when searching a mostly-full heap.
	int  mCurrentAllocs;   // For checking purposes.

	unsigned char *mLocalMemory;    // This is the start of the memory the user gave us in reachable, local memory, that is used to track the remote address space.
	unsigned char *mFreeMask;       // This is a pointer INTO mLocalMemory, and refers to a bitmask that tracks which blocks of size mGranularity are free or used.
	unsigned char *mEndOfAllocMask; // This is a pointer INTO mLocalMemory, and refers to a bitmask that is zero except at the block that marks the end of each allocation.
};

//-------------------

uint CRemoteHeapBitwise::Alloc(uint sizeInBytes)
{
	if (sizeInBytes==0)
	{
		sizeInBytes = 1;  // otherwise, this ends up allocating no blocks and it messes up the mask
	}

	// configure the local memory pointers
	uint const bitsInMask = mLength / mGranularity;
	uint const bitsInAlloc = (sizeInBytes + mGranularity - 1) / mGranularity;  // round up to next even granular block
	uint const lastValidAllocStart = bitsInMask - bitsInAlloc + 1;

	// search from the last good spot to the end of the block
	for (uint bit=/*0; */mFirstBitToCheck; bit < lastValidAllocStart; )
	{
		// this scans forward from 'bit' and returns the index of the first bit it finds set, or lastValidAllocStart+1
		uint const onBit = FindFirst1BitInRange(mFreeMask, bit, lastValidAllocStart);
		if (onBit > lastValidAllocStart)
		{
			break;  // failed to allocate
		}

		// scan forward only as far as we have to looking for enough space to allocate the memory
		uint const lastBitInAlloc = onBit + bitsInAlloc - 1;
		
		// this is only a valid allocation if the next off bit is farther away than bitsInAlloc
		uint const offBit = FindFirst0BitInRange(mFreeMask, onBit+1, lastBitInAlloc);
		if (offBit > lastBitInAlloc)
		{
			// set a marker to know the last block in this particular allocation
			assert(FindFirst0BitInRange(mEndOfAllocMask, lastBitInAlloc, lastBitInAlloc)==lastBitInAlloc);  // make sure nothing ends here already
			SetBitTo1(mEndOfAllocMask, lastBitInAlloc);
			
			// mark all these blocks as used
			SetBitRangeTo0(mFreeMask, onBit, lastBitInAlloc);

			mCurrentAllocs++;  // keep tally
			mFirstBitToCheck = lastBitInAlloc+1;  // advance the search to right after this allocation			
			return onBit * mGranularity + mStart;
		}

		bit = offBit+1;  // skip past the blocking bit and start scanning again
	}

	// search from the beginning of memory to the last known good spot, unlikely but possible to find memory
#if 1
	for (uint bit=0; bit < mFirstBitToCheck; )
	{
		// this scans forward from 'bit' and returns the index of the first bit it finds set, or lastValidAllocStart+1
		uint const onBit = FindFirst1BitInRange(mFreeMask, bit, mFirstBitToCheck);
		if (onBit > lastValidAllocStart)
		{
			return 0;  // failed to allocate
		}

		// scan forward only as far as we have to looking for enough space to allocate the memory
		uint const lastBitInAlloc = onBit + bitsInAlloc - 1;
		
		// this is only a valid allocation if the next off bit is farther away than bitsInAlloc
		uint const offBit = FindFirst0BitInRange(mFreeMask, onBit+1, lastBitInAlloc);
		if (offBit > lastBitInAlloc)
		{
			// set a marker to know the last block in this particular allocation
			assert(FindFirst0BitInRange(mEndOfAllocMask, lastBitInAlloc, lastBitInAlloc)==lastBitInAlloc);  // make sure nothing ends here already
			SetBitTo1(mEndOfAllocMask, lastBitInAlloc);
			
			// mark all these blocks as used
			SetBitRangeTo0(mFreeMask, onBit, lastBitInAlloc);

			mCurrentAllocs++;  // keep tally
			mFirstBitToCheck = lastBitInAlloc+1;  // advance the search to right after this allocation
			return onBit * mGranularity + mStart;
		}

		bit = offBit+1;  // skip past the blocking bit and start scanning again
	}
#endif
	// failed to allocate
	return 0;
}

//-------------------

void CRemoteHeapBitwise::Free (uint addr)
{
	uint const bitsInMask = mLength / mGranularity;

	assert(((addr - mStart) % mGranularity) == 0);  // ensure the address is actually a proper starting for an allocation
	uint const startBit = (addr - mStart) / mGranularity;
	uint const lastBit  = FindFirst1BitInRange(mEndOfAllocMask, startBit, bitsInMask);
	assert(lastBit <= bitsInMask);  // allocation has no end to it... something broke here

	// clear end of allocation bit
	SetBitTo0(mEndOfAllocMask, lastBit);
	
	// mark block as free
	SetBitRangeTo1(mFreeMask, startBit, lastBit);

	mCurrentAllocs--;  // keep tally
	assert(mCurrentAllocs>=0);

	// move the search to begin right here, if this address is LOWER than the one we're already searching from
	if (startBit < mFirstBitToCheck)
		mFirstBitToCheck = startBit;  
}

//-------------------

#endif
