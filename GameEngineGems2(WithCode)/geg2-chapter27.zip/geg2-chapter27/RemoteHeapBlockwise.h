//-------------------
// RemoteHeapBlockwise.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef REMOTEHEAPBLOCKWISE_H
#define REMOTEHEAPBLOCKWISE_H

//-------------------

#include <limits.h>
//#include <stdio.h>

//-------------------

class CRemoteHeapBlockwise
{
public:
	CRemoteHeapBlockwise(uint startAddr, uint length, uint maxAllocs, uint alignment, unsigned char *localMemory, uint localMemoryLength)
		: mStart(startAddr), mLength(length), mMaxAllocs(maxAllocs), mAlignment(alignment), mCurrentAllocs(0), mLocalMemory(localMemory)
	{
		// double-check that the user is doing his job
		assert(GetLocalMemoryRequirements(length, maxAllocs) == localMemoryLength && localMemory!=NULL);

		// configure the local memory pointers
		mAllocations = (AllocatedBlock *)mLocalMemory;
		mAllocations[0].mAddress = startAddr;
		mAllocations[0].mAllocBytes = mAlignment;  // much as it pains me, this has to be done or it SEVERELY complicates allocation/deletion with special case code to save one tiny piece of memory.
		mAllocations[0].mFreeBytes = length - mAlignment;
		mAllocations[0].mNextBlockIndex = kSentinel;  // sentinel, means end of list
		mHeadIndex = 0;

		// thread the unused list
		for (uint i=1; i<mMaxAllocs-1; i++)
		{
			((UnusedBlock*)&mAllocations[i])->mNextUnusedBlockIndex = i+1;
		}
		((UnusedBlock*)&mAllocations[mMaxAllocs-1])->mNextUnusedBlockIndex = kSentinel;		
		mUnusedIndex = 1;

		// configure hash table, and set to sentinel, meaning we don't know anything about existing allocations or free spots.
		mNumHashEntries = LogBase2(length)+1;
		mHashTable = (uint*)(mAllocations + mMaxAllocs);  // put the hash table at the end of the local memory, after the allocation tracking pool
		for (uint i=0; i<mNumHashEntries; i++)
		{
			mHashTable[i] = kSentinel;
		}
	}
	~CRemoteHeapBlockwise(void)
	{
		assert(mCurrentAllocs==0);  // should balance, or you have leaks
	}

	uint     Alloc(uint sizeInBytes);
	void     Free (uint addr);

	// Simple function to determine if a specific remote pointer plausibly could belong to this heap or not.
	bool     IsFromHeap(uint addr) { return (addr >= mStart && addr < mStart + mLength); }

	// Asserts if anything goes haywire.
	void     SanityCheck(void);

	// Simple accessors, to allow user to clean up later
	uint           GetHeapAddress(void) const { return mStart;       }
	unsigned char *GetLocalMemory(void) const { return mLocalMemory; }

	// Before you can construct the heap, you first have to give it some LOCAL memory to track the heap with.
	static uint GetLocalMemoryRequirements(uint length, uint maxAllocs)
	{
		uint const bytesForAllocs = sizeof(AllocatedBlock) * maxAllocs;
		uint const bytesForHashTable = (LogBase2(length)+1) * sizeof(uint);
		
		return bytesForAllocs + bytesForHashTable;
	}
	
protected:
	enum
	{
		kSentinel = UINT_MAX
	};
	
	struct AllocatedBlock
	{
		uint        mAddress;         // this is where the block starts
		uint        mAllocBytes;      // these are bytes at the BEGINNING of the allocation
		uint        mFreeBytes;       // these are bytes at the END of the allocation
		uint        mNextBlockIndex;  // this makes allocation and mergine free blocks fast, by turning the array of allocations
		                              // into a pool of a large linked list that contains all tracked memory.
	};

	struct UnusedBlock
	{
		uint        mNextUnusedBlockIndex;  // This is a threaded free list inside the mAllocations pool.  Doing this allows for O(1) locating of AllocatedBlock objects in the pool.
		uint        mSentinel;              // If unused, this is set to sentinel.  This saves us effort of managing the hash table.
	};
	
private:
	uint mStart;           // This is the address to the start of the remote heap's memory
	uint mLength;          // This is how long the block is in the remote heap that we're managing.
	uint mMaxAllocs;       // This is how many allocations are possible with this heap.  If you run out, bump it up some.
	uint mAlignment;       // All allocations will be rounded up to an even multiple of this.
	int  mCurrentAllocs;   // For checking purposes.

	unsigned char  *mLocalMemory;  // This is the start of the memory the user gave us in reachable, local memory, that is used to track the remote address space.
	AllocatedBlock *mAllocations;  // This is a pool of AllocatedBlock objects, and by being a pool, also has a threaded linked list of UnusedBlock objects.
	uint            mHeadIndex;    // Points to the first AllocatedBlock.
	uint            mUnusedIndex;  // Points to the first UnusedBlock, which occupies the space of an AllocatedBlock.

	uint            mNumHashEntries;  // This is how many entries are in the hash table.
	uint           *mHashTable;       // This is basically broken up in power-of-two sizes up to the complete size of the heap, for quick allocating.  If kSentinel is stored, we must do a slow search instead.
};

//-------------------

uint CRemoteHeapBlockwise::Alloc(uint sizeInBytes)
{
	if (mUnusedIndex==kSentinel)  // out of allocations, fail
		return 0;
		
	// round up to even multiple of mAlignment
	sizeInBytes = (sizeInBytes + mAlignment - 1) / mAlignment * mAlignment;  

	static int hitsOnHash = 0;  // my tests suggest the hash table finds a block about 65% of the time, in general.
	static int total = 0;
	total++;

#if 1  // zero this out to see how much a hash table helps
	// try for a quick fix by checking the hash table for our allocation.  This doesn't always work, but sometimes it will, and it saves us a potentially lengthy search.
	uint const initialHashEntry = LogBase2(sizeInBytes);  // check for entries large enough to hold this 
	for (uint iHash = initialHashEntry; iHash < mNumHashEntries; iHash++)  // check all size buckets that have room for us
	{
		if (mHashTable[iHash] != kSentinel)  // this hash entry may not have anything right now.
		{
			UnusedBlock &ublock = *(UnusedBlock *)&mAllocations[mHashTable[iHash]];
			if (ublock.mSentinel != kSentinel)  // yes, the hash table points to a valid allocation block
			{
				uint const cur = mHashTable[iHash];
				AllocatedBlock &eblock = mAllocations[cur];
				if (eblock.mFreeBytes >= sizeInBytes)  // got room?
				{
					uint const newIndex = mUnusedIndex;
					AllocatedBlock &ablock = mAllocations[newIndex];  // take an allocation header from the pool
					mUnusedIndex = ((UnusedBlock*)&ablock)->mNextUnusedBlockIndex;  // snatch the new head of the unused list
		
					// configure the new allocation
					ablock.mAddress    = eblock.mAddress + eblock.mAllocBytes;
					ablock.mAllocBytes = sizeInBytes;
					ablock.mFreeBytes  = eblock.mFreeBytes - sizeInBytes;
					ablock.mNextBlockIndex = eblock.mNextBlockIndex;  // wedge this in there, so allocs stay in increasing-address-order.
					eblock.mFreeBytes = 0;              // since we put the new allocation immediately after the current allocation, there should be no free bytes left there.
					eblock.mNextBlockIndex = newIndex;  // link in the new allocation

					// insert the remainder into the hash table
					uint const hashEntry = LogBase2(ablock.mFreeBytes);
					assert(hashEntry < mNumHashEntries);
					mHashTable[hashEntry] = newIndex;
		
					mCurrentAllocs++;  // keep tally
					hitsOnHash++;
					return ablock.mAddress;				
				}
				else
				{
					mHashTable[iHash] = kSentinel;  // table is out of date--there isn't room at this alloc anymore
				}
			}
			else
			{
				mHashTable[iHash] = kSentinel;  // table is out of date--there isn't an allocation here anymore
			}			
		}
	}
#endif

	// search the linked list for a block big enough to hold the alloc (this is a First Fit algorithm).  Can be slow for many allocs.
	for (uint cur = mHeadIndex; cur!=kSentinel; cur = mAllocations[cur].mNextBlockIndex)
	{
		if (mAllocations[cur].mFreeBytes >= sizeInBytes)
		{
			uint const newIndex = mUnusedIndex;
			AllocatedBlock &ablock = mAllocations[newIndex];  // take an allocation header from the pool
			mUnusedIndex = ((UnusedBlock*)&ablock)->mNextUnusedBlockIndex;  // snatch the new head of the unused list

			// configure the new allocation
			AllocatedBlock &eblock = mAllocations[cur];
			ablock.mAddress    = eblock.mAddress + eblock.mAllocBytes;
			ablock.mAllocBytes = sizeInBytes;
			ablock.mFreeBytes  = eblock.mFreeBytes - sizeInBytes;
			ablock.mNextBlockIndex = eblock.mNextBlockIndex;  // wedge this in there, so allocs stay in increasing-address-order.
			eblock.mFreeBytes = 0;              // since we put the new allocation immediately after the current allocation, there should be no free bytes left there.
			eblock.mNextBlockIndex = newIndex;  // link in the new allocation

			// insert the remainder into the hash table
			uint const hashEntry = LogBase2(ablock.mFreeBytes);
			assert(hashEntry < mNumHashEntries);
			mHashTable[hashEntry] = newIndex;

			mCurrentAllocs++;  // keep tally
			return ablock.mAddress;
		}
	}

	// failed to allocate
	return 0;
}

//-------------------

void CRemoteHeapBlockwise::Free (uint addr)
{
	// find the allocation in the list... this can be slow for lots of allocs.
	for (uint cur = mHeadIndex, prev = kSentinel; cur!=kSentinel; prev = cur, cur = mAllocations[cur].mNextBlockIndex)
	{
		if (addr == mAllocations[cur].mAddress)  // found it!  Delete the memory.
		{
			assert(prev!=kSentinel);  // this should never happen since we fake-allocate the first block of memory and it always is the head.
			AllocatedBlock &prevBlock = mAllocations[prev];
			AllocatedBlock &curBlock  = mAllocations[cur];
			assert(prevBlock.mAddress + prevBlock.mAllocBytes + prevBlock.mFreeBytes == curBlock.mAddress);  // sanity check that these two are actually adjacent in memory

			// merge the memory represented by the newly deleted chunk into the previous one.
			prevBlock.mNextBlockIndex = curBlock.mNextBlockIndex;
			prevBlock.mFreeBytes     += curBlock.mAllocBytes + curBlock.mFreeBytes;  

			// make this the new top of the unused blocks list
			((UnusedBlock *)&curBlock)->mNextUnusedBlockIndex = mUnusedIndex;			
			((UnusedBlock *)&curBlock)->mSentinel = kSentinel;  // mark unused
			mUnusedIndex = cur;

			// see if we can put this block in the hash table
			uint const hashEntry = LogBase2(prevBlock.mFreeBytes);
			assert(hashEntry < mNumHashEntries);
			mHashTable[hashEntry] = prev;

			mCurrentAllocs--;  // keep tally
			assert(mCurrentAllocs>=0);
			return;
		}
	}

	assert(false);  // failed to delete memory
}

//-------------------

void CRemoteHeapBlockwise::SanityCheck(void)
{
#ifdef _DEBUG
	uint memoryFree = 0;
	uint memoryAlloc = 0;
	int allocCount = -1;  // there is an extra alloc sentinel at the head that we don't want to count in the total.
	for (uint cur = mHeadIndex; cur!=kSentinel; cur = mAllocations[cur].mNextBlockIndex)
	{
		allocCount++;
		memoryAlloc += mAllocations[cur].mAllocBytes;		
		memoryFree  += mAllocations[cur].mFreeBytes;
	}

	assert(allocCount == mCurrentAllocs);
	assert(memoryFree + memoryAlloc == mLength);
#endif
}
	
//-------------------
	
#endif
