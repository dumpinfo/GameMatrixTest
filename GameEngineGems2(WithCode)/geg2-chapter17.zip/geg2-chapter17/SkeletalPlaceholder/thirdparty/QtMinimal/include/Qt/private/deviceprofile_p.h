#include "../../../tools/designer/src/lib/shared/deviceprofile_p.h"
