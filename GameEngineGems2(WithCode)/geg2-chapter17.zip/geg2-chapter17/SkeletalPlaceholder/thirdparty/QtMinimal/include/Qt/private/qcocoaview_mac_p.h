#include "../../../src/gui/kernel/qcocoaview_mac_p.h"
