#include "../../../src/xmlpatterns/type/qatomictypedispatch_p.h"
