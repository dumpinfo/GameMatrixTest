#include "../../../tools/designer/src/lib/shared/propertylineedit_p.h"
