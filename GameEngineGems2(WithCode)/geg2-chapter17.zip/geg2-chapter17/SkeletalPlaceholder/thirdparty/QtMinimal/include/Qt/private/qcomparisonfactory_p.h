#include "../../../src/xmlpatterns/data/qcomparisonfactory_p.h"
