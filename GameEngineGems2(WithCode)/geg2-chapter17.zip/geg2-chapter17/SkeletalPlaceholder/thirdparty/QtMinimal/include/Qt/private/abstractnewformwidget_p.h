#include "../../../tools/designer/src/lib/sdk/abstractnewformwidget_p.h"
