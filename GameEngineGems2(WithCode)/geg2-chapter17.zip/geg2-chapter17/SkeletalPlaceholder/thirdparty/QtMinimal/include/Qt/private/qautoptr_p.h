#include "../../../src/xmlpatterns/utils/qautoptr_p.h"
