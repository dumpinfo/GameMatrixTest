#include "../../../src/xmlpatterns/functions/qcurrentfn_p.h"
