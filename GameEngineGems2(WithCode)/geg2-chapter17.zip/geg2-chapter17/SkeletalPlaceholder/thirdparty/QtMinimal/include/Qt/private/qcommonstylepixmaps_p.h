#include "../../../src/gui/styles/qcommonstylepixmaps_p.h"
