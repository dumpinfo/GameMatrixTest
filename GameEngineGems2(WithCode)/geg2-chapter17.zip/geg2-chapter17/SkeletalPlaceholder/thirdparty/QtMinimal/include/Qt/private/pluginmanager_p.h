#include "../../../tools/designer/src/lib/shared/pluginmanager_p.h"
