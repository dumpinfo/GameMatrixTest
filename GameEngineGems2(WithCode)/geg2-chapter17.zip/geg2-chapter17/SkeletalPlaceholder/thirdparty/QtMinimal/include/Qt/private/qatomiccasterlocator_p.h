#include "../../../src/xmlpatterns/type/qatomiccasterlocator_p.h"
