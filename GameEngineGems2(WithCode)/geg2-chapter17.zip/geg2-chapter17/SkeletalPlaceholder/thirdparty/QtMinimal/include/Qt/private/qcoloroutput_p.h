#include "../../../src/xmlpatterns/api/qcoloroutput_p.h"
