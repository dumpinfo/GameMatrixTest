#include "../../../src/xmlpatterns/type/qatomiccasterlocators_p.h"
