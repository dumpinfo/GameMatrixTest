#include "../../../src/xmlpatterns/type/qcommonsequencetypes_p.h"
