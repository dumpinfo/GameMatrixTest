#include "../../../src/xmlpatterns/expr/qcopyof_p.h"
