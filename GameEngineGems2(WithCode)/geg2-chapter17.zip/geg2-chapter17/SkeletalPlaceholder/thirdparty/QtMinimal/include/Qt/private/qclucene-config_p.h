#include "../../../tools/assistant/lib/fulltextsearch/qclucene-config_p.h"
