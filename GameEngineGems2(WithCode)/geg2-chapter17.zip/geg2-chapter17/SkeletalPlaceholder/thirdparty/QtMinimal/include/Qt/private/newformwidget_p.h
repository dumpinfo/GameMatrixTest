#include "../../../tools/designer/src/lib/shared/newformwidget_p.h"
