#include "../../../tools/designer/src/lib/shared/plugindialog_p.h"
