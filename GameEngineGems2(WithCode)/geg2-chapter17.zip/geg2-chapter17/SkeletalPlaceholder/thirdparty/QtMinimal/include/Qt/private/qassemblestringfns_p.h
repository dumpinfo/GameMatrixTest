#include "../../../src/xmlpatterns/functions/qassemblestringfns_p.h"
