#include "../../../src/xmlpatterns/functions/qaggregator_p.h"
