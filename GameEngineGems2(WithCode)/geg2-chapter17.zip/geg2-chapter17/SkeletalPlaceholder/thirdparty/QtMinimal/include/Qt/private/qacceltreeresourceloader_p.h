#include "../../../src/xmlpatterns/acceltree/qacceltreeresourceloader_p.h"
