#include "../../../src/xmlpatterns/expr/qcurrentitemstore_p.h"
