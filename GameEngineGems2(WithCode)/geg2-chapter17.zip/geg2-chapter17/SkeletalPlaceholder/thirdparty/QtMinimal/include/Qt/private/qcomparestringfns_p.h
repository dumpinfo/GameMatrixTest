#include "../../../src/xmlpatterns/functions/qcomparestringfns_p.h"
