#include "../../../src/xmlpatterns/data/qatomicstring_p.h"
