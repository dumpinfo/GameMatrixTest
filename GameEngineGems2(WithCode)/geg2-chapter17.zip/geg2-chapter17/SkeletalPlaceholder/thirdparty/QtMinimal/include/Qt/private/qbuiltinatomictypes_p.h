#include "../../../src/xmlpatterns/type/qbuiltinatomictypes_p.h"
