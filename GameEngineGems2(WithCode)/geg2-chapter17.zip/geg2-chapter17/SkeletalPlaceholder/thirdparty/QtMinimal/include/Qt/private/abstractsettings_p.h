#include "../../../tools/designer/src/lib/sdk/abstractsettings_p.h"
