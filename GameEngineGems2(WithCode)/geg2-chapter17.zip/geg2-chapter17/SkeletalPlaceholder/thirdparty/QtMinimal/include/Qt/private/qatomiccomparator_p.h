#include "../../../src/xmlpatterns/data/qatomiccomparator_p.h"
