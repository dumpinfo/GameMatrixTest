#include "../../../tools/designer/src/lib/shared/codedialog_p.h"
