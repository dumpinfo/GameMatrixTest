#include "../../../src/xmlpatterns/expr/qcastingplatform_p.h"
