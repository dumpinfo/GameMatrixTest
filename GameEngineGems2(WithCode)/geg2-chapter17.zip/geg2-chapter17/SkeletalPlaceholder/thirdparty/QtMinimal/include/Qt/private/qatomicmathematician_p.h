#include "../../../src/xmlpatterns/data/qatomicmathematician_p.h"
