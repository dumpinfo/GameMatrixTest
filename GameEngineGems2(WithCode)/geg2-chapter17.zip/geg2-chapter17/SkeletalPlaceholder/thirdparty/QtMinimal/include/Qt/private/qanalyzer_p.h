#include "../../../tools/assistant/lib/fulltextsearch/qanalyzer_p.h"
