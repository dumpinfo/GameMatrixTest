#include "../../../tools/assistant/lib/fulltextsearch/qclucene_global_p.h"
