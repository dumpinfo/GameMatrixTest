#ifndef SKINNINGMETHOD_H_
#define SKINNINGMETHOD_H_

class Animated;

class SkinningMethod
{
public :
    virtual void SetAnimated(Animated* aAnim){};
    virtual void PreRender() = 0;
    virtual void PostRender() = 0;
};

#endif //SKINNINGMETHOD_H_