#include "SkeletonReader.h"

SkeletonReader::SkeletonReader()
:   mpRootBone(NULL)
,   mpCurrentBone(NULL)
{}

bool SkeletonReader::startDocument()
{
    mpRootBone = NULL;
    mpCurrentBone = NULL;

    return true;
}

bool SkeletonReader::endDocument()
{
    mpRootBone->RefreshTransform();
    mpRootBone->GenerateBindPose();
    mpRootBone->RefreshTransform();

    return mpCurrentBone == NULL;
}

bool SkeletonReader::startElement(const QString& arNamespaceURI, 
                                  const QString& arLocalName, 
                                  const QString& arQualName, 
                                  const QXmlAttributes& arAttr)
{
    if(arLocalName == "bone")
    {
        if(mpCurrentBone != NULL)
        {
            mpCurrentBone = mpCurrentBone->AddChild(new Bone());
        }
        else
        {
            mpRootBone = new Bone();
            mpCurrentBone = mpRootBone;
        }

        for( int i = 0; i < arAttr.count(); ++i)
        {
            if(arAttr.localName(i) == "name")
            {
                mpCurrentBone->SetName(arAttr.value(i));
            }
            else if(arAttr.localName(i) == "offset")
            {
                mpCurrentBone->SetT(_ToCoord(arAttr.value(i)));
            }
            else if(arAttr.localName(i) == "weight")
            {
                mpCurrentBone->SetWeight(arAttr.value(i).toDouble());
            }
        }
    }

    return true;
}

bool SkeletonReader::endElement(const QString& arNamespaceURI, 
                                const QString& arLocalName, 
                                const QString& arQualName)
{
    if(arLocalName == "bone")
    {
        mpCurrentBone = mpCurrentBone->Parent();
    }

    return true;
}

QVector3D SkeletonReader::_ToCoord(const QString& aVal)
{
    QStringList Components = aVal.split(',',QString::SkipEmptyParts);

    return QVector3D(   Components[0].toDouble(),
                        Components[1].toDouble(),
                        Components[2].toDouble());
}

SkeletonReader::~SkeletonReader()
{}
