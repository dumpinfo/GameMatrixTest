#include "CRCString.h"

int CRC32String(const void* atpv_Hashee, unsigned int au32_Size, unsigned int au32_Seed /* = 65599 */)
{
	const unsigned char*	tc_Data		= (const unsigned char*)atpv_Hashee;
	unsigned int			u32_Hash	= au32_Seed;

	while(au32_Size > 0)
	{
		au32_Size--;
		u32_Hash = (u32_Hash << 16) + (u32_Hash << 6) - u32_Hash + (unsigned)tc_Data[au32_Size];
	}

	return u32_Hash;
}

int CRC32String(std::string ao_Text,unsigned int au32_Seed /*= 65599*/)
{
	return CRC32String(ao_Text.c_str(),ao_Text.size(),au32_Seed);
}


short CRC16String(const void *atpv_Hashee, unsigned int au32_Size, unsigned short au16_Seed /*= 5381*/)
{
	const unsigned char*	tc_Data		= (const unsigned char*)atpv_Hashee;
	unsigned short			u16_Hash	= au16_Seed;

	while(au32_Size > 0)
	{
		au32_Size--;
		u16_Hash = (u16_Hash << 8) + (u16_Hash << 3	) - u16_Hash + (unsigned)tc_Data[au32_Size];
	}

	return u16_Hash;
}

short CRC16String(std::string ao_Text, unsigned short au16_Seed /*= 5381*/)
{
	return CRC16String(ao_Text.c_str(),ao_Text.size(),au16_Seed);
}
