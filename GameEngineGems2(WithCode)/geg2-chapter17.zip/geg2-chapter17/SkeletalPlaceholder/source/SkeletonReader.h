#ifndef SKELETONREADER_H_
#define SKELETONREADER_H_

#include <QXmlDefaultHandler>
#include <QVector3D>

#include "Bone.h"

class SkeletonReader : public QXmlDefaultHandler
{
public:

    SkeletonReader();
    ~SkeletonReader();

    virtual bool startDocument();
    virtual bool endDocument();

    virtual bool startElement(
        const QString& arNamespaceURI, 
        const QString& arLocalName, 
        const QString& arQualName, 
        const QXmlAttributes& arAttr);

    virtual bool endElement(
        const QString& arNamespaceURI, 
        const QString& arLocalName, 
        const QString& arQualName);

    Bone* Skeleton() const;

protected:

    QVector3D _ToCoord(const QString& aVal);

    Bone* mpRootBone;
    Bone* mpCurrentBone;
};

inline Bone* SkeletonReader::Skeleton() const
{
    return mpRootBone;
}

#endif //SKELETONREADER_H_
