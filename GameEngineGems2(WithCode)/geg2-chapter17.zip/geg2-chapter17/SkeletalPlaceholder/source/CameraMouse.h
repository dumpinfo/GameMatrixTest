#ifndef CAMERA_MOUSE_H_
#define CAMERA_MOUSE_H_

#include <QMouseEvent>

#include "Camera.h"

class CameraMouse : public Camera
{
public:

	CameraMouse();
	virtual ~CameraMouse();

	virtual void Refresh(float DeltaT);


    void RefreshPosition(QMouseEvent* apEvent);
    void RefreshState(QMouseEvent* apEvent);

protected:

	float	mDistance;//Distance from the lookat target
	float	mTheta;	//Rotation on the y axis
	float	mPhi;		//Rotation on the z axis

	bool	mZoomActive;
	bool	mRotateActive;

    QPoint  mMouseCoord;
};

#endif //CAMERA_MOUSE_H_
