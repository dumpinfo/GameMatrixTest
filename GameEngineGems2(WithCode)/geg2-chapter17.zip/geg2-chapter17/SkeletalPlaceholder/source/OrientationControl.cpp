#include "OrientationControl.h"

#include <QBoxLayout>

#include "ResourceManager.h"

OrientationControl::OrientationControl(QWidget *apParent /*= NULL*/)
:   QWidget(apParent)
,   mpSlider(NULL)
,   mpResetButton(NULL)
{
    _InitUi();
}

void OrientationControl::_InitUi()
{
    QHBoxLayout* pLayout = new QHBoxLayout();
    setLayout(pLayout);

    //Slider creation
    mpSlider = new QSlider(Qt::Horizontal,this);
    mpSlider->setRange(-359,359);
    mpSlider->setValue(0);
    pLayout->addWidget(mpSlider);

    connect(
        mpSlider,
        SIGNAL(valueChanged(int)),
        this,
        SIGNAL(valueChanged(int)));

    //Reset button creation
    mpResetButton = new QPushButton(
        ResourceManager::Instance().Res<QIcon>("Resources/Icons/Icon_Reset.png"),
        "",
        this
        );
    pLayout->addWidget(mpResetButton);

    connect(
        mpResetButton,
        SIGNAL(clicked(bool)),
        this,
        SLOT(OnReset(bool)));
};
