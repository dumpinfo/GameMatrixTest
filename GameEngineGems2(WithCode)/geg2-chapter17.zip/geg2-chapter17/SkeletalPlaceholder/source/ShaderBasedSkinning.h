#ifndef SHADERBASEDSKIN_H_
#define SHADERBASEDSKIN_H_

#include <GL/glew.h>
#include <QGLShader>
#include <QGLShaderProgram>
#include <QObject>

#include "Animated.h"
#include "SkinningMethod.h"

class ShaderBasedSkinning : public QObject, public SkinningMethod
{
public:

    ShaderBasedSkinning();
    virtual ~ShaderBasedSkinning();

    void InitShaders(
        const QString& aVxShaderSourceFile,
        const QString& aFgShaderSourceFile);


    virtual void PreRender();
    virtual void PostRender();

protected:

    QGLShader* mpFragmentShader;
    QGLShader* mpVertexShader;

    QGLShaderProgram* mpShaderProgram;
};

#endif //SHADERBASEDSKIN_H_