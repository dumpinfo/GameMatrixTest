#ifndef GLVIEW_H_
#define GLVIEW_H_

#include <QGLWidget>

#include "CameraMouse.h"
#include "Bone.h"

class GLView : public QGLWidget
{
public:

    GLView(QWidget* apParent = NULL);
    ~GLView();

    virtual void initializeGL();
    virtual void resizeGL(int aW, int aH);
    virtual void paintGL();

    virtual void mouseMoveEvent(QMouseEvent* apEvent);
    virtual void mousePressEvent(QMouseEvent* apEvent);
    virtual void mouseReleaseEvent(QMouseEvent* apEvent);

    void AddRenderable(Renderable* aR);
    void RemoveRenderable(Renderable* aR);

protected:
    void _RenderAxisGuide();

    CameraMouse*    mpCam;

    QList<Renderable*> mRenderList;
};

inline void GLView::mouseMoveEvent(QMouseEvent* apEvent)
{
    mpCam->RefreshPosition(apEvent);
    apEvent->accept();
    updateGL();
}

inline void GLView::mousePressEvent(QMouseEvent* apEvent)
{
    mpCam->RefreshState(apEvent);
    apEvent->accept();
    updateGL();
}

inline void GLView::mouseReleaseEvent(QMouseEvent* apEvent)
{
    mpCam->RefreshState(apEvent);
    apEvent->accept();
    updateGL();
}

#endif //GLVIEW_H_
