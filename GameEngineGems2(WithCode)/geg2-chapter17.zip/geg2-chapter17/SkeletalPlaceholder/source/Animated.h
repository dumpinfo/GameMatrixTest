#ifndef ANIMATED_H_
#define ANIMATED_H_

#include <QList>
#include <QVector3D>
#include <QVector4D>

#include "Bone.h"
#include "DisplayDefs.h"
#include "GeometryUtils.h"
#include "Renderable.h"
#include "SkinningMethod.h"

class Animated : public Renderable
{
public:

    Animated();

    void SetSkinningMethod(SkinningMethod* const aMethod);
    const SkinningMethod& GetSkinningMethod() const;

    void SetGeometry(const QList<Tri>& aGeometry);
    QList<TriAnim>& Geometry();
   
    void SetSkeleton(Bone* aSkel);
    Bone& Skeleton();

    virtual void Render();
    virtual void RenderDebug();

protected:

    void _DoRender();

    //Utility methods
    void _GenerateSkinData();

    void _Skin(
        const QList<Bone*> Bones,
        const QVector3D& aPos, 
        QVector4D& aWeights, 
        BoneIndex& aIndex);

    Bone* _FindNearestBone(
        const QList<Bone*> aBones,
        const QVector3D& aPos);

    void _FindNearestBoneRecur(
        QMap<Bone*,double>& aResultMap,
        double aThreshold,
        const QVector3D& aPos,
        Bone* aStartingBone);

    Bone* _ClosestElligibleParent(
        double aThreshold,
        const QVector3D& aPos,
        Bone* aStartingBone);

    void _ReorderIndexAndWeight(
        BoneIndex& aIndex,
        QVector4D& aWeights);

    //Data members
    QList<TriAnim>  mGeometry;
    Bone*           mpSkeleton;

    SkinningMethod* mpSkinMethod;
};

inline void Animated::SetSkinningMethod(SkinningMethod *const aMethod)
{
    mpSkinMethod = aMethod;
    mpSkinMethod->SetAnimated(this);
}

inline const SkinningMethod& Animated::GetSkinningMethod() const
{
    return *mpSkinMethod;
}

inline QList<TriAnim>& Animated::Geometry()
{
    return mGeometry;
}

inline void Animated::SetSkeleton(Bone *aSkel)
{
    mpSkeleton = aSkel;
}

inline Bone& Animated::Skeleton()
{
    return *mpSkeleton;
}

#endif //ANIMATED_H_
