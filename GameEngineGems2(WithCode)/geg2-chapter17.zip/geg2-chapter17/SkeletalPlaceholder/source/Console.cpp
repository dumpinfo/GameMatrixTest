#include "Console.h"

Console::Console()
:   mpConsoleTerminal(NULL)
{}
