#ifndef LINEARBLENDSKINNING_H_
#define LINEARBLENDSKINNING_H_

#include "ShaderBasedSkinning.h"

class LinearBlendSkinning : public ShaderBasedSkinning
{
public:

    LinearBlendSkinning(QGLWidget* const aGLWidget);
    virtual ~LinearBlendSkinning();

    virtual void SetAnimated(Animated* const aAnim);
    virtual void PreRender();
    virtual void PostRender();

protected:

    void BindAttributes();
    void GenAndBindMatrixList();
    void InitLookup(QGLWidget* const aGLWidget, const QString& aLookupFileName);

    unsigned int mLookupId;
    Animated* mAnim;
};

inline void LinearBlendSkinning::SetAnimated(Animated* const aAnim)
{
    mAnim = aAnim;
}

#endif //LINEARBLENDSKINNING_H_
