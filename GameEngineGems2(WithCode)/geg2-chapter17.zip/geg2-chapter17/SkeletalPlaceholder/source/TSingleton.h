//!@file	TSingleton.h
//!@author	Olivier Vaillancourt
//!@date	07/04/2007 (dd/mm/yyyy)
//!@version	1.0
//!
//!@brief	File Containing the standard singleton definition
#ifndef T_SINGLETON_H_
#define T_SINGLETON_H_

//!@author	Olivier Vaillancourt
//!@date	07/04/2007 (dd/mm/yyyy)
//!@version	1.0
//!
//!@brief	Standard singleton definition
//!
//!			This class is a standard definition of the Singleton
//!			design pattern. Note that this is not a lazy initialization
//!			class which means the class instance won't be created
//!			when calling the accessors for the first time. It's instead
//!			initialized when calling the "Create" method. Please also
//!			note that the singleton being a static object will not
//!			be deleted implicitly on stack, it's therefore important
//!			to call explicitly the method "Destroy()" which will
//!			verify the existence of the instance in order to delete it
//!			and sets it to NULL.
//!
//!			In order to use this class it's important to define the 
//!			default constructor, copy constructor, = operator and the
//!			destructor in the class' private members. Don't forget to
//!			declare the templated singleton class as a friend of the
//!			desired class in order to allow access to the private
//!			constructor.
template< class _CLASS_>
class TSingleton
{
public:

	//!@brief Lazy creation method. Creates the instance and returns it.
	static _CLASS_* Create();

	//!@brief standard accessor to the static instance.
	static _CLASS_& Instance()
	{
		return *mpo_TheInstance;
	}

	//!@brief standard destructor
	static void	Destroy()
	{
		if(mpo_TheInstance)
		{
			delete mpo_TheInstance;
			mpo_TheInstance = NULL;
		}
	};

	static bool Exists()
	{
		return mpo_TheInstance != NULL;
	}

protected:

	TSingleton(){};

	TSingleton(const TSingleton&){};
	TSingleton& operator=(const TSingleton&){};

	virtual void Init(){};

	virtual ~TSingleton(){};

private:

	//!@brief The only instance of the _CLASS_
	static _CLASS_ *mpo_TheInstance;
};

template< class _CLASS_>
_CLASS_* TSingleton<_CLASS_>::Create()
{
	if(!mpo_TheInstance)
	{
		mpo_TheInstance = new _CLASS_;
	}

	mpo_TheInstance->Init();

	return mpo_TheInstance;
}

template< class _CLASS_>
_CLASS_* TSingleton<_CLASS_>::mpo_TheInstance = 0;

#endif T_SINGLETON_H_