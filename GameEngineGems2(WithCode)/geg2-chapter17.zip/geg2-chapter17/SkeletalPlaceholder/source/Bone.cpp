#include "Bone.h"

#include <cmath>
#include <qgl.h>

#include "MathUtils.h"

Bone::Bone(const QString& aName/* = */)
:   mpParent(NULL)
,   mName(aName)
,   mSelected(false)
,   mWeight(0.2)
,   mId(-1)
{
    EnableDebug(true);
    mR.fromAxisAndAngle(1,0,0,0);
}

Bone* Bone::AddChild(Bone* aChild)
{
    if(aChild->Parent() != NULL)
    {
        aChild->Parent()->RemoveChild(aChild);
    }

    mChildren.push_back(aChild);
    aChild->mpParent = this;

    aChild->RefreshTransform();

    return aChild;
}


Bone* Bone::RemoveChild(Bone* aChild)
{
    QList<Bone*>::iterator It;

    for(It = mChildren.begin(); It != mChildren.end(); ++It)
    {
        if(*(It) == aChild)
        {
            mChildren.erase(It);
            return aChild;
        }
    }
    return NULL;
}

QList<Bone*> Bone::AllBonesList()
{
    QList<Bone*> TmpList;

    TmpList.push_back(this);

    for(int i = 0; i < mChildren.size(); ++i)
    {
        TmpList.append(mChildren[i]->AllBonesList());
    }

    return TmpList;
}

QMatrix4x4 Bone::M()  const
{
    QMatrix4x4 RetMat;

    RetMat.rotate(mR);
    RetMat.translate(mT);

    return RetMat;
}

void Bone::GenerateBindPose()
{
    mBindT = SkelSpaceT();
    mBindR = SkelSpaceR();

    for(int i = 0; i < mChildren.size(); ++i)
    {
        mChildren[i]->GenerateBindPose();
    }
}

QQuaternion Bone::SkelSpaceR() const
{
    return mSkelSpaceR;
}

QVector3D Bone::SkelSpaceT() const
{
    return mSkelSpaceT;
}

QMatrix4x4 Bone::SkelSpaceM() const
{
    QMatrix4x4 RetMat;

    RetMat.translate(mSkelSpaceT);
    RetMat.rotate(mSkelSpaceR);

    return RetMat;
}

void Bone::RefreshTransform()
{
    if(mpParent != NULL)
    {
        mSkelSpaceR = mpParent->SkelSpaceR() * R();
        mSkelSpaceT = mpParent->SkelSpaceR().rotatedVector(T()) + 
                      mpParent->SkelSpaceT();
    }
    else
    {
        mSkelSpaceR = R();
        mSkelSpaceT = T();
    }

    QMatrix4x4 Tmp;
    Tmp.translate(-BindPoseT());

    mCT = (SkelSpaceM() * Tmp).column(3).toVector3D();

    for( int i = 0; i < mChildren.size(); ++i)
    {
        mChildren[i]->RefreshTransform();
    }
}

void Bone::RenderDebug()
{
    glMatrixMode(GL_MODELVIEW);

    glPushAttrib(GL_LINE_BIT);
    glPushAttrib(GL_POLYGON_BIT);
    glPushAttrib(GL_LIGHTING_BIT);

    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
    glDisable(GL_LIGHTING);

    if(Selected())
    {
        glLineWidth(3.0f);
    }
    else
    {
        glLineWidth(2.0f);
    }
        
    //Render Joint
    glPushMatrix();
    glMultMatrixd(SkelSpaceM().data());
    _DrawJoint(0.3,20);    
    glPopMatrix();

    //Render segment
    glPushMatrix();
    if(Parent() != NULL)
    {
        QMatrix4x4 Tmp = GenerateBasis( Parent()->SkelSpaceR().rotatedVector(T()),
                                        SkelSpaceM().column(1).toVector3D(),
                                        SkelSpaceM().column(2).toVector3D());

        Tmp.setColumn(3,QVector4D(Parent()->SkelSpaceT(),1));

        glMultMatrixd(Tmp.data());
        _DrawSegment(0.2,4);
    }
    glPopMatrix();

    glPopAttrib();
    glPopAttrib();
    glPopAttrib();

    for(int i = 0; i < mChildren.size(); ++i)
    {
        mChildren[i]->RenderDebug();
    }
}

double Bone::Evaluate(const QVector3D& aPos)
{
    double RetVal = 0.0;

    if(Parent() != NULL)
    {
        RetVal += _EvalBone(aPos);
    }

    for(int i = 0; i < mChildren.size(); ++i)
    {
        RetVal += mChildren[i]->Evaluate(aPos);
    }

    return RetVal;
}

QVector3D Bone::EvaluateNormal(const QVector3D& aPos)
{
    return _DoEvalNormal(aPos).normalized();
}

void Bone::_DrawJoint(float aRadius, int aPrecision)
{
    if(!Selected())
    {
        glColor3f(0.5,0.5,0.5);
    }
    else
    {
        glColor3f(0,1,1);
    }


    //Draw the bone's origin
    glBegin(GL_LINE_LOOP);
    for( int i = 0; i < aPrecision; ++i)
    {
        glVertex3f( aRadius * cos(i/(float)aPrecision * 2 * PI),
                    0,
                    aRadius * sin(i/(float)aPrecision * 2 * PI));
    }
    glEnd();

    glBegin(GL_LINE_LOOP);
    for( int i = 0; i < aPrecision; ++i)
    {
        glVertex3f( 0,
                    aRadius * cos(i/(float)aPrecision * 2 * PI),
                    aRadius * sin(i/(float)aPrecision * 2 * PI));
    }
    glEnd();


    glBegin(GL_LINE_LOOP);
    for( int i = 0; i < aPrecision; ++i)
    {
        glVertex3f( aRadius * cos(i/(float)aPrecision * 2 * PI),
                    aRadius * sin(i/(float)aPrecision * 2 * PI),
                    0);
    }
    glEnd();
}

void Bone::_DrawSegment(float aRadius, int aPrecision)
{
    if(!Selected())
    {
        glColor3f(1,0,0);
    }
    else
    {
        glColor3f(0,1,0);
    }

    glBegin(GL_LINE_LOOP);
    for( int i = 0; i < aPrecision; ++i)
    {
        glVertex3f( 0,
                    aRadius * cos(i/(float)aPrecision * 2 * PI),
                    aRadius * sin(i/(float)aPrecision * 2 * PI));
    }
    glEnd();
    

    glBegin(GL_LINES);
    for( int i = 0; i < aPrecision; ++i)
    {
        glVertex3f( 0,
                    aRadius * cos(i/(float)aPrecision * 2 * PI),
                    aRadius * sin(i/(float)aPrecision * 2 * PI));

        glVertex3f(mT.length(),0,0);
    }
    glEnd();    
}

void Bone::_GenId(int &aId)
{
    mId = aId++;

    for(int i = 0; i < mChildren.size(); ++i)
    {
        mChildren[i]->_GenId(aId);
    }
}

double Bone::_EvalBone(const QVector3D& aPos)
{
    if(Parent() != NULL)
    {
        double DistSq = DistToSegmentSquared(Segment(),aPos);

        if(DistSq > 0.0)
        {
            return 1.0/DistSq * mWeight;
        }
        else
        {
            return 99999999999999;
        }
        
    }

    return 0.0;
}

QVector3D Bone::_DoEvalNormal(const QVector3D& aPos)
{
    QVector3D RetVal(0,0,0);

    if(Parent() != NULL)
    {
        RetVal += SegmentNormal(Segment(),aPos) * _EvalBone(aPos);
    }

    for(int i = 0; i < mChildren.size(); ++i)
    {
        RetVal += mChildren[i]->_DoEvalNormal(aPos);
    }

    return RetVal;
}

Bone::~Bone()
{
    for(int i = 0; i < mChildren.size(); ++i)
    {
        delete mChildren[i];
        mChildren[i] = NULL;
    }
}
