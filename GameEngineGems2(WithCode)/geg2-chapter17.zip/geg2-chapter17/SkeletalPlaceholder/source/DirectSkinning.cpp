#include "DirectSkinning.h"

#include <QSettings>
#include <QVarLengthArray>

DirectSkinning::DirectSkinning(QGLWidget* const aGLWidget)
:   ShaderBasedSkinning()
,   mAnim(NULL)
,   mLookupId(-1)
{
    QSettings settings("resources/Settings.ini",QSettings::IniFormat);
    settings.setPath(QSettings::IniFormat,QSettings::UserScope,"./resources");
    settings.sync();

    InitShaders(
        settings.value("DirectSkinningVxShader").toString(),
        settings.value("DirectSkinningPxShader").toString());

    BindAttributes();

    InitLookup(
        aGLWidget,
         settings.value("BarlaLookup").toString());
}

DirectSkinning::~DirectSkinning()
{
    glDeleteTextures(1,&mLookupId);
}

void DirectSkinning::PreRender()
{
    glBindTexture(GL_TEXTURE_2D,mLookupId);
    ShaderBasedSkinning::PreRender();
    mpShaderProgram->setUniformValue("LookupSampler",0);
    GenAndBindMatrixList();
}

void DirectSkinning::PostRender()
{
    ShaderBasedSkinning::PostRender();
    glBindTexture(GL_TEXTURE_2D,0);
}

void DirectSkinning::BindAttributes()
{

    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Vertex,"aVertex");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Normal,"aNormal");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Weight,"aWeight");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_BoneId,"aBoneId");
    mpShaderProgram->link();

    //int VertexLocation = mpShaderProgram->attributeLocation("aVertex");
    //int NormalLocation = mpShaderProgram->attributeLocation("aNormal");
    //int WeightLocation = mpShaderProgram->attributeLocation("aWeight");
    //int BoneIdLocation = mpShaderProgram->attributeLocation("aBoneId");
}

void DirectSkinning::GenAndBindMatrixList()
{
    QList<Bone*> TmpList = mAnim->Skeleton().AllBonesList();

    Q_ASSERT_X(
        TmpList.size() <= MAX_BONE_COUNT,
        "DirectSkinning::GenAndBindMatrixList()",
        "Too many bones, shader supports up to MAX_BONE_COUNT bones.");

    QVarLengthArray<QMatrix4x4,MAX_BONE_COUNT> TmpArray(TmpList.size());

    for(int i = 0; i < TmpList.size(); ++i)
    {
        QMatrix4x4 P = TmpList[i]->SkelSpaceM();
        QMatrix4x4 Bminus1;
        Bminus1.setToIdentity();
        Bminus1.setColumn(3,QVector4D(-TmpList[i]->BindPoseT(),1));

        TmpArray[i] = P * Bminus1;
    }

    mpShaderProgram->setUniformValueArray(
        "BonesMatrices",
        TmpArray.data(),
        MAX_BONE_COUNT);
}

void DirectSkinning::InitLookup(QGLWidget* const aGLWidget, 
                                const QString& aLookupFileName)
{
    mLookupId = aGLWidget->bindTexture(
        QImage(aLookupFileName),
        GL_TEXTURE_2D,
        GL_RGBA);

    glBindTexture(GL_TEXTURE_2D,mLookupId);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);

    glBindTexture(GL_TEXTURE_2D,0);
}

