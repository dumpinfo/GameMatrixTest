#include "ImplicitSurface.h"

#include <cmath>
#include <qgl.h>
#include <QString>


#include "Console.h"
#include "glext.h"
#include "MathUtils.h"

ImplicitSurface::ImplicitSurface(const QVector3D& arAABBMin, 
                                 const QVector3D& arAABBMax)                               
:   mAABBMin(arAABBMin)
,   mAABBMax(arAABBMax)
,   mThreshold(1)
,   mSubDivCount(80) //80
,   mpField(NULL)
,   mRefined()
{
    SetVisible(false);
    EnableDebug(false);
};

ImplicitSurface::~ImplicitSurface()
{}

void ImplicitSurface::Render()
{
    if(!mTriangles.empty())
    {
        glPushAttrib(GL_POLYGON_BIT);
        glPushAttrib(GL_LIGHTING_BIT);

        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        glDisable(GL_LIGHTING);
        glBegin(GL_TRIANGLES);

        glColor3f(0.5,0.5,0.5);

        Tri Tmp;
        for(int i = 0;i < mTriangles.size(); ++i)
        {
            Tmp = mTriangles[i];
            glNormal3f(Tmp.N1.x(),Tmp.N1.y(),Tmp.N1.z());
            glVertex3f(Tmp.Pt1.x(),Tmp.Pt1.y(),Tmp.Pt1.z());
            glNormal3f(Tmp.N2.x(),Tmp.N2.y(),Tmp.N2.z());
            glVertex3f(Tmp.Pt2.x(),Tmp.Pt2.y(),Tmp.Pt2.z());
            glNormal3f(Tmp.N3.x(),Tmp.N3.y(),Tmp.N3.z());
            glVertex3f(Tmp.Pt3.x(),Tmp.Pt3.y(),Tmp.Pt3.z());
        }

        glEnd();
        glPopAttrib();
        glPopAttrib();
    }
}

void ImplicitSurface::RenderDebug()
{
    if(mpField != NULL && !mGrid.empty())
    {
        glPointSize(2);
       
        for(int z = 0; z < mSubDivCount; ++z)
        {
            for(int y = 0; y < mSubDivCount; ++y)
            {   
                for( int x = 0; x < mSubDivCount; ++x)        
                {
                    GridEntry& GE = V(x,y,z);

                    if(GE.Val >= mThreshold)
                    {
                        QVector3D Normal = mpField->EvaluateNormal(GE.Pos) * 0.5;
                        Normal += GE.Pos;

                        glColor3f(1,0,0);
                        glBegin(GL_LINES);
                        glVertex3f(GE.Pos.x(),GE.Pos.y(),GE.Pos.z());
                        glVertex3f(Normal.x(),Normal.y(),Normal.z());
                        glEnd();

                        glColor3f(0,0,1);
                        glBegin(GL_POINTS);
                        glVertex3f(GE.Pos.x(),GE.Pos.y(),GE.Pos.z());
                        glEnd();
                    }
                    else
                    {
                        glColor3f(0.9,0.9,0.9);
                    }

                }
            }
        }
    }
}

QList<Tri> ImplicitSurface::GetGeometry(bool aRefine /*= true*/)
{
    mTriangles.clear();
    mGrid.clear();

    _GenerateGrid();
    _GenerateShape();
    if(aRefine)
    {
        _RefineShape();
    }
    _GenerateNormals();

    return mTriangles.toList();
}

void ImplicitSurface::FreeMemory()
{
    mTriangles.clear();
    mGrid.clear();
}

void ImplicitSurface::_GenerateGrid()
{
    if(mpField != NULL)
    {
        mGrid.clear();
        mGrid.resize(mSubDivCount * mSubDivCount * mSubDivCount);

        QVector3D Step3D = (mAABBMax  - mAABBMin) / mSubDivCount;

        for( int z = 0; z < mSubDivCount; ++z)
        {
            for(int y = 0; y < mSubDivCount; ++y)
            {   
                for(int x = 0; x < mSubDivCount; ++x)
                {
                    QVector3D CurPos = mAABBMin + QVector3D(x,y,z) * Step3D;
                    V(x,y,z).Val = mpField->Evaluate(CurPos);
                    V(x,y,z).Pos = CurPos;
                }
            }
        }
    }
}

void ImplicitSurface::_GenerateShape()
{
    mTriangles.clear();

    if(mpField != NULL)
    {
        for(int z = 0; z < mSubDivCount-1; ++z)
        {
            for(int y = 0; y < mSubDivCount-1; ++y)
            {   
                for( int x = 0; x < mSubDivCount-1; ++x)        
                {
                    const GridEntry Pt0 = V(x,y,z);
                    const GridEntry Pt1 = V(x+1,y,z);
                    const GridEntry Pt2 = V(x+1,y,z+1);
                    const GridEntry Pt3 = V(x,y,z+1);
                    const GridEntry Pt4 = V(x,y+1,z);
                    const GridEntry Pt5 = V(x+1,y+1,z);
                    const GridEntry Pt6 = V(x+1,y+1,z+1);
                    const GridEntry Pt7 = V(x,y+1,z+1);

                    _SingleTetraHedron(Pt2,Pt7,Pt3,Pt1);
                    _SingleTetraHedron(Pt0,Pt7,Pt1,Pt3);
                    _SingleTetraHedron(Pt6,Pt1,Pt7,Pt2);
                    _SingleTetraHedron(Pt0,Pt1,Pt7,Pt4);
                    _SingleTetraHedron(Pt1,Pt4,Pt5,Pt7);
                    _SingleTetraHedron(Pt1,Pt7,Pt5,Pt6);
                }
            }
        }
    }
}

void ImplicitSurface::_RefineShape()
{
    Tri Tmp;
    for(int i = 0; i < mTriangles.size(); ++i)
    {
        Tmp = mTriangles[i];

        mTriangles[i].Pt1 = _RefinePoint(Tmp.Pt1,0.001);
        mTriangles[i].Pt2 = _RefinePoint(Tmp.Pt2,0.001);
        mTriangles[i].Pt3 = _RefinePoint(Tmp.Pt3,0.001);
    }
}

void ImplicitSurface::_GenerateNormals()
{
    if(mpField != NULL)
    {
        for(int i = 0; i < mTriangles.size(); ++i)
        {
            mTriangles[i].N1 = mpField->EvaluateNormal(mTriangles[i].Pt1);
            mTriangles[i].N2 = mpField->EvaluateNormal(mTriangles[i].Pt2);
            mTriangles[i].N3 = mpField->EvaluateNormal(mTriangles[i].Pt3);
        }
    }

}

QVector3D ImplicitSurface::_RefinePoint(const QVector3D& aPos, double aPrecision)
{
    bool        Flip = false;

    QVector3D   Pos = aPos;
    QVector3D   Norm = mpField->EvaluateNormal(aPos);

    double      Val = mpField->Evaluate(aPos);
    double      Step = 0.01;

    while(fabs(Val-Threshold()) > aPrecision)
    {
        double      TmpVal;
        QVector3D   TmpPos = Pos;

        if(Flip)
        {
            TmpPos += Norm * Step;
            TmpVal = mpField->Evaluate(TmpPos);
        }
        else
        {
            TmpPos -= Norm * Step;
            TmpVal = mpField->Evaluate(TmpPos);
        }

        if(fabs(TmpVal - Threshold()) >= fabs(Val - Threshold()))
        {
            Flip = !Flip;
            Step /= 2;
            Norm = mpField->EvaluateNormal(Pos);
        }
        else
        {
            Val = TmpVal;
            Pos = TmpPos;
        }
    }

    return Pos;
}

void ImplicitSurface::_SingleTetraHedron(const GridEntry& arGe0, 
                                         const GridEntry& arGe1, 
                                         const GridEntry& arGe2, 
                                         const GridEntry& arGe3)
{
    //We generate the mask
    int Mask = 0;

    if(arGe0.Val > Threshold()){Mask |= 1;}
    if(arGe1.Val > Threshold()){Mask |= 2;}
    if(arGe2.Val > Threshold()){Mask |= 4;}
    if(arGe3.Val > Threshold()){Mask |= 8;}

    //Depending on the result of the mask, we render the correct
    //triangle(s).
    switch(Mask)
    {
    case 0x00: //Completely outside/inside means that
    case 0x0F: //we're not on the edge and no triangle
        return;//should be generated.
    case 0x0E:
    case 0x01:
        _Tri(_Interp(arGe0,arGe1),_Interp(arGe0,arGe2),_Interp(arGe0,arGe3));
        return;
    case 0x0D:
    case 0x02:
        _Tri(_Interp(arGe1,arGe0),_Interp(arGe1,arGe3),_Interp(arGe1,arGe2));
        return;
    case 0x0C:
    case 0x03:
        _Tri(_Interp(arGe0,arGe3),_Interp(arGe0,arGe2),_Interp(arGe1,arGe3));
        _Tri(_Interp(arGe1,arGe3),_Interp(arGe1,arGe2),_Interp(arGe0,arGe2));
        return;
    case 0x0B:
    case 0x04:
        _Tri(_Interp(arGe2,arGe0),_Interp(arGe2,arGe1),_Interp(arGe2,arGe3));
        return;
    case 0x0A:
    case 0x05:
        _Tri(_Interp(arGe0,arGe1),_Interp(arGe2,arGe3),_Interp(arGe0,arGe3));
        _Tri(_Interp(arGe0,arGe1),_Interp(arGe1,arGe2),_Interp(arGe2,arGe3));
        return;
    case 0x09:
    case 0x06:
        _Tri(_Interp(arGe0,arGe1),_Interp(arGe1,arGe3),_Interp(arGe2,arGe3));
        _Tri(_Interp(arGe0,arGe1),_Interp(arGe0,arGe2),_Interp(arGe2,arGe3));
        return;
    case 0x07:
    case 0x08:
        _Tri(_Interp(arGe3,arGe0),_Interp(arGe3,arGe2),_Interp(arGe3,arGe1));
        return;
    default:
        break;
    }
}

QVector3D  ImplicitSurface::_Interp(const GridEntry& arGe0, 
                                    const GridEntry& arGe1)
{
    GridEntry Min;
    GridEntry Max;
    
    if(arGe0.Val < arGe1.Val)
    {
        Min = arGe0;
        Max = arGe1;
    }
    else
    {   
        Min = arGe1;
        Max = arGe0;
    }

    double Progress = (Threshold() - Min.Val)/(Max.Val-Min.Val);

    return (Progress * Max.Pos) + ((1-Progress) * Min.Pos);
}
