//!@file	CRCString.h
//!@author	Olivier Vaillancourt
//!@date	18/05/2007
//!@brief	File Containing hashing algorithms.
#ifndef CRCSTRING_H_
#define CRCSTRING_H_
#pragma once

#include <string>
#include <map>

//!@brief		Generates an int based on the entry data.
//!@param[in]	atpv_Hashee		Array of data.	
//!@param[in]	au32_Size		Size of the atpv_Hashee pointer. (In Bytes)
//!@param[in]	au32_Seed		Seed of the hashing algorithm. Keeping the default seed is suggested.
//!@return		Long integer corresponding to the hashing of atpv_Hashee.
int			CRC32String(const void* atpv_Hashee, unsigned int au32_Size, unsigned int au32_Seed = 65599);

//!@brief		Generates an int based on the entry string. Simply calls the other version of CRC32String.
//!				It was made available since text string are the most usual form of hashee data.
//!@param[in]	ao_Text		String that will be hashed.
//!@param[in]	au32_Seed	Seed of the hashing algorithm. Keeping the default seed is suggested.
//!@return		Long integer corresponding to the hashing of ao_Text
int			CRC32String(std::string ao_Text, unsigned int au32_Seed = 65599);

template<class _T1_,class _T2_>
int CRC32String(std::map<_T1_,_T2_> &atT_Data,int au32_Seed = 65539)
{
	int s32_Hash = au32_Seed;
	for(std::map<_T1_,_T2_>::iterator o_it = atT_Data.begin(); o_it != atT_Data.end(); o_it++)
	{
		s32_Hash = CRC32String(&o_it->first,sizeof(_T1_),s32_Hash);
		s32_Hash = CRC32String(&o_it->second,sizeof(_T2_),s32_Hash);
	}

	return s32_Hash;
}

//!@brief		Generates a short in based on the entry data. Same as CRC32String but generates a 16 bits int.
//!@see			CRC32String
short		CRC16String(const void* aptv_Hashee, unsigned int au32_Size, unsigned shortau16_Seed = 5381);

//!@brief		Generates a short in based on the entry string. Same as CRC32String but generates a 16 bits int.
//!@see			CRC32String
short		CRC16String(std::string ao_Text, unsigned short au16_Seed = 5381);




#endif //CRCSTRING_H_