#include "Animated.h"

#include <GL/glew.h>
#include <QtAlgorithms>

#include "Console.h"
#include "MathUtils.h"

Animated::Animated()
:   mpSkeleton(NULL)
,   mpSkinMethod(NULL)
{
    SetVisible(false);
    EnableDebug(true);
}

void Animated::SetGeometry(const QList<Tri> &aGeometry)
{
    mGeometry.clear();

    for(int i = 0; i < aGeometry.size(); ++i)
    {
        mGeometry.push_back(TriAnim(aGeometry[i]));
    }

    _GenerateSkinData();
}

void Animated::Render()
{
    if(mpSkinMethod != NULL){mpSkinMethod->PreRender();}

    glVertexAttrib4f( Attrib_Color, 0,0,0,1);
    glPushAttrib(GL_POLYGON_BIT);
    glPushAttrib(GL_LINE_BIT);
    glPushAttrib(GL_DEPTH_BUFFER_BIT);

    glDepthMask(GL_FALSE);

    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
    glLineWidth(5);
    _DoRender();

    glPopAttrib();
    glPopAttrib();
    glPopAttrib();
    

    glVertexAttrib4f( Attrib_Color, 1,1,1,1);
    //glEnable(GL_POLYGON_OFFSET_FILL);
    //glPolygonOffset( -4,-4 );
    _DoRender();
    //glDisable(GL_POLYGON_OFFSET_FILL);
  

    if(mpSkinMethod != NULL){mpSkinMethod->PostRender();}
}

void Animated::RenderDebug()
{
    glPushAttrib(GL_POLYGON_BIT);
    glPushAttrib(GL_LIGHTING_BIT);

    glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
    glDisable(GL_LIGHTING);

    if(mpSkinMethod != NULL){mpSkinMethod->PreRender();}

    glVertexAttrib4f( Attrib_Color, 1,1,1,1);

    _DoRender();

    if(mpSkinMethod != NULL){mpSkinMethod->PostRender();}

    glPopAttrib();
    glPopAttrib();
}

void Animated::_DoRender()
{
    /*glColor3f(0.5,0.5,0.5);*/

    glBegin(GL_TRIANGLES);

    TriAnim Tmp;
    for(int i = 0;i < mGeometry.size(); ++i)
    {
        Tmp = mGeometry[i];

        glVertexAttrib3f(
            Attrib_Normal,Tmp.N1.x(),Tmp.N1.y(),Tmp.N1.z());
        glVertexAttrib4f(
            Attrib_Weight,Tmp.Pt1W.x(),Tmp.Pt1W.y(),Tmp.Pt1W.z(), Tmp.Pt1W.w());
        glVertexAttrib4f(
            Attrib_BoneId,Tmp.B1.Idx1,Tmp.B1.Idx2,Tmp.B1.Idx3,Tmp.B1.Idx4);
        glVertexAttrib4f(
            Attrib_Vertex,Tmp.Pt1.x(),Tmp.Pt1.y(),Tmp.Pt1.z(),Tmp.RC1);

        glVertexAttrib3f(
            Attrib_Normal,Tmp.N2.x(),Tmp.N2.y(),Tmp.N2.z());
        glVertexAttrib4f(
            Attrib_Weight,Tmp.Pt2W.x(),Tmp.Pt2W.y(),Tmp.Pt2W.z(), Tmp.Pt2W.w());
        glVertexAttrib4f(
            Attrib_BoneId,Tmp.B2.Idx1,Tmp.B2.Idx2,Tmp.B2.Idx3,Tmp.B2.Idx4);
        glVertexAttrib4f(
            Attrib_Vertex,Tmp.Pt2.x(),Tmp.Pt2.y(),Tmp.Pt2.z(),Tmp.RC2);

        glVertexAttrib3f(
            Attrib_Normal,Tmp.N3.x(),Tmp.N3.y(),Tmp.N3.z());
        glVertexAttrib4f(
            Attrib_Weight,Tmp.Pt3W.x(),Tmp.Pt3W.y(),Tmp.Pt3W.z(), Tmp.Pt3W.w());
        glVertexAttrib4f(
            Attrib_BoneId,Tmp.B3.Idx1,Tmp.B3.Idx2,Tmp.B3.Idx3,Tmp.B3.Idx4);
        glVertexAttrib4f(
            Attrib_Vertex,Tmp.Pt3.x(),Tmp.Pt3.y(),Tmp.Pt3.z(),Tmp.RC3);
    }

    glEnd();
}

void Animated::_GenerateSkinData()
{

    if(mpSkeleton != NULL)
    {
        mpSkeleton->GenId();
        QList<Bone*> BoneList = mpSkeleton->AllBonesList();

        for(int i = 0; i < mGeometry.size(); ++i)
        {

            TriAnim& Tmp = mGeometry[i];
            _Skin(
                BoneList, 
                Tmp.Pt1,
                Tmp.Pt1W,
                Tmp.B1);
            _ReorderIndexAndWeight(Tmp.B1,Tmp.Pt1W);

            _Skin(
                BoneList, 
                Tmp.Pt2,
                Tmp.Pt2W,
                Tmp.B2);
            _ReorderIndexAndWeight(Tmp.B2,Tmp.Pt2W);

            _Skin(
                BoneList, 
                Tmp.Pt3,
                Tmp.Pt3W,
                Tmp.B3);
            _ReorderIndexAndWeight(Tmp.B3,Tmp.Pt3W);
        }
    }
}

void Animated::_Skin(const QList<Bone*> aBones,
                            const QVector3D& aPos, 
                            QVector4D& aWeights, 
                            BoneIndex& aIndex)
{
    //The process might appear to differ a bit from what is written in the chapter
    //but it remains 100% equivalent. The only difference here is that instead
    //of starting from the nearest bone and propagating through parents/children,
    //we simply find the highest parent below threshold and propagate through the
    //lowest possible childrens below that same threshold. (It's like doing the
    //propagation in two times : Parent first, children after)

    double Threshold = 1;

    Bone* NearestBone    = _FindNearestBone(aBones,aPos);

    if(NearestBone->Weight() >= Threshold)
    {
        Threshold += NearestBone->Weight();
    }

    Bone* StartingParent = _ClosestElligibleParent( Threshold,
                                                    aPos,
                                                    NearestBone);

    QMap<Bone*,double> Results ;
    QMap<double,Bone*> ResultsSorted;
        
    _FindNearestBoneRecur(Results, Threshold, aPos, StartingParent);

    if(!Results.empty())
    {
        for(QMap<Bone*,double>::iterator It = Results.begin();
            It != Results.end();
            ++It)
        {
            ResultsSorted.insertMulti(It.value(),It.key());
        }

        aIndex = BoneIndex(0,0,0,0);
        aWeights = QVector4D(0,0,0,0);

        QMap<double,Bone*>::Iterator It = ResultsSorted.begin();

        if(ResultsSorted.size() == 1)
        {
            aIndex.Idx1 = It.value()->Id();
            aWeights.setX(It.key());
        }
        else if(ResultsSorted.size() == 2)
        {
            aIndex.Idx1 = It.value()->Id();
            aWeights.setX(It.key()); 
            It++;
            aIndex.Idx2 = It.value()->Id();
            aWeights.setY(It.key());
        }
        else if(ResultsSorted.size() == 3)
        {
            aIndex.Idx1 = It.value()->Id();
            aWeights.setX(It.key());
            It++;
            aIndex.Idx2 = It.value()->Id();
            aWeights.setY(It.key());
            It++;
            aIndex.Idx3 = It.value()->Id();
            aWeights.setZ(It.key());
        }
        else if(ResultsSorted.size() >= 4)
        {
            aIndex.Idx1 = It.value()->Id();
            aWeights.setX(It.key());
            It++;
            aIndex.Idx2 = It.value()->Id();
            aWeights.setY(It.key());
            It++;
            aIndex.Idx3 = It.value()->Id();
            aWeights.setZ(It.key());
            It++;
            aIndex.Idx4 = It.value()->Id();
            aWeights.setW(It.key());
        }

        aWeights *= aWeights * aWeights * aWeights;

        double Sum = aWeights.x() + aWeights.y() + aWeights.z() + aWeights.w();
        aWeights /= Sum;
    }
    else
    {
        aIndex = BoneIndex(NearestBone->Id(),0,0,0);
        aWeights = QVector4D(1,0,0,0);
    }
}

Bone* Animated::_FindNearestBone(const QList<Bone*> aBones,
                                 const QVector3D &aPos)
{
    Bone* RetBone = NULL;
    int TmpBoneIndex = -1;
    double MinDist = 999999999999.0;

    for(int i = 0; i < aBones.size(); ++i)
    {
        if(aBones[i]->Parent() != NULL)
        {
            QPair<QVector3D,QVector3D> TmpSegment = aBones[i]->Segment();

            double TmpDist = DistToSegment(TmpSegment,aPos);

            if(TmpDist  < MinDist)
            {
                RetBone = aBones[i]->Parent();
                MinDist = TmpDist;
                TmpBoneIndex = i;
            }
        }
    }

    return RetBone;
}

void Animated::_FindNearestBoneRecur(QMap<Bone*,double>& aResultMap,
                                                   double aThreshold, 
                                                   const QVector3D& aPos, 
                                                   Bone* aStartingBone)
{
    for(int i = 0; i < aStartingBone->ChildCount(); ++i)
    {
        Bone* Child = aStartingBone->Child(i);

        QPair<QVector3D,QVector3D> Seg = Child->Segment();

        double TmpDist = DistToSegment(Seg,aPos);

        if(TmpDist < aThreshold)
        {
            if(aResultMap.contains(aStartingBone))
            {
                if(aResultMap[aStartingBone] < 1.0/TmpDist)
                {
                    aResultMap[aStartingBone] = 1.0/TmpDist;    
                }                
            }
            else
            {
                aResultMap[aStartingBone] = 1.0/TmpDist;
            }

            _FindNearestBoneRecur(aResultMap,aThreshold,aPos,Child);
        }
    }
}

Bone* Animated::_ClosestElligibleParent(double aThreshold,
                                        const QVector3D& aPos, 
                                        Bone* aStartingBone)
{
    if(aStartingBone->Parent() == NULL)
    {
        return aStartingBone;
    }
    else
    {
        double Dist = DistToSegment(aStartingBone->Segment(),aPos);
        if(Dist < aThreshold)
        {
            return _ClosestElligibleParent(
                aThreshold, 
                aPos, 
                aStartingBone->Parent());
        }
        else
        {
            return aStartingBone;
        }
    }
}

void Animated::_ReorderIndexAndWeight(BoneIndex &aIndex, 
                                      QVector4D &aWeights)
{
    QMap<unsigned char, double> TmpMap;
    int NbW = 0;

    if(aWeights.x() > 0.0){TmpMap[aIndex.Idx1] = aWeights.x();NbW++;}
    if(aWeights.y() > 0.0){TmpMap[aIndex.Idx2] = aWeights.y();NbW++;}
    if(aWeights.z() > 0.0){TmpMap[aIndex.Idx3] = aWeights.z();NbW++;}
    if(aWeights.w() > 0.0){TmpMap[aIndex.Idx4] = aWeights.w();NbW++;}

    QMap<unsigned char, double>::iterator It = TmpMap.begin();
    switch(NbW)
    {
    case 1:
        aIndex.Idx1 = It.key(); aWeights.setX(It.value());It++;
        break;
    case 2:
        aIndex.Idx1 = It.key(); aWeights.setX(It.value());It++;
        aIndex.Idx2 = It.key(); aWeights.setY(It.value());
        break;
    case 3:
        aIndex.Idx1 = It.key(); aWeights.setX(It.value());It++;
        aIndex.Idx2 = It.key(); aWeights.setY(It.value());It++;
        aIndex.Idx3 = It.key(); aWeights.setZ(It.value());
        break;
    case 4:
        aIndex.Idx1 = It.key(); aWeights.setX(It.value());It++;
        aIndex.Idx2 = It.key(); aWeights.setY(It.value());It++;
        aIndex.Idx3 = It.key(); aWeights.setZ(It.value());It++;
        aIndex.Idx4 = It.key(); aWeights.setW(It.value());
        break;
    }
}
