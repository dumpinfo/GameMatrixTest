#include "SphericalBlendSkinning.h"

#include <QSettings>
#include <QVarLengthArray>
#include <cmath>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>

#include "CRCString.h"
#include "DisplayDefs.h"

#define EPS 0.0000000001

SphericalBlendSkinning::SphericalBlendSkinning(QGLWidget* const aGLWidget)
:   ShaderBasedSkinning()
,   mAnim(NULL)
,   mLookupId(-1)
{
    QSettings settings("resources/Settings.ini",QSettings::IniFormat);
    settings.setPath(QSettings::IniFormat,QSettings::UserScope,"./resources");
    settings.sync();

    InitShaders(
        settings.value("SBSVxShader").toString(),
        settings.value("SBSPxShader").toString());

    BindAttributes();

    InitLookup(
        aGLWidget,
        settings.value("BarlaLookup").toString());
}

SphericalBlendSkinning::~SphericalBlendSkinning()
{
    glDeleteTextures(1,&mLookupId);
}

void SphericalBlendSkinning::PreRender()
{
    glBindTexture(GL_TEXTURE_2D,mLookupId);
    ShaderBasedSkinning::PreRender();
    mpShaderProgram->setUniformValue("LookupSampler",0);
    UpdateRotationCenters();
    BindRotationCenters();
    GenAndBindMatrixList();
    FallBack();
}

void SphericalBlendSkinning::PostRender()
{
    ShaderBasedSkinning::PostRender();
    glBindTexture(GL_TEXTURE_2D,0);
}

void SphericalBlendSkinning::UpdateRotationCenters()
{
    QMap<int,RotationCenter>::iterator It;

    for(It = mRCs.begin(); It != mRCs.end(); ++It)
    {
        RotationCenter& TmpRC = It.value();

        int NbBones = 0;
        while(TmpRC.ImplicatedBones[NbBones] != NULL)
        {
            NbBones++;
        }

        It.value().RC = QVector3D(0,0,0);

        switch(NbBones)
        {
        case 1: UpdateRotationCenter1Bone(TmpRC);   break;
        case 2: UpdateRotationCenter2Bones(TmpRC);  break;
        case 3: UpdateRotationCenter3Bones(TmpRC);  break;
        case 4: UpdateRotationCenter4Bones(TmpRC);  break;
        }
    } 
}

void SphericalBlendSkinning::UpdateRotationCenter1Bone(RotationCenter& aRC)
{
    //With a single bone, the rotation center doesn't change anything.
    aRC.RC = aRC.ImplicatedBones[0]->CT();
}

void SphericalBlendSkinning::UpdateRotationCenter2Bones(RotationCenter &aRC)
{
    QMatrix4x4 Rot1,Rot2;

    Rot1.rotate(aRC.ImplicatedBones[0]->CR());
    Rot2.rotate(aRC.ImplicatedBones[1]->CR());

    QMatrix4x4 MS = Rot1 - Rot2;

    QVector3D Vec1 = aRC.ImplicatedBones[0]->CT();
    QVector3D Vec2 = aRC.ImplicatedBones[1]->CT();

    QVector3D VecSub = Vec2 - Vec1;

    double AData[9] = { MS(0,0),MS(0,1),MS(0,2),
                        MS(1,0),MS(1,1),MS(1,2),
                        MS(2,0),MS(2,1),MS(2,2)};

    double BData[3] = {VecSub.x(),VecSub.y(),VecSub.z()};

    double SData[3], XData[3], VData[9], WorkData[3];

    gsl_matrix_view AMat = gsl_matrix_view_array(AData,3,3);
    gsl_matrix_view VMat = gsl_matrix_view_array(VData,3,3);

    gsl_vector_view SVec = gsl_vector_view_array(SData,3);
    gsl_vector_view BVec = gsl_vector_view_array(BData,3);
    gsl_vector_view XVec = gsl_vector_view_array(XData,3);
    gsl_vector_view Work = gsl_vector_view_array(WorkData,3);

    gsl_linalg_SV_decomp(
        &AMat.matrix,
        &VMat.matrix,
        &SVec.vector,
        &Work.vector);

    for(int i = 0; i < 3; ++i)
    {
        if(fabs(SData[i]) < EPS){SData[i] = 0.0;}
    }

    gsl_linalg_SV_solve(
        &AMat.matrix,
        &VMat.matrix,
        &SVec.vector,
        &BVec.vector,
        &XVec.vector);

    aRC.RC = QVector3D(XData[0],XData[1],XData[2]);
}

void SphericalBlendSkinning::UpdateRotationCenter3Bones(RotationCenter &aRC)
{
    QMatrix4x4 R1,R2,R3, R1mR2, R1mR3, R2mR3;
    QVector3D  T1,T2,T3, T2mT1, T3mT1, T3mT2;

    R1.rotate(aRC.ImplicatedBones[0]->CR());
    R2.rotate(aRC.ImplicatedBones[1]->CR());
    R3.rotate(aRC.ImplicatedBones[2]->CR());

    T1 = aRC.ImplicatedBones[0]->CT();
    T2 = aRC.ImplicatedBones[1]->CT();
    T3 = aRC.ImplicatedBones[2]->CT();

    R1mR2 = R1 - R2;
    R1mR3 = R1 - R3;
    R2mR3 = R2 - R3;

    T2mT1 = T2 - T1;
    T3mT1 = T3 - T1;
    T3mT2 = T3 - T2;

    double AData[27] = {R1mR2(0,0), R1mR2(0,1), R1mR2(0,2),
                        R1mR2(1,0), R1mR2(1,1), R1mR2(1,2),
                        R1mR2(2,0), R1mR2(2,1), R1mR2(2,2),
                        R1mR3(0,0), R1mR3(0,1), R1mR3(0,2),
                        R1mR3(1,0), R1mR3(1,1), R1mR3(1,2),
                        R1mR3(2,0), R1mR3(2,1), R1mR3(2,2),
                        R2mR3(0,0), R2mR3(0,1), R2mR3(0,2),
                        R2mR3(1,0), R2mR3(1,1), R2mR3(1,2),
                        R2mR3(2,0), R2mR3(2,1), R2mR3(2,2)};

    double BData[9] = { T2mT1.x(),T2mT1.y(),T2mT1.z(),
                        T3mT1.x(),T3mT1.y(),T3mT1.z(),
                        T3mT2.x(),T3mT2.y(),T3mT2.z()};

    double SData[3], XData[3], VData[9],WorkData[3];

    gsl_matrix_view AMat = gsl_matrix_view_array(AData,9,3);
    gsl_matrix_view VMat = gsl_matrix_view_array(VData,3,3);

    gsl_vector_view SVec = gsl_vector_view_array(SData,3);
    gsl_vector_view BVec = gsl_vector_view_array(BData,9);
    gsl_vector_view XVec = gsl_vector_view_array(XData,3);
    gsl_vector_view Work = gsl_vector_view_array(WorkData,3);

    gsl_linalg_SV_decomp(&AMat.matrix,&VMat.matrix,&SVec.vector,&Work.vector);

    for(int i = 0; i < 3; ++i)
    {
        if(fabs(SData[i]) < EPS){SData[i] = 0.0;}
    }

    gsl_linalg_SV_solve(
        &AMat.matrix,&VMat.matrix,
        &SVec.vector,&BVec.vector,&XVec.vector);

    aRC.RC = QVector3D(XData[0],XData[1],XData[2]);
}

void SphericalBlendSkinning::UpdateRotationCenter4Bones(RotationCenter& aRC)
{
    QMatrix4x4 R1,R2,R3,R4, R1mR2, R1mR3, R1mR4, R2mR3, R2mR4,R3mR4;
    QVector3D T1,T2,T3,T4, T2mT1,T3mT1,T4mT1,T3mT2,T4mT2,T4mT3;

    R1.rotate(aRC.ImplicatedBones[0]->CR());
    R2.rotate(aRC.ImplicatedBones[1]->CR());
    R3.rotate(aRC.ImplicatedBones[2]->CR());
    R4.rotate(aRC.ImplicatedBones[3]->CR());

    T1 = aRC.ImplicatedBones[0]->CT();
    T2 = aRC.ImplicatedBones[1]->CT();
    T3 = aRC.ImplicatedBones[2]->CT();
    T4 = aRC.ImplicatedBones[3]->CT();

    R1mR2 = R1 - R2;
    R1mR3 = R1 - R3;
    R1mR4 = R1 - R4;
    R2mR3 = R2 - R3;
    R2mR4 = R2 - R4;
    R3mR4 = R3 - R4;

    T2mT1 = T2 - T1;
    T3mT1 = T3 - T1;
    T4mT1 = T4 - T1;
    T3mT2 = T3 - T2;
    T4mT2 = T4 - T2;
    T4mT3 = T4 - T3;

    double AData[54] = {R1mR2(0,0), R1mR2(0,1), R1mR2(0,2),
                        R1mR2(1,0), R1mR2(1,1), R1mR2(1,2),
                        R1mR2(2,0), R1mR2(2,1), R1mR2(2,2),
                        R1mR3(0,0), R1mR3(0,1), R1mR3(0,2),
                        R1mR3(1,0), R1mR3(1,1), R1mR3(1,2),
                        R1mR3(2,0), R1mR3(2,1), R1mR3(2,2),
                        R1mR4(0,0), R1mR4(0,1), R1mR4(0,2),
                        R1mR4(1,0), R1mR4(1,1), R1mR4(1,2),
                        R1mR4(2,0), R1mR4(2,1), R1mR4(2,2),
                        R2mR3(0,0), R2mR3(0,1), R2mR3(0,2),
                        R2mR3(1,0), R2mR3(1,1), R2mR3(1,2),
                        R2mR3(2,0), R2mR3(2,1), R2mR3(2,2),
                        R2mR4(0,0), R2mR4(0,1), R2mR4(0,2),
                        R2mR4(1,0), R2mR4(1,1), R2mR4(1,2),
                        R2mR4(2,0), R2mR4(2,1), R2mR4(2,2),
                        R3mR4(0,0), R3mR4(0,1), R3mR4(0,2),
                        R3mR4(1,0), R3mR4(1,1), R3mR4(1,2),
                        R3mR4(2,0), R3mR4(2,1), R3mR4(2,2)};

    double BData[18]  = {T2mT1.x(),T2mT1.y(),T2mT1.z(),
                        T3mT1.x(),T3mT1.y(),T3mT1.z(),
                        T4mT1.x(),T4mT1.y(),T4mT1.z(),
                        T3mT2.x(),T3mT2.y(),T3mT2.z(),
                        T4mT2.x(),T4mT2.y(),T4mT2.z(),
                        T4mT3.x(),T4mT3.y(),T4mT3.z()};

    double SData[3], XData[3], VData[9], WorkData[3];

    gsl_matrix_view AMat = gsl_matrix_view_array(AData,18,3);
    gsl_matrix_view VMat = gsl_matrix_view_array(VData,3,3);

    gsl_vector_view SVec = gsl_vector_view_array(SData,3);
    gsl_vector_view BVec = gsl_vector_view_array(BData,18);
    gsl_vector_view XVec = gsl_vector_view_array(XData,3);
    gsl_vector_view Work = gsl_vector_view_array(WorkData,3);

    gsl_linalg_SV_decomp(&AMat.matrix,&VMat.matrix, &SVec.vector, &Work.vector);

    for(int i = 0; i < 3; ++i)
    {
        if(fabs(SData[i]) < EPS){SData[i] = 0.0;}
    }

    gsl_linalg_SV_solve(
        &AMat.matrix,&VMat.matrix,
        &SVec.vector,&BVec.vector,&XVec.vector);

    aRC.RC = QVector3D(XData[0],XData[1],XData[2]);


}

void SphericalBlendSkinning::InitRotationCenters()
{
    if(mAnim == NULL)
    {
        return;
    }

    mRCs.clear();

    QList<TriAnim>& Geo = mAnim->Geometry();
    QList<Bone*> SkelBones = mAnim->Skeleton().AllBonesList();

    for(int i = 0; i < Geo.size(); ++i)
    {
        TriAnim TmpTri = Geo[i];

        InitRotationCenter(TmpTri.Pt1W,TmpTri.B1,SkelBones);
        InitRotationCenter(TmpTri.Pt2W,TmpTri.B2,SkelBones);
        InitRotationCenter(TmpTri.Pt3W,TmpTri.B3,SkelBones);
    }

    QMap<int,RotationCenter>::iterator It;
    int Counter = 0;
    for(It = mRCs.begin(); It != mRCs.end(); ++It)
    {
        It->RCId = Counter++;
    }

    for(int i = 0; i < Geo.size(); ++i)
    {
        Geo[i].RC1 = mRCs[CRC32String(&Geo[i].B1,sizeof(BoneIndex))].RCId;
        Geo[i].RC2 = mRCs[CRC32String(&Geo[i].B2,sizeof(BoneIndex))].RCId;
        Geo[i].RC3 = mRCs[CRC32String(&Geo[i].B3,sizeof(BoneIndex))].RCId;
    }
}

void SphericalBlendSkinning::BindRotationCenters()
{
    Q_ASSERT_X(
        mRCs.size() <= 65,
        "SphericalBlendSkinning::BindRotationCenters()",
        "Too many different rotation centers, shader supports up to 64 RCs.");

    QVarLengthArray<QVector3D,65> TmpArray(mRCs.size());

    QMap<int,RotationCenter>::Iterator It;
    int i = 0;
    for(It = mRCs.begin(); It != mRCs.end(); ++It)
    {
        TmpArray[i++] = It->RC;
    }

    mpShaderProgram->setUniformValueArray("RCs",TmpArray.data(),65);
}

void SphericalBlendSkinning::InitRotationCenter(
    const QVector4D& aW,
    const BoneIndex& aIndex,
    QList<Bone*>& aSkel)
{
    int CRC = CRC32String(&aIndex,sizeof(BoneIndex));

    if(!mRCs.contains(CRC))
    {
        RotationCenter TmpRC;

        memset(TmpRC.ImplicatedBones,NULL,sizeof(Bone*) * 4);

        
        Q_ASSERT_X(aSkel[aIndex.Idx1]->Id() == aIndex.Idx1,
            "SphericalBlendSkinning::InitRotationCenter",
            "Bone Id doesn't correspond to position in list.");

        if(aW.x() > 0.0){TmpRC.ImplicatedBones[0] = aSkel[aIndex.Idx1];}

        if(aW.y() > 0.0){TmpRC.ImplicatedBones[1] = aSkel[aIndex.Idx2];}

        if(aW.z() > 0.0){TmpRC.ImplicatedBones[2] = aSkel[aIndex.Idx3];}

        if(aW.w() > 0.0){TmpRC.ImplicatedBones[3] = aSkel[aIndex.Idx4];}

        mRCs[CRC] = TmpRC;
    }
}

void SphericalBlendSkinning::InitLookup(QGLWidget* const aGLWidget, 
                                        const QString& aLookupFileName)
{
    mLookupId = aGLWidget->bindTexture(
        QImage(aLookupFileName),
        GL_TEXTURE_2D,
        GL_RGBA);

    glBindTexture(GL_TEXTURE_2D,mLookupId);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);

    glBindTexture(GL_TEXTURE_2D,0);
}

void SphericalBlendSkinning::BindAttributes()
{
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Vertex,"aVertex");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Normal,"aNormal");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Weight,"aWeight");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_BoneId,"aBoneId");
    glBindAttribLocation(mpShaderProgram->programId(), Attrib_Color,"aColor");
    mpShaderProgram->link();
}

void SphericalBlendSkinning::GenAndBindMatrixList()
{
    QList<Bone*> TmpList = mAnim->Skeleton().AllBonesList();

    Q_ASSERT_X(
        TmpList.size() <= MAX_BONE_COUNT,
        "SphericalBlendSkinning::GenAndBindMatrixList()",
        "Too many bones, shader supports up to ROT_CENTER_ARRAY_SIZE bones.");

    QVarLengthArray<QMatrix3x3,MAX_BONE_COUNT> TmpArray(TmpList.size());

    for(int i = 0; i < TmpList.size(); ++i)
    {
        QQuaternion Q = TmpList[i]->SkelSpaceR();
        QVector3D   T = TmpList[i]->SkelSpaceT();

        QVector3D   TMinus1 = TmpList[i]->BindPoseT();

        QVector3D   FinalT = T - TMinus1;

        QMatrix3x3 TmpMat;

        TmpMat(0,0) = Q.x();
        TmpMat(0,1) = Q.y();
        TmpMat(0,2) = Q.z();
        TmpMat(1,0) = Q.scalar();

        TmpMat(1,1) = 0;
        TmpMat(1,2) = 0;

        TmpMat(2,0) = FinalT.x();
        TmpMat(2,1) = FinalT.y();
        TmpMat(2,2) = FinalT.z();

        TmpArray[i] = TmpMat;
    }
    
    mpShaderProgram->setUniformValueArray(
        "BonesT",
        TmpArray.data(),
        MAX_BONE_COUNT);
}

void SphericalBlendSkinning::FallBack()
{
    QList<Bone*> TmpList = mAnim->Skeleton().AllBonesList();

    Q_ASSERT_X(
        TmpList.size() <= MAX_BONE_COUNT,
        "SphericalBlendSkinning::GenAndBindMatrixList()",
        "Too many bones, shader supports up to ROT_CENTER_ARRAY_SIZE bones.");

    QVarLengthArray<QVector4D,MAX_BONE_COUNT> TmpRot(TmpList.size());
    QVarLengthArray<QVector3D,MAX_BONE_COUNT> TmpTrans(TmpList.size());

    for(int i = 0; i < TmpList.size(); ++i)
    {
        QMatrix4x4 P = TmpList[i]->SkelSpaceM();
        QMatrix4x4 Bminus1;
        Bminus1.translate(-TmpList[i]->BindPoseT());

        TmpTrans[i] = (P * Bminus1).column(3).toVector3D();

        QQuaternion Q = TmpList[i]->CR();
        TmpRot[i].setX(Q.x());
        TmpRot[i].setY(Q.y());
        TmpRot[i].setZ(Q.z());
        TmpRot[i].setW(Q.scalar());        
    }

    mpShaderProgram->setUniformValueArray(
        "BonesR",
        TmpRot.data(),
        MAX_BONE_COUNT);

    mpShaderProgram->setUniformValueArray(
        "BonesTrans",
        TmpTrans.data(),
        MAX_BONE_COUNT);
}
