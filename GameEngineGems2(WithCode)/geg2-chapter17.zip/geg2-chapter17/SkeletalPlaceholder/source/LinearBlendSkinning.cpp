#include "LinearBlendSkinning.h"

#include <QSettings>
#include <QVarLengthArray>

LinearBlendSkinning::LinearBlendSkinning(QGLWidget* const aGLWidget)
:   ShaderBasedSkinning()
,   mAnim(NULL)
,   mLookupId(-1)
{
    QSettings settings("resources/Settings.ini",QSettings::IniFormat);
    settings.setPath(QSettings::IniFormat,QSettings::UserScope,"./resources");
    settings.sync();

    InitShaders(
        settings.value("LBSVxShader").toString(),
        settings.value("LBSPxShader").toString());

    BindAttributes();

    InitLookup(
        aGLWidget,
        settings.value("BarlaLookup").toString());
}

LinearBlendSkinning::~LinearBlendSkinning()
{
    glDeleteTextures(1,&mLookupId);
}

void LinearBlendSkinning::PreRender()
{
    glBindTexture(GL_TEXTURE_2D,mLookupId);
    ShaderBasedSkinning::PreRender();
    mpShaderProgram->setUniformValue("LookupSampler",0);
    GenAndBindMatrixList();
}

void LinearBlendSkinning::PostRender()
{
    ShaderBasedSkinning::PostRender();
    glBindTexture(GL_TEXTURE_2D,0);
}

void LinearBlendSkinning::BindAttributes()
{
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Vertex,"aVertex");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Normal,"aNormal");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Weight,"aWeight");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_BoneId,"aBoneId");
    mpShaderProgram->link();
}

void LinearBlendSkinning::GenAndBindMatrixList()
{
    QList<Bone*> TmpList = mAnim->Skeleton().AllBonesList();

    Q_ASSERT_X(
        TmpList.size() <= MAX_BONE_COUNT,
        "LinearBlendSkinning::GenAndBindMatrixList()",
        "Too many bones, shader supports up to MAX_BONE_COUNT bones.");

    QVarLengthArray<QMatrix4x4,MAX_BONE_COUNT> TmpArray(TmpList.size());

    for(int i = 0; i < TmpList.size(); ++i)
    {
        QMatrix4x4 P = TmpList[i]->SkelSpaceM();
        QMatrix4x4 Bminus1;
        Bminus1.translate(-TmpList[i]->BindPoseT());

        TmpArray[i] = P * Bminus1;
    }

    mpShaderProgram->setUniformValueArray(
        "BonesMatrices",
        TmpArray.data(),
        MAX_BONE_COUNT);
}

void LinearBlendSkinning::InitLookup(QGLWidget* const aGLWidget, 
                                     const QString& aLookupFileName)
{
    mLookupId = aGLWidget->bindTexture(
        QImage(aLookupFileName),
        GL_TEXTURE_2D,
        GL_RGBA);

    glBindTexture(GL_TEXTURE_2D,mLookupId);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);

    glBindTexture(GL_TEXTURE_2D,0);
}
