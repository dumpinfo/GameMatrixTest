#include "CameraMouse.h"

#include <qgl.h>

#include <cmath>
#include <iostream>

using namespace std;

CameraMouse::CameraMouse()
:	mDistance(30.0f)
,	mTheta(0.0f)
,	mPhi(3.141592f/8.0f)
,	mZoomActive(false)
,	mRotateActive(false)
,   mMouseCoord(0,0)
{}

void CameraMouse::Refresh(float DeltaT)
{
	mPosition.setX(mDistance * cos(mPhi) * sin(mTheta));
	mPosition.setY(mDistance * sin(mPhi));
	mPosition.setZ(mDistance * cos(mPhi) * cos(mTheta));

	gluLookAt(	mPosition.x(),mPosition.y(),mPosition.z(),
				0,0,0,
				0,1,0);
}

void CameraMouse::RefreshPosition(QMouseEvent* apEvent)
{
	if(mZoomActive || mRotateActive)
	{
        QPoint Delta = apEvent->pos() - mMouseCoord;

        mMouseCoord = apEvent->pos();

		if(mZoomActive)
		{
			mDistance += Delta.y()/20.0f;

			if(mDistance < 4)
			{
				mDistance = 4;
			}
			else if(mDistance > 500)
			{
				mDistance = 500;
			}
		}

		if(mRotateActive)
		{
			mPhi += Delta.y()/200.0f;
			mTheta -= Delta.x()/100.0f;

			if(mPhi > 3.141592f/2.0f)
			{
				mPhi = 3.141592f/2.0f;
			}
			else if(mPhi < -3.141592/2.0f)
			{
				mPhi = -3.141592/2.0f;
			}
		}
	}
}

void CameraMouse::RefreshState(QMouseEvent* apEvent)
{
    if(apEvent->button() == Qt::LeftButton)
    {
        if(apEvent->type() == QEvent::MouseButtonPress)
        {
            mRotateActive = true;
            mMouseCoord = apEvent->pos();
        }
        else if(apEvent->type() == QEvent::MouseButtonRelease)
        {
            mRotateActive = false;
        }
    }
    else if(apEvent->button() == Qt::RightButton)
    {
        if(apEvent->type() == QEvent::MouseButtonPress)
        {
            mZoomActive = true;
            mMouseCoord = apEvent->pos();
        }
        else if(apEvent->type() == QEvent::MouseButtonRelease)
        {
            mZoomActive = false;
        }
    }
}

CameraMouse::~CameraMouse()
{
}
