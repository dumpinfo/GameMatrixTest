#ifndef DENSITYFIELD_H
#define DENSITYFIELD_H

#include <QVector3D>

class DensityField
{
public:

    virtual double Evaluate(const QVector3D& aPos) =  0;
    virtual QVector3D EvaluateNormal(const QVector3D& aPos) = 0;
};

#endif //DENSITYFIELD_H