#ifndef CONSOLE_H_
#define CONSOLE_H_

#include <QPlainTextEdit>

#include "TSingleton.h"

class Console : public TSingleton<Console>
{
public:

    void OutPlain(const QString& arStr);
    void OutHtml(const QString& arStr);

    void SetTerminal(QPlainTextEdit* apConsole);

private:

    friend class TSingleton<Console>;

    Console();
    Console(const Console& arConsole){};
    void operator=(const Console& arRHS){};
    virtual ~Console(){};

    QPlainTextEdit* mpConsoleTerminal;
};


inline void Console::OutPlain(const QString& arStr)
{
    if(mpConsoleTerminal != NULL)
    {
        mpConsoleTerminal->appendPlainText(arStr);
    }
}

inline void Console::OutHtml(const QString& arStr)
{
    if(mpConsoleTerminal != NULL)
    {
        mpConsoleTerminal->appendHtml(arStr);
    }
}

inline void Console::SetTerminal(QPlainTextEdit* apConsole)
{
    mpConsoleTerminal = apConsole;
}
#endif //CONSOLE_H_