#ifndef BONE_H_
#define BONE_H_

#include <QList>
#include <QMatrix4x4>
#include <QQuaternion>
#include <QVector3D>

#include "DensityField.h"
#include "Renderable.h"

class Bone : public Renderable, public DensityField
{
public:

    Bone(const QString& aName="Unnamed");
    virtual ~Bone();

    QString Name() const;
    void SetName(const QString& aName);

    bool Selected() const;
    void SetSelected(bool aSelected);

    double Weight() const;
    void SetWeight(double aWeight);

    Bone*   AddChild(Bone* aChild);
    Bone*   RemoveChild(Bone* aChild);
    int     ChildCount() const;
    bool    HasChildren() const;
    Bone*   Child(int aId) const;
    QList<Bone*> Children() const;

    void GenId();
    int Id() const;
    QList<Bone*> AllBonesList();

    QPair<QVector3D,QVector3D> Segment() const;

    Bone*   Parent() const;

    QQuaternion R() const;
    QVector3D   T() const;
    void        SetR(const QQuaternion& aR);
    void        SetT(const QVector3D& aT);

    QMatrix4x4      M() const;

    void        GenerateBindPose();
    QVector3D   BindPoseT() const;
    QQuaternion BindPoseR() const;
    QMatrix4x4  BindPoseM() const;
    void        SetBindPoseT(const QVector3D& aT);
    void        SetBindPoseR(const QQuaternion& aT);

    QVector3D   CT();
    QQuaternion CR();
    
    QQuaternion     SkelSpaceR() const;
    QVector3D       SkelSpaceT() const;
    QMatrix4x4      SkelSpaceM() const;

    //Renderable part
    void RefreshTransform();
    void RenderDebug();

    //DensityField part
    virtual double Evaluate(const QVector3D& aPos);
    virtual QVector3D EvaluateNormal(const QVector3D& aPos);


protected:

    void _DrawJoint(float aRadius, int aPrecision);
    void _DrawSegment(float aRadius, int aPrecision);
    void _GenId(int &aId);

    double _EvalBone(const QVector3D& aPos);
    QVector3D _DoEvalNormal(const QVector3D& aPos);

    bool mSelected;

    Bone* mpParent;
    QList<Bone*> mChildren;

    QString mName;
    int mId;

    //Bind Pose
    QQuaternion mBindR;
    QVector3D   mBindT;

    //Bone space transformations
    QQuaternion mR;
    QVector3D   mT;

    //Cached transforms
    QVector3D   mCT;

    //Skeleton space transformation cache.
    //(Prevents having to recompute the
    // skeleton transformation every time
    // a child asks for it.)
    QQuaternion mSkelSpaceR;
    QVector3D   mSkelSpaceT;

    double mWeight;//Weight for the Density field part.
};

Q_DECLARE_METATYPE(Bone*);

inline QString Bone::Name() const
{
    return mName;
}

inline void Bone::SetName(const QString& aName)
{
    mName = aName;
}

inline bool Bone::Selected() const
{
    return mSelected;
}

inline void Bone::SetSelected(bool aSelected)
{
    mSelected = aSelected;
}

inline double Bone::Weight() const
{
    return mWeight;
}

inline void Bone::SetWeight(double aWeight)
{
    mWeight = aWeight;
}

inline int Bone::ChildCount() const
{
    return mChildren.size();
}

inline bool Bone::HasChildren() const
{
    return !mChildren.empty();
}

inline Bone* Bone::Child(int aId) const
{
    return mChildren[aId];
}

inline QList<Bone*> Bone::Children() const
{
    return mChildren;
}

inline void Bone::GenId()
{
    int TmpId = 0;
    _GenId(TmpId);

}

inline int Bone::Id() const
{
    return mId;
}

inline QPair<QVector3D,QVector3D> Bone::Segment() const
{
    if(Parent() != NULL)
    {
        return QPair<QVector3D,QVector3D>(
            Parent()->SkelSpaceT(),
            SkelSpaceT());    
    }
    else
    {
        return QPair<QVector3D,QVector3D>();
    }
}

inline Bone* Bone::Parent() const
{
    return mpParent;
}

inline QQuaternion Bone::R() const
{
    return mR;
}

inline QVector3D Bone::T() const
{
    return mT;
}

inline void Bone::SetR(const QQuaternion& aR)
{
    mR = aR;
    RefreshTransform();
}

inline void Bone::SetT(const QVector3D& aT)
{
    mT = aT;
    RefreshTransform();
}

inline QVector3D Bone::BindPoseT() const
{
    return mBindT;
}

inline QQuaternion Bone::BindPoseR() const
{
    return mBindR;
}

inline QMatrix4x4 Bone::BindPoseM() const
{
    QMatrix4x4 RetMat;

    RetMat.translate(mSkelSpaceT);
    RetMat.rotate(mSkelSpaceR);

    return RetMat;
}

inline void Bone::SetBindPoseT(const QVector3D& aT)
{
    mBindT = aT;
}

inline void Bone::SetBindPoseR(const QQuaternion& aR)
{
    mBindR = aR;
}

inline QVector3D Bone::CT()
{
    return mCT;
}

inline QQuaternion Bone::CR()
{
    return SkelSpaceR();
}

#endif //BONE_H_
