#include "GenericBarlaSkinning.h"

#include <qgl.h>
#include <QSettings>

#include "glext.h"

GenericBarlaSkinning::GenericBarlaSkinning(QGLWidget* const aGLWidget)
:   ShaderBasedSkinning()
,   mLookupId(-1)
{
    QSettings settings("resources/Settings.ini",QSettings::IniFormat);
    settings.setPath(QSettings::IniFormat,QSettings::UserScope,"./resources");
    settings.sync();

    InitShaders(
        settings.value("BarlaVxShader").toString(),
        settings.value("BarlaPxShader").toString());

    BindAttributes();

    InitLookup(
        aGLWidget,
        settings.value("BarlaLookup").toString());
}

GenericBarlaSkinning::~GenericBarlaSkinning()
{
    glDeleteTextures(1,&mLookupId);       
}

void GenericBarlaSkinning::PreRender()
{
    glBindTexture(GL_TEXTURE_2D,mLookupId);
    ShaderBasedSkinning::PreRender(); //Sets the shader up

    mpShaderProgram->setUniformValue("LookupSampler",0);
}

void GenericBarlaSkinning::PostRender()
{
    ShaderBasedSkinning::PostRender();
    glBindTexture(GL_TEXTURE_2D,0);
}

void GenericBarlaSkinning::InitLookup(QGLWidget* const aGLWidget, 
                                      const QString& aLookupFileName)
{
    mLookupId = aGLWidget->bindTexture(
        QImage(aLookupFileName),
        GL_TEXTURE_2D,
        GL_RGBA);

    glBindTexture(GL_TEXTURE_2D,mLookupId);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);

    glBindTexture(GL_TEXTURE_2D,0);
}

void GenericBarlaSkinning::BindAttributes()
{
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Vertex,"aVertex");
    glBindAttribLocation(mpShaderProgram->programId(),Attrib_Normal,"aNormal");
    mpShaderProgram->link();
}

