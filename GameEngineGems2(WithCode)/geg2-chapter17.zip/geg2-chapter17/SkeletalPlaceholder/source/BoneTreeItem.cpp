#include "BoneTreeItem.h"

#include "ResourceManager.h"

BoneTreeItem::BoneTreeItem(Bone* apBone)
:   QTreeWidgetItem(QTreeWidgetItem::UserType)
,   mpBone(apBone)
{}

QVariant BoneTreeItem::data(int aColumn, int aRole) const
{
    switch(aRole)
    {
    case Qt::DisplayRole :
        return mpBone->Name();
    case Qt::DecorationRole :
    {
        if(mpBone->HasChildren())
        {
            return ResourceManager::Instance().Res<QIcon>(
                "Resources/Icons/Bone_Icon_Group.png");
        }
        else
        {
            return ResourceManager::Instance().Res<QIcon>(
                "Resources/Icons/Bone_Icon_Leaf.png");
        }
    }
    case Role_Bone :
        return QVariant::fromValue<Bone*>(mpBone);
    default :
        return QVariant();
    }
}

BoneTreeItem* CreateItemTree(Bone* apBone)
{
    if(apBone != NULL)
    {
        BoneTreeItem* RetVal = new BoneTreeItem(apBone);

        for(int i = 0; i < apBone->ChildCount(); ++i)
        {
            RetVal->addChild(CreateItemTree(apBone->Child(i)));
        }

        return RetVal;
    }
    else
    {
        return NULL;
    }

    
}
