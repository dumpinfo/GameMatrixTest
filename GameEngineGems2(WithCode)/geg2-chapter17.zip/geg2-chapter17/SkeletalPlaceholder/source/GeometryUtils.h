#ifndef GEOMETRYUTILS_H_
#define GEOMETRYUTILS_H_

#include <QVector3D>
#include <QVector4D>

struct BoneIndex
{
    BoneIndex(){};

    BoneIndex(
        unsigned char aIdx1, 
        unsigned char aIdx2, 
        unsigned char aIdx3, 
        unsigned char aIdx4)
        : Idx1(aIdx1), Idx2(aIdx2)
        , Idx3(aIdx3), Idx4(aIdx4)
    {}

    operator QVector4D() const
    {
        return QVector4D(Idx1,Idx2,Idx3,Idx4);
    }

    unsigned char Idx1;
    unsigned char Idx2;
    unsigned char Idx3;
    unsigned char Idx4;
};


struct Tri
{
    Tri(){};

    Tri(const Tri& aRHS)
        :   Pt1(aRHS.Pt1),  Pt2(aRHS.Pt2)
        ,   Pt3(aRHS.Pt3),  N1(aRHS.N1)
        ,   N2(aRHS.N2),    N3(aRHS.N3)
    {}

    Tri(const QVector3D& aPt1, const QVector3D& aPt2, const QVector3D& aPt3)
        : Pt1(aPt1)
        , Pt2(aPt2)
        , Pt3(aPt3)
    {}

    QVector3D Pt1;
    QVector3D Pt2;
    QVector3D Pt3;

    QVector3D N1;
    QVector3D N2;
    QVector3D N3;
};

struct TriAnim : public Tri
{
    TriAnim(){};

    TriAnim(const Tri& aRHS)
        :   Tri(aRHS)
        ,   Pt1W(0,0,0,0), Pt2W(0,0,0,0)
        ,   Pt3W(0,0,0,0), B1(0,0,0,0)
        ,   B2(0,0,0,0),   B3(0,0,0,0)
        ,   RC1(0),RC2(0),RC3(0)
    {}

    TriAnim(const TriAnim& aRHS)
        :   Tri(aRHS)
        ,   Pt1W(aRHS.Pt1W),Pt2W(aRHS.Pt2W)
        ,   Pt3W(aRHS.Pt3W),B1(aRHS.B1)
        ,   B2(aRHS.B2),    B3(aRHS.B3)
        ,   RC1(aRHS.RC1),RC2(aRHS.RC2),RC3(aRHS.RC3)
    {}

    QVector4D Pt1W;
    QVector4D Pt2W;
    QVector4D Pt3W;

    //Bone indices
    BoneIndex B1;
    BoneIndex B2;
    BoneIndex B3;

    //Rotation centers (only used for SBS)
    int RC1;
    int RC2;
    int RC3;
};

#endif //GEOMETRYUTILS_H_
