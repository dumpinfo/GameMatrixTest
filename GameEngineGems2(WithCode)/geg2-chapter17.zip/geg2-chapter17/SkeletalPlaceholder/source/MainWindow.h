#ifndef MAINWINDOW_H_
#define MAINWINDOW_H_

#include <GL/glew.h>
#include <QDial>
#include <QGridLayout>
#include <QGroupBox>
#include <QMainWindow>
#include <QMenuBar>
#include <QPlainTextEdit>
#include <QTreeWidget>
#include <QActionGroup>

#include "Animated.h"
#include "Bone.h"
#include "GLView.h"
#include "ImplicitSurface.h"
#include "OrientationControl.h"

class GLView;


class MainWindow : public QMainWindow
{
	Q_OBJECT

    enum EulerAxis
    {
        Euler_X,
        Euler_Y,
        Euler_Z,
    };

    enum AvailableSkins
    {
        Skin_GenericBarla = 0,
        Skin_DirectSkinning,
        Skin_LBS,
        Skin_SBS,
    };

public:
	MainWindow(QWidget *apParent = NULL);
	~MainWindow();

    void PostGLInit();

    void LoadSkeleton(const QString& aSkeletonFile);

public slots:

    void OnOpenFile();
    void OnBoneSelectionChange();
    void OnDialChangeX(int aVal);
    void OnDialChangeY(int aVal);
    void OnDialChangeZ(int aVal);
    void OnSkinChange(QAction* aTriggered);
    void OnShowHideSkeleton();
    void OnShowHideMesh();
    void OnWireframeMesh();

private:

    void _InitUi();
    void _InitMenuBar();
    void _InitGL();
    void _InitControls();
    void _InitConsole();
    void _InitSkinningMethods();
    void _UpdateRotation(int aAngle, EulerAxis aDialId);


    QWidget*        mpCentralWidget;
    QGridLayout*    mpLayout;

    QMenuBar* mpMenuBar;

    QGroupBox* mpGroupDisplay;
    QGroupBox* mpGroupControls;
    QGroupBox* mpGroupConsole;

    QPlainTextEdit* mpConsole;

    GLView* mpGLView;

    //Skeleton related
    Bone*           mpSkeleton; //Root bone of the skeleton.
    Bone*           mpSelectedBone; //Currently selecte bone.
    QTreeWidget*    mpSkeletonTreeView; //Displays the skeleton in a tree view.
    QVector3D       mSelectedBoneEulAngles;//Euler angles of the currently 
                                           //selected bone.

    Animated*           mpAnimatedMesh;
    ImplicitSurface*    mpImplicitSurface;

    OrientationControl* mpRotX;
    OrientationControl* mpRotY;
    OrientationControl* mpRotZ;

    SkinningMethod* mpSkinningMethods[4];

    QActionGroup* mpSkinningActions;

    bool mHideSkeleton;
    bool mHideMesh;
    bool mMeshWireframe;
};

#endif // MAINWINDOW_H_
