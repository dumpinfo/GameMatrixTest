#include "ShaderBasedSkinning.h"

#include <QGLContext>
#include <QSettings>

#include "DisplayDefs.h"
#include "Console.h"

ShaderBasedSkinning::ShaderBasedSkinning()
:   mpFragmentShader(NULL)
,   mpVertexShader(NULL)
,   mpShaderProgram(NULL)
{}

ShaderBasedSkinning::~ShaderBasedSkinning()
{
    delete mpFragmentShader;
    delete mpVertexShader;
    delete mpShaderProgram;
}

void ShaderBasedSkinning::PreRender()
{
    mpShaderProgram->bind();

    int Tmp = mpShaderProgram->attributeLocation("aBoneId");
}

void ShaderBasedSkinning::PostRender()
{
    mpShaderProgram->release();
}

void ShaderBasedSkinning::InitShaders(const QString& aVxShaderSourceFile, 
                                      const QString& aFgShaderSourceFile)
{
    if(mpShaderProgram  != NULL){delete mpShaderProgram;}
    if(mpFragmentShader != NULL){delete mpFragmentShader;}
    if(mpVertexShader   != NULL){delete mpVertexShader;}

    mpFragmentShader    = new QGLShader(QGLShader::Fragment,this);
    mpVertexShader      = new QGLShader(QGLShader::Vertex,this);
    mpShaderProgram     = new QGLShaderProgram(this);


    Console::Instance().OutPlain(tr("======= Shader Build Started ======="));
    Console::Instance().OutPlain(tr("Compiling Shaders..."));

    Console::Instance().OutPlain(tr("%1").arg(aFgShaderSourceFile));

    mpFragmentShader->compileSourceFile(aFgShaderSourceFile);
    if(!mpFragmentShader->isCompiled())
    {
        Console::Instance().OutPlain(mpFragmentShader->log());
    }


    Console::Instance().OutPlain(tr("%1").arg(aVxShaderSourceFile));

    mpVertexShader->compileSourceFile(aVxShaderSourceFile);
    if(!mpVertexShader->isCompiled())
    {
        Console::Instance().OutPlain(mpVertexShader->log());
    }

    mpShaderProgram->addShader(mpFragmentShader);
    mpShaderProgram->addShader(mpVertexShader);

    mpShaderProgram->link();

    Console::Instance().OutPlain(tr("Linking Shader Program..."));
    if(!mpShaderProgram->isLinked())
    {
        Console::Instance().OutPlain(mpShaderProgram->log());
        Console::Instance().OutPlain(tr("======= Build : Failed ======="));
    }
    else
    {
        Console::Instance().OutPlain(tr("======= Build : Succeeded ======="));
    }

    Console::Instance().OutPlain(tr(""));
}
