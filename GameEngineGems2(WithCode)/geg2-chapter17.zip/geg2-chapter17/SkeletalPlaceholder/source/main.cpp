
#include <GL/glew.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>
#include <QtGui/QApplication>
#include <QSplashScreen>
#include <iostream>

#include "Console.h"
#include "MainWindow.h"
#include "ResourceManager.h"

#include <QDir>

int main(int argc, char *argv[])
{
    //Application initialization
    QApplication a(argc, argv);

    //Singleton creation
    Console::Create();
    ResourceManager::Create();

	MainWindow w;

    w.show();

    int Err = glewInit();
    if(GLEW_OK != Err)
    {
        qDebug() <<"Glew initialization error :";
        qDebug() << (char*)glewGetErrorString(Err);
    }
    
    w.PostGLInit();

    Console::Instance().OutPlain("Initialization complete.");

    int RetVal = a.exec();

    //Singleton destruction
    Console::Destroy();
    ResourceManager::Destroy();

	return RetVal;
}
