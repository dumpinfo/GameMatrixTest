#include "GLView.h"

#include <cmath>
#include <QVector3D>

GLView::GLView(QWidget* apParent /* = NULL */)
:   QGLWidget(apParent)
,   mpCam(new CameraMouse())
{
    setAutoBufferSwap(false);
}

GLView::~GLView()
{}

void GLView::initializeGL()
{
    glClearColor(1,1,1,1);

    glShadeModel(GL_SMOOTH);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

    glEnable(GL_TEXTURE_2D);

    glViewport(0,0,width(),height());
}

void GLView::resizeGL(int aW, int aH)
{
    glViewport(0,0,aW,aH);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(55,(float)width()/(float)height(),0.1f,500.0f);

    updateGL();
}

void GLView::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);   

    float pAmbient[]     = { 0.2f,   0.2f,   0.2f,   1.0f };
    float pDiffuse[]     = { 0.8f,   0.8f,   0.8,    1.0f };
    float pSpecular[]    = { 0.5f,   0.5f,   0.5f,   1.0f };
    float pPosition[]    = { 5.0f,   0.0f,   10.0f,  1.0f };

    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0,GL_AMBIENT, pAmbient);
    glLightfv(GL_LIGHT0,GL_DIFFUSE, pDiffuse);
    glLightfv(GL_LIGHT0,GL_SPECULAR,pSpecular);
    glLightfv(GL_LIGHT0,GL_POSITION,pPosition);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    mpCam->Refresh(1);

    for(int i = 0; i < mRenderList.size(); ++i)
    {
        if(mRenderList[i]->Visible())
        {
            mRenderList[i]->Render();
        }

        if(mRenderList[i]->DebugEnabled())
        {
            mRenderList[i]->RenderDebug();
        }
    }

    glPushAttrib(GL_LIGHTING_BIT);
    glDisable(GL_LIGHTING);
    _RenderAxisGuide();
    glPopAttrib();

    swapBuffers();
}

void GLView::AddRenderable(Renderable* aR)
{
    mRenderList.push_back(aR);
}

void GLView::RemoveRenderable(Renderable* aR)
{
    QList<Renderable*>::iterator It;

    for(It = mRenderList.begin(); It != mRenderList.end(); ++It)
    {
        if(*It == aR)
        {
            mRenderList.erase(It);
            return;
        }
    }
}

void GLView::_RenderAxisGuide()
{
    glPushMatrix();
    QMatrix4x4 MV;
    glGetDoublev(GL_MODELVIEW_MATRIX,MV.data());

    MV.setColumn(3,QVector4D(width()-60,60,1,1));

    glLoadMatrixd(MV.data());

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0,width(),0,height(),-100,100);

    glBegin(GL_LINES);
    glColor3f(1,0,0);
    glVertex3f(0,0,0);
    glVertex3f(50,0,0);

    glColor3f(0,1,0);
    glVertex3f(0,0,0);
    glVertex3f(0,50,0);


    glColor3f(0,0,1);
    glVertex3f(0,0,0);
    glVertex3f(0,0,50);

    glEnd();

    glColor3f(1,0,0);
    renderText(50,0,0,"X",QFont("Arial"));
    glColor3f(0,1,0);
    renderText(0,50,0,"Y",QFont("Arial"));
    glColor3f(0,0,1);
    renderText(0,0,50,"Z",QFont("Arial"));

    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}
