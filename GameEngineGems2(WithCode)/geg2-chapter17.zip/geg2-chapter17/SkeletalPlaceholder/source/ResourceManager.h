#ifndef RESOURCEMANAGER_H_
#define RESOURCEMANAGER_H_

//Qt includes
#include <QVariant>

//Other includes
#include "TSingleton.h"

class ResourceManager : public TSingleton<ResourceManager>
{
public:

	//Returns a resource and loads it if required. The correct TypeHint must
	//be inserted if the resource has never been loaded. If the resource has
	//already been loaded, the Typehint is not obligatory.
	template<class T>
	T Res(const QString& aResPath);

protected:

	//This method is called when the ResourceManager is constructed. this
	//function **HAS** to be called **AFTER** the QApplication was created
	//since it will instantiate resources that require the application's
	//graphic capabilities.
	virtual void PreloadResources();

	QMap<QString,QVariant> mResources;

private:

	friend class TSingleton<ResourceManager>;

	ResourceManager();
	ResourceManager(const ResourceManager& aResMan){};
	virtual ~ResourceManager(){};

	void operator=(const ResourceManager& aRHS){};

};

template<class T>
T ResourceManager::Res(const QString &aResPath)
{
	QMap<QString,QVariant>::iterator It;

	It = mResources.find(aResPath);

	if(It != mResources.end())
	{
		return qvariant_cast<T>(*It);
	}
	else
	{
		T Tmp(aResPath);
		mResources[aResPath] = Tmp;
		return Tmp;
	}
}

#endif //RESOURCEMANAGER_H_