#ifndef GENERICBARLASKINNING_H_
#define GENERICBARLASKINNING_H_

#include "ShaderBasedSkinning.h"

class GenericBarlaSkinning : public ShaderBasedSkinning
{
public:

    GenericBarlaSkinning(QGLWidget* const aGLWidget);
    virtual ~GenericBarlaSkinning();

    virtual void PreRender();
    virtual void PostRender();

protected:

    void InitLookup(QGLWidget* const aGLWidget, const QString& aLookupFileName);
    void BindAttributes();

    unsigned int mLookupId;
};

#endif //GENERICBARLASKINNING_H_
