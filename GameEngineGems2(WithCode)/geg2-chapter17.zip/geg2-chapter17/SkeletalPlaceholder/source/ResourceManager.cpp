#include "ResourceManager.h"

//Qt includes
#include <QIcon>

ResourceManager::ResourceManager()
{
	PreloadResources();
}

void ResourceManager::PreloadResources()
{
	//Icons preloading
	Res<QIcon>("Resources/Icons/Bone_Icon_Group.png");
	Res<QIcon>("Resources/Icons/Bone_Icon_Leaf.png");
}