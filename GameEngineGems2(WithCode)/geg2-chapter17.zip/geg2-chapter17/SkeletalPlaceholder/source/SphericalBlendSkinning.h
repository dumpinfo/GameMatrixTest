 #ifndef SPHERICALBLENDSKINNING_H_
#define SPHERICALBLENDSKINNING_H_

#include <QVector3D>
#include <QList>
#include <QMap>

#include "ShaderBasedSkinning.h"

class SphericalBlendSkinning : public ShaderBasedSkinning
{
public:

    struct RotationCenter
    {
        int         RCId;
        QVector3D   RC;

        Bone*       ImplicatedBones[4];
    };

    SphericalBlendSkinning(QGLWidget* const aGLWidget);
    ~SphericalBlendSkinning();

    virtual void SetAnimated(Animated* const aAnim);
    virtual void PreRender();
    virtual void PostRender();

protected:

    void BindAttributes();
    void GenAndBindMatrixList();
    void FallBack();

    void InitRotationCenters();
    void BindRotationCenters();

    void UpdateRotationCenters();
    void UpdateRotationCenter1Bone(RotationCenter& aRC);
    void UpdateRotationCenter2Bones(RotationCenter& aRC);
    void UpdateRotationCenter3Bones(RotationCenter& aRC);
    void UpdateRotationCenter4Bones(RotationCenter& aRC);

    void InitLookup(QGLWidget* const aGLWidget, const QString& aLookupFileName);

    void InitRotationCenter(
        const QVector4D& aW,
        const BoneIndex& aIndex,
        QList<Bone*>& aSkel);

    QMap<int,RotationCenter> mRCs;

    unsigned int mLookupId;
    Animated* mAnim;
};

inline void SphericalBlendSkinning::SetAnimated(Animated *const aAnim)
{
    mAnim = aAnim;
    InitRotationCenters();
}

#endif //SPHERICALBLENDSKINNING_H_
