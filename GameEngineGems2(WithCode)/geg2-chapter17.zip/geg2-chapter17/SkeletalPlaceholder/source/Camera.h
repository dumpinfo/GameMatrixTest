#ifndef CAMERA_H_
#define CAMERA_H_

#include <QVector3D>
class Camera
{
public:

	virtual void	Refresh(float aDeltaT) = 0;

	void			SetPosition(const QVector3D& aPosition);
	QVector3D		GetPosition() const;

	void			SetLookAt(const QVector3D& aLookAt);
	QVector3D		GetLookAt() const;

protected:

	QVector3D mPosition;
	QVector3D mLookat;
};

inline void Camera::SetPosition(const QVector3D& aPosition)
{
	mPosition = aPosition;
}

inline QVector3D Camera::GetPosition() const
{
	return mPosition;
}

inline void Camera::SetLookAt(const QVector3D& aLookat)
{
	mLookat = aLookat;
}

inline QVector3D Camera::GetLookAt() const
{
	return mLookat;
}



#endif //CAMERA_H_
