#ifndef DISPLAYDEFS_H_
#define DISPLAYDEFS_H_

#define MAX_BONE_COUNT 40

enum AttributeIndex
{
    Attrib_Vertex   = 0,
    Attrib_Normal   = 1,
    Attrib_Weight   = 2,
    Attrib_BoneId   = 3,
    Attrib_Color    = 4,
};

#endif //DISPLAYDEFS_H_