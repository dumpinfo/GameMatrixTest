#ifndef BONETREEITEM_H_
#define BONETREEITEM_H_

#include <QTreeWidgetItem>

#include "Bone.h"

class BoneTreeItem : public QTreeWidgetItem
{
public:

    enum Role
    {
        Role_Bone = Qt::UserRole,
    };

    BoneTreeItem(Bone* apBone);

    virtual QVariant data(int aColumn, int aRole) const;

protected:

    Bone* mpBone;
};

BoneTreeItem* CreateItemTree(Bone* apBone);

#endif //BONETREEITEM_H_