#ifndef ORIENTATIONCONTROL_H_
#define ORIENTATIONCONTROL_H_

#include <QWidget>
#include <QSlider>
#include <QPushButton>

class OrientationControl : public QWidget
{
    Q_OBJECT

public:

    OrientationControl(QWidget* apParent = NULL);

    void setValue(int aVal);

public slots:

    void OnReset(bool aChecked);

signals:

    void valueChanged(int);

protected:

    void _InitUi();

    QSlider*        mpSlider;
    QPushButton*    mpResetButton;
};

inline void OrientationControl::setValue(int aVal)
{
    mpSlider->setValue(aVal);
}

inline void OrientationControl::OnReset(bool aChecked)
{
    setValue(0);
}

#endif //ORIENTATIONCONTROL_H_