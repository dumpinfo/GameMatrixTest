#include "MainWindow.h"

#include <QApplication>
#include <QFileDialog>
#include <QLabel>

#include "BoneTreeItem.h"
#include "Console.h"
#include "DirectSkinning.h"
#include "GenericBarlaSkinning.h"
#include "LinearBlendSkinning.h"
#include "MathUtils.h"
#include "SkeletonReader.h"
#include "SphericalBlendSkinning.h"

MainWindow::MainWindow(QWidget *apParent)
:   QMainWindow(apParent)
,   mpCentralWidget(NULL)
,   mpLayout(NULL)
,   mpMenuBar(NULL)
,   mpGroupDisplay(NULL)
,   mpGroupControls(NULL)
,   mpGroupConsole(NULL)
,   mpConsole(NULL)
,   mpGLView(NULL)
,   mpSkeleton(NULL)
,   mpSelectedBone(NULL)
,   mpSkeletonTreeView(NULL)
,   mpRotX(NULL)
,   mpRotY(NULL)
,   mpRotZ(NULL)
,   mpAnimatedMesh(NULL)
,   mpImplicitSurface(NULL)
,   mpSkinningActions(NULL)
,   mHideMesh(false)
,   mHideSkeleton(false)
,   mMeshWireframe(true)
{
    _InitUi();
}

void MainWindow::PostGLInit()
{
    _InitSkinningMethods();
}

void MainWindow::LoadSkeleton(const QString& aSkeletonFile )
{
    mpRotX->setDisabled(true);
    mpRotY->setDisabled(true);
    mpRotZ->setDisabled(true);

    QApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
    if(QFile::exists(aSkeletonFile))
    {
        QFile SkeletonFile(aSkeletonFile);

        QXmlInputSource XmlSource(&SkeletonFile);
        QXmlSimpleReader XmlReader;
        SkeletonReader SkeletonParser;

        XmlReader.setContentHandler(&SkeletonParser);
        XmlReader.parse(XmlSource);

        Bone* TmpSkel = SkeletonParser.Skeleton();

        if(TmpSkel != NULL)
        {
            mpGLView->RemoveRenderable(mpSkeleton);

            if(mpSkeleton != NULL)
            {
                delete mpSkeleton;
                mpSkeleton = NULL;
            }

            mpSkeleton = TmpSkel;

            mpSelectedBone = NULL;
            mpSkeletonTreeView->clearFocus();
            mpSkeletonTreeView->clearMask();
            mpSkeletonTreeView->clearSelection();

            mpSkeletonTreeView->clear();
            

            mpGLView->update();
            Console::Instance().OutPlain(
                tr("File %1 was successfully loaded.").arg(aSkeletonFile));

            Console::Instance().OutPlain(
                tr("Generating Implicit Surface for Loaded Skeleton..."));

            mpConsole->repaint();

            if(mpImplicitSurface == NULL)
            {
                mpImplicitSurface = new ImplicitSurface(
                    QVector3D(-10,-10,-10),
                    QVector3D(10,10,10));

                mpGLView->AddRenderable(mpImplicitSurface);
            }
            mpImplicitSurface->SetDensityField(mpSkeleton);

            if(mpAnimatedMesh == NULL)
            {
                mpAnimatedMesh = new Animated();
                mpGLView->AddRenderable(mpAnimatedMesh);
            }

            unsigned int CurSkin = mpSkinningActions->checkedAction()->data().toUInt();
            mpAnimatedMesh->SetSkeleton(mpSkeleton);
            mpAnimatedMesh->SetGeometry(mpImplicitSurface->GetGeometry(true));
            mpAnimatedMesh->SetSkinningMethod(mpSkinningMethods[CurSkin]);
           
            Console::Instance().OutPlain(
                tr("Implict Surface Generation Completed..."));

            mpGLView->AddRenderable(mpSkeleton);
            mpSkeletonTreeView->addTopLevelItem(CreateItemTree(mpSkeleton));
            mpSkeletonTreeView->expandAll();

            mpAnimatedMesh->SetVisible(!mHideMesh && !mMeshWireframe);
            mpAnimatedMesh->EnableDebug(!mHideMesh && mMeshWireframe);

            mpSkeleton->EnableDebug(!mHideSkeleton);

            mpGLView->update();
        }
        else
        {
            Console::Instance().OutPlain(
                tr("There was a problem loading file %1.").arg(aSkeletonFile));
        }


    }    
    else
    {
        Console::Instance().OutPlain(tr("The file does not exist."));
    }
    QApplication::restoreOverrideCursor();

    mpRotX->setDisabled(false);
    mpRotY->setDisabled(false);
    mpRotZ->setDisabled(false);
}

void MainWindow::OnOpenFile()
{
    QString FileName = QFileDialog::getOpenFileName(NULL,
                                tr("Please select a skeleton xml file."),
                                "",
                                tr("Skeleton File (*.xml)"));

    LoadSkeleton(FileName);
}

void MainWindow::OnBoneSelectionChange()
{
    QList<QTreeWidgetItem*> SelItems = mpSkeletonTreeView->selectedItems();

    if(mpSelectedBone != NULL)
    {
        mpSelectedBone->SetSelected(false);
    }

    if(!SelItems.isEmpty())
    {
        QVariant Tmp = SelItems[0]->data(0,BoneTreeItem::Role_Bone);

        if(Tmp.canConvert<Bone*>())
        {
            mpSelectedBone = Tmp.value<Bone*>();
            mpSelectedBone->SetSelected(true);

            mSelectedBoneEulAngles = QuatToEulerAngles(mpSelectedBone->R());

            mpRotX->setValue(mSelectedBoneEulAngles.x() * 180.0f/PI);
            mpRotY->setValue(mSelectedBoneEulAngles.y() * 180.0f/PI);
            mpRotZ->setValue(mSelectedBoneEulAngles.z() * 180.0f/PI);

            mpRotX->setEnabled(true);
            mpRotY->setEnabled(true);
            mpRotZ->setEnabled(true);
        }
    }
    else
    {
        mpSelectedBone = NULL;
    }

    mpGLView->update();
}

void MainWindow::OnDialChangeX(int aVal)
{
    _UpdateRotation(aVal,Euler_X);
}

void MainWindow::OnDialChangeY(int aVal)
{
    _UpdateRotation(aVal,Euler_Y);
}

void MainWindow::OnDialChangeZ(int aVal)
{
    _UpdateRotation(aVal,Euler_Z);
}

void MainWindow::OnSkinChange(QAction* aTriggered)
{
    if(mpAnimatedMesh != NULL)
    {
        mpAnimatedMesh->SetSkinningMethod(
            mpSkinningMethods[aTriggered->data().toUInt()]);

        mpGLView->update();
    }
}

void MainWindow::OnShowHideSkeleton()
{
    mHideSkeleton = !mHideSkeleton;

    if(mpSkeleton != NULL)
    {
        mpSkeleton->EnableDebug(!mHideSkeleton);
    }

    mpGLView->update();
}

void MainWindow::OnShowHideMesh()
{
    mHideMesh = !mHideMesh;

    if(mpAnimatedMesh != NULL)
    {
        mpAnimatedMesh->SetVisible(!mHideMesh && !mMeshWireframe);
        mpAnimatedMesh->EnableDebug(!mHideMesh && mMeshWireframe);
    }

    mpGLView->update();
}

void MainWindow::OnWireframeMesh()
{
    mMeshWireframe = !mMeshWireframe;
    
    if(mpAnimatedMesh != NULL)
    {
        mpAnimatedMesh->SetVisible(!mMeshWireframe && !mHideMesh);
        mpAnimatedMesh->EnableDebug(!mHideMesh && mMeshWireframe);
    }

    mpGLView->update();
}

void MainWindow::_InitUi()
{
    this->setCentralWidget(new QWidget(this));

    //Display group setup
    mpGroupDisplay = new QGroupBox(tr("Display"),this);
    mpGroupDisplay->setSizePolicy(  QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
    mpGroupDisplay->setMinimumSize(800,600);

    //Controls group setup
    mpGroupControls = new QGroupBox(tr("Controls"),this);
    mpGroupControls->setSizePolicy( QSizePolicy::MinimumExpanding,
                                    QSizePolicy::MinimumExpanding);
    mpGroupControls->setMinimumHeight(200);


    //Console group setup
    mpGroupConsole = new QGroupBox(tr("Console"),this);
    mpGroupConsole->setSizePolicy(  QSizePolicy::MinimumExpanding,
                                    QSizePolicy::Minimum);
    mpGroupConsole->setMinimumSize(1000,200);

    //General grid layout setup
    mpLayout = new QGridLayout(centralWidget());

    mpLayout->setColumnStretch(0,75);
    mpLayout->setColumnStretch(1,25);
    mpLayout->setRowStretch(0,75);
    mpLayout->setRowStretch(1,25);

    mpLayout->addWidget(mpGroupDisplay,0,0,1,1);
    mpLayout->addWidget(mpGroupControls,0,1,1,1);
    mpLayout->addWidget(mpGroupConsole,1,0,1,2);

    //Interface widgets initialization
    _InitMenuBar();
    _InitConsole();
    _InitGL();
    _InitControls();
}

void MainWindow::_InitMenuBar()
{
    //File Menu
    //////////////////////////////////////////////////////////////////////////
    QMenu* FileMenu = this->menuBar()->addMenu(tr("&File"));

    FileMenu->addAction(
        "&Open...",
        this,
        SLOT(OnOpenFile()),
        QKeySequence(tr("Ctrl+O", "File|Open")));

    FileMenu->addSeparator();

    FileMenu->addAction(
        "&Exit",
        this,
        SLOT(close()));

    //View Menu
    //////////////////////////////////////////////////////////////////////////
    QMenu* ViewMenu = this->menuBar()->addMenu(tr("&View"));

    QActionGroup* AGroup = new QActionGroup(this);
    mpSkinningActions = AGroup;

    QAction* Tmp = new QAction("Generic Barla Shader",AGroup);
    Tmp->setData(QVariant(Skin_GenericBarla));
    Tmp->setCheckable(true);
    AGroup->addAction(Tmp);

    Tmp = new QAction("Direct Skinning",AGroup);
    Tmp->setData(QVariant(Skin_DirectSkinning));
    Tmp->setCheckable(true);
    AGroup->addAction(Tmp);

    Tmp = new QAction("Linear Blend Skinning",AGroup);
    Tmp->setData(QVariant(Skin_LBS));
    Tmp->setCheckable(true);
    AGroup->addAction(Tmp);

    Tmp = new QAction("Spherical Blend Skinning",AGroup);
    Tmp->setData(QVariant(Skin_SBS));
    Tmp->setCheckable(true);
    AGroup->addAction(Tmp);

    Tmp->setChecked(true);
    AGroup->setExclusive(true);

    connect(
        AGroup,
        SIGNAL(triggered(QAction*)),
        this,
        SLOT(OnSkinChange(QAction*)));

    ViewMenu->addActions(AGroup->actions());

    ViewMenu->addSeparator();

    Tmp = ViewMenu->addAction(
        "Hide Skeleton",
        this,
        SLOT(OnShowHideSkeleton()));
    Tmp->setCheckable(true);
    Tmp->setChecked(mHideSkeleton);

    Tmp = ViewMenu->addAction(
        "Hide Mesh",
        this,
        SLOT(OnShowHideMesh()));
    Tmp->setCheckable(true);
    Tmp->setChecked(mHideMesh);

    Tmp = ViewMenu->addAction(
        "Show Wireframe",
        this,
        SLOT(OnWireframeMesh()));
    Tmp->setCheckable(true);
    Tmp->setChecked(mMeshWireframe);
}

void MainWindow::_InitConsole()
{
    //Create and setup the console
    mpConsole = new QPlainTextEdit(this);
    mpConsole->setFont(QFont("Courier",10));
    mpConsole->setReadOnly(true);

    //Place the console in the ui itself.
    QVBoxLayout* pVBoxLayout = new QVBoxLayout;
    mpGroupConsole->setLayout(pVBoxLayout);
    pVBoxLayout->addWidget(mpConsole);

    Console::Instance().SetTerminal(mpConsole);
}

void MainWindow::_InitSkinningMethods()
{
    mpSkinningMethods[0] = new GenericBarlaSkinning(mpGLView);
    mpSkinningMethods[1] = new DirectSkinning(mpGLView);
    mpSkinningMethods[2] = new LinearBlendSkinning(mpGLView);
    mpSkinningMethods[3] = new SphericalBlendSkinning(mpGLView);
}


void MainWindow::_InitGL()
{
    mpGLView = new GLView(this);

    QVBoxLayout* pVBoxLayout = new QVBoxLayout;
    mpGroupDisplay->setLayout(pVBoxLayout);
    pVBoxLayout->addWidget(mpGLView);
}

void MainWindow::_InitControls()
{
    //Skeleton tree view setup
    mpSkeletonTreeView = new QTreeWidget(this);
    mpSkeletonTreeView->setMinimumHeight(300);
    mpSkeletonTreeView->setSizePolicy(  QSizePolicy::MinimumExpanding,
                                        QSizePolicy::MinimumExpanding);
    mpSkeletonTreeView->setHeaderLabel(tr("Skeleton"));

    connect(
        mpSkeletonTreeView,
        SIGNAL(itemSelectionChanged()),
        this,
        SLOT(OnBoneSelectionChange()));

    //Rotation dials setup
    mpRotX = new OrientationControl(this);
    mpRotY = new OrientationControl(this);
    mpRotZ = new OrientationControl(this);

    mpRotX->setDisabled(true);
    mpRotY->setDisabled(true);
    mpRotZ->setDisabled(true);

    connect(mpRotX,SIGNAL(valueChanged(int)),this,SLOT(OnDialChangeX(int)));
    connect(mpRotY,SIGNAL(valueChanged(int)),this,SLOT(OnDialChangeY(int)));
    connect(mpRotZ,SIGNAL(valueChanged(int)),this,SLOT(OnDialChangeZ(int)));

    QGridLayout* pDialLayout = new QGridLayout;
    pDialLayout->addWidget(mpRotX,0,1,1,1);
    pDialLayout->addWidget(mpRotY,1,1,1,1);
    pDialLayout->addWidget(mpRotZ,2,1,1,1);
    pDialLayout->addWidget(new QLabel(tr("Heading :"),this),0,0,1,1,Qt::AlignRight);
    pDialLayout->addWidget(new QLabel(tr("Attitude :"),this),1,0,1,1,Qt::AlignRight);
    pDialLayout->addWidget(new QLabel(tr("Bank :"),this),2,0,1,1,Qt::AlignRight);

    QVBoxLayout* pVBoxLayout = new QVBoxLayout;
    mpGroupControls->setLayout(pVBoxLayout);
    mpGroupControls->setMinimumWidth(400);
    mpGroupControls->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::MinimumExpanding);
    pVBoxLayout->addWidget(mpSkeletonTreeView);
    pVBoxLayout->addLayout(pDialLayout);
}

void MainWindow::_UpdateRotation(int aAngle, EulerAxis aDialId)
{
    if(mpSelectedBone != NULL)
    {
        double aAngRad = (PI * aAngle) / 180.0;

        switch(aDialId)
        {
        case Euler_X :
            mSelectedBoneEulAngles.setX(aAngRad);
            break;
        case Euler_Y :
            mSelectedBoneEulAngles.setY(aAngRad);
            break;
        case Euler_Z :
            mSelectedBoneEulAngles.setZ(aAngRad);
            break;
        default :
            return;
        }

        mpSelectedBone->SetR(EulerAnglesToQuat(mSelectedBoneEulAngles));
        mpGLView->update();
    }
}

MainWindow::~MainWindow()
{}
