#ifndef MATRIXUTILS_H_
#define MATRIXUTILS_H_

#include <QMatrix4x4>
#include <QVector3D>
#include <QQuaternion>

#define PI 3.14159265

QMatrix4x4 GenerateBasis(const QVector3D& aVec,
                         const QVector3D& aUp = QVector3D(),
                         const QVector3D& aFallBack = QVector3D());

QVector3D QuatToEulerAngles(const QQuaternion& aQuat);

QQuaternion EulerAnglesToQuat(const QVector3D& aEulerAngles);

//Projects Vector A on Vector B
QVector3D Project(const QVector3D& arA,const QVector3D& arB);

QVector3D ShortestVecToSegment( const QPair<QVector3D,QVector3D> aSeg, 
                                const QVector3D& aPoint);

double DistToSegmentSquared(const QPair<QVector3D,QVector3D> aSeg, 
                            const QVector3D& aPoint);

double DistToSegment(const QPair<QVector3D,QVector3D> aSeg, 
                     const QVector3D& aPoint);

QVector3D SegmentNormal( const QPair<QVector3D,QVector3D> aSeg, 
                         const QVector3D& aPoint);

#endif //MATRIXUTILS_H_