#include "MathUtils.h"

#include <cmath>

QMatrix4x4 GenerateBasis(const QVector3D& aVec, 
                         const QVector3D& aUp, 
                         const QVector3D& aFallBack)
{
    QVector3D FirstVec;
    QVector3D SecondVec;

    FirstVec = QVector3D::crossProduct(aUp,aVec);

    //We verify if the crossproduct returned a
    //quasi-null vector. If it's the case we compute
    //firstvec with the fallback vector.
    if(qFuzzyCompare(QVector3D(1,1,1) + FirstVec,QVector3D(1,1,1)))
    {
        FirstVec = QVector3D::crossProduct(aFallBack,aVec);
    }

    SecondVec = QVector3D::crossProduct(FirstVec,aVec);

    QMatrix4x4 RetMat;
    RetMat.setColumn(0,aVec.normalized().toVector4D());
    RetMat.setColumn(1,FirstVec.normalized().toVector4D());
    RetMat.setColumn(2,SecondVec.normalized().toVector4D());
    RetMat.setColumn(3,QVector4D(0,0,0,1));

    return RetMat;   
}

QVector3D QuatToEulerAngles(const QQuaternion& aQuat)
{
    double heading = 0.0;
    double attitude = 0.0;
    double bank = 0.0;

    double sqw = aQuat.scalar() * aQuat.scalar();
    double sqx = aQuat.x() * aQuat.x();
    double sqy = aQuat.y() * aQuat.y();
    double sqz = aQuat.z() * aQuat.z();
    double unit = sqx + sqy + sqz + sqw; // if normalised is one, otherwise is correction factor
    double test = aQuat.x() * aQuat.y() + aQuat.z() * aQuat.scalar();
    
    if (test > 0.499*unit)// singularity at north pole
    {
        heading = 2 * atan2(aQuat.x(),aQuat.scalar());
        attitude = PI/2;
        bank = 0;
    }
    else if (test < -0.499*unit)// singularity at south pole
    {
        heading = -2 * atan2(aQuat.x(),aQuat.scalar());
        attitude = -PI/2;
        bank = 0;
    }
    else
    {
        heading = atan2(2*aQuat.y()*aQuat.scalar()-2*aQuat.x()*aQuat.z(), sqx - sqy - sqz + sqw);
        attitude = asin(2*test/unit);
        bank = atan2(2*aQuat.x()*aQuat.scalar()-2*aQuat.y()*aQuat.z() , -sqx + sqy - sqz + sqw);
    }

    return QVector3D(heading,attitude,bank);
}

QQuaternion EulerAnglesToQuat(const QVector3D& aEulerAngles)
{
    double heading = aEulerAngles.x();
    double attitude = aEulerAngles.y();
    double bank = aEulerAngles.z();
    double c1 = cos(heading/2);
    double s1 = sin(heading/2);
    double c2 = cos(attitude/2);
    double s2 = sin(attitude/2);
    double c3 = cos(bank/2);
    double s3 = sin(bank/2);
    double c1c2 = c1*c2;
    double s1s2 = s1*s2;
    double w =c1c2*c3 - s1s2*s3;
    double x =c1c2*s3 + s1s2*c3;
    double y =s1*c2*c3 + c1*s2*s3;
    double z =c1*s2*c3 - s1*c2*s3;
    
    return QQuaternion(w,x,y,z);
}

QVector3D Project(const QVector3D& arA,const QVector3D& arB)
{
    return (QVector3D::dotProduct(arA,arB)/arB.lengthSquared())*arB;
}

QVector3D ShortestVecToSegment(const QPair<QVector3D,QVector3D> aSeg, 
                               const QVector3D& aPoint)
{
    QVector3D Segment  = (aSeg.second - aSeg.first);
    QVector3D PtToSeg = (aPoint - aSeg.first);

    QVector3D Proj = Project(PtToSeg,Segment);

    if(QVector3D::dotProduct(Proj,Segment) > 0.0)
    {
        if(Proj.lengthSquared() > Segment.lengthSquared())
        {
            return (aPoint - aSeg.second);
        }
        else
        {
            return (aPoint - (aSeg.first + Proj));
        }
    }
    else
    {
        return (aPoint - aSeg.first);
    }
}

double DistToSegmentSquared(const QPair<QVector3D,QVector3D> aSeg, 
                            const QVector3D& aPoint)
{
   return ShortestVecToSegment(aSeg,aPoint).lengthSquared();
}

double DistToSegment(const QPair<QVector3D,QVector3D> aSeg, 
                     const QVector3D& aPoint)
{
    return sqrt(DistToSegmentSquared(aSeg,aPoint));
}

QVector3D SegmentNormal(const QPair<QVector3D,QVector3D> aSeg, 
                        const QVector3D& aPoint)
{
    return ShortestVecToSegment(aSeg,aPoint).normalized();
}
