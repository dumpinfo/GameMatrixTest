#ifndef RENDERABLE_H_
#define RENDERABLE_H_

class Renderable
{
public:

    Renderable()
        : mDebugEnabled(false)
        , mVisible(true)
    {};

    bool DebugEnabled() const;
    void EnableDebug(bool aEnable);

    bool Visible() const;
    void SetVisible(bool aVisible);

    virtual void Render(){};
    virtual void RenderDebug(){};

private:

    friend class GLView;

    bool mDebugEnabled;
    bool mVisible;
};

inline bool Renderable::DebugEnabled() const
{
    return mDebugEnabled;
}

inline void Renderable::EnableDebug(bool aEnable)
{
    mDebugEnabled = aEnable;
}

inline bool Renderable::Visible() const
{
    return mVisible;
}

inline void Renderable::SetVisible(bool aVisible)
{
    mVisible = aVisible;
}

#endif //RENDERABLE_H_