#ifndef IMPLICITSURFACE_H_
#define IMPLICITSURFACE_H_

#include <QGLShader>
#include <QGLShaderProgram>
#include <QObject>
#include <QVector3D>
#include <QVector>
#include <QGLPixelBuffer>

#include "DensityField.h"
#include "Renderable.h"
#include "GeometryUtils.h"

class ImplicitSurface : public QObject, public Renderable
{
public:

    struct GridEntry
    {
        double      Val; //Value
        QVector3D   Pos; //Position in space
    };

    ImplicitSurface(
        const QVector3D& arAABBMin, 
        const QVector3D& arAABBMax);

    virtual ~ImplicitSurface();

    double  Threshold() const;
    void    SetThreshold(double aT);

    int     SubDivCount() const;
    void    SetSubDivCount(int aCount);

    void    SetDensityField(DensityField* apField);

    GridEntry   V(int x,int y ,int z) const;
    GridEntry&  V(int x, int y, int z);

    virtual void Render();
    virtual void RenderDebug();

    QList<Tri> GetGeometry(bool aRefine = true);
    void FreeMemory();

protected:

    //Protected methods
    //////////////////////////////////////////////////////////////////////////
    
    void _GenerateGrid();
    void _GenerateShape();
    void _RefineShape();
    void _GenerateNormals();

    QVector3D _RefinePoint(const QVector3D& aPos, double aPrecision);

    void _SingleTetraHedron(
        const GridEntry& arGe0,
        const GridEntry& arGe1,
        const GridEntry& arGe2,
        const GridEntry& arGe3);


    QVector3D _Interp(
        const GridEntry& arGe0,
        const GridEntry& arGe1);

    void _Tri(
        const QVector3D& arPt0,
        const QVector3D& arPt1,
        const QVector3D& arPt2);

    double  mThreshold;
    int     mSubDivCount;
    bool    mRefined;

    QVector3D mAABBMin;
    QVector3D mAABBMax;

    DensityField* mpField;

    QVector<Tri> mTriangles;
    QVector<GridEntry> mGrid;
};

inline double ImplicitSurface::Threshold() const
{
    return mThreshold;
}

inline void ImplicitSurface::SetThreshold(double aT)
{
    mThreshold = aT;
}

inline int ImplicitSurface::SubDivCount() const
{
    return mSubDivCount;
}

inline void ImplicitSurface::SetSubDivCount(int aCount)
{
    mSubDivCount = aCount;
}
inline void ImplicitSurface::SetDensityField(DensityField* apSkel)
{
    mpField = apSkel;
}

inline ImplicitSurface::GridEntry ImplicitSurface::V(int x,int y ,int z) const
{
    return mGrid[z * mSubDivCount * mSubDivCount + y * mSubDivCount + x];
}

inline ImplicitSurface::GridEntry& ImplicitSurface::V(int x,int y ,int z)
{
    return mGrid[z * mSubDivCount * mSubDivCount + y * mSubDivCount + x];
}

inline void ImplicitSurface::_Tri(const QVector3D& arPt0, 
                                  const QVector3D& arPt1, 
                                  const QVector3D& arPt2)
                                  
{
    mTriangles.push_back(Tri(arPt0,arPt1,arPt2));
}

#endif //IMPLICITSURFACE_H_
