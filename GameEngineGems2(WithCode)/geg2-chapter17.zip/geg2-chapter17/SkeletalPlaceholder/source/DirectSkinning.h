#ifndef DIRECTSKINNING_H_
#define DIRECTSKINNING_H_

#include "ShaderBasedSkinning.h"

class DirectSkinning : public ShaderBasedSkinning
{
public:

    DirectSkinning(QGLWidget* const aGLWidget);
    virtual ~DirectSkinning();

    virtual void SetAnimated(Animated* const aAnim);
    virtual void PreRender();
    virtual void PostRender();

    

protected:
   
    void BindAttributes();
    void GenAndBindMatrixList();
    void InitLookup(QGLWidget* const aGLWidget, const QString& aLookupFileName);

    unsigned int mLookupId;
    Animated* mAnim;
    

};

inline void DirectSkinning::SetAnimated(Animated* aAnim)
{
    mAnim = aAnim;
}

#endif //DIRECTSKINNING_H_
