///////////////////////////////////////////////////////////////
//
// PlaceHolders Beyond Static Art Replacement - Demo Readme
//
// v1.0 - First file version.
//
// Sherbrooke University, 2010-10-31
//
///////////////////////////////////////////////////////////////

This folder contains the demo code for the chapter "Placeholders Beyond Static Art Replacement".

The code contained within the visual studio solution is a demonstration of the articulated placeholder generation technique described in the chapter. 

=== SETUP AND INSTALLATION ===

The provided solution requires Visual Studio 2008 or Higher. All the required dependencies are provided with the demo and configured within the VS solution. It is therefore possible to directly compile the solution with no further configurations.

To run the demo, simply extract the folders from the disc, open the Visual Studio solution and fire up the build/execution.

=== FILES OF INTEREST ===

The demo is rather large as a full animation and rendering system is required to demonstrate the technique.

The following is a list of files directly related to the technique described in the book's chapter which might be of greater interest to the reader.

- source/Bone.h/.cpp 		       (Animation Skeleton code + Skeleton density field)
- source/ImplicitSurface.h/.cpp        (Implicit surface generation)
- source/Animated.h/.cpp 	       (Automatic Skinning algorithm)
- source/LinearBlendSkinning.h/.cpp    (Linear Blend Skinning implementation)
- source/SphericalBlendSkinning.h/.cpp (Spherical Blend Skinning implementation

- resources/shaders/LinearBlendSkinning.vxs/.pxs    (Linear blend skinning vertex and fragment shader)
- resources/shaders/SphericalBlendSkinning.vxs/.pxs (Spherical blend skinning vertex and fragment shader)


=== MINIMUM REQUIREMENTS ===

This demo requires a GLSL1.3 capable graphics processing unit.

=== AKNOWLEDGEMENTS ===

The demo uses the following third party libraries :

GSL - Gnu scientific Library : http://www.gnu.org/software/gsl/
GLEW - The OpenGL Extension Wrangler Library : http://glew.sourceforge.net/
Qt - Cross-platform application and UI framework : http://qt.nokia.com/ 

=== MISCELLANEOUS ===

1- Please note that multiple files have been removed from the third party library folders to reduce the size of this demo. Only the minimally required files are contained within them. Downloading the full libraries from the libraries' website is recommended for further development or modification of this demo. 

2- The visual studio solution comes with a property sheet that overrides the environment variable QTDIR to point towards the minimal Qt directory located in folder "/thirdparty/QtMinimal". This could cause problem to readers trying to link with their own complete Qt distribution. If you would like to do so, simply remove the environment variable from the property sheet to remove the override.

3- The provided solution works with Win32, however, all the librairies are cross-platform. The demo will compile on Linux or OS X with very few modifications.