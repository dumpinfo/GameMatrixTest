//-------------------
// ToolsTimeWriter.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef TOOLSTIMEWRITER_H
#define TOOLSTIMEWRITER_H

//-------------------

#include <stack>
#include <vector>
#include <string>

//-------------------
// This is what the user fills out for each struct that is written.  We remember the address where it began,
// the contents of what was written, and the locations of where all the pointers were.  That way, during the
// Finalize() call, we can merge all the structs together and rewrite the pointers, then convert them to relative
// addresses.
typedef unsigned int PtrType;

struct Asset
{
	Asset(char const *name, PtrType addr) : mName(name), mAddress(addr) {}

	std::string mName;
	PtrType     mAddress;
};

struct StructContents
{
	StructContents(PtrType addr) : mStartAddr(addr) {}

	PtrType                    mStartAddr;
	std::vector<unsigned char> mData;
	std::vector<PtrType>       mPointerLocations;
};

//-------------------
// This is a basic serialization class that tracks where pointers are and what they point to.
class ToolsTimeWriter
{
public:
	ToolsTimeWriter(bool byteSwap);

	// this puts an entry in the asset table at the header of the output file.
	void StartAsset(char const *name, void *s);

	// the system records where all the structs start and based on the number of write calls, how long they are,
	// and therefore knows when a pointer is pointing INTO another struct that's been serialized.  It can automatically
	// convert them to relative pointers this way.  This works like a stack, so it's easy to traverse structures.
	void StartStruct(void *s);

	// once a struct has been started, you call these to pump out data.  These are useful for handling byte swapping, mainly.
	// Wherever a pointer is in a structure, you call WritePtr(), which lets the writer know to watch out for 
	void Write1(void);	
	void Write2(void);	
	void Write4(void);
	void Write8(void);
	void WritePtr(void);	
	void WriteRaw(int numBytes);	

	void EndStruct(void);

	// This will resolve all pointers stored in the stream and throw an error if anything is wrong.
	std::vector<unsigned char> Finalize(void);

protected:
	// This runs through all the structs and sees which one contains the target byte of the pointer.  asserts if none do.
	StructContents *LookupPointerTarget(PtrType ptr);
	
private:
	bool mByteSwap;

	std::stack<int>             mCurrentStructs;  // this holds a stack of indices into the StructInfo vector, for quick access.
	std::vector<StructContents> mStructInfo;      // held and written in the order supplied by the user
	std::vector<Asset>          mAssets;          // catalog of assets, so we can retrieve them in the runtime
};

//-------------------

#endif
