//-------------------
// RuntimePatchSet.cpp
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include "RuntimePatchSet.h"
#include <string.h>

//-------------------

void DoFixups(PointerPatchTableHeader *header)
{
	// walk all the pointers and convert them from relative to absolute
	// by adding the offset stored in their location to their current address.
	PointerPatchTable *ppt = header->mPatchTable.GetPointer();
	for (int i=0; i<header->mNumPointers; i++)
	{
		intSZ *pointerToFixup = ppt[i].GetPointer();

		// add the pointer's address to the offset stored at that location, converting it from a relative to an absolute pointer.
		// Special case: if the offset is zero, it would be a pointer to itself, which we assume really means NULL.  So we leave it alone.
		if (*pointerToFixup)
			*pointerToFixup = *pointerToFixup + (intSZ)pointerToFixup;  
	}
}

//-------------------

void *FindAssetByName(PointerPatchTableHeader *header, char const *name)
{
	// walk all the assets and string compare them all (yeah, very slow.  Optimizations left to the reader, obviously.)
	AssetTable *atable = header->mAssetTable.GetPointer();
	for (int i=0; i<header->mNumAssets; i++)
	{
		if (strcmp(atable[i].mName, name)==0)
		{
			return atable[i].mAsset;
		}
	}
	return NULL;
}

//-------------------
