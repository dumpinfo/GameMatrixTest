//-------------------
// ToolsTimeWriter.cpp
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include "ToolsTimeWriter.h"
#include "TRelativePointer.h"
#include <map>
#include <assert.h>

//-------------------

static unsigned short SwapBytes2(unsigned short d)
{
	return (d >> 8) | (d << 8);
}

static unsigned int SwapBytes4(unsigned int d)
{
	return (d >> 24) | (d << 24) | ((d & 0xff00) << 8) | ((d & 0xff0000) >> 8);
}

static unsigned long long SwapBytes8(unsigned long long d)
{
	return (d >> 56) | ((d & 0xff) << 56) | ((d & 0xff00) << 40) | ((d & 0xff0000) << 24) |
	       ((d & 0xff000000) << 8) | ((d & 0xff00000000) >> 8) | ((d & 0xff0000000000) >> 24) | ((d & 0xff000000000000) >> 40);
}

//-------------------
// Helpers--implicitly assumes non-byte-swapped is Little Endian.
static void Write2(unsigned short d, std::vector<unsigned char> &stream, bool byteSwap)
{
	if (byteSwap)
	{
		d = SwapBytes2(d);
	}
	stream.push_back((unsigned char)(d & 0xff));		
	stream.push_back((unsigned char)(d >> 8));		
}

//-------------------

static void Write4(unsigned int d, std::vector<unsigned char> &stream, bool byteSwap)
{
	if (byteSwap)
	{
		d = SwapBytes4(d);
	}
	stream.push_back((unsigned char)((d & 0xff)));		
	stream.push_back((unsigned char)((d & 0xff00) >> 8));		
	stream.push_back((unsigned char)((d & 0xff0000) >> 16));		
	stream.push_back((unsigned char)((d & 0xff000000) >> 24));					
}

//-------------------

static void Write8(unsigned long long d, std::vector<unsigned char> &stream, bool byteSwap)
{
	if (byteSwap)
	{
		d = SwapBytes8(d);
	}
	stream.push_back((unsigned char)((d & 0xff)));		
	stream.push_back((unsigned char)((d & 0xff00) >> 8));		
	stream.push_back((unsigned char)((d & 0xff0000) >> 16));		
	stream.push_back((unsigned char)((d & 0xff000000) >> 24));					
	stream.push_back((unsigned char)((d & 0xff00000000) >> 32));			
	stream.push_back((unsigned char)((d & 0xff0000000000) >> 40));		
	stream.push_back((unsigned char)((d & 0xff000000000000) >> 48));		
	stream.push_back((unsigned char)((d & 0xff00000000000000) >> 56));					
}

//-------------------

static void Overwrite4(unsigned int d, std::vector<unsigned char> &stream, int index, bool byteSwap)
{
	if (byteSwap)
	{
		d = SwapBytes4(d);
	}
	stream[index + 0] = ((unsigned char)((d & 0xff)));		
	stream[index + 1] = ((unsigned char)((d & 0xff00) >> 8));		
	stream[index + 2] = ((unsigned char)((d & 0xff0000) >> 16));		
	stream[index + 3] = ((unsigned char)((d & 0xff000000) >> 24));					
}

//-------------------

ToolsTimeWriter::ToolsTimeWriter(bool byteSwap)
	: mByteSwap(byteSwap)
{
}

//-------------------
// this puts an entry in the asset table at the header of the output file.
void ToolsTimeWriter::StartAsset(char const *name, void *s)
{
	mAssets.push_back(Asset(name, (PtrType)s));
}

//-------------------

void ToolsTimeWriter::StartStruct(void *s)
{
	StructContents sc((PtrType)s);
	mCurrentStructs.push(mStructInfo.size());  // put index onto the top of the stack
	mStructInfo.push_back(sc);  // add new struct
}

//-------------------

void ToolsTimeWriter::Write1(void)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];
	unsigned char d = *(unsigned char *)(sc.mStartAddr + sc.mData.size());
	sc.mData.push_back(d);
}

//-------------------

void ToolsTimeWriter::Write2(void)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];
	unsigned short d = *(unsigned short *)(sc.mStartAddr + sc.mData.size());
	::Write2(d, sc.mData, mByteSwap);
}

//-------------------

void ToolsTimeWriter::Write4(void)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];
	unsigned int d = *(unsigned int *)(sc.mStartAddr + sc.mData.size());
	::Write4(d, sc.mData, mByteSwap);	
}

//-------------------

void ToolsTimeWriter::Write8(void)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];
	unsigned long long d = *(unsigned long long *)(sc.mStartAddr + sc.mData.size());
	::Write8(d, sc.mData, mByteSwap);	
}

//-------------------

void ToolsTimeWriter::WritePtr(void)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];

	// remember this is where a pointer is
	sc.mPointerLocations.push_back(sc.mStartAddr + sc.mData.size());
	
	// just write out zero for now
	::Write4(0, sc.mData, false);	
}

//-------------------

void ToolsTimeWriter::WriteRaw(int numBytes)
{
	assert(mCurrentStructs.size());
	StructContents &sc = mStructInfo[mCurrentStructs.top()];
	for (int i=0; i<numBytes; i++)
	{
		unsigned char d = *(unsigned char *)(sc.mStartAddr + sc.mData.size());
		sc.mData.push_back(d);		
	}
}

//-------------------

void ToolsTimeWriter::EndStruct(void)
{
	assert(mCurrentStructs.size());
	mCurrentStructs.pop();
}

//-------------------

StructContents *ToolsTimeWriter::LookupPointerTarget(PtrType ptr)
{
	if (ptr==NULL)
		return NULL;
		
	// slow walk through all structs looking for one where pointer targets the specified range
	for (unsigned int i=0; i<mStructInfo.size(); i++)
	{
		StructContents &sc = mStructInfo[i];
		if (ptr >= sc.mStartAddr && ptr < sc.mStartAddr + sc.mData.size())
			return &sc;
	}
	assert(false);  // if this hits, you've got a pointer that is pointing to some data that you ARE NOT serializing.
	return NULL;
}

//-------------------

std::vector<unsigned char> ToolsTimeWriter::Finalize(void)
{
	assert(mCurrentStructs.size()==0);
	std::vector<unsigned char> block;

	//-------------------
	// count how many pointers there are, so we know how much space to reserve for the fixup table at the top of the file
	unsigned int numPointers = 0;
	for (unsigned int i=0; i<mStructInfo.size(); i++)
	{
		numPointers += mStructInfo[i].mPointerLocations.size();
	}

	// generate the asset header and pointer table
	::Write4(numPointers, block, mByteSwap);	
	::Write4(12, block, mByteSwap);  // this always points to the address immediately following the header for the pointer table
	::Write4(mAssets.size(), block, mByteSwap);	
	::Write4(4+numPointers*sizeof(intSZ), block, mByteSwap);  // this always points to the address immediately following the block of pointers

	// write out the pointers, initially empty
	int const startOfPointers = block.size();
	block.insert(block.end(), numPointers * sizeof(intSZ), 0);
	
	// write out the asset table pointers, also empty
	int const startOfAssets = block.size();
	block.insert(block.end(), mAssets.size() * sizeof(intSZ) * 2, 0);

	// while building the final data set, we remember where each structure ended up, so we can make relative fixups to all the pointers
	std::map<PtrType, int> addressToIndex;

	// Walk all the structs and concatenate all the structs into a single block.
	for (unsigned int i=0; i<mStructInfo.size(); i++)	
	{
		StructContents &sc = mStructInfo[i];
		addressToIndex[sc.mStartAddr] = block.size();  // remember where this struct starts
		std::copy(sc.mData.begin(), sc.mData.end(), std::back_inserter(block));  // concatenate this chunk to the end of the block
	}

	// finally, fixup all the pointers
	unsigned int pointerCount = 0;
	for (unsigned int i=0; i<mStructInfo.size(); i++)	
	{
		StructContents &sc = mStructInfo[i];
		int const startOfStruct = addressToIndex[sc.mStartAddr];
		for (unsigned j=0; j<sc.mPointerLocations.size(); j++)
		{
			PtrType ptr = sc.mPointerLocations[j];

			// determine where the pointer is stored in the data block
			int const indexToPointerStorage = startOfStruct + (ptr - sc.mStartAddr);

			// find out the index of where the pointer points TO in the data block.  If LookupPointerTarget fails, it's because
			// the pointer points to some structure that was not written out, or not entirely written out.
			PtrType const addressPointedTo = ptr ? *(PtrType*)ptr : NULL;
			StructContents *target = LookupPointerTarget(addressPointedTo);
			int const indexToTarget = target ? addressToIndex[target->mStartAddr] + addressPointedTo - target->mStartAddr : indexToPointerStorage;  // null points to itself

			// write out the offset in bytes from the pointer to the target
			int const relOffset = indexToTarget - indexToPointerStorage;
			::Overwrite4(relOffset, block, indexToPointerStorage, mByteSwap);

			// add this pointer location to the fixup table at the top of the file
			int const fixupAddr = startOfPointers + pointerCount*sizeof(PtrType);
			int const pointerOffset = indexToPointerStorage - fixupAddr;
			::Overwrite4(pointerOffset, block, fixupAddr, mByteSwap);			

			pointerCount++;
		}
	}
	assert(pointerCount==numPointers);  // basic sanity check

	// finally, write out the strings for assets and hook up the pointers for assets in the asset table
	for (unsigned int i=0; i<mAssets.size(); i++)
	{
		// write a relative pointer to the string name of the asset, which we're appending to the end of the block
		int const stringPtrIndex = startOfAssets + i*2*sizeof(PtrType);
		int const stringOffset = block.size() - stringPtrIndex;
		::Overwrite4(stringOffset, block, stringPtrIndex, mByteSwap);					

		// write out the string name of the asset
		int const stringLength = mAssets[i].mName.size()+1;  // null terminate it
		for (int j=0; j<stringLength; j++)
		{
			unsigned char d = mAssets[i].mName.c_str()[j];
			block.push_back(d);
		}

		// patch up the asset pointer too
		int const assetIndex = startOfAssets + (i*2+1)*sizeof(PtrType);
		int const assetOffset = addressToIndex[mAssets[i].mAddress] - assetIndex;
		::Overwrite4(assetOffset, block, assetIndex, mByteSwap);
	}

	return block;
}

//-------------------
