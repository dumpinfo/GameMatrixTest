//-------------------
// RuntimePatchSet.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef RUNTIMEPATCHSET_H
#define RUNTIMEPATCHSET_H

//-------------------

#include "TRelativePointer.h"

//-------------------
// This is a table of offsets to pointers that haven't been fixed up yet.
typedef TRelativePointer<intSZ> PointerPatchTable;

// This is a table of pointers to asset names and asset pointers
struct AssetTable
{
	TRelativePointer<char> mName;
	TRelativePointer<char> mAsset;  // this would be a template of type void, but void doesn't support operator* that the template expands...
};

//-------------------
// This is a pointer patch table.  It represents only the header data, which specifies
// how many pointers there are to fixup, and where the start of the array of pointers begins.
struct PointerPatchTableHeader
{
	int                                 mNumPointers;
	TRelativePointer<PointerPatchTable> mPatchTable;  // actually a pointer to an array of PPT entries

	int                                 mNumAssets;
	TRelativePointer<AssetTable>        mAssetTable;  // actually a pointer to an array of AssetTable entries
};

//-------------------
// This does all the fixup work.
void  DoFixups(PointerPatchTableHeader *header);

// This scans the list of assets and returns the first match.
void *FindAssetByName(PointerPatchTableHeader *header, char const *name);

//-------------------

#endif
