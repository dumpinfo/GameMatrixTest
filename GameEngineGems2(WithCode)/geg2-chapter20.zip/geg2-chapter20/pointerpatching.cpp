//-------------------
// PointerPatching.cpp
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#include <assert.h>
#include <memory.h>
#include "TRelativePointer.h"
#include "ToolsTimeWriter.h"
#include "RuntimePatchSet.h"

//-------------------

struct TPP_TestStruct
{
	float x;
	int   y;
};

//-------------------

struct TPP_EmbeddedInStruct
{
	TPP_TestStruct                   ts;
	TRelativePointer<TPP_TestStruct> pToStruct;  // this will point to 'ts'
};

//-------------------
// Test driven development makes for good usage documentation as well as a 
// solid test for class capabilities.
static void TestTRelativePointer(void)
{
	// These first tests are simply abusing the pointers.  
	// Anywhere a TRelativePointer is used, it should typically point to data
	// that is at a fixed offset in memory from the pointer.  So copying just the
	// pointer is meaningless--you have to copy ALL of the data, so what it points to
	// goes with it.  Otherwise you get a dangling pointer.
	float foo = 3.0f;
	float bar = 5.0f;

	// test trivial NULL constructor
	TRelativePointer<float> pToFloat0;
	assert(pToFloat0==0);

	// test simple constructor
	TRelativePointer<float> pToFloat1(&foo);
	assert(*pToFloat1 == 3.0f);
	
	// test copy construction maintains relative address.  foo is NOT the same
	// distance from the temporary as it is from the new variable.
	TRelativePointer<float> pToFloat2 = TRelativePointer<float>(&foo);
	// on MSVC2005, this actually calls the constructor (T *p) rather than create a temporary and call the copy constructor
	assert(pToFloat2.GetPointer()==&foo);  

	// test assignment
	pToFloat2 = &bar;
	assert(*pToFloat2 == 5.0f);

	// test assignment, which should end up with them pointing at different physical addresses,
	// but both point away from themselves by the same number of bytes 
	TRelativePointer<float> pToFloat3 = pToFloat2;
	assert(pToFloat3.GetPointer()!=pToFloat2.GetPointer());

	// but explicit assignment to the pointer will of course work
	TRelativePointer<float> pToFloat4(pToFloat2.GetPointer());
	assert(*pToFloat4 == 5.0f);	

	// test equality operators for the raw pointer value
	assert(pToFloat4 == &bar);	
	assert(&bar == pToFloat4);

	// test equality operators for the patched pointer types as well
	assert(pToFloat4 == pToFloat2);
	assert(*pToFloat4 == *pToFloat2);

	//-------------------
	// Test with non-POD data
	TPP_TestStruct ts;
	ts.x = 3.14159f;
	ts.y = -7;
	
	TRelativePointer<TPP_TestStruct> pToStruct1(&ts);
	assert(pToStruct1->x==3.14159f);

	//-------------------
	// Test when the pointer points relatively to something within a contiguous block
	TPP_EmbeddedInStruct eis1;
	eis1.ts.x = 12345.6789f;
	eis1.ts.y = 777;
	eis1.pToStruct = &eis1.ts;

	// Note, this uses the copy constructor, but since the pointer assumes that all data it points to is
	// RELATIVE to itself, it will point at the 'ts' in the destination copy, not the source.
	TPP_EmbeddedInStruct eis2 = eis1;
	assert(eis2.pToStruct==&eis2.ts);

	// Same thing would happen if you just block copy it around.
	memcpy(&eis2, &eis1, sizeof(eis1));
	assert(eis2.pToStruct==&eis2.ts);
}

//-------------------

struct Node
{
	Node(float v) : mLeft(NULL), mRight(NULL), mValue(v) {}

	Node *mLeft;
	Node *mRight;
	float mValue;
};

static void WriteTree(Node *n, ToolsTimeWriter &ttw)
{
	ttw.StartStruct(n);
		ttw.WritePtr();
			if (n->mLeft)
				WriteTree(n->mLeft, ttw);  // these calls could be interleaved with writes or not.  System handles either method.
		ttw.WritePtr();
			if (n->mRight)
				WriteTree(n->mRight, ttw);
		ttw.Write4();
	ttw.EndStruct();
}

static void TestWriting(void)
{
	// First, we construct a big bunch of nodes that all kind of interconnect.
	Node *root = new Node(3.14159f);
	root->mLeft = new Node(5.0f);
	root->mRight = new Node(777.0f);
	root->mLeft->mRight = new Node(1.0f);
	root->mLeft->mRight->mLeft = new Node(0.01f);

	//-------------------
	ToolsTimeWriter ttw(false);
	ttw.StartAsset("TreeOfNodes", root);
	WriteTree(root, ttw);
	std::vector<unsigned char> packedData = ttw.Finalize();

	//-------------------
	// Try patching it and getting our tree back in a single memory efficient block
	void *dataBlock = &packedData[0];  // this is kind of how you'd get it from disk
	DoFixups((PointerPatchTableHeader*)dataBlock);
	Node *packedRoot = (Node*)FindAssetByName((PointerPatchTableHeader*)dataBlock, "TreeOfNodes");
	// set a breakpoint here and notice how "root" and "packedRoot" are two identical structures, only
	// packedRoot is all tidied up into a single contiguous block of memory!
}

//-------------------

void main(void)
{
	TestTRelativePointer();
	TestWriting();
}

//-------------------
