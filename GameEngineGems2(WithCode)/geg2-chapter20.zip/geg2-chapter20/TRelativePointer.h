//-------------------
// TRelativePointer.h
// Jason Hughes
// Copyright 2010
// Steel Penny Games
//-------------------

#ifndef TRELATIVEPOINTER_H
#define TRELATIVEPOINTER_H

//-------------------
// Minor assurance that the intSZ type is set correctly for the compilation target.
#define COMPILE_TIME_ASSERT(expression) typedef char _CTA_ ## __LINE__[(expression)?1:-1]
typedef __int32 intSZ;  // redefine this to a 32-bit integer for your platform

// The purpose of the TRelativePointer is to impersonate a standard pointer type,
// but actually stores an OFFSET rather than an actual pointer to data, so that
// it is completely relocatable.
template <typename T>
class TRelativePointer
{
public:
	COMPILE_TIME_ASSERT(sizeof(intSZ) == sizeof(T*));

	// when constructing these manually in code, they immediately convert to a 
	// relative representation.  When reading these in from disk, constructors
	// are not called, meaning it must be stored as relative on disk.
	explicit TRelativePointer(T *p); // without explicit, the operator== is ambiguous
	TRelativePointer(void);          // points to NULL by default

	// *** Note: The copy constructor does not attempt to recompute or fixup anything.
	// The assumption is that a pointer is pointing to data in a fixed chunk relative
	// to the pointer itself.  There's no way to verify this in code, so you have to
	// just be vigilant that you don't abuse it.  Otherwise you WILL have dangling pointers.
	TRelativePointer(TRelativePointer<T> const &p);

	// assignment operators
	TRelativePointer<T> &operator=(T *p);
	TRelativePointer<T> &operator=(TRelativePointer<T> &p);	

	// casting operators allow this to look and feel like type T* most of the time
	operator T         *(void);
	operator T const   *(void) const;

	// allow caller to dereference this like a normal pointer
	T       *operator-> (void);
	T const *operator-> (void) const;

	// equality operators
	bool     operator== (TRelativePointer<T> const &p) const;

	// real work of constructing the final pointer happens here
	T       &GetReference(void) const      { return *GetPointer();               }
	T const &GetReference(void)            { return *GetPointer();               }
	T       *GetPointer  (void)            { return (T*)((intSZ)this + mOffset); }
	T const *GetPointer  (void) const      { return (T*)((intSZ)this + mOffset); }

private:
	// mOffset must be exactly the same size as a real pointer, 
	// allowing the easy insertion/removal of this type 
	// without changing structure memory layouts!
	// mOffset as a signed integer value that is added to "this" to calculate the 
	// actual pointer wherever this pointer is in a structure.  intSZ needs to match
	// the bit size of the pointer type, or bad things happen.  Hence the CTA above.
	intSZ  mOffset;
};

//-------------------

template <typename T>
inline TRelativePointer<T>::TRelativePointer(T *p) 
{
	// do the subtraction as signed integers
	mOffset = ((intSZ)p - (intSZ)this);  
}

template <typename T>
inline TRelativePointer<T>::TRelativePointer(void) 
{
	// negating this means the result of pointer computation is zero, or NULL.
	mOffset = -(intSZ)this;
}

template <typename T>
inline TRelativePointer<T>::TRelativePointer(TRelativePointer<T> const &p)
{
	// straight copy means make the destination pointer relative in the same way as the source
	mOffset = p.mOffset;  
}

template <typename T>	
inline TRelativePointer<T> &TRelativePointer<T>::operator=(T *p)
{
	// do the subtraction as signed integers
	mOffset = ((intSZ)p - (intSZ)this);  
	return *this;
}

template <typename T>	
inline TRelativePointer<T> &TRelativePointer<T>::operator=(TRelativePointer<T> &p) 
{
	// straight copy means make the destination pointer relative in the same way as the source
	mOffset = p.mOffset;
	return *this;	
}

template <typename T>
inline TRelativePointer<T>::operator T*(void)
{
	return GetPointer();
}

template <typename T>
inline TRelativePointer<T>::operator T const *(void) const
{
	return GetPointer();
}

template <typename T>
inline T *TRelativePointer<T>::operator->(void)
{
	return GetPointer();
}

template <typename T>	
inline T const *TRelativePointer<T>::operator->(void) const
{
	return GetPointer();
}

template <typename T>	
inline bool TRelativePointer<T>::operator==(TRelativePointer<T> const &p) const
{
	return GetPointer()==p.GetPointer();
}

//-------------------

#endif
