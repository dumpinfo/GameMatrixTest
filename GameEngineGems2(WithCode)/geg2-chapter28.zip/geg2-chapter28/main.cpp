/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#include "stdafx.h"

int SortTest_GEG();

int _tmain(int argc, _TCHAR* argv[])
{
	int result = SortTest_GEG();

	return result;
}
