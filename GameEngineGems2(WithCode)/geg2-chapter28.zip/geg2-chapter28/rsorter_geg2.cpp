/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */

#include "stdafx.h"
#include <malloc.h>
#include <assert.h>
#include <crtdbg.h>
#include <algorithm>

#include "rsorter_geg2.h"
#include "loser4.h"
#include "herf.h"			//M.Herf's radix-2048 sort + my optimized radix-256 adaption

#define USECPUID	1		//use cpuid() to get the cache characteristics
#define CHKIINV		0		//check to see if our sort has bugs or not

#define ENABLEHEAPCHK	1
#if ENABLEHEAPCHK
#define CHECKHEAP _CrtCheckMemory()
#else
#define CHECKHEAP
#endif


#if USECPUID
#include "utils/cpuid.h"
#endif

//some defaults to avoid calling CPUId:
static const size_t kDefL1CacheSize = 32*1024;
static const size_t kDefL2CacheSize = 4*1024*1024;
static const size_t kDefL3CacheSize = 0;
static const size_t kDefL2CacheLineSize = 64;

using namespace GEG2;

GEG2::RadixSorter::RadixSorter()
: m_count(0), m_inited(false),
  m_L1CacheSize(kDefL1CacheSize),
  m_L2CacheSize(kDefL2CacheSize),
  m_L3CacheSize(kDefL3CacheSize),
  m_L2CacheLineSize(kDefL2CacheLineSize)
{
	size_t reserve = 1024*4;	//reserve some cache space for general use
	const size_t kElemSize = sizeof(float) + sizeof(size_t);
#if USECPUID
	const GEG2::CPUId& cpuid = GEG2::GetCPUId();
	const GEG2::CacheTLB& cacheTLB = cpuid.GetCacheTLB();
	m_L1CacheSize	  = cacheTLB.m_L1DCache.m_size;
	m_L2CacheSize	  = cacheTLB.m_L2Cache.m_size;
	m_L3CacheSize	  = cacheTLB.m_L3Cache.m_size;
	m_L2CacheLineSize = cacheTLB.m_L2Cache.m_linesize;
#endif
	//compute the size of each substream
	m_inCache = (m_L2CacheSize - reserve)/(kElemSize);		//TODO: generalize
	m_inCache /= (U32)kNumThreads;

	for (size_t t=0; t < kNumThreads; t++) {
		m_temp[t] = 0;
		m_blockSizes[t] = 0;
	}
	m_outbuf = 0;

	assert( kStreams == kNumThreads );
};

GEG2::RadixSorter::RadixSorter( int count ) : m_count(0), m_inited(false)
{
	for (size_t t=0; t < kNumThreads; t++) {
		m_temp[t] = 0;
		m_blockSizes[t] = 0;
	}
	m_outbuf = 0;

	Resize(count);
}

GEG2::RadixSorter::~RadixSorter()
{
	Clear();
}

void GEG2::RadixSorter::Clear()
{
	for (size_t t=0; t < kNumThreads; t++) {
		if (m_temp[t] != 0) {
			//_aligned_free(m_temp[t]);	m_temp[t] = 0; 
		}
	}
	_aligned_free( m_outbuf );	m_outbuf = 0;
}

void RadixSorter::Resize( int count ) 
{
	if (m_count != count) {
		_aligned_free( m_outbuf );	m_outbuf = 0;
	}
	int perThreadCnt = (count + kNumThreads-1) / kNumThreads;

	for (size_t t=0; t < kNumThreads; t++) {
		if (m_temp[t] == 0) {
			//m_temp[t] = (float*)_aligned_malloc( sizeof(float)*perThreadCnt, 64 );
		}
	}
	if (m_outbuf == 0) {
		m_outbuf = (float*)_aligned_malloc( sizeof(float)*count, 64 );
	}
	m_count = count;
}

static bool CheckInversions( const float* input, size_t len )
{
	for (size_t i=1; i < len; i++) {
		if (input[i-1] > input[i]) {
			return false;
		}
	}
	return true;
}

///initialize the sorter for 'values' :
void GEG2::RadixSorter::SortInit( float* values, int count )
{
	if ((values == 0) || (count == 0))
		return;
	Resize(count);

	//0: compute # of merge passes needed based on what will fit in cache
	static const U32 blocks = DATA::LoserTree4::kStreams;		//4
	U32 todo = count;
	float* values_p = values;
	float* out_p    = m_outbuf;

	const U32 bsize = count / blocks;
	const U32 slack = count - (bsize*blocks);

	//1: break input into blocks that fits into L2 cache
	for (size_t b=0; b < blocks; b++) {
		U32 bsize1 = bsize + (b < slack ? 1 : 0);
		
		m_streams[b] = values_p;			//record these so that we can find the substreams easier
		m_blockSizes[b] = bsize1;			//record these so that we can find the substreams easier
		m_temp[b]	 = out_p;				//work-buffer needed by the radix-sort phase running concurrently

		values_p += bsize1;
		out_p	 += bsize1;
		todo -= bsize1;
	}
	assert(m_blockSizes[0] == m_blockSizes[3]);		//TODO: assumes input divisibe by 4 

	Resize(count);

	m_inited = true;
}

///sort sub-stream 's':
void GEG2::RadixSorter::SortStream( int s )
{
	assert( m_inited );
	if (!m_inited)
		return;
	U32 bsize1 = m_blockSizes[s];
	float* values_p = m_streams[s];

	HERF::RadixSort8( values_p, m_temp[s], bsize1 );
	//std::sort( values_p, values_p + bsize1 );

#if CHKIINV
	bool result = ::CheckInversions( values_p, bsize1 );
	if (!result) {
		assert(0);
	}
#endif
	CHECKHEAP;
}

void GEG2::RadixSorter::MergeStreams()
{
	//2: use loser-tree to merge the 4-substreams:
	DATA::LoserTree4 loser;
	assert(m_blockSizes[0] == m_blockSizes[3]);		//TODO: assumes input divisibe by 4 

	float* ostream2 = (float*)m_temp[0];
	loser.Merge( m_streams, m_blockSizes, ostream2 );

	CHECKHEAP;
}
