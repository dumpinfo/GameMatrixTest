/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#ifndef MSVC_H
#define MSVC_H

#include <vector>
#include <math.h>

#if defined(_MSC_VER)
#include <float.h>   // isnan is not in the same lib under unix as windows
#include <malloc.h>  // _alloca

#pragma warning (disable: 4324)  // ignore declspec(align) padding warnings
#pragma warning (disable: 4996)  // ignore functions declared as 'deprecated'

#define FASTCALL   __fastcall
#define ALLOCA(sn) _alloca(sn)
#define FORCEINLINE __forceinline
#define NOINLINE __declspec(noinline)
#define VSNPRINTF    _vsnprintf

#define DLLENTRY  __declspec(dllimport)
#define DLLEXPORT __declspec(dllexport)

/// support for __restrict keyword, only for compilers that support it
#if _MSC_VER >= 1400
	#define RESTRICT __restrict
#else
	#define RESTRICT
#endif

//-------------------

#else
#include <math.h>          //isnan

#define FASTCALL
#define ALLOCA(sn) alloca(sn);
#define FORCEINLINE __inline
#define VSNPRINTF    vsnprintf

//gcc   #define FASTCALL __attribute__((stdcall, regparm(3)))

//-------------------
// On non-msvc compilers, this just calls clear for you
template <typename T>
void ClearVector(std::vector<T> &v)
{
    v.clear();
}

/// support for __restrict keyword, only for compilers that support it
#define RESTRICT

//-------------------

#endif

#endif
