/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 */
#ifndef BASICTYPES_H
#define BASICTYPES_H

typedef unsigned char         Byte;
typedef unsigned char         U8;
typedef signed char           I8;
typedef unsigned short        U16;
typedef signed short          I16;
typedef unsigned int          U32;
typedef signed int            I32;
typedef unsigned __int64      U64;
typedef signed __int64        I64;
typedef float                 F32;
typedef double                F64;

typedef unsigned int          U32F;
typedef signed int            I32F;

#endif
