herf8.cpp - my optimized version of Herf's radixsort
herf.cpp  - Michael Herf's original source for radixsort for reference
loser.h   - my implementation of Knuth's Loser-tree
main.cpp  -
rsorter_geg2.cpp/h - the main class for our cache-aware hybrid sorter
sorttest_geg2.cpp  - the testing driver and sample multi-threaded usage
stdafx.cpp/h - precompiled headers
utils/    - utilization for threading, cpuid, performance counter etc.
----------------


Manchor Ko
9/1/2010
mannyk90@yahoo.com
