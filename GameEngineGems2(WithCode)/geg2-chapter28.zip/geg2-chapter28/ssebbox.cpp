/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 */


#include "stdafx.h"
#include <assert.h>
#include <stdio.h>

#include "ssebbox.h"

using namespace SSE;


SSE::AABB* SSE::LoadBoxes( size_t* len, const char* fileName )
{
	FILE *inFile;	fopen_s( &inFile, fileName, "rb");
	if ( !inFile ) {
		printf("could not open file: %s\n", fileName);
		*len = 0;
		return 0;
	}
	fseek(inFile, 0, SEEK_END);
	unsigned __int32 size = (unsigned __int32)(ftell(inFile)/sizeof(SSE::AABB));
	rewind(inFile);

	SSE::AABB* boxes = (SSE::AABB*)_aligned_malloc( size*sizeof(SSE::AABB), 16 );
	fread(boxes, sizeof(SSE::AABB), size, inFile);
	fclose(inFile);
	*len = size;
	
	return boxes;
}

