/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#include "stdafx.h"

#include <stdio.h>
#include <algorithm>
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#include "rsorter_geg2.h"

#include "ssebbox.h"

#include "utils/cpuid.h"
#include "utils/perf.h"
#include "utils/thread.h"
//#include "herf.h"				//Michael Herf's original source


#define SINGLETHREAD	0		//use single-threaded or 'kNumThreads'

#define USEGEG2			1
#define CHECKINV		0
#define FOURSUBLISTS	0

static const int kNumThreads = 4;

using namespace SSE;

inline void CopyNTA( void* dst, const void* src, size_t count ) {
	memcpy( dst, src, count * 4 );
}

class KDTreeBuilder2 {
public:
	KDTreeBuilder2();
	~KDTreeBuilder2();

	bool LoadBBoxes( const char * filen );
	void MakeHiLoLists( const SSE::AABB* bboxes, size_t numtris );

	float*	GetXMins() const { return m_loLists[0]; }
public:
	SSE::AABB*	m_bboxes;
	size_t		m_numTris;
	float*		m_loLists[1];	//!< lo(x/y/z) sorted extremas of tris

	size_t		m_L2CacheSize;
	size_t		m_L2CacheLineSize;
};

struct ThreadContext {
	explicit ThreadContext() : m_event(0), m_radixSorter(0) {}
	ThreadContext(
		int instance,
		MT::EventHandle sevent, 
		MT::CountMutexed* completion,
		MT::EventHandle syncevent, 
		GEG2::RadixSorter*	radixSorter
	) : m_instance(instance), m_startEvent(sevent), m_completion(completion), m_event(syncevent), m_radixSorter(radixSorter) {} 

	void Reset() { m_completion->Reset(); }

	int					m_instance;			//!< instance id
	MT::EventHandle		m_startEvent;		//!< event to signal start
	MT::CountMutexed*	m_completion;		//!< completion count
	MT::EventHandle		m_event;			//!< event to sync with main thread
	GEG2::RadixSorter*	m_radixSorter;		//!< the work horse
};


static const char* gFileNameBoxes = "data/dragon-boxes-centered";
static size_t g_L2CacheSize	    = 0;
static size_t g_L2CacheLineSize = 0;



static float* GetXMins( const SSE::AABB* bboxes, size_t len )
{
	float* vals = (float*)_aligned_malloc( sizeof(float)*len, 16 );
	float* vp = vals;

	for (size_t i=0; i < len; i++) {
		*vp++ = bboxes[i].m_min.m_c[1] * 10.f;
	}
	return vals;
}

static void Extract( float* seq, const float* values, const size_t* sorted, size_t len )
{
	for (size_t i=0; i < len; i++) {
		seq[i] = values[sorted[i]];
	}
}
KDTreeBuilder2::KDTreeBuilder2() : m_bboxes(0), m_numTris(0)
{
	const GEG2::CPUId& cpuid = GEG2::GetCPUId();
	const GEG2::CacheTLB& cacheTLB = cpuid.GetCacheTLB();
	const GEG2::CacheDesc& tlb = cacheTLB.m_TLBCache;

	m_L2CacheSize	  = cacheTLB.m_L2Cache.m_size;
	m_L2CacheLineSize = cacheTLB.m_L2Cache.m_linesize;

	for (int a=0; a < 1; a++) {
		m_loLists[a] = 0;
	}
}

KDTreeBuilder2::~KDTreeBuilder2()
{
	for (int a=0; a < 1; a++) {
		_aligned_free(m_loLists[a]);
	}
}

static SSE::AABB* LoadBoxes( size_t* len, const char* fileName )
{
	FILE *inFile;	fopen_s( &inFile, fileName, "rb");
	if ( !inFile ) {
		printf("could not open file: %s\n", fileName);
		*len = 0;
		return 0;
	}
	fseek(inFile, 0, SEEK_END);
	unsigned __int32 size = (unsigned __int32)(ftell(inFile)/sizeof(SSE::AABB));
	rewind(inFile);

	SSE::AABB* boxes = (SSE::AABB*)_aligned_malloc( size*sizeof(SSE::AABB), 16 );
	fread(boxes, sizeof(SSE::AABB), size, inFile);
	fclose(inFile);
	*len = size;
	
	return boxes;
}

bool KDTreeBuilder2::LoadBBoxes( const char * filen )
{
	m_bboxes = ::LoadBoxes( &m_numTris, gFileNameBoxes );
	bool result = (m_bboxes != 0);
	if (result) {
	}
	return result;
}

///make the indirect HiLo lists - m_indices only
void KDTreeBuilder2::MakeHiLoLists( const SSE::AABB* bboxes, size_t numtris )
{
	m_numTris = numtris;

	for (int a=0; a < 1; a++) {
		m_loLists[a] = (float*)_aligned_malloc( sizeof(float) * m_numTris, m_L2CacheLineSize );
	}
	//1: make lo..hi lists from bboxes
	for (size_t t=0; t < m_numTris; t++) {
		const SSE::AABB& ab = bboxes[t];
		for (int a=0; a < 1; a++) {
			m_loLists[a][t] = ab.GetMin(a);
		}
	}
}

U32 __stdcall ThreadCallback ( void* lpParameter )
{
	assert( lpParameter != 0 );
	ThreadContext* threadContext = (ThreadContext*)lpParameter;

	while (true) {
		//0: wait for start event
		MT::MiWaitForMultipleEvents( &threadContext->m_startEvent, 1 );
		//1: do the work
		threadContext->m_radixSorter->SortStream( threadContext->m_instance );
		//2: atomic-inc completion count
		int completed = threadContext->m_completion->Inc();
		//3: signal completion
		if (completed == GEG2::RadixSorter::kNumThreads) {
			MT::MiSetEvent( threadContext->m_event );
		}
	}
	return 0;
}

GEG2::RadixSorter s_radixSorter_geg;

int SortTest_GEG()
{
	PerfCounter perf;
	KDTreeBuilder2 kdbuilder;

	assert( kNumThreads == GEG2::RadixSorter::kNumThreads );
	if (kNumThreads != GEG2::RadixSorter::kNumThreads) {
		printf("Only %d threads is supported.\n", GEG2::RadixSorter::kNumThreads);
		return 1;
	}
	//SSE::Init();

	bool loaded = kdbuilder.LoadBBoxes( gFileNameBoxes );
	if (!loaded) {
		printf("Cannot load bboxes %s", gFileNameBoxes);
		return 1;
	}
	size_t len = kdbuilder.m_numTris; 

	kdbuilder.MakeHiLoLists( kdbuilder.m_bboxes, len );

	//multi-threading code:
	MT::CountMutexed completion;
	ThreadContext threadContexts[kNumThreads];
	MT::EventHandle syncEvent = MT::MiCreateAutoEvent(false);

	MT::ThreadHdl threadIds[kNumThreads];

	for (int t=0; t < kNumThreads; t++) {
		MT::EventHandle sEvent = MT::MiCreateAutoEvent(false);		//create an auto-reset event for each worker thread

		//create a thread-context object and pass our sorter. Notice all threads shares the 
		//same sorter since all the sub-streams and working storage are setup for multi-threaded 
		//execution without synchronization
		threadContexts[t] = ThreadContext( t, sEvent, &completion, syncEvent, &s_radixSorter_geg );
		threadIds[t] = MT::MiCreateThread( ThreadCallback, (void*)&threadContexts[t] );
	}
	int trials = 1;		//set to more than 1 for in-cache perf and to stabilize stat

#if SINGLETHREAD
	perf.Start();

	s_radixSorter_geg.SortInit( kdbuilder.m_loLists[0], kdbuilder.m_numTris );
	for (int s=0; s < GEG2::RadixSorter::kNumThreads; s++) {		//
		s_radixSorter_geg.SortStream( s );
	}
	s_radixSorter_geg.MergeStreams();
#else
	for (int t=0; t < GEG2::RadixSorter::kNumThreads; t++) {
		MT::MiResumeThread(threadIds[t]);
	}
	perf.Start();

	for (int t=0; t < trials; t++) {
		s_radixSorter_geg.SortInit( kdbuilder.m_loLists[0], kdbuilder.m_numTris );

		//1: go go - fire the threads
		for (int t=0; t < GEG2::RadixSorter::kNumThreads; t++) {
			MT::MiSetEvent( threadContexts[t].m_startEvent );
		}
		//2: wait for all the worker threads to finish sorting the sub-streams
		MT::MiWaitForMultipleEvents( &syncEvent, 1 );

		//3: all the sub-streams are sorted, we now use the loser-tree to merge
		s_radixSorter_geg.MergeStreams();

		completion.Reset();
	}
#endif
	PerfCounter::CounterT sorttime = perf.End();
	printf("Sort time %.3f", PerfCounter::MilliSecsF(sorttime/trials) );

#if (SINGLETHREAD == 0)
	for (int t=0; t < GEG2::RadixSorter::kNumThreads; t++) {
		MT::MiDestroyThread(threadIds[t]);
	}
#endif
	return 0;
}

