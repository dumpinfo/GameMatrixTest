// Radix.cpp: a fast floating-point radix sort demo
//
//   Copyright (C) Herf Consulting LLC 2001.  All Rights Reserved.
//   Use for anything you want, just tell me what you do with it.
//   Code provided "as-is" with no liabilities for anything that goes wrong.
//

//
// Edit History:
//	 Place Herf's orignal code into a namespace HERF - mck.
//	 Use #if HERF_V to control Herf's original radix-256 sorter and my faster version - mck.
//

#include <algorithm>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>


#include "herf.h"

#define	HERF_V	0		//1: a direct adaption of Herf's radix-2048 routine
						//0: my optimized radix-256 version

using namespace HERF;

// ------------------------------------------------------------------------------------------------
// ---- Basic types

typedef double real64;
typedef unsigned char uint8;
typedef const char *cpointer;

// ------------------------------------------------------------------------------------------------
// Configuration/Testing

// ---- number of elements to test (shows tradeoff of histogram size vs. sort size)
const uint32 ct = 65536;

// ---- really, a correctness check, not correctness itself ;)
#define CORRECTNESS 1

// ---- use SSE prefetch (needs compiler support), not really a problem on non-SSE machines.
//		need http://msdn.microsoft.com/vstudio/downloads/ppack/default.asp
//		or recent VC to use this

#define PREFETCH 1

#if PREFETCH
#include <xmmintrin.h>	// for prefetch
#define pfval	64
#define pfval2	128
#define pf(x)	_mm_prefetch(cpointer(x + i + pfval), 0)
#define pf2(x)	_mm_prefetch(cpointer(x + i + pfval2), 0)
#else
#define pf(x)
#define pf2(x)
#endif

// ------------------------------------------------------------------------------------------------
// ---- Visual C++ eccentricities

#if _WINDOWS
#define finline __forceinline
#else
#define finline inline
#endif

typedef __int32 index_t;		//for 64b we might want to try __int64
typedef unsigned char byte;

//radix loop for directly sorting values
__forceinline void ScatterLoop2( 
	float* __restrict output,		//Out: buffer 
	const float* __restrict input,	//In: input 
	index_t* __restrict counts,		//In: counts 
	const index_t r,				//In: active byte (radix)
	const index_t numElements		//In: length of input
)
{
	output += numElements;
	input  += numElements;
	const byte* __restrict iptr = ((const byte*)input) + r;	//input ptr -> the radix digit
	index_t i = -numElements;
	for (; i != 0; i++) {
		const index_t rdigit = *(const byte*)((const float*)iptr + i);
		const index_t finalpos = counts[rdigit];
		counts[rdigit] = finalpos + 1;
		output[finalpos] = input[i];
	}
}

// ================================================================================================
// flip a float for sorting
//  finds SIGN of fp number.
//  if it's 1 (negative float), it flips all bits
//  if it's 0 (positive float), it flips the sign only
// ================================================================================================
finline uint32 FloatFlip(uint32 f)
{
	uint32 mask = -int32(f >> 31) | 0x80000000;		//Herf's orginal formulation
	return f ^ mask;
}

finline void FloatFlipXHerf(uint32 &f)
{
	uint32 mask = -int32(f >> 31) | 0x80000000;
	f ^= mask;
}

finline void FloatFlipX(int32 &f)
{
	int32 mask = int32(f >> 31) | 0x80000000;		//Hunt's sign-extension optimization
	f ^= mask;
}

// ================================================================================================
// flip a float back (invert FloatFlip)
//  signed was flipped from above, so:
//  if sign is 1 (negative), it flips the sign bit back
//  if sign is 0 (positive), it flips all bits back
// ================================================================================================
finline uint32 IFloatFlipHerf(uint32& f)
{
	uint32 mask = ((f >> 31) - 1) | 0x80000000;	//Herf's orginal formulation
	return f ^ mask;
}

finline void IFloatFlip(uint32& f)
{
	f ^= (int32(f^0x80000000) >> 31)|0x80000000;	//Hunt's sign-extension optimization
}

static void ReverseBitHack( float* a, const __int32 size )
{
	int32* v = (int32*)(a);
	for ( index_t i = 0; i != size ; i++ )
		IFloatFlip( *(uint32*)&v[i]);
}

// ---- utils for accessing 8-bit quantities
#define _0(x)	(x & 0xFF)
#define _1(x)	(x >>  8 & 0xFF)
#define _2(x)	(x >> 16 & 0xFF)
#define _3(x)	(x >> 24)

// ================================================================================================
// Main radix sort
// ================================================================================================
#if HERF_V
void HERF::RadixSort8(real32 *farray, real32 *sorted, uint32 elements)
{
	uint32 i;
	uint32 *sort = (uint32*)sorted;
	uint32 *array = (uint32*)farray;

	// 3 histograms on the stack:
	const uint32 kHist = 256;
	uint32 b0[kHist * 4];

	uint32 *b1 = b0 + kHist;
	uint32 *b2 = b1 + kHist;
	uint32 *b3 = b2 + kHist;

	for (i = 0; i < kHist * 4; i++) {
		b0[i] = 0;
	}
	//memset(b0, 0, kHist * 12);

	// 1.  parallel histogramming pass
	//
	for (i = 0; i < elements; i++) {
		pf(array);

		uint32 fi = FloatFlip((uint32&)array[i]);
		//FloatFlipX((uint32&)array[i]);
		//uint32 fi = array[i];

		b0[_0(fi)] ++;
		b1[_1(fi)] ++;
		b2[_2(fi)] ++;
		b3[_3(fi)] ++;
	}
	
	// 2.  Sum the histograms -- each histogram entry records the number of values preceding itself.
	{
		uint32 sum0 = 0, sum1 = 0, sum2 = 0, sum3 = 0;
		uint32 tsum;
		for (i = 0; i < kHist; i++) {

			tsum = b0[i] + sum0;
			b0[i] = sum0 - 1;
			sum0 = tsum;

			tsum = b1[i] + sum1;
			b1[i] = sum1 - 1;
			sum1 = tsum;

			tsum = b2[i] + sum2;
			b2[i] = sum2 - 1;
			sum2 = tsum;

			tsum = b3[i] + sum3;
			b3[i] = sum3 - 1;
			sum3 = tsum;
		}
	}

	// byte 0: floatflip entire value, read/write histogram, write out flipped
	for (i = 0; i < elements; i++) {

		uint32 fi = array[i];
		FloatFlipXHerf(fi);
		uint32 pos = _0(fi);
		
		pf2(array);
		sort[++b0[pos]] = fi;
	}

	// byte 1: read/write histogram, copy
	//   sorted -> array
	for (i = 0; i < elements; i++) {
		uint32 si = sort[i];
		uint32 pos = _1(si);
		pf2(sort);
		array[++b1[pos]] = si;
	}

	// byte 2: read/write histogram, copy & flip out
	//   array -> sorted
	for (i = 0; i < elements; i++) {
		uint32 ai = array[i];
		uint32 pos = _2(ai);

		pf2(array);
		sort[++b2[pos]] = (ai);
	}

	// byte 3: read/write histogram, copy
	//   sorted -> array
	for (i = 0; i < elements; i++) {
		uint32 si = sort[i];
		uint32 pos = _3(si);
		pf2(sort);
		array[++b3[pos]] = IFloatFlipHerf(si);
	}
}
#else
void HERF::RadixSort8(real32 *farray, real32 *sorted, uint32 elements)
{
	uint32 i;
	uint32 *sort = (uint32*)sorted;
	uint32 *iarray = (uint32*)farray;

	for (i = 0; i < elements; i++) {
		FloatFlipX((int32&)iarray[i]);
	}
	// 3 histograms on the stack:
	const uint32 kHist = 256;			//radix-256
	uint32 histograms[kHist * 4];		//use signed arithmetic 

	uint32 *h0 = histograms + 0;
	uint32 *h1 = histograms + kHist;
	uint32 *h2 = histograms + kHist*2;
	uint32 *h3 = histograms + kHist*3;

	for (i = 0; i < kHist * 4; i++) {
		histograms[i] = 0;
	}
	// 1.  parallel histogramming pass
	for (i = 0; i < elements; i++) {
		pf(iarray);

		uint32 *a = iarray + i;
		uint32 fi = a[0];
		h0[_0(fi)] ++; h1[_1(fi)] ++;
		h2[_2(fi)] ++; h3[_3(fi)] ++;
	}
	// 2.  Sum the histograms -- each histogram entry records the number of values preceding itself.
	{
		int32 sum0, sum1, sum2, sum3;
		sum0 = sum1 = sum2 = sum3 = -(int32)elements;
		int32 tsum;
		for (i = 0; i < kHist; i++) {
			tsum = h0[i] + sum0;
			h0[i] = sum0;
			sum0 = tsum;

			tsum = h1[i] + sum1;
			h1[i] = sum1;
			sum1 = tsum;

			tsum = h2[i] + sum2;
			h2[i] = sum2;
			sum2 = tsum;

			tsum = h3[i] + sum3;
			h3[i] = sum3;
			sum3 = tsum;
		}
	}
	float* a = farray;
	float* b = sorted;
	index_t* counts = (index_t*)histograms;

	for ( index_t d = 0; d != 4; d += 1 ) {
		ScatterLoop2( b, a, counts, d, (index_t)elements);
		std::swap( a, b );
		counts += 0x100;
	}
	ReverseBitHack(a, elements);
}
#endif
