/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */

#include "stdafx.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "perf.h"

PerfCounter::CounterT PerfCounter::m_freq = 0;

PerfCounter::PerfCounter()
{
	if (m_freq == 0) {
		QueryPerformanceFrequency( (LARGE_INTEGER*)&m_freq );
	}
}

void PerfCounter::Start()
{
	QueryPerformanceCounter( (LARGE_INTEGER*)&m_start );
	m_end = m_start;
}

PerfCounter::CounterT PerfCounter::End()
{
	CounterT count;
	QueryPerformanceCounter( (LARGE_INTEGER*)&count );
	__int64 diff = count - m_end;	//compute delta from previous call
	m_end = count;
	//m_total += diff;
	return diff;
}

unsigned int PerfCounter::MilliSecs(CounterT count)
{
	const unsigned int msec = (unsigned int)((count * 1000) / m_freq);
	return msec;
}

float PerfCounter::MilliSecsF(CounterT count)
{
	const float msec = (float)(((double)count * 1000) / m_freq);
	return msec;
}
