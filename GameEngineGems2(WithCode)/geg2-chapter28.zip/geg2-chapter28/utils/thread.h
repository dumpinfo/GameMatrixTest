/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */

#ifndef THREAD_H
#define THREAD_H

#include "basictypes.h"

namespace MT {
	typedef void* ThreadHdl;
	typedef void* CriticalSection;
	typedef void* EventHandle;
	typedef void* MeteredSection;
	typedef U32 (__stdcall *ThreadFunc) ( void* lpParameter );

	/*!
	-- CountMutexed: a mutex protected counter.
	*/
	class CountMutexed {
	public:
		CountMutexed();
		~CountMutexed();

		void	Reset();
		long	Inc();
		long	Dec();
	public:
		CriticalSection		m_cs;
		long				m_count;
	};	//end of CountMutexed


	/*!
	-- ThreadPool: a pool of threads.
	*/
	class ThreadPool {
	public:
		explicit ThreadPool() : m_threads(0), m_numThreads() {} 
		ThreadPool(int nt);
		~ThreadPool();

		void	Clear();
		void	Init(int nt);
	public:
		ThreadHdl*	m_threads;
		int			m_numThreads;
	};

	/// machine independent way to create a thread
	ThreadHdl MiCreateThread( ThreadFunc func, void* userData );
	/// machine independent way to destroy a thread
	void MiDestroyThread( ThreadHdl hThread );
	/// machine independent way to resume a thread
	void MiResumeThread( ThreadHdl hThread );
	/// machine independent way to suspend a thread
	void MiSuspendThread( ThreadHdl hThread );

	/// machine independent way to create a critical section
	CriticalSection MiCreateCriticalSection();
	/// machine independent way to destroy a critical section
	void MiDestroyCriticalSection( CriticalSection cs );
	/// machine independent way to enter a critical section
	void MiEnterCriticalSection( CriticalSection cs );
	/// machine independent way to leave a critical section
	void MiLeaveCriticalSection( CriticalSection cs );

	///create an event object
	EventHandle MiCreateEvent(bool initState, bool manualReset = true);
	///create an auto-reset event object
	EventHandle inline MiCreateAutoEvent(bool initState) { return MiCreateEvent( initState, false ); }
	///destroy an event object 'e'
	void MiDestroyEvent(EventHandle e);
	///signal an event for 'e'
	void MiSetEvent(EventHandle e);
	///reset an event (set to clear):
	void MiResetEvent(EventHandle e);
	///wait for events[count] to all be signaled:
	void MiWaitForMultipleEvents( EventHandle* events, int count );

};	//end of namespace MT

#endif
