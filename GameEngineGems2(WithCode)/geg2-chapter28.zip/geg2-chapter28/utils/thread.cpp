/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 */

#include <assert.h>
#include <malloc.h>
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>

#include "thread.h"

//#include <psapi.h>

#define	CS		0		//use critical section or InterlockedExchange/Dec/Inc

using namespace MT;

MT::CountMutexed::CountMutexed() : m_cs(0), m_count(0)
{
#if CS
	m_cs = MT::MiCreateCriticalSection();
#endif
}

MT::CountMutexed::~CountMutexed()
{
	if (m_cs) {
		MT::MiDestroyCriticalSection( m_cs );	m_cs = 0;
	}
}

void MT::CountMutexed::Reset() {
#if CS
	MiEnterCriticalSection(m_cs);
	m_count = 0;
	MiLeaveCriticalSection(m_cs);
#else
	LONG count = 0;
	InterlockedExchange( &m_count, count );
#endif
}

long MT::CountMutexed::Inc() {
	long count;
#if CS
	MiEnterCriticalSection(m_cs);
	m_count += 1;
	count = m_count;
	MiLeaveCriticalSection(m_cs);
#else
	count = InterlockedIncrement( (LONG*)&m_count );
#endif
	return count;
}

long MT::CountMutexed::Dec() {
	long count;
#if CS
	MiEnterCriticalSection(m_cs);
	m_count -= 1;
	count = m_count;
	MiLeaveCriticalSection(m_cs);
#else
	count = InterlockedDecrement( (LONG*)&m_count );
#endif
	return count;
}

MT::ThreadPool::ThreadPool(int nt) : m_threads(0), m_numThreads(0)
{
	Init(nt);
}

MT::ThreadPool::~ThreadPool()
{
	Clear();
}

void MT::ThreadPool::Clear()
{
	for (int t=0; t < m_numThreads; t++) {
		MiDestroyThread( m_threads[t] );
	}
	delete [] m_threads;	m_threads = 0;
}

static U32 __stdcall ThreadCallback ( void* lpParameter )
{
	assert( lpParameter != 0 );
	//ThreadContext* threadContext = (ThreadContext*)lpParameter;

	while (true) {
		//TODO: should be blocked waiting for a start signal
	}
	return 0;
}

void MT::ThreadPool::Init(int nt)
{
	if (nt != m_numThreads) {
		Clear();

		m_threads = new ThreadHdl[nt];

		for (int t=0; t < m_numThreads; t++) {
			m_threads[t] = MiCreateThread( ThreadCallback, 0 );
		}
	}
}

ThreadHdl MT::MiCreateThread( ThreadFunc func, void* userData )
{
	DWORD dwThreadId; 
	HANDLE hThread; 
	wchar_t szMsg[80];

	hThread = CreateThread( 
		NULL,						// default security attributes 
		0,							// use default stack size  
		(LPTHREAD_START_ROUTINE)func,	// thread function 
		userData,					// argument to thread function 
		CREATE_SUSPENDED,			// use default creation flags 
		&dwThreadId);				// returns the thread identifier 
 
	// Check the return value for success. 
	if (hThread == NULL) {
		wsprintf( szMsg, L"CreateThread failed." ); 
		MessageBox( NULL, szMsg, L"main", MB_OK );
	}
	return hThread;
}

void MT::MiDestroyThread( ThreadHdl hThread )
{
	CloseHandle( (HANDLE)hThread );
}

void MT::MiResumeThread( ThreadHdl hThread )
{
	ResumeThread( (HANDLE)hThread );
}

/// machine independent way to suspend a thread
void MT::MiSuspendThread( ThreadHdl hThread )
{
	SuspendThread( (HANDLE)hThread );
}

/// machine independent way to create a critical section
CriticalSection MT::MiCreateCriticalSection()
{
	CRITICAL_SECTION* section = (CRITICAL_SECTION*)malloc( sizeof(CRITICAL_SECTION) );
	if (section) {
		InitializeCriticalSection( section );
	}
	return section;
}

void MT::MiDestroyCriticalSection( CriticalSection cs )
{
	if (cs) {
		DeleteCriticalSection( (LPCRITICAL_SECTION)cs );
		free( cs );
	}
}

void MT::MiEnterCriticalSection( CriticalSection cs )
{
	EnterCriticalSection( (LPCRITICAL_SECTION)cs );
}

void MT::MiLeaveCriticalSection( CriticalSection cs )
{
	LeaveCriticalSection( (LPCRITICAL_SECTION)cs );
}

EventHandle MT::MiCreateEvent(bool initState, bool manualReset)
{
	HANDLE eventhdl = CreateEvent( 
		0, 
		(BOOL)manualReset,	// BOOL bManualReset
		(BOOL)initState,	// BOOL bInitialState,
		NULL				//LPCTSTR lpName
	);
	return (EventHandle)eventhdl;
};

void MT::MiDestroyEvent(EventHandle e)
{
	CloseHandle( (HANDLE)e );
}

void MT::MiSetEvent(EventHandle e)
{
	SetEvent((HANDLE)e);
}

void MT::MiResetEvent(EventHandle e)
{
	ResetEvent((HANDLE)e);
}

void MT::MiWaitForMultipleEvents( EventHandle* events, int count )
{
	//wait for all the worker threads to finish
	WaitForMultipleObjects( count, events, TRUE, INFINITE );
}
