/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#include <conio.h>
//#include "inc/cpuconfig.h"
#include "cpuid.h"

/*
 Parts of it based on C.Wright's code http://softpixel.com/~cwright/programming/simd/cpuid.php

 Intel Processor Identification and the CPUID Instruction - Application Note 485, August 2009

 64 bit - http://software.intel.com/en-us/articles/cpuid-for-x64-platforms-and-microsoft-visual-studio-net-2005/
*/

static U32 kProcessorInfo	= 0x01;
static U32 kCache_TLBInfo	= 0x02;
static U32 kProcessorSerial = 0x03;
static U32 kCacheParameters = 0x04;
static U32 kL1Cache_TLBIdentifiers  = 0x80000005;
static U32 kL2CacheFeatures			= 0x80000006;
static U32 kAdvancedPowerManagement = 0x80000007;
static U32 kVirtual_PhysicalAddrSize = 0x80000008;

using namespace GEG2;
static const U32 k1KB  = 1024;
static const U32 k512K = 512*1024;
static const U32 k1Meg = 1024*1024;

CPUId* g_cpuid = 0;

//L1 data cache (table 2-7):
static CacheDesc gL1DCacheDesc[] = {
	CacheDesc(0x0A,  8*k1KB,  2, 32),
	CacheDesc(0x0C, 16*k1KB,  4, 32),
	CacheDesc(0x0D, 16*k1KB,  4, 64),	//ECC
	CacheDesc(0x2C, 32*k1KB,  8, 64),
	CacheDesc(0x60, 16*k1KB,  8, 64),	//sectored
	CacheDesc(0x66,  8*k1KB,  4, 64),	//sectored
	CacheDesc(0x67, 16*k1KB,  4, 64),	//sectored
	CacheDesc(0x68, 32*k1KB,  4, 64),	//sectored
};
//L1 instruction cache (table 2-7):
static CacheDesc gL1ICacheDesc[] = {
	CacheDesc(0x06,  8*k1KB,  4, 32),
	CacheDesc(0x08, 16*k1KB,  4, 32),
	CacheDesc(0x09, 32*k1KB,  4, 64),
	CacheDesc(0x30, 32*k1KB,  8, 64),
	//CacheDesc(0x0C, 16*k1KB,  4, 32),
	//CacheDesc(0x0D, 16*k1KB,  4, 32),	//ECC
};
//L2 cache (table 2-7):
static CacheDesc gL2CacheDesc[] = {
	CacheDesc(0x21, 256*k1KB, 8, 64),
	CacheDesc(0x39, 128*k1KB, 4, 64),
	CacheDesc(0x3A, 192*k1KB, 6, 64),
	CacheDesc(0x3B, 128*k1KB, 2, 64),
	CacheDesc(0x3C, 256*k1KB, 4, 64),
	CacheDesc(0x3D, 384*k1KB, 6, 64),
	CacheDesc(0x41, 128*k1KB, 4, 32),
	CacheDesc(0x42, 256*k1KB, 4, 32),
	CacheDesc(0x43, 512*k1KB, 4, 32),
	CacheDesc(0x44,  1*k1Meg, 4, 32),
	CacheDesc(0x45,  2*k1Meg, 4, 32),
	CacheDesc(0x46,  4*k1Meg, 4, 64),
	CacheDesc(0x47,  8*k1Meg, 8, 64),
	CacheDesc(0x48,  3*k1Meg, 12, 64),		//unified on-die
	CacheDesc(0x49,  4*k1Meg, 16, 64),		//Xeon MP, Family 0Fh, Model 06h; otherwise 2nd-level cache
	CacheDesc(0x4E,  6*k1Meg, 24, 64),
	CacheDesc(0x78,  1*k1Meg,  4, 64),
	CacheDesc(0x7A, 256*k1KB,  8, 64),
	CacheDesc(0x7B, 512*k1KB,  8, 64),
	CacheDesc(0x7C,  1*k1Meg,  8, 64),
	CacheDesc(0x7D,  2*k1Meg,  8, 64),
	CacheDesc(0x7F, 512*k1KB,  2, 64),
	CacheDesc(0x82, 256*k1KB,  8, 32),
	CacheDesc(0x83, 512*k1KB,  8, 32),
	CacheDesc(0x84,  1*k1Meg,  8, 32),
	CacheDesc(0x85,  2*k1Meg,  8, 32),
	CacheDesc(0x86, 512*k1KB,  4, 64),
	CacheDesc(0x87,  1*k1Meg,  8, 64),
};
//L3 cache (table 2-7):
static CacheDesc gL3CacheDesc[] = {
	CacheDesc(0x22,  k512K,   4, 64),
	CacheDesc(0x23,  k1Meg,   8, 64),
	CacheDesc(0x25, 2*k1Meg,  8, 64),
	CacheDesc(0x29, 4*k1Meg,  8, 64),
	CacheDesc(0x46, 4*k1Meg,  4, 64),
	CacheDesc(0x47, 8*k1Meg,  8, 64),
	//CacheDesc(0x49, 4*k1Meg, 16, 64),	//Xeon MP, Family 0Fh, Model 06h; otherwise 2nd-level cache
	CacheDesc(0x4A, 6*k1Meg, 12, 64),
	CacheDesc(0x4B, 8*k1Meg, 12, 64),
	CacheDesc(0x4D, 16*k1Meg, 16, 64),

	CacheDesc(0xD0, 512*k1KB, 4, 64),
	CacheDesc(0xD1, 1*k1Meg,  4, 64),
	CacheDesc(0xD2, 2*k1Meg,  4, 64),
	CacheDesc(0xD6, 1*k1Meg,  8, 64),
	CacheDesc(0xD7, 2*k1Meg,  8, 64),
	CacheDesc(0xD8, 4*k1Meg,  8, 64),
	CacheDesc(0xDC, k1Meg + k512K,  12, 64),
	CacheDesc(0xDD, 3*k1Meg, 12, 64),
	CacheDesc(0xDE, 6*k1Meg, 12, 64),
	CacheDesc(0xE2, 2*k1Meg, 16, 64),
	CacheDesc(0xE3, 4*k1Meg, 16, 64),
	CacheDesc(0xE4, 8*k1Meg, 16, 64),
	CacheDesc(0xEA, 12*k1Meg, 24, 64),
	CacheDesc(0xEB, 18*k1Meg, 24, 64),
	CacheDesc(0xEC, 24*k1Meg, 24, 64),
};

//TLB cache (table 2-7):
static CacheDesc gTLBDesc[] = {
	CacheDesc(0x03,  4*k1KB,  4, 64),	//id, pagesize, k-way, entries
	CacheDesc(0x04,  4*k1Meg, 4,  8),
	CacheDesc(0x05,  4*k1Meg, 4, 32),
	CacheDesc(0x56,  4*k1Meg, 4, 16),
	CacheDesc(0x57,  4*k1Meg, 4, 16),
	CacheDesc(0x5A,  4*k1Meg, 4, 32),
	CacheDesc(0x5B,  4*k1Meg, 0, 32),	//id, 4kb/4m, full-assoc, entries
	CacheDesc(0x5C,  4*k1Meg, 0, 128),	//id, 4kb/4m, full-assoc, entries
	CacheDesc(0x5D,  4*k1Meg, 0, 256),	//id, 4kb/4m, full-assoc, entries
	CacheDesc(0xB3,  4*k1KB,  4, 128),	//id, 4kb,    4-way, entries
	CacheDesc(0xB4,  4*k1KB,  4, 256),	//id, 4kb,    4-way, entries
};

void GEG2::ExitCPUId()
{
	delete g_cpuid;	g_cpuid = 0;
}

#ifdef _M_X64
#include "asm/cpuid64.h"
static void cpuid(unsigned int inp, unsigned int* a, unsigned int* b, unsigned int* c, unsigned int* d)
{
	CPUID_ARGS cpuregs;
	cpuregs.eax = *a;	cpuregs.ebx = *b;	cpuregs.ecx = *c;	cpuregs.edx = *d;
	cpuid64( &cpuregs );
	*a = cpuregs.eax;	*b = cpuregs.ebx;	*c = cpuregs.ecx;	*d = cpuregs.edx;
}
#else
static void cpuid(unsigned int inp, unsigned int* a, unsigned int* b, unsigned int* c, unsigned int* d)
{
	unsigned int A,B,C,D;

	_asm {
		push eax
		push ebx
		push ecx
		push edx

		mov eax, [inp]
		mov ecx, [c]
		mov ecx, [ecx];
		cpuid
		mov [A], eax
		mov [B], ebx
		mov [C], ecx
		mov [D], edx

		pop edx
		pop ecx
		pop ebx
		pop eax
	};
	*a = A;
	*b = B;
	*c = C;
	*d = D;
}
#endif

CPUId::Signature::Signature()
{
	cpuid( kProcessorInfo, &m_AX, &m_BX, &m_CX, &m_DX );
}

/* Decode Cyrix TLB and cache info descriptors */
static void decode_cyrix_tlb(int x){
	switch(x & 0xff) {
	  case 0:
		break;
	  case 0x70:
		_cprintf("TLB: 32 entries 4-way associative 4KB pages\n");
		break;
	  case 0x80:
		_cprintf("L1 Cache: 16KB 4-way associative 16 bytes/line\n");
		break;
	}
}

static void TLB()
{
    int ntlb = 255;
    int i;

    for(i=0;i<ntlb;i++){
      U32 eax,ebx,ecx,unused;

      cpuid(0x80000005,&eax,&ebx,&ecx,&unused);
      ntlb =  eax & 0xff;
      decode_cyrix_tlb(ebx >> 8);
      decode_cyrix_tlb(ebx >> 16);
      decode_cyrix_tlb(ebx >> 24);
      
      /* eax and edx are reserved */

      if((ecx & 0x80000000) == 0){
    	decode_cyrix_tlb(ecx);
 		decode_cyrix_tlb(ecx >> 8);
		decode_cyrix_tlb(ecx >> 16);
		decode_cyrix_tlb(ecx >> 24);
      }
    }
}

U32 GEG2::CacheSize( U32 cachelevel )
{
	U32 cx, dx, ax, bx;

	cx = cachelevel;
	cpuid( kCacheParameters, &ax, &bx, &cx, &dx );

	if ((ax & 0x1f) == 0) 
		return 0;
	U32 sets = (cx + 1);
	U32 linesize   = (bx & 0xfff);			//[11:0]
	U32 partitions = (bx >> 12) & 0x3ff;	//[21:12]
	U32 ways = (bx >> 22) & 0x3ff;			//[31:22]
	return (ways+1) * (partitions+1) * (linesize+1) * sets;
}

static void GetCacheInfo(U32* cacheLineSize)
{
	U32 cx, dx, ax, bx;
	cpuid( kProcessorInfo, &ax, &bx, &cx, &dx );
	*cacheLineSize = ((bx >> 8) & 0xff) * 8;		//Intel only
	//For AMD Microprocessors, the data Cache Line Size is in cl and the instruction Cache Line Size is in dl after calling cpuid function 0x80000005.

	U32 csize0 = CacheSize( 0 );
	U32 csize1 = CacheSize( 1 );
	U32 csize2 = CacheSize( 2 );
	U32 csize3 = CacheSize( 3 );
}

CacheTLB::CacheTLB()
: m_prefetch(0),
  m_L1DCache(CacheDesc(0,32*k1KB,  4, 64)),			//!< L1 dcache descriptor
  m_L1ICache(CacheDesc(0,32*k1KB,  4, 64)),			//!< L1 icache descriptor
  m_L2Cache(CacheDesc(0, 1*k1Meg,  8, 64)),			//!< L2 cache descriptor
  m_L3Cache()										//!< L3 cache descriptor
{
	cpuid( kCache_TLBInfo, &m_reg[0], &m_reg[1], &m_reg[2], &m_reg[3] );

	for (int r=0; r < 4; r++) {
		U32 reg = m_reg[r];
		for (int b=0; b < 4; b++) {
			U32 ourid = (reg >> (8*b)) & 0xff;
			if (ourid == 0)
				continue;
			for (int c= 0; c < sizeof(gL1DCacheDesc)/sizeof(CacheDesc); c++) {
				if (gL1DCacheDesc[c].m_id == ourid) {
					m_L1DCache = gL1DCacheDesc[c];
					continue;
				}
			}
			for (int c= 0; c < sizeof(gL1ICacheDesc)/sizeof(CacheDesc); c++) {
				if (gL1ICacheDesc[c].m_id == ourid) {
					m_L1ICache = gL1ICacheDesc[c];
					continue;
				}
			}
			for (int c= 0; c < sizeof(gL2CacheDesc)/sizeof(CacheDesc); c++) {
				if (gL2CacheDesc[c].m_id == ourid) {
					m_L2Cache = gL2CacheDesc[c];
					continue;
				}
			}
			for (int c= 0; c < sizeof(gL3CacheDesc)/sizeof(CacheDesc); c++) {
				if (gL3CacheDesc[c].m_id == ourid) {
					m_L3Cache = gL3CacheDesc[c];
					continue;
				}
			}
			for (int c= 0; c < sizeof(gTLBDesc)/sizeof(CacheDesc); c++) {
				if (gTLBDesc[c].m_id == ourid) {
					m_TLBCache = gTLBDesc[c];
					continue;
				}
			}
			if (ourid == 0xf0) {
				m_prefetch = 64;
			}
			if (ourid == 0xf1) {
				m_prefetch = 128;
			}
		}
	}
}

CPUId::CPUId() : m_vendorId(0), m_highest(0), m_highestExtended(0), m_cacheTLB()
{
	U32 cx, dx, unused, ax, bx;	(void)ax; (void)bx;
	U32 cacheline;

	cpuid( 0, &m_highest, &m_vendorId, &cx, &dx );
	GetCacheInfo( &cacheline );
	cpuid(0x80000000, &m_highestExtended, &unused, &unused, &unused);

	cpuid(kL1Cache_TLBIdentifiers, &m_L1Cache_TLBIdentifiers[0], &m_L1Cache_TLBIdentifiers[1], &m_L1Cache_TLBIdentifiers[2], &m_L1Cache_TLBIdentifiers[3]);
	cpuid(kL2CacheFeatures, &m_L2CacheFeatures[0], &m_L2CacheFeatures[1], &m_L2CacheFeatures[2], &m_L2CacheFeatures[3]);

	TLB();

	bool SSE2 = m_signature.HasSSE2();
	bool SSE3 = m_signature.HasSSE3();
	bool SSSE3 = m_signature.HasSSSE3();
	bool SSE4_1 = m_signature.HasSSE4_1();
}

const CPUId& GEG2::GetCPUId()
{
	if (g_cpuid == 0) {
		g_cpuid = new CPUId();
	}
	return *g_cpuid;
}

void GEG2::DumpSSELevels(const CPUId& cpuid)
{
	_cprintf("SSE2 : %s, ", cpuid.m_signature.HasSSE2() ? "T" : "F" );
	_cprintf("SSE3 : %s, ", cpuid.m_signature.HasSSE3() ? "T" : "F" );
	_cprintf("SSSE3 : %s, ", cpuid.m_signature.HasSSSE3() ? "T" : "F" );
	_cprintf("SSE4_1 : %s, ", cpuid.m_signature.HasSSE4_1() ? "T" : "F" );
	_cprintf("SSE4_2 : %s, ", cpuid.m_signature.HasSSE4_2() ? "T" : "F" );
	_cprintf("SSE5 : %s, ", cpuid.m_signature.HasSSE5() ? "T" : "F" );
	_cprintf("\n");
}
