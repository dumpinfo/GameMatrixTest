/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#ifndef PERF_h
#define PERF_h

class PerfCounter {
public:
	typedef __int64 CounterT;

	PerfCounter();

	void Reset() { /*m_total = 0;*/ }
	void Start();
	CounterT End();
	CounterT GetTotal() { return m_end - m_start; }
	static unsigned int MilliSecs(CounterT count);
	static float MilliSecsF(CounterT count);
public:
	static CounterT	m_freq;
	static CounterT m_overHead;		//!< platform dependent overhead for each Perf call

	CounterT		m_start;
	CounterT		m_end;
	//CounterT		m_total;
};

#endif
