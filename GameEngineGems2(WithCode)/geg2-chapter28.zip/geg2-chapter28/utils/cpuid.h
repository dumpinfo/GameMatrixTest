/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 */
#ifndef CPUID_GEG2_h
#define CPUID_GEG2_h

#include "basictypes.h"

/*
 Parts of it based on C.Wright's code http://softpixel.com/~cwright/programming/simd/cpuid.php

 Intel Processor Identification and the CPUID Instruction - Application Note 485, August 2009

 64 bit - http://software.intel.com/en-us/articles/cpuid-for-x64-platforms-and-microsoft-visual-studio-net-2005/
*/

namespace GEG2
{
	/*
	-- CacheDesc: Cache descriptor.
	*/
	struct CacheDesc {
		CacheDesc() : m_id(0), m_size(0), m_assoc(0), m_linesize(0) {}
		CacheDesc(U32 id, U32 size, U32 assoc, U32 linesize) : m_id(id), m_size(size), m_assoc(assoc), m_linesize(linesize) {}

		bool IsValid() const { return m_id != 0; }

		U32		m_id;			//!< 8 bit id
		U32		m_size;			//!< cache size
		U32		m_assoc;		//!< how many ways
		U32		m_linesize;		//!< cache line size
	};

	/*
	-- CacheTLB: Cache and TLB descriptor.
	*/
	class CacheTLB {
	public:
		CacheTLB();

		///according to 2.1.3 a given register is valid only if the b3 is 0
		bool IsValid(U32 reg) const { return (reg & 0x8000000) == 0; }
	public:
		CacheDesc	m_L1DCache;		//!< L1 dcache descriptor
		CacheDesc	m_L1ICache;		//!< L1 icache descriptor
		CacheDesc	m_L2Cache;		//!< L2 cache descriptor
		CacheDesc	m_L3Cache;		//!< L3 cache descriptor
		CacheDesc	m_TLBCache;
		U32			m_prefetch;		//!< prefetch size
		U32			m_reg[4];		//!< registers from cpuid
	};

	class CPUId {
	public:
		class Signature {
		public:
			Signature();

			U32 Stepping() const	  { return m_AX & 0xf; }		// 3:0
			U32 Model() const	 	  { return m_AX & 0xf0; }		// 7:4
			U32 Family() const		  { return m_AX & 0x0f00; }		// 11:8
			U32 ProcessorType() const { return m_AX & 0x3000; }	// 13:12
			U32 ExtendedModel() const { return m_AX & 0xf0000; }		// 19:16
			U32 ExtendedFamily() const { return m_AX & 0x0ff00000; }	// 27:20

			bool HasSSE2() const { return (m_DX & 0x04000000) != 0;}	//bit 26
			bool HasSSE3() const { return (m_CX & 0x1) != 0; }
			bool HasSSSE3() const { return (m_CX & 0x20) != 0; }		//bit 9
			bool HasSSE4_1() const { return (m_CX & 0x080000) != 0; }	//bit 19
			bool HasSSE4_2() const { return (m_CX & 0x100000) != 0; }	//bit 20
			bool HasSSE5() const   { return (m_CX & 0x000800) != 0; }	//bit 11
		public:
			U32		m_AX;		//!< EAX
			U32		m_BX;		//!< EBX
			U32		m_CX;		//!< ECX
			U32		m_DX;		//!< EDX
		};	//end of Signature

		CPUId();

		bool IsIntel() const { return m_vendorId == kIntel; }
		bool IsAMD() const { return m_vendorId == kAMD; }
		bool IsCyrix() const { return m_vendorId == kCyrix; }

		/// Cache and TLB Descriptor info
		const CacheTLB& GetCacheTLB() const { return m_cacheTLB; }
	public:
		static const U32 kIntel = 0x756e6547; /* Intel */
		static const U32 kAMD	= 0x68747541; /* AMD */
		static const U32 kCyrix = 0x69727943; /* Cyrix */

		U32		m_vendorId;
		U32		m_highest;			//!< highest calling parameter
		U32		m_highestExtended;	//!< highest supported extended feature
		Signature m_signature;		//!< Processor Info and Feature Bits
		CacheTLB m_cacheTLB;		//!< Cache and TLB Descriptor info
		U32		m_L1Cache_TLBIdentifiers[4];
		U32		m_L2CacheFeatures[4];
	};	//end of CPUId

	void ExitCPUId();

	const CPUId& GetCPUId();

	void DumpSSELevels(const CPUId& cpuid);

	U32 CacheSize( U32 cachelevel );
};

#endif
