/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 */

#ifndef SSEVEC_h
#define SSEVEC_h

#include <assert.h>
#include <float.h>
#include <xmmintrin.h>
#include <emmintrin.h>	    // SSE2 intrinsics (P4) -> has the __m128i type for 128bit integer support


namespace SSE 
{
	/*!
	-- Vec4: class to help the compiler hold 4 floats inside a xmms register.
	*/
	class Vec4 {
	public:
		Vec4() {}
		//Vec4( const float f ) { m_v = _mm_set1_ps(f); }
		//Builds a Vec4 out of a scalar 'f' - keeps it within a SSE register
		Vec4( float x, float y, float z, float w ) {
			m_v = _mm_setr_ps(x,y,z,w); 
		}
		Vec4( float x, float y, float z ) { m_v = _mm_setr_ps(x,y,z,z); }
		Vec4( const __m128& v ) : m_v(v) {}
		/// v[4] must be SSE aligned
		Vec4( const float* v ) { m_v = _mm_load_ps(v) ;}

		void Clear() { m_v = _mm_setzero_ps(); }
	public:
		union {
			__m128	m_v;
			struct {
				float m_c[4];
			};
		};
	};	//end of Vec4

	///common vector constants
	static const Vec4 kVec4PosInf = _mm_set_ps1(FLT_MAX);
	static const Vec4 kVec4NegInf = _mm_set_ps1(-FLT_MAX);

	typedef Vec4 Vec3;	//for now
	typedef const Vec3& Vec3_arg;

};	//end of namspace SSE

#endif
