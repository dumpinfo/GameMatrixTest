/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
*/

#ifndef SSEBBOX_H
#define SSEBBOX_H

#include "msvc.h"

#include "ssevec.h"

#define SSE_ALIGN __declspec(align(16))

namespace SSE
{
	/*!
	-- AABB:
	*/
    class AABB {
    public:
		AABB() {}
		AABB(SSE::Vec3_arg lb, SSE::Vec3_arg ub) : m_min(lb), m_max(ub) { }

        /// resets to default state
        void Reset() {
            Empty();
        }
        /// make it empty
		void Empty() { m_min = SSE::kVec4PosInf;	m_max = SSE::kVec4NegInf; }

		float GetMin(size_t a) const { return m_min.m_c[a]; }
		float GetMax(size_t a) const { return m_max.m_c[a]; }
		float Extent(size_t a) const { return GetMax(a) - GetMin(a); }

		/// x-min
		float XMin() const { return m_min.m_c[0]; }
        /// x-max
        float XMax() const { return m_max.m_c[0]; }
        /// y-min
        float YMin() const { return m_min.m_c[1]; }
        /// y-max
        float YMax() const { return m_max.m_c[1]; }
        /// z-min
        float ZMin() const { return m_min.m_c[2]; }
        /// z-max
        float ZMax() const { return m_max.m_c[2]; }

	public:
		SSE_ALIGN SSE::Vec3		m_min;
		SSE_ALIGN SSE::Vec3		m_max;
	};	//end of AABB

	SSE::AABB* LoadBoxes( size_t* len, const char* filename );

}; //end of namespace SSE

#endif