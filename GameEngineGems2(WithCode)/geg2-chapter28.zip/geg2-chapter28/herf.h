// Radix.cpp: a fast floating-point radix sort demo
//
//   Copyright (C) Herf Consulting LLC 2001.  All Rights Reserved.
//   Use for anything you want, just tell me what you do with it.
//   Code provided "as-is" with no liabilities for anything that goes wrong.
//
#ifndef HERF_h
#define HERF_h

namespace HERF
{
	typedef __int32 int32;
	typedef unsigned long uint32;
	typedef float real32;

	///Herf's original radix-2048 sort
	void RadixSort11(real32 *farray, real32 *sorted, uint32 elements);
	///my optimized radix-256 adapation of Herf's code
	void RadixSort8(real32 *farray, real32 *sorted, uint32 elements);
};

#endif