/*
 * source code Copyright(c) 2004-2009 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */
#ifndef LOSER4_h
#define LOSER4_h

/*
	LoserTree4 - an SSE implementation of Knuth's classic 'loser tree' vol 2 [5.4.1]
	 It is a complete binary-tree optimized for replacement select operations.
*/

#include <limits>
#include <assert.h>

#include "msvc.h"

#ifndef CACHE_ALIGN
#define CACHE_ALIGN __declspec(align(64))
#endif

namespace DATA
{
	static const float  kSentinel = std::numeric_limits<float>::infinity();

	/*!
	-- LoserTree4 - an implementation of Knuth's classic 'loser tree' [5.4.1]
	--
	-- It is a complete binary-tree optimized for replacement select operations.
	-- Each substream is marked by an EOS marker to speed up the inner loop.
	*/
	class LoserTree4 {
		typedef float Key;		//TODO: make this a template when needed
	public:
		static const size_t kStreams = 4;

		LoserTree4() {
			//logK = 2;			// log of current tree size
			//k	 = kStreams;	// invariant k = 1 << logK
		}
		~LoserTree4() {}

		/// merge 4 input to produce 1 sorted output stream:
		void Merge( float* istreams[kStreams], size_t* len, float* output ) {
			Key* streams[kStreams] = {istreams[0], istreams[1], istreams[2], istreams[3]};
			float* ostream = output;
			
			//1: load the head of each stream into the leafs and set markers
			InitMerge( streams, len );
			//2: start the first round of tournament
			int winner = InitWinner(Root());

			const size_t count = len[0] * kStreams;		//assumes the 1st substream is the longest
			for (size_t i=0; i < count; i++) {
				const Key oval = m_nodes[winner].m_key;
				int sindex = m_nodes[winner].m_value - kStreams;
				assert( oval != kSentinel );
				*ostream++ = oval;		//emit winner 

				//3: get next element from the winning stream 
				float nval = *streams[sindex]++;
				winner = Update(winner, nval);	//start the next round of tournament
			}
			//3: remove all the EOS markers
			Restore( istreams, len );
		}
	protected:		//core algorithm
		///kick start the algorithm
		inline void InitMerge( float* streams[kStreams], size_t* stlen ) {
			Node* leafs = Leafs();
			for (int s=0; s < kStreams; s++) {
				Node& node = leafs[s];
				node.m_key = *streams[s];
				node.m_value = s + kStreams;	//encode its own leaf-slot/stream index
			}
			InsertMarker( streams, stlen );		//add EOS marker to mark the end of each substream
		}
		///insert EOS markers for each substream to speed up the inner loop
		inline void InsertMarker( float* streams[kStreams], size_t* stlen ) {
			for (int s=0; s < kStreams; s++) {
				size_t slen = stlen[s];
				m_save[s] = streams[s][slen];
				streams[s][slen] = kSentinel;		//mark the end of a substream
				streams[s]++;
			}
		}
		///restores the original input
		inline void Restore(float* streams[kStreams], size_t* stlen) {
			for (int s=0; s < kStreams; s++) {
				size_t slen = stlen[s];
				streams[s][slen] = m_save[s];
			}
		}
		///build the loser-tree after populating all the leaf nodes:
		int InitWinner(int root) {
			if (root >= kStreams) {			// leaf reached
				return root;	//root - kStreams;		// leaf index
			} else {
				int left  = InitWinner(2*root    );
				int right = InitWinner(2*root + 1);
				Key lk    = m_nodes[left ].m_key;
				Key rk    = m_nodes[right].m_key;
				if (lk <= rk) {			// right subtree looses
					m_nodes[root] = m_nodes[right];	//store loser
					return left;		//ret winner
				} else {
					m_nodes[root] = m_nodes[left];
					return right;
				}
			}
		}
		///update loser tree after storing 'nextval' at 'slot':
		FORCEINLINE int Update(int slot, Key newKey) {
			m_nodes[slot].m_key = newKey;
			assert( m_nodes[slot].m_value == slot);	//should always be the same stream

			int loserslot = Parent(slot);
			int winner = slot;
			float loser;

			while (loserslot != 0) {
				loser = m_nodes[loserslot].m_key;	//previous loser
				if (newKey > loser) {				//newKey is losing to old loser
					newKey = loser;					//new winner's key
					int newwinner = m_nodes[loserslot].m_value;	//new winner's slot	//;			
					m_nodes[loserslot] = m_nodes[winner];	// newKey is the new loser
					winner = newwinner;
				}
				loserslot = Parent(loserslot);
			}
			return winner;
		}
	protected:		//data abstraction and invariants
		struct Node {
			Key		m_key;			//!< our key
			int		m_value;		//!< always the substream index 'm_key' is from
		};

		//bool IsDone() const { return m_heads == kInf4; }

		///predicate for 'index' being a leaf:
		bool IsLeaf(int index) const { return (index >= kStreams); }
		///current winner
		//float	Winner() const { return m_nodes[0].m_key; };
		///our root
		int		Root() const { return 1; }
		///returns our parent's index:
		int		Parent(int index) const { return index >> 1; }
		///left child
		int		Left(int index) const { return index << 1; }
		///right child
		int		Right(int index) const { return (index << 1) + 1; }
		///our leaf nodes:
		Node*	Leafs() { return &m_nodes[kStreams]; };
		///from a leaf index compute the stream index:
		int		Leaf2Stream(int lindex) const { assert(IsLeaf(lindex)); return (lindex - kStreams); }

	protected:
		CACHE_ALIGN Node m_nodes[kStreams*2];	//!< our tree
		Key				m_save[kStreams];		//!< to restore the locations of the sentinels
	};	//end of LoserTree4

};	//end of namespace DATA

#endif
