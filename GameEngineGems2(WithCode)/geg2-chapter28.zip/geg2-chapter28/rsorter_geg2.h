/*
 * source code Copyright(c) 2004-2010 Manchor Ko
 *
 * All Rights Reserved.
 * Use and distribution without consent strictly prohibited
 *
 *  mannyk90@yahoo.com
 */

#ifndef RSORTER_GEG2_h
#define RSORTER_GEG2_h

#include <malloc.h>

#include "basictypes.h"

namespace GEG2
{
	/*!
	-- RadixSorter: a builder class to aid with the use of Warren's radix-sorter.
	--	 It splits the input stream into substreams that fits into 
	--	 Mostly it holds the indices and temporaries for reuse.
	--	 It currently only supports sorting of <key,index> pairs. Caller can either
	--	 request for the sorted indices or request the original values to be moved.
	*/
	class RadixSorter {
		typedef size_t*		Indices;
		static const size_t kStreams = 4;
	public:
		static const size_t kNumThreads = 4;		//# of threads

		RadixSorter();
		RadixSorter( int count );
		~RadixSorter();

		///reallocate internal storage to prepare for a stream of length 'count':
		void	Resize( int count );
		///deallocate all storage:
		void	Clear();

		///initialize the sorter for 'values' :
		void	SortInit( float* values, int count );

		///sort sub-stream 's':
		void	SortStream( int s );
		///merge the sorted sub-streams to produce the final output in m_outbuf:
		void	MergeStreams();
	protected:

	public:
		size_t		m_blockSizes[kStreams];		//!< size of each sub-stream
		float*		m_streams[kStreams];		//!< our sub-streams of work
		float*		m_temp[kNumThreads];		//!< working buffer carved out from the output buffer
		float*		m_outbuf;
		int			m_count;					//!< max size of the input sequence
		bool		m_inited;

	public:
		U32		m_inCache;			//!< cross-over point for in cache sort - size M
		U32		m_L1CacheSize;		//!< size of L1
		U32		m_L2CacheSize;		//!< size of L2
		U32		m_L3CacheSize;		//!< size of L3
		U32		m_L2CacheLineSize;	//!< L2 linesize
	};

};	//end of namespace GEG2
#endif
