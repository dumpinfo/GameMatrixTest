#pragma once

class ICleanable;

class ICleanableObserver
{
public:
    virtual ~ICleanableObserver() {}
    virtual void NotifyDirty(ICleanable *value) = 0;
};
