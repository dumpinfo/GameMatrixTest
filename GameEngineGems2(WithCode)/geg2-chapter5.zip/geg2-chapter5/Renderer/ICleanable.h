#pragma once

class ShaderProgram;

class ICleanable
{
public:
    virtual ~ICleanable() {}

private:
    virtual void Clean() = 0;

    friend class ShaderProgram;
};