#pragma once

typedef int GLint;
typedef unsigned int GLuint;
typedef float GLfloat;

GLuint glCreateProgram(void)
{
    return 0;
}

void glDeleteProgram(GLuint program)
{
}

void glUniform1f(GLint location, GLfloat v0)
{
}