#pragma once

#include "ShaderProgram.h"

class Context
{
public:
    void Draw(ShaderProgram &shaderProgram)
    {
        // glUseProgram
        shaderProgram.Clean();

        // glDrawArrays, glDrawElements, etc
    }
};