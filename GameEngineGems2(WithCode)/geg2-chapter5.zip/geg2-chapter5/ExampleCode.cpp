#include "stdafx.h"

#include "Context.h"
#include "Uniform.h"
#include "ShaderProgram.h"

int _tmain(int argc, _TCHAR* argv[])
{
    Context context;

    std::string vertexSource = ""; // ...
    std::string fragmentSource = ""; // ...

    ShaderProgram program(vertexSource, fragmentSource);

    context.Draw(program);

    Uniform *diffuseIntensity = program.GetUniformByName("diffuseIntensity");
    Uniform *specularIntensity = program.GetUniformByName("specularIntensity");

    diffuseIntensity->SetValue(0.5f);
    specularIntensity->SetValue(0.2f);
    specularIntensity->SetValue(0.2f);

    context.Draw(program);
    context.Draw(program);

	return 0;
}

