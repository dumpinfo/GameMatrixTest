rust.jpg => http://texturez.com/textures/rust/1181
wood.png => http://www.sci.utah.edu/~wald/animrep/ The Utah Animation Rep.

alphamap.jpg 
=> Author: Noctua-Graphics
=> http://www.noctua-graphics.de/english/Tex/metal_01.htm

brickwork_normal-map.jpg
=> http://www.bricksntiles.com/textures/

wall.png (wall2.png is a modified file)

yellowhenna2.jpg
=> A part of the lamb mesh ( http://cg-india.com/cgblog_3dmodels.html )

Crate.jpg
=> http://www.turbosquid.com/3d-models/free-x-mode-crates/348777