Stone diffuse-normal-height textures are from: 
 * http://planetpixelemporium.com/tutorialpages/normal2.html
Brick diffuse-normal-height testures are from:
 * ATI RenderMonkey Examples 
   OR
 * NVIDIA Shader Library (http://developer.download.nvidia.com/shaderlibrary/packages/relief_mapping.zip)
 
Note: The height maps are baked in to the normal map texture alpha channel.