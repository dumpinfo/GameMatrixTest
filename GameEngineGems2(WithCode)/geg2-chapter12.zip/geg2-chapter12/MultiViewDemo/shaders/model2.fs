#ifdef GL_ES
	precision mediump float;
#endif

// vertex shader to fragment shader
varying vec2  vTexCoord;
varying vec4  vDiffuse;
varying vec4  vSpecular;

void main(void)
{
	if(gl_FrontFacing)
		gl_FragColor = vec4(1.0,1.0,1.0,1.0) * vDiffuse + vSpecular;
	else 
		gl_FragColor = vec4(1.0,0.0,0.0,1.0);
}
