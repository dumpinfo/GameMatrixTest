// vertex shader to fragment shader
varying vec3 vNormal;   // view space normal
varying vec3 vPos;      // view-space coordinate of the vertex
varying vec3 wPos;      // world-space coordinate of the vertex
#ifdef ENABLE_TEXTURING
	varying vec2 vTexCoord;
#endif

// scene parameters
uniform vec4 ambient;

// the surface parameters of the mesh
uniform float Kd;
uniform float Ks;
uniform float Ka;
uniform float n_specular;

#ifdef ENABLE_TEXTURING
	uniform sampler2D texSource;
#endif

vec4 vDiffuse;
vec4 vSpecular;

void main(void) {   
	vec3 vNormal_N = normalize(vNormal);
	
	// Compute the light direction in world space:
	vec3 vLightDiff = re_SpotLights_position[0]-wPos;
	float vLightDistance = length(vLightDiff);
	vec3 vLightDir_N = normalize(vec3(re_ViewMatrix * vec4(vLightDiff / vLightDistance,0)));
	
	// Compute reflection vector in view space:
	vec3 vReflect = normalize( 2.0 * dot(vNormal_N, vLightDir_N) * vNormal_N - vLightDir_N );         

	// Compute view vector (view space):
	vec3 vView = -normalize(vPos);                

	// Compute ambient contribution: 
	vDiffuse = ambient * Ka;
	vSpecular = vec4(0.0);
	
	// the dot product between vertex normal and light direction (view space)
	float NdotL = max(dot(vNormal_N,vLightDir_N),0.0);
	if(NdotL > 0.0) {
		// convert spot light direction into view space
		vec3 vSpotDirNorm = normalize ( vec3( re_ViewMatrix * vec4(-re_SpotLights_direction[0], 0) ) );
		float spotEffect = dot(vSpotDirNorm, vLightDir_N);
		if (spotEffect > re_SpotLights_attenDir[0].x) {
			// Compute diffuse contribution: 
			vDiffuse += re_SpotLights_color[0] * Kd * NdotL;
			
			// Compute specular term:
			vSpecular = re_SpotLights_color[0] * Ks * pow(max(0.0, dot(vReflect, vView)), n_specular);

			// apply attenuation
			float attenuation = 1.0 / (
				re_SpotLights_attenPos[0].x +         // constant
				re_SpotLights_attenPos[0].y * vLightDistance +     // linear
				re_SpotLights_attenPos[0].z * vLightDistance * vLightDistance); // quadric
			vDiffuse = vDiffuse * attenuation ; 
		}
	}

#ifdef ENABLE_TEXTURING
	gl_FragColor = texture2D(texSource, vTexCoord ) * vDiffuse;
#else	
	gl_FragColor = vDiffuse;
#endif
	gl_FragColor += vSpecular;
}
