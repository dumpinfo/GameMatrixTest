// vertex shader to fragment shader
varying vec3 vNormal;   // view space normal
varying vec3 vPos;      // view-space coordinate of the vertex
varying vec3 wPos;      // world-space coordinate of the vertex
#ifdef ENABLE_TEXTURING
	varying vec2 vTexCoord;
#endif

// scene parameters
uniform vec4 ambient;

// the surface parameters of the mesh
uniform float Kd;
uniform float Ks;
uniform float Ka;
uniform float n_specular;

#ifdef ENABLE_TEXTURING
	uniform sampler2D texSource;
#endif

vec4 vDiffuse;
vec4 vSpecular;

void main(void) {   
	vec3 vNormal_N = normalize(vNormal);
	
	// Compute the light direction in view space:
	vec3 vLightDiff = re_PointLights[0].position-wPos;
	float vLightDistance = length(vLightDiff);
	vec3 vLightDir_N = normalize(vec3(re_ViewMatrix * vec4(vLightDiff / vLightDistance,0)));
	
	// Compute reflection vector in view space:
	vec3 vReflect = normalize( 2.0 * dot(vNormal_N, vLightDir_N) * vNormal_N - vLightDir_N );         

	// Compute view vector (view space):
	vec3 vView = -normalize(vPos);                

	// Compute diffuse and ambient contribution: 
	vDiffuse = ambient * Ka + re_PointLights[0].color * Kd * max(0.0, dot(vNormal_N, vLightDir_N));

	// Compute specular term:
	vSpecular = re_PointLights[0].color * Ks * pow(max(0.0, dot(vReflect, vView)), n_specular);

	// apply attenuation
	float attenuation = 1.0 / (
	    re_PointLights[0].attenPos.x +         // constant
	    re_PointLights[0].attenPos.y * vLightDistance +     // linear
        re_PointLights[0].attenPos.z * vLightDistance * vLightDistance); // quadric
	vDiffuse = vDiffuse * attenuation ; 

#ifdef ENABLE_TEXTURING
	gl_FragColor = texture2D(texSource, vTexCoord ) * vDiffuse;
#else	
	gl_FragColor = vDiffuse;
#endif
	gl_FragColor += vSpecular;
}
