#ifdef GL_ES
	precision mediump float;
#endif

uniform sampler2D baseMap;

// vertex shader to fragment shader
varying vec2  vTexCoord;
varying vec4  vDiffuse;
varying vec4  vSpecular;
// varying vec3  vNormal; // use this to debug normals

void main(void)
{
   gl_FragColor = texture2D(baseMap, vTexCoord) * vDiffuse + vSpecular;
   
//   gl_FragColor.rgb = vNormal.rgb;
//   gl_FragColor.a = 1.0; // use this to debug normals
}
