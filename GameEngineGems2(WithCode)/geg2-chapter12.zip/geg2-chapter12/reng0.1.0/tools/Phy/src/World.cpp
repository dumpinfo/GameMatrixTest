/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/World.h"

#include "Phy/Space.h"
#include "Phy/Simulator.h"

#include <boost/foreach.hpp>
#include <log4cplus/logger.h>
using namespace log4cplus;

#define PHY_HRTIMER

#ifdef PHY_HRTIMER
// temp: remove linkage
#include "Phy/HRTimer.hpp"
#endif PHY_HRTIMER

namespace Phy {

World::~World(){
	if(mID) {
		dWorldDestroy(mID);
		mID=0;
	}
	// delete the spaces within this world
	BOOST_FOREACH(GeomSpace* space, mSpaceList) { delete space; }
}
void World::simulate(float sec){
	mSimTimeAccum += sec*mSimulationSpeed;
	size_t stepCount = 0;
	double totalEvalTime = 0;
	while(canStep()){
	#ifdef PHY_HRTIMER
		HRTimer timer;
	#endif
		if(mListener) mListener->preStep();
		step();
		if(mListener) mListener->postStep();
		mSimTimeAccum -= mStepTime;
		stepCount++;
	#ifdef PHY_HRTIMER
		double evalTime(timer.milliseconds());
//		LOG4CPLUS_INFO(Logger::getInstance("Perf"), "Phy, World, Simulate, stepEvalTime, "<<evalTime);
		totalEvalTime += evalTime;
	#endif
	}
#ifdef PHY_HRTIMER
	LOG4CPLUS_INFO(Logger::getInstance("Perf"), "Phy, World, Simulate, "
		"PhyStepTime, "  <<sec*mSimulationSpeed*1000/*to ms*/<<", "
		"totalEvalTime, "<<totalEvalTime<<", "
		"stepCount, "    <<stepCount);
#endif
	LOG4CPLUS_INFO(Logger::getInstance("Phy"),"World | Simulate | Seconds:"<<sec<<", stepCount:"<<stepCount);
}
void World::addSpace(GeomSpace& space){
	mSpaceList.push_back(&space);
	if(mActiveSpace==0) mActiveSpace = &space;
}
void World::removeSpace(GeomSpace& space){
	GeomSpaceList::iterator it= mSpaceList.begin(), it_end = mSpaceList.end();
	for( ;it!=it_end ; ++it ) {
		if((*it)->_getIDSpace()==space._getIDSpace()) {
			mSpaceList.erase(it);
			break;
		}
	}
	if(mActiveSpace->_getIDSpace()==space._getIDSpace()){
		mActiveSpace = 0;
	}
}
GeomSpace* World::getDefaultSpace(){
	return mActiveSpace;
}
size_t World::getSpaceCount(){
	return mSpaceList.size();
}
GeomSpaceList& World::getSpaces(){
	return mSpaceList;
}

}
