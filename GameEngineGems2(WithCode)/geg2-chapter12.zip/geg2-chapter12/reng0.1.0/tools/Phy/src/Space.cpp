/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/Space.h"

#include "Phy/World.h"

namespace Phy {

	GeomSpace::GeomSpace() : mAttachedWorld(0) { ; }
	dSpaceID GeomSpace::_getIDSpace(){
		return (dSpaceID)mID;
	}
	GeomSpace::~GeomSpace(){ 
		if(mID) {
			dSpaceDestroy((dSpaceID)mID); 
			mID=0;
		}
	}
	void GeomSpace::setOwnership(bool flag){
		dSpaceSetCleanup((dSpaceID)mID,flag);
	}
	bool GeomSpace::hasOwnership(){
		return dSpaceGetCleanup((dSpaceID)mID)!=0;
	}
	void GeomSpace::setSublevel(size_t level){
		dSpaceSetSublevel((dSpaceID)mID,(int)level);
	}
	size_t GeomSpace::getSublevel() const{
		return (size_t)dSpaceGetSublevel((dSpaceID)mID);
	}
	void GeomSpace::attachToWorld(World& world){
		if(mAttachedWorld){
			if(mAttachedWorld->_getID()==world._getID()) return;
		}
		if(mAttachedWorld) detachFromWorld();
		// do not call addSpace method again
		world.addSpace(*this);
		mAttachedWorld = &world;
	}
	void GeomSpace::detachFromWorld(){
		assert(mAttachedWorld);
		mAttachedWorld->removeSpace(*this);
		mAttachedWorld=0;
	}
	bool GeomSpace::isAttachedToWorld() const{
		return mAttachedWorld!=0;
	}
	World& GeomSpace::getAttachedWorld(){
		return *mAttachedWorld;
	}
	void GeomSpace::add(Geom& geom){
		dSpaceAdd((dSpaceID)mID,geom._getID());
	}
	void GeomSpace::remove(Geom& geom){
		dSpaceRemove((dSpaceID)mID,geom._getID());
	}
	bool GeomSpace::isChild(Geom& geom){
		return dSpaceQuery((dSpaceID)mID,geom._getID())!=0;
	}
	size_t GeomSpace::getChildCound(){
		return dSpaceGetNumGeoms((dSpaceID)mID);
	}
	Geom* GeomSpace::getGeom(size_t i){
		dGeomID gid = dSpaceGetGeom((dSpaceID)mID,(int)i);
		return (Geom*)dGeomGetData(gid);
	}

	//////////////////////////////////////////////////////////////////////////
	// SIMPLE SPACE
	SpaceSimple::SpaceSimple(GeomSpace* parentSpace){
		dSpaceID s(NULL);
		if(parentSpace) s = (dSpaceID)(parentSpace->_getID());
		mID = (dGeomID)dSimpleSpaceCreate(s);
		dGeomSetData(mID,this);
	}
	GeomType SpaceSimple::getType() const{ return GeomTypeSpaceSimple; }
	//////////////////////////////////////////////////////////////////////////
	// HASH SPACE
	SpaceHash::SpaceHash(GeomSpace* parentSpace){
		dSpaceID s(NULL);
		if(parentSpace) s = (dSpaceID)(parentSpace->_getID());
		mID = (dGeomID)dHashSpaceCreate(s);
		dGeomSetData(mID,this);
	}
	GeomType SpaceHash::getType() const{ return GeomTypeSpaceHash; }
	void SpaceHash::setLevels(int minLevel, int maxLevel){
		dHashSpaceSetLevels((dSpaceID)mID,minLevel,maxLevel);
	}
	void SpaceHash::getLevels(int& minLevel, int& maxLevel){
		dHashSpaceGetLevels((dSpaceID)mID,&minLevel,&maxLevel);
	}
	//////////////////////////////////////////////////////////////////////////
	// QUAD-TREE SPACE
	SpaceQuadTree::SpaceQuadTree(const REng::Vector3& center, const REng::Vector3& extents, 
		size_t depth, GeomSpace* parentSpace)
	{
		dSpaceID s(NULL);
		if(parentSpace) s = (dSpaceID)(parentSpace->_getID());
		dVector3 c;
		c[0] = WORLD_TO_SIM(center[0]);
		c[1] = WORLD_TO_SIM(center[1]);
		c[2] = WORLD_TO_SIM(center[2]);
		dVector3 e;
		e[0] = WORLD_TO_SIM(extents[0]);
		e[1] = WORLD_TO_SIM(extents[1]);
		e[2] = WORLD_TO_SIM(extents[2]);
		mID = (dGeomID)dQuadTreeSpaceCreate(s, c, e, (int)depth);
		dGeomSetData(mID,this);
	}
	GeomType SpaceQuadTree::getType() const{ return GeomTypeSpaceQuadTree; }

	//////////////////////////////////////////////////////////////////////////
	// SWAP AND PRUNE SPACE
	SpaceSwapAndPrune::SpaceSwapAndPrune(AxisOrder axisOrder, GeomSpace* parentSpace){
		dSpaceID s(NULL);
		if(parentSpace) s = (dSpaceID)(parentSpace->_getID());
		mID = (dGeomID)dSweepAndPruneSpaceCreate(s,axisOrder);
		dGeomSetData(mID,this);
	}
	GeomType SpaceSwapAndPrune::getType() const{ return GeomTypeSpaceSweepAndPrune; }

}

