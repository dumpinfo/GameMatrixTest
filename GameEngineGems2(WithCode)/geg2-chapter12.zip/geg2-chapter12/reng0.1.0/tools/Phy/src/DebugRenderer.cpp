/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/DebugRenderer.h"
#include "Phy/Space.h"
#include "Phy/Contact.h"

#include <boost/foreach.hpp>

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace Phy {

	const char *gODEMaterial = 
		// a specialized sky vertex shader
		"shader ode/VS { type vertex \n"
		"	source {{\n"
		"		in vec4 re_Position;\n"
		"		out vec2 checkerCoord;"
		"		void main (void) {\n"
		"			gl_Position = re_ModelViewProjectionMatrix * re_Position;\n"
		"			checkerCoord = re_Position.xy;\n"
		"		}\n"
		"	}}\n"
		"	version 130\n"
		"}\n"
		"shader ode/FS { type fragment\n"
		"	source {{\n"
		"		uniform vec4 fragColor;"
		"		out vec4 outFragColor;"
		"		void main(void) {\n"
		"			outFragColor = fragColor;\n"
		"		}\n"
		"	}}\n"
		"	version 130\n"
		"	uniform_defaults { fragColor vec4 1 0 0 0.8 }\n"
		"}\n"
		"shader ode/CheckerFS { type fragment \n"
		"	source {{\n"
		"		in vec2 checkerCoord;"
		"		void main(void) {\n"
		"			vec4 clr1 = vec4(1,1,1,1);\n"
		"			vec4 clr2 = vec4(0,0,0,1);\n"
		"			gl_FragColor = clr1;\n"
		"			ivec2 c = ivec2(ceil(checkerCoord / 0.05));\n"
		"			if(bool(c.x%2) ^^ bool(c.y%2)) gl_FragColor = clr2;\n"
		"		}\n"
		"	}}\n"
		"	version 130\n"
		"}\n"
		"material ode/MAT {\n"
		"	technique {\n"
		"		pass {\n"
		"			shader_ref   ode/VS\n"
		"			shader_ref ode/CheckerFS\n"
		"			render_states {\n"
		"				depth_test on\n"
		"				depth_mask on\n"
		"				cull_face BACK\n"
		"			}\n"
		"		}\n"
		"	}\n"
		"}\n"
		"material ode/MAT/Contact {\n"
		"	technique {\n"
		"		pass {\n"
		"			shader_ref   ode/VS\n"
		"			shader_ref ode/FS\n"
		"			render_states {\n"
		"				depth_test off\n"
		"				depth_mask off\n"
		"			}\n"
		"		}\n"
		"	}\n"
		"}\n"
		"material ode/MAT/Sphere {\n"
		"	technique {\n"
		"		pass {\n"
		"			shader_ref   ode/VS\n"
		"			shader_ref ode/FS\n"
		"			render_states {\n"
		"				blending on\n"
		"				blend_function SRC_ALPHA ONE_MINUS_SRC_ALPHA SRC_ALPHA ONE_MINUS_SRC_ALPHA \n"
		"				depth_test on\n"
		"				depth_mask on\n"
		"				cull_face BACK\n"
		"			}\n"
		"		}\n"
		"	}\n"
		"}";

	const REng::uchar DebugRenderer::RenderQueue_ODE_ID = 57;

	ContactRenderSettings::ContactRenderSettings() : mFlags(0){}
	void ContactRenderSettings::set(ContactRenderFlag flag){
		mFlags = mFlags | flag;
	}
	void ContactRenderSettings::unSet(ContactRenderFlag flag){
		mFlags = mFlags & ~flag;
	}
	bool ContactRenderSettings::isSet(ContactRenderFlag flag) const{
		return (mFlags & flag)!=false;
	}

	DebugRenderer::DebugRenderer(){
		REng::RenderQueueMap::getSingleton().registerRenderQueue(this,RenderQueue_ODE_ID);
		if(!REng::MaterialScriptParser::getSingleton().parseFromMem( gODEMaterial, strlen(gODEMaterial))){
			assert(0);
		}
		REng::MaterialManager::getSingleton().compileMaterialShaders();
		REng::MaterialManager::getSingleton().loadMaterials();
		REng::MaterialPtr odeMat = REng::MaterialManager::getSingleton().getMaterial("ode/MAT");
		assert(odeMat.get());
		mODERenderPass = odeMat->getSuitableData()->getRenderPass();
		odeMat = REng::MaterialManager::getSingleton().getMaterial("ode/MAT/Sphere");
		assert(odeMat.get());
		mODERenderPassSphere = odeMat->getSuitableData()->getRenderPass();
		odeMat = REng::MaterialManager::getSingleton().getMaterial("ode/MAT/Contact");
		assert(odeMat.get());
		mODERenderPassContact = odeMat->getSuitableData()->getRenderPass();
		assert(mODERenderPass);
		assert(mODERenderPassSphere);

		REngRMM = REng::RenderMatrixManager::getSingletonPtr();
		assert(REngRMM);
		REngDraw = REng::GPUDrawer::getSingletonPtr();
		assert(REngDraw);

		mActiveContactCount = 0;
		mContactList.reserve(100);

		mRenderStaticGeoms = true;
		mRenderNonSimulated = true;
		mEnabled = false;
		
		mContactSettings.set(ContactRenderEnabled);
		mContactSettings.set(ContactRenderPosition);
		mContactSettings.set(ContactRenderNormal);

		setMeshGeoms();
	}
	DebugRenderer::~DebugRenderer(){ ; }

	void DebugRenderer::setMeshGeoms(){
		REng::MeshGeomGenerator& MGG(REng::MeshGeomGenerator::getSingleton());
		mMeshGeom_Box       = MGG.getUnitAAB(false);
		mMeshGeom_HalfSpace = MGG.getUnitPlane();
		mMeshGeom_Sphere    = MGG.getUnitSphere(2);
		
		mMeshNode_SphereTri = & REng::MeshGeomGenerator::getSingleton().createTriad_Sphere(
			REng::RootNode::getSingleton());

		mMeshGeom_ContactPos.mIndexDataPtr .reset(new REng::IndexData() );
		mMeshGeom_ContactPos.mIndexDataPtr->primType = REng::PrimitiveType_Points;
		mMeshGeom_ContactPos.mVertexDataPtr.reset(new REng::VertexData());
		mMeshGeom_ContactPos.mVertexDataPtr->insertAttribute(
			REng::VertexAttribute(0,0,REng::VertexAttribDataType_Float,
			REng::VertexAttribDataCount3,REng::VertexAttribSem_Position));

		mMeshGeom_ContactNormal.mIndexDataPtr .reset(new REng::IndexData() );
		mMeshGeom_ContactNormal.mIndexDataPtr->primType = REng::PrimitiveType_Lines;
		mMeshGeom_ContactNormal.mVertexDataPtr.reset(new REng::VertexData());
		mMeshGeom_ContactNormal.mVertexDataPtr->insertAttribute(
			REng::VertexAttribute(0,0,REng::VertexAttribDataType_Float,
			REng::VertexAttribDataCount3,REng::VertexAttribSem_Position));

		mMeshGeom_ContactDepth.mIndexDataPtr .reset(new REng::IndexData() );
		mMeshGeom_ContactDepth.mIndexDataPtr->primType = REng::PrimitiveType_Lines;
		mMeshGeom_ContactDepth.mVertexDataPtr.reset(new REng::VertexData());
		mMeshGeom_ContactDepth.mVertexDataPtr->insertAttribute(
			REng::VertexAttribute(0,0,REng::VertexAttribDataType_Float,
			REng::VertexAttribDataCount3,REng::VertexAttribSem_Position));

		// TODO : complete
	}

	void DebugRenderer::registerGeom(Geom* g){
		assert(g);
		switch(g->getType()){
			case GeomTypeBox:
				mBoxList.push_back(static_cast<GeomBox*>(g));
				break;
			case GeomTypeCapsule:
				mCapsuleList.push_back(static_cast<GeomCapsule*>(g));
				break;
			case GeomTypeCylinder:
				mCylinderList.push_back(static_cast<GeomCylinder*>(g));
				break;
			case GeomTypeHalfSpace:
				mHalfSpaceList.push_back(static_cast<GeomHalfSpace*>(g));
				break;
			case GeomTypeRay:
				mRayList.push_back(static_cast<GeomRay*>(g));
				break;
			case GeomTypeSphere:
				mSphereList.push_back(static_cast<GeomSphere*>(g));
				break;
			case GeomTypeSpaceHash:
			case GeomTypeSpaceQuadTree:
			case GeomTypeSpaceSimple:
			case GeomTypeSpaceSweepAndPrune:
				LOG4CPLUS_INFO(Logger::getInstance("Phy"),
					"DebugRenderer | renderGeomsInSpace | Spaces are -currently- not renderable.");
				break;
			default:
				LOG4CPLUS_WARN(Logger::getInstance("Phy"),
					"DebugRenderer | renderGeomsInSpace | Non-renderable type detected.");
				break;
		}
	}
	void DebugRenderer::registerGeomsInSpace(GeomSpace& gs){
		size_t gc = gs.getChildCound();
		for(size_t i=0 ; i<gc ; ++i) registerGeom(gs.getGeom(i));
	}
	void DebugRenderer::registerContact(Contact& c){
		dContactGeom* dcg = new dContactGeom(c.collision()._getODE());
		mContactList.push_back(Contact_Collision(*dcg));
	}
	void DebugRenderer::clearContacts(){
		BOOST_FOREACH(Contact_Collision& c, mContactList){
			delete &(c._getODE());
		}
		mContactList.resize(0);
	}

	void DebugRenderer::preRenderQueueProcess(){
		renderSpheres();
/*		mODERenderPassSphere->prepareState();
		BOOST_FOREACH(GeomSphere* g, mSphereList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}
		mODERenderPassSphere->clearState();
*/		mODERenderPassSphere->prepareState();
		BOOST_FOREACH(GeomBox* g, mBoxList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}
		mODERenderPassSphere->clearState();
/*		BOOST_FOREACH(GeomCylinder* g, mCylinderList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}
		BOOST_FOREACH(GeomCapsule* g, mCapsuleList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}*/
		mODERenderPass->prepareState();
		BOOST_FOREACH(GeomHalfSpace* g, mHalfSpaceList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}
		mODERenderPass->clearState();
		if(mContactSettings.isSet(ContactRenderEnabled)){
			if(mContactSettings.isSet(ContactRenderPosition)) renderContactPositions();
			if(mContactSettings.isSet(ContactRenderNormal)) renderContactNormals();
		}
/*		BOOST_FOREACH(GeomRay* g, mRayList){
			if(!checkRenderable(*g)) continue;
			renderGeom(*g);
		}
*/		
	}
	void DebugRenderer::postRenderQueueProcess(){
		; // NO-OP
	}
	bool DebugRenderer::checkRenderable(Geom& g){
		if(!mRenderStaticGeoms){
			if(!g.isAttached()) return false;
		}
		if(!mRenderNonSimulated){
			if(g.isAttached()){
				if(!g.getAttachedBody().isSimulated()) return false;
			}
		}
		return true;
	}

	void DebugRenderer::renderContactPositions(){
		if(mContactList.size()==0) return;
		// Prepare the vertex buffer
		// All contact positions are rendered in a single pass as a single model
		size_t pointCount = mContactList.size();
		mMeshGeom_ContactPos.mIndexDataPtr->mRange.set(0,pointCount);
		mMeshGeom_ContactPos.mVertexDataPtr->mRange.set(0,pointCount);
		mMeshGeom_ContactPos.mVertexDataPtr->unsetBufferIndex(0);
		REng::SWVertexBuffer *vbufPtr = new REng::SWVertexBuffer(
				mMeshGeom_ContactPos.mVertexDataPtr->getVertexSize(0),pointCount);
		float* swbuff = (float*)vbufPtr->getBuffer();
		size_t i=0;
		BOOST_FOREACH(Contact_Collision& c, mContactList){
			REng::Vector3 pos(c.getPosition());
			swbuff[i++]=pos[0];  swbuff[i++]=pos[1];  swbuff[i++]=pos[2];
		}
		mMeshGeom_ContactPos.mVertexDataPtr->linkBufferToIndex(0,REng::VertexBufferPtr(vbufPtr));

		// Render the mesh geom with appropriate material
		GLfloat green[4] = {0,1,0,1};
		mODERenderPassContact->getUniformProperty("fragColor")->setData(green,sizeof(green));
		mODERenderPassContact->prepareState();
		glPointSize(7.0f);
		REngRMM->setModel(cml::identity_4x4(),true);
		REngDraw->drawMeshGeom(mMeshGeom_ContactPos);
		glPointSize(1.0f);
		mODERenderPassContact->clearState();
	}
	void DebugRenderer::renderContactNormals(){
		if(mContactList.size()==0) return;
		// Prepare the vertex buffer
		// All contact positions are rendered in a single pass as a single model
		size_t pointCount = mContactList.size()*2;
		mMeshGeom_ContactNormal.mIndexDataPtr->mRange.set(0,pointCount);
		mMeshGeom_ContactNormal.mVertexDataPtr->mRange.set(0,pointCount);
		mMeshGeom_ContactNormal.mVertexDataPtr->unsetBufferIndex(0);
		REng::SWVertexBuffer *vbufPtr = new REng::SWVertexBuffer(
				mMeshGeom_ContactPos.mVertexDataPtr->getVertexSize(0),pointCount);
		float* swbuff = (float*)vbufPtr->getBuffer();
		size_t i=0;
		BOOST_FOREACH(Contact_Collision& c, mContactList){
			REng::Vector3 pos(c.getPosition());
			swbuff[i++]=pos[0];  swbuff[i++]=pos[1];  swbuff[i++]=pos[2];
			pos += c.getNormal();
			swbuff[i++]=pos[0];  swbuff[i++]=pos[1];  swbuff[i++]=pos[2];
		}
		mMeshGeom_ContactNormal.mVertexDataPtr->linkBufferToIndex(0,REng::VertexBufferPtr(vbufPtr));

		// Render the mesh geom with appropriate material
		GLfloat blue[4] = {0,0,1,1};
		mODERenderPassContact->getUniformProperty("fragColor")->setData(blue,sizeof(blue));
		mODERenderPassContact->prepareState();
		REngRMM->setModel(cml::identity_4x4(),true);
		REngDraw->drawMeshGeom(mMeshGeom_ContactNormal);

		// Draw contact depths
		i=0;
		BOOST_FOREACH(Contact_Collision& c, mContactList){
			REng::Vector3 pos(c.getPosition());
			swbuff[i++]=pos[0];  swbuff[i++]=pos[1];  swbuff[i++]=pos[2];
			pos -= c.getDepth()*c.getNormal();
			swbuff[i++]=pos[0];  swbuff[i++]=pos[1];  swbuff[i++]=pos[2];
		}
		GLfloat black[4] = {0.5,0.5,0.5,0.5};
		mODERenderPassContact->getUniformProperty("fragColor")->setData(black,sizeof(blue));
		mODERenderPassContact->getUniformProperty("fragColor")->activate();
		REngDraw->drawMeshGeom(mMeshGeom_ContactNormal);

		mODERenderPassContact->clearState();
	}


	void DebugRenderer::renderSpheres(){
		REng::Matrix4 geomRot;
		for(REng::uint i=0;i<3;++i){
			REng::MeshNode*   meshNode = static_cast<REng::MeshNode*>(mMeshNode_SphereTri->getChild(i));
			REng::MeshPtr     meshPtr = meshNode->getMesh();
			REng::MeshGeom*   meshGeom = meshPtr->getSuitableData();
			REng::RenderPass* rp = meshPtr->mMaterial->getSuitableData()->getRenderPass();
			cml::matrix_rotation_quaternion(geomRot,meshNode->getRotation_Parent());
			rp->prepareState();
			BOOST_FOREACH(GeomSphere* g, mSphereList){
				if(!checkRenderable(*g)) continue;
				getGeomModelMatrix(*g,cModelMatrix);
				cModelMatrix *= geomRot;
				REngRMM->setModel(cModelMatrix,true);
				REngDraw->drawMeshGeom(*meshGeom);
			}
			rp->clearState();
		}
	}
	void DebugRenderer::renderGeom(GeomSphere& geom){
		getGeomModelMatrix(geom,cModelMatrix);
		REngRMM->setModel(cModelMatrix,true);
		REngDraw->drawMeshGeom(mMeshGeom_Sphere);
	}
	void DebugRenderer::renderGeom(GeomBox& geom){
		getGeomModelMatrix(geom,cModelMatrix);
		REngRMM->setModel(cModelMatrix,true);
		REngDraw->drawMeshGeom(mMeshGeom_Box);
	}
	void DebugRenderer::renderGeom(GeomCapsule& geom){
	}
	void DebugRenderer::renderGeom(GeomCylinder& geom){
	}
	void DebugRenderer::renderGeom(GeomHalfSpace& geom){
		getGeomModelMatrix(geom,cModelMatrix);
		REngRMM->setModel(cModelMatrix,true);
		REngDraw->drawMeshGeom(mMeshGeom_HalfSpace);
	}
	void DebugRenderer::renderGeom(GeomRay& geom){
		getGeomModelMatrix(geom,cModelMatrix);
		REngRMM->setModel(cModelMatrix,true);
		REngDraw->drawMeshGeom(mMeshGeom_Ray);
	}

	void DebugRenderer::getGeomModelMatrix(const GeomSphere& geom, REng::Matrix4& modelMat){
		REng::Matrix4 matMult;
		modelMat.identity();
		// 3. translation
		REng::Vector3& geomPos(geom.getPosition());
		cml::matrix_translation(matMult,geomPos);
		modelMat *= matMult;
		// 2. rotation (can rotate vertex coordinates and can be visualizaed)
		REng::Quaternion& geomRot(geom.getRotation());
		cml::matrix_rotation_quaternion(matMult,geomRot);
		modelMat *= matMult;
		// 1. scale
		float geomScale(geom.getRadius());
		cml::matrix_uniform_scale(matMult,geomScale);
		modelMat *= matMult;
	}
	void DebugRenderer::getGeomModelMatrix(const GeomBox& geom, REng::Matrix4& modelMat){
		REng::Matrix4 matMult;
		modelMat.identity();
		// 3. translation
		REng::Vector3& geomPos(geom.getPosition());
		cml::matrix_translation(matMult,geomPos);
		modelMat *= matMult;
		// 2. rotation
		REng::Quaternion& geomRot(geom.getRotation());
		cml::matrix_rotation_quaternion(matMult,geomRot);
		modelMat *= matMult;
		// 1. scale
		REng::Vector3& geomScale(geom.getSideLengths());
		cml::matrix_scale(matMult,geomScale/2);
		modelMat *= matMult;
	}
	void DebugRenderer::getGeomModelMatrix(const GeomHalfSpace& geom, REng::Matrix4& modelMat){
		REng::Matrix4 matMult;
		modelMat.identity();
		REng::Vector3 normal; Real eqD;
		geom.getParams(normal,eqD);
		// 3. translation
		REng::Vector3 geomPos(normal.normalize()*(float)eqD);
		cml::matrix_translation(matMult,geomPos);
		modelMat *= matMult;
		// 2. rotation
		REng::Quaternion geomRot;
		const REng::Vector3 unitPlaneNormal(0.f,0.f,1.f);
		cml::quaternion_rotation_vec_to_vec(geomRot,unitPlaneNormal,normal,true);
		cml::matrix_rotation_quaternion(matMult,geomRot);
		modelMat *= matMult;
		// 1. scale
		cml::matrix_uniform_scale(matMult,1000.0f/*infinite*/);
		modelMat *= matMult;
	}
	void DebugRenderer::getGeomModelMatrix(const GeomRay& geom, REng::Matrix4& modelMat){
		REng::Matrix4 matMult;
		modelMat.identity();
		// 3. translation
		REng::Vector3& geomPos(geom.getPosition());
		cml::matrix_translation(matMult,geomPos);
		modelMat *= matMult;
		// 2. rotation
		REng::Quaternion& geomRot(geom.getRotation());
		cml::matrix_rotation_quaternion(matMult,geomRot);
		modelMat *= matMult;
		// 1. scale
		float rayLength = geom.getLength();
		cml::matrix_scale(matMult,0.f,0.f,rayLength);
		modelMat *= matMult;
	}



} // namespace Phy 
