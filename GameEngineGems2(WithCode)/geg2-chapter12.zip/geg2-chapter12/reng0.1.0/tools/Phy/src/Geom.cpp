/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/Geom.h"
#include "Phy/Space.h"

#include <assert.h>

namespace Phy {

	Geom::Geom() :mID(0) { }
	Geom::~Geom(){ if(mID) dGeomDestroy(mID); }
	Geom::Geom(const Geom& g){(void)g;}
	Geom& Geom::operator==(const Geom& g){(void)g;return *this;}

	dGeomID Geom::_getID() const{
		return mID;
	}
	bool Geom::isNonPlacable() const { 
		return false;
	}

	//////////////////////////////////////////////////////////////////////////
	// ENABLE/DISABLE
	void Geom::setEnabled(bool flag){
		if(flag) {
			dGeomEnable(mID);
		} else {
			dGeomDisable(mID);
		}
	}
	bool Geom::isEnabled(){
		return dGeomIsEnabled(mID)!=0;
	}

	//////////////////////////////////////////////////////////////////////////
	// ATTACHMENT TO RIGID BODIES
	void Geom::attachToBody(RigidBody& body){
		assert(!isNonPlacable());
		if(isNonPlacable()) return;
		dGeomSetBody(mID,body._getID());
	}
	void Geom::detachFromBody(){
		dGeomSetBody(mID,0);
	}
	bool Geom::isAttached(){
		return dGeomGetBody(mID)!=0;
	}
	RigidBody& Geom::getAttachedBody(){
		dBodyID bid= dGeomGetBody(mID);
		assert(bid);
		RigidBody* b=(RigidBody*)dBodyGetData(bid);
		return *b;
	}

	//////////////////////////////////////////////////////////////////////////
	// GEOMS AND GEOM SPACES
	bool Geom::isItselfASpace(){
		return dGeomIsSpace(mID)!=0;
	}
	bool Geom::isInSpace(){
		return dGeomGetSpace(mID)!=0;
	}
	dSpaceID Geom::getSpace(){
		return dGeomGetSpace(mID);
	}

	//////////////////////////////////////////////////////////////////////////
	// BASIC POSITION / ROTATION QUERIES
	REng::Vector3 Geom::getPosition() const{
		const dReal* p = dGeomGetPosition(mID);
		return REng::Vector3( SIM_TO_WORLD(p[0]), SIM_TO_WORLD(p[1]), SIM_TO_WORLD(p[2]) );
	}
	REng::Quaternion Geom::getRotation() const{
		assert(!isNonPlacable());
		dQuaternion d;
		dGeomGetQuaternion(mID,d);
		// swap element order WXYZ -> XYZW
		return REng::Quaternion(d[1], d[2], d[3], d[0]);
	}
	REng::Matrix3 Geom::getRotationMatrix(){
		assert(!isNonPlacable());
		const dReal *dRotMar = dGeomGetRotation(mID);
		// TODO
		return cml::identity_3x3();
	}
	void Geom::setPosition(const REng::Vector3& pos){
		assert(!isNonPlacable());
		dGeomSetPosition(mID, WORLD_TO_SIM(pos[0]), WORLD_TO_SIM(pos[1]), WORLD_TO_SIM(pos[2]));
	}
	void Geom::setRotation(const REng::Quaternion& rot){
		assert(!isNonPlacable());
		dQuaternion dQuat;
		dQuat[0] = rot[3];
		dQuat[1] = rot[0];
		dQuat[2] = rot[1];
		dQuat[3] = rot[2];
		dGeomSetQuaternion(mID, dQuat);
	}

	//////////////////////////////////////////////////////////////////////////
	// OFFSETing
	void Geom::clearOffset(){
		assert(!isNonPlacable());
		dGeomClearOffset(mID);
	}
	void Geom::setOffsetPosition_Local(const REng::Vector3& pos){
		assert(!isNonPlacable());
		dGeomSetOffsetPosition(mID,
			WORLD_TO_SIM(pos[0]),WORLD_TO_SIM(pos[1]),WORLD_TO_SIM(pos[2]));
	}
	void Geom::setOffsetPosition_World(const REng::Vector3& pos){
		assert(!isNonPlacable());
		dGeomSetOffsetWorldPosition(mID,
			WORLD_TO_SIM(pos[0]),WORLD_TO_SIM(pos[1]),WORLD_TO_SIM(pos[2]));
	}
	void Geom::setOffsetRotation_Local(const REng::Quaternion& rot){
		assert(!isNonPlacable());
		dQuaternion dQuat;
		dQuat[0] = rot[3];
		dQuat[1] = rot[0];
		dQuat[2] = rot[1];
		dQuat[3] = rot[2];
		dGeomSetOffsetQuaternion(mID,dQuat);
	}
	void Geom::setOffsetRotation_World(const REng::Quaternion& rot){
		assert(!isNonPlacable());
		dQuaternion dQuat;
		dQuat[0] = rot[3];
		dQuat[1] = rot[0];
		dQuat[2] = rot[1];
		dQuat[3] = rot[2];
		dGeomSetOffsetWorldQuaternion(mID,dQuat);
	}
	REng::Vector3 Geom::getOffsetPosition_Local(){
		assert(!isNonPlacable());
		const dReal* p = dGeomGetOffsetPosition(mID);
		return REng::Vector3( SIM_TO_WORLD(p[0]), SIM_TO_WORLD(p[1]), SIM_TO_WORLD(p[2]) );
	}
	REng::Quaternion Geom::getOffsetRotation_Local(){
		assert(!isNonPlacable());
		dQuaternion d;
		dGeomGetOffsetQuaternion(mID,d);
		// swap element order WXYZ -> XYZW
		return REng::Quaternion(d[1], d[2], d[3], d[0]);
	}
	void Geom::setCategoryBits1(unsigned long bits){
		dGeomSetCategoryBits(mID,bits);
	}
	unsigned long Geom::getCatergoryBits1() const{
		return dGeomGetCategoryBits(mID);
	}
	void Geom::setCategoryBits2(unsigned long bits){
		dGeomSetCollideBits(mID,bits);
	}
	unsigned long Geom::getCatergoryBits2() const{
		return dGeomGetCollideBits(mID);
	}

	REng::GeomAxisAlignedBox Geom::getAABB() const{
		dReal aabbLimits[6];
		dGeomGetAABB(mID,aabbLimits);
		return REng::GeomAxisAlignedBox(
			SIM_TO_WORLD(REng::Vector3(aabbLimits[0],aabbLimits[2],aabbLimits[4])),
			SIM_TO_WORLD(REng::Vector3(aabbLimits[1],aabbLimits[3],aabbLimits[5])),
			REng::GeomAxisAlignedBox::Set_MinMax
			);
	}

	//////////////////////////////////////////////////////////////////////////
	// SPHERE
	GeomSphere::GeomSphere(GeomSpace* space, Real radius){
		mID = dCreateSphere(space?space->_getIDSpace():0,WORLD_TO_SIM(radius));
		dGeomSetData(mID,this);
	}
	GeomType GeomSphere::getType() const{ return GeomTypeSphere; }
	void GeomSphere::setRadius(Real radius){
		dGeomSphereSetRadius(mID,WORLD_TO_SIM(radius));
	}
	Real GeomSphere::getRadius() const{
		return SIM_TO_WORLD(dGeomSphereGetRadius(mID));
	}

	//////////////////////////////////////////////////////////////////////////
	// BOX
	GeomBox::GeomBox(GeomSpace* space, const REng::Vector3& sideLengths){
		dVector3 s;
		s[0] = WORLD_TO_SIM(sideLengths[0]);
		s[1] = WORLD_TO_SIM(sideLengths[1]);
		s[2] = WORLD_TO_SIM(sideLengths[2]);
		mID = dCreateBox(space?space->_getIDSpace():0,s[0],s[1],s[2]);
		dGeomSetData(mID,this);
	}
	GeomType GeomBox::getType() const{ return GeomTypeBox; }
	void GeomBox::setSideLengths(const REng::Vector3& sideLengths){
		dVector3 s;
		s[0] = WORLD_TO_SIM(sideLengths[0]);
		s[1] = WORLD_TO_SIM(sideLengths[1]);
		s[2] = WORLD_TO_SIM(sideLengths[2]);
		dGeomBoxSetLengths(mID,s[0],s[1],s[2]);
	}
	REng::Vector3 GeomBox::getSideLengths() const{
		dVector3 result;
		dGeomBoxGetLengths(mID,result);
		return REng::Vector3( 
			SIM_TO_WORLD(result[0]), SIM_TO_WORLD(result[1]), SIM_TO_WORLD(result[2]));
	}

	//////////////////////////////////////////////////////////////////////////
	// PLANE
	GeomHalfSpace::GeomHalfSpace(GeomSpace* space, const REng::Vector3& normal, Real eqD){
		mID = dCreatePlane(space?space->_getIDSpace():0,normal[0],normal[1],normal[2],WORLD_TO_SIM(eqD));
		dGeomSetData(mID,this);
	}
	GeomType GeomHalfSpace::getType() const{ return GeomTypeHalfSpace; }
	void GeomHalfSpace::setParams(const REng::Vector3& normal, Real eqD){
		dGeomPlaneSetParams(mID,normal[0],normal[1],normal[2],WORLD_TO_SIM(eqD));
	}
	void GeomHalfSpace::getParams(REng::Vector3& normal, Real& eqD) const{
		dVector4 result;
		dGeomPlaneGetParams(mID,result);
		normal[0] = result[0];
		normal[1] = result[1];
		normal[2] = result[2];
		eqD = SIM_TO_WORLD(result[3]);
	}

	//////////////////////////////////////////////////////////////////////////
	// CAPSULE
	GeomCapsule::GeomCapsule(GeomSpace* space, Real radius, Real length){
		mID = dCreateCapsule(space?space->_getIDSpace():0,WORLD_TO_SIM(radius),WORLD_TO_SIM(length));
		dGeomSetData(mID,this);
	}
	GeomType GeomCapsule::getType() const{ return GeomTypeCapsule; }
	void GeomCapsule::setParams(Real radius, Real length){
		dGeomCapsuleSetParams(mID,WORLD_TO_SIM(radius),WORLD_TO_SIM(length));
	}
	void GeomCapsule::getParams(Real& radius, Real& length) const{
		dReal r, l;
		dGeomCapsuleGetParams(mID,&r,&l);
		radius = SIM_TO_WORLD(r);
		length = SIM_TO_WORLD(l);
	}

	//////////////////////////////////////////////////////////////////////////
	// CYLINDER
	GeomCylinder::GeomCylinder(GeomSpace* space, Real radius, Real length){
		mID = dCreateCylinder(space?space->_getIDSpace():0,WORLD_TO_SIM(radius),WORLD_TO_SIM(length));
		dGeomSetData(mID,this);
	}
	GeomType GeomCylinder::getType() const{ return GeomTypeCylinder; }
	void GeomCylinder::setParams(Real radius, Real length){
		dGeomCylinderSetParams(mID,WORLD_TO_SIM(radius),WORLD_TO_SIM(length));
	}
	void GeomCylinder::getParams(Real& radius, Real& length) const{
		dReal r, l;
		dGeomCylinderGetParams(mID,&r,&l);
		radius = SIM_TO_WORLD(r);
		length = SIM_TO_WORLD(l);
	}

	//////////////////////////////////////////////////////////////////////////
	// RAY
	GeomRay::GeomRay(GeomSpace* space, Real length){
		mID = dCreateRay(space?space->_getIDSpace():0,length);
		dGeomSetData(mID,this);
	}
	GeomType GeomRay::getType() const{ return GeomTypeRay; }
	Real GeomRay::getLength() const{
		return SIM_TO_WORLD(dGeomRayGetLength(mID));
	}
	void GeomRay::setLength(Real length){
		dGeomRaySetLength(mID,WORLD_TO_SIM(length));
	}
	void GeomRay::setStartDir(const REng::Vector3& start, const REng::Vector3& direction){
		dGeomRaySet(mID,
			WORLD_TO_SIM(start[0]), WORLD_TO_SIM(start[1]), WORLD_TO_SIM(start[2]), 
			WORLD_TO_SIM(direction[0]), WORLD_TO_SIM(direction[1]), WORLD_TO_SIM(direction[2]) 
		);
	}
	void GeomRay::getStartDir(REng::Vector3& start, REng::Vector3& direction) const{
		dVector3 s;
		dVector3 d;
		dGeomRayGet(mID,s,d);
		start[0] = SIM_TO_WORLD(s[0]);
		start[1] = SIM_TO_WORLD(s[1]);
		start[2] = SIM_TO_WORLD(s[2]);
		direction[0] = SIM_TO_WORLD(d[0]);
		direction[1] = SIM_TO_WORLD(d[1]);
		direction[2] = SIM_TO_WORLD(d[2]);
	}

	//////////////////////////////////////////////////////////////////////////
	// TRANSFORM
	GeomTransform::GeomTransform(GeomSpace* space){
		mID = dCreateGeomTransform(space?space->_getIDSpace():0);
		dGeomSetData(mID,this);
	}
	GeomType GeomTransform::getType() const{ return GeomTypeTransform; }
	void GeomTransform::setOwnership(bool flag){
		dGeomTransformSetCleanup(mID,flag);
	}
	bool GeomTransform::hasOwnership(){
		return dGeomTransformGetCleanup(mID)!=0;
	}
	void GeomTransform::setAlias(bool flag){
		dGeomTransformSetInfo(mID,flag);
	}
	bool GeomTransform::isAlias(){
		return dGeomTransformGetInfo(mID)!=0;
	}
	void GeomTransform::attachGeom(Geom& g){
		assert(!g.isAttached());
		assert(!g.isInSpace());
		dGeomTransformSetGeom(mID,g.mID);
	}
	bool GeomTransform::hasGeom(){
		return dGeomTransformGetGeom(mID)!=0;
	}
	Geom& GeomTransform::getGeom(){
		dGeomID gid = dGeomTransformGetGeom(mID);
		assert(gid);
		Geom* g = (Geom*)dGeomGetData(gid);
		return *g;
	}

}

