/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/RigidBody.h"
#include "Phy/BodyNodeLink.h"
#include "Phy/World.h"

//! To find a world matching a world ID
#include "Phy/Simulator.h"

namespace Phy{

std::vector<RigidBody*> gBodyList;

//////////////////////////////////////////////////////////////////////////
// CONSTRUCT AND DESTRUCT

RigidBody::RigidBody(World& w)
	:mSubstance(*this)
{ 
	mOwnerSceneBody = 0;
	// create a rigid body
	mID = dBodyCreate(w._getID()); assert(mID);
	damping.mID = this->mID;
	autoSleep.mID = this->mID;
	dBodySetData(mID,this);
	// copy the initial substance to body
	dBodyGetMass(mID,&mSubstance.mOdeMass);

	dBodySetMovedCallback(mID,RigidBody::bodyMovedCallback);

	gBodyList.push_back(this);
	mNoCollideList.clear();
}
RigidBody::~RigidBody() { 
	dBodyDestroy(mID);

	//remove from list of simulated objects
	std::vector<RigidBody*>::iterator it = gBodyList.begin();
	std::vector<RigidBody*>::iterator itEnd = gBodyList.end();
	for( ; it != itEnd ; it++) {
		if((*it) == this) {
			gBodyList.erase(it);
			break;
		}
	}
}

World& RigidBody::getOwnerWorld(){
	// find the world with that ID
	return Simulator::getSingleton().getWorld(dBodyGetWorld(mID));
}

//////////////////////////////////////////////////////////////////////////
// GETTERS
REng::Vector3 RigidBody::getPosition() const {
	const dReal* p = dBodyGetPosition(mID);
	return REng::Vector3( SIM_TO_WORLD(p[0]), SIM_TO_WORLD(p[1]), SIM_TO_WORLD(p[2]) );
}
REng::Quaternion RigidBody::getRotation() const {
	const dReal* r = dBodyGetQuaternion(mID);
	// swap element order WXYZ -> XYZW
	return REng::Quaternion(r[1], r[2], r[3], r[0]);
}
REng::Matrix3 RigidBody::getRotationMatrix() const{
	const dReal *dRotMar = dBodyGetRotation(mID);
	// TODO
	return cml::identity_3x3();
}

REng::Vector3 RigidBody::getVelocity_Linear() const{
	const dReal* v = dBodyGetLinearVel(mID);
	return REng::Vector3( SIM_TO_WORLD(v[0]), SIM_TO_WORLD(v[1]), SIM_TO_WORLD(v[2]) );
}
REng::Vector3 RigidBody::getVelocity_Angular() const{
	const dReal* v = dBodyGetAngularVel(mID);
	return REng::Vector3( v[0], v[1], v[2] );
}

//////////////////////////////////////////////////////////////////////////
// SETTERS
void RigidBody::setSimulated(bool val) {
	if(val==true){
		dBodyEnable(mID);
		dGeomID gid = dBodyGetFirstGeom(mID);
		for(dGeomID gid = dBodyGetFirstGeom(mID); gid ; gid = dGeomGetBodyNext(gid)) {
			dGeomEnable(gid);
		}
	} else {
		dBodyDisable(mID);
		for(dGeomID gid = dBodyGetFirstGeom(mID); gid ; gid = dGeomGetBodyNext(gid)) {
			dGeomDisable(gid);
		}
	}
}
void RigidBody::setPosition(const REng::Vector3& pos ) {
	dBodySetPosition(mID,WORLD_TO_SIM(pos[0]), WORLD_TO_SIM(pos[1]), WORLD_TO_SIM(pos[2]));
	//for stability...
	setVelocity_Linear(REng::Vector3(0,0,0));
}
void RigidBody::setRotation(const REng::Quaternion& rot) {
	// swap element order XYZW -> WXYZ
	dQuaternion dQuat;
	dQuat[0] = rot[3];
	dQuat[1] = rot[0];
	dQuat[2] = rot[1];
	dQuat[3] = rot[2];
	dBodySetQuaternion(mID, dQuat);
	//for stability...
	setVelocity_Angular(REng::Vector3(0,0,0));
}
void RigidBody::setVelocity_Linear(const REng::Vector3& vel) {
	dBodySetLinearVel(mID, WORLD_TO_SIM(vel[0]), WORLD_TO_SIM(vel[1]), WORLD_TO_SIM(vel[2]));
}
void RigidBody::setVelocity_Angular(const REng::Vector3& vel){
	dBodySetAngularVel(mID, vel[0], vel[1], vel[2]);
}
void RigidBody::bodyMovedCallback(dBodyID id){
	RigidBody* rigidBody = (RigidBody*)dBodyGetData(id);
	BodyNodeLink* sBody = rigidBody->mOwnerSceneBody;
	if(sBody==0) return;
	// find the scene body which has this rigid body
	sBody->getNode().translate_World(rigidBody->getPosition(),true);
	sBody->getNode().rotate_World(rigidBody->getRotation(),true);
}


void RigidBody::disableCollisionWith(RigidBody *pb){
	// avoid re-inserting
	std::vector<RigidBody*>::iterator it = mNoCollideList.begin();
	std::vector<RigidBody*>::iterator itEnd = mNoCollideList.end();
	for( ; it != itEnd ; it++) if(pb == (*it)) return;

	mNoCollideList.push_back(pb);
}
bool RigidBody::canCollideWith(RigidBody *pb) const{
	std::vector<RigidBody*>::const_iterator it = mNoCollideList.begin();
	std::vector<RigidBody*>::const_iterator itEnd = mNoCollideList.end();
	for( ; it != itEnd ; it++) if(pb == (*it)) return false;
	return true;
}


} //namespace Phy

