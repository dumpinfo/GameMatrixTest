/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/CollisionCallback.h"

#include "Phy/Space.h"
#include "Phy/Contact.h"
#include "Phy/World.h"

namespace Phy {

	//////////////////////////////////////////////////////////////////////////
	// SAMPLE COLLISION CALLBACK LISTENER

	CollisionCallback::CollisionCallback() { }
	CollisionCallback::~CollisionCallback() { }

	void CollisionCallback::collisionCallback(GeomSpace* space, Geom* geom) {
		dSpaceCollide2(
			space->_getID(),
			geom->_getID(),
			static_cast<CollisionCallback*>(this),
			CollisionCallback::collisionCallbackODE);
	}
	void CollisionCallback::collisionCallback(GeomSpace* space) {
		dSpaceCollide(
			(dSpaceID)space->_getID(),
			static_cast<CollisionCallback*>(this),
			CollisionCallback::collisionCallbackODE);
	}
	void CollisionCallback::collisionCallbackODE(void *data, dGeomID geom_a, dGeomID geom_b) {
		CollisionCallback* colCallback = (CollisionCallback*) data;

		bool isSpaceA = (dGeomIsSpace(geom_a))?true:false;
		bool isSpaceB = (dGeomIsSpace(geom_b))?true:false;

		Geom* GeomA = static_cast<Geom*>(dGeomGetData(geom_a));
		Geom* GeomB = static_cast<Geom*>(dGeomGetData(geom_b));

		if(isSpaceA || isSpaceB ) {
			GeomSpace* SpaceA = static_cast<GeomSpace*>(dGeomGetData(geom_a));
			GeomSpace* SpaceB = static_cast<GeomSpace*>(dGeomGetData(geom_b));

			if(isSpaceA && isSpaceB) { // Space_A VS Space_B
				colCallback->collisionCallback(SpaceA, SpaceB);
			} else if(isSpaceA) { // Space_A VS Geom_B
				colCallback->collisionCallback(SpaceA, GeomB);
			} else {  // Space_B VS Geom_A
				colCallback->collisionCallback(SpaceB, GeomA);
			}

			// Collide geometries internal to the spaces
			if(isSpaceA) colCallback->collisionCallback(SpaceA);
			if(isSpaceB) colCallback->collisionCallback(SpaceB);
		} else {
			colCallback->collisionCallback(GeomA, GeomB);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	// A SAMPLE CALLBACK IMPLEMENTATION
	CollisionCallback_Default::CollisionCallback_Default(){
		mWorldID = 0;
		mJID = 0;
		mContactList = 0;
		mMaxContacts = 0;
		resizeContactList(16);
		mMaxContacts = 16;
	}
	CollisionCallback_Default::~CollisionCallback_Default(){
		if(mContactList) {
			free(mContactList);
			mContactList=0;
		}
	}
	void CollisionCallback_Default::setMaxContacts(unsigned short maxSize){
		resizeContactList(maxSize);
		mMaxContacts = maxSize;
	}
	unsigned short CollisionCallback_Default::getMaxContacts() const{
		return mMaxContacts;
	}
	void CollisionCallback_Default::resizeContactList(unsigned short listSize){
		if(mContactList) free(mContactList);
		mContactList = (dContact*)malloc(listSize*sizeof(dContact));
	}
	void CollisionCallback_Default::setWorld(World& w){
		mWorldID = w._getID();
	}
	void CollisionCallback_Default::setJointGroup(dJointGroupID jid){
		mJID = jid;
	}
	void CollisionCallback_Default::collisionCallback(Geom* GeomA, Geom* GeomB) {
		unsigned int num_contacts = dCollide(
			GeomA->_getID(),
			GeomB->_getID(),
			(int)mMaxContacts,
			&(mContactList[0].geom),
			sizeof(dContact));

		if(num_contacts==0) return;

		// two basic geoms intersected.
		// Add the contact data to joint group

		const dBodyID BodyA = GeomA->getAttachedBody()._getID();
		const dBodyID BodyB = GeomB->getAttachedBody()._getID();

		// filter out collisions between connected bodies (except for contact joints)
		if(BodyA!=0 && BodyB!=0)
			if(dAreConnectedExcluding(BodyA, BodyB, dJointTypeContact)){
				return;
			}

		for(unsigned int i=0; i<num_contacts; ++i) {
			Contact contact(mContactList[i]);
			if(contactFill(&contact)) {
				dJointAttach(dJointCreateContact(mWorldID,mJID,&mContactList[i]),BodyA,BodyB);
			} 
		}
	}
	bool CollisionCallback_Default::contactFill(Contact* contact){
		return true;
	}

}
