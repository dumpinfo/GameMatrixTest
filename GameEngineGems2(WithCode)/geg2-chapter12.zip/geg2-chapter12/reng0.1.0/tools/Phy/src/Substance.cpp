/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/Substance.h"

#include "Phy/RigidBody.h"

namespace Phy{

Substance::Substance(){
	mOwnerBody = 0;
	mAutoSynch = true;
	setZero();
}
Substance::Substance(RigidBody& owner) {
	mOwnerBody = &owner;
	mAutoSynch = true;
}

Substance::Substance(const Substance& rhs) {
	(void)rhs;
}
Substance& Substance::operator=(const Substance& rhs) {
	(void)rhs;
	return *this;
}
void Substance::synch(){
	if(mOwnerBody) dBodySetMass(mOwnerBody->mID,&mOdeMass);
}

void Substance::setTorus(Real density, Real majorRadius, Real minorRadius){
	mOdeMass.setZero();
	Real majSq = majorRadius*majorRadius;
	Real minSq = minorRadius*minorRadius;
	Real torusVolume = 0.25*REng::Math::PI*REng::Math::PI*
		2*majorRadius*
		4*minorRadius*minorRadius;
	Real torusMass = torusVolume*density;

	mOdeMass.mass = torusMass;
	mOdeMass.I[0 ]= (5*minSq+4*majSq)*torusMass/8.0;
	mOdeMass.I[10]= mOdeMass.I[0];
	mOdeMass.I[5 ]= (0.75*minSq+majSq)*torusMass;
}
void Substance::translate(const REng::Vector3& v){
	mOdeMass.translate(WORLD_TO_SIM(v[0]), WORLD_TO_SIM(v[1]), WORLD_TO_SIM(v[2]));
	synchAuto();
}
void Substance::rotate(const REng::Quaternion& q) {
	REng::Matrix4 m;
	cml::matrix_rotation_quaternion(m,q);
	dMatrix3 r;

	r[0] = m(0,0);
	r[1] = m(0,1);
	r[2] = m(0,2);

	r[3] = m(1,0);
	r[4] = m(1,1);
	r[5] = m(1,2);

	r[6] = m(2,0);
	r[7] = m(2,1);
	r[8] = m(2,2);

	r[9]  = 0.0;
	r[10] = 0.0;
	r[11] = 0.0;

	mOdeMass.rotate(r);
	synchAuto();
}

} // namespace Phy
