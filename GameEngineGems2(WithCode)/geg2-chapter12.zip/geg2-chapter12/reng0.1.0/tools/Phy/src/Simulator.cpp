/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "Phy/Simulator.h"
#include "Phy/RigidBody.h"
#include "Phy/Contact.h"
#include "Phy/World.h"
#include "Phy/Space.h"
#include "Phy/DebugRenderer.h"

#include "Phy/BodyNodeLink.h"

#include <log4cplus/logger.h>
#include <boost/foreach.hpp>
#include <memory>

#define PHY_HRTIMER

#ifdef PHY_HRTIMER
#include "Phy/HRTimer.hpp"
#endif // PHY_TIMER

using namespace log4cplus;

#define MAX_CONTACT_POINTS 16

namespace REng {
	template<> Phy::Simulator* REng::Singleton<Phy::Simulator>::ms_Singleton = 0;
}

namespace Phy {

	GeomHalfSpace *mPlaneID =0;

	// SINGLETON
	Simulator* Simulator::getSingletonPtr(void) {
		return ms_Singleton;
	}
	Simulator& Simulator::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	Simulator::Simulator()
		:mJointGroupID(0)
		,mIsActive(true)
		,MaxStepTime(0.5f)
	{
		LOG4CPLUS_INFO(Logger::getInstance("Phy"),"Physics simulator initialization...");
		dInitODE2(0);
		dAllocateODEDataForThread(dAllocateFlagCollisionData);

		dSetErrorHandler(Simulator::errorHandler);
		dSetDebugHandler(Simulator::debugHandler);
		dSetMessageHandler(Simulator::messageHandler);

		initWorld();

		mRenderer = new DebugRenderer();

		LOG4CPLUS_INFO(Logger::getInstance("Phy"),"Physics simulator created.");
	}
	Simulator::~Simulator(){
		dJointGroupDestroy(mJointGroupID);
		BOOST_FOREACH(World* w, mWorlds) { delete w; }
		dCloseODE();
	}

	World& Simulator::getWorld(size_t index){
		return *(mWorlds[index]);
	}
	World& Simulator::getWorld(dWorldID wid){
		BOOST_FOREACH(World* w, mWorlds){ if(w->_getID() == wid) return *w; }
		return *(mWorlds[0]);// just a fallback case
	}
	const dJointGroupID Simulator::getJointGroupID() const { 
		return mJointGroupID;
	}
	DebugRenderer* Simulator::getDebugRenderer(){
		return mRenderer;
	}

	//////////////////////////////////////////////////////////////////////////
	// INITIALIZE
	void Simulator::initWorld(){
		mWorlds.push_back(new World);
		World& w = *(mWorlds[0]); {
			w.setGravityForce(REng::Vector3(0.0,-15,0.0));

			w.mSimulationSpeed = 1.0f;

			w.mStepMethod = WorldStep_Normal;
			w.setStepTime(0.005); // do not set to a smaller value
			w.quickStep.setIterationCount(25);
			w.quickStep.setOverRelaxation(1.3);

			w.damping.setAngular(0.004f);
			w.damping.setAngularThres(0.0005f);
			w.damping.setLinear(0.004f);
			w.damping.setLinearThres(0.0005f);

			w.autoSleep.setActive(true);
			w.autoSleep.setAngularThres(0.1f);
			w.autoSleep.setLinearThres(0.03f);
			w.autoSleep.setAverageSamplesCount(7);
			w.autoSleep.setLimitSteps(20);
			w.autoSleep.setLimitSeconds(0.);

			w.setContactMaxCorrectingVelocity(100.0f);
			w.setContactSurfaceLayerDepth(0.005f);
			w.setERP(0.5);
			w.setCFM(1e-4);
		}

		// create a simple space for the first world
		(new SpaceSimple())->attachToWorld(w);

		mJointGroupID = dJointGroupCreate(0);

		// set a plane (TODO: REMOVE)
		mPlaneID = new GeomHalfSpace(w.getDefaultSpace(),REng::Vector3(0,1,0),0);
	}

	void Simulator::step(float sec) {
		if(mIsActive == false) return;

		//don't do anything if no objects are being simulated
		if(gBodyList.size() == 0) return;

		//make sure time step is reasonable
		if(sec <= 0) return;
		if(sec > MaxStepTime) {
			LOG4CPLUS_INFO(Logger::getInstance("Phy"),"The total simulation step time is larger "
				"than max allowed time ["<<sec<<">"<<MaxStepTime<<"]");
			return;
		}

	#ifdef PHY_HRTIMER
		HRTimer timer;
		double prePhyTime= timer.milliseconds();
	#endif // PHY_HRTIMER

		BOOST_FOREACH(Phy::World* w, mWorlds) { w->simulate(sec); }

	#ifdef PHY_HRTIMER
		double execTime = timer.milliseconds()-prePhyTime;
		LOG4CPLUS_INFO(Logger::getInstance("Perf"),"Phy, Simulator, "
			"stepTime, "<<sec<<", "
			"execTime, "<<execTime);
		if(execTime>50){
			LOG4CPLUS_INFO(Logger::getInstance("Phy"),"Simulator | "
				"Watch out, your simulator step calculation time is high : " << execTime);
		}
	#endif // PHY_HRTIMER
	}

	//Collision Callback
	void Simulator::PotentialHitCallback(void *data, dGeomID geom_a, dGeomID geom_b) {
		bool isSpaceA = (dGeomIsSpace(geom_a))?true:false;
		bool isSpaceB = (dGeomIsSpace(geom_b))?true:false;

		Geom* GeomA = static_cast<Geom*>(dGeomGetData(geom_a));
		Geom* GeomB = static_cast<Geom*>(dGeomGetData(geom_b));

		if(isSpaceA || isSpaceB) {
			// colliding a space with something
			dSpaceCollide2(geom_a, geom_b, data, &PotentialHitCallback);
			// now colliding all geoms internal to the space(s)
			if(isSpaceA) dSpaceCollide((dSpaceID)geom_a, data, &PotentialHitCallback);
			if(isSpaceB) dSpaceCollide((dSpaceID)geom_b, data, &PotentialHitCallback);
		} else {
			// colliding two "normal" (non-space) geoms

			RigidBody *entity1 = 0;
			RigidBody *entity2 = 0;
			if(GeomA->isAttached()) entity1 = &(GeomA->getAttachedBody());
			if(GeomB->isAttached()) entity2 = &(GeomB->getAttachedBody());
			if(entity1 && entity2) {
				if(!entity1->canCollideWith(entity2) || !entity2->canCollideWith(entity1)) {
					return;
				}
			}

			dContactGeom cp_array[MAX_CONTACT_POINTS];
			int num_cp = dCollide(geom_a, geom_b, MAX_CONTACT_POINTS, cp_array, sizeof(dContactGeom));

			if(num_cp==0) return;

			const dBodyID BodyA = dGeomGetBody(geom_a);
			const dBodyID BodyB = dGeomGetBody(geom_b);

			// filter out collisions between connected bodies (except for contact joints)
			if(BodyA !=0 && BodyB != 0)
				if(dAreConnectedExcluding(BodyA, BodyB, dJointTypeContact)){
					return;
				}

			// add these contact points to the simulation
			for(int i=0; i<num_cp; i++) {
				dContact tempContact;// = new dContact;

				tempContact.surface.mode = dContactApprox1 | dContactSoftCFM ;//| dContactSlip1 | dContactSlip2 ;
				tempContact.surface.slip1 = (dReal).2;
				tempContact.surface.slip2 = (dReal).1;
				tempContact.surface.soft_cfm = (dReal)0.01;
				tempContact.surface.mu = 0.2;

				tempContact.geom = cp_array[i];

				Simulator *simulator = Simulator::getSingletonPtr();
				dJointID j = dJointCreateContact(simulator->getWorld()._getID(), 
					simulator->getJointGroupID(), &tempContact);
				dJointAttach(j, BodyA, BodyB);
			}
		}
	}

	void Simulator::debugHandler(int errnum, const char *msg, va_list ap){
		char msgBuf[1024];
		vsprintf(msgBuf, msg, ap);
		LOG4CPLUS_WARN(Logger::getInstance("Phy"),"ODE Debug #"<<errnum<<": "<<msgBuf);
	}
	void Simulator::errorHandler(int errnum, const char *msg, va_list ap){
		char msgBuf[1024];
		vsprintf(msgBuf, msg, ap);
		LOG4CPLUS_ERROR(Logger::getInstance("Phy"),"ODE Error #"<<errnum<<": "<<msgBuf);
	}
	void Simulator::messageHandler(int errnum, const char *msg, va_list ap){
		char msgBuf[1024];
		vsprintf(msgBuf, msg, ap);
		LOG4CPLUS_INFO(Logger::getInstance("Phy"),"ODE Message #"<<errnum<<": "<<msgBuf);
	}
}
