/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_GEOM_H_
#define _PHY_GEOM_H_

#include "Phy/Config.h"
#include "Phy/RigidBody.h"

#include <REng/REng.h>

namespace Phy {

	//! List of supported ODE Collision Geometry types
	enum GeomType{
		GeomTypeSphere      = dSphereClass,
		GeomTypeBox         = dBoxClass,
		GeomTypeCapsule     = dCapsuleClass,
		GeomTypeCylinder    = dCylinderClass,
		GeomTypeHalfSpace   = dPlaneClass,
		GeomTypeRay         = dRayClass,
		GeomTypeTransform   = dGeomTransformClass,
		GeomTypeSpaceSimple = dSimpleSpaceClass,
		GeomTypeSpaceHash   = dHashSpaceClass,
		GeomTypeSpaceSweepAndPrune = dSweepAndPruneSpaceClass,
		GeomTypeSpaceQuadTree = dQuadTreeSpaceClass,
		GeomTypeMax         = dGeomNumClasses
		// Below are currently not supported
//		dConvexClass,
//		dTriMeshClass,
//		dHeightfieldClass,
//		dFirstSpaceClass,
//		dLastSpaceClass = dQuadTreeSpaceClass,
//		dFirstUserClass,
//		dLastUserClass = dFirstUserClass + dMaxUserClasses - 1,
	};

	//! @todo Add Convex class
	//! @todo Add TriMesh class

	/**
	 * @note You cannot create a geom directly, use one of the derived types.
	 */
	class Geom {
	public:
		virtual ~Geom();

		virtual GeomType getType() const = 0;

		dGeomID _getID() const;

		//! @note Non-placeable Geom's cannot be attached to a rigid body.
		virtual bool isNonPlacable() const;

		/** Disabled Geom's are completely ignored by dSpaceCollide and
		 * dSpaceCollide2, although they can still be members of a space
		 * @note Initially, Geoms are enabled by default.
		 */
		void setEnabled(bool flag=true);
		bool isEnabled();

		/** 
		 * Attaches the geom to a rigid body
		 *
		 * Setting a body on a geom automatically combines the position vector and
		 * rotation matrix of the body and geom, so that setting the position or
		 * orientation of one will set the value for both objects. 
		 * . If the geom was previously connected to a body then its
		 * new independent position/rotation is set to the current position/rotation
		 * of the body.
		 *
		 * @note Cannot attach non-placeable geoms.
		 */
		void attachToBody(RigidBody& body);
		//! Detaches the geom from the body it is connected to.
		//! @note The geom can still be placed in space for collision detection
		void detachFromBody();
		//! @return True if this geom attached to a rigid body, false otherwise
		bool isAttached();
		//! @return The rigid body this geom is attached to.
		//! @note Make sure that there is an attached geom first ( isAttached() )
		RigidBody& getAttachedBody();

		//! @return True if this geom created in a space, false otherwise
		bool isInSpace();
		dSpaceID getSpace();

		//! Is this geom itself a space?
		bool isItselfASpace();

		//! @return World-space position
		//! @note
		//!	If the geom is attached to a body, the body's position will be returned
		REng::Vector3 getPosition() const;

		//! @return World-space rotation of the body, in quaternion form.
		//! @note
		//!	If the geom is attached to a body, the body's rotation will be returned
		REng::Quaternion getRotation() const;

		//! @return World-space rotation of the body, in rotation matrix form.
		//! @note
		//!	If the geom is attached to a body, the body's rotation matrix will be returned
		//! @todo Incomplete, do not use this.
		REng::Matrix3 getRotationMatrix();

		//! @todo Document
		void setPosition(const REng::Vector3& pos);

		//! @todo Document
		void setRotation(const REng::Quaternion& rot);		

		//////////////////////////////////////////////////////////////////////////
		// OFFSETing

		void clearOffset();

		void setOffsetPosition_Local(const REng::Vector3& pos);
		void setOffsetPosition_World(const REng::Vector3& pos);
		void setOffsetRotation_Local(const REng::Quaternion& rot);
		void setOffsetRotation_World(const REng::Quaternion& rot);

		REng::Vector3 getOffsetPosition_Local();
		REng::Quaternion getOffsetRotation_Local();

		//////////////////////////////////////////////////////////////////////////
		// ADDITIONAL METHODS

		//! @return The axis-aligned bounding box of the current geom.
		//! @note If geom is of Phy::Space type, the bounding box that surrounds all 
		//!       internal geoms is returned.
		REng::GeomAxisAlignedBox getAABB() const;

		//////////////////////////////////////////////////////////////////////////
		// CATEGORY BITS
		void setCategoryBits1(unsigned long bits);
		unsigned long getCatergoryBits1() const;
		void setCategoryBits2(unsigned long bits);
		unsigned long getCatergoryBits2() const;

	protected:
		Geom();
		dGeomID mID;

	private:
		Geom(const Geom& g);
		Geom& operator==(const Geom& g);

		friend class GeomTransform;
	};

	class GeomSphere : public Geom {
	public:
		//! Creates a sphere at origin, with the given radius.
		//! @param space If non-zero, the new geom is inserted into given space.
		GeomSphere(GeomSpace* space, Real radius);
		GeomType getType() const;

		void setRadius(Real radius);
		Real getRadius() const;
	};

	class GeomBox : public Geom {
	public:
		//! Creates a box at origin, with the given side lengths.
		//! @param space If non-zero, the new geom is inserted into given space.
		GeomBox(GeomSpace* space, const REng::Vector3& sideLengths);
		GeomType getType() const;

		void setSideLengths(const REng::Vector3& sideLengths);
		REng::Vector3 getSideLengths() const;
	};

	//! Plane
	class GeomHalfSpace : public Geom {
	public:
		//! Creates a half-space(plane) in the given world-space position.
		//! Plane normal is (eqA, eqB, eqC), must have length 1.
		//! Plane equation is eqA*x + eqB*y +  eqC*z = eqD (global coordinates)
		//! The half-space that is filled is in the direction of normal (TODO: check!)
		//! @param space If non-zero, the new geom is inserted into given space.
		GeomHalfSpace(GeomSpace* space, const REng::Vector3& normal, Real eqD);
		GeomType getType() const;

		void setParams(const REng::Vector3& normal, Real eqD);
		void getParams(REng::Vector3& normal, Real& eqD) const;

		//! @note Planes are non placeable, cannot be tied to rigid bodies
		bool isNonPlacable() const { return true; }
	};

	class GeomCylinder : public Geom {
	public:
		//! Creates a cylinder. It is aligned to local Z-axis initially.
		//! @param space If non-zero, the new geom is inserted into given space.
		//! @param radius Radius of the half-sphere caps
		//! @param length The length of sweeping (ex: if 0, if identical to a full sphere)
		GeomCylinder(GeomSpace* space, Real radius, Real length);
		GeomType getType() const;
		
		void setParams(Real radius, Real length);
		void getParams(Real& radius, Real& length) const;
	};

	class GeomCapsule : public Geom {
	public:
		//! Creates a capsule (swept sphere). It is aligned to local Z-axis initially.
		//! @param space If non-zero, the new geom is inserted into given space.
		//! @param radius Radius of the half-sphere caps
		//! @param length The length of sweeping (ex: if 0, if identical to a full sphere)
		GeomCapsule(GeomSpace* space, Real radius, Real length);
		GeomType getType() const;
		
		void setParams(Real radius, Real length);
		void getParams(Real& radius, Real& length) const;
	};

	// An infinitely thin line segment that starts from the geom's position and 
	//! extends in the direction of the geom's local Z-axis
	class GeomRay : public Geom {
	public:
		//! Creates a ray from origin
		//! @param length The length of sweeping (ex: if 0, if identical to a full sphere)
		GeomRay(GeomSpace* space, Real length);
		GeomType getType() const;

		void setLength(Real length);
		Real getLength() const;

		//!@ Note The ray's rotation matrix will be adjusted so that the local Z-axis 
		//!       is aligned with the direction.
		//! @note Does not adjust ray length.
		void setStartDir(const REng::Vector3& start, const REng::Vector3& direction);

		//! @param start     Updated to ray start position in world-space
		//! @param direction Updated to unit length ray direction in world-space 
		void getStartDir(REng::Vector3& start, REng::Vector3& direction) const;
		
		//! @note Rays are non placeable.
		bool isNonPlacable() const { return true; }
	};


	/**
	 * This class encapsulates another geom 'E', allowing E to be positioned and
	 * rotated arbitrarily with respect to its point of reference.
	 * @note 
	 *		Using GeomTransform's, you can offset the center of a sphere, 
	 *		or rotate a cylinder so that its axis is something other than its default
	 * @todo Restrict the following: Cannot attach E to an object, cannot create E in s space! ???
	 */
	class GeomTransform : public Geom {
	public:
		//! @param length The length of sweeping (ex: if 0, if identical to a full sphere)
		GeomTransform(GeomSpace* space);
		GeomType getType() const;

		//! If set to true, the encapsulated geom will be destroyed when transfer geom is destroyed.
		//! @note Initially, transform does not own an attached geom.
		void setOwnership(bool flag=false);
		bool hasOwnership();

		//! @note Initially, transform does not behave as an alias for an attached geom.
		void setAlias(bool flag=false);
		bool isAlias();

		//! Sets the encapsulated geom.
		void attachGeom(Geom& g);

		//! @return True if this transform encapsulates a geom.
		//! @note   Initially, transform is not assigned a geom, so returns false.
		bool hasGeom();

		//! Returns the encapsulated geom
		//! @note Make sure it has a geom beforehand, 
		//!       otherwise you code will crash into 10000 pieces.
		Geom& getGeom();
	};

} // namespace Phy

#endif // _PHY_GEOM_H_
