/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_SUBSTANCE_H_
#define _PHY_SUBSTANCE_H_

#include "Phy/Config.h"

#include "REng/Math.h" // PI

namespace Phy {

	//! The orientation of a capsule
	enum CapsuleOrientation{
		Capsule_Along_X = 1,
		Capsule_Along_Y = 2,
		Capsule_Along_Z = 3
	};

	/**
	 * @class RigidBodySubstance
	 * @brief 
	 *	Body substance properties are:
	 *	- Mass (scalar value)
	 *	- CoG: Center of Gravity in body coordinates (3D vector)
	 *	- ITM : Inertia tensor matrix (3x3 matrix)
	 * @note
	 *	This class effectively wraps over ODE::dMass struct
	 */
	class Substance{
	public:
		//! @note This substance is not attached to any rigid body
		Substance();

		//! If true, the functions that update substance data will synch 
		//! @note Default is true
		bool mAutoSynch;

		//! If this substance has an owner body, synchs the data to owner body
		//! @note The substance center-of-mass must be at 0.
		void synch();

		Real getMass() const;
		REng::Vector3 getCenterOfGravity() const;
		//! @todo INCOMPLETE
		REng::Matrix3 getInertiaTensor() const;

		//! Checks if the mass and inertia matrix are positive
		//! @return True if both conditions are met
		bool isValid() const;

		//! Adds another static property to this one
		//! Resulting prop is the correct physical summation/adjustment of mass, CoG and ITM
		void add(const Substance& prop);

		//! Sets all the mass parameters to zero
		void setZero();

		//! Sets all the internal values directly, can use it to create custom static properties
		//! @param mass The mass of the body. 
		//! @param cog The center of gravity of the body in body coordinates
		//! @param I11 I22 I33 I12 I13 I23 The elements of the inertia matrix: 
		//!        ( I11 I12 I13 ) ( I12 I22 I23 ) ( I13 I23 I33 )
		//! @todo INCOMPLETE
		void setAll(Real mass, const REng::Vector3& cog, Real I11, Real I22, Real I33, Real I12, Real I13, Real I23);

		//! Updates the mass and the inertia tensor to reflect updated mass value
		//! Center of gravity is not updated
		void setMassAndAdjust(Real mass);

		//! Pre-defined substances for common physics geometries
		void setSphere(Real density, Real radius);
		void setBox(Real density, const REng::Vector3& size);
		void setCapsule(Real density, CapsuleOrientation direction, Real radius, Real length);
		void setCylinder(Real density, CapsuleOrientation direction, Real radius, Real length);
		void setTorus(Real density, Real majorRadius, Real minorRadius);

		//!  Adjust body static properties to represent the body displaced by the given translation
		void translate(const REng::Vector3& v);
		//!  Adjust body static properties to represent the body returned by the given rotation
		void rotate(const REng::Quaternion& q);

		//! TODO: returns in world coordinates
	//	REng::Matrix3 getInertiaTensor_World() const;

	private:
		RigidBody* mOwnerBody;
		dMass mOdeMass;
		
		//! Default constructor
		Substance(RigidBody& owner);

		//! Disabled Copy constructor 
		Substance(const Substance& rhs);
		//! Disabled Assignment operator
		Substance& operator=(const Substance& rhs);

		//! synchs to owner body if auto synch is enabled
		void synchAuto();

		friend class RigidBody;
	};

	#include "Phy/inl/Substance.inl"

} // namespace Phy

#endif // _PHY_SUBSTANCE_H_
