/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_CONTACT_H_
#define _PHY_CONTACT_H_

#include "Phy/Config.h"
#include "Phy/Geom.h"

namespace Phy {

	//! @brief Stores surface related constraint parameters for a contact data
	//! Wrapper over ODE contact surface parameter struct, for easier control of underlying ODE structure
	class Contact_Surface {
	public:
		//! @note This structure does not become the owner of p (does not delete it on destruction.)
		Contact_Surface(dSurfaceParameters& p);

		//! @return The wrapped ODE surface parameter object
		dSurfaceParameters& _getODE();

		/** [MANDATORY]
		 * Coulomb friction coefficient.
		 *	- Valid range
		 *	  min: 0:         Frictionless surface. 
		 *	  max: dInfinity: Infinite friction surface, no slipping possible.
		 * @note Frictionless contacts are less time consuming to compute than ones with friction, 
		 *		and infinite friction contacts can be cheaper than contacts with finite friction. 
		 */
		void setMU(Real mu);
		void setMUInf();
		Real getMU() const;

		//! Enumerates/defines possible optional members for surface parameters
		enum Member {

			/** [OPTIONAL], 1 parameter
			 * 1st parameter: Coulomb friction coefficient for FDir2
			 * - If not set, mu is used for FDir2.
			 *	- Valid range
			 *	  min: 0: Frictionless surface. 
			 *   max: dInfinity: Infinite friction surface, no slipping possible.
			 */
			Member_MU2,

			/** [OPTIONAL], 2 parameters
			 *  Bounciness for contact surface.
			 *  1st parameter: Restitution 
			 *  - Valid range:
			 *    min: 0: No bounciness
			 *    max: 1: Maximum bounciness
			 *  2nd parameter: Minimum incoming velocity.
			 *  - If incoming velocities of bodies is below the limit, surface behaves non-bouncy.
			 */
			Member_Bounce,

			//! [OPTIONAL], 1 parameter
			//! 1st parameter: Normal softness "error-reduction parameter"
			Member_SoftERP,
			//! [OPTIONAL], 1 parameter
			//! 1st parameter: Normal softness "constraint force mixing parameter"
			Member_SoftCFM,

			//! [OPTIONAL], 1 parameter
			//! If set, the contact surface is assumed to be moving independently of bodies, along FDir1.
			//! 1st parameter: 1D Velocity of contact surface along FDir1
			Member_MotionFDir1,  
			//! [OPTIONAL], 1 parameter
			//! If set, the contact surface is assumed to be moving independently of the motion of the bodies.
			//! 1st parameter: 1D Velocity of contact surface along FDir2
			Member_MotionFDir2,
			//! [OPTIONAL], 1 parameter
			//! If true, the contact surface is assumed to be moving independently of the motion of the bodies.
			//! 1st parameter: 1D Velocity of contact surface along Normal
			Member_MotionFNorm,

			//! [OPTIONAL], 1 parameter
			//! If set, uses force-dependent-slip (FDS) along FDir1
			//! 1st parameter: The coefficient of FDS along FDir1
			Member_FDS_FDir1,
			//! [OPTIONAL], 1 parameter
			//! If set, uses force-dependent-slip (FDS) along FDir2
			//! 1st parameter: The coefficient of FDS along FDir2
			Member_FDS_FDir2,

			//! [OPTIONAL], No parameters
			//! If set, uses the friction pyramid approximation for FDir1
			//! If not, the constant-force-limit approximation is used (and mu is a force limit).
			Member_FrictPyramid_FDir1,
			//! [OPTIONAL], No parameters
			//! If set, uses the friction pyramid approximation for FDir2
			//! If not, the constant-force-limit approximation is used (and mu is a force limit).
			Member_FrictPyramid_FDir2,
			//! [OPTIONAL], No parameters
			//! If set, uses the friction pyramid approximation for both FDir1 and FDir2
			//! If not, the constant-force-limit approximation is used (and mu is a force limit).
			Member_FrictPyramid_Both,

			//! [OPTIONAL]
			//! @todo
			//! If false, auto-calculate FDir1 (perpendicular, unpredictable)
			//! If true, use fdir1 parameter
			Member_FDir1
		};
		
		//! Sets an optional member
		//! @param p1 The first parameter of the member, if used
		//! @param p2 The second parameter of the member, if used
		void set(Member m, Real p1=0., Real p2=0.);
		//! Resets/Invalidates an optional member
		void reset(Member m);
		//! Retrieves optional member parameters.
		//! @return True iff the member is active
		bool get(Member m, Real& p1, Real& p2);

	private:
		dSurfaceParameters* mSurface;
		friend class Contact;
	};

	/**
	 * @brief Describes the contact point between two Geom's (Wrapper over ODE contact geom)
	 *
	 * If two bodies touch, or if a body touches a static feature in its environment, 
	 * the contact is represented by one or more "contact points", described by dContactGeom.
	 *
	 * The convention is that if body 1 is moved along the normal vector by a distance depth 
	 * (or equivalently if body 2 is moved the same distance in the opposite direction) 
	 * then the contact depth will be reduced to zero. 
	 * This means that the normal vector points "in" to body 1.
	 */
	class Contact_Collision {
	public:
		//! @note Does not create an ode object
		Contact_Collision();
		//! @note This structure does not become the owner of p (does not delete it on destruction.)
		Contact_Collision(dContactGeom& c);

		//! @return The wrapped ODE surface parameter object
		dContactGeom& _getODE();
		//! Sets the object wrapper by this object
		void _setODE(dContactGeom& c);

		void setPosition(const REng::Vector3& pos);
		REng::Vector3 getPosition() const;

		void setNormal(const REng::Vector3& normal);
		REng::Vector3 getNormal() const;

		void setDepth(Real depth);
		Real getDepth() const;

		Geom* getGeom1();
		Geom* getGeom2();
		void setGeom1(Geom* g);
		void setGeom2(Geom* g);

	private:
		//! The actual contact structure
		dContactGeom* mCollision;
		friend class Contact;
	};

	//! @brief Contact is the sum of collision and surface information (+ friction direction1)
	class Contact{
	public:
		//! @note This structure does not become the owner of c (does not delete it on destruction.)
		Contact(dContact& c);

		dContact& _getODE();

		//! @note Only a light wrapper over ODE contact geom
		Contact_Collision collision(); 

		//! @note Only a light wrapper over ODE surface parameters
		Contact_Surface surface(); // holds a pointer only

		void setFDir1(const REng::Vector3& fdir1);
		REng::Vector3 getFDir1() const;

	private:
		dContact* contact;
	};


	#include "Phy/inl/Contact.inl"
}

#endif // _PHY_CONTACT_H_
