/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_COLLISIONCALLBACK_H_
#define _PHY_COLLISIONCALLBACK_H_

#include "Phy/Config.h"

namespace Phy {

	//! @note To have a complete collision listener, you need to define a method which fills
	//!       in contact data (most importantly the surface parameters)
	class CollisionCallback {
	public:
		CollisionCallback();
		virtual ~CollisionCallback();

		//! Specialize this one to set contact data after
		virtual bool contactFill(Contact* contact) = 0;

		//! Generates contact points between two Geom's (they should not be geom spaces)
		//! Implements a basic static algorithm which calls extensible methods
		virtual void collisionCallback(Geom* geom1, Geom* geom2) = 0;

		//! The main ODE callback routine, used by the main simulation itself
		static void collisionCallbackODE(void *data, dGeomID geom_a, dGeomID geom_b);

		//! Generates collision inside the given geom space
		//! @note Default just calls regular ODE Space internal collide method
		virtual void collisionCallback(GeomSpace* space);

		//! @note geom parameter can hold a space itself
		//! @note Default just calls regular ODE Space-Geom/Space collide method
		virtual void collisionCallback(GeomSpace* space, Geom* geom);
	};
	
	//! - For each contact generated between geoms, inserts into a shared world / joint group
	//! - Does not fill in contact surface information
	//! - Default max contact count = 16
	class CollisionCallback_Default : public CollisionCallback {
	public:
		CollisionCallback_Default();
		~CollisionCallback_Default();

		void collisionCallback(Geom* geom1, Geom* geom2);
		bool contactFill(Contact* contact);

		void setMaxContacts(unsigned short maxSize);
		unsigned short getMaxContacts() const;

		void setWorld(World& w);
		void setJointGroup(dJointGroupID jid);

	private:
		unsigned short mMaxContacts;
		dContact* mContactList;
		dWorldID mWorldID;
		dJointGroupID mJID;

		void resizeContactList(unsigned short listSize);
	};

}

#endif // _PHY_COLLISIONCALLBACK_H_
