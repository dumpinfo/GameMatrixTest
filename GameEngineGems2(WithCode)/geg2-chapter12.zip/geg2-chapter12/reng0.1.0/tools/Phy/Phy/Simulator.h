/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_SIMULATOR_H_
#define _PHY_SIMULATOR_H_

#include "Phy/Config.h"
#include "Phy/World.h"

#include <REng/Singleton.h>

#include <vector>

namespace Phy {

	typedef std::vector<World*> WorldList;

	/**
	 * A simulator holds -multiple- worlds and geom spaces.
	 */
	class Simulator : public REng::Singleton<Simulator> {
	public:
		Simulator();
		~Simulator();

		static Simulator& getSingleton(void);
		static Simulator* getSingletonPtr(void);

		//! Set to false to disable any physical simulation in this world.
		bool mIsActive;

		//! @return the rigid body world at the given index
		World& getWorld(size_t index=0);

		//! @return the rigid body world with the given id
		World& getWorld(dWorldID wid);

		const float MaxStepTime;

		//! Steps the simulation given the seconds elapsed
		void step(float sec);

		//! TODO
		const dJointGroupID getJointGroupID() const;

		DebugRenderer* getDebugRenderer();

		// TODO: Make private!
		WorldList mWorlds;
		dJointGroupID mJointGroupID;

		static void PotentialHitCallback(void *data, dGeomID o1, dGeomID o2);

	private:

		void initWorld();

		DebugRenderer *mRenderer;

		static void errorHandler(int errnum, const char *msg, va_list ap);
		static void debugHandler(int errnum, const char *msg, va_list ap);
		static void messageHandler(int errnum, const char *msg, va_list ap);
	};

}

#endif // _PHY_SIMULATOR_H_
