/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_SPACE_H_
#define _PHY_SPACE_H_

#include "Phy/Config.h"
#include "Phy/Geom.h"

namespace Phy {

	/**
	 * A geom space is a specific kind of geom that holds a list of Geom's and/or spaces.
	 * Note that a space can hold a space, thus you can create space hierarchies by 
	 * attaching GeomSpaces to a GeomSpace.
	 * 
	 * Spaces can speed-up collision detection significantly, 
	 * by internally managing the spatial geom data and performing proximity queries more efficiently.
	 * So, try to choose right kind of spaces and to create reasonable hierarchies.
	 *
	 * @par 
	 * Attaching Spaces to Worlds
	 * - Spaces can be attached to worlds. Worlds can automatically link rigid bodies and spaces.
	 * - Initially, spaces are not attached to a world. You have to manually attach them.
	 */ 
	class GeomSpace : public Geom {
	public:
		virtual ~GeomSpace();

		//! @brief Provides access to internal ODE Space ID
		dSpaceID _getIDSpace();
		
		//! Spaces are not placable
		bool isNonPlacable() const { return true; }

		//! If set to true, the encapsulated objects will be destroyed when 
		//! the space is destroyed.
		//! @note Initially, spaces do own child objects, 
		//!       so deleting spaces will delete its children.
		void setOwnership(bool flag=true);
		bool hasOwnership();

		/**
		 * @brief Sets sublevel value for a space.
		 *
		 * Sublevel affects how the space is handled in dSpaceCollide2 when it is collided
		 * with another space. If sublevels of both spaces match, the function iterates 
		 * geometries of both spaces and collides them with each other. If sublevel of one
		 * space is greater than the sublevel of another one, only the geometries of the 
		 * space with greater sublevel are iterated, another space is passed into 
		 * collision callback as a geometry itself. By default all the spaces are assigned
		 * zero sublevel.
		 *
		 * @note
		 * The space sublevel IS NOT automatically updated when one space is inserted
		 * into another or removed from one. It is a client's responsibility to update sublevel
		 * value if necessary.
		 */
		void setSublevel(size_t level);
		size_t getSublevel() const;

		//////////////////////////////////////////////////////////////////////////
		// WORLD INTERFACE
	
		void attachToWorld(World& world);
		void detachFromWorld();
		bool isAttachedToWorld() const;
		World& getAttachedWorld();

		//////////////////////////////////////////////////////////////////////////
		// INTERNAL GEOMS

		void add(Geom& geom);
		void remove(Geom& geom);
		bool isChild(Geom& geom);
		size_t getChildCound();

		//! @param The geom index, must be between o and getChildCound()-1
		Geom* getGeom(size_t i);

		//! @todo add: dSpaceSetSublevel
		//! @todo add: dSpaceGetSublevel

	protected:
		GeomSpace();
		World* mAttachedWorld;
	};

	/**
	 * Simple Space
	 *
	 * Performs no collision culling, It checks every possible pair of Geom's
	 * for intersection, and reports the pairs whose bounding boxes overlap.
	 * 
	 * Time complexity: 
	 * - O(n^2), where n is number of child objects
	 * Prefer when:
	 * - number of objects is small (ex:less than 100)
	 * - implementing new spaces, use this class as a reference implementation 
	 *   that does not miss intersecting pairs.
	 */
	class SpaceSimple : public GeomSpace {
	public:
		SpaceSimple(GeomSpace* parentSpace=NULL);
		GeomType getType() const;
	};

	/**
	 * Multi-resolution hash table space. 
	 *
	 * This uses an internal data structure that records how each geom
	 * overlaps cells in one of several three dimensional grids. 
	 * Each grid has cubical cells of side lengths 2i, 
	 *   where i is an integer that ranges from a minimum to a maximum value. 
	 *
	 * Time complexity: 
	 * - O(n) approx, where n is number of child objects.
	 * More efficient when:
	 * - The child objects are not clustered together too closely.
	 */
	class SpaceHash : public GeomSpace {
	public:
		SpaceHash(GeomSpace* parentSpace=NULL);
		GeomType getType() const;

		void setLevels(int minLevel, int maxLevel);
		void getLevels(int& minLevel, int& maxLevel);
	};

	/**
	 * Quad-Tree Space
	 *
	 * This uses a pre-allocated hierarchical grid-based AABB tree to cull collision checks.
	 *
	 * Prefer when:
	 * - Large amounts of objects in landscape-shaped worlds.
	 * Memory requirement:
	 * - 4^depth * 32 bytes.
	 *
	 * @note
	 *		Currently dSpaceGetGeom is not implemented for the quad-tree space.
	 */ 
	class SpaceQuadTree : public GeomSpace {
	public:
		SpaceQuadTree(const REng::Vector3& center, const REng::Vector3& extents, size_t depth,
			GeomSpace* parentSpace=NULL);
		GeomType getType() const;
	};

	//! @todo Complete documentation
	class SpaceSwapAndPrune : public GeomSpace {
	public:
		enum AxisOrder {
			AxisOrder_XYZ = dSAP_AXES_XYZ,
			AxisOrder_XZY = dSAP_AXES_XZY,
			AxisOrder_YXZ = dSAP_AXES_YXZ,
			AxisOrder_YZX = dSAP_AXES_YZX,
			AxisOrder_ZXY = dSAP_AXES_ZXY,
			AxisOrder_ZYX = dSAP_AXES_ZYX
		};
		SpaceSwapAndPrune(AxisOrder axisOrder, GeomSpace* parentSpace=NULL);
		GeomType getType() const;
	};
}

#endif // _PHY_SPACE_H_
