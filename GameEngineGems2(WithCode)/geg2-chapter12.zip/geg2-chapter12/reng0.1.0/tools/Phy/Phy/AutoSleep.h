/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_AUTOSLEEP_H_
#define _PHY_AUTOSLEEP_H_

#include "Phy/Config.h"

namespace Phy {

	/**
	 * @brief The shared interface for auto sleep parameters for bodies and world defaults
	 *
	 * Every body can be enabled or disabled. Enabled bodies participate in the
	 * simulation, while disabled bodies are turned off and do not get updated
	 * during a simulation step. New bodies are always created in the enabled state.
	 *
	 * A disabled body that is connected through a joint to an enabled body will be
	 * automatically re-enabled at the next simulation step.
	 *
	 * Disabled bodies do not consume CPU time, therefore to speed up the simulation
	 * bodies should be disabled when they come to rest. This can be done automatically
	 * with the auto-disable feature.
	 *
	 * If a body has its auto-disable flag turned on, it will automatically disable
	 * itself when
	 *   @li It has been idle for a given number of simulation steps.
	 *   @li It has also been idle for a given amount of simulation time.
	 *
	 * A body is considered to be idle when the magnitudes of both its
	 * linear average velocity and angular average velocity are below given thresholds.
	 * The sample size for the average defaults to one and can be disabled by setting
	 * to zero with 
	 *
	 * Thus, every body has six auto-disable parameters: an enabled flag, a idle step
	 * count, an idle time, linear/angular average velocity thresholds, and the
	 * average samples count.
	 *
	 * Newly created bodies get these parameters from world.
	 */
	class AutoSleep{
	public:
		virtual void setActive(bool enabled)=0;
		virtual bool isActive() const=0;

		virtual void setLinearThres(Real linear_thres)=0;
		virtual Real getLinearThres() const=0;

		virtual void setAngularThres(Real angular_thres)=0;
		virtual Real getAngularThres() const=0;

		virtual void setLimitSteps(size_t steps)=0;
		virtual size_t getLimitSteps() const=0;

		virtual void setAverageSamplesCount(size_t s)=0;
		virtual size_t getAverageSamplesCount() const=0;

		virtual void setLimitSeconds(Real t)=0;
		virtual Real getLimitSeconds() const=0;
	};

	//! The interface specific for per-body setting
	class AutoSleep_Body : public AutoSleep{
	public:
		void resetToWorldDefaults();

		void setActive(bool enabled);
		bool isActive() const;

		void setLinearThres(Real linear_thres);
		Real getLinearThres() const;

		void setAngularThres(Real angular_thres);
		Real getAngularThres() const;

		void setLimitSteps(size_t steps);
		size_t getLimitSteps() const;

		void setAverageSamplesCount(size_t s);
		size_t getAverageSamplesCount() const;

		void setLimitSeconds(Real t);
		Real getLimitSeconds() const;
	private:
		AutoSleep_Body();
		dBodyID mID;
		friend class RigidBody;
	};

	//! The interface specific for per-world-default setting
	class AutoSleep_World : public AutoSleep{
	public:
		void setActive(bool enabled);
		bool isActive() const;

		void setLinearThres(Real linear_thres);
		Real getLinearThres() const;

		void setAngularThres(Real angular_thres);
		Real getAngularThres() const;

		void setLimitSteps(size_t steps);
		size_t getLimitSteps() const;

		void setAverageSamplesCount(size_t s);
		size_t getAverageSamplesCount() const;

		void setLimitSeconds(Real t);
		Real getLimitSeconds() const;
	private:
		AutoSleep_World();
		dWorldID mID;
		friend class World;
	};

	#include "Phy/inl/AutoSleep.inl"
}

#endif // _PHY_AUTOSLEEP_H_
