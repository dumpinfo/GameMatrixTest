/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_DAMPING_H_
#define _PHY_DAMPING_H_

#include "Phy/Config.h"

namespace Phy {

	/**
	 * @brief The shared interface for setting damping data for bodies and world defaults
	 *
	 * Damping serves two purposes: reduce simulation instability, and to allow
	 * the bodies to come to rest (and possibly auto-disabling them).
	 *
	 * Bodies are constructed using the world's current damping parameters. Setting
	 * the scales to 0 disables the damping.
	 *
	 * Here is how it is done: after every time step linear and angular
	 * velocities are tested against the corresponding thresholds. If they
	 * are above, they are multiplied by (1 - scale). So a negative scale value
	 * will actually increase the speed, and values greater than one will
	 * make the object oscillate every step; both can make the simulation unstable.
	 *
	 * To disable damping just set the damping scale to zero.
	 *
	 * You can also limit the maximum angular velocity. In contrast to the damping
	 * functions, the angular velocity is affected before the body is moved.
	 * This means that it will introduce errors in joints that are forcing the body
	 * to rotate too fast. Some bodies have naturally high angular velocities
	 * (like cars' wheels), so you may want to give them a very high (like the default,
	 * dInfinity) limit.
	 *
	 * @note The velocities are damped after the stepper function has moved the
	 * object. Otherwise the damping could introduce errors in joints. First the
	 * joint constraints are processed by the stepper (moving the body), then
	 * the damping is applied.
	 *
	 * @note The damping happens right after the moved callback is called; this way 
	 * it still possible use the exact velocities the body has acquired during the
	 * step. You can even use the callback to create your own customized damping.
	 */
	class Damping{
	public:
		//! @note Should be in the interval [0, 1].
		virtual void setLinear(Real scale) = 0;
		virtual Real getLinear() const = 0;
		//! @note Should be in the interval [0, 1].
		virtual void setAngular(Real scale) = 0;
		virtual Real getAngular() const = 0;

		virtual void setLinearThres(Real threshold) = 0;
		virtual Real getLinearThres() const = 0;
		virtual void setAngularThres(Real threshold) = 0;
		virtual Real getAngularThres() const = 0;

		virtual void setMaxSpeedAngular(Real max_speed) = 0;
		virtual Real getMaxAngularSpeed() const = 0;
	};

	//! The interface specific for per-body setting
	class Damping_Body : public Damping {
	public:
		void resetToWorldDefaults();

		void setLinear(Real scale);
		Real getLinear() const;
		void setAngular(Real scale);
		Real getAngular() const;

		void setLinearThres(Real threshold);
		Real getLinearThres() const;
		void setAngularThres(Real threshold);
		Real getAngularThres() const;

		void setMaxSpeedAngular(Real max_speed);
		Real getMaxAngularSpeed() const;
	private:
		Damping_Body();
		dBodyID mID;
		friend class RigidBody;
	};

	//! The interface specific for per-world-default setting
	class Damping_World : public Damping {
	public:
		//! @note Default: 0 (no damping). 
		void setLinear(Real scale);
		Real getLinear() const;
		//! @note Default: 0 (no damping). 
		void setAngular(Real scale);
		Real getAngular() const;

		//! @note Default: 0.01
		void setLinearThres(Real threshold);
		Real getLinearThres() const;
		//! @note Default: 0.01
		void setAngularThres(Real threshold);
		Real getAngularThres() const;

		void setMaxSpeedAngular(Real max_speed);
		Real getMaxAngularSpeed() const;
	private:
		Damping_World();
		dWorldID mID;
		friend class World;
	};

	#include "Phy/inl/Damping.inl"
}

#endif // _PHY_DAMPING_H_
