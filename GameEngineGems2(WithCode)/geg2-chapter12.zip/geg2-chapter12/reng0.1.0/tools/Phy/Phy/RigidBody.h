/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_RIGIDBODY_H_
#define _PHY_RIGIDBODY_H_

#include "Phy/Config.h"
#include "Phy/Substance.h"

#include "Phy/Damping.h"
#include "Phy/AutoSleep.h"

#include <vector>

namespace Phy{

	/**
	 * This class provides a wrapper over ODE Bodies. 
	 * @par
	 *		A rigid body has no geometric collision definition by default, you need to attach one or more
	 *		Phy::Geoms to give it some collision shape to be used in automated ODE collision detection.
	 * @par
	 *		You need to set the substance of the rigid body yourself, using Phy::Substance helper methods.
	 * @par
	 *    Use World class to creae a rigid body inside that world.
	 *    You cannot change the world the body is inside after creating the body.
	 *
	 * @note
	 *		If you want to create simple shaped physics bodies including collision geometries and
	 *    substances, use one of the derived classes (ex: RigidBodyBox)
	 * @note
	 *		Consult to ODE Manual for additional details.
	 *
	 *	@remark
	 * 	This class does not deal with rendering and does not store directly renderable data.
	 *    Use SceneBody class to link a physics body with a graphics mesh.
	 *
	 */
	class RigidBody {
	public:
		//! Any geom or rigid body this object is associated with is deleted
		virtual ~RigidBody();

		//! @brief Provides access to internal ODE Body ID
		dBodyID _getID() const;

		//! Rigid bodies can be attached to a scene body
		//! @note Scene body automatically updates its graphics position&rotation when the
		//!       rigid body moves.
		BodyNodeLink* mOwnerSceneBody;

		//! @return The world that this rigid body has been created inside
		World& getOwnerWorld();

		//! @note This property is not updated by the simulation, 
		//!       its contents should remain constant.
		//! @note Try to set the it before you start your simulation to prevent errors.
		Substance mSubstance;

		//! Damping state @see Damping
		Damping_Body damping;
		//! Auto-sleep state @see AutoSleep
		AutoSleep_Body autoSleep;

		//////////////////////////////////////////////////////////////////////////
		// GEOMS
		//////////////////////////////////////////////////////////////////////////

		//! @note To attach Geom's to a rigid body, use the geom methods

		//! @return The number of Geom's attached to this body
		//! @note The linked list is traversed, it takes O(n) time
		//! @todo Fix the behavior
		size_t getGeomCount() const;

		//! @return The geom at the given index
		//! @note index must be smaller than geom count @see getGeomCount
		Geom* getGeom(size_t index=0);
		const Geom* getGeom(size_t index=0) const;

		//////////////////////////////////////////////////////////////////////////
		// DYNAMICS
		//////////////////////////////////////////////////////////////////////////

		/**
		 * @brief Sets rigid body to kinematic state.
		 *		When in kinematic state the body isn't simulated as a dynamic
		 *		body (it's "unstoppable", doesn't respond to forces),
		 *		but can still affect dynamic bodies (e.g. in joints).
		 *		Kinematic bodies can be controlled by setting position and velocity.
		 *	@note A kinematic body has infinite mass. If you set its mass
		 *		to something else, it loses the kinematic state and behaves
		 *		as a normal dynamic body.
		 * @note The body is dynamic by default.
		 */
		void setKinematic(bool flag=true);

		//! @return True if kinematic state is enabled, false otherwise.
		bool isKinematic() const;
		
		//! Sets whether the body will be dynamically updated in simulation time-step
		//! @note Also commonly named as sleep/wake method
		void setSimulated(bool val=true);

		//! @return True if this body is updated in simulation time-step
		bool isSimulated() const;

		//////////////////////////////////////////////////////////////////////////
		// SPATIAL INFORMATION
		//////////////////////////////////////////////////////////////////////////

		//! @return World-space position
		//! @note The physics-space can be scaled w.r.t. world-space. 
		//!       Use this method to get correct world-space position of the physics body
		REng::Vector3 getPosition() const;

		//! @return World-space rotation of the body, in quaternion form.
		REng::Quaternion getRotation() const;

		//! @return World-space rotation of the body, in rotation matrix form.
		//! @todo Incomplete, do not use this.
		REng::Matrix3 getRotationMatrix() const;

		//! @return The linear velocity of the body
		//! @note The physics-space can be scaled w.r.t. world-space. 
		//!       Use this method to get correct world-space physical linear velocity
		REng::Vector3 getVelocity_Linear() const;

		//! @return The angular velocity of the body
		REng::Vector3 getVelocity_Angular() const;

		//! @brief Sets the position of a body to given world-space position.
		//! @remarks 
		//!	If body is attached to joints, the simulation can become inconsistent.
		//! @note 
		//!	The physics-space can be scaled w.r.t. world-space. (see SIM_TO_WORLD)
		//!	Use this method to set the physical simulation position correctly.
		void setPosition(const REng::Vector3& pos);

		//! Sets the rotation of the physics body to given world-space position
		//! @remarks 
		//!	If body is attached to joints, the simulation can become inconsistent.
		void setRotation(const REng::Quaternion& rot);		

		//! Sets the linear velocity of the body
		//! @note The physics-space can be scaled w.r.t. world-space. (see SIM_TO_WORLD)
		//!       Use this method to set physical linear velocity correctly
		void setVelocity_Linear(const REng::Vector3& vel);

		//! Sets the angular velocity of the body
		void setVelocity_Angular(const REng::Vector3& vel);

		//! @note Currently your only interface to static body properties
		void setMassAndAdjust(Real mass);

		///////////////////////////////////////////////////////////////////////////
		// FORCE / TORQUE ON BODY
		///////////////////////////////////////////////////////////////////////////

		//! @brief Add force at CoG of body in world coordinates.
		void addForce(const REng::Vector3& force);
		//! @brief Add torque at CoG of body in world coordinates.
		void addTorque(const REng::Vector3& torque);
		//! @brief Add force at CoG of body in local body coordinates.
		void addRelForce(const REng::Vector3& force);
		//! @brief Add torque at CoG of body in local body coordinates.
		void addRelTorque(const REng::Vector3& torque);
		//! @brief Add force at specified point in world coordinates.
		void addForceAtPos(const REng::Vector3& force, const REng::Vector3& pos);
		//! @brief Add force at specified point in local coordinates.
		void addForceAtRelPos(const REng::Vector3& force, const REng::Vector3& pos);

		//! @brief Sets the body force accumulation vector.
		void setTotalForce(const REng::Vector3& force);
		//! @brief Sets the body torque accumulation vector.
		void setTotalTorque(const REng::Vector3& torque);
		
		//! @return The current accumulated force vector on the body
		REng::Vector3 getTotalForce() const;
		//! @return The current accumulated torque vector on the body
		REng::Vector3 getTotalTorque() const;

		//////////////////////////////////////////////////////////////////////////
		// JOINTS
		//////////////////////////////////////////////////////////////////////////

		//! @return The number of joints that are attached to this body.
		size_t getJointCount() const;
		//! @return A joint attached to this body, given by index. 
		//!         Valid indexes are 0 to n-1 where n is the number of joints attached
		dJointID getJoint(size_t index);

		//////////////////////////////////////////////////////////////////////////
		// MISC
		//////////////////////////////////////////////////////////////////////////

		//! @brief Set whether the body is influenced by the world's gravity or not.
		//! @note The gravity is applied by default.
		//! @param flag If true, world gravity is applied on the body, else you know what.
		void setGravityApplied(bool flag=true);
		bool isGravityApplied() const;

		//! @brief Enables/disables the body's gyroscopic term.
		//! @remark
		//!	Disabling the gyroscopic term of a body usually improves
		//!	stability. It also helps turning spinning objects, like cars' wheels.
		void setGyroscobic(bool flag=true);
		bool isGyroscobic() const;

		/**
		 * Controls the way a body's orientation is updated at each timestep.
		 * @param mode 
		 *	\li 0: An ``infinitesimal'' orientation update is used.
		 *		This is fast to compute, but it can occasionally cause inaccuracies
		 *		for bodies that are rotating at high speed, especially when those
		 *		bodies are joined to other bodies.
		 *		This is the default for every new body that is created.
		 * \li 1: A ``finite'' orientation update is used.
		 *		This is more costly to compute, but will be more accurate for high
		 *		speed rotations.
		 * @remarks
		 *		High speed rotations can result in many types of error in a simulation, 
		 *    and the finite mode will only fix one of those sources of error.
		 */
		void setFiniteRotation(bool mode);
		bool hasFiniteRotation() const;

		/**
		 * Sets the finite rotation axis for a body.
		 * @remarks
		 *		This is axis only has meaning when the finite rotation mode is set
		 *		If this axis is zero (0,0,0), full finite rotations are performed on
		 *		the body.
		 *		If this axis is nonzero, the body is rotated by performing a partial finite
		 *		rotation along the axis direction followed by an infinitesimal rotation
		 *		along an orthogonal direction.
		 * @remarks
		 *		This can be useful to alleviate certain sources of error caused by quickly
		 *		spinning bodies. For example, if a car wheel is rotating at high speed
		 *		you can call this function with the wheel's hinge axis as the argument to
		 *		try and improve its behavior.
		 */
		void setFiniteRotationAxis(const REng::Vector3& axis);
		REng::Vector3 getFiniteRotationAxis() const;

		//////////////////////////////////////////////////////////////////////////
		// OTHERS
		//////////////////////////////////////////////////////////////////////////

		//! This callback is automatically called by ODE whenever a body position is updated
		//! If a rigid body is linked to a scene body, scene bodies spatial information is 
		//! automatically updated
		static void bodyMovedCallback(dBodyID id);

		// dGeomID dBodyGetFirstGeom(dBodyID b); // TODO
		// dGeomID dBodyGetNextGeom(dGeomID g); // TODO

		void disableCollisionWith(RigidBody *pb);
		bool canCollideWith(RigidBody *pb) const;

	protected:
		//! @note PhyGeom is not created in this method!
		//! @note The body is created in the simulator's default world.
		RigidBody(World& w);

		// ODE-side data
		mutable dBodyID mID;

		//! The list of bodies that this body cannot collide
		std::vector<RigidBody*> mNoCollideList;

		friend class Substance;
		friend class World;
	};

	extern std::vector<RigidBody*> gBodyList;

	#include "Phy/inl/RigidBody.inl"

} // namespace Phy

#endif // _PHY_RIGIDBODY_H_
