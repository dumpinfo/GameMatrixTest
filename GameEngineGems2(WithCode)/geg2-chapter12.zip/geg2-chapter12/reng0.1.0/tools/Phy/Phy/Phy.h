/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_PHY_H_
#define _PHY_PHY_H_

#include "Phy/Config.h"

#include "Phy/AutoSleep.h"
#include "Phy/CollisionCallback.h"
#include "Phy/Contact.h"
#include "Phy/Damping.h"
#include "Phy/DebugRenderer.h"
#include "Phy/Geom.h"
#include "Phy/RigidBody.h"
#include "Phy/RigidBodyBox.h"
#include "Phy/BodyNodeLink.h"
#include "Phy/Simulator.h"
#include "Phy/Space.h"
#include "Phy/World.h"

#endif // _PHY_PHY_H_
