/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_DEBUGRENDERER_H_
#define _PHY_DEBUGRENDERER_H_

#include "Phy/Config.h"
#include "Phy/Geom.h"

#include <REng/REng.h>

#include <vector>

namespace Phy {

	enum ContactRenderFlag{
		ContactRenderEnabled  = 0x001,
		ContactRenderPosition = 0x002,
		ContactRenderNormal   = 0x004,
		ContactRenderDepth    = 0x008
	};

	class ContactRenderSettings {
	public:
		ContactRenderSettings();
		void set(ContactRenderFlag flag);
		void unSet(ContactRenderFlag flag);
		bool isSet(ContactRenderFlag flag) const;
	private:
		size_t mFlags;
	};

	//! Stores the list of physics objects to be rendered on frame render time.
	//! Renders the lists using RenderQueue attachment points
	//! @todo Registered objects are pointers, when they are deleted by the system,
	//!       the pointers become invalid. How to solve this problem?
	class DebugRenderer : public REng::RenderQueue_Vector {
	public:
		static const REng::uchar RenderQueue_ODE_ID;

		DebugRenderer();
		~DebugRenderer();

		//! If true, renders non-simulated objects that are registered as well
		//! Default: False
		bool mRenderNonSimulated;

		//! If true, renders static geometries (not attached to rigid bodies)
		//! Default: True
		bool mRenderStaticGeoms;

		//! Registers all geoms in the given space to be rendered
		void registerGeomsInSpace(GeomSpace& gs);
		void registerGeom(Geom* g);

		void registerContact(Contact& c);
		void clearContacts();

		//////////////////////////////////////////////////////////////////////////
		// RENDER QUEUE INTERFACE

		void preRenderQueueProcess();
		void postRenderQueueProcess();

		ContactRenderSettings mContactSettings;

	private:
		
		//////////////////////////////////////////////////////////////////////////
		// LIST OF GEOMS TO BE RENDERED ON RENDER QUEUE PROCESS TIME
		std::vector<GeomSphere*>    mSphereList;
		std::vector<GeomBox*>       mBoxList;
		std::vector<GeomCapsule*>   mCapsuleList;
		std::vector<GeomCylinder*>  mCylinderList;
		std::vector<GeomHalfSpace*> mHalfSpaceList;
		std::vector<GeomRay*>       mRayList;

		//////////////////////////////////////////////////////////////////////////
		// Since contacts are created  / destroyed per frame, we need some kind 
		// of cache here. Members after mActiveContactCount are expected to be NULL and are
		// not processed
		std::vector<Contact_Collision> mContactList;
		size_t mActiveContactCount;

		//////////////////////////////////////////////////////////////////////////
		// MESH GEOMS
		void setMeshGeoms();
		REng::MeshGeom mMeshGeom_Sphere;
		REng::GroupNode* mMeshNode_SphereTri;
		REng::MeshGeom mMeshGeom_Box;
//		REng::MeshGeom mMeshGeom_Capsule;
		REng::MeshGeom mMeshGeom_Cylinder;
		REng::MeshGeom mMeshGeom_HalfSpace;
		REng::MeshGeom mMeshGeom_Ray;
		REng::MeshGeom mMeshGeom_Contact;

		// Dynamic mesh geoms (modified 
		REng::MeshGeom mMeshGeom_ContactPos;    // points index
		REng::MeshGeom mMeshGeom_ContactNormal; // lines index
		REng::MeshGeom mMeshGeom_ContactDepth;  // lines index

		REng::RenderPass* mODERenderPass;
		REng::RenderPass* mODERenderPassSphere;
		REng::RenderPass* mODERenderPassContact;

		// cache variables
		REng::RenderMatrixManager* REngRMM;
		REng::GPUDrawer*           REngDraw;
		REng::Matrix4 cModelMatrix;

		//! @return True if the given geom is to be rendered depending on debug renderer config
		bool checkRenderable(Geom& g);

		void renderSpheres();
		void renderGeom(GeomSphere& geom);
		void renderGeom(GeomBox& geom);
		void renderGeom(GeomCapsule& geom);
		void renderGeom(GeomCylinder& geom);
		void renderGeom(GeomHalfSpace& geom);
		void renderGeom(GeomRay& geom);
		void renderContactPositions();
		void renderContactNormals();
		void renderContactDepths();

		static void getGeomModelMatrix(const GeomSphere& geom, REng::Matrix4& modelMat);
		static void getGeomModelMatrix(const GeomBox& geom, REng::Matrix4& modelMat);
		// A single capsule mesh cannot be used. Need to render caps and the cylinder separately
		// static void getGeomModelMatrix(const GeomCapsule& geom, REng::Matrix4& modelMat);
		static void getGeomModelMatrix(const GeomHalfSpace& geom, REng::Matrix4& modelMat);
		static void getGeomModelMatrix(const GeomRay& geom, REng::Matrix4& modelMat);
	};

}

#endif // _PHY_DEBUGRENDERER_H_
