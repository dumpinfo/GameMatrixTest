/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_BODYNODELINK_H_
#define _PHY_BODYNODELINK_H_

#include "Phy/Config.h"
#include "Phy/RigidBody.h"

#include <REng/REng.h>

namespace Phy {

	//! BodyMeshLink aims to link a physically simulated rigid body to a scene node.
	//! The scene node position and rotation are automatically synch'ed with the rigid body.
	//!
	//! @note If you want to rotate/translate the scenebody, 
	//! use the physical body methods/simulation to do so!
	//! @note The linked node can be any type (camera / group / mesh / etc)
	class BodyNodeLink {
	public:
		BodyNodeLink();

		//////////////////////////////////////////////////////////////////////////
		// Physical body associated with the scene node
		void setPhyBody(RigidBody& body);
		RigidBody* getPhyBody() { return mBody; }
		const RigidBody* getPhyBody() const{ return mBody; }

		void setREngNode(REng::SceneNode& node);
		REng::SceneNode& getNode();
		const REng::SceneNode& getNode() const;

		//! @return The type of the node this link is connected to
		REng::SceneNodeType getNodeType() const;

		//! @note Make sure that getNodeType returns mesh node type
		REng::MeshNode& getMeshNode();
		const REng::MeshNode& getMeshNode() const;

		bool mUseCollisionProxy;
		REng::MeshGeom mHFCollisionProxy;
		
		// object bounding box data IN LOCAL SPACE
		// TEMP: Use the scene node's bounding box later...
		REng::GeomAxisAlignedBox mBoundingBox;

		//! Returns a copy of Translated/rotated local space bounding box
		//! Use this for collision detection purposes!
		REng::GeomAxisAlignedBox getWorldSpaceBox() const;

	private:
		//! Linked rendering context
		REng::SceneNode* mSceneNode;
		//! Linked physics context
		RigidBody *mBody;
	};

	#include "Phy/inl/BodyNodeLink.inl"
}

#endif // _PHY_BODYNODELINK_H_
