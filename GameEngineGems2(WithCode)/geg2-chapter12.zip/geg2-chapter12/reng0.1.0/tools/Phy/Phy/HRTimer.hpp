#ifndef _HRTIMER_H_
#define _HRTIMER_H_

#include <windows.h>

// NOTE: WINDOWS ONLY
// Using code snippets from http://www.mindcontrol.org/~hplus/misc/simple-timer.html
class HRTimer{
public:
	//! Initializes the constructed timer to current time.
	HRTimer(){
		unsigned __int64 pf;
		if(!QueryPerformanceFrequency( (LARGE_INTEGER *)&pf )){
			// fail TODO
		}
		freq_ = 1.0 / (double)pf;
		reset();
	}

	//! Resets the time counting.
	void reset(){
		// stores the counter to baseTime__
		QueryPerformanceCounter( (LARGE_INTEGER *)&baseTime_ );
	}

	//! seconds() returns the number of seconds (to very high resolution)
	//! elapsed since the timer was last created or reset().
	double seconds() {
		unsigned __int64 val;
		QueryPerformanceCounter( (LARGE_INTEGER *)&val );
		return (val - baseTime_) * freq_;
	}

	//! milliseconds() returns the number of milliseconds (to very high resolution)
	//! elapsed since the timer was last created or reset().
	double milliseconds() {
		return seconds() * 1000.0;
	}

protected:
	double freq_;
	unsigned __int64 baseTime_;

};

#endif // _HRTIMER_H_
