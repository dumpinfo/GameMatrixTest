/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_WORLD_H__
#define _PHY_WORLD_H__

#include "Phy/Config.h"
#include "Phy/RigidBody.h"
#include "Phy/RigidBodyBox.h"
#include "Phy/RigidBodySphere.h"

#include "Phy/Damping.h"
#include "Phy/AutoSleep.h"

namespace Phy {

	class WorldSimListener; // fw decleration

	//! Currently, ODE supports two types of stable integration methods
	enum WorldStepMethod{
		WorldStep_Normal = 0,
		WorldStep_Quick  = 1
	};

	//! The interface specific for per-body setting
	class QuickStepParams {
	public:
		//! Increasing iteration count will increase accuracy, but will also increase 
		//! step calculation time
		void setIterationCount(size_t i);
		size_t getIterationCOunt() const;
		
		//! See http://en.wikipedia.org/wiki/Successive_over-relaxation for details.
		//! @note Default: 1.3
		void setOverRelaxation(Real over_relax);
		Real getOverRelaxation() const;

	private:
		QuickStepParams();
		dWorldID mID;
		friend class World;
	};

	// The world object is a container for rigid bodies and joints. Objects in
	// different worlds can not interact, for example rigid bodies from two
	// different worlds can not collide.
	// All the objects in a world exist at the same point in time, thus one
	// reason to use separate worlds is to simulate systems at different
	// rates.
	class World{
	public:

		//! Destroy the world, all bodies inside, and all joints that are not part of a joint
		//! group. 
		//! @note Joints that are part of a joint group will be deactivated, and can be 
		//! destroyed by calling, for example, dJointGroupEmpty.
		~World();

		//! Access to internal ode structure
		dWorldID _getID();

		//! Creates a new rigid body structure that is created in this world.
		RigidBody* createRigidBody();
		RigidBodyBox* createRigidBodyBox(Real density, const REng::Vector3& size);
		RigidBodySphere* createRigidBodySphere(Real density, Real radius);

		//! If the given space is within this world, it is selected as the default space
		void setDefaultSpace(GeomSpace& space);
		GeomSpace* getDefaultSpace();
		size_t getSpaceCount();
		GeomSpaceList& getSpaces();

		//! The gravity force is applied to every rigid body in the world in each simulation step
		void setGravityForce(const REng::Vector3& g);
		REng::Vector3 getGravityForce() const;

		//! Shorthand for setting gravity to (0,0,0) vector
		void disableGravity();
		//! Sets the gravity to previously set value @see setGravityForce
		void enableGravity();
		//! If gravity is enabled, disables it. If it is disabled, enables it.
		void toggleGravity();
		//! @return True if no gravity force is applied to bodies in this world
		bool isGravityEnabled() const;
		
		/*!
		 * The error reduction parameter
		 *  
		 * Error Reduction Parameter: for joint constraints.  
		 * controls how much error correction is performed in each step
		 * 0 gives "bouncy joints" and 1 gives hard constraints (both unstable)
		 *
		 * @note Typical value range: [0.1-0.8] 
		 * @note Default: 0.2
		 */
		void setERP(Real erp);
		Real getERP() const;
		
		/*!
		 * Constraint force mixing
		 *
		 * Controls softness of collisions
		 * 0 means hard contacts while 1 means more spongy
		 *  
		 * @note Typical value range [10^9-1] 
		 * Default: 10^5 (ODE single precision) 10^10 (ODE double precision)
		 */
		void setCFM(Real cfm);
		Real getCFM() const;

		//! Each step is expected to be the same duration, set by the function call here.
		//! @note Default: 0.005
		void setStepTime(float sec);
		float getStepTime();

		//! Adds simulation time to this world
		void simulate(float sec);

		//! The main stepping method (the simulation pulse)
		//! @see setTimeStep
		void step();

		//! The stepping method that will be used to step the world
		//! @note Default method : Quick
		WorldStepMethod mStepMethod;

		//! The parameters used when using quick-step method
		QuickStepParams quickStep;

		//! If 1, simulation is in the same speed with frame rate.
		//! If less than one, you have to slow-mo effect.
		//! If greater than one, you will get dizzy
		//! @note Does not affect frame step time, so if you decrease sim speed, 
		//! the number of steps per render frame will decrease.
		float mSimulationSpeed;

		//////////////////////////////////////////////////////////////////////////
		// CONTACT PARAMETERS
		//////////////////////////////////////////////////////////////////////////

		//! Limiting maximum correcting velocity can prevent popping effects of deeply 
		//! penetrating objects
		//! @note Default: Infinity
		void setContactMaxCorrectingVelocity(Real vel);
		Real getMaxCorrectingVelocity() const;

		//! Set and get the depth of the surface layer around all geometry objects. 
		//! Contacts are allowed to sink into the surface layer up to the given 
		//! depth before coming to rest. The default value is zero. Increasing
		//! this to some small value (e.g. 0.001) can help prevent jittering 
		//! problems due to contacts being repeatedly made and broken
		void setContactSurfaceLayerDepth(Real depth);
		Real getContactSurfaceLayerDepth() const;

		//////////////////////////////////////////////////////////////////////////
		// RIGID BODY DEFAULT SETTINGS
		//////////////////////////////////////////////////////////////////////////

		Damping_World damping;
		AutoSleep_World autoSleep;

		/************************************************************************/
		/* World Listener                                                       */
		/************************************************************************/
		//! If successful, the listener will be notified in each simulate.
		//! You have to unregister a previous listener if active before.
		//! @note The world does not become the owner of listener
		void attachListener(WorldSimListener* listener);
		//! Active listener is detached
		void detachListener();
		//! Returns true if the world has a simulation listener
		bool isListenerActive() const;
		WorldSimListener* getListener();

	private:
		World();

		//! Disable copy constructor
		World(const World& rhs);
		//! Disable assignment operator
		World& operator=(const World& rhs);

		//! ODE Object
		mutable dWorldID mID;

		//! The list of spaces the objects in this world can be placed in
		GeomSpaceList mSpaceList;

		//! When you attach a geom to a body, its geom space is 
		//! set to the rigid body world's active geom space	
		GeomSpace* mActiveSpace;

		//! The gravity (used for rolling back to previous gravity value)
		mutable REng::Vector3 mGravityCache;
		
		//! The step amount, in seconds
		float mStepTime;

		//! The accumulated simulation time
		float mSimTimeAccum;

		//! The world can step if the accumulated sim time is larger than or equal to step time
		bool canStep();

		//! Adds the given space to this world
		//! @note A space can only be inserted to a single world
		//! @note GeomSpaces cannot add themselves to the world they are currently in
		void addSpace(GeomSpace& space);

		//! Removes the given space from this world, if it has been inserted
		void removeSpace(GeomSpace& space);
		
		//! Attached external renderer object, null if none
		WorldSimListener* mListener;

		friend class Simulator;
		friend class GeomSpace;
	};

	//! This class allows extending pre and post world stepping methods
	class WorldSimListener{
	public:
		~WorldSimListener();

		virtual void preStep();
		virtual void postStep();
	};

	#include "Phy/inl/World.inl"
} 

#endif // _PHY_WORLD_H__
