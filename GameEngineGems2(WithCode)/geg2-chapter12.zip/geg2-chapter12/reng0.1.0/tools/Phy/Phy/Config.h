/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _PHY_CONFIG_H_
#define _PHY_CONFIG_H_

#include <ode/ode.h>
#include <REng/Prerequisites.h>

#include <vector>

namespace Phy {

//! @todo The high-res timer is not cross-platform (only supported in windows)
#define PHY_HRTIMER

	//! Set this type to ODE's floating point precision
	typedef float Real;

	//the simulator performs better when you give it objects of roughly unit size
	//increase this to match the scale of the real-world objects being simulated
	#define WORLD_SCALE 1.0f
	#define SIM_TO_WORLD(x) (WORLD_SCALE*(x))
	#define WORLD_TO_SIM(x) ((x) / WORLD_SCALE)

	class Contact;
	class Contact_Collision;
	class Contact_Surface;

	class DebugRenderer;

	class AutoSleep;
	class AutoSleep_Body;
	class AutoSleep_World;

	class Damping;
	class Damping_Body;
	class Damping_World;

	class Geom;
	class GeomSphere;
	class GeomBox;
	class GeomHalfSpace;
	class GeomCapsule;
	class GeomCylinder;
	class GeomRay;
	class GeomTransform;

	class GeomSpace;
	class SpaceSimple;
	class SpaceHash;
	class SpaceQuadTree;
	class SpaceSwapAndPrune;

	class RigidBody;
	class RigidBodyBox;

	class Simulator;

	class BodyNodeLink;
	
	class Substance;

	class World;
	
	typedef std::vector<GeomSpace*> GeomSpaceList;
	typedef std::vector<Geom*> GeomList;

}

#endif // _PHY_CONFIG_H_
