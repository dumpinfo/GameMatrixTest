/***********************************************************************
    filename:   CEGUIREngGeometryBuffer.cpp
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngGeometryBuffer.h"

#include "CEGUIVertex.h"
#include "CEGUIRenderEffect.h"

#include <REng/RenderSystem.h>
#include <REng/RenderMatrixManager.h>
#include <REng/GPU/GPUDrawer.h>

namespace CEGUI {

/************************************************************************/
/* SIMPLE SETTER's                                                      */
/************************************************************************/
void REngGeometryBuffer::setTranslation(const Vector3& t) {
	d_translation = t;
	d_modelMatrixValid = false;
}
void REngGeometryBuffer::setRotation(const Vector3& r) {
	d_rotation = r;
	d_modelMatrixValid = false;
}
void REngGeometryBuffer::setPivot(const Vector3& p) {
	d_pivot = p;
	d_modelMatrixValid = false;
}
void REngGeometryBuffer::setClippingRegion(const Rect& region) {
	d_clipRect = region;
}
void REngGeometryBuffer::setRenderEffect(RenderEffect* effect) {
	d_effect = effect;
}
void REngGeometryBuffer::setActiveTexture(Texture* texture) {
	d_activeTexture = static_cast<REngTexture*>(texture);
}
/************************************************************************/
/* SIMPLE GETTER's                                                      */
/************************************************************************/
Texture* REngGeometryBuffer::getActiveTexture() const {
	return d_activeTexture;
}
uint REngGeometryBuffer::getVertexCount() const {
	return uint(d_vertices.size());
}
uint REngGeometryBuffer::getBatchCount() const {
	return uint(d_batches.size());
}
RenderEffect* REngGeometryBuffer::getRenderEffect() {
	return d_effect;
}
const double* REngGeometryBuffer::getMatrix() const {
	if(!d_modelMatrixValid) updateModelMatrix();
	static double d[16];
	for(uchar i=0; i<16; ++i) d[i] = d_modelMatrix.data()[i];
	return d;
}
const REng::Matrix4& REngGeometryBuffer::getModelMatrix() const{
	if(!d_modelMatrixValid) updateModelMatrix();
	return d_modelMatrix;
}

//----------------------------------------------------------------------------//
// Helper to allocate a HW vertex buffer and initialize a REng::RenderOperation
void REngGeometryBuffer::initialiseMeshGeom() const{
	size_t vertexCount = 1024;

	using namespace REng;
	// INDEX DATA ( no index buffer is used, triangles are indexed by order)
	d_meshGeom.mIndexDataPtr.reset(new IndexData());
	d_meshGeom.mIndexDataPtr->primType = PrimitiveType_Triangles;
	d_meshGeom.mIndexDataPtr->mRange.set(0,vertexCount); // put something there initially

	// VERTEX DATA
	d_meshGeom.mVertexDataPtr.reset(new VertexData());
	size_t vd_offset = 0;
	VertexAttribute posAttrib( 0, vd_offset, 
		VertexAttribDataType_Float, VertexAttribDataCount4, VertexAttribSem_Position);
	vd_offset += posAttrib.getSizeInBytes();
	VertexAttribute colorAttrib( 0, vd_offset,
		VertexAttribDataType_Float, VertexAttribDataCount4, VertexAttribSem_ColorDiffuse);
	vd_offset += colorAttrib.getSizeInBytes();
	VertexAttribute tcAttrib( 0, vd_offset,
		VertexAttribDataType_Float, VertexAttribDataCount2, VertexAttribSem_TexCoord0);
	d_meshGeom.mVertexDataPtr->insertAttribute(posAttrib);
	d_meshGeom.mVertexDataPtr->insertAttribute(colorAttrib);
	d_meshGeom.mVertexDataPtr->insertAttribute(tcAttrib);
	d_meshGeom.mVertexDataPtr->mRange.set(0,vertexCount); // put something there initially

	assert(sizeof(REngVertex) == d_meshGeom.mVertexDataPtr->getVertexSize(0));

	d_vBufGPU = new GPUVertexBuffer(
			sizeof(REngVertex),vertexCount,BufferUsageFreq_Static, BufferUsageNature_Draw);
	VertexBufferPtr vertexBufPtr(d_vBufGPU);
	d_meshGeom.mVertexDataPtr->linkBufferToIndex(0,vertexBufPtr);
}

void REngGeometryBuffer::resizeVertexBuffer(size_t bufVertexCount) const{
	if(bufVertexCount!=0) {
		d_vBufGPU->initStorage(sizeof(REngVertex)*bufVertexCount);
	}
	CHECKGLERROR_TERM();
}

//----------------------------------------------------------------------------//
REngGeometryBuffer::REngGeometryBuffer() :
    d_activeTexture(0),
    d_translation(0, 0, 0),
    d_rotation(0, 0, 0),
    d_pivot(0, 0, 0),
    d_effect(0),
    d_modelMatrixValid(false),
    d_vBufSynched(false)
{
    initialiseMeshGeom();
}

//----------------------------------------------------------------------------//
void REngGeometryBuffer::draw() const {
	// setup clip region
	GLint vp[4];
	glGetIntegerv(GL_VIEWPORT, vp);
	GLint scissor[4] = {
		static_cast<GLint>(d_clipRect.d_left),
		static_cast<GLint>(vp[3] - d_clipRect.d_bottom),
		static_cast<GLint>(d_clipRect.getWidth()),
		static_cast<GLint>(d_clipRect.getHeight())
	};
	REng::RenderSystem::getSingleton().setScissorTest(true, scissor[0],scissor[1],scissor[2],scissor[3]);

	if(!d_modelMatrixValid) updateModelMatrix();
	REng::RenderMatrixManager::getSingleton().setModel(d_modelMatrix,true);

	if(!d_vBufSynched) syncHardwareBuffer();

	size_t vertBufSize = d_meshGeom.mVertexDataPtr->mRange.getSize();

	const int pass_count = d_effect ? d_effect->getPassCount() : 1;
	for (int pass = 0; pass < pass_count; ++pass) {
		if(d_effect) d_effect->performPreRenderFunctions(pass);

			// draw the batches
			size_t vertexStartIndex = 0;
			BatchList::const_iterator i = d_batches.begin(), iEnd = d_batches.end();
			for ( ; i!=iEnd ; ++i) {
				size_t batchVertexCount = (*i).second;
				(*i).first->bindResource();
            // set up pointers to the vertex element arrays
				d_meshGeom.mVertexDataPtr->mRange.set(vertexStartIndex,batchVertexCount);
				d_meshGeom.mIndexDataPtr ->mRange.set(0,batchVertexCount);
				REng::GPUDrawer::getSingleton().drawMeshGeom(d_meshGeom);
				vertexStartIndex += batchVertexCount;
        }
	}

	d_meshGeom.mVertexDataPtr->mRange.set(0,vertBufSize);

	if(d_effect) d_effect->performPostRenderFunctions();
}

//----------------------------------------------------------------------------//
void REngGeometryBuffer::appendGeometry(const Vertex* const vbuff, uint vertex_count) {
	REng::GPUTexture* tex = 0;
	if(d_activeTexture) tex = d_activeTexture->getTexturePtr();

	if (d_batches.empty() || (tex != d_batches.back().first))
		d_batches.push_back(BatchInfo(tex, 0));

    // update size of current batch
    d_batches.back().second += vertex_count;

    // buffer these vertices
    REngVertex vd;
    const Vertex* vs = vbuff;
    for (uint i = 0; i < vertex_count; ++i, ++vs) {
        vd.pos[0]      = vs->position.d_x;
        vd.pos[1]      = vs->position.d_y;
        vd.pos[2]      = vs->position.d_z;
        vd.pos[3]      = 1.0f;
        vd.colour[0]   = vs->colour_val.getRed();
        vd.colour[1]   = vs->colour_val.getGreen();
        vd.colour[2]   = vs->colour_val.getBlue();
        vd.colour[3]   = vs->colour_val.getAlpha();
        vd.tex[0]      = vs->tex_coords.d_x;
        vd.tex[1]      = vs->tex_coords.d_y;
        d_vertices.push_back(vd);
    }

    d_vBufSynched = false;
}

//----------------------------------------------------------------------------//
void REngGeometryBuffer::reset() {
	d_vertices.clear();
	d_batches.clear();
	d_activeTexture = 0;
	d_vBufSynched = false;
}

//----------------------------------------------------------------------------//
void REngGeometryBuffer::updateModelMatrix() const {
	// translation to position geometry and offset to pivot point
	REng::Matrix4 trans,rot,inv_pivot_trans;
	cml::matrix_translation(
		trans,
		d_translation.d_x + d_pivot.d_x,
		d_translation.d_y + d_pivot.d_y,
		d_translation.d_z + d_pivot.d_z);

	// rotation
	REng::Quaternion qz,qy,qx;
	cml::quaternion_rotation_world_x(qx,REng::Angle::degree2radian(d_rotation.d_x));
	cml::quaternion_rotation_world_y(qy,REng::Angle::degree2radian(d_rotation.d_y));
	cml::quaternion_rotation_world_z(qz,REng::Angle::degree2radian(d_rotation.d_z));
	cml::matrix_rotation_quaternion(rot,qz * qy * qx);

	// translation to remove rotation pivot offset
	cml::matrix_translation(inv_pivot_trans,-d_pivot.d_x, -d_pivot.d_y, -d_pivot.d_z);

	// calculate final matrix
	d_modelMatrix = trans * rot * inv_pivot_trans;
	d_modelMatrixValid = true;
}

//----------------------------------------------------------------------------//
void REngGeometryBuffer::syncHardwareBuffer() const {
	// Reallocate h/w buffer as required
	size_t sizeCurrent = d_meshGeom.mVertexDataPtr->mRange.getSize();
	size_t sizeRequired = d_vertices.size();
	if(sizeCurrent < sizeRequired) {
		// calculate new size to use
		while(sizeCurrent < sizeRequired) sizeCurrent *= 2;
		resizeVertexBuffer(sizeCurrent);
	}

	// copy vertex data into hw buffer
	if(sizeRequired > 0) {
		d_vBufGPU->writeData(&d_vertices[0],sizeof(REngVertex)*sizeRequired,0,false);
	}

	d_vBufSynched = true;
}

} // End of  CEGUI namespace section

