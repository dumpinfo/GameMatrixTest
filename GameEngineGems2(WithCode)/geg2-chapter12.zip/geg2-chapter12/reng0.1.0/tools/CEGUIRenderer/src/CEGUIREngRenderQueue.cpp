/***********************************************************************
	 filename:   CEGUIREngRenderQueue.cpp
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngRenderQueue.h"

#include "CEGUISystem.h"

#include <REng/Material/MaterialScriptParser.h>
#include <REng/Material/MaterialManager.h>
#include <REng/RenderSystem.h>
#include <REng/RenderMatrixManager.h>

using namespace REng;

namespace CEGUI {

	const char *gGUIMaterial = 
		// a specialized sky vertex shader
		"shader cegui/VS {\n"
		"  type vertex\n"
		"	source {{\n"
		"		attribute vec4 re_Position;\n"
		"		attribute vec4 re_TexCoord0;\n"
		"		attribute vec4 re_ColorDiffuse;\n"
		"		varying vec2 vTexCo;\n"
		"		varying vec4 vColor;\n"
		"		void main (void) {\n"
		"			gl_Position = re_ModelViewProjectionMatrix * re_Position;\n"
		"			vTexCo = re_TexCoord0.xy;\n"
		"			vColor = re_ColorDiffuse;\n"
		"		}\n"
		"	}}\n"
		"}\n"
		"shader cegui/FS {\n"
		"  type fragment\n"
		"	source {{\n"
		"		uniform sampler2D guiTxt;\n"
		"		varying vec2 vTexCo;\n"
		"		varying vec4 vColor;\n"
		"		void main(void) { gl_FragColor = texture2D(guiTxt, vTexCo ) * vColor; }\n"
		"	}}\n"
		"	uniform_defaults { guiTexture int 0 }\n"
		"}\n"
		"material cegui/MAT { \n"
		"	technique { \n"
		"		pass { \n"
		"			shader_ref cegui/VS \n"
		"			shader_ref cegui/FS \n"
		"			render_states { \n"
		"				blending on \n"
		"				blend_function SRC_ALPHA ONE_MINUS_SRC_ALPHA SRC_ALPHA ONE_MINUS_SRC_ALPHA \n"
		"				depth_test off \n"
		"				depth_mask off \n"
		"				cull_face NONE \n"
		"			} \n"
		"		} \n"
		"	} \n"
		"}";

	const uchar RenderQueue_CEGUI::RenderQueue_GUI_ID = REnderQueueID_GUI;
	//! Registers itself to RenderQueue_GUI_ID
	RenderQueue_CEGUI::RenderQueue_CEGUI(){
		RenderQueueMap::getSingleton().registerRenderQueue(this,RenderQueue_GUI_ID);
		if(!MaterialScriptParser::getSingleton().parseFromMem( gGUIMaterial, strlen(gGUIMaterial))){
			assert(0);
		}
		REng::MaterialManager::getSingleton().compileMaterialShaders();
		REng::MaterialManager::getSingleton().loadMaterials();
		MaterialPtr guiMat = MaterialManager::getSingleton().getMaterial("cegui/MAT");
		assert(guiMat.get());
		mGuiRenderStates = guiMat->getSuitableData()->getRenderPass();
		assert(mGuiRenderStates);
	}
	void RenderQueue_CEGUI::preRenderQueueProcess(){
		REng::RenderMatrixManager& RMM(REng::RenderMatrixManager::getSingleton());
		RMM.pushAll();
		mGuiRenderStates->prepareState();
		RMM.setView(cml::identity_4x4(),true);
		GPUTexture::setActiveTextureUnit(0);
		System::getSingleton().renderGUI();
		CHECKGLERROR_TERM();
	}
	void RenderQueue_CEGUI::postRenderQueueProcess(){
		REng::RenderMatrixManager& RMM(REng::RenderMatrixManager::getSingleton());
		RMM.popAll();
		mGuiRenderStates->clearState();
		REng::RenderSystem::getSingleton().setScissorTest(false);
		CHECKGLERROR_TERM();
	}

} // End of  CEGUI namespace section
