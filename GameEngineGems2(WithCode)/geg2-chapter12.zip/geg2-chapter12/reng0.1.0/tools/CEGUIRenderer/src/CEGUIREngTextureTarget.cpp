/***********************************************************************
    filename:   CEGUIOpenGLTextureTarget.cpp
	 created:    Tue Feb 19 2010
	 author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngTextureTarget.h"
#include "CEGUIREngTexture.h"

// Start of CEGUI namespace section
namespace CEGUI {

	//----------------------------------------------------------------------------//
	const float REngTextureTarget::DEFAULT_SIZE = 128.0f;

	//----------------------------------------------------------------------------//
	REngTextureTarget::REngTextureTarget()
		:d_texture(REng::TextureType_2D)
		,d_frameBuffer()
	{
		d_CEGUITexture = new REngTexture(d_area.getSize());
		initialiseRenderTexture();
		// setup area and cause the initial texture to be generated.
		declareRenderSize(Size(DEFAULT_SIZE, DEFAULT_SIZE));
	}
	REngTextureTarget::~REngTextureTarget() {
	    delete d_CEGUITexture;
	}

	Texture& REngTextureTarget::getTexture() const { 
		return *d_CEGUITexture;
	}


	//----------------------------------------------------------------------------//
	void REngTextureTarget::declareRenderSize(const Size& sz) {
		// exit if current size is enough
		if ((d_area.getWidth() >= sz.d_width) && (d_area.getHeight() >=sz.d_height))
			return;

		setArea(Rect(d_area.getPosition(), sz));
		resizeRenderTexture();
	}

	//----------------------------------------------------------------------------//
	void REngTextureTarget::activate(){
		d_frameBuffer.bindResource();
		REngRenderTarget::activate();
	}

	//----------------------------------------------------------------------------//
	void REngTextureTarget::deactivate() {
		d_frameBuffer.unbindResource();
		REngRenderTarget::deactivate();
	}

	//----------------------------------------------------------------------------//
	void REngTextureTarget::clear() {
		GLfloat old_col[4];
		glGetFloatv(GL_COLOR_CLEAR_VALUE, old_col);

		d_frameBuffer.bindResource();
		glClearColor(0,0,0,0);
		glClear(GL_COLOR_BUFFER_BIT);
		d_frameBuffer.unbindResource();

		glClearColor(old_col[0], old_col[1], old_col[2], old_col[3]);
	}

	//----------------------------------------------------------------------------//
	void REngTextureTarget::initialiseRenderTexture() {
		d_frameBuffer.bindResource();

		// set up the texture the FBO will draw to
		d_texture.setInternalFormat(REng::ImageFormat_RGBA);
		d_texture.setMagFilter(REng::MagFilter_Linear);
		d_texture.setMinFilter(REng::MinFilter_Linear);
		d_texture.updateSamplerState();
		d_texture.loadFromMemToResource(
			static_cast<GLsizei>(DEFAULT_SIZE),static_cast<GLsizei>(DEFAULT_SIZE),
			REng::PixelDataType_UByte,REng::PixelDataFormat_RGBA,0);
		d_texture.attachToActiveFBO();
		d_frameBuffer.unbindResource();

		d_CEGUITexture->setTexturePtr(&d_texture);
	}

	//----------------------------------------------------------------------------//
	void REngTextureTarget::resizeRenderTexture() {
		const Size sz(d_area.getSize());
		d_texture.loadFromMemToResource(
			static_cast<GLsizei>(sz.d_width),static_cast<GLsizei>(sz.d_height),
			REng::PixelDataType_UByte,REng::PixelDataFormat_RGBA,0);
		clear();
		d_CEGUITexture->setTexturePtr(&d_texture);
	}

} // End of  CEGUI namespace section
