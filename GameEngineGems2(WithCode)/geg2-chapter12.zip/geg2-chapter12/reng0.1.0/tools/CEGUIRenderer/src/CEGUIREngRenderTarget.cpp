/***********************************************************************
    filename:   CEGUIOpenGLRenderTarget.cpp
    created:    Wed Jan 14 2009
    author:     Paul D Turner
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngRenderTarget.h"
#include <cmath>

#include <REng/RenderMatrixManager.h>
#include <REng/RenderSystem.h>
#include <REng/Viewport.h>

// Start of CEGUI namespace section
namespace CEGUI
{
//----------------------------------------------------------------------------//
const double REngRenderTarget::d_yfov_tan = 0.267949192431123;

//----------------------------------------------------------------------------//
REngRenderTarget::REngRenderTarget()
	:d_area(0, 0, 0, 0)
	,mProjectionMatrixValid(false){}
REngRenderTarget::~REngRenderTarget(){}

void REngRenderTarget::activate() {
	REng::RenderSystem::getSingleton().setViewportTrans(
		REng::RectI(d_area.d_left,d_area.getWidth(),d_area.d_top,d_area.getHeight()));

	if(!mProjectionMatrixValid) updateProjectionMatrix();
	REng::RenderMatrixManager::getSingleton().setProjection(mProjectionMatrix);
}
void REngRenderTarget::deactivate() {
}


REng::Vector3 transProjW(const REng::Matrix4& m, const REng::Vector3& v){
	float fInvW = 1.0 / ( m(3,0) * v[0] + m(3,1) * v[1] + m(3,2) * v[2] + m(3,3) );
	return REng::Vector3(
		( m(0,0) * v[0] + m(0,1) * v[1] + m(0,2) * v[2] + m(0,3) ) * fInvW,
		( m(1,0) * v[0] + m(1,1) * v[1] + m(1,2) * v[2] + m(1,3) ) * fInvW,
		( m(2,0) * v[0] + m(2,1) * v[1] + m(2,2) * v[2] + m(2,3) ) * fInvW
		);
}


//----------------------------------------------------------------------------//
void REngRenderTarget::unprojectPoint(const GeometryBuffer& buff,
    const Vector2& p_in, Vector2& p_out) const
{
	if (!mProjectionMatrixValid) updateProjectionMatrix();

	const REngGeometryBuffer& geomBuf = static_cast<const REngGeometryBuffer&>(buff);

	const float midx = d_area.getWidth() * 0.5f;
	const float midy = d_area.getHeight() * 0.5f;

	// viewport matrix
	const REng::Matrix4 vpmat(
		midx,    0,    0,    d_area.d_left + midx,
		0,    -midy,  0,    d_area.d_top + midy,
		0,      0,    1,    0,
		0,      0,    0,    1
		);

	// matrices used for projecting and unprojecting points
	const REng::Matrix4 proj(geomBuf.getModelMatrix() * mProjectionMatrix* vpmat);
	const REng::Matrix4 unproj(cml::inverse(proj));

	REng::Vector3 in;

	// unproject the ends of the ray
	in[0] = midx;
	in[1] = midy;
	in[2] = -d_viewDistance;
	const REng::Vector3 r1(transProjW(unproj, in));
	in[0] = p_in.d_x;
	in[1] = p_in.d_y;
	in[2] = 0;
	// calculate vector of picking ray
	const REng::Vector3 rv(r1 - transProjW(unproj, in));

	// project points to orientate them with GeometryBuffer plane
	in[0] = 0.0;
	in[1] = 0.0;
	const REng::Vector3 p1(transProjW(proj, in));
	in[0] = 1.0;
	in[1] = 0.0;
	const REng::Vector3 p2(transProjW(proj, in));
	in[1] = 0.0;
	in[0] = 1.0;
	const REng::Vector3 p3(transProjW(proj, in));

	// calculate the plane normal
	const REng::Vector3 pn(cml::cross(p2 - p1,p3 - p1));
	// calculate distance from origin
	const float plen = pn.length();
	const float dist = -(p1[0] * (pn[0] / plen) +
		p1[1] * (pn[1] / plen) +
		p1[2] * (pn[2] / plen));

	// calculate intersection of ray and plane
	const float pn_dot_rv = cml::dot(pn,rv);
	const float tmp = pn_dot_rv != 0.0 ?
		(cml::dot(pn,r1) + dist) / pn_dot_rv :
	0.0;

	p_out.d_x = static_cast<float>(r1[0] - rv[0] * tmp);
	p_out.d_y = static_cast<float>(r1[1] - rv[1] * tmp);
}

//----------------------------------------------------------------------------//
void REngRenderTarget::updateProjectionMatrix() const
{
    const double w = d_area.getWidth();
    const double h = d_area.getHeight();
    const double aspect = w / h;
    const double midx = w * 0.5;
    d_viewDistance = midx / (aspect * d_yfov_tan);

	 const float nearZ = d_viewDistance * 0.5f;
	 const float farZ = d_viewDistance * 2.0f;
	 const float nr_sub_far = nearZ - farZ;

	 mProjectionMatrix.zero();
	 mProjectionMatrix(0,0) = 3.732050808f / aspect;
	 mProjectionMatrix(0,3) = -d_viewDistance;
	 mProjectionMatrix(1,1) = -3.732050808f;
	 mProjectionMatrix(1,3) = d_viewDistance;
	 mProjectionMatrix(2,2) = -((farZ + nearZ) / nr_sub_far);
	 mProjectionMatrix(3,2) = 1.0f;
	 mProjectionMatrix(3,3) = d_viewDistance;
	 mProjectionMatrixValid= true;
}

} // End of  CEGUI namespace section
