/***********************************************************************
    filename:   CEGUIMyTexture.cpp
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngTexture.h"

#include "CEGUIExceptions.h"
#include "CEGUISystem.h"
#include "CEGUIImageCodec.h"

namespace CEGUI {

uint32 REngTexture::d_textureNumber = 0;

/************************************************************************/
/* GETTERS                                                              */
/************************************************************************/
const Size& REngTexture::getSize() const {
    return d_size;
}
const Size& REngTexture::getOriginalDataSize() const {
    return d_originalSize;
}
const Vector2& REngTexture::getTexelScaling() const {
    return d_texelScaling;
}
REng::GPUTexture* REngTexture::getTexturePtr() const {
    return d_texture;
}

//----------------------------------------------------------------------------//
REngTexture::REngTexture()
	:d_size(0, 0)
	,d_originalSize(0, 0)
	,d_texelScaling(0, 0) 
{
	generateREngTexture();
}
REngTexture::REngTexture(const String& filename, const String& resourceGroup)
	:d_size(0, 0)
	,d_originalSize(0, 0)
	,d_texelScaling(0, 0)
{
	generateREngTexture();
	loadFromFile(filename, resourceGroup);
}
REngTexture::REngTexture(const Size& sz)
	:d_size(0, 0)
	,d_originalSize(0, 0)
	,d_texelScaling(0, 0)
{
	generateREngTexture();
	setTextureSize(sz);
}
REngTexture::REngTexture(REng::GPUTexture* tex) {
	setTexturePtr(tex);
}
REngTexture::~REngTexture() {
	delete d_texture;
}

//----------------------------------------------------------------------------//
void REngTexture::loadFromFile(const String& filename,
                               const String& resourceGroup) {
    System* sys = System::getSingletonPtr();
    if(!sys)
        throw RendererException("MyTexture::loadFromFile - "
                                "CEGUI::System object has not been created: "
                                "unable to access ImageCodec.");

    RawDataContainer texFile;
    sys->getResourceProvider()->loadRawDataContainer(filename, texFile, resourceGroup);
    Texture* res = sys->getImageCodec().load(texFile, this);
    sys->getResourceProvider()->unloadRawDataContainer(texFile);

    if (!res)throw RendererException("MyTexture::loadFromFile - " +
                                sys->getImageCodec().getIdentifierString()+
                                " failed to load image '" + filename + "'.");
}
//----------------------------------------------------------------------------//
void REngTexture::loadFromMemory(const void* buffer, const Size& buffer_size,
                                 PixelFormat pixel_format) {
	// get pixel type for the target texture.
	REng::PixelDataFormat target_fmt =
		(pixel_format == PF_RGBA) ? REng::PixelDataFormat_RGBA : REng::PixelDataFormat_RGB;

	// try to create a Ogre::Texture from the input data
	if(!d_texture->loadFromMemToResource(
		buffer_size.d_width, buffer_size.d_height,
		REng::PixelDataType_UByte, target_fmt, buffer))
	{
		throw RendererException("MyTexture::loadFromMemory: Failed to create Texture object from memory.");
	}

	d_size.d_width = d_texture->getWidth();
	d_size.d_height = d_texture->getHeight();
	d_originalSize = buffer_size;
	updateCachedScaleValues();
}

//----------------------------------------------------------------------------//
void REngTexture::saveToMemory(void* buffer) {
	// TODO
}

//----------------------------------------------------------------------------//
void REngTexture::updateCachedScaleValues() {
	const float orgW = d_originalSize.d_width;
	const float texW = d_size.d_width;
	d_texelScaling.d_x = 1.0f / ((orgW == texW) ? orgW : texW);

	const float orgH = d_originalSize.d_height;
	const float texH = d_size.d_height;
	d_texelScaling.d_y = 1.0f / ((orgH == texH) ? orgH : texH);
}

void REngTexture::generateREngTexture(){
	// try to create a Ogre::Texture with given dimensions
	d_texture = new REng::GPUTexture(REng::TextureType_2D);
	d_texture->setInternalFormat(REng::ImageFormat_RGBA);
	d_texture->setMagFilter(REng::MagFilter_Linear);
	d_texture->setMinFilter(REng::MinFilter_Linear);
	d_texture->setWrap(REng::WrapAxis_S,REng::WrapMode_ClampToEdge);
	d_texture->setWrap(REng::WrapAxis_T,REng::WrapMode_ClampToEdge);
	d_texture->updateSamplerState();
}

//----------------------------------------------------------------------------//
std::string REngTexture::getUniqueName() {
	char uniqueName[256];
	sprintf(uniqueName,"_cegui_reng_%d", d_textureNumber++);
	return std::string(uniqueName);
}

//----------------------------------------------------------------------------//
void REngTexture::setTexturePtr(REng::GPUTexture* texture) {
	if(texture != d_texture)
	{ if(d_texture) delete d_texture; }
	d_texture = texture;
	if(d_texture) {
		d_size.d_width = d_texture->getWidth();
		d_size.d_height= d_texture->getHeight();
	} else {
		d_size = Size(0, 0);
	}
	d_originalSize = d_size;
	updateCachedScaleValues();
}

void REngTexture::setTextureSize(const Size& sz){
	d_texture->loadFromMemToResource(
		sz.d_width, sz.d_height,
		REng::PixelDataType_UByte,
		REng::PixelDataFormat_RGBA,0 );

	d_size.d_width = sz.d_width;
	d_size.d_height = sz.d_height;
	d_originalSize = sz;
	updateCachedScaleValues();
}

} // End of  CEGUI namespace section
