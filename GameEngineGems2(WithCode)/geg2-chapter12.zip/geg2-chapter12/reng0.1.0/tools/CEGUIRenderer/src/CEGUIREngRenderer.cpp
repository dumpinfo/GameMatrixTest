/***********************************************************************
    filename:   CEGUIOpenGLRenderer.cpp
	 created:    Tue Feb 19 2010
	 author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngRenderer.h"

#include "CEGUIExceptions.h"
#include "CEGUIEventArgs.h"
#include "CEGUIImageCodec.h"
#include "CEGUIDynamicModule.h"
#include "CEGUISystem.h"
#include "CEGUIRenderingRoot.h"

#include "CEGUIREngGeometryBuffer.h"
#include "CEGUIREngTexture.h"
#include "CEGUIREngRenderQueue.h"
#include "CEGUIREngWindowTarget.h"
#include "CEGUIREngTextureTarget.h"

#include <REng/RenderSystem.h>
#include <REng/GPU/GPUConfig.h>

#include <sstream>
#include <algorithm>

namespace CEGUI {

//----------------------------------------------------------------------------//
String REngRenderer::d_rendererID(
"CEGUI::OpenREngRenderer - CEGUI renderer for OpenREng.");

//----------------------------------------------------------------------------//
void REngRenderer::destroySystem() {
	System* sys;
	if(!(sys = System::getSingletonPtr()))
		throw InvalidRequestException("REngRenderer::destroySystem: CEGUI::System object is not created or was already destroyed.");
	REngRenderer* renderer = static_cast<REngRenderer*>(sys->getRenderer());
	REngImageCodec* ic = &static_cast<REngImageCodec&>(sys->getImageCodec());
	System::destroy();
	destroyImageCodec(*ic);
	destroy(*renderer);
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
REngRenderer& REngRenderer::create(const REng::Viewport& vp) {
    return *new REngRenderer(vp);
}
void REngRenderer::destroy(REngRenderer& renderer) {
    delete &renderer;
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
REngRenderer::REngRenderer(const REng::Viewport& vp) :
    d_displayDPI(96, 96)
{
	assert(REng::RenderSystem::getSingletonPtr());
	assert(REng::RenderSystem::getSingleton().isInited());
	d_displaySize.d_height = vp.getAbsRect().getHeight();
	d_displaySize.d_width  = vp.getAbsRect().getWidth();
	
	REng::RectI vpR(vp.getAbsRect());
	Rect r(vpR.getLeft(),vpR.getBottom(),vpR.getRight(),vpR.getTop());
	d_defaultTarget = new REngWindowTarget(r);
	d_defaultRoot = new RenderingRoot(*d_defaultTarget);

	rq = new RenderQueue_CEGUI();
}
REngRenderer::~REngRenderer() {
	destroyAllGeometryBuffers();
	destroyAllTextureTargets();
	destroyAllTextures();

	delete d_defaultRoot;
	delete d_defaultTarget;
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
REngImageCodec& REngRenderer::createImageCodec(){
	return *new REngImageCodec;
}
void REngRenderer::destroyImageCodec(REngImageCodec& ic){
	delete &ic;
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
GeometryBuffer& REngRenderer::createGeometryBuffer() {
	REngGeometryBuffer* b= new REngGeometryBuffer();
	d_geometryBuffers.push_back(b);
	return *b;
}
void REngRenderer::destroyGeometryBuffer(const GeometryBuffer& buffer) {
	GeometryBufferList::iterator i = 
		std::find(d_geometryBuffers.begin(),d_geometryBuffers.end(),&buffer);
	if (d_geometryBuffers.end() != i) {
		d_geometryBuffers.erase(i);
		delete &buffer;
	}
}
void REngRenderer::destroyAllGeometryBuffers() {
	while (!d_geometryBuffers.empty())
		destroyGeometryBuffer(**d_geometryBuffers.begin());
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
TextureTarget* REngRenderer::createTextureTarget() {
	TextureTarget* t = new REngTextureTarget();
	d_textureTargets.push_back(t);
	return t;
}
void REngRenderer::destroyTextureTarget(TextureTarget* target) {
	TextureTargetList::iterator i =	
		std::find(d_textureTargets.begin(),d_textureTargets.end(),target);
	if (d_textureTargets.end() != i) d_textureTargets.erase(i);
}
void REngRenderer::destroyAllTextureTargets() {
	while (!d_textureTargets.empty())
		destroyTextureTarget(*d_textureTargets.begin());
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
Texture& REngRenderer::createTexture() {
	REngTexture* tex = new REngTexture();
	d_textures.push_back(tex);
	return *tex;
}
Texture& REngRenderer::createTexture(const String& filename,
    const String& resourceGroup)
{
	REngTexture* tex = new REngTexture(filename, resourceGroup);
	d_textures.push_back(tex);
	return *tex;
}
Texture& REngRenderer::createTexture(const Size& size) {
	REngTexture* tex = new REngTexture(size);
	d_textures.push_back(tex);
	return *tex;
}
void REngRenderer::destroyTexture(Texture& texture) {
	TextureList::iterator i = 
		std::find(d_textures.begin(),d_textures.end(),&texture);
	if (d_textures.end() != i) {
		d_textures.erase(i);
		delete &static_cast<REngTexture&>(texture);
	}
}
void REngRenderer::destroyAllTextures() {
	while (!d_textures.empty())
		destroyTexture(**d_textures.begin());
}


//----------------------------------------------------------------------------//
void REngRenderer::beginRendering() {
	return;
}

//----------------------------------------------------------------------------//
void REngRenderer::endRendering() {
	return;
}

//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
//----------------------------------------------------------------------------//
const Size& REngRenderer::getDisplaySize() const {
	return d_displaySize;
}
const Vector2& REngRenderer::getDisplayDPI() const {
	return d_displayDPI;
}
uint REngRenderer::getMaxTextureSize() const {
	return REng::GPUConfig::getSingleton().getGLMaxTextureSize();
}
const String& REngRenderer::getIdentifierString() const {
	return d_rendererID;
}
RenderingRoot& REngRenderer::getDefaultRenderingRoot(){
	return *d_defaultRoot;
}

//----------------------------------------------------------------------------//
void REngRenderer::setDisplaySize(const Size& sz) {	
	if (sz != d_displaySize) {
		d_displaySize = sz;
		// update the default target's area
		Rect area(d_defaultTarget->getArea());
		area.setSize(sz);
		d_defaultTarget->setArea(area);
	}
}

} // End of  CEGUI namespace section

