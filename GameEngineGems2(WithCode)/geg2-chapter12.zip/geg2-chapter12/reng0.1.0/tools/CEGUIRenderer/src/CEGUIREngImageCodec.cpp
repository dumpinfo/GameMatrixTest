/***********************************************************************
    filename:   CEGUIMyImageCodec.cpp
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "CEGUIREngImageCodec.h"
#include "CEGUIExceptions.h"

#include "CEGUISize.h"

#include <il/il.h>

namespace CEGUI {

	REngImageCodec::REngImageCodec() :
	    ImageCodec("MyImageCodec - Integrated ImageCodec using the REng engine.")
	{ }

	Texture* REngImageCodec::load(const RawDataContainer& data, Texture* result) {
		// NOTE: currently uses DevIL directly
		// When image loader codecs are enabled in OpenREng, this function needs to be updated

		ilOriginFunc(IL_ORIGIN_UPPER_LEFT);

		ILuint imgName;
		ilGenImages(1, &imgName);
		ilBindImage(imgName);

		if(IL_FALSE != ilLoadL(IL_TYPE_UNKNOWN, 
			static_cast<const void*>(data.getDataPtr()), data.getSize()))
		{
			// get details about size of loaded image
			// set dimensions of texture
			size_t width = ilGetInteger(IL_IMAGE_WIDTH);
			size_t height = ilGetInteger(IL_IMAGE_HEIGHT);
			// allocate temp buffer to receive image data
			uchar* tmpBuff = new uchar[width * height * 4];
			// get image data in required format
			Texture::PixelFormat cefmt;
			ILenum ilfmt;
			ILint imageFormat = ilGetInteger(IL_IMAGE_FORMAT);
			switch(imageFormat){
				case IL_RGBA:
				case IL_BGRA:
					ilfmt = IL_RGBA;
					cefmt = Texture::PF_RGBA;
					break;
				default:
					ilfmt = IL_RGB;
					cefmt = Texture::PF_RGB;
					break;
			};
			ilCopyPixels(0, 0, 0, width, height, 1, ilfmt, IL_UNSIGNED_BYTE,
			static_cast<void*>(tmpBuff));

			// delete DevIL image
			ilDeleteImages(1, &imgName);
			ilOriginFunc(IL_ORIGIN_LOWER_LEFT);

			// create cegui texture
			try {
				result->loadFromMemory(tmpBuff, Size(width, height), cefmt);
			} catch(...) {
				delete [] tmpBuff;
				throw;
			}
			// free temp buffer
			delete [] tmpBuff;
			return result;
		} else {
			// failed to load image properly.
			ilDeleteImages(1, &imgName);
			ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
			return 0;
		}
	}

} // End of  CEGUI namespace section
