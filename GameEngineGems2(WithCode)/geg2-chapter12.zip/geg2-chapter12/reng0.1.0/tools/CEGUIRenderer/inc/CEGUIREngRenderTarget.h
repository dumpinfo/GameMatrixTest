/***********************************************************************
    filename:   CEGUIMyRenderTarget.h
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIMyRenderTarget_h_
#define _CEGUIMyRenderTarget_h_

#include "CEGUIREngPrerequisites.h"
#include "CEGUIREngRenderer.h"
#include "CEGUIREngGeometryBuffer.h"

#include <REng/Prerequisites.h>

#include "CEGUIRenderQueue.h"
#include "CEGUIRenderTarget.h"
#include "CEGUIRect.h"

namespace CEGUI {

	//! Intermediate RenderTarget implementation for REng engine.
	class RENG_GUIRENDERER_API REngRenderTarget : public virtual RenderTarget {
	public:
		REngRenderTarget();
		virtual ~REngRenderTarget();

		//********************************************************************//
		// implement part of CEGUI::RenderTarget interfaces
		//********************************************************************//
		void draw(const GeometryBuffer& buffer){ buffer.draw(); }
		void draw(const RenderQueue& queue){ queue.draw(); }

		void setArea(const Rect& area){
			d_area = area;
			mProjectionMatrixValid = false;
		}
		const Rect& getArea() const{ return d_area; }

		virtual void activate();
		virtual void deactivate();

		void unprojectPoint(const GeometryBuffer& buff,
		            const Vector2& p_in, Vector2& p_out) const;

	protected:
		//! helper that initializes the cached matrix
		void updateProjectionMatrix() const;

		//! holds defined area for the RenderTarget
		Rect d_area;
		//! tangent of the y FOV half-angle; used to calculate viewing distance.
		static const double d_yfov_tan;
		//! saved copy of projection matrix
		mutable REng::Matrix4 mProjectionMatrix;
		const double* helpMe() const;
		//! true if saved matrix is up to date
		mutable bool mProjectionMatrixValid;
		//! tracks viewing distance (this is set up at the same time as d_matrix)
		mutable double d_viewDistance;

		GLint mVPRollback[4];
	};

}

#endif  // end of guard _CEGUIMyRenderTarget_h_
