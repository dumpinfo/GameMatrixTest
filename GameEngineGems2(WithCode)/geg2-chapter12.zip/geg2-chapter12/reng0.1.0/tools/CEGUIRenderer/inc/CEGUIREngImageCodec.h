/***********************************************************************
    filename:   CEGUIMyImageCodec.h
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIMyImageCodec_h_
#define _CEGUIMyImageCodec_h_

#include "CEGUIREngPrerequisites.h"

#include "CEGUIImageCodec.h"

namespace CEGUI {

	//! ImageCodec object that loads data via image loading facilities in REng.
	class RENG_GUIRENDERER_API REngImageCodec : public ImageCodec {
	public:
	    REngImageCodec();
	    Texture* load(const RawDataContainer& data, Texture* result);
	};

} // End of  CEGUI namespace section

#endif  // end of guard _CEGUIMyImageCodec_h_
