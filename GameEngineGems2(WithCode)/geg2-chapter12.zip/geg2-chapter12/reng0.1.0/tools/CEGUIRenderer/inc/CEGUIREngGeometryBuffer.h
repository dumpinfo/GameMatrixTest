/***********************************************************************
    filename:   CEGUIREngGeometryBuffer.h
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIREngGeometryBuffer_h_
#define _CEGUIREngGeometryBuffer_h_

#include "CEGUIREngPrerequisites.h"
#include "CEGUIREngTexture.h"

#include "CEGUIGeometryBuffer.h"
#include "CEGUIRect.h"

#include <REng/Prerequisites.h>
#include <REng/GPU/GPUBuffer.h>
#include <REng/GPU/GPUTexture.h>
#include <REng/Mesh.h>

#include <utility>
#include <vector>

#if defined(_MSC_VER)
#   pragma warning(push)
#   pragma warning(disable : 4251)
#endif

namespace CEGUI {

	class REngTexture;

	//! Implementation of CEGUI::GeometryBuffer for the OpenREng engine
	//! @note Based on the implementation for OGRE engine.
	class RENG_GUIRENDERER_API REngGeometryBuffer : public GeometryBuffer {
	public:
	    REngGeometryBuffer();

	    // implement CEGUI::GeometryBuffer interface.
	    void draw() const;
	    void reset();

	    void setTranslation(const Vector3& t);
	    void setRotation(const Vector3& r);
	    void setPivot(const Vector3& p);
	    void setClippingRegion(const Rect& region);

		 void appendVertex(const Vertex& vertex){ appendGeometry(&vertex, 1); }
	    void appendGeometry(const Vertex* const vbuff, uint vertex_count);

	    void setActiveTexture(Texture* texture);
	    Texture* getActiveTexture() const;

	    uint getVertexCount() const;
	    uint getBatchCount() const;

	    void setRenderEffect(RenderEffect* effect);
	    RenderEffect* getRenderEffect();

	    const double* getMatrix() const;
		 const REng::Matrix4& getModelMatrix() const;

	protected:
		//! update cached matrix
		void updateModelMatrix() const;
		//! Synchronize data in the hardware buffer with what's been added
		void syncHardwareBuffer() const;

		//! vertex structure used internally and also by REng.
		struct REngVertex {
			float pos[4];
			float colour[4];
			float tex[2];
		};
		//! type of container used to queue the geometry
		typedef std::vector<REngVertex> VertexList;
		//! container where added geometry is stored.
		VertexList d_vertices;

		//! Texture that is set as active
		REngTexture* d_activeTexture;
		//! rectangular clip region
		Rect d_clipRect;

		//! translation vector
		Vector3 d_translation;
		//! rotation vector
		Vector3 d_rotation;
		//! pivot point for rotation
		Vector3 d_pivot;

		//! RenderEffect that will be used by the GeometryBuffer
		RenderEffect* d_effect;

		//! model matrix cache
		mutable REng::Matrix4 d_modelMatrix;
		//! true when d_modelMatrix is valid and up to date
		mutable bool d_modelMatrixValid;

		//! type to track info for per-texture sub batches of geometry
		typedef std::pair<REng::GPUTexture*, uint> BatchInfo;
		//! type of container that tracks BatchInfos.
		typedef std::vector<BatchInfo> BatchList;
		//! list of texture batches added to the geometry buffer
		BatchList d_batches;

		void initialiseMeshGeom() const;
		void resizeVertexBuffer(size_t bufVertexCount) const;

		//! Renderable complete geometry information for this buffer.
		mutable REng::MeshGeom d_meshGeom;
		//! For easy access to the GPU vertex buffer
		mutable REng::GPUVertexBuffer* d_vBufGPU;
		//! whether the h/w buffer is in sync with the added geometry
		mutable bool d_vBufSynched;
	};

} // End of  CEGUI namespace section

#endif  // end of guard _CEGUIREngGeometryBuffer_h_
