/***********************************************************************
    filename:   CEGUIOpenGLRenderer.h
    created:    Sun Jan 11 2009
    author:     Paul D Turner
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIOpenGLRenderer_h_
#define _CEGUIOpenGLRenderer_h_

#include "CEGUIREngPrerequisites.h"
#include "CEGUIREngImageCodec.h"

#include <REng/Prerequisites.h>
#include <REng/Viewport.h>

#include "CEGUIBase.h"
#include "CEGUIRenderer.h"
#include "CEGUISize.h"
#include "CEGUIVector.h"
#include <vector>

#if defined(_MSC_VER)
#   pragma warning(push)
#   pragma warning(disable : 4251)
#endif

namespace CEGUI {

	class REngTexture;
	class REngTextureTarget;
	class REngGeometryBuffer;
	class RenderQueue_CEGUI;

	typedef std::vector<TextureTarget*> TextureTargetList;
	typedef std::vector<REngGeometryBuffer*> GeometryBufferList;
	typedef std::vector<REngTexture*> TextureList;

	//! Renderer class to interface with OpenGL
	class RENG_GUIRENDERER_API REngRenderer : public Renderer {
	public:
		/*!
		\brief
			Convenience function to cleanup the CEGUI system and related objects
			that were created by calling the bootstrapSystem function.
			This function will destroy the following objects for you:
			- CEGUI::System
			- CEGUI::REngRenderer
			- CEGUI::REngImageCodec
		\note
			If you did not initialise CEGUI by calling the bootstrapSystem function,
			you should \e not call this, but rather delete any objects you created
			manually.
		*/
		static void destroySystem();

		/************************************************************************/
		/* RENG IMAGE CODEC                                                     */
		/************************************************************************/
		static REngImageCodec& createImageCodec();
		static void destroyImageCodec(REngImageCodec& ic);

		static REngRenderer& create(const REng::Viewport& vp);
		static void destroy(REngRenderer& renderer);

		// implement Renderer interface
		RenderingRoot& getDefaultRenderingRoot();
		GeometryBuffer& createGeometryBuffer();
		void destroyGeometryBuffer(const GeometryBuffer& buffer);
		void destroyAllGeometryBuffers();
		TextureTarget* createTextureTarget();
		void destroyTextureTarget(TextureTarget* target);
		void destroyAllTextureTargets();
		Texture& createTexture();
		Texture& createTexture(const String& filename, const String& resourceGroup);
		Texture& createTexture(const Size& size);
		void destroyTexture(Texture& texture);
		void destroyAllTextures();
		void beginRendering();
		void endRendering();
		void setDisplaySize(const Size& sz);
		const Size& getDisplaySize() const;
		const Vector2& getDisplayDPI() const;
		uint getMaxTextureSize() const;
		const String& getIdentifierString() const;

		/*!
		\brief
		Tells the renderer to initialise some extra states beyond what it
		directly needs itself for CEGUI.

		This option is useful in cases where you've made changes to the default
		OpenGL state and do not want to save/restore those between CEGUI
		rendering calls.  Note that this option will not deal with every
		possible state or extension - if you want a state added here, make a
		request and we'll consider it ;)
		*/
		void enableExtraStateSettings(bool setting);

	private:
		//! Constructor for OpenGL Renderer objects.
		REngRenderer(const REng::Viewport& vp);

		//! Destructor for OpenGL Renderer objects.
		virtual ~REngRenderer();

		//! init the extra GL states enabled via enableExtraStateSettings
		void setupExtraStates();

		//! cleanup the extra GL states enabled via enableExtraStateSettings
		void cleanupExtraStates();

		//! String holding the renderer identification text.
		static String d_rendererID;
		//! What the renderer considers to be the current display size.
		Size d_displaySize;
		//! What the renderer considers to be the current display DPI resolution.
		Vector2 d_displayDPI;
		//! The default rendering root object
		RenderingRoot* d_defaultRoot;
		//! The default RenderTarget (used by d_defaultRoot)
		RenderTarget* d_defaultTarget;
		//! Container used to track texture targets.
		TextureTargetList d_textureTargets;
		//! Container used to track geometry buffers.
		GeometryBufferList d_geometryBuffers;
		//! Container used to track textures.
		TextureList d_textures;

		// temp
		RenderQueue_CEGUI* rq;
	};

} // End of  CEGUI namespace section

#if defined(_MSC_VER)
#   pragma warning(pop)
#endif

#endif // end of guard _CEGUIOpenGLRenderer_h_
