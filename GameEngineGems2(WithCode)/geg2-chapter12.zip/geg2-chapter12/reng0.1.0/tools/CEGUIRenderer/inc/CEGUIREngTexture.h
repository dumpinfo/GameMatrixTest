/***********************************************************************
    filename:   CEGUIMyTexture.h
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIMyTexture_h_
#define _CEGUIMyTexture_h_

#include "CEGUIREngPrerequisites.h"

#include "CEGUITexture.h"
#include "CEGUISize.h"
#include "CEGUIVector.h"

#include <REng/GPU/GPUTexture.h>

#include <string>

namespace CEGUI {

	//! Implementation of the CEGUI::Texture class for the OpenREng engine.
	class RENG_GUIRENDERER_API REngTexture : public Texture {
	public:
		void setTexturePtr(REng::GPUTexture* texture);
		REng::GPUTexture* getTexturePtr() const;

		//! return a string containing a unique name.
		static std::string getUniqueName();

		//********************************************************************//
		// implement CEGUI::Texture interfaces
		//********************************************************************//

		//! Returns the current pixel size of the texture.
		//! @return Reference to a Size object that describes the size of the 
		//!         texture in pixels.
		const Size& getSize() const;

		//! Returns the original pixel size of the data loaded into the texture.
		//! @return Reference to a Size object that describes the original size, 
		//!         in pixels, of the data loaded into the texture.
		const Size& getOriginalDataSize() const;

		//! Returns pixel to texel scale values that should be used for converting
		//! pixel values to texture co-ords.
		//! @return Reference to a Vector2 object that describes the scaling values
		//!         required to accurately map pixel positions to texture co-ordinates.
		const Vector2& getTexelScaling() const;

		/*!
		\brief
			Loads the specified image file into the texture.  The texture is resized
			as required to hold the image.
		\param filename
			The filename of the image file that is to be loaded into the texture
		\param resourceGroup
			Resource group identifier to be passed to the resource provider when
			loading the image file.
		*/
		void loadFromFile(const String& filename, const String& resourceGroup);

		/*!
		\brief
			Loads (copies) an image in memory into the texture.  The texture is
			resized as required to hold the image.
		\param buffer
			Pointer to the buffer containing the image data.
		\param buffer_size
			Size of the buffer (in pixels as specified by \a pixelFormat)
		\param pixel_format
			PixelFormat value describing the format contained in \a buffPtr.
		*/
		void loadFromMemory(const void* buffer, const Size& buffer_size,
		                  PixelFormat pixel_format);
		/*!
		\brief
			Save / dump the content of the texture to a memory buffer.  The dumped
			pixel format is always RGBA (4 bytes per pixel).
		\param buffer
			Pointer to the buffer that is to receive the image data.  You must make
			sure that this buffer is large enough to hold the dumped texture data,
			the required pixel dimensions can be established by calling getSize.
		*/
		void saveToMemory(void* buffer);

		REngTexture();
		REngTexture(const String& filename, const String& resourceGroup);
		REngTexture(const Size& sz);
		REngTexture(REng::GPUTexture* tex);
		virtual ~REngTexture();

	protected:
		//! generate the REng material texture and set some initial options.
		void generateREngTexture();

		//! updates cached scale values used to map pixels to texture coordinates.
		void updateCachedScaleValues();

		//! to conform to previous opengl texture
		void setTextureSize(const Size& sz);

		static uint32 d_textureNumber;     ///< Counter used to provide unique texture names.
		REng::GPUTexture* d_texture;        ///< The underlying REng texture.
		Size d_size;                       ///< Size of the texture.
		Size d_originalSize;               ///< Original pixel of size data loaded into texture
		Vector2 d_texelScaling;            ///< Cached pixel to texel mapping scale values.
	};

} // End of  CEGUI namespace section

#endif  // end of guard _CEGUIMyTexture_h_
