/***********************************************************************
    filename:   CEGUIREngRenderQueue.h
    created:    Tue Feb 19 2010
    author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIREngRenderQueue_h_
#define _CEGUIREngRenderQueue_h_

#include "CEGUIREngPrerequisites.h"

#include "CEGUITexture.h"

#include <REng/Material/RenderPass.h>
#include <REng/RenderQueue.h>

#include <string>

namespace CEGUI {

	//! A render queue which renders GUI elements in preProcess step
	class RENG_GUIRENDERER_API RenderQueue_CEGUI : public REng::RenderQueue_Vector {
	public:
		static const uchar RenderQueue_GUI_ID;
		//! Registers itself to RenderQueue_GUI_ID
		RenderQueue_CEGUI();
		//! Renders the GUI
		void preRenderQueueProcess();
		//! Clears render states
		void postRenderQueueProcess();
	private:
		//! GUI is rendered as a single pass state.
		//! @note Only texture bindings and model matrix needs to be updated during traversal
		REng::RenderPass* mGuiRenderStates;
	};

} // End of  CEGUI namespace section

#endif  // end of guard _CEGUIREngRenderQueue_h_
