/***********************************************************************
    filename:   CEGUIOpenGLTextureTarget.h
	 created:    Tue Feb 19 2010
	 author:     Adil Yalcin
*************************************************************************/
/****************************************************************************
Copyright 2010 Adil Yalcin

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _CEGUIREngTextureTarget_h_
#define _CEGUIREngTextureTarget_h_

#include "CEGUIREngPrerequisites.h"
#include "CEGUIREngRenderTarget.h"
#include "CEGUITextureTarget.h"

#include <REng/Prerequisites.h>
#include <REng/GPU/GPUFrameBuffer.h>
#include <REng/GPU/GPUTexture.h>

#if defined(_MSC_VER)
#   pragma warning(push)
#   pragma warning(disable : 4250)
#endif

namespace CEGUI {

	class REngTexture;

	//! Renderable texture target
	class RENG_GUIRENDERER_API REngTextureTarget : public REngRenderTarget, public TextureTarget {
	public:
		REngTextureTarget();
		~REngTextureTarget();

		//********************************************************************//
		// implement CEGUI::RenderTarget interfaces
		//********************************************************************//
		bool isImageryCache() const { return true; }
		
		void activate();
		void deactivate();

		//********************************************************************//
		// implement CEGUI::TextureTarget interfaces
		//********************************************************************//
		bool isRenderingInverted() const{ return true; }
		Texture& getTexture() const;
		void clear();
		void declareRenderSize(const Size& sz);

	protected:
		//! default size of created texture objects
		static const float DEFAULT_SIZE;

		//! Texture object.
		REng::GPUTexture d_texture;
		//! Frame buffer object.
		REng::GPUFrameBuffer d_frameBuffer;
		//! we use this to wrap d_texture so it can be used by the core CEGUI lib.
		REngTexture* d_CEGUITexture;

		//! allocate and set up the texture used with the FBO.
		void initialiseRenderTexture();
		//! resize the texture
		void resizeRenderTexture();
	};

	#if defined(_MSC_VER)
	#   pragma warning(pop)
	#endif

}

#endif  // end of guard _CEGUIREngTextureTarget_h_
