#include "REng/REng.h"

#pragma comment(lib, "REng.lib")

#include <stdio.h>
#include <time.h>


void matrix_decompose_tester(){
	// test matrix decomposition stuff
	// these are matrices that can be updated in each operation
	REng::Matrix4 matMult;
	cml::quaternionf_p rotation;
	float scalex, scaley, scalez;
	REng::Vector3 translation;
	REng::Vector3 axis;

	REng::Matrix4 mat1;
	mat1.identity();

	// update matrix by applying rotation, scale and translation
	cml::matrix_translation(matMult,20.1f,8.2f,25.2f);
	mat1 *= matMult;
	//
	axis.set(1.0f,1.0f,1.0f);
	axis.normalize();
	cml::quaternion_rotation_axis_angle(rotation,axis,0.3f);
	cml::matrix_rotation_quaternion(matMult,rotation);
	mat1 *= matMult;
	//
	cml::matrix_translation(matMult,20.1f,8.2f,25.2f);
	mat1 *= matMult;
	cml::matrix_translation(matMult,-10.1f,-6.2f,-22.2f);
	mat1 *= matMult;
	//	cml::matrix_scale(matMult,10.1f,8.2f,25.2f);
	cml::matrix_uniform_scale(matMult,0.3f);
	mat1 *= matMult;
	//
	axis.set(1.0f,1.0f,1.0f);
	axis.normalize();
	cml::quaternion_rotation_axis_angle(rotation,axis,0.3f);
	cml::matrix_rotation_quaternion(matMult,rotation);
	mat1 *= matMult;
	//

	// decompose the matrix
	matrix_decompose_SRT(mat1, scalex, scaley, scalez, rotation, translation );

	// reconstruct a matrix from decomposed parts
	REng::Matrix4 matGen;
	matGen.identity();
	// translation
	cml::matrix_translation(matMult,translation);
	matGen *= matMult;
	// rotation
	cml::matrix_rotation_quaternion(matMult,rotation);
	matGen *= matMult;
	// scale
	cml::matrix_scale(matMult,scalex,scaley,scalez);
	matGen *= matMult;

	// check if the original and generated matrix are equal using an epsilon
	for(int i=0 ; i<4 ; i++){
		for(int j=0 ; j<4 ; j++){
			float dif = mat1(i,j) - matGen(i,j);
			if(dif<0) dif *= -1;
			if(dif > 0.001){ 
				dif = 0;
			}
		}
	}

}

int main(){
	matrix_decompose_tester();
}
