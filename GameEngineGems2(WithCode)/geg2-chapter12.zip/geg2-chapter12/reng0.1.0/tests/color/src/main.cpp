#include "REng/Color.h"

#undef True

// unit testing support
#include <UnitTest++/UnitTest++.h>
#include <UnitTest++/XmlTestReporter.h>
#include <fstream>


using namespace REng;
using namespace std;
using namespace UnitTest;

// NOTE: You should run test with different ChType values for Color_Int and Color_Real.

TEST(COLOR_BASICS)
{
	CHECK_EQUAL(Color_Real::MIN_VAL,0.0);
	CHECK_EQUAL(Color_Real::MAX_VAL,1.0);
	CHECK_EQUAL(Color_Int::MIN_VAL, 0);
	CHECK_EQUAL(Color_Int::MAX_VAL, Color_Int::ChType(Color_Int::ChType(0)-1));
}

TEST(COLOR_CONVERT_REAL_INT)
{
	Color_Int::ChType mx(Color_Int::MAX_VAL);

	Color_Real c1(1.0,1.0,1.0,1.0);
	Color_Real c2(Color_Real::Red);
	Color_Real c3(0.5,0.25,0.5,1.0);

	Color_Int cp1(c1.get_Int());
	CHECK((cp1.r==mx) && (cp1.g==mx) && (cp1.b==mx) && (cp1.a==mx) );
	Color_Int cp2(c2.get_Int());
	CHECK((cp2.r==mx) && (cp2.g==0) && (cp2.b==0) && (cp2.a==mx) );
	Color_Int cp3(c3.get_Int());
	CHECK((cp3.r==mx/2) && (cp3.g==mx/4) && (cp3.b==mx/2) && (cp3.a==mx) );

	// and back...

	// conversions to/from lose some data, increase the tolerance
	// Note: if int resolution is high (ex: uint is used) this conversion is much more "tolerant"
	CHECK_ARRAY_CLOSE(cp1.get_Real().ptr(), c1.ptr(), 4, 0.05);
	CHECK_ARRAY_CLOSE(cp2.get_Real().ptr(), c2.ptr(), 4, 0.05);
	CHECK_ARRAY_CLOSE(cp3.get_Real().ptr(), c3.ptr(), 4, 0.05);
}


TEST(COLOR_CONVERT_PACKED_INT)
{
	Color_Packed cp(0x12345678); // RGBA
	uchar r1[4]; cp.get(r1);

	Color_Int ci(cp.get_Int());
	CHECK_ARRAY_EQUAL(r1,ci.ptr(),4);

	// and back
	Color_Packed cp2;
	cp2.setFrom_Int(ci);
	CHECK_EQUAL(cp,cp2);
}

int main()
{
	// log to an xml file (has more detailed structure)
	std::ofstream f("logs/colortest.xml");
	XmlTestReporter reporter(f);
	TestRunner runner(reporter);
	return runner.RunTestsIf(Test::GetTestList(), NULL, True(), 0);
}

