#include <UnitTest++/UnitTest++.h>

#include "REng/Color.h"

using namespace UnitTest;
using namespace REng;

SUITE(COLOR_INT)
{

TEST(Constructors)
{
	Color_Int c1;
	Color_Int c2(120,100,90,250);
	Color_Int c3(c2);
	Color_Int::ChType val2[] = {22, 81, 34, 55};
	Color_Int c4(val2);

	CHECK( (c1.r==0) && (c1.g==0) && (c1.b==0) && (c1.a==Color_Int::MAX_VAL) );
	CHECK( (c2.r==120) && (c2.g==100) && (c2.b==90) && (c2.a==250) );
	CHECK( (c3.r==120) && (c3.g==100) && (c3.b==90) && (c3.a==250) );
	CHECK_ARRAY_EQUAL(c4.ptr(),val2,4);

	c3.set(20,40,60,80);
	CHECK( (c3.r==20) && (c3.g==40) && (c3.b==60) && (c3.a==80) );
	c3.set(30,50,70);
	CHECK( (c3.r==30) && (c3.g==50) && (c3.b==70) && (c3.a==Color_Int::MAX_VAL) );

	c2.set(val2);
	CHECK_ARRAY_EQUAL(c2.ptr(),val2,4);
}

TEST(Comparison)
{
	Color_Int c1;
	c1.set(100,230,232,186);
	Color_Int c2(c1);
	CHECK_ARRAY_EQUAL(c1.ptr(),c2.ptr(),4);
	CHECK(c1==c2);
	c2.a = 232;
	CHECK(c1!=c2);
}

TEST(Inversion)
{
	Color_Int::ChType mx(Color_Int::MAX_VAL);

	Color_Int c1(60,80,230,140);

	c1.invertRGB();
	Color_Int::ChType ri1[] = {mx-60, mx-80, mx-230, 140};
	CHECK_ARRAY_EQUAL(c1.ptr(), ri1, 4);

	c1.invertRGBA();
	Color_Int::ChType ri2[] = {60, 80, 230, mx-140};
	CHECK_ARRAY_EQUAL(c1.ptr(), ri2, 4);
}

TEST(Arithmetic)
{
	Color_Int ci1(10,20,30,40);
	Color_Int ci2(20,30,48,87);
	Color_Int ci3(23,47,27,38);

	Color_Int ci_1(ci1+ci2+ci3);
	Color_Int::ChType ri1[] = {53,97,105,165};
	CHECK_ARRAY_EQUAL(ci_1.ptr(),ri1,4);
	
	Color_Int ci_2(ci3-ci2);
	Color_Int::ChType ri3[] = {3,17,Color_Int::ChType(27-48),Color_Int::ChType(38-87)};
	CHECK_ARRAY_EQUAL(ci_2.ptr(),ri3,4);
}

}