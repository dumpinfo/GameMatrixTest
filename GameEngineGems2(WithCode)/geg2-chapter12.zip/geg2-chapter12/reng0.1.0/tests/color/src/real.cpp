#include <UnitTest++/UnitTest++.h>

#include "REng/Color.h"

using namespace UnitTest;
using namespace REng;

// tolerance value for floating point operations
Color_Real::ChType _t(0.0000005);

SUITE(COLOR_REAL)
{

TEST(Constructors)
{
	Color_Real c1;
	Color_Real c2(0.4,0.3,0.2,1.0);
	Color_Real c3(c2);
	Color_Real::ChType val[] = {0.2, 0.8, 0.3, 1.5};
	Color_Real c4(val);
	Color_Real c5(0.4,0.3,0.2);

	CHECK_CLOSE(c1.r,0.0,_t); CHECK_CLOSE(c1.g,0.0,_t); CHECK_CLOSE(c1.b,0.0,_t); CHECK_CLOSE(c1.a,1.0,_t);
	CHECK_CLOSE(c2.r,0.4,_t); CHECK_CLOSE(c2.g,0.3,_t); CHECK_CLOSE(c2.b,0.2,_t); CHECK_CLOSE(c2.a,1.0,_t);
	CHECK_CLOSE(c3.r,0.4,_t); CHECK_CLOSE(c3.g,0.3,_t); CHECK_CLOSE(c3.b,0.2,_t); CHECK_CLOSE(c3.a,1.0,_t);
	CHECK_ARRAY_CLOSE(c4.ptr(),val,4,_t);
	CHECK_CLOSE(c5.r,0.4,_t); CHECK_CLOSE(c5.g,0.3,_t); CHECK_CLOSE(c5.b,0.2,_t); CHECK_CLOSE(c5.a,1.0,_t);

	c3.set(1.3,1.4,1.7,2.6);
	CHECK_CLOSE(c3.r,1.3,_t); CHECK_CLOSE(c3.g,1.4,_t); CHECK_CLOSE(c3.b,1.7,_t); CHECK_CLOSE(c3.a,2.6,_t);

	c3.set(1.0,1.2,0.9);
	CHECK_CLOSE(c3.r,1.0,_t); CHECK_CLOSE(c3.g,1.2,_t); CHECK_CLOSE(c3.b,0.9,_t); CHECK_CLOSE(c3.a,1.0,_t);

	c2.set(val);
	CHECK_ARRAY_CLOSE(c2.ptr(), val, 4, _t);
}

TEST(Comparison)
{
	Color_Real cr1(0.0,0.4,0.223,0.5);
	Color_Real cr2(cr1);
	CHECK_ARRAY_EQUAL(cr1.ptr(),cr2.ptr(),4);
	CHECK_EQUAL(cr1, cr2);
	cr2.a = 0.3;
	CHECK(cr1!=cr2);
}

TEST(Inversion)
{
	Color_Real cr1(0.3,0.4,0.5,0.6);

	cr1.invertRGB();
	Color_Real::ChType rr1[] = {0.7, 0.6, 0.5, 0.6};
	CHECK_ARRAY_CLOSE(cr1.ptr(), rr1, 4, _t);

	cr1.invertRGBA();
	Color_Real::ChType rr2[] = {0.3, 0.4, 0.5, 0.4};
	CHECK_ARRAY_CLOSE(cr1.ptr(), rr2, 4, _t);
}

TEST(Arithmetic)
{
	Color_Real cr1(0.2,0.4,0.6,0.8);
	Color_Real cr2(0.5,0.5,0.5,0.5);
	Color_Real cr3(1.0,1.0,1.5,1.0);

	Color_Real c_1(cr1+cr2+cr3);
	Color_Real::ChType r1[] = {1.7,1.9,2.6,2.3};
	CHECK_ARRAY_CLOSE(c_1.ptr(),r1,4,_t);

	c_1.compress();
	Color_Real::ChType r2[] = {1.0,1.0,1.0,1.0};
	CHECK_ARRAY_CLOSE(c_1.ptr(),r2,4,_t);

	Color_Real c_2(cr3-cr2-cr1);
	Color_Real::ChType r3[] = {0.3,0.1,0.4,-0.3};
	CHECK_ARRAY_CLOSE(c_2.ptr(),r3,4,_t);

	c_2.compress();
	Color_Real::ChType r4[] = {0.3,0.1,0.4,0.0};
	CHECK_ARRAY_CLOSE(c_2.ptr(),r4,4,_t);

	Color_Real c_3(cr1*cr2);
	Color_Real::ChType r5[] = {0.1,0.2,0.3,0.4};
	CHECK_ARRAY_CLOSE(c_3.ptr(),r5,4,_t);

	c_3 = cr1*cr2*cr3;
	Color_Real::ChType r6[] = {0.1,0.2,0.45,0.4};
	CHECK_ARRAY_CLOSE(c_3.ptr(),r6,4,_t);

	c_3 = cr1/cr2;
	Color_Real::ChType r7[] = {0.4,0.8,1.2,1.6};
	CHECK_ARRAY_CLOSE(c_3.ptr(),r7,4,_t);
}

TEST(HSB_Convertion)
{
	// R:182 G:116 B:159  ==> H:320 S:36 V:71
	Color_Real cr1(182/255.0f,116/255.0f,159/255.0f);
	
	CHECK_CLOSE(320.0f/360.0f, cr1.getHue(), 0.01);
	CHECK_CLOSE(0.36f, cr1.getSaturation(), 0.01);
	CHECK_CLOSE(0.71f, cr1.getBrightness(), 0.01);

	Color_Real::ChType hsb[3];
	cr1.getHSB(hsb[0], hsb[1], hsb[2]);
	CHECK_CLOSE(320.0f/360.0f, hsb[0], 0.01);
	CHECK_CLOSE(0.36f,         hsb[1], 0.01);
	CHECK_CLOSE(0.71f,         hsb[2], 0.01);

	// H:125 S:74 B:60 ===> R:39 G:153 B:49
	cr1.setFrom_HSB(125.0f/360.0f,0.74f,0.6f);

	CHECK_CLOSE(39 /255.0f,cr1.r,0.01);
	CHECK_CLOSE(153/255.0f,cr1.g,0.01);
	CHECK_CLOSE(49 /255.0f,cr1.b,0.01);
}

}
