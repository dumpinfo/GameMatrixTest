#include <UnitTest++/UnitTest++.h>

#include "REng/Color.h"

using namespace UnitTest;
using namespace REng;

SUITE(COLOR_PACKED)
{

TEST(Constructors)
{
	Color_Packed cb1;
	Color_Packed cb2(0xFF0A0B0C); // RGBA
	Color_Packed cb3(0xFF0A0B0C, Color_Pack_ARGB);

	CHECK_EQUAL(cb1.getType(), Color_Pack_RGBA);
	CHECK_EQUAL(cb2.getType(), Color_Pack_RGBA);
	CHECK_EQUAL(cb3.getType(), Color_Pack_ARGB);

	CHECK_EQUAL(cb1.get(), 0x000000FF);
	CHECK_EQUAL(cb2.get(), 0xFF0A0B0C);
	CHECK_EQUAL(cb3.get(), 0xFF0A0B0C);
}

TEST(Comparison)
{
	// all the colors below are equivalent
	Color_Packed c1(0x12345678, Color_Pack_RGBA);
	Color_Packed c2(0x12345678, Color_Pack_RGBA);
	Color_Packed c3(0x78123456, Color_Pack_ARGB);
	Color_Packed c4(0x56341278, Color_Pack_BGRA);
	Color_Packed c5(0x78563412, Color_Pack_ABGR);

	CHECK_EQUAL(c1, c2);
	CHECK_EQUAL(c1, c3);
	CHECK_EQUAL(c1, c4);
	CHECK_EQUAL(c1, c5);
	CHECK_EQUAL(c3, c5);

	// but this is not equivalent with the ones above
	Color_Packed c6(0x86228298, Color_Pack_RGBA);
	CHECK(c1 != c6);
	CHECK(c5 != c6);
}
TEST(Inversion)
{
	Color_Packed cp(0xFF0A0B0C, Color_Pack_ARGB);
	cp.invertRGBA();
	CHECK_EQUAL(cp.get(), 0x00F5F4F3);
	cp.invertRGBA();
	CHECK_EQUAL(cp.get(), 0xFF0A0B0C);

	Color_Packed c_rgba(0x12345678, Color_Pack_RGBA);
	Color_Packed c_bgra(0x12345678, Color_Pack_BGRA);
	Color_Packed c_argb(0x12345678, Color_Pack_ARGB);
	Color_Packed c_abgr(0x12345678, Color_Pack_ABGR);

	c_rgba.invertRGB();
	c_bgra.invertRGB();
	c_argb.invertRGB();
	c_abgr.invertRGB();
	CHECK_EQUAL(c_rgba.get(), 0xEDCBA978);
	CHECK_EQUAL(c_bgra.get(), 0xEDCBA978);
	CHECK_EQUAL(c_argb.get(), 0x12CBA987);
	CHECK_EQUAL(c_abgr.get(), 0x12CBA987);
	c_rgba.invertRGB(); // to initial state 
	c_bgra.invertRGB(); // ...
	c_argb.invertRGB(); // ...
	c_abgr.invertRGB(); // ...
	CHECK_EQUAL(c_rgba.get(), 0x12345678);
	CHECK_EQUAL(c_bgra.get(), 0x12345678);
	CHECK_EQUAL(c_argb.get(), 0x12345678);
	CHECK_EQUAL(c_abgr.get(), 0x12345678);
}

TEST(Getters)
{
	Color_Packed c_rgba(0x12345678, Color_Pack_RGBA);
	Color_Packed c_bgra(0x12345678, Color_Pack_BGRA);
	Color_Packed c_argb(0x12345678, Color_Pack_ARGB);
	Color_Packed c_abgr(0x12345678, Color_Pack_ABGR);

	                // RRRR  GGGG  BBBB  AAAA
	uchar ar_rgba[] = {0x12, 0x34, 0x56, 0x78};
	uchar ar_bgra[] = {0x56, 0x34, 0x12, 0x78};
	uchar ar_argb[] = {0x34, 0x56, 0x78, 0x12};
	uchar ar_abgr[] = {0x78, 0x56, 0x34, 0x12};
	uchar arc_rgba[4], arc_bgra[4], arc_argb[4], arc_abgr[4];
	c_rgba.get(arc_rgba);
	c_argb.get(arc_argb);
	c_bgra.get(arc_bgra);
	c_abgr.get(arc_abgr);

	CHECK_ARRAY_EQUAL(arc_rgba,ar_rgba,4);
	CHECK_ARRAY_EQUAL(arc_argb,ar_argb,4);
	CHECK_ARRAY_EQUAL(arc_bgra,ar_bgra,4);
	CHECK_ARRAY_EQUAL(arc_abgr,ar_abgr,4);
}

TEST(Type_Convert)
{
	uchar c1[4], c2[4];

	Color_Packed c_rgba(0x12345678, Color_Pack_RGBA);
	Color_Packed c_rgba1(c_rgba); c_rgba1.setType(Color_Pack_RGBA);
	Color_Packed c_rgba2(c_rgba); c_rgba2.setType(Color_Pack_ARGB);
	Color_Packed c_rgba3(c_rgba); c_rgba3.setType(Color_Pack_BGRA);
	Color_Packed c_rgba4(c_rgba); c_rgba4.setType(Color_Pack_ABGR);
	c_rgba.get(c1); c_rgba1.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_rgba.get(c1); c_rgba2.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_rgba.get(c1); c_rgba3.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_rgba.get(c1); c_rgba4.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);

	Color_Packed c_bgra(0x12345678, Color_Pack_BGRA);
	Color_Packed c_bgra1(c_bgra); c_bgra1.setType(Color_Pack_RGBA);
	Color_Packed c_bgra2(c_bgra); c_bgra2.setType(Color_Pack_ARGB);
	Color_Packed c_bgra3(c_bgra); c_bgra3.setType(Color_Pack_BGRA);
	Color_Packed c_bgra4(c_bgra); c_bgra4.setType(Color_Pack_ABGR);
	c_bgra.get(c1); c_bgra1.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_bgra.get(c1); c_bgra2.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_bgra.get(c1); c_bgra3.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_bgra.get(c1); c_bgra4.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);

	Color_Packed c_argb(0x12345678, Color_Pack_ARGB);
	Color_Packed c_argb1(c_argb); c_argb1.setType(Color_Pack_RGBA);
	Color_Packed c_argb2(c_argb); c_argb2.setType(Color_Pack_ARGB);
	Color_Packed c_argb3(c_argb); c_argb3.setType(Color_Pack_BGRA);
	Color_Packed c_argb4(c_argb); c_argb4.setType(Color_Pack_ABGR);
	c_argb.get(c1); c_argb1.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_argb.get(c1); c_argb2.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_argb.get(c1); c_argb3.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_argb.get(c1); c_argb4.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);

	Color_Packed c_abgr(0x12345678, Color_Pack_ABGR);
	Color_Packed c_abgr1(c_abgr); c_abgr1.setType(Color_Pack_RGBA);
	Color_Packed c_abgr2(c_abgr); c_abgr2.setType(Color_Pack_ARGB);
	Color_Packed c_abgr3(c_abgr); c_abgr3.setType(Color_Pack_BGRA);
	Color_Packed c_abgr4(c_abgr); c_abgr4.setType(Color_Pack_ABGR);
	c_abgr.get(c1); c_abgr1.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_abgr.get(c1); c_abgr2.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_abgr.get(c1); c_abgr3.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
	c_abgr.get(c1); c_abgr4.get(c2); CHECK_ARRAY_EQUAL(c1,c2,4);
}

}
