#include <UnitTest++/UnitTest++.h>

#include "REng/Geom.h"

using namespace UnitTest;
using namespace std;
using namespace REng;

SUITE(Geom_Plane)
{
	Vector3 tolerance(0.0000005,0.0000005,0.0000005);


TEST(Constructors)
{	
	GeomPlaneBoundedVolume pbv;

	GeomPlaneList planeList;
	planeList.push_back(GeomPlane(Vector3(0.5,0,0),Vector3(-1,0,0)));
	planeList.push_back(GeomPlane(Vector3(-0.5,0,0),Vector3(1,0,0)));
	planeList.push_back(GeomPlane(Vector3(0,0.5,0),Vector3(0,-1,0)));
	planeList.push_back(GeomPlane(Vector3(0,-0.5,0),Vector3(0,1,0)));
	planeList.push_back(GeomPlane(Vector3(0,0,-0.5),Vector3(0,0,1)));
	planeList.push_back(GeomPlane(Vector3(0,0,0.5),Vector3(0,0,-1)));
	GeomPlaneBoundedVolume pbv2(planeList);

	//Test Equality
	GeomPlaneList pbvPlaneList=pbv.getPlaneList();
	GeomPlaneList pbv2PlaneList=pbv2.getPlaneList();
	for(unsigned int i=0;i<pbv2PlaneList.size() || i<pbvPlaneList.size();i++) {
		if(i>=pbv2PlaneList.size() || i>=pbvPlaneList.size()) {
			CHECK(false);
			break;
		}
		CHECK_EQUAL(pbv2PlaneList[i].getPosition(),pbvPlaneList[i].getPosition());
		CHECK_EQUAL(pbv2PlaneList[i].getNormal(),pbvPlaneList[i].getNormal());
	}
}

TEST(Translation)
{	
	GeomPlaneBoundedVolume pbv;

	GeomPlaneList planeList;
	planeList.push_back(GeomPlane(Vector3(4.5,3,0),Vector3(-1,0,0)));
	planeList.push_back(GeomPlane(Vector3(3.5,3,0),Vector3(1,0,0)));
	planeList.push_back(GeomPlane(Vector3(4,3.5,0),Vector3(0,-1,0)));
	planeList.push_back(GeomPlane(Vector3(4,2.5,0),Vector3(0,1,0)));
	planeList.push_back(GeomPlane(Vector3(4,3,-0.5),Vector3(0,0,1)));
	planeList.push_back(GeomPlane(Vector3(4,3,0.5),Vector3(0,0,-1)));
	GeomPlaneBoundedVolume pbv2(planeList);

	//Apply Translation
	pbv.translate(Vector3(4,3,0),GeomTS_Local);

	//Test Equality
	GeomPlaneList pbvPlaneList=pbv.getPlaneList();
	GeomPlaneList pbv2PlaneList=pbv2.getPlaneList();
	for(unsigned int i=0;i<pbv2PlaneList.size() || i<pbvPlaneList.size();i++) {
		if(i>=pbv2PlaneList.size() || i>=pbvPlaneList.size()) {
			CHECK(false);
			break;
		}
		CHECK_EQUAL(pbv2PlaneList[i].getPosition(),pbvPlaneList[i].getPosition());
		CHECK_EQUAL(pbv2PlaneList[i].getNormal(),pbvPlaneList[i].getNormal());
	}
}

TEST(Rotation)
{
	//TODO Test Rotation
}

}