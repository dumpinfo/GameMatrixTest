#include <UnitTest++/UnitTest++.h>

#include "REng/Geom.h"

using namespace UnitTest;
using namespace std;
using namespace REng;

SUITE(Geom_PBV)
{
	Vector3 tolerance(0.0000005,0.0000005,0.0000005);

TEST(Constructors)
{	
	GeomPlane plane;
	GeomPlane plane2(Vector3(0,0,0),Vector3(0,1,0));
	GeomPlane plane3(Vector3(0,0,0),Vector3(3,0,2),Vector3(12,0,43));

	CHECK_EQUAL(plane.getPosition(),plane2.getPosition());
	CHECK_EQUAL(plane.getNormal(),plane2.getNormal());

	CHECK_EQUAL(plane2.getPosition(),plane3.getPosition());
	CHECK_CLOSE(plane2.getNormal(),plane3.getNormal(),tolerance);
}

TEST(Translation)
{	
	GeomPlane plane;

	//Goal Plane
	GeomPlane control(Vector3(13.5,5.5,7.5),Vector3(0,1,0));

	//Apply and Test
	plane.translate(Vector3(13.5,5.5,7.5),GeomTS_World);
	CHECK_EQUAL(plane.getPosition(),control.getPosition());
}

TEST(Local_Rotation)
{
	GeomPlane plane(Vector3(3,5,1),Vector3(0,1,0));

	//Goal Line
	GeomPlane control(Vector3(3,5,1),Vector3(-0.707106781,0.707106781,0));

	//Rotation to be applied
	Quaternion q;
	cml::quaternion_rotation_euler(q,(float)0.0,(float)0.0,(float)45.0*cml::constants<float>::rad_per_deg(),cml::euler_order_xyz);

	//Apply and Test
	plane.rotate(q,GeomTS_Local);
	CHECK_CLOSE(plane.getPosition(),control.getPosition(),tolerance);
	CHECK_CLOSE(plane.getNormal(),control.getNormal(),tolerance);
}

TEST(Global_Rotation)
{
	GeomPlane plane(Vector3(1,1,0),Vector3(1,1,0));

	//Goal Line
	GeomPlane control(Vector3(1.41421356,0,0),Vector3(1,0,0));

	//Rotation to be applied
	Quaternion q;
	cml::quaternion_rotation_euler(q,(float)0.0,(float)0.0,(float)-45.0*cml::constants<float>::rad_per_deg(),cml::euler_order_xyz);

	//Apply and Test
	plane.rotate(q,GeomTS_World);
	CHECK_CLOSE(plane.getPosition(),control.getPosition(),tolerance);
	CHECK_CLOSE(plane.getNormal(),control.getNormal(),tolerance);
}

}