#include <UnitTest++/UnitTest++.h>

#include "REng/Geom.h"

using namespace UnitTest;
using namespace std;
using namespace REng;

SUITE(Geom_Point)
{
	Vector3 tolerance(0.0000005,0.0000005,0.0000005);

TEST(Constructors)
{	
	GeomPoint point;
	GeomPoint point2(Vector3(0,0,0));

	CHECK_EQUAL(point.getPosition(),point2.getPosition());
}

TEST(Translation)
{	
	GeomPoint point;

	//Goal Line
	GeomPoint control(Vector3(13.5,5.5,7.5));

	//Apply and Test
	point.translate(Vector3(13.5,5.5,7.5),GeomTS_World);
	CHECK_EQUAL(point.getPosition(),control.getPosition());
}

}