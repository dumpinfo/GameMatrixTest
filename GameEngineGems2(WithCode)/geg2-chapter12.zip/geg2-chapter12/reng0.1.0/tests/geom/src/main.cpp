#include "REng/Geom.h"

// unit testing support
#include <UnitTest++/UnitTest++.h>
#include <UnitTest++/XmlTestReporter.h>
#include <fstream>
#include <iostream>

using namespace REng;
using namespace std;
using namespace UnitTest;

SUITE(Geom)
{

TEST(Function_Calls)
{
	GeomAxisAlignedBox aab;
	GeomCylinder cylinder;
	GeomLine line;
	GeomOrientedBox ob;
	GeomPlane plane;
	GeomPlaneBoundedVolume pbv;
	GeomPoint point;
	GeomSphere sphere;

	cout << endl << "aab" << endl;
	cout << aab.getPosition() << endl;
	if(aab.canRotate()) {
		aab.rotate(Quaternion(0,0,0,1));
		cout << aab.getPosition() << endl;	
		aab.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << aab.getPosition() << endl;
	}
	if(aab.canScale()) {
		aab.scale(Vector3());
		cout << aab.getPosition() << endl;
	}
	if(aab.canTranslate()) {
		aab.translate(Vector3());
		cout << aab.getPosition() << endl;
		aab.translate(Vector3(),GeomTS_Local);
		cout << aab.getPosition() << endl;
	}

	cout << endl << "cylinder" << endl;
	cout << cylinder.getPosition() << endl;
	if(cylinder.canRotate()) {
		cylinder.rotate(Quaternion(0,0,0,1));
		cout << cylinder.getPosition() << endl;
		cylinder.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << cylinder.getPosition() << endl;
	}
	if(cylinder.canScale()) {
		cylinder.scale(Vector3());
		cout << cylinder.getPosition() << endl;
	}
	if(cylinder.canTranslate()) {
		cylinder.translate(Vector3());
		cout << cylinder.getPosition() << endl;
		cylinder.translate(Vector3(),GeomTS_Local);
		cout << cylinder.getPosition() << endl;
	}

	cout << endl << "line" << endl;
	cout << line.getPosition() << endl;
	if(line.canRotate()) {
		line.rotate(Quaternion(0,0,0,1));
		cout << line.getPosition() << endl;
		line.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << line.getPosition() << endl;
	}
	if(line.canScale()) {
		line.scale(Vector3());
		cout << line.getPosition() << endl;
	}
	if(line.canTranslate()) {
		line.translate(Vector3());
		cout << line.getPosition() << endl;
		line.translate(Vector3(),GeomTS_Local);
		cout << line.getPosition() << endl;
	}

	cout << endl << "ob" << endl;
	cout << ob.getPosition() << endl;
	if(ob.canRotate()) {
		ob.rotate(Quaternion(0,0,0,1));
		cout << ob.getPosition() << endl;
		ob.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << ob.getPosition() << endl;
	}
	if(ob.canScale()) {
		ob.scale(Vector3());
		cout << ob.getPosition() << endl;
	}
	if(ob.canTranslate()) {
		ob.translate(Vector3());
		cout << ob.getPosition() << endl;
		ob.translate(Vector3(),GeomTS_Local);
		cout << ob.getPosition() << endl;
	}

	cout << endl << "plane" << endl;
	cout << plane.getPosition() << endl;
	if(plane.canRotate()) {
		plane.rotate(Quaternion(0,0,0,1));
		cout << plane.getPosition() << endl;
		plane.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << plane.getPosition() << endl;
	}
	if(plane.canScale()) {
		plane.scale(Vector3());
		cout << plane.getPosition() << endl;
	}
	if(plane.canTranslate()) {
		plane.translate(Vector3());
		cout << plane.getPosition() << endl;
		plane.translate(Vector3(),GeomTS_Local);
		cout << plane.getPosition() << endl;
	}

	cout << endl << "pbv" << endl;
	cout << pbv.getPosition() << endl;
	if(pbv.canRotate()) {
		pbv.rotate(Quaternion(0,0,0,1));
		cout << pbv.getPosition() << endl;
		pbv.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << pbv.getPosition() << endl;
	}
	if(pbv.canScale()) {
		pbv.scale(Vector3());
		cout << pbv.getPosition() << endl;
	}
	if(pbv.canTranslate()) {
		pbv.translate(Vector3());
		cout << pbv.getPosition() << endl;
		pbv.translate(Vector3(),GeomTS_Local);
		cout << pbv.getPosition() << endl;
	}

	cout << endl << "point" << endl;
	cout << point.getPosition() << endl;
	if(point.canRotate()) {
		point.rotate(Quaternion(0,0,0,1));
		cout << point.getPosition() << endl;
		point.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << point.getPosition() << endl;
	}
	if(point.canScale()) {
		point.scale(Vector3());
		cout << point.getPosition() << endl;
	}
	if(point.canTranslate()) {
		point.translate(Vector3());
		cout << point.getPosition() << endl;
		point.translate(Vector3(),GeomTS_Local);
		cout << point.getPosition() << endl;
	}

	cout << endl << "sphere" << endl;
	cout << sphere.getPosition() << endl;
	if(sphere.canRotate()) {
		sphere.rotate(Quaternion(0,0,0,1));
		cout << sphere.getPosition() << endl;
		sphere.rotate(Quaternion(0,0,0,1),GeomTS_Local);
		cout << sphere.getPosition() << endl;
	}
	if(sphere.canScale()) {
		sphere.scale(Vector3());
		cout << sphere.getPosition() << endl;
	}
	if(sphere.canTranslate()) {
		sphere.translate(Vector3());
		cout << sphere.getPosition() << endl;
		sphere.translate(Vector3(),GeomTS_Local);
		cout << sphere.getPosition() << endl;
	}

}

}

int main()
{
	// log to an xml file (has more detailed structure)
	std::ofstream f("logs/geomtest.xml");
	XmlTestReporter reporter(f);
	TestRunner runner(reporter);
	return runner.RunTestsIf(Test::GetTestList(), NULL, True(), 0);
}

