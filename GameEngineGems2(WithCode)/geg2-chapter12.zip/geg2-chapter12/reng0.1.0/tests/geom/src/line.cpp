#include <UnitTest++/UnitTest++.h>

#include "REng/Geom.h"

using namespace UnitTest;
using namespace std;
using namespace REng;

SUITE(Geom_Line)
{
	Vector3 tolerance(0.0000005,0.0000005,0.0000005);

TEST(Constructors)
{	
	GeomLine line;
	GeomLine line2(Vector3(0,0,0),Vector3(1,0,0));
	GeomLine line3(Vector3(0,0,0),Vector3(1,0,0),true);

	CHECK_EQUAL(line.getPosition(),line2.getPosition());
	CHECK_EQUAL(line.getDirection(),line2.getDirection());

	CHECK_EQUAL(line.getPosition(),line3.getPosition());
	CHECK_EQUAL(line.getDirection(),line3.getDirection());
}

TEST(Translation)
{
	GeomLine line;

	//Goal Line
	GeomLine control(Vector3(1,2,3),Vector3(1,0,0));

	//Apply and Test
	line.translate(Vector3(1,2,3),GeomTS_Local);
	CHECK_EQUAL(line.getPosition(),control.getPosition());
	CHECK_EQUAL(line.getDirection(),control.getDirection());
}

TEST(Rotation)
{
	GeomLine line;

	line.setPosition(Vector3(1,2,3));
	line.setDirection(Vector3(0,0,1));

	//Goal Line
	GeomLine control(Vector3(1,-3,2),Vector3(0,-1,0));

		
	//Rotation to be applied
	Quaternion q;
	cml::quaternion_rotation_euler(q,(float)90.0*cml::constants<float>::rad_per_deg(),(float)0.0,(float)0.0,cml::euler_order_xyz);

	//Apply and Test
	line.rotate(q,GeomTS_World);
	CHECK_CLOSE(line.getPosition(),control.getPosition(),tolerance);
	CHECK_CLOSE(line.getDirection(),control.getDirection(),tolerance);
}
}