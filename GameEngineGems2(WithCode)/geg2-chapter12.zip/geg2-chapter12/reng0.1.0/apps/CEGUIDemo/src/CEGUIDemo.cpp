#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// CEGUI DEMO

#define WINDOW_WIDTH  800
#define WINDOW_HEIGHT 600

CEGUI::REngRenderer* guiRenderer;
CameraNode* camNode  =0;
MeshNode*   meshNode =0;

// common quaternions
Quaternion rotX_neg90, rotZ_neg90, rotX_pos90, rotZ_pos90, rotY_pos90;
Quaternion rotZ_neg135, rotZ_pos135;
Quaternion rotX_pos45, rotX_neg45;
Quaternion rotY_180, rotZ_180;

void initQuaternions(){
	cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
	cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
	cml::quaternion_rotation_world_y(rotY_180,Angle::degree2radian(180));
	cml::quaternion_rotation_world_y(rotY_pos90,Angle::degree2radian(90));
	cml::quaternion_rotation_world_z(rotZ_180,Angle::degree2radian(180));
	rotX_pos90 = rotX_neg90; rotX_pos90.inverse();
	rotX_pos45 = rotX_neg45;   rotX_pos45.inverse();
	rotZ_pos90 = rotZ_neg90;   rotZ_pos90.inverse();
	rotZ_pos135 = rotZ_neg135; rotZ_pos135.inverse();
}
bool handle_ItemDropped(const CEGUI::EventArgs& args){
	using namespace CEGUI;
	const DragDropEventArgs& dd_args =
		static_cast<const DragDropEventArgs&>(args);

	if (!dd_args.window->getChildCount()) {
		dd_args.window->addChildWindow(dd_args.dragDropItem);
		dd_args.dragDropItem->setPosition(UVector2(UDim(0.05f, 0),UDim(0.05f, 0)));
	}
	return true;
}

bool handle_CloseButton(const CEGUI::EventArgs&) {
	return true;
}

void subscribeEvents() {
	using namespace CEGUI;
	WindowManager& wmgr = WindowManager::getSingleton();

	try {
		CEGUI::Window* main_wnd = wmgr.getWindow("Root/MainWindow");
		main_wnd->subscribeEvent(
			FrameWindow::EventCloseClicked,
			Event::Subscriber(&handle_CloseButton));
	}
	catch(CEGUI::Exception&) {}

	String base_name = "Root/MainWindow/Slot";

	for (int i = 1; i <= 12; ++i) {
		try {
			CEGUI::Window* wnd = wmgr.getWindow(base_name + PropertyHelper::intToString(i));

			wnd->subscribeEvent(
				CEGUI::Window::EventDragDropItemDropped,
				Event::Subscriber(handle_ItemDropped));
		}
		// if something goes wrong, log the issue but do not bomb!
		catch(CEGUI::Exception&)
		{}
	}
}



class CEGUIDemoApp : public Application_Base {
public:
	CEGUIDemoApp() {}
	~CEGUIDemoApp() {}
	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		// create application window
		RectI pos(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30);
		RSys.createWindowAndGLContext(pos,0,inputStartup);
		if(!RSys.initSystem()) return false;

		initQuaternions();

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/model.material");
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		// create a mesh node, put a mesh inside
		meshNode = &(MeshNode::create(RootNode::getSingleton()));
		MeshPtr mesh = MeshManager::getSingleton().createMesh("boxMesh");
		mesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB());
		mesh->mMaterial = MaterialManager::getSingleton().getMaterial("SimpleMat");
		meshNode->setMesh(mesh);
		meshNode->scale_Parent(17);

		// *********************
		// CAMERA SETUP
		camNode = &(CameraNode::create(RootNode::getSingleton()));
		camNode->translate_Parent(Vector3(0.0f,0.0f,400.0f),true);
		CameraPerspective& camera(CameraPerspective::create(*camNode));
		camera.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera.setFarDistance(2000.0f);
		camera.setNearDistance(1.f);
		camera.setFieldOfView_y(AngleDegree(45.0f));

		RSys.getViewport(0)->mCamera = &camera;

		Logger logger = Logger::getInstance("App");

		guiRenderer = &CEGUI::REngRenderer::create(*RSys.getViewport(0));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();

		initSharedCEGUIOverlay(guiRenderer);
	    
		initGUI();
		return true;
	}
	void initGUI(){
		using namespace CEGUI;
		SchemeManager::getSingleton().create("TaharezLook.scheme");

		System::getSingleton().setDefaultMouseCursor("TaharezLook", "MouseArrow");

		WindowManager& winMgr = WindowManager::getSingleton();

		DefaultWindow* root = (DefaultWindow*)winMgr.createWindow("DefaultWindow", "Root");

		System::getSingleton().setGUISheet(root);

		FrameWindow* wnd = (FrameWindow*)winMgr.createWindow("TaharezLook/FrameWindow", "Demo Window");

		root->addChildWindow(wnd);

		wnd->setPosition(UVector2(cegui_reldim(0.25f), cegui_reldim( 0.25f)));
		wnd->setSize(UVector2(cegui_reldim(0.5f), cegui_reldim( 0.5f)));

		wnd->setMaxSize(UVector2(cegui_reldim(1.0f), cegui_reldim( 1.0f)));
		wnd->setMinSize(UVector2(cegui_reldim(0.1f), cegui_reldim( 0.1f)));

		wnd->setText("Hello World!");
	}
	bool preRender(float timeLapse){
		// update logo rotation
		cml::quaternionf_n rotator2;
		Vector3 rotatorAxis2(1.0f,1.0f,0.6f);
		rotatorAxis2.normalize();
		cml::quaternion_rotation_axis_angle(rotator2,rotatorAxis2,timeLapse);
		meshNode->rotate_Parent(rotator2);
		return true;
	}
	void initGUI_2(){
		using namespace CEGUI;
		// load windows look
		SchemeManager::getSingleton().create("WindowsLook.scheme");

		// load font and setup default if not loaded via scheme
		FontManager::getSingleton().create("DejaVuSans-10.font");

		// set up defaults
		System::getSingleton().setDefaultMouseCursor("WindowsLook", "MouseArrow");
		System::getSingleton().setDefaultFont("DejaVuSans-10");

		// load the drive icons imageset
		ImagesetManager::getSingleton().create("DriveIcons.imageset");

		// load the initial layout
		System::getSingleton().setGUISheet(
			WindowManager::getSingleton().loadWindowLayout("DragDropDemo.layout"));

		// setup events
		subscribeEvents();
	}

};


int main(){
	new CEGUIDemoApp();
	return CEGUIDemoApp::getSingleton().run();
}

