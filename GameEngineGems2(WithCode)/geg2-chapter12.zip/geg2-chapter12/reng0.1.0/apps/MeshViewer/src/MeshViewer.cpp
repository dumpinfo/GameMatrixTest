#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// MESHVIEWER

// Loads mesh geometries and material from files, and provides
// a simple interface to switch between them.
// Author: Adil Yalcin

#define WINDOW_WIDTH  700
#define WINDOW_HEIGHT 700

class MeshViewerApp : public Application_Base {
public:
	Vector2 mMousePos;

	//! There is only a single mesh shown at a time, and this is it.
	//! @note Its material and mesh-geoms are updated to traverse in lists
	MeshNode* TheMeshNode; 

	std::vector<std::string> mMeshFiles;
	std::vector<std::string> mMaterialFiles;
	std::vector<std::string> mMeshNames;
	std::vector<std::string> mMaterialNames;

	std::vector<MeshPtr>     mMeshList;
	std::vector<MaterialPtr> mMaterialList;

	REng::uint activeMeshGeomIndex, activeMaterialIndex;

	CameraNode* camNode;
	GroupNode*  camNodeBase;
	LightNode*  sunLightNode;

	MeshViewerApp() 
		:mMousePos(0,0)
		,activeMeshGeomIndex(0)
		,activeMaterialIndex(0)
		,camNode(0)
		,camNodeBase(0)
		,sunLightNode(0)
	{}
	~MeshViewerApp() {}

	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		// create application window
		int contextParams[] = {
			GLCntxtParDoubleBuffer, GLCntxtParTrue,
			GLCntxtParVSynch,       GLCntxtParFalse,
			GLCntxtParSampleCount,  2, // request some multi-sampling
			GLCntxtParNull
		};
		RSys.createWindowAndGLContext(
			REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),
			contextParams,inputStartup,"MeshViewer",false);
		if(!RSys.initSystem()) return false;

		parseInputFile();

		// load material scripts
		for(size_t i=0 ; i<mMaterialFiles.size() ; i++){
			MaterialScriptParser::getSingleton().parseFile(mMaterialFiles[i].c_str());
		}
		// load meshes
		MeshManager::getSingleton().mTmpBoundBoxType = REng::GeomTypeAABox;
		MeshManager::getSingleton().mGenerateTangent = true;
		MeshManager::getSingleton().mGenerateBitangent = true;
		for(size_t i=0 ; i<mMeshFiles.size() ; i++){
			MeshManager::getSingleton().loadFromFile(mMeshFiles[i]);
		}
		// process meshlist
		for(size_t i=0 ; i<mMeshNames.size() ; i++){
			const char* makeTorus = strstr(mMeshNames[i].c_str(),"makeTorus_maj_");
			if(makeTorus==mMeshNames[i].c_str()){
				int maj_rad, maj_seg, min_rad, min_seg;
				if(4==sscanf(makeTorus,"makeTorus_maj_%d_%d_min_%d_%id",&maj_rad,&maj_seg,&min_rad,&min_seg)){
					MeshGeom mg=MeshGeomGenerator::getSingleton().getTorus(maj_rad,maj_seg,min_rad,min_seg);
					MeshPtr mptr = MeshManager::getSingleton().createMesh(makeTorus);
					mptr->createLoDGeom(mg);
					mMeshList.push_back(mptr);
					continue;
				}
			}
			MeshPtr mptr(MeshManager::getSingleton().getMeshByName(mMeshNames[i]));
			if(mptr.get()!=0) mMeshList.push_back(mptr);
		}
		// process materials
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();
		for(size_t i=0 ; i<mMaterialNames.size() ; i++){
			MaterialPtr mptr(MaterialManager::getSingleton().getMaterial(mMaterialNames[i].c_str()));
			if(mptr.get()!=0) {
				if(!mptr->isValid()) continue;
				mMaterialList.push_back(mptr);
			}
		}

		// add another node to display the triad
		GroupNode& triadNode(MeshGeomGenerator::getSingleton().createTriad_Arrow(RootNode::getSingleton()));
		triadNode.translate_World(Vector3(50,-50,50));
		triadNode.scale_Parent(10);
		triadNode.mCullingMode = SceneNode::CULL_NEVER;

		// *********************
		// CAMERA SETUP

		camNodeBase = &(GroupNode::create(RootNode::getSingleton()));
		camNode = &(CameraNode::create(*camNodeBase));
		camNode->translate_Parent(Vector3(0.0f,0.0f,180.0f),true);
		CameraPerspective& camera(CameraPerspective::create(*camNode));
		camera.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera.setFarDistance(2000.0f);
		camera.setNearDistance(1.f);
		camera.setFieldOfView_y(AngleDegree(45.0f));
		RSys.getViewport(0)->mCamera = &camera;

	   // *********************
		// Light setup
		GroupNode* lightNode_base = &GroupNode::create(RootNode::getSingleton());
		sunLightNode = &LightNode::create(*((GroupNode*)lightNode_base));
		sunLightNode->translate_Local(Vector3(0.0f,22.0f,-20.0f),true);
		// NOTE: MODIFIED LIGHT CLASSES FOR OMAP ARE CURRENTLY NOT SUPPORTED
		// Update OMAP's GL driver to solve the struct uniform access problems, if you want to.
		Light_Sun& sunLight1(Light_Sun::create(*((LightNode*)sunLightNode)));
		sunLight1.setColor(Color_Real(0.6f,0.6f,0.8f));

		RSys.setSkyMeshGeom( MeshGeomGenerator::getSingleton().getUnitAAB() );

		TheMeshNode = &MeshNode::create(RootNode::getSingleton());
		initGUI();
		refreshTheMesh();
		
		return true;
	}
	bool preRender(float timeLapse){
		Quaternion rotY;
		cml::quaternion_rotation_world_y(rotY,timeLapse*0.9f);
		sunLightNode->rotate_World(rotY);
		return true;
	}

	void refreshTheMesh(){
		MeshPtr m = mMeshList[activeMeshGeomIndex];
		m->mMaterial = mMaterialList[activeMaterialIndex];
		TheMeshNode->setMesh(m);
#ifdef RENG_SAMPLE_USECEGUI
		CEGUI::DefaultWindow* textBox = (CEGUI::DefaultWindow*)
			CEGUI::WindowManager::getSingleton().getWindow("MaterialText");
		char matStr[128];
		sprintf(matStr,"Material: %s",m->mMaterial->getName().c_str());
		textBox->setText(matStr);
		textBox = (CEGUI::DefaultWindow*) CEGUI::WindowManager::getSingleton().getWindow("MeshText");
		sprintf(matStr,"Mesh: %s",m->getName().c_str());
		textBox->setText(matStr);
#endif
	}

	void initGUI(){
#ifdef RENG_SAMPLE_USECEGUI
		Viewport *vpFull = RenderSystem::getSingleton().getViewport(0);
		Viewport *vp = new Viewport();
		vp->setAbsRect(vpFull->getAbsRect());
		vp->disableRenderQueues_LessThan(REnderQueueID_GUI);
		vp->autoClearBuffer(FrameBufferComponent_Depth,false);
		vp->autoClearBuffer(FrameBufferComponent_Stencil,false);
		//	// Note: GUi viewport should be rendered after (on top of) multi-view viewports
		RenderSystem::getSingleton().addViewport(1,vp);

		CEGUI::REngRenderer* guiRenderer(&CEGUI::REngRenderer::create(*vp));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();
		initSharedCEGUIOverlay(guiRenderer);
		CEGUI::SchemeManager::getSingleton().create("TaharezLook.scheme");

		using namespace CEGUI;

		SchemeManager::getSingleton().create("TaharezLook.scheme");
		System::getSingleton().setDefaultMouseCursor("TaharezLook", "MouseArrow");

		WindowManager& winMgr = WindowManager::getSingleton();
		DefaultWindow* root = (DefaultWindow*)winMgr.createWindow("DefaultWindow", "Root");
		System::getSingleton().setGUISheet(root);

		CEGUI::Font& ft(FontManager::getSingleton().createFreeTypeFont("overlayFont",15,true,"batang.ttf"));

		DefaultWindow* textBox;
		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","MaterialText");
		textBox->setPosition(UVector2(cegui_absdim(20), cegui_reldim(0.9)));
		textBox->setSize(UVector2(cegui_absdim(500), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		root->addChildWindow(textBox);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","MeshText");
		textBox->setPosition(UVector2(cegui_absdim(20), cegui_reldim(0.86)));
		textBox->setSize(UVector2(cegui_absdim(500), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		root->addChildWindow(textBox);
#endif
	}

	bool parseInputFile(){
		Logger logger = Logger::getInstance("App");
		std::ifstream fileStream;
		const char* fileName = "MeshViewer.input";
		fileStream.open(fileName);
		size_t memSize = 0;
		char* mem = 0;
		if(!fileStream.is_open()) {
			LOG4CPLUS_ERROR(logger, "File ["<<fileName<<"] could not be opened.");
			return false;
		} else {
			std::string inputStr((std::istreambuf_iterator<char>(fileStream)), std::istreambuf_iterator<char>());
			fileStream.close();
			memSize = inputStr.length();
			mem = (char*)malloc(memSize+2);
			mem[memSize+1] = 0;
			strcpy(mem,inputStr.c_str());
		}
		LOG4CPLUS_INFO(logger, "Parsing input file ["<<fileName<<"].");

		char lineBuf[256];
		enum BlockType {BlockMatFile, BlockMatName, BlockMeshFile, BlockMeshName};
		BlockType bt(BlockMatFile);
		for(size_t ind=0;ind<memSize;){
			size_t indL=0;
			for(; ; ++indL){
				size_t _ind = ind+indL;
				if(mem[_ind]=='\n'||_ind==memSize){
					lineBuf[indL] = 0;
					indL++;
					break;
				}
				lineBuf[indL] = mem[ind+indL];
			}
			ind += indL;
			// trim whitespace at the end
			for(size_t i=indL-1;;--i){ 
				if(lineBuf[i]==' ') lineBuf[i]=0; else break;
			}
			if(lineBuf[0]=='#' && lineBuf[1]=='#') { continue; } // comment line
			if(lineBuf[0]==0) {continue;} // empty line
			if(!strcmp(lineBuf,"==materialFiles==")){ bt=BlockMatFile;  continue;}
			if(!strcmp(lineBuf,"==materialNames==")){ bt=BlockMatName;  continue;}
			if(!strcmp(lineBuf,"==meshFiles=="))    { bt=BlockMeshFile; continue;}
			if(!strcmp(lineBuf,"==meshNames=="))    { bt=BlockMeshName; continue;}
			switch(bt){
				case BlockMatFile: mMaterialFiles.push_back(lineBuf); break;
				case BlockMatName: mMaterialNames.push_back(lineBuf); break;
				case BlockMeshFile: mMeshFiles.push_back(lineBuf); break;
				case BlockMeshName: mMeshNames.push_back(lineBuf); break;
				default:break;
			}
			size_t a=10;
		}

		free(mem);
		return true;
	}

	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_LEFT) {
			if(activeMaterialIndex>0) activeMaterialIndex--;
			else activeMaterialIndex = mMaterialList.size()-1;
		}
		if(arg.key == OIS::KC_RIGHT) {
			activeMaterialIndex++;
			activeMaterialIndex = activeMaterialIndex % mMaterialList.size();
		}
		if(arg.key == OIS::KC_DOWN) {
			activeMeshGeomIndex++;
			activeMeshGeomIndex = activeMeshGeomIndex % mMeshList.size();
		}
		if(arg.key == OIS::KC_UP) {
			if(activeMeshGeomIndex>0) activeMeshGeomIndex--;
			else activeMeshGeomIndex = mMeshList.size()-1;
		}
		refreshTheMesh();
		return true;
	}
	bool mouseMoved( const OIS::MouseEvent &arg ) {
		Vector2 curMousePos(arg.state.X.abs,arg.state.Y.abs);
		if(arg.state.buttonDown(OIS::MB_Left)){
			Vector2 dif = curMousePos-mMousePos;
			Quaternion rotY, rotX;
			cml::quaternion_rotation_world_x(rotX,-(arg.state.Y.rel*0.009f));
			cml::quaternion_rotation_world_y(rotY,-(arg.state.X.rel*0.009f));
			if(!mKeyboard->isModifierDown(OIS::Keyboard::Shift)){
				camNodeBase->rotate_Parent(rotX,false);
				camNodeBase->rotate_Parent(rotY,false);
			} else {
//				TheMeshNode->rotate_World(rotX.inverse(),false);
				TheMeshNode->rotate_World(rotY.inverse(),false);
			}
		}
		if( arg.state.Z.rel != 0 ){
			if(arg.state.Z.rel>0) camNode->translate_Parent(Vector3(0.0f,0.0f,+10.0f),false);
			if(arg.state.Z.rel<0) camNode->translate_Parent(Vector3(0.0f,0.0f,-10.0f),false);
		}
		mMousePos = curMousePos;
		return true;
	}
};

int main(){
	new MeshViewerApp();
	return MeshViewerApp::getSingleton().run();
}
