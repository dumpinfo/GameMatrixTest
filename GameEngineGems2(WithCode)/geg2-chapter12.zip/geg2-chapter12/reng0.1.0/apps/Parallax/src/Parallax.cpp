// PARALLAX DEMO IS ONLY AIMED TOWARDS OPENGL 3.0> CONTEXTS

#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <stdio.h>
#include <time.h>

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

#define WINDOW_WIDTH  700
#define WINDOW_HEIGHT 700

CameraNode* camNode    = 0;
GroupNode*  camNodeBase = 0;

// common quaternions
Quaternion rotX_neg90;
Quaternion rotX_neg45;
Quaternion rotZ_neg90;
Quaternion rotZ_neg135;
Quaternion rotX_pos90;
Quaternion rotX_pos45;
Quaternion rotZ_pos90;
Quaternion rotZ_pos135;
Quaternion rotY_180;
Quaternion rotZ_180;

Quaternion rotator;
Quaternion rotator2;

bool animate = false;

MeshPtr mesh1, mesh2, mesh3, sphereMesh;
MeshNode *meshNode, *sphereNode;

Vector3 camSpeed = Vector3(0,0,0);

void initQuaternions(){
	cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
	cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
	cml::quaternion_rotation_world_y(rotY_180,Angle::degree2radian(180));
	cml::quaternion_rotation_world_z(rotZ_180,Angle::degree2radian(180));
	rotX_pos90 = rotX_neg90; rotX_pos90.inverse();
	rotX_pos45 = rotX_neg45;   rotX_pos45.inverse();
	rotZ_pos90 = rotZ_neg90;   rotZ_pos90.inverse();
	rotZ_pos135 = rotZ_neg135; rotZ_pos135.inverse();
}

class ParallaxApp : public Application_Base {
public:
	ParallaxApp() :mMousePos(0,0){}
	~ParallaxApp() {}

	bool loadApp(){
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		std::cout << "This demo is not supported in OpenGL ES 2.0 configurations" << std::endl;
		return 0;
#endif
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		RSys.createWindowAndGLContext(RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),0,inputStartup);
		if(!RSys.initSystem()) return false;

		MeshManager& MeshMan(MeshManager::getSingleton());
		MaterialManager& MatMan(MaterialManager::getSingleton());
		Logger myLogger= Logger::getInstance("App");

		// shared materials
		MaterialScriptParser::getSingleton().parseFile("materials/parallax.material");

		// create and initialize material resources
		MatMan.compileMaterialShaders();
		MatMan.loadMaterials();

		initQuaternions();

		//////////////////////////////////////////////////////////////////////////
		// CREATE MESHES
		//////////////////////////////////////////////////////////////////////////

		REng::MeshManager::getSingleton().mGenerateBitangent = true;
		REng::MeshManager::getSingleton().mGenerateTangent   = true;
		REng::MeshManager::getSingleton().mGenerateNormals   = true;
		REng::MeshManager::getSingleton().mMeshOrient = REng::MeshOrientRHS;
		REng::MeshManager::getSingleton().loadFromFile("mesh/Disc2.3ds");  // ChamferCyl
		REng::MeshManager::getSingleton().loadFromFile("mesh/Teapot.3ds"); // Teapot01
		REng::MeshManager::getSingleton().loadFromFile("mesh/Car.3ds");  // carrip #1
		mesh1 = MeshMan.getMeshByName("ChamferCyl");
		if(mesh1.get())mesh1->mMaterial = MaterialManager::getSingleton().getMaterial("Parallax");
		mesh2 = MeshMan.getMeshByName("Teapot01");
		if(mesh2.get())mesh2->mMaterial = MaterialManager::getSingleton().getMaterial("Parallax");
		mesh3 = MeshMan.getMeshByName("carrip #1");
		if(mesh3.get())mesh3->mMaterial = MaterialManager::getSingleton().getMaterial("Parallax");

		sphereMesh = REng::MeshManager::getSingleton().createMesh("sphereMesh");
		sphereMesh->mMaterial = REng::MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		sphereMesh->createLoDGeom(REng::MeshGeomGenerator::getSingleton().getUnitSphere(3));
		//////////////////////////////////////////////////////////////////////////
		// SET SCENE GRAPH STRUCTURE
		//////////////////////////////////////////////////////////////////////////

		// Base Node
		meshNode = &(MeshNode::create(RootNode::getSingleton()));
		if(mesh1.get()) meshNode->setMesh(mesh1);
		else if(mesh2.get()) meshNode->setMesh(mesh2);
		else if(mesh3.get()) meshNode->setMesh(mesh3);

		// Base Node
		sphereNode = &(MeshNode::create(RootNode::getSingleton()));
		sphereNode->setMesh(sphereMesh);
		sphereNode->scale_Parent(10.0f);

		// *********************
		// CAMERA SETUP

		camNodeBase = &(GroupNode::create(RootNode::getSingleton()));
		camNode = &(CameraNode::create(*camNodeBase));
		camNode->translate_Parent(Vector3(0.0f,0.0f,130.0f),true);

		CameraPerspective& camera(CameraPerspective::create(*camNode));
		camera.setAspectRatio(700.0f/700.0f);
		camera.setFarDistance(2000.0f);
		camera.setNearDistance(1.f);
		camera.setFieldOfView_y(AngleDegree(45.0f));

		RSys.getViewport(0)->mCamera = &camera;
		return true;
	}

	bool preRender(float elapsed){
		camNode->translate_Parent(100*elapsed*camSpeed,false);
		return true;
	}

	Vector2 mMousePos;
	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_1) if(mesh1.get()) meshNode->setMesh(mesh1);
		if(arg.key == OIS::KC_2) if(mesh2.get()) meshNode->setMesh(mesh2);
		if(arg.key == OIS::KC_3) if(mesh3.get()) meshNode->setMesh(mesh3);
		if(arg.key == OIS::KC_W) camSpeed = Vector3(0.0f,0.0f,-10.0f);
		if(arg.key == OIS::KC_S) camSpeed = Vector3(0.0f,0.0f,+10.0f);
		if(arg.key == OIS::KC_SPACE) {
			if(sphereNode->mCullingMode == SceneNode::CULL_ALWAYS) 
				sphereNode->mCullingMode = SceneNode::CULL_DYNAMIC;
			else 
				sphereNode->mCullingMode = SceneNode::CULL_ALWAYS;
		}
		return true;
	}
	bool keyReleased( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_W) camSpeed = Vector3(0.0f,0.0f,0.0f);
		if(arg.key == OIS::KC_S) camSpeed = Vector3(0.0f,0.0f,0.0f);
		return true;
	}
	bool mouseMoved( const OIS::MouseEvent &arg ) {
		Vector2 curMousePos(arg.state.X.abs,arg.state.Y.abs);
		if(arg.state.buttonDown(OIS::MB_Left)){
			Vector2 dif = curMousePos-mMousePos;
			Quaternion rotY, rotX;
			cml::quaternion_rotation_world_x(rotX,-(arg.state.Y.rel*0.009f));
			cml::quaternion_rotation_world_y(rotY,-(arg.state.X.rel*0.009f));
			camNodeBase->rotate_Parent(rotX,false);
			camNodeBase->rotate_Parent(rotY,false);
		}
		if( arg.state.Z.rel != 0 ){
			if(arg.state.Z.rel>0)
				camNode->translate_Parent(Vector3(0.0f,0.0f,+10.0f),false);
			if(arg.state.Z.rel<0)
				camNode->translate_Parent(Vector3(0.0f,0.0f,-10.0f),false);
		}
		mMousePos = curMousePos;
		return true;
	}
};

int main(){
	new ParallaxApp();
	return ParallaxApp::getSingleton().run();
}
