#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// GEOM GENERATOR

// Tests GeomGenerator feature (spheres, cylinders, etc)
// Author: Adil Yalcin

#define WINDOW_WIDTH  700
#define WINDOW_HEIGHT 700

CameraNode* camNode = 0;
GroupNode* sphereGroup;
GroupNode* boxGroup;
GroupNode* discGroup;
GroupNode* cylinderGroup;
GroupNode* robotGroup;


class GeomGeneratorApp : public Application_Base {
public:
	GeomGeneratorApp() {}
	~GeomGeneratorApp() {}
	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		RSys.createWindowAndGLContext(REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),0,inputStartup);
		if(!RSys.initSystem()) return false;

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/model.material");
		MaterialScriptParser::getSingleton().parseFile("materials/meshgeomgen.material");

		// create and initialize material resources
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		//////////////////////////////////////////////////////////////////////////
		// CREATE MESHES
		//////////////////////////////////////////////////////////////////////////
		// we won't load external meshes...

		MeshPtr groundMesh = MeshManager::getSingleton().createMesh("ground");
		groundMesh->mMaterial = MaterialManager::getSingleton().getMaterial("base_ground");
		groundMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane(),0,0);

		MeshPtr sphereMesh = MeshManager::getSingleton().createMesh("sphereMesh");
		sphereMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		sphereMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(3));
		MeshPtr sphereMesh_LR = MeshManager::getSingleton().createMesh("sphereMesh_LR");
		sphereMesh_LR->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		sphereMesh_LR->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(1));
		MeshPtr sphereMesh_LR2 = MeshManager::getSingleton().createMesh("sphereMesh_LR2");
		sphereMesh_LR2->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		sphereMesh_LR2->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(0));

		MeshPtr boxMesh = MeshManager::getSingleton().createMesh("boxMesh");
		boxMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		boxMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB());
		MeshPtr boxMeshGreen = MeshManager::getSingleton().createMesh("boxMeshGreen");
		boxMeshGreen->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat_Green");
		boxMeshGreen->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB());
		MeshPtr boxMeshWire = MeshManager::getSingleton().createMesh("boxMeshWire");
		boxMeshWire->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		boxMeshWire->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB(false));

		MeshPtr discMesh = MeshManager::getSingleton().createMesh("discMesh");
		discMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		discMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitCircle(3,true));

		MeshPtr cylMesh1 = MeshManager::getSingleton().createMesh("cylMesh1");
		cylMesh1->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		cylMesh1->createLoDGeom(MeshGeomGenerator::getSingleton().getCyclinder(3,0.5));
		MeshPtr cylMesh2 = MeshManager::getSingleton().createMesh("cylMesh2");
		cylMesh2->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		cylMesh2->createLoDGeom(MeshGeomGenerator::getSingleton().getCyclinder(3,2.0));
		MeshPtr cylMesh3 = MeshManager::getSingleton().createMesh("cylMesh3");
		cylMesh3->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		cylMesh3->createLoDGeom(MeshGeomGenerator::getSingleton().getCyclinder(3,1.0));
		MeshPtr coneMesh = MeshManager::getSingleton().createMesh("coneMesh");
		coneMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		coneMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getCyclinder(3,0.0));
		MeshPtr coneMesh2 = MeshManager::getSingleton().createMesh("coneMesh2");
		coneMesh2->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		coneMesh2->createLoDGeom(MeshGeomGenerator::getSingleton().getCone(3));

		//////////////////////////////////////////////////////////////////////////
		// SET SCENE GRAPH STRUCTURE
		//////////////////////////////////////////////////////////////////////////

		Quaternion rotX_neg90;
		cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
		Quaternion rotX_pos90(rotX_neg90);
		rotX_pos90.inverse();

		Quaternion rotX_neg45;
		cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
		Quaternion rotX_pos45(rotX_neg45);
		rotX_pos45.inverse();

		Quaternion rotZ_neg90;
		cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
		Quaternion rotZ_pos90(rotZ_neg90);
		rotZ_pos90.inverse();

		Quaternion rotZ_neg135;
		cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
		Quaternion rotZ_pos135(rotZ_neg135);
		rotZ_pos135.inverse();

		// Ground Node
		MeshNode& groundNode(MeshNode::create(RootNode::getSingleton()));
		groundNode.setMesh(groundMesh);
		groundNode.translate_Local(cml::vector3f(0.0f,-20.0f,0.0f),true);
		groundNode.scale_Parent(70.f,true);
		groundNode.rotate_Parent(rotX_neg90,true);

		// Box Group
		boxGroup = &(GroupNode::create(RootNode::getSingleton()));
		boxGroup->scale_Parent(0.8);
		boxGroup->translate_Local(cml::vector3f(0.0f,-10.0f,0.0f),true);
		MeshNode& boxNode(MeshNode::create(*boxGroup));
		boxNode.setMesh(boxMesh);
		boxNode.scale_Parent(5.0);
		MeshNode& boxNode_2(MeshNode::create(*boxGroup));
		boxNode_2.setMesh(boxMesh);
		boxNode_2.scale_Parent(3.0);
		boxNode_2.translate_Parent(Vector3(8,0,0));
		MeshNode& boxNode_3(MeshNode::create(*boxGroup));
		boxNode_3.setMesh(boxMesh);
		boxNode_3.scale_Parent(2.0);
		boxNode_3.translate_Parent(Vector3(13,0,0));
		MeshNode& boxNode_4(MeshNode::create(*boxGroup));
		boxNode_4.setMesh(boxMeshWire);
		boxNode_4.translate_Parent(Vector3(16,0,0));
		boxNode_4.scale_Parent(1.0);
		MeshNode& boxNode_5(MeshNode::create(*boxGroup));
		boxNode_5.setMesh(boxMeshWire);
		boxNode_5.translate_Parent(Vector3(22,0,0));
		boxNode_5.scale_Parent(5.0);

		// Circle / disc group
		discGroup = &(GroupNode::create(RootNode::getSingleton()));
		discGroup->translate_Parent(Vector3(0.0f,00.0f,0.0f));
		discGroup->scale_Parent(0.8);
		discGroup->rotate_Parent(rotX_neg90,true);
		MeshNode& discNode(MeshNode::create(*discGroup));
		discNode.setMesh(discMesh);
		discNode.scale_Parent(8.0f);
		MeshNode& discNode2(MeshNode::create(*discGroup));
		discNode2.setMesh(discMesh);
		discNode2.scale_Parent(4.0f);
		discNode2.translate_Parent(Vector3(-12.0,0.0,0.0));
		discNode2.rotate_Parent(rotX_neg90.inverse(),true);
		MeshNode& discNode3(MeshNode::create(*discGroup));
		discNode3.setMesh(discMesh);
		discNode3.scale_Parent(2.0f);
		discNode3.translate_Parent(Vector3(-18.0,0.0,0.0));

		// Sphere group
		sphereGroup = &(GroupNode::create(RootNode::getSingleton()));
		sphereGroup->translate_Parent(Vector3(0.0f,10.0f,0.0f));
		sphereGroup->scale_Parent(0.4f);
		MeshNode& sphereNode(MeshNode::create(*sphereGroup));
		sphereNode.setMesh(sphereMesh);
		sphereNode.scale_Parent(10.0f);
		MeshNode& sphereNode_LR(MeshNode::create(*sphereGroup));
		sphereNode_LR.setMesh(sphereMesh_LR);
		sphereNode_LR.scale_Parent(3.0f);
		sphereNode_LR.translate_Parent(Vector3(0.0,0.0,-13));
		MeshNode& sphereNode_LR2(MeshNode::create(*sphereGroup));
		sphereNode_LR2.setMesh(sphereMesh_LR);
		sphereNode_LR2.scale_Parent(2.0f);
		sphereNode_LR2.translate_Parent(Vector3(0.0,0.0,-18));

		// Cylinder group
		cylinderGroup = &(GroupNode::create(RootNode::getSingleton()));
		cylinderGroup->translate_Parent(Vector3(0.0f,20.0f,0.0f));
		cylinderGroup->scale_Parent(0.6);
		MeshNode& cylNode(MeshNode::create(*cylinderGroup));
		cylNode.setMesh(cylMesh1);
		cylNode.scale_Parent(8.0f);
		cylNode.rotate_Parent(rotX_neg90);
		MeshNode& cylNode2(MeshNode::create(*cylinderGroup));
		cylNode2.setMesh(cylMesh1);
		cylNode2.scale_Parent(Vector3(8.0f,4.0f,8.0f));
		cylNode2.rotate_Parent(rotX_pos90.inverse());
		MeshNode& discCap(MeshNode::create(*cylinderGroup));
		discCap.setMesh(discMesh);
		discCap.scale_Parent(4.0f);
		discCap.translate_Parent(Vector3(0.0,0.0,8.0));
		MeshNode& cylNodeCone(MeshNode::create(*cylinderGroup));
		cylNodeCone.setMesh(coneMesh);
		cylNodeCone.scale_Parent(4.0f);
		cylNodeCone.translate_Parent(Vector3(0.0,0.0,-4.0));
		cylNodeCone.rotate_Parent(rotX_pos90);

		// Robot node
		robotGroup = &(GroupNode::create(RootNode::getSingleton()));
		robotGroup->translate_Parent(Vector3(0.0f,70.0f,0.0f));
		robotGroup->scale_Parent(1.5f);
		// head
		GroupNode& robotHeadGroup(GroupNode::create(*robotGroup));
		robotHeadGroup.translate_Parent(Vector3(0.0f,7.0f,0.0f));
		MeshNode& robotHead(MeshNode::create(robotHeadGroup));
		robotHead.setMesh(sphereMesh);
		robotHead.scale_Parent(2.0f);
		MeshNode& robotEar1(MeshNode::create(robotHeadGroup));
		robotEar1.setMesh(coneMesh2);
		robotEar1.rotate_Parent(rotZ_neg90);
		robotEar1.translate_Parent(Vector3(+2.0f,0.0f,0.0f));
		MeshNode& robotEar2(MeshNode::create(robotHeadGroup));
		robotEar2.setMesh(coneMesh2);
		robotEar2.rotate_Parent(rotZ_pos90);
		robotEar2.translate_Parent(Vector3(-2.0,0.0,0.0));
		MeshNode& robotNose(MeshNode::create(robotHeadGroup));
		robotNose.setMesh(sphereMesh_LR2);
		robotNose.scale_Parent(0.5f);
		robotNose.translate_Parent(Vector3(0.0,0.0,2.25));
		// neck
		MeshNode& robotNeck(MeshNode::create(*robotGroup));
		robotNeck.setMesh(cylMesh1);
		robotNeck.translate_Parent(Vector3(0.0f,4.0f,0.0f));
		// body
		MeshNode& robotBody(MeshNode::create(*robotGroup));
		robotBody.setMesh(boxMeshGreen);
		robotBody.scale_Parent(Vector3(1.6f,4.0f,1.6f));
		// arms
		MeshNode& armNodeL(MeshNode::create(*robotGroup));
		armNodeL.setMesh(cylMesh3);
		armNodeL.scale_Parent(Vector3(.9f,2.0f,0.9f));
		armNodeL.rotate_Parent(rotZ_neg90);
		armNodeL.translate_Parent(Vector3(1.6f,1.5f,0.0f));
		MeshNode& handNodeL(MeshNode::create(*robotGroup));
		handNodeL.setMesh(discMesh);
		handNodeL.rotate_Parent(rotX_neg45);
		handNodeL.translate_Parent(Vector3(3.6f,1.5f,0.0f));
		MeshNode& armNodeR(MeshNode::create(*robotGroup));
		armNodeR.setMesh(cylMesh3);
		armNodeR.scale_Parent(Vector3(.9f,2.0f,0.9f));
		armNodeR.rotate_Parent(rotZ_pos90);
		armNodeR.translate_Parent(Vector3(-1.6f,1.5f,0.0f));
		MeshNode& handNodeR(MeshNode::create(*robotGroup));
		handNodeR.setMesh(discMesh);
		handNodeR.rotate_Parent(rotX_neg45);
		handNodeR.translate_Parent(Vector3(-3.6f,1.5f,0.0f));
		// feet
		MeshNode& legNodeL(MeshNode::create(*robotGroup));
		legNodeL.setMesh(cylMesh3);
		legNodeL.scale_Parent(Vector3(.9f,4.0f,0.9f));
		legNodeL.rotate_Parent(rotZ_neg135);
		legNodeL.translate_Parent(Vector3(+1.1f,-3.0f,0.0f));
		MeshNode& footNodeL(MeshNode::create(*robotGroup));
		footNodeL.setMesh(sphereMesh_LR2);
		footNodeL.scale_Parent(0.9f);
		footNodeL.rotate_Parent(rotZ_neg135);
		footNodeL.translate_Parent(Vector3(+1.1f,-3.0f,0.0f));
		// the tricky part: translate in local axis :)
		footNodeL.translate_Local(Vector3(+0.0f,4.0f,0.0f));
		MeshNode& legNodeR(MeshNode::create(*robotGroup));
		legNodeR.setMesh(cylMesh3);
		legNodeR.scale_Parent(Vector3(.9f,4.0f,0.9f));
		legNodeR.rotate_Parent(rotZ_pos135);
		legNodeR.translate_Parent(Vector3(-1.1f,-3.0,0.0f));
		MeshNode& footNodeR(MeshNode::create(*robotGroup));
		footNodeR.setMesh(sphereMesh_LR2);
		footNodeR.scale_Parent(0.9f);
		footNodeR.rotate_Parent(rotZ_pos135);
		footNodeR.translate_Parent(Vector3(-1.1f,-3.0f,0.0f));
		// the tricky part: translate in local axis :)
		footNodeR.translate_Local(Vector3(+0.0f,4.0f,0.0f));

		// *********************
		// CAMERA SETUP

		camNode = &(CameraNode::create(RootNode::getSingleton()));
		camNode->translate_World(Vector3(0.0f,15.0f,-90.0f),true);
		Quaternion camRot;
		cml::quaternion_rotation_world_x(camRot,-0.2f);
		camNode->rotate_World(camRot);
		cml::quaternion_rotation_world_y(camRot,Math::PI);
		camNode->rotate_World(camRot);

		CameraPerspective& camera(CameraPerspective::create(*camNode));
		camera.setAspectRatio(700.0f/700.0f);
		camera.setFarDistance(300.0f);
		camera.setNearDistance(0.1f);
		camera.setFieldOfView_y(AngleDegree(45.0f));

		RSys.getViewport(0)->mCamera = &camera;
		return true;
	}
	bool preRender(){
		Logger logger = Logger::getInstance("App");
		// rotate sphereNode node
		Quaternion rotator;
		cml::quaternion_rotation_world_y(rotator,0.001f);
		Quaternion rotatorFaster;
		cml::quaternion_rotation_world_y(rotatorFaster,0.003f);

		sphereGroup  ->rotate_World(cml::inverse(rotator));
		boxGroup     ->rotate_World(rotator);
		discGroup    ->rotate_World(rotator);
		cylinderGroup->rotate_World(rotator);
		robotGroup   ->rotate_World(rotatorFaster);
		return true;
	}
	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_W)
			camNode->translate_World(Vector3(0,+10,0));
		if(arg.key == OIS::KC_S)
			camNode->translate_World(Vector3(0,-10,0));
		return true;
	}
	void handleNonBufferedKeys() {
		static Quaternion q1, q2, q3, q4;
		EXEC_ONCE_BEGIN();
		cml::quaternion_rotation_world_y(q1,+0.001f);
		cml::quaternion_rotation_world_y(q2,-0.001f);
		cml::quaternion_rotation_world_x(q3,+0.001f);
		cml::quaternion_rotation_world_x(q4,-0.001f);
		EXEC_ONCE_END();
		if(mKeyboard->isKeyDown(OIS::KC_UP))
			camNode->rotate_Parent(q3);
		if(mKeyboard->isKeyDown(OIS::KC_DOWN))
			camNode->rotate_Parent(q4);
		if(mKeyboard->isKeyDown(OIS::KC_LEFT))
			camNode->rotate_Parent(q1);
		if(mKeyboard->isKeyDown(OIS::KC_RIGHT))
			camNode->rotate_Parent(q2);
		return;
	}
};

int main(){
	new GeomGeneratorApp();
	return GeomGeneratorApp::getSingleton().run();
}

