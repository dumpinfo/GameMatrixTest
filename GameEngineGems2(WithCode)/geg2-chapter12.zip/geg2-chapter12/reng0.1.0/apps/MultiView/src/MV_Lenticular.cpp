#include "REng/REng.h"

#include <log4cplus/logger.h>

using namespace log4cplus;

// 5-cameras in a row, with equal distance apart
// They are all oriented cameras with the same focus (todo: check)
// @note This class is used as a proof of concept, not tested on an actual 
// lenticular display
class CameraFiveView : public REng::CameraMultiView {
public:
	static CameraFiveView& create(REng::CameraNode& node){ return *(new CameraFiveView(node)); }

	REng::uchar getViewCount() const {return 5;}

	void setFocalDistance(float distance){ if(distance<0) return; mFocalDistance = distance; }
	void setEyeSeparation(float distance){ if(distance<0) return; mEyeSeparation = distance; }

	float getFocalDistance() const{ return mFocalDistance; }
	float getEyeSeparation() const{ return mEyeSeparation; }

	const REng::Matrix4& getViewMatrix() const{
		REng::Vector3 transW = getNode().getTranslation_World();
		/* */if(mActiveView == LeftView2) { transW += getLeftViewPosOffset() *2; }
		else if(mActiveView == LeftView1) { transW += getLeftViewPosOffset() *1; }
		else if(mActiveView == RightView1){ transW += getRightViewPosOffset()*1; }
		else if(mActiveView == RightView2){ transW += getRightViewPosOffset()*2; }
		REng::Quaternion rotateW(getNode().getRotation_World());
		if(true/*mType==TypeOriented*/){
			double tanAngle = mEyeSeparation/(2*mFocalDistance+mEyeSeparation*std::tan(getFieldOfView_y().getRadian()));
			double angle = std::atan(tanAngle);
			double tanAngle2 = tanAngle/2.0f;
			double angle2 = std::atan(tanAngle2);
			if(mActiveView == LeftView2){
				cml::quaternion_rotate_about_world_y(rotateW,-float(angle ));
			} else if(mActiveView == LeftView1){
				cml::quaternion_rotate_about_world_y(rotateW,-float(angle2));
			} else if(mActiveView == RightView1){
				cml::quaternion_rotate_about_world_y(rotateW,+float(angle2));
			} else if(mActiveView == RightView2){
				cml::quaternion_rotate_about_world_y(rotateW,+float(angle ));
			}
		}
		REng::CameraNode::calculateViewMatrix(rotateW,transW,mActiveViewMatrix);
		return mActiveViewMatrix;
	}

private:
	float mFocalDistance, mEyeSeparation;
	mutable REng::Matrix4 mActiveViewMatrix;
	
	enum { // two-left, two-right views
		LeftView2  = 0, LeftView1  = 1, CenterView = 2, RightView1 = 3, RightView2 = 4
	};
		
	CameraFiveView(REng::CameraNode& node)
		: CameraMultiView(node)
		,mFocalDistance(1.)
		,mEyeSeparation(0.1){}

	void updateProjectionMatrix() const{
		cml::matrix_perspective_yfov_RH( mProjectionMatrix_Cache,
			mFoV_y.getRadian(), mAspectRatio, mNearDistance, mFarDistance,
			cml::z_clip_neg_one);
		mProjectionMatrix_Dirty = false;
	}

	REng::Vector3 getLeftViewPosOffset() const  {return getNode().getRight()*-mEyeSeparation/4;}
	REng::Vector3 getRightViewPosOffset() const {return getNode().getRight()*+mEyeSeparation/4;}
};

// Merges 5 view specific images with some kind of a lenticular interlacing pattern
// @note This class is used as a proof of concept, not tested on an actual 
// lenticular display
class MVC_Lenticular : public REng::MultiViewCompositor {
public:
	MVC_Lenticular()
		: MultiViewCompositor(5)
		,mCompProg(0)
		,mCompFragS(0)
		,mImageSampler_L2(0)
		,mImageSampler_L1(0)
		,mImageSampler_C(0)
		,mImageSampler_R1(0)
		,mImageSampler_R2(0){}
	~MVC_Lenticular() { ; }

	bool init(REng::Viewport& vp){
		if(mIsInitialized) return true;
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "MultiViewCompositor Lenticular initializing...");

		if(updateCompProg()==false) return false;
		initCompositorGeom();

		mIsInitialized = true;
		mIsSupported = true;
		LOG4CPLUS_INFO(logger, "MVC Lenticular initialization completed.");
		return true;
	}

	bool clear(){
		if(mImageSampler_L2){ delete mImageSampler_L2; mImageSampler_L2=0; }
		if(mImageSampler_L1){ delete mImageSampler_L1; mImageSampler_L1=0; }
		if(mImageSampler_C ){ delete mImageSampler_C ; mImageSampler_C =0; }
		if(mImageSampler_R1){ delete mImageSampler_R1; mImageSampler_R1=0; }
		if(mImageSampler_R2){ delete mImageSampler_R2; mImageSampler_R2=0; }
		if(mCompProg)       { delete mCompProg;  mCompProg=0;  }
		if(mCompFragS)      { delete mCompFragS; mCompFragS=0; }
		mIsInitialized = false;
		return true;
	}

	bool mergeViews(REng::MultiViewBuffer& mvb){
		if(!isSupported()) return false;
		glDisable(GL_DEPTH_TEST);
		for(REng::uint i=0; i<getViewCount(); ++i){
			REng::GPUTexture::setActiveTextureUnit(i);
			mvb.getColorTarget(i)->bindResource();
		}
		mCompProg->bindResource();
		REng::GPUDrawer::getSingleton().drawMeshGeom(mCompositorGeom);
		glEnable(GL_DEPTH_TEST);
		return true;
	}

protected:

	mutable REng::GPUProgram *mCompProg;
	mutable REng::GPUShader  *mCompFragS;
	mutable REng::RenderProp_Uniform *mImageSampler_L2;
	mutable REng::RenderProp_Uniform *mImageSampler_L1;
	mutable REng::RenderProp_Uniform *mImageSampler_C;
	mutable REng::RenderProp_Uniform *mImageSampler_R1;
	mutable REng::RenderProp_Uniform *mImageSampler_R2;

	bool updateCompProg() const{
		Logger logger = Logger::getInstance("RSys");
		if(!mCompProg){
			mCompProg = new REng::GPUProgram();
			REng::GPUShader vertShader(REng::ShaderType_Vertex); // creates OpenGL object
			const char *vertShaderText[] = {
				" #ifdef GL_ES\n",
				"   precision highp float;\n",
				" #endif\n",
				" attribute vec2 vertexIn;\n",
				" attribute vec2 texCoordIn;\n",
				" varying   vec2 textureCoord;\n",
				" void main() {\n",
				"   textureCoord = texCoordIn;\n",
				"   gl_Position = vec4(vertexIn.xy,0.0,1.0);\n",
				" }"
			};
			if(!vertShader.compileFromText( 10, vertShaderText)){
				LOG4CPLUS_WARN(logger, "MultiViewCompositor Lenticular vertex shader could not be compiled.");
				return false;
			}
			mCompProg->attachShader(vertShader);
			mCompProg->bindAttribLocation(0,"vertexIn");
			mCompProg->bindAttribLocation(1,"texCoordIn");
		}

		//////////////////////////////////////////////////////////////////////////
		// CREATE FRAGMENT SHADER
		if(mCompFragS!=0) { mCompProg->detachShader(*mCompFragS); delete mCompFragS; }
		mCompFragS = new REng::GPUShader(REng::ShaderType_Fragment); // creates OpenGL object
		const char* fragShaderText[] = {
			"uniform sampler2D view0;\n"
			"uniform sampler2D view1;\n"
			"uniform sampler2D view2;\n"
			"uniform sampler2D view3;\n"
			"uniform sampler2D view4;\n"
			"varying vec2 textureCoord;\n"
			"const int viewCount = 5;         // total number of views\n"
			"const float subPixPerLens = 4.5; // subpixels per lens (horizontally)\n"
			"const float tan_slant = 5.0/3.0; // tangent of slant angle (alpha)\n"
			"const float viewOffset = -3.0;   // WTF?\n"
			"void main() {\n"
			"	// Which view to sample R-G-B values, possible values range from 0 to viewCount-1\n"
			"	int viewSamples[3];\n"
			"	// the row of the processed fragment affects the sampling pattern\n"
			"	int row = (int)gl_FragCoord.y;\n"
			"	int columnBase = (int)(gl_FragCoord.x*3);\n"
			"	float povMultiplier=viewCount/subPixPerLens;\n"
			"	float viewOffset_All = viewOffset - 3*row*tan_slant;\n"
			"	// for each color sample, decide which view to sample\n"
			"	for(int h = 0; h<3; ++h) {\n"
			"		float pov = mod( (columnBase+h) + viewOffset_All, subPixPerLens) * povMultiplier;\n"
			"		int ipov = clamp( (int)(pov)+1, 0 ,viewCount-1);\n"
			"		// do we need further offset applied? ... nope, I assume\n"
			"		viewSamples[h] = ipov;\n"
			"	}\n"
			"	// sample all the information in each view (will not use all the samples, but anyway...)\n"
			"	// NOTE: Use nearest sampling\n"
			"	vec4 color0 = texture(view0, textureCoord);\n"
			"	vec4 color1 = texture(view1, textureCoord);\n"
			"	vec4 color2 = texture(view2, textureCoord);\n"
			"	vec4 color3 = texture(view3, textureCoord);\n"
			"	vec4 color4 = texture(view4, textureCoord);\n"
			"	\n"
			"	//red channel\n"
			"	     if(viewSamples[0]==0) gl_FragColor.r = color0.r;\n"
			"	else if(viewSamples[0]==1) gl_FragColor.r = color1.r;\n"
			"	else if(viewSamples[0]==2) gl_FragColor.r = color2.r;\n"
			"	else if(viewSamples[0]==3) gl_FragColor.r = color3.r;\n"
			"	else gl_FragColor.r = color4.r;\n"
			"	\n"
			"	//green channel\n"
			"	     if(viewSamples[1]==0) gl_FragColor.g = color0.g;\n"
			"	else if(viewSamples[1]==1) gl_FragColor.g = color1.g;\n"
			"	else if(viewSamples[1]==2) gl_FragColor.g = color2.g;\n"
			"	else if(viewSamples[1]==3) gl_FragColor.g = color3.g;\n"
			"	else gl_FragColor.g = color4.g;\n"
			"	\n"
			"	//blue channel\n"
			"	     if(viewSamples[2]==0) gl_FragColor.b = color0.b;\n"
			"	else if(viewSamples[2]==1) gl_FragColor.b = color1.b;\n"
			"	else if(viewSamples[2]==2) gl_FragColor.b = color2.b;\n"
			"	else if(viewSamples[2]==3) gl_FragColor.b = color3.b;\n"
			"	else gl_FragColor.b = color4.b;\n"
			"}"
		};
		if( !mCompFragS->compileFromText( sizeof(fragShaderText)/4, fragShaderText) ){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Lenticular fragment shader could not be compiled.");
			return false;
		}

		//////////////////////////////////////////////////////////////////////////
		// CREATE HW PROGRAM
		mCompProg->attachShader(*mCompFragS);
		if(!mCompProg->link()){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Lenticular GPU program could not be linked.");
			return false;
		}
		mCompProg->bindResource();

		//////////////////////////////////////////////////////////////////////////
		// RETRIEVE UNIFORM BINDINGS
		const char* samplerNames[] = {"view0","view1","view2","view3","view4"};
		REng::RenderProp_Uniform* uniforms[] = {mImageSampler_L2,mImageSampler_L1,mImageSampler_C,
			mImageSampler_R1,mImageSampler_R2};
		for(int i=0; i<5; ++i){
			if(uniforms[i]) delete uniforms[i];
			uniforms[i] = new REng::RenderProp_Uniform(samplerNames[i],REng::UniformType_Int_1);
			uniforms[i]->setDataAtIndex(0,i);
			uniforms[i]->bindToProgram(*mCompProg);
			uniforms[i]->activate();
		}
		return true;
	}

	REng::MeshGeom mCompositorGeom;
	void initCompositorGeom(){
		size_t numVertices = 4;

		mCompositorGeom.mIndexDataPtr.reset(new REng::IndexData());
		mCompositorGeom.mIndexDataPtr->primType = REng::PrimitiveType_TriangleStrip;
		mCompositorGeom.mIndexDataPtr->mRange.set(0,numVertices);

		mCompositorGeom.mVertexDataPtr.reset(new REng::VertexData());
		mCompositorGeom.mVertexDataPtr->mRange.set(0,numVertices);
		REng::VertexAttribute attribVertex  (0,0,REng::VertexAttribDataType_Byte,REng::VertexAttribDataCount2,"vertexIn");
		REng::VertexAttribute attribTexCoord(0,attribVertex.getSizeInBytes(),REng::VertexAttribDataType_Byte,REng::VertexAttribDataCount2,"texCoordIn");
		mCompositorGeom.mVertexDataPtr->insertAttribute(attribVertex);
		mCompositorGeom.mVertexDataPtr->insertAttribute(attribTexCoord);

		REng::GPUVertexBufferPtr bufPtr( new REng::GPUVertexBuffer(
			mCompositorGeom.mVertexDataPtr->getVertexSize(0), numVertices, 
			REng::BufferUsageFreq_Static,REng::BufferUsageNature_Draw) );
		mCompositorGeom.mVertexDataPtr->linkBufferToIndex(0,bufPtr);
		GLbyte geometryArray[4*4];
		int t=0;
		// vertex coordinates                         // texture coordinates
		geometryArray[t++] = -1; geometryArray[t++] = -1; geometryArray[t++] = 0; geometryArray[t++] = 0;
		geometryArray[t++] =  1; geometryArray[t++] = -1; geometryArray[t++] = 1; geometryArray[t++] = 0;
		geometryArray[t++] = -1; geometryArray[t++] =  1; geometryArray[t++] = 0; geometryArray[t++] = 1;
		geometryArray[t++] =  1; geometryArray[t++] =  1; geometryArray[t++] = 1; geometryArray[t++] = 1;
		bufPtr->writeData(geometryArray);
	}
};
