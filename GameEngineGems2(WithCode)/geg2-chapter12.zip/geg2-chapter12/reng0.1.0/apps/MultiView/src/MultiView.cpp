#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// MULTI-VIEW

// Tests a single stereo multi view using a single mesh
// Allows camera stereo parameter modifications
// Author: Adil Yalcin

#define WINDOW_WIDTH 1000
#define WINDOW_HEIGHT 700

#include "MV_Lenticular.cpp"
// out-of-reng source actually
#include "REng/MVC_Parallax.h"
#include "REng/MVC_Anaglyph.h"
#include "REng/MultiViewBuffer.h"
#include "REng/MultiViewCompositor.h"

#undef USE_PARALLAX 

MeshPtr torusMesh;
CameraStereoView* mCamera_2;
CameraFiveView*  mCamera_5;
const MVC_Parallax *myMVC;

enum MVConfig{
	MVConfig_Disabled,
	MVConfig_Anaglyph_ColorMode,
	MVConfig_Anaglyph_Sampling,
	MVConfig_Parallax_Stencil,
	MVConfig_Parallax_Offtarget,
	MVConfig_Lenticular,
	MVConfig_SideBySide
};

class RenderQueue_Transparent : public RenderQueue_Vector {
public:
	RenderQueue_Transparent::RenderQueue_Transparent(){ ; }
	void preRenderQueueProcess() { glDepthMask(GL_FALSE); }
	void postRenderQueueProcess(){ glDepthMask(GL_TRUE);  }
};

class MultiViewApp : public Application_Base {
public:
	MeshPtr mMeshSphere;
	MeshPtr mMeshTorus;
	MeshPtr mMeshBox;
	MeshPtr mMeshChair;
	MeshPtr mMeshBunny;
	MeshPtr mMeshFocus;
	MeshPtr mMeshDoll;

	MeshNode* mNodeCorridorGround;
	MeshNode* mNodeCorridorCeil1;
	MeshNode* mNodeCorridorCeil2;
	MeshNode* mNodeCorridorLeft;
	MeshNode* mNodeCorridorRight;
	MeshNode* mNodeCorridorBack;

	MeshNode* mNodeSphere;
	MeshNode* mNodeTorus;
	MeshNode* mNodeBox;
	MeshNode* mNodeChair;
	MeshNode* mNodeChair2;
	MeshNode* mNodeBunny;
	MeshNode* mNodeDoll;
	MeshNode* mNodeFocus;
	GroupNode* mNodeLamp1;
	GroupNode* mNodeLamp2;
	LightNode* mNodeLight1;
	LightNode* mNodeLight2;
	GroupNode* mCameraNode; // holds two nodes, which hold 2-view and 5-view cameras 

	enum Corridor{
		Corridor_All,
		Corridor_Sphere,
		Corridor_Torus,
		Corridor_Box,
		Corridor_Chair,
		Corridor_Chair2,
		Corridor_Bunny,
		Corridor_Doll
	};

	MVC_Anaglyph* mvcAnaglyph_Sampling;
	MVC_Anaglyph_OnTarget* mvcAnaglyph_ColorMode;
	MVC_Parallax* mvcParallax;
	MVC_Parallax_Stencil* mvcParallax_Stencil;
	MVC_Lenticular* mvcLenticular;
	MultiViewBuffer* myMVB;

	MultiViewApp() {}
	~MultiViewApp() {}

	void setMeshPtrs(){
		MeshManager& MM(MeshManager::getSingleton());
		mMeshFocus = MM.createMesh("DemoScene/Focus");
		mMeshFocus->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane());
		mMeshFocus->mMaterial = MaterialManager::getSingleton().getMaterial("FocalPlane");
		mMeshSphere = MM.createMesh("DemoScene/Sphere");
		mMeshSphere->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(2));
		mMeshSphere->mMaterial = MaterialManager::getSingleton().getMaterial("SphereMaterial");
		mMeshTorus = MM.createMesh("DemoScene/Torus");
		mMeshTorus->createLoDGeom(MeshGeomGenerator::getSingleton().getTorus(1,20,0.4,20));
		mMeshTorus->mMaterial = MaterialManager::getSingleton().getMaterial("BrickMaterial");
		mMeshBox = MM.createMesh("DemoScene/Box");
		mMeshBox->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB());
		mMeshBox->mMaterial = MaterialManager::getSingleton().getMaterial("CrateMaterial");

		MM.mTmpBoundBoxType = GeomTypeOBox;
		MM.mGenerateTangent = true;
		MM.mGenerateBitangent = true;
		MM.loadFromFile("mesh/chair1.obj");
		MM.loadFromFile("mesh/bunny_res3.obj");
		MM.loadFromFile("mesh/bunny_res4.obj");
		MM.loadFromFile("mesh/wooddoll_00.obj");
		MM.loadFromFile("mesh/lamp.obj");

		mMeshChair = MM.getMeshByName("chair1_0");
		mMeshChair->mMaterial = MaterialManager::getSingleton().getMaterial("ChairMaterial");
		mMeshBunny = MM.getMeshByName("bunny_res3_0");
		mMeshBunny->mMaterial = MaterialManager::getSingleton().getMaterial("ChairMaterial");
		mMeshDoll= MM.getMeshByName("wooddoll_00_0");
		mMeshDoll->mMaterial = MaterialManager::getSingleton().getMaterial("ChairMaterial");

		MM.getMeshByName("lamp_0")->mMaterial = MaterialManager::getSingleton().getMaterial("lamp_base");
		MM.getMeshByName("lamp_1")->mMaterial = MaterialManager::getSingleton().getMaterial("lamp_base");
		MM.getMeshByName("lamp_2")->mMaterial = MaterialManager::getSingleton().getMaterial("lamp_base");
		MM.getMeshByName("lamp_3")->mMaterial = MaterialManager::getSingleton().getMaterial("lamp");
		MM.getMeshByName("lamp_4")->mMaterial = MaterialManager::getSingleton().getMaterial("lamp_base");
	}
	void setLights(){
		mNodeLight1 = &(LightNode::create(RootNode::getSingleton()));
		mNodeLight2 = &(LightNode::create(RootNode::getSingleton()));
		mNodeLight1->translate_World(Vector3(40,40,0));
		mNodeLight2->translate_World(Vector3(-40,40,90));
		Light_Point& lamp1(Light_Point::create(*mNodeLight1));
		Light_Point& lamp2(Light_Point::create(*mNodeLight2));
		lamp2.setColor(Color_Real(0.9f,0.8f,0.9f));
		lamp1.setColor(Color_Real(0.7f,0.8f,1.0f));
	}
	void setLightLid(int lightID){
		// unlit all lights
		mNodeLight1->getLight()->setLit(false);
		mNodeLight2->getLight()->setLit(false);
		mNodeLamp1->mCullingMode = SceneNode::CULL_NEVER;//CULL_ALWAYS;
		mNodeLamp2->mCullingMode = SceneNode::CULL_NEVER;//CULL_ALWAYS;
		if(lightID==0){
			mNodeLight1->getLight()->setLit(true);
		} else if(lightID==1){
			mNodeLight2->getLight()->setLit(true);
		}
	}
	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		int contextParams[] = {
			GLCntxtParStencilRes,   8, // one of the compositors use stencil buffers on default frame buffer
//			GLCntxtParProfile, GLContextProfile_Core,
//			GLCntxtParGLVersionMaj, 3,
//			GLCntxtParGLVersionMin, 2,
//			GLCntxtParVSynch,       GLCntxtParTrue,
			GLCntxtParNull
		};
		RSys.createWindowAndGLContext(RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),contextParams,inputStartup);
		if(!RSys.initSystem()) return false;

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/model.material");
		MaterialScriptParser::getSingleton().parseFile("materials/mv.material");
		// create and initialize material resources
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		setMeshPtrs();
		setLights();

		torusMesh = MeshManager::getSingleton().getMeshByName("Torus Knot");

		GroupNode& triadNode(MeshGeomGenerator::getSingleton().createTriad_Arrow(RootNode::getSingleton()));
//		triadNode.scale_Parent(1);
//		triadNode.mCullingMode = SceneNode::CULL_NEVER;

		// CORRIDOR
		MeshPtr corridorFloor = MeshManager::getSingleton().createMesh("corridorFloor");
		MeshPtr corridorWall  = MeshManager::getSingleton().createMesh("corridorWall");
		MeshPtr corridorCeil  = MeshManager::getSingleton().createMesh("corridorCeil");
		corridorFloor->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane());
		corridorWall ->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane());
		corridorCeil ->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane());
		corridorFloor->mMaterial = MaterialManager::getSingleton().getMaterial("floor");
		corridorWall ->mMaterial = MaterialManager::getSingleton().getMaterial("wall");
		corridorCeil ->mMaterial = MaterialManager::getSingleton().getMaterial("ceiling");

		mNodeCorridorGround = &(MeshNode::create(RootNode::getSingleton()));
		mNodeCorridorGround->translate_World(Vector3(0,-30,0));
		mNodeCorridorGround->scale_Parent(Vector3(50,400,1));
		Quaternion corridorGroundRotate;// x-y mesh to x-z mesh
		cml::quaternion_rotation_world_x(corridorGroundRotate,AngleDegree(-90).getRadian());
		mNodeCorridorGround->rotate_World(corridorGroundRotate);
		mNodeCorridorGround->setMesh(corridorFloor);
		mNodeCorridorCeil1 = &(MeshNode::create(RootNode::getSingleton()));
		mNodeCorridorCeil1->translate_World(Vector3(-5,70,0));
		mNodeCorridorCeil1->scale_Parent(Vector3(50,400,1));
		Quaternion corridorCeilRotate;// x-y mesh to x-z mesh
		cml::quaternion_rotation_world_x(corridorCeilRotate,AngleDegree(+90).getRadian());
		mNodeCorridorCeil1->rotate_World(corridorCeilRotate);
		cml::quaternion_rotation_world_z(corridorCeilRotate,AngleDegree(+20).getRadian());
		mNodeCorridorCeil1->rotate_World(corridorCeilRotate);
		mNodeCorridorCeil1->setMesh(corridorCeil);
		mNodeCorridorCeil2 = &(MeshNode::create(RootNode::getSingleton()));
		mNodeCorridorCeil2->translate_World(Vector3(5,70,0));
		mNodeCorridorCeil2->scale_Parent(Vector3(50,400,1));
		cml::quaternion_rotation_world_x(corridorCeilRotate,AngleDegree(+90).getRadian());
		mNodeCorridorCeil2->rotate_World(corridorCeilRotate);
		cml::quaternion_rotation_world_z(corridorCeilRotate,AngleDegree(-20).getRadian());
		mNodeCorridorCeil2->rotate_World(corridorCeilRotate);
		mNodeCorridorCeil2->setMesh(corridorCeil);
		mNodeCorridorLeft = &(MeshNode::create(RootNode::getSingleton()));
		Quaternion corridorLeftRotate;// x-y mesh to x-z mesh
		cml::quaternion_rotation_world_y(corridorLeftRotate,AngleDegree(90).getRadian());
		mNodeCorridorLeft->rotate_World(corridorLeftRotate);
		mNodeCorridorLeft->translate_World(Vector3(-50,15,0));
		mNodeCorridorLeft->scale_Parent(Vector3(400,50,1));
		mNodeCorridorLeft->setMesh(corridorWall);
		mNodeCorridorRight = &(MeshNode::create(RootNode::getSingleton()));
		mNodeCorridorRight->translate_World(Vector3(50,15,0));
		mNodeCorridorRight->scale_Parent(Vector3(400,50,1));
		Quaternion corridorRightRotate;// x-y mesh to x-z mesh
		cml::quaternion_rotation_world_y(corridorRightRotate,AngleDegree(-90).getRadian());
		mNodeCorridorRight->rotate_World(corridorRightRotate);
		mNodeCorridorRight->setMesh(corridorWall);
		mNodeCorridorBack = &(MeshNode::create(RootNode::getSingleton()));
		mNodeCorridorBack->translate_World(Vector3(0,0,-400));
		mNodeCorridorBack->scale_Parent(Vector3(200,200,1)); // a bit large, for better texture scaling
		mNodeCorridorBack->setMesh(corridorWall);

		mNodeBox = &(MeshNode::create(RootNode::getSingleton()));
		mNodeBox->setMesh(mMeshBox);
		mNodeBox->scale_Parent(10);
		mNodeTorus = &(MeshNode::create(RootNode::getSingleton()));
		mNodeTorus->setMesh(mMeshTorus);
		mNodeTorus->scale_Parent(13);
		mNodeTorus->rotate_World(corridorGroundRotate);
		mNodeChair = &(MeshNode::create(RootNode::getSingleton()));
		mNodeChair->setMesh(mMeshChair);
		mNodeChair->scale_Parent(6.5);
		mNodeSphere = &(MeshNode::create(RootNode::getSingleton()));
		mNodeSphere->setMesh(mMeshSphere);
		mNodeSphere->scale_Parent(7);
		mNodeBunny= &(MeshNode::create(RootNode::getSingleton()));
		mNodeBunny->setMesh(mMeshBunny);
		mNodeBunny->scale_Parent(8);
		mNodeDoll= &(MeshNode::create(RootNode::getSingleton()));
		mNodeDoll->setMesh(mMeshDoll);
		mNodeDoll->scale_Parent(1.2);
		mNodeChair2 = &(MeshNode::create(RootNode::getSingleton()));
		mNodeChair2->setMesh(mMeshChair);
		mNodeChair2->scale_Parent(3);
		mNodeFocus = &(MeshNode::create(RootNode::getSingleton()));
		mNodeFocus->setMesh(mMeshFocus);
		mNodeFocus->scale_Parent(250);
		RenderQueueMap::getSingleton().registerRenderQueue(new RenderQueue_Transparent(),55);
		mNodeFocus->setRenderQueueGroupID(55);
		mNodeFocus->mCullingMode = SceneNode::CULL_ALWAYS;
		mNodeLamp1 = &(GroupNode::create(RootNode::getSingleton()));
		mNodeLamp1->scale_Parent(10);
		mNodeLamp1->translate_World(Vector3(47,40,0));
		mNodeLamp1->rotate_World(corridorRightRotate);
		MeshNode::create(*mNodeLamp1).setMesh(MeshManager::getSingleton().getMeshByName("lamp_0"));
		MeshNode::create(*mNodeLamp1).setMesh(MeshManager::getSingleton().getMeshByName("lamp_1"));
		MeshNode::create(*mNodeLamp1).setMesh(MeshManager::getSingleton().getMeshByName("lamp_2"));
		MeshNode::create(*mNodeLamp1).setMesh(MeshManager::getSingleton().getMeshByName("lamp_4"));
		MeshNode* lampOut1(&MeshNode::create(*mNodeLamp1));
		lampOut1->setMesh(MeshManager::getSingleton().getMeshByName("lamp_3"));
		lampOut1->setRenderQueueGroupID(55);
		mNodeLamp2 = &(GroupNode::create(RootNode::getSingleton()));
		mNodeLamp2->scale_Parent(10);
		mNodeLamp2->translate_World(Vector3(-47,40,90));
		mNodeLamp2->rotate_World(corridorRightRotate.inverse());
		MeshNode::create(*mNodeLamp2).setMesh(MeshManager::getSingleton().getMeshByName("lamp_0"));
		MeshNode::create(*mNodeLamp2).setMesh(MeshManager::getSingleton().getMeshByName("lamp_1"));
		MeshNode::create(*mNodeLamp2).setMesh(MeshManager::getSingleton().getMeshByName("lamp_2"));
		MeshNode::create(*mNodeLamp2).setMesh(MeshManager::getSingleton().getMeshByName("lamp_4"));
		MeshNode* lampOut2(&MeshNode::create(*mNodeLamp2));
		lampOut2->setMesh(MeshManager::getSingleton().getMeshByName("lamp_3"));
		lampOut2->setRenderQueueGroupID(55);

		setCorridor(Corridor_All);

		// *********************
		// CAMERA SETUP
		mCameraNode = &(GroupNode::create(RootNode::getSingleton()));
		CameraNode& camNode_2(CameraNode::create(*mCameraNode));
		CameraNode& camNode_5(CameraNode::create(*mCameraNode));
		mCameraNode->translate_World(Vector3(0.0f,10.0f,250.0f));
		mCamera_2 = &(CameraStereoView::create(camNode_2));
		mCamera_2->setAspectRatio(float(WINDOW_WIDTH)/WINDOW_HEIGHT);
		mCamera_2->setFarDistance(1500.0f);
		mCamera_2->setNearDistance(1.0f);
		mCamera_2->setFieldOfView_y(AngleDegree(45.0f));
		mCamera_2->setEyeSeparation(1.0);
		mCamera_2->setFocalDistance(100.0);

		mCamera_5 = &(CameraFiveView::create(camNode_2));
		mCamera_5->setAspectRatio(float(WINDOW_WIDTH)/WINDOW_HEIGHT);
		mCamera_5->setFarDistance(1500.0f);
		mCamera_5->setNearDistance(1.0f);
		mCamera_5->setFieldOfView_y(AngleDegree(45.0f));
		mCamera_5->setEyeSeparation(1.0);
		mCamera_5->setFocalDistance(100.0);

		Viewport* vp = RSys.getViewport(0);
		vp->mCamera = mCamera_2;
		vp->mDisableMultiView = false;
		vp->disableRenderQueue(REnderQueueID_GUI);

		mvcAnaglyph_Sampling = new MVC_Anaglyph;
		mvcAnaglyph_ColorMode = new MVC_Anaglyph_OnTarget;
		mvcParallax = new MVC_Parallax;
		mvcParallax_Stencil = new MVC_Parallax_Stencil;
		mvcLenticular = new MVC_Lenticular;
		myMVB=0;

		setLightLid(1);
		setMVConfig(MVConfig_Disabled);

		initGUI();
		return true;
	}
	bool preRender(float timeLapse){
		// rotate the mesh node
		cml::quaternionf_n rotator,rotator2;
		cml::quaternion_rotation_world_y(rotator,timeLapse*0.3f);
		cml::quaternion_rotation_world_y(rotator2,timeLapse*0.1f);
		mNodeSphere->rotate_Parent(rotator);
		mNodeBox->rotate_Parent(rotator2);
		// update focus plane's spatial info
		Vector3 pos(mCamera_2->getNode().getTranslation_World());
		Quaternion orient(mCamera_2->getNode().getRotation_World());
		Vector3 dir(mCamera_2->getNode().getDirection());
		float focalDist = mCamera_2->getFocalDistance();
		pos += dir*focalDist;
		mNodeFocus->translate_World(pos,true);
		mNodeFocus->rotate_World(orient,true);
		return true;
	}
	void setMVConfig(MVConfig cfg){
		Viewport* vp = RenderSystem::getSingleton().getViewport(0);
		MVBuffer_Cfg mvbParams;
		mvbParams.viewCount = 2;
		vp->mDisableMultiView=false; // default
		switch(cfg){
			case MVConfig_Disabled:
				vp->mCamera = mCamera_2;
				vp->mDisableMultiView=true;
				break;
			case MVConfig_Anaglyph_ColorMode: {
				vp->mCamera = mCamera_2;
				mvbParams.type = MVBufferType_Ontarget;
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->attachMVCompositor(mvcAnaglyph_ColorMode);
				mvcAnaglyph_ColorMode->setType(Anaglyh_R_GB);
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
			case MVConfig_Anaglyph_Sampling: {
				vp->mCamera = mCamera_2;
				mvbParams.type = MVBufferType_Offtarget;
				mvbParams.offtarget.stencilFormat = ImageFormat_None;
				mvbParams.offtarget.sharedDepthStencilTargets = true;
				mvbParams.offtarget.sharedFrameBuffer         = true;
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->attachMVCompositor(mvcAnaglyph_Sampling);
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
			case MVConfig_Parallax_Stencil: {
				vp->mCamera = mCamera_2;
				mvbParams.type = MVBufferType_Ontarget;
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->attachMVCompositor(mvcParallax_Stencil);
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
			case MVConfig_Parallax_Offtarget: {
				vp->mCamera = mCamera_2;
				mvbParams.type = MVBufferType_Offtarget;
				mvbParams.offtarget.stencilFormat = ImageFormat_None; // no need for stencil support
				mvbParams.offtarget.sharedDepthStencilTargets = true;
				mvbParams.offtarget.sharedFrameBuffer         = true;
				mvbParams.offtarget.halfResWidth              = true;
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->attachMVCompositor(mvcParallax);
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
			case MVConfig_Lenticular: {
				vp->mCamera = mCamera_5;
				mvbParams.viewCount = 5;
				mvbParams.type = MVBufferType_Offtarget;
				mvbParams.offtarget.stencilFormat = ImageFormat_None; // no need for stencil support
				mvbParams.offtarget.sharedDepthStencilTargets = true;
				mvbParams.offtarget.sharedFrameBuffer         = true;
				mvbParams.offtarget.halfResWidth              = false;
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->attachMVCompositor(mvcLenticular);
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
			case MVConfig_SideBySide: {
				vp->mCamera = mCamera_2;
				mvbParams.type = MVBufferType_Ontarget;
				mvbParams.ontarget.viewRects.push_back(RectF(0.00,0.495,0.0,1.0));
				mvbParams.ontarget.viewRects.push_back(RectF(0.505,1.00,0.0,1.0));
				MultiViewBuffer* asdsa(new MultiViewBuffer);
				vp->detachMVCompositor();
				vp->attachMVBuffer(asdsa,mvbParams);
//				if(myMVB) myMVB->clear();
				myMVB = asdsa;
				} break;
		}
	}
	bool setFocalPlaneDisplay(bool flag){
		if(mCamera_2->getStereoType()==CameraStereoView::TypeParallel) return false;
		if(flag) mNodeFocus->mCullingMode = SceneNode::CULL_NEVER;
		else     mNodeFocus->mCullingMode = SceneNode::CULL_ALWAYS;
		return true;
	}
	void setCorridor(Corridor type){
		if(type==Corridor_All){
			mNodeSphere->mCullingMode = SceneNode::CULL_DYNAMIC;
			mNodeTorus->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeBox->mCullingMode    = SceneNode::CULL_DYNAMIC;
			mNodeChair->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeChair2->mCullingMode = SceneNode::CULL_DYNAMIC;
			mNodeBunny->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeDoll->mCullingMode   = SceneNode::CULL_DYNAMIC;
			mNodeBox->translate_World(Vector3(-10,-20,-100),true);
			mNodeTorus->translate_World(Vector3(20,25,-150),true);
			mNodeChair->translate_World(Vector3(10,-19,-250),true);
			mNodeSphere->translate_World(Vector3(-13,-23,50),true);
			mNodeBunny->translate_World(Vector3(23,-18,-5),true);
			mNodeDoll->translate_World(Vector3(-32,-28,35),true);
			mNodeChair2->translate_World(Vector3(6,-25,105),true);
			return;
		}
		// hide all
		mNodeSphere->mCullingMode = SceneNode::CULL_ALWAYS;
		mNodeTorus->mCullingMode  = SceneNode::CULL_ALWAYS;
		mNodeBox->mCullingMode    = SceneNode::CULL_ALWAYS;
		mNodeChair->mCullingMode  = SceneNode::CULL_ALWAYS;
		mNodeChair2->mCullingMode = SceneNode::CULL_ALWAYS;
		mNodeBunny->mCullingMode  = SceneNode::CULL_ALWAYS;
		mNodeDoll->mCullingMode   = SceneNode::CULL_ALWAYS;
		Vector3 origin(0,10,-20);
		if(type==Corridor_Sphere){
			mNodeSphere->mCullingMode = SceneNode::CULL_DYNAMIC;
			mNodeSphere->translate_World(origin,true);
		} else if(type==Corridor_Torus){
			mNodeTorus->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeTorus->translate_World(origin,true);
		} else if(type==Corridor_Box){
			mNodeBox->mCullingMode    = SceneNode::CULL_DYNAMIC;
			mNodeBox->translate_World(origin,true);
		} else if(type==Corridor_Chair){
			mNodeChair->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeChair->translate_World(origin,true);
		} else if(type==Corridor_Chair2){
			mNodeChair2->mCullingMode = SceneNode::CULL_DYNAMIC;
			mNodeChair2->translate_World(origin,true);
		} else if(type==Corridor_Bunny){
			mNodeBunny->mCullingMode  = SceneNode::CULL_DYNAMIC;
			mNodeBunny->translate_World(origin,true);
		} else if(type==Corridor_Doll){
			mNodeDoll->mCullingMode   = SceneNode::CULL_DYNAMIC;
			mNodeDoll->translate_World(origin,true);
		}
	}
	void showWallsAndLamps(bool flag){
		SceneNode::CullingMode cm;
		if(flag==false) cm = SceneNode::CULL_ALWAYS;
		if(flag==true)  cm = SceneNode::CULL_NEVER;
		mNodeCorridorGround->mCullingMode = cm;
		mNodeCorridorCeil1->mCullingMode = cm;
		mNodeCorridorCeil2->mCullingMode = cm;
		mNodeCorridorLeft->mCullingMode = cm;
		mNodeCorridorRight->mCullingMode = cm;
		mNodeCorridorBack->mCullingMode = cm;
		mNodeLamp1->mCullingMode = cm;
		mNodeLamp2->mCullingMode = cm;
	}
	bool getFocalPlaneDisplay(){
		return (mNodeFocus->mCullingMode==SceneNode::CULL_NEVER);
	}
	bool keyPressed(const OIS::KeyEvent &arg){
		Application_Base::keyPressed(arg);
		switch(arg.key){
			case OIS::KC_Z:
				mCamera_2->setStereoType(CameraStereoView::TypeParallel); break;
				break;
			case OIS::KC_X:
				mCamera_2->setStereoType(CameraStereoView::TypeSkewed); break;
				break;
			case OIS::KC_C:
				mCamera_2->setStereoType(CameraStereoView::TypeOriented); break;
				break;
			case OIS::KC_Q:
				{
					bool m=getFocalPlaneDisplay();
					setFocalPlaneDisplay(!m);
				}
				break;
			case OIS::KC_U:
				setMVConfig(MVConfig_Disabled); break;
			case OIS::KC_I:
				setMVConfig(MVConfig_Anaglyph_ColorMode); break;
			case OIS::KC_O:
				setMVConfig(MVConfig_Anaglyph_Sampling); break;
			case OIS::KC_P:
				setMVConfig(MVConfig_Lenticular); break;
			case OIS::KC_J:
				setMVConfig(MVConfig_Parallax_Stencil); break;
			case OIS::KC_K:
				setMVConfig(MVConfig_Parallax_Offtarget); break;
			case OIS::KC_L:
				setMVConfig(MVConfig_SideBySide); break;
			case OIS::KC_B:
				mvcAnaglyph_ColorMode->setType(Anaglyh_R_GB);
				mvcAnaglyph_Sampling ->setType(Anaglyh_R_GB);
				break;
			case OIS::KC_N:
				mvcAnaglyph_ColorMode->setType(Anaglyh_Mono_R_B);
				mvcAnaglyph_Sampling ->setType(Anaglyh_Mono_R_B);
				break;
			case OIS::KC_M:
				mvcAnaglyph_ColorMode->setType(Anaglyh_Mono_R_G);
				mvcAnaglyph_Sampling ->setType(Anaglyh_Mono_R_G);
				break;
			case OIS::KC_H:
				mvcParallax->setViewAxisTransposed(!mvcParallax->isViewAxisTransposed());
				mvcParallax_Stencil->setViewAxisTransposed(!mvcParallax_Stencil->isViewAxisTransposed());
				break;
			case OIS::KC_SPACE:
				showWallsAndLamps(mNodeLamp1->mCullingMode!=SceneNode::CULL_NEVER);
				break;
			case OIS::KC_0:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_All); }
				break;
			case OIS::KC_1:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Sphere); }
				break;
			case OIS::KC_2:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Doll); }
				break;
			case OIS::KC_3:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Bunny); }
				break;
			case OIS::KC_4:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Torus); }
				break;
			case OIS::KC_5:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Chair); }
				break;
			case OIS::KC_6:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Chair2); }
				break;
			case OIS::KC_7:
				if(mKeyboard->isModifierDown(OIS::Keyboard::Shift)){ setCorridor(Corridor_Box); }
				break;
			case OIS::KC_T:
				setLightLid(0); break;
			case OIS::KC_Y:
				setLightLid(1); break;
#ifdef RENG_SAMPLE_USECEGUI
			case OIS::KC_F1: {
				CEGUI::Window* textBox = CEGUI::WindowManager::getSingleton().getWindow("HelpText");
				if(!textBox->isVisible())
					textBox->show();
				else
					textBox->hide();
				} break;
			case OIS::KC_F2: {
				CEGUI::Window* root = CEGUI::WindowManager::getSingleton().getWindow("Root");
				if(!root->isVisible())
					root->show();
				else
					root->hide();
				} break;
#endif // RENG_SAMPLE_USECEGUI
			default: 
				break;
		}
		return true;
	}
	void handleNonBufferedKeys() {
		float elapsedTime = mTimer.getElapsedTime(false,0);
		float displacement = elapsedTime*90;
		if(mKeyboard->isKeyDown(OIS::KC_UP)){
			float z=(mCamera_2->getPosition()[2]) - displacement;
			z = Math::clamp(z,-300.0f,400.0f);
			mCamera_2->getNode().getParent()->translate_World(Vector3(0,10.0f,z),true);
		}
		if(mKeyboard->isKeyDown(OIS::KC_DOWN)){
			float z=(mCamera_2->getPosition()[2]) + displacement;
			z = Math::clamp(z,-300.0f,400.0f);
			mCamera_2->getNode().getParent()->translate_World(Vector3(0,10.0f,z),true);
		}
		Quaternion r1,r2;
		cml::quaternion_rotation_world_y(r1,AngleDegree(-0.1).getRadian()*elapsedTime);
		cml::quaternion_rotation_world_y(r2,AngleDegree(+0.1).getRadian()*elapsedTime);
		if(mKeyboard->isKeyDown(OIS::KC_LEFT))
//			mCamera_2->getNode().translate_World(Vector3(-0.2,0,0));
			mCamera_2->getNode().getParent()->rotate_World(r2);
		if(mKeyboard->isKeyDown(OIS::KC_RIGHT))
//			mCamera_2->getNode().translate_World(Vector3(+0.2,0,0));
			mCamera_2->getNode().getParent()->rotate_World(r1);
		if(mKeyboard->isKeyDown(OIS::KC_D)){
			mCamera_2->setEyeSeparation(mCamera_2->getEyeSeparation()+0.1);
			mCamera_5->setEyeSeparation(mCamera_5->getEyeSeparation()+0.1);
		}
		if(mKeyboard->isKeyDown(OIS::KC_A)){
			mCamera_2->setEyeSeparation(mCamera_2->getEyeSeparation()-0.1);
			mCamera_5->setEyeSeparation(mCamera_5->getEyeSeparation()-0.1);
		}
		if(mKeyboard->isKeyDown(OIS::KC_W)){
			mCamera_2->setFocalDistance(mCamera_2->getFocalDistance()+1);
			mCamera_5->setFocalDistance(mCamera_5->getFocalDistance()+1);
		}
		if(mKeyboard->isKeyDown(OIS::KC_S)){
			mCamera_2->setFocalDistance(mCamera_2->getFocalDistance()-1);
			mCamera_5->setFocalDistance(mCamera_5->getFocalDistance()-1);
		}
	}
	void initGUI(){
#ifdef RENG_SAMPLE_USECEGUI
		Viewport *vpFull = RenderSystem::getSingleton().getViewport(0);
		Viewport *vp = new Viewport();
		vp->setAbsRect(vpFull->getAbsRect());
		vp->disableRenderQueues_LessThan(REnderQueueID_GUI);
		vp->autoClearBuffer(FrameBufferComponent_Depth,false);
		vp->autoClearBuffer(FrameBufferComponent_Stencil,false);
		//	// Note: GUi viewport should be rendered after (on top of) multi-view viewports
		RenderSystem::getSingleton().addViewport(1,vp);

		CEGUI::REngRenderer* guiRenderer(&CEGUI::REngRenderer::create(*vp));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();
		initSharedCEGUIOverlay(guiRenderer);
		CEGUI::SchemeManager::getSingleton().create("TaharezLook.scheme");

		using namespace CEGUI;

		SchemeManager::getSingleton().create("TaharezLook.scheme");
		System::getSingleton().setDefaultMouseCursor("TaharezLook", "MouseArrow");

		WindowManager& winMgr = WindowManager::getSingleton();
		DefaultWindow* root0 = (DefaultWindow*)winMgr.createWindow("DefaultWindow", "Root0");
		System::getSingleton().setGUISheet(root0);
		DefaultWindow* root = (DefaultWindow*)winMgr.createWindow("DefaultWindow", "Root");
		root0->addChildWindow(root);

		CEGUI::Font& ft(FontManager::getSingleton().createFreeTypeFont("overlayFont",15,true,"batang.ttf"));

		DefaultWindow* textBox;

		FrameWindow* camFrame;
		camFrame = (FrameWindow*)winMgr.createWindow("TaharezLook/FrameWindow","CamFrame");
		camFrame->setText("Stereo Camera Options");
		camFrame->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.73)));
		camFrame->setSize(UVector2(cegui_absdim(300), cegui_reldim(0.25)));
		camFrame->setProperty("DragMovingEnabled","False");
		root->addChildWindow(camFrame);

		Combobox* camStereoSetup;
		camStereoSetup = (Combobox*)winMgr.createWindow("TaharezLook/Combobox","CamStereoSetup");
		camStereoSetup->addItem(new ListboxTextItem("Parallel"));
		camStereoSetup->addItem(new ListboxTextItem("Oriented"));
		camStereoSetup->addItem(new ListboxTextItem("Skewed"));
		camStereoSetup->setPosition(UVector2(cegui_absdim(160), cegui_reldim(0.06)));
		camStereoSetup->setSize(UVector2(cegui_absdim(120), cegui_absdim(130)));
		camStereoSetup->setReadOnly(true);
		camStereoSetup->setText("Skewed");
		camStereoSetup->setProperty("ClippedByParent","False");
		camStereoSetup->subscribeEvent(
			Combobox::EventListSelectionAccepted, Event::Subscriber(&MultiViewApp::cbCamStereoMode,this));
		camFrame->addChildWindow(camStereoSetup);
		
		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","CamStereoSetupText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.06)));
		textBox->setSize(UVector2(cegui_absdim(140), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Camera Stereo");
		camFrame->addChildWindow(textBox);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","CamEyeSeptext");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.29)));
		textBox->setSize(UVector2(cegui_absdim(150), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Eye Separation");
		camFrame->addChildWindow(textBox);

		Spinner* camSlider;
		camSlider = (Spinner*)winMgr.createWindow("TaharezLook/Spinner","CamEyeSep");
		camSlider->setPosition(UVector2(cegui_absdim(160), cegui_reldim(0.29)));
		camSlider->setSize(UVector2(cegui_absdim(120), cegui_absdim(30)));
		camSlider->setCurrentValue(1);
		camSlider->setTextInputMode(Spinner::FloatingPoint);
		camSlider->setStepSize(0.05);
		camSlider->subscribeEvent(
			Spinner::EventValueChanged,
			Event::Subscriber(&MultiViewApp::cbCamEyeSep,this));
		camFrame->addChildWindow(camSlider);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","CamSliderText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.55)));
		textBox->setSize(UVector2(cegui_absdim(150), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Focal Distance");
		camFrame->addChildWindow(textBox);

		camSlider = (Spinner*)winMgr.createWindow("TaharezLook/Spinner","CamFocalDist");
		camSlider->setPosition(UVector2(cegui_absdim(160), cegui_reldim(0.55)));
		camSlider->setSize(UVector2(cegui_absdim(120), cegui_absdim(30)));
		camSlider->setCurrentValue(100);
		camSlider->setStepSize(2);
		camSlider->setTextInputMode(Spinner::FloatingPoint);
		camSlider->subscribeEvent(
			Spinner::EventValueChanged,
			Event::Subscriber(&MultiViewApp::cbCamFocalDist,this));
		camFrame->addChildWindow(camSlider);

		Checkbox* showFocalPlane;
		showFocalPlane = (Checkbox*)winMgr.createWindow("TaharezLook/Checkbox","ShowFocalPlane");
		showFocalPlane->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.77)));
		showFocalPlane->setSize(UVector2(cegui_absdim(250), cegui_absdim(30)));
		showFocalPlane->setFont(&ft);
		showFocalPlane->setText("Show Focal Plane?");
		showFocalPlane->subscribeEvent(
			Checkbox::EventCheckStateChanged,Event::Subscriber(&MultiViewApp::cbFocalPlane,this));
		camFrame->addChildWindow(showFocalPlane);

		//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////

		FrameWindow* mvFrame;
		mvFrame = (FrameWindow*)winMgr.createWindow("TaharezLook/FrameWindow","MVFrame");
		mvFrame->setText("MultiView Config Options");
		mvFrame->setPosition(UVector2(cegui_reldim(0.62), cegui_reldim(0.73)));
		mvFrame->setSize(UVector2(cegui_reldim(0.35), cegui_reldim(0.25)));
		mvFrame->setProperty("DragMovingEnabled","False");
		root->addChildWindow(mvFrame);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","MVTypeText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.05)));
		textBox->setSize(UVector2(cegui_absdim(80), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Type:");
		mvFrame->addChildWindow(textBox);

		Combobox* mvType;
		mvType = (Combobox*)winMgr.createWindow("TaharezLook/Combobox","MVType");
		mvType->addItem(new ListboxTextItem("Disabled"));
		mvType->addItem(new ListboxTextItem("Anaglyph (ColorMode)"));
		mvType->addItem(new ListboxTextItem("Anaglyph (Sampling)"));
		mvType->addItem(new ListboxTextItem("Parallax (Stencil)"));
		mvType->addItem(new ListboxTextItem("Parallax (Off-target)"));
		mvType->addItem(new ListboxTextItem("Lenticular"));
		mvType->addItem(new ListboxTextItem("Side-by-side"));
		mvType->setPosition(UVector2(cegui_absdim(60), cegui_reldim(0.06)));
		mvType->setSize(UVector2(cegui_absdim(230), cegui_absdim(130)));
		mvType->setReadOnly(true);
		mvType->setText("Disabled");
		mvType->setProperty("ClippedByParent","False");
		mvType->subscribeEvent(
			Combobox::EventListSelectionAccepted, Event::Subscriber(&MultiViewApp::cbMVType,this));
		textBox->addChildWindow(mvType);
		
		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","AnaglyphTypeText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.29)));
		textBox->setSize(UVector2(cegui_absdim(145), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Anaglyph Type:");
		mvFrame->addChildWindow(textBox);

		Combobox* agType;
		agType = (Combobox*)winMgr.createWindow("TaharezLook/Combobox","AnaglyphType");
		agType->addItem(new ListboxTextItem("Red/Green-Blue"));
		agType->addItem(new ListboxTextItem("Red/Blue"));
		agType->addItem(new ListboxTextItem("Red/Green"));
		agType->setPosition(UVector2(cegui_absdim(150), cegui_reldim(0.12)));
		agType->setSize(UVector2(cegui_absdim(173), cegui_absdim(107)));
		agType->setReadOnly(true);
		agType->setText("Red/Green-Blue");
		agType->setProperty("ClippedByParent","False");
		agType->subscribeEvent(
			Combobox::EventListSelectionAccepted, Event::Subscriber(&MultiViewApp::cbAnaglyphType,this));
		textBox->addChildWindow(agType);
		
		Checkbox* parallaxVert;
		parallaxVert = (Checkbox*)winMgr.createWindow("TaharezLook/Checkbox","ParallaxVertical");
		parallaxVert->setPosition(UVector2(cegui_absdim(10), cegui_reldim(0.5)));
		parallaxVert->setSize(UVector2(cegui_absdim(180), cegui_absdim(30)));
		parallaxVert->setFont(&ft);
		parallaxVert->setText("Invert Parallax Axis?");
		parallaxVert->subscribeEvent(
			Checkbox::EventCheckStateChanged, Event::Subscriber(&MultiViewApp::cbParallaxVertical,this));
		mvFrame->addChildWindow(parallaxVert);

		FrameWindow* sceneFrame;
		sceneFrame = (FrameWindow*)winMgr.createWindow("TaharezLook/FrameWindow","SceneFrame");
		sceneFrame->setText("Scene Options");
		sceneFrame->setPosition(UVector2(cegui_reldim(0.73), cegui_reldim(0.06)));
		sceneFrame->setSize(UVector2(cegui_reldim(0.24), cegui_reldim(0.24)));
		sceneFrame->setProperty("ClippedByParent","False");
		sceneFrame->setProperty("RollUpState","True");
		root->addChildWindow(sceneFrame);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","LightOnText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_absdim(45)));
		textBox->setSize(UVector2(cegui_absdim(105), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Lights-On:");
		sceneFrame->addChildWindow(textBox);

		Combobox* lightOnType;
		lightOnType = (Combobox*)winMgr.createWindow("TaharezLook/Combobox","LightOn");
		lightOnType->addItem(new ListboxTextItem("1"));
		lightOnType->addItem(new ListboxTextItem("2"));
		lightOnType->setPosition(UVector2(cegui_absdim(120), cegui_absdim(45)));
		lightOnType->setSize(UVector2(cegui_absdim(60), cegui_absdim(84)));
		lightOnType->setReadOnly(true);
		lightOnType->setText("1");
		lightOnType->setProperty("ClippedByParent","False");
		lightOnType->subscribeEvent(
			Combobox::EventListSelectionAccepted, Event::Subscriber(&MultiViewApp::cbLightType,this));
		sceneFrame->addChildWindow(lightOnType);
		
		Checkbox* showWalls;
		showWalls = (Checkbox*)winMgr.createWindow("TaharezLook/Checkbox","ShowWalls");
		showWalls->setPosition(UVector2(cegui_absdim(10), cegui_absdim(85)));
		showWalls->setSize(UVector2(cegui_absdim(120), cegui_absdim(30)));
		showWalls->setFont(&ft);
		showWalls->setText("Show Walls&Lamps?");
		showWalls->setSelected(true);
		showWalls->subscribeEvent(
			Checkbox::EventCheckStateChanged, Event::Subscriber(&MultiViewApp::cbWallsAndLamps,this));
		sceneFrame->addChildWindow(showWalls);

		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","CorrObjTypeText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_absdim(8)));
		textBox->setSize(UVector2(cegui_absdim(105), cegui_absdim(30)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setText("Corridor:");
		sceneFrame->addChildWindow(textBox);

		Combobox* corrObjType;
		corrObjType = (Combobox*)winMgr.createWindow("TaharezLook/Combobox","CorrObjType");
		corrObjType->addItem(new ListboxTextItem("All"));
		corrObjType->addItem(new ListboxTextItem("Bunny"));
		corrObjType->addItem(new ListboxTextItem("Torus"));
		corrObjType->addItem(new ListboxTextItem("Doll"));
		corrObjType->addItem(new ListboxTextItem("Chair-1"));
		corrObjType->addItem(new ListboxTextItem("Chair-2"));
		corrObjType->addItem(new ListboxTextItem("Box"));
		corrObjType->addItem(new ListboxTextItem("Sphere"));
		corrObjType->setPosition(UVector2(cegui_absdim(120), cegui_absdim(8)));
		corrObjType->setSize(UVector2(cegui_absdim(100), cegui_absdim(127)));
		corrObjType->setReadOnly(true);
		corrObjType->setText("All");
		corrObjType->setProperty("ClippedByParent","False");
		corrObjType->subscribeEvent(
			Combobox::EventListSelectionAccepted, Event::Subscriber(&MultiViewApp::cbCorridorType,this));
		sceneFrame->addChildWindow(corrObjType);
		
		// help text
		textBox = (DefaultWindow*)winMgr.createWindow("TaharezLook/StaticText","HelpText");
		textBox->setPosition(UVector2(cegui_absdim(10), cegui_absdim(50)));
		textBox->setSize(UVector2(cegui_absdim(800), cegui_absdim(300)));
		textBox->setFont(&ft);
		textBox->setProperty("FrameEnabled","False");
		textBox->setProperty("BackgroundEnabled","False");
		textBox->setProperty("MousePassThroughEnabled","True");
		textBox->hide();
		textBox->setText(
			"==== = = = = = = HELP = = = = = = ====\n"
			"\n"
			"Camera stereo : Parallel=Z / Skewed=X / Oriented=C\n"
			"Eye separation: Increase=D / Decrease=A\n"
			"Focal distance: Increase=W / Decrease=S\n"
			"Show focal plane: Q\n"
			"\n"
			"Multi-view type: Disabled=U / Anaglyph ColorMode=I Sampling=O / Lenticular=P\n"
			"Multi-view type: Parallax Stencil=J Offtarget=K / Side-by-side=L\n"
			"Anaglyph type: R-GB=B / R-B=N / R-G=M\n"
			"Invert Parallax Axis: H\n"
			"\n"
			"Corridor: All=Shift+0 / Sphere=Shift+1 / Doll=Shift+2 / Bunny=Shift+3\n"
			"Corridor: Torus=Shift+4 / Chair-1=Shift+5 / Chair-2=Shift+6 / Box=Shift+7\n"
			"Show Walls&light: Space\n"
			"Lights: White=T / Blue=Y\n");
		root0->addChildWindow(textBox);

#endif
	}
	bool cbParallaxVertical(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Checkbox* pv= (Checkbox*)winMgr.getWindow("ParallaxVertical");
		mvcParallax->setViewAxisTransposed(pv->isSelected());
		mvcParallax_Stencil->setViewAxisTransposed(pv->isSelected());
		return true;
	}
	
	bool cbFocalPlane(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Checkbox* showFocalPlane = (Checkbox*)winMgr.getWindow("ShowFocalPlane");
		setFocalPlaneDisplay(showFocalPlane->isSelected());
		showFocalPlane->setSelected(getFocalPlaneDisplay());
		return true;
	}
	bool cbWallsAndLamps(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Checkbox* showWalls = (Checkbox*)winMgr.getWindow("ShowWalls");
		showWallsAndLamps(showWalls->isSelected());
		return true;
	}
	
	bool cbCamEyeSep(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Spinner* camSlider = (Spinner*) winMgr.getWindow("CamEyeSep");
		double camVal = camSlider->getCurrentValue();
		mCamera_2->setEyeSeparation(camVal);
		mCamera_5->setEyeSeparation(camVal);
		return true;
	}
	bool cbCamFocalDist(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Spinner* camSlider = (Spinner*) winMgr.getWindow("CamFocalDist");
		double camVal = camSlider->getCurrentValue();
		mCamera_2->setFocalDistance(camVal);
		mCamera_5->setFocalDistance(camVal);
		return true;
	}
	bool cbCorridorType(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Combobox* lightOn= (Combobox*)winMgr.getWindow("CorrObjType");
		const char* s = lightOn->getSelectedItem()->getText().c_str();
		if(!strcmp(s,"All")){
			setCorridor(Corridor_All);
		} else if(!strcmp(s,"Sphere")){
			setCorridor(Corridor_Sphere);
		} else if(!strcmp(s,"Box")){
			setCorridor(Corridor_Box);
		} else if(!strcmp(s,"Chair-1")){
			setCorridor(Corridor_Chair);
		} else if(!strcmp(s,"Chair-2")){
			setCorridor(Corridor_Chair2);
		} else if(!strcmp(s,"Doll")){
			setCorridor(Corridor_Doll);
		} else if(!strcmp(s,"Torus")){
			setCorridor(Corridor_Torus);
		} else if(!strcmp(s,"Bunny")){
			setCorridor(Corridor_Bunny);
		}
		return true;
	}
	bool cbLightType(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Combobox* lightOn= (Combobox*)winMgr.getWindow("LightOn");
		const char* s = lightOn->getSelectedItem()->getText().c_str();
		if(!strcmp(s,"1")){
			setLightLid(0);
		} else if(!strcmp(s,"2")){
			setLightLid(1);
		}
		return true;
	}
	bool cbCamStereoMode(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Combobox* camStereoSetup = (Combobox*)winMgr.getWindow("CamStereoSetup");
		const char* s = camStereoSetup->getSelectedItem()->getText().c_str();
		if(!strcmp(s,"Parallel")){
			mCamera_2->setStereoType(CameraStereoView::TypeParallel);
		} else if(!strcmp(s,"Oriented")){
			mCamera_2->setStereoType(CameraStereoView::TypeOriented);
		} else if(!strcmp(s,"Skewed")){
			mCamera_2->setStereoType(CameraStereoView::TypeSkewed);
		}
		return true;
	}
	bool cbAnaglyphType(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Combobox* mvType = (Combobox*)winMgr.getWindow("AnaglyphType");
		const char* s = mvType->getSelectedItem()->getText().c_str();
		if(!strcmp(s,"Red/Green-Blue")){
			mvcAnaglyph_ColorMode->setType(Anaglyh_R_GB);
			mvcAnaglyph_Sampling ->setType(Anaglyh_R_GB);
		} else if(!strcmp(s,"Red/Blue")){
			mvcAnaglyph_ColorMode->setType(Anaglyh_Mono_R_B);
			mvcAnaglyph_Sampling ->setType(Anaglyh_Mono_R_B);
		} else if(!strcmp(s,"Red/Green")){
			mvcAnaglyph_ColorMode->setType(Anaglyh_Mono_R_G);
			mvcAnaglyph_Sampling ->setType(Anaglyh_Mono_R_G);
		} else {
		}
		return true;
	}
	bool cbMVType(const CEGUI::EventArgs& args){
		using namespace CEGUI;
		WindowManager& winMgr = WindowManager::getSingleton();
		Combobox* mvType = (Combobox*)winMgr.getWindow("MVType");
		const char* s = mvType->getSelectedItem()->getText().c_str();
		if(!strcmp(s,"Disabled")){
			setMVConfig(MVConfig_Disabled);
		} else if(!strcmp(s,"Anaglyph (ColorMode)")){
			setMVConfig(MVConfig_Anaglyph_ColorMode);
		} else if(!strcmp(s,"Anaglyph (Sampling)")){
			setMVConfig(MVConfig_Anaglyph_Sampling);
		} else if(!strcmp(s,"Parallax (Stencil)")){
			setMVConfig(MVConfig_Parallax_Stencil);
		} else if(!strcmp(s,"Parallax (Off-target)")){
			setMVConfig(MVConfig_Parallax_Offtarget);
		} else if(!strcmp(s,"Lenticular")){
			setMVConfig(MVConfig_Lenticular);
		} else if(!strcmp(s,"Side-by-side")){
			setMVConfig(MVConfig_SideBySide);
		} else {
		}
		return true;
	}
};

int main(){
	new MultiViewApp();
	return MultiViewApp::getSingleton().run();
}

