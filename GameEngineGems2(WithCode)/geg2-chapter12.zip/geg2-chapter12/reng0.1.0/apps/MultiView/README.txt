Application: MultiView Demo

Controls:

Continous:
LEFT-RIGHT ARROW : Move camera left-right
UP-DOWN ARROW    : Move Object bask-forward
A-D              : Decrease/increase eye separation
W-S              : Increase/decrease focal distance

One-time:
SPACE            : Enable/disable perspective correction
J-K-L            : Hack : Override view cameras : Always left camera - auto camera - always right camera
H                : Switch MVC view axis transpose  feature