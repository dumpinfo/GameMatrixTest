#include "PieWidget.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

const float PieWidget::MaximumScale = 2.0f;

REng::MeshGeom* PieWidget::mPieMeshGeom;
REng::MeshPtr   PieWidget::mPieMeshRed;
REng::MeshPtr   PieWidget::mPieMeshBlue;
REng::MeshPtr   PieWidget::mPieMeshGreen;
REng::MeshPtr   PieWidget::mPieMeshRedDark;
REng::MeshPtr   PieWidget::mPieMeshBlueDark;
REng::MeshPtr   PieWidget::mPieMeshGreenDark;

PieWidget::PieWidget(REng::uchar numOfPies)
:mAnimationSpeed(2.0f)
,mActiveState(State_Idle)
,mHasExpanded(false)
,mRootNode(0)
,mPieContainerNode(0)
,mNumberOfPies(numOfPies)
,mPieRotation(0)
,mCurrentScale(1)
{
	mActivePieNo = mNumberOfPies-1;
	assert(numOfPies>3);
}

void PieWidget::initGraphics(){
	REng::MeshManager::getSingleton().loadFromFile("mesh/piece_of_cake_new.obj");
	mPieMeshGeom = REng::MeshManager::getSingleton().getMeshByName("piece_of_cake_new_0")
		->getSuitableData(0,0);
	mPieMeshRed = REng::MeshManager::getSingleton().createMesh("PieMeshRed");
	mPieMeshRed->createLoDGeom(*mPieMeshGeom);
	mPieMeshRed->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Red");
	mPieMeshBlue = REng::MeshManager::getSingleton().createMesh("PieMeshBlue");
	mPieMeshBlue->createLoDGeom(*mPieMeshGeom);
	mPieMeshBlue->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Blue");
	mPieMeshGreen = REng::MeshManager::getSingleton().createMesh("PieMeshGreen");
	mPieMeshGreen->createLoDGeom(*mPieMeshGeom);
	mPieMeshGreen->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Green");
	mPieMeshRedDark = REng::MeshManager::getSingleton().createMesh("PieMeshRedDark");
	mPieMeshRedDark->createLoDGeom(*mPieMeshGeom);
	mPieMeshRedDark->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Red_Dark");
	mPieMeshBlueDark = REng::MeshManager::getSingleton().createMesh("PieMeshBlueDark");
	mPieMeshBlueDark->createLoDGeom(*mPieMeshGeom);
	mPieMeshBlueDark->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Blue_Dark");
	mPieMeshGreenDark = REng::MeshManager::getSingleton().createMesh("PieMeshGreenDark");
	mPieMeshGreenDark->createLoDGeom(*mPieMeshGeom);
	mPieMeshGreenDark->mMaterial = REng::MaterialManager::getSingleton().getMaterial("PieMaterial_Green_Dark");
}

REng::AngleDegree PieWidget::getAngleBetweenPies() const{
	return REng::AngleDegree(360.0f / mNumberOfPies);
}

void PieWidget::initPieCollection(){
	if(mRootNode) return;	// return if initialized
	mRootNode         = &REng::GroupNode::create(REng::RootNode::getSingleton());
	mPieContainerNode = &REng::GroupNode::create(*mRootNode);
	mPieContainerNode->scale_Parent(REng::Vector3(1.0,1.0,3.0),true);
	REng::AngleDegree angleBetweenPies(360.0f / mNumberOfPies);
	mPieNodes.clear();
	REng::Quaternion rotator;
	rotator.identity();
	for(REng::uchar pieNo=0 ; pieNo<mNumberOfPies ; ++pieNo){
		REng::MeshNode* pieMesh = &REng::MeshNode::create(*mPieContainerNode);
		mPieNodes.push_back(pieMesh);
		pieMesh->setMesh(getMeshForPie(pieNo,false));
		cml::quaternion_rotate_about_world_z(rotator,angleBetweenPies.getRadian());
		pieMesh->rotate_Parent(rotator,true);
	}
}

void PieWidget::expand(){ 
	if(mActiveState == State_Idle) {
		mActiveState = State_Expand;
		mAnimationTime = 0;
	}
}

bool PieWidget::shrink(){ 
	if(mActiveState == State_Idle) {
		mActiveState = State_Shrink;
		mAnimationTime = 0;
		mHasExpanded = false;
		return true;
	}
	return false;
}

void PieWidget::show(bool flag) {
	if(mPieContainerNode){
		if(flag){
			mPieContainerNode->mCullingMode = REng::SceneNode::CULL_NEVER;
		} else {
			mPieContainerNode->mCullingMode = REng::SceneNode::CULL_ALWAYS;
		}
	}
}

REng::GroupNode& PieWidget::getRootNode(){
	return *mRootNode;
}

void PieWidget::rotatePieForward() {
	if(!mHasExpanded) return;
	if(mActiveState == State_Idle){
		mActiveState = State_RotateFW;
		mPieNodes[mActivePieNo]->setMesh(getMeshForPie(mActivePieNo,false));
		mAnimationTime = 0.0f;
	}
}
void PieWidget::rotatePieBackward(){
	if(!mHasExpanded) return;
	if(mActiveState == State_Idle){
		mActiveState = State_RotateBW;
		mPieNodes[mActivePieNo]->setMesh(getMeshForPie(mActivePieNo,false));
		mAnimationTime = 0.0f;
	}
}
bool PieWidget::activate(){
	if(mActiveState==State_Idle){
		mActiveState = State_Activating;
		mAnimationTime = 0.0f;
		return true;
	}
	return false;
}
bool PieWidget::deactivate(){
	if(mActiveState==State_Activated){
		mActiveState = State_Deactivating;
		mAnimationTime = 0.0f;
		return true;
	}
	return false;
}

void PieWidget::scaleWidget(float s){
	mPieContainerNode->scale_Parent(REng::Vector3(s,s,5.0*s/MaximumScale),true);
}

void PieWidget::animateSelectNext(float u, REng::uchar curItem, REng::uchar nextItem){
	float curScale;
	REng::Interp::Lerp(1.2f,1.0f,u,curScale);
	mPieContainerNode->getChildren()[curItem]->scale_Parent(curScale,true);
	REng::Interp::Lerp(1.0f,1.2f,u,curScale);
	mPieContainerNode->getChildren()[nextItem]->scale_Parent(curScale,true);
}

REng::MeshPtr PieWidget::getMeshForPie(REng::uchar pieNo, bool isDark){
	if(pieNo%3==0){
		if(isDark) return mPieMeshRedDark; else return mPieMeshRed;
	}
	if(pieNo%3==1){
		if(isDark) return mPieMeshBlueDark; else return mPieMeshBlue;
	}
	if(pieNo%3==2){
		if(isDark) return mPieMeshGreenDark; else return mPieMeshGreen;
	}
	return REng::MeshPtr();
}




void PieWidget::tick(float ms){
	mAnimationTime += ms;
	switch(mActiveState){
		// states with no animations
		case State_Idle:
		case State_Activated:
			break;
		case State_Expand: {
			float curScale;
			float u = mAnimationTime*mAnimationSpeed;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Idle;
				mHasExpanded = true;
			}
			REng::Interp::Lerp(0.0f,MaximumScale,u,curScale);
			scaleWidget(curScale);
			break;
		}
		case State_Shrink: {
			float u = mAnimationTime*mAnimationSpeed;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Idle;
			}
			float curScale;
			REng::Interp::Lerp(MaximumScale,0.0f,u,curScale);
			scaleWidget(curScale);
			break;
		}
		case State_RotateFW: {
			float u = mAnimationTime*mAnimationSpeed;
			int activePieNo = mActivePieNo;
			int pieRotation = mPieRotation;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Idle;
				mActivePieNo = getPrevPieNo(mActivePieNo);
				mPieNodes[mActivePieNo]->setMesh(getMeshForPie(mActivePieNo,true));
				mPieRotation = getNextPieNo(mPieRotation);
			}
			{	// rotation for all pies
				REng::AngleDegree initRotate( pieRotation   *360.0f/mNumberOfPies);
				REng::AngleDegree lastRotate((pieRotation+1)*360.0f/mNumberOfPies);
				REng::AngleDegree curRotate;
				REng::Interp::Lerp(initRotate,lastRotate,u,curRotate);
				REng::Quaternion rotator;
				cml::quaternion_rotation_world_z(rotator,curRotate.getRadian());
				mPieContainerNode->rotate_Parent(rotator,true);
			}
			{  // select/deselect two specific pies
				animateSelectNext(u,activePieNo,getPrevPieNo(activePieNo));
			}
			break;
		}
		case State_RotateBW: {
			float u = mAnimationTime*mAnimationSpeed;
			int activePieNo = mActivePieNo;
			int pieRotation = mPieRotation;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Idle;
				mPieNodes[mActivePieNo]->setMesh(getMeshForPie(mActivePieNo,false));
				mActivePieNo = getNextPieNo(mActivePieNo);
				mPieNodes[mActivePieNo]->setMesh(getMeshForPie(mActivePieNo,true));
				mPieRotation = getPrevPieNo(mPieRotation);
			}
			{	// rotation for all pies
				REng::AngleDegree initRotate( pieRotation   *360.0f/mNumberOfPies);
				REng::AngleDegree lastRotate((pieRotation-1)*360.0f/mNumberOfPies);
				REng::AngleDegree curRotate;
				REng::Interp::Lerp(initRotate,lastRotate,u,curRotate);
				REng::Quaternion rotator;
				cml::quaternion_rotation_world_z(rotator,curRotate.getRadian());
				mPieContainerNode->rotate_Parent(rotator,true);
			}
			{  // select/deselect two specific pies
				animateSelectNext(u,activePieNo,getNextPieNo(activePieNo));
			}
			break;
		}
		case State_Activating : {
			float curScale;
			float u = mAnimationTime*mAnimationSpeed;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Activated;
				mHasExpanded = true;
			}
			REng::Interp::Lerp(MaximumScale,MaximumScale*0.5f,u,curScale);
			scaleWidget(curScale);
			break;
		}
		case State_Deactivating : {
			float curScale;
			float u = mAnimationTime*mAnimationSpeed;
			if(u>=1.0f){ // end of animation
				u = 1.0f;
				mActiveState = State_Idle;
				mHasExpanded = true;
			}
			REng::Interp::Lerp(MaximumScale*0.5f,MaximumScale,u,curScale);
			scaleWidget(curScale);
			break;
		}
	}
}

