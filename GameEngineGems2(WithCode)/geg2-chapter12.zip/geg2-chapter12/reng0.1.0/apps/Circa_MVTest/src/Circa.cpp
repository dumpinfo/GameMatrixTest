#include "REng/REng.h"

#include <boost/foreach.hpp> // before InputManager, which inlcudes Xlib.h

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// CIRCA-MVTEST

// A sample 3D UI
// Author: Adil Yalcin

#define WINDOW_WIDTH  1060
#define WINDOW_HEIGHT 680

#include "REng/MVC_Parallax.h"
#include "REng/MVC_Anaglyph.h"

#include "PieWidget.h"

using namespace std;

std::vector<PieWidget*> pieWidgets;
size_t pieWidgetActive = 0;

GroupNode*  camNodeBase = 0;

REng::Viewport* vp =0;
REng::Viewport* vp2=0;
REng::Viewport* vp3=0;
REng::Viewport* vp4=0;
REng::Viewport* vp5=0;

enum CameraPosState{
	CameraPos1,
	CameraPos2,
	CameraPos1to2,
	CameraPos2to1,
};

CameraPosState camPosState = CameraPos1;
float          camAnimTime = 0.0f;

class Circa_MVTestApp : public Application_Base {
public:
	Quaternion camRot1, camRot2;
	Circa_MVTestApp() {}
	~Circa_MVTestApp() {}

	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		// create application window
		int contextParams[] = {
			GLCntxtParStencilRes,   8, // one of the compositors use stencil buffers on default frame buffer
//			GLCntxtParVSynch,       GLCntxtParTrue,
			GLCntxtParNull
		};
		RSys.createWindowAndGLContext(REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),contextParams,inputStartup);
		if(!RSys.initSystem()) return false;

		Logger logger = Logger::getInstance("App");

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/circa.material");

		// create and initialize material resources
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		// *********************
		// CAMERA SETUP

		LOG4CPLUS_INFO(logger, "111");

		camNodeBase = &(GroupNode::create(RootNode::getSingleton()));
		CameraNode* camNode = &(CameraNode::create(*camNodeBase));
		camNode->translate_Parent(Vector3(0.0f,0.0f,130.0f),true);
		CameraStereoView& camera(CameraStereoView::create(*camNode));
		camera.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera.setFarDistance(2000.0f);
		camera.setNearDistance(1.f);
		camera.setFieldOfView_y(AngleDegree(45.0f));
		camera.setEyeSeparation(3.5);
		camera.setFocalDistance(100.0);

		GroupNode* camNode2 = &(GroupNode::create(*camNodeBase));
		Quaternion rotCam;
		cml::quaternion_rotation_world_y(rotCam,Angle::degree2radian(-45));
		camNode2->rotate_Parent(rotCam);
		CameraNode* camNode2_ = &(CameraNode::create(*camNode2));
		camNode2_->translate_Parent(Vector3(0.0f,0.0f,130.0f),true);
		CameraStereoView& camera2(CameraStereoView::create(*camNode2_));
		camera2.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera2.setFarDistance(2000.0f);
		camera2.setNearDistance(1.f);
		camera2.setFieldOfView_y(AngleDegree(45.0f));
		camera2.setEyeSeparation(22.5);
		camera2.setFocalDistance(100.0);

		MVBuffer_Cfg mvbParams;
		mvbParams.viewCount                 = 2;
		mvbParams.type = MVBufferType_Offtarget;
		mvbParams.offtarget.colorFormat               = ImageFormat_RGBA;
		mvbParams.offtarget.depthFormat               = ImageFormat_D;
		mvbParams.offtarget.stencilFormat             = ImageFormat_None;
		mvbParams.offtarget.sharedDepthStencilTargets = true;
		mvbParams.offtarget.sharedFrameBuffer         = true;
		mvbParams.offtarget.halfResHeight             = false;
		mvbParams.offtarget.halfResWidth              = false;

		// Viewport 0 clears color of entire viewport

		////////////////////////////////////////////
		// FIRST MULTI-VIEW VIEWPORT
		// - Parallax-based 2-view
		vp = new Viewport();
		vp->setAbsRect(RectI(380,700,330,650));
		vp->mCamera = &camera;
		vp->mDisableMultiView = true;
		vp->disableRenderQueue(REnderQueueID_GUI);
		RSys.addViewport(1,vp);
		MultiViewBuffer* myMVB(new MultiViewBuffer);
		vp->attachMVCompositor(new MVC_Parallax);
		vp->attachMVBuffer(myMVB,mvbParams);

		////////////////////////////////////////////
		// SECOND MULTI-VIEW VIEWPORT
		// - Anaglyph-based 2-view
		vp2 = new Viewport();
		vp2->setAbsRect(RectI(20,340,20,310));
		vp2->mCamera = &camera2;
		vp2->mDisableMultiView = true;
		vp2->disableRenderQueue(REnderQueueID_GUI);
		RSys.addViewport(2,vp2);
		MultiViewBuffer* myMVB2(new MultiViewBuffer);
		vp2->attachMVCompositor(new MVC_Anaglyph);
		mvbParams.offtarget.halfResWidth=false;
		mvbParams.offtarget.lod.halfResBuffer = false;
		vp2->attachMVBuffer(myMVB2,mvbParams);

		////////////////////////////////////////////
		// THIRD MULTI-VIEW VIEWPORT
		// - Wiggle stereo
		vp3 = new Viewport();
		vp3->setAbsRect(RectI(20,340,330,650));
		vp3->mCamera = &camera;
		vp3->mDisableMultiView = true;
		vp3->disableRenderQueue(REnderQueueID_GUI);
		RSys.addViewport(3,vp3);
		MultiViewBuffer* myMVB3(new MultiViewBuffer);
		mvbParams.type = MVBufferType_Ontarget;
		vp3->attachMVBuffer(myMVB3,mvbParams);

		////////////////////////////////////////////
		// FIFTH MULTI-VIEW VIEWPORT
		// - On-screen buffer, parallax, stencil-based
		vp5 = new Viewport();
		vp5->setAbsRect(RectI(710,1030,330,650));
		vp5->mCamera = &camera;
		vp5->mDisableMultiView = true;
		vp5->disableRenderQueue(REnderQueueID_GUI);
		RSys.addViewport(6,vp5);
		MultiViewBuffer* myMVB5(new MultiViewBuffer);
		vp5->attachMVBuffer(myMVB5,mvbParams);
		MVC_Parallax_Stencil* mvcParStc = new MVC_Parallax_Stencil;
		mvbParams.type = MVBufferType_Ontarget;
//		mvcParStc->setViewAxisTransposed(true);
		vp5->attachMVCompositor(mvcParStc);
		

		////////////////////////////////////////////
		// FOURTH MULTI-VIEW VIEWPORT
		// - Same buffer, different rectangles
		vp4 = new Viewport();
		vp4->setAbsRect(RectI(380,1030,20,310));
		vp4->mCamera = &camera2;
		vp4->mDisableMultiView = true;
		vp4->disableRenderQueue(REnderQueueID_GUI);
		RSys.addViewport(5,vp4);
		MultiViewBuffer* myMVB4(new MultiViewBuffer);
		mvbParams.ontarget.viewRects.push_back(RectF(0.00,0.47,0.0,1.0));
		mvbParams.ontarget.viewRects.push_back(RectF(0.53,1.00,0.0,1.0));
		vp4->attachMVBuffer(myMVB4,mvbParams);

		camRot1.identity();
		cml::quaternion_rotation_world_y(camRot2,REng::Angle::degree2radian(90.0f));

		REng::RenderSystem::getSingleton().setSkyMeshGeom( REng::MeshGeomGenerator::getSingleton().getUnitAAB() );

		//create new pieWidget
		PieWidget::initGraphics();
		pieWidgets.push_back(new PieWidget(10));
		pieWidgets.push_back(new PieWidget(9));
		pieWidgets.push_back(new PieWidget(8));

		REng::Quaternion rotator;
		cml::quaternion_rotation_world_y(rotator,REng::AngleDegree(90).getRadian());
		BOOST_FOREACH(PieWidget* pw, pieWidgets){
			pw->initPieCollection();
			cml::quaternion_rotation_world_z(rotator, -REng::Angle::degree2radian(90));
			pw->getRootNode().rotate_Parent(rotator);
			pw->getRootNode().translate_Parent(REng::Vector3(0.0,0.0,-20.0));
			pw->getRootNode().scale_Parent(1.1);
		}

		pieWidgets[0]->expand();
		pieWidgets[0]->show(true);
		for(size_t i=1; i<pieWidgets.size() ; ++i){
			pieWidgets[i]->shrink();
			pieWidgets[i]->show(false);
			pieWidgets[i]->getRootNode().translate_Parent(REng::Vector3(0.0*i,0.0*i,+20.0*i));
		}

		initGUI();
		return true;
	}

	void initGUI(){
#ifdef RENG_SAMPLE_USECEGUI
		Viewport *vpFull = RenderSystem::getSingleton().getViewport(0);
		Viewport *vp = new Viewport();
		vp->setAbsRect(vpFull->getAbsRect());
		vp->disableRenderQueues_LessThan(REnderQueueID_GUI);
		vp->autoClearBuffer(FrameBufferComponent_Depth,false);
		vp->autoClearBuffer(FrameBufferComponent_Stencil,false);
		//	// Note: GUi viewport should be rendered after (on top of) multi-view viewports
		RenderSystem::getSingleton().addViewport(8,vp);

		CEGUI::REngRenderer* guiRenderer(&CEGUI::REngRenderer::create(*vp));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();
		initSharedCEGUIOverlay(guiRenderer);

		using namespace CEGUI;

		SchemeManager::getSingleton().create("TaharezLook.scheme");
		System::getSingleton().setDefaultMouseCursor("TaharezLook", "MouseArrow");

		WindowManager& winMgr = WindowManager::getSingleton();
		DefaultWindow* root = (DefaultWindow*)winMgr.createWindow("DefaultWindow", "Root");
		System::getSingleton().setGUISheet(root);

/*		FrameWindow* wnd = (FrameWindow*)winMgr.createWindow("TaharezLook/FrameWindow", "Demo Window");
		wnd->setPosition(UVector2(cegui_reldim(0.55f), cegui_reldim( 0.55f)));
		wnd->setSize(UVector2(cegui_reldim(0.4f), cegui_reldim( 0.4f)));
		wnd->setMaxSize(UVector2(cegui_reldim(1.0f), cegui_reldim( 1.0f)));
		wnd->setMinSize(UVector2(cegui_reldim(0.1f), cegui_reldim( 0.1f)));
		wnd->setText("Hello World!");
		root->addChildWindow(wnd); */

		CEGUI::Font& ft(FontManager::getSingleton().createFreeTypeFont("overlayFont",15,true,"batang.ttf"));

		Editbox* textBox;
		textBox = (Editbox*)winMgr.createWindow("TaharezLook/Editbox","VP1");
		textBox->setPosition(UVector2(cegui_absdim(445), cegui_absdim( 320)));
		textBox->setSize(UVector2(cegui_absdim(195), cegui_absdim( 30)));
		textBox->setText("Parallax (offtarget)");
		textBox->setReadOnly(true);
		textBox->setFont(&ft);
		root->addChildWindow(textBox);

		textBox = (Editbox*)winMgr.createWindow("TaharezLook/Editbox","VP2");
		textBox->setPosition(UVector2(cegui_absdim(780), cegui_absdim( 320)));
		textBox->setSize(UVector2(cegui_absdim(190), cegui_absdim( 30)));
		textBox->setText("Parallax (w. Stencil)");
		textBox->setReadOnly(true);
		textBox->setFont(&ft);
		root->addChildWindow(textBox);

		textBox = (Editbox*)winMgr.createWindow("TaharezLook/Editbox","VP3");
		textBox->setPosition(UVector2(cegui_absdim(125), cegui_absdim( 320)));
		textBox->setSize(UVector2(cegui_absdim(75), cegui_absdim( 30)));
		textBox->setText("Wiggle");
		textBox->setReadOnly(true);
		textBox->setFont(&ft);
		root->addChildWindow(textBox);

		textBox = (Editbox*)winMgr.createWindow("TaharezLook/Editbox","VP5");
		textBox->setPosition(UVector2(cegui_absdim(80), cegui_absdim( 630)));
		textBox->setSize(UVector2(cegui_absdim(190), cegui_absdim( 30)));
		textBox->setReadOnly(true);
		textBox->setFont(&ft);
		textBox->setText("Anaglyph Red-Cyan");
		root->addChildWindow(textBox);

		textBox = (Editbox*)winMgr.createWindow("TaharezLook/Editbox","VP4");
		textBox->setPosition(UVector2(cegui_absdim(460), cegui_absdim( 630)));
		textBox->setSize(UVector2(cegui_absdim(510), cegui_absdim( 30)));
		textBox->setText("Separated Views (different cam with higher separation)");
		textBox->setReadOnly(true);
		textBox->setFont(&ft);
		root->addChildWindow(textBox);
#endif
	}

	bool preRender(float timeLapse){
		if(camPosState==CameraPos1to2){
			camAnimTime+=timeLapse*2;
			float u = camAnimTime;
			if(u>=1.0f){
				u = 1.0f;
				camPosState = CameraPos2;
			}
			REng::Quaternion rot;
			REng::Interp::NLerp(camRot1,camRot2,u,rot);
			camNodeBase->rotate_Parent(rot,true);
		}
		if(camPosState==CameraPos2to1){
			camAnimTime+=timeLapse*2;
			float u = camAnimTime;
			if(u>=1.0f){
				u = 1.0f;
				camPosState = CameraPos1;
			}
			REng::Quaternion rot;
			REng::Interp::NLerp(camRot2,camRot1,u,rot);
			camNodeBase->rotate_Parent(rot,true);
		}

		BOOST_FOREACH(PieWidget* pw, pieWidgets) pw->tick(timeLapse);
		return true;
	}

	bool keyPressed( const OIS::KeyEvent &arg ) {
		cegui_keyPressed(arg);
		PieWidget* pieWidget = pieWidgets[pieWidgetActive];
		if(arg.key == OIS::KC_1){
			if(pieWidget->hasExpanded()) 
				pieWidget->shrink();
			else
				pieWidget->expand();
		}
		if(arg.key == OIS::KC_2){
			if(vp) { bool& flag(vp ->mDisableMultiView); flag = !flag; }
			if(vp2){ bool& flag(vp2->mDisableMultiView); flag = !flag; }
			if(vp3){ bool& flag(vp3->mDisableMultiView); flag = !flag; }
			if(vp4){ bool& flag(vp4->mDisableMultiView); flag = !flag; }
			if(vp5){ bool& flag(vp5->mDisableMultiView); flag = !flag; }
		}
		if(arg.key == OIS::KC_UP){
			pieWidget->rotatePieForward();
		}
		if(arg.key == OIS::KC_DOWN){
			pieWidget->rotatePieBackward();
		}
		if(arg.key==OIS::KC_SPACE || arg.key==OIS::KC_3){ // camera 
			if(camPosState==CameraPos1){
				camPosState=CameraPos1to2;
				camAnimTime=0.0f;
			}
			if(camPosState==CameraPos2){
				camPosState=CameraPos2to1;
				camAnimTime=0.0f;
			}
		}
		if(arg.key == OIS::KC_LEFT){
			if(pieWidgetActive<pieWidgets.size()-1){
				if(pieWidget->activate()==true){
					pieWidgetActive++;
					pieWidget = pieWidgets[pieWidgetActive];
					pieWidget->show(true);
					pieWidget->expand();
				}
			}
		}
		if(arg.key == OIS::KC_RIGHT){
			if(pieWidgetActive!=0){
				if(pieWidget->shrink()==true){
					pieWidgetActive--;
					pieWidget = pieWidgets[pieWidgetActive];
					pieWidget->deactivate();
				}
			}
		}
		return true;
	}
};

int main(){
	new Circa_MVTestApp();
	return Circa_MVTestApp::getSingleton().run();
}
