#include "REng/REng.h"

#include <vector>

//! Each pie widgets attaches itself to root node
class PieWidget {
public:
	//! @param numOfPies must be larger than 4
	PieWidget(REng::uchar numOfPies);

	//! Loads the meshes that will be used by all instances
	static void initGraphics();

	REng::AngleDegree getAngleBetweenPies() const;

	//! Initializes mPieContainerNode structure
	void initPieCollection();

	//! True if pie widget is completely expanded and ready to be used
	bool hasExpanded() const { return mHasExpanded; }

	//! Expands the pie widget to full size
	void expand();

	//! Shrinks the pie widget to minimal size, than hides it
	bool shrink();

	//! Shows/Hides the pie widget, without any animation
	//! @param flag If true, this widget is shown, else hidden
	void show(bool flag=true);

	//! Rotates the pie forward one pie element
	void rotatePieForward();
	//! Rotates the pie backward one pie element
	void rotatePieBackward();

	bool activate();
	bool deactivate();

	//! @note Modify spatial data of this widget through this node
	//! @note Do not try to access pie elements within this widget individually
	REng::GroupNode& getRootNode();

	//! Per-frame update routine
	//! @param ms Time elapsed since last call
	void tick(float ms);

	float mAnimationSpeed;

	//! The damping constant used in animation
	float mDamping;

	//! The speed of rotation of pie widget
	float mSpeed;

protected:

	enum State{
		State_Expand,
		State_Shrink,
		State_RotateFW,
		State_RotateBW,
		State_Activating,
		State_Deactivating,
		State_Activated,
		State_Idle // max
	};

	State mActiveState;

	bool mHasExpanded;

	//! The scene node that can be modified by the application to put this widget in the world
	REng::GroupNode* mRootNode;

	//! The scene node that collects all the pies in this widget
	//! Internal widget animations affect this node
	REng::GroupNode* mPieContainerNode;

	//! The individual pies in this node
	std::vector<REng::MeshNode*> mPieNodes;

	void scaleWidget(float s);

	REng::uchar mNumberOfPies;

	REng::uchar mActivePieNo;
	
	REng::uchar mPieRotation;

	// circular iteration
	REng::uchar getNextPieNo(REng::uchar pieNo) { 
		if(pieNo+1==mNumberOfPies) return 0;
		return pieNo+1;
	}
	REng::uchar getPrevPieNo(REng::uchar pieNo) { 
		if(pieNo==0) return mNumberOfPies-REng::uchar(1);
		return pieNo-1;
	}

	float mCurrentScale;

	float mAnimationTime;

	void animateSelectNext(float u, REng::uchar curItem, REng::uchar nextItem);

	REng::MeshPtr getMeshForPie(REng::uchar pieNo, bool isDark);

	static const float MaximumScale;

	static REng::MeshGeom* mPieMeshGeom;
	static REng::MeshPtr mPieMeshRed;
	static REng::MeshPtr mPieMeshBlue;
	static REng::MeshPtr mPieMeshGreen;
	static REng::MeshPtr mPieMeshRedDark;
	static REng::MeshPtr mPieMeshBlueDark;
	static REng::MeshPtr mPieMeshGreenDark;
};

