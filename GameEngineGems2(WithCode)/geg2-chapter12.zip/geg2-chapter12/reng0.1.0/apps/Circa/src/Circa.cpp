#include "REng/REng.h"

#include <boost/foreach.hpp> // before InputManager, which includes Xlib.h

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// CIRCA

// A sample 3D UI
// Author: Adil Yalcin

// OPTIONS 

//(Choose one Multi-view option)
//#define MV_PARALLAX_STENCIL
//#define MV_PARALLAX_ONTARGET
//#define MV_ANAGLYPH
#define MV_ANAGLYPH_ONTARGET

//#define REVERT_VIEW

#define WINDOW_WIDTH  850
#define WINDOW_HEIGHT 475

#include "REng/MVC_Parallax.h"
#include "REng/MVC_Anaglyph.h"

#include "PieWidget.h"

using namespace std;

enum CameraPosState{
	CameraPos1,
	CameraPos2,
	CameraPos1to2,
	CameraPos2to1,
};

CameraPosState camPosState = CameraPos1;
float          camAnimTime = 0.0f;
REng::Quaternion rotZ_pos90;

class CircaApp : public Application_Base {
public:
	
	Quaternion camRot1, camRot2; ///< interpolated camera rotations

	std::vector<PieWidget*> pieWidgets;
	size_t pieWidgetActive;
	GroupNode*  camNodeBase;
	REng::Viewport* vp;
	ScreenCapturer* scrCap;
	bool captureMV;

	CircaApp()
		:pieWidgetActive(0)
		,camNodeBase(0)
		,vp(0)
		,scrCap(0)
		,captureMV(false)
	{}

	~CircaApp() {}

	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());
		int contextParams[] = {
			#if defined(MV_PARALLAX_STENCIL)
			GLCntxtParStencilRes, 8,
			#endif // MV_PARALLAX_STENCIL
			GLCntxtParSampleCount, 4,
			GLCntxtParNull
		};
		RSys.createWindowAndGLContext(
#if defined(REVERT_VIEW)
		RectI(20,20+WINDOW_HEIGHT,30+WINDOW_WIDTH,30),
#else
		RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),
#endif
			contextParams,inputStartup,"Circa");
		if(!RSys.initSystem()) return false;

		cml::quaternion_rotation_world_z(rotZ_pos90,Angle::degree2radian(90));

		Logger logger = Logger::getInstance("App");

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/circa.material");

		// create and initialize material resources
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		MeshManager::getSingleton().loadFromFile("mesh/piece_of_cake.obj");

		// *********************
		// CAMERA SETUP

		camNodeBase = &(GroupNode::create(RootNode::getSingleton()));
#ifdef REVERT_VIEW
		camNodeBase->rotate_Parent(rotZ_pos90,true);
#endif
		CameraNode* camNode = &(CameraNode::create(*camNodeBase));
		camNode->translate_Parent(Vector3(0.0f,0.0f,130.0f),true);
		CameraStereoView& camera(CameraStereoView::create(*camNode));
#ifdef REVERT_VIEW
		float aspectR = float(WINDOW_HEIGHT)/WINDOW_WIDTH;
		camera.setFieldOfView_y(AngleDegree(45.0f)/aspectR);
#else
		float aspectR = float(WINDOW_WIDTH)/WINDOW_HEIGHT;
		camera.setFieldOfView_y(AngleDegree(45.0f));
#endif
		camera.setFarDistance(2000.0f);
		camera.setNearDistance(1.f);
		camera.setAspectRatio(aspectR);
		camera.setEyeSeparation(3.5);
		camera.setFocalDistance(100.0);

		MVBuffer_Cfg mvbParams;
		mvbParams.viewCount                 = 2;
		mvbParams.offtarget.colorFormat               = ImageFormat_RGBA;
		mvbParams.offtarget.depthFormat               = ImageFormat_D24;
		mvbParams.offtarget.stencilFormat             = ImageFormat_None;
		mvbParams.offtarget.sharedDepthStencilTargets = true;
		mvbParams.offtarget.sharedFrameBuffer         = true;
		mvbParams.offtarget.halfResHeight             = false;
		mvbParams.offtarget.halfResWidth              = true;

		// MULTI-VIEW VIEWPORT
		vp = RSys.getViewport(0);
		vp->mCamera = &camera;
		vp->mDisableMultiView = true;
#if defined MV_ANAGLYPH
		MVC_Anaglyph* myMVC(new MVC_Anaglyph);
		myMVC->setType(Anaglyh_Mono_R_G);
		mvbParams.type = MVBufferType_Offtarget;
#elif defined MV_ANAGLYPH_ONTARGET
		MVC_Anaglyph_OnTarget* myMVC(new MVC_Anaglyph_OnTarget);
		myMVC->setType(Anaglyh_R_GB);
		mvbParams.type = MVBufferType_Ontarget;
#elif defined MV_PARALLAX_STENCIL
		MVC_Parallax_Stencil * myMVC(new MVC_Parallax_Stencil);
		mvbParams.type = MVBufferType_Ontarget;
#elif defined MV_PARALLAX_ONTARGET
		MVC_Parallax * myMVC(new MVC_Parallax);
		mvbParams.type = MVBufferType_Offtarget;
#endif
		MultiViewBuffer* myMVB(new MultiViewBuffer);
		vp->attachMVCompositor(myMVC);
		vp->attachMVBuffer(myMVB,mvbParams);

		camRot1.identity();
		cml::quaternion_rotation_world_y(camRot2,REng::Angle::degree2radian(90.0f));

		REng::RenderSystem::getSingleton().setSkyMeshGeom( REng::MeshGeomGenerator::getSingleton().getUnitAAB() );

		//create new pieWidget
		PieWidget::initGraphics();
		pieWidgets.push_back(new PieWidget(10));
		pieWidgets.push_back(new PieWidget(9));
		pieWidgets.push_back(new PieWidget(8));

		REng::Quaternion rotator;
		cml::quaternion_rotation_world_y(rotator,REng::AngleDegree(90).getRadian());
		BOOST_FOREACH(PieWidget* pw, pieWidgets){
			pw->initPieCollection();
			cml::quaternion_rotation_world_z(rotator, -REng::Angle::degree2radian(90));
			pw->getRootNode().rotate_Parent(rotator);
			pw->getRootNode().translate_Parent(REng::Vector3(0.0,0.0,-20.0));
			pw->getRootNode().scale_Parent(1.1);
		}

		pieWidgets[0]->expand();
		pieWidgets[0]->show(true);
		for(size_t i=1; i<pieWidgets.size() ; ++i){
			pieWidgets[i]->shrink();
			pieWidgets[i]->show(false);
			pieWidgets[i]->getRootNode().translate_Parent(REng::Vector3(0.0*i,0.0*i,+20.0*i));
		}

		scrCap = new ScreenCapturer();

		return true;
	}

	bool preRender(float timeLapse){
		static size_t frameNo = 0;
		if(captureMV && vp->mDisableMultiView==false){
			// store the result of previous frame to an  image file
			MultiViewBuffer* mvb = vp->getMVBuffer();
			GPUFrameBuffer* fb_left =mvb->getFrameBuffer(0);
			GPUFrameBuffer* fb_right=mvb->getFrameBuffer(1);
			FrameBufferColorBufferType colorBuf_Left  = FrameBufferColorBufferType_Color0;
			FrameBufferColorBufferType colorBuf_Right = FrameBufferColorBufferType_Color0;
			char fileName[32];

			mvb->setActiveView(0); // updates attached color target
			scrCap->captureFrame(
				*fb_left,
				RectI(0,fb_left->getWidth(),0,fb_left->getHeight()),
				PixelDataFormat_RGBA, 
				colorBuf_Left
				);
			sprintf(fileName,"left_%d",frameNo);
			scrCap->saveCaptureToFile(IFT_PNG,fileName,false,false);
			
			mvb->setActiveView(1); // updates attached color target
			scrCap->captureFrame(
				*fb_right,
				RectI(0,fb_right->getWidth(),0,fb_right->getHeight()),
				PixelDataFormat_RGBA, 
				colorBuf_Right
				);
			sprintf(fileName,"right_%d",frameNo);
			scrCap->saveCaptureToFile(IFT_PNG,fileName,false,false);
		}

		if(camPosState==CameraPos1to2){
			camAnimTime+=timeLapse*2;
			float u = camAnimTime;
			if(u>=1.0f){
				u = 1.0f;
				camPosState = CameraPos2;
			}
			REng::Quaternion rot;
			REng::Interp::NLerp(camRot1,camRot2,u,rot);
			camNodeBase->rotate_Parent(rot,true);
#ifdef REVERT_VIEW
			camNodeBase->rotate_Parent(rotZ_pos90);
#endif
		}
		if(camPosState==CameraPos2to1){
			camAnimTime+=timeLapse*2;
			float u = camAnimTime;
			if(u>=1.0f){
				u = 1.0f;
				camPosState = CameraPos1;
			}
			REng::Quaternion rot;
			REng::Interp::NLerp(camRot2,camRot1,u,rot);
			camNodeBase->rotate_Parent(rot,true);
#ifdef REVERT_VIEW
			camNodeBase->rotate_Parent(rotZ_pos90);
#endif
		}
		BOOST_FOREACH(PieWidget* pw, pieWidgets) pw->tick(timeLapse);
		++frameNo;
		return true;
	}

	//////////////////////////////////////////////////////////////////////////
	// INPUT HANDLING

	bool keyPressed( const OIS::KeyEvent &arg ) {
		cegui_keyPressed(arg);
		PieWidget* pieWidget = pieWidgets[pieWidgetActive];
		if(arg.key == OIS::KC_1){
			if(pieWidget->hasExpanded()) 
				pieWidget->shrink();
			else
				pieWidget->expand();
		}
		if(arg.key == OIS::KC_2){
			bool& flag(vp->mDisableMultiView);
			flag = !flag;
		}
//		if(arg.key == OIS::KC_3){
//			captureMV = !captureMV;
//		}
		if(arg.key == OIS::KC_UP){
			pieWidget->rotatePieForward();
		}
		if(arg.key == OIS::KC_DOWN){
			pieWidget->rotatePieBackward();
		}
		if(arg.key==OIS::KC_SPACE || arg.key==OIS::KC_3){ // camera 
			if(camPosState==CameraPos1){
				camPosState=CameraPos1to2;
				camAnimTime=0.0f;
			}
			if(camPosState==CameraPos2){
				camPosState=CameraPos2to1;
				camAnimTime=0.0f;
			}
		}
		if(arg.key == OIS::KC_LEFT){
			if(pieWidgetActive<pieWidgets.size()-1){
				if(pieWidget->activate()==true){
					pieWidgetActive++;
					pieWidget = pieWidgets[pieWidgetActive];
					pieWidget->show(true);
					pieWidget->expand();
				}
			}
		}
		if(arg.key == OIS::KC_RIGHT){
			if(pieWidgetActive!=0){
				if(pieWidget->shrink()==true){
					pieWidgetActive--;
					pieWidget = pieWidgets[pieWidgetActive];
					pieWidget->deactivate();
				}
			}
		}
		return true;
	}
};

int main(){
	new CircaApp();
	return CircaApp::getSingleton().run();
}
