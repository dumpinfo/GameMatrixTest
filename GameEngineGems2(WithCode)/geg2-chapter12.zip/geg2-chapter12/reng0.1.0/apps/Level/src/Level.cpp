#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// LEVEL

// Loads big environment models and allows fly-through interaction
// Author: Adil Yalcin

// APPLICATION COMPILE_TIME CONFIGURATIONS
//#define RUN_FULLSCREEN
//#define REVERT_VIEW

#ifdef RUN_FULLSCREEN
#	define WINDOW_WIDTH (1280)//(1280)// (800)
#	define WINDOW_HEIGHT (800)//(800)// (600)
#else
#	define WINDOW_WIDTH 850
#	define WINDOW_HEIGHT 475
#endif //RUN_FULLSCREEN

#include "REng/MVC_Anaglyph.h"
#include "REng/MVC_Parallax.h"

#if RENG_PLATFORM == RENG_PLATFORM_OMAP
#include "Light_Omap.h"
#endif

CameraNode* camNode = 0;

GroupNode* meshGroup;

SceneNode* lightNode_base = 0;
GroupNode* lightNode = 0;

MeshNode* lightMeshNode = 0;

Vector3 camSpeed(0,0,0);
float camSpeedVal = 50;

bool mAnimateLights=true;


enum SceneType{
	SceneOutdoor,
	SceneAtrium,
	SceneCathedral,
	SceneCathedral2
};

GroupNode* sceneOutdoorNode= 0;
GroupNode* sceneAtriumNode= 0;
GroupNode* sceneCathedralNode= 0;
GroupNode* sceneCathedral2Node= 0;

SceneType sceneType = SceneCathedral2;

class LevelApp : public Application_Base {
public:
	// 10 textures X 7 materials(varying with lighting conditions)
	MaterialPtr mMaterials[7 * 10];

	// 10 meshes
	std::vector<MeshPtr> mMeshes;

	LevelApp() {}
	~LevelApp() {}

	void cullAllSceneNodes(){
		sceneOutdoorNode->mCullingMode= SceneNode::CULL_ALWAYS;
		sceneAtriumNode->mCullingMode = SceneNode::CULL_ALWAYS;
		sceneCathedralNode->mCullingMode = SceneNode::CULL_ALWAYS;
		sceneCathedral2Node->mCullingMode = SceneNode::CULL_ALWAYS;
	}

	void createMaterials(){
	    MaterialManager& MatMan(MaterialManager::getSingleton());
        // set mesh materials
        MaterialPtr basicTexMaterial;
        char matName[64];
        int matIndex=0;

        MaterialTexturePtr texture0 = MatMan.getMaterialTexture("tex0");
        MaterialTexturePtr texture1 = MatMan.getMaterialTexture("tex1");
        MaterialTexturePtr texture2 = MatMan.getMaterialTexture("tex2");
        MaterialTexturePtr texture3 = MatMan.getMaterialTexture("tex3");
        MaterialTexturePtr texture4 = MatMan.getMaterialTexture("tex4");
        MaterialTexturePtr texture5 = MatMan.getMaterialTexture("tex5");
        MaterialTexturePtr texture6 = MatMan.getMaterialTexture("tex6");
        MaterialTexturePtr texture7 = MatMan.getMaterialTexture("tex7");
        MaterialTexturePtr texture8 = MatMan.getMaterialTexture("tex8");
        MaterialTexturePtr texture9 = MatMan.getMaterialTexture("tex9");

        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Sun_Vertex_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerVertexSun1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Sun_Pixel_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerPixelSun1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Point_Vertex_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerVertexPoint1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Point_Pixel_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerPixelPoint1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Spot_Vertex_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerVertexSpot1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Spot_Pixel_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("PerPixelSpot1_Tex");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0; i<10 ; ++i, ++matIndex){
            sprintf(matName,"Default_%i",i);
            MatMan.createMaterial(matName  ,mMaterials[matIndex]);
            basicTexMaterial = MatMan.getMaterial("Default");
            basicTexMaterial->clone(*(mMaterials[matIndex]),true);
        }
        for(int i=0 ; i<10*7; ) {
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture0);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture1);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture2);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture3);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture4);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture5);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture6);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture7);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture8);
            mMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,texture9);
        }
	}

	void setDefaultMaterials(){
		for(int i=60 ; i<70 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}
	void setSunLightMaterials(){
		for(int i=0 ; i<10 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}
	void setSunLightMaterials_PerPixel(){
		for(int i=10 ; i<20 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}

	void setPointLightMaterials(){
		for(int i=20 ; i<30 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}
	void setPointLightMaterials_PerPixel(){
		for(int i=30 ; i<40 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}

	void setSpotLightMaterials(){
		for(int i=40 ; i<50 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}
	void setSpotLightMaterials_PerPixel(){
		for(int i=50 ; i<60 ; ++i) mMeshes[i%10]->mMaterial = mMaterials[i];
	}
	void createLights(){
	    //////////////////////////////////////////////////////////////////////////
		// POINT LIGHT 1
		lightNode_base   = &(GroupNode::create(RootNode::getSingleton()));
		lightNode = & GroupNode::create(*((GroupNode*)lightNode_base)) ;
		lightNode->translate_Local(Vector3(0.0f,22.0f,-20.0f),true);

		//////////////////////////////////////////////////////////////////////////
		// SUN LIGHT 1
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		Light_Sun_Omap& sunLight1(Light_Sun_Omap::create(*((LightNode*)lightNode)));
#else
		Light_Sun& sunLight1(Light_Sun::create(*((LightNode*)lightNode)));
#endif
		sunLight1.setColor(Color_Real(1.0f,0.3f,0.3f));

		// light parameters
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		Light_Point_Omap& pointLight1(Light_Point_Omap::create(LightNode::create(*((GroupNode*)lightNode))));
#else
		Light_Point& pointLight1(Light_Point::create(LightNode::create(*((GroupNode*)lightNode))));
#endif
		pointLight1.setColor(Color_Real(1.0f,0.8f,0.6f));
		pointLight1.setAttenPosFactors(0.95f,0.0005f,0.00001f);

		//////////////////////////////////////////////////////////////////////////
		// SPOT LIGHT 1
		// light parameters
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		Light_Spot_Omap& spotLight1(Light_Spot_Omap::create(LightNode::create(*((GroupNode*)lightNode))));
#else
		Light_Spot& spotLight1(Light_Spot::create(LightNode::create(*((GroupNode*)lightNode))));
#endif

		spotLight1.setColor(Color_Real(1.0f,1.0f,1.0f));
		spotLight1.setAttenPosFactors(0.95f,0.0005f,0.0001f);
		spotLight1.setAttenDirFactors(10,AngleDegree(40));

		// light meshes
		MeshPtr spotLightMesh  = MeshManager::getSingleton().createMesh("spotLightMesh");
		spotLightMesh ->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(1));
		spotLightMesh ->mMaterial = MaterialManager::getSingleton().getMaterial("re_Blue");

		// set a mesh in the position of light
		lightMeshNode  = &( MeshNode::create(*((GroupNode*)lightNode)) );
		lightMeshNode->setMesh(spotLightMesh);
		Quaternion rotY;
		cml::quaternion_rotation_world_x(rotY,Angle::degree2radian(90));
		lightMeshNode->rotate_World(rotY);
		lightMeshNode->mCullingMode  = SceneNode::CULL_ALWAYS;
	}

	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		// create application window
		int contextParams[] = {
			GLCntxtParSampleCount, 4,
			GLCntxtParNull
		};

		RectI winPos;
#ifdef REVERT_VIEW
		winPos.setLimits(20,20+WINDOW_HEIGHT,30+WINDOW_WIDTH,30);
#else
		winPos.setLimits(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30);
#endif

		RSys.createWindowAndGLContext(winPos,contextParams,
			inputStartup,
			"Level Demo"
			#ifdef RUN_FULLSCREEN
			,true
			#endif
		);

		if(!RSys.initSystem()) return false;

		// parse required material files
		// shared materials
		MaterialScriptParser::getSingleton().parseFile("materials/Level/level.material");
		MaterialScriptParser::getSingleton().parseFile("materials/Level/lightmat.material");
		MaterialScriptParser::getSingleton().parseFile("materials/marble.material");
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		MaterialScriptParser::getSingleton().parseFile("materials/Level/shaders_omap.material");
		MaterialScriptParser::getSingleton().parseFile("materials/Level/textures_omap.material");
#else
		MaterialScriptParser::getSingleton().parseFile("materials/Level/shaders.material");
		MaterialScriptParser::getSingleton().parseFile("materials/Level/textures.material");
#endif

		MeshManager& MeshMan(MeshManager::getSingleton());
		MaterialManager& MatMan(MaterialManager::getSingleton());

		// create and initialize material resources
		MatMan.compileMaterialShaders();
		MatMan.loadMaterials();

		// *********************
		// LIGHT SETUP
		createLights();
		createMaterials();

		//////////////////////////////////////////////////////////////////////////
		// SET SCENE GRAPH STRUCTURE
		//////////////////////////////////////////////////////////////////////////

		// Mesh Group

		MeshMan.mTmpBoundBoxType = GeomTypeOBox;
		MeshMan.mSwapTexCoordS_T = false;

		// *********************
		// MESH SETUP
		sceneOutdoorNode = &(GroupNode::create(RootNode::getSingleton()));
		MeshMan.loadFromFile("mesh/outdoor/outdoor.obj");
		loadOBJMeshList("outdoor",MatMan.getMaterial("Marble"),sceneOutdoorNode);
		Quaternion rot;
		cml::quaternion_rotation_world_y(rot,Angle::degree2radian(-90));
		sceneOutdoorNode->rotate_World(rot);
		sceneOutdoorNode->scale_Parent(160.0);
		sceneOutdoorNode->translate_World(Vector3(10,7,0));
		setDefaultMaterials();

		sceneAtriumNode = &(GroupNode::create(RootNode::getSingleton()));
		MeshMan.loadFromFile("mesh/atrium/atrium.obj");
		loadOBJMeshList("atrium",MatMan.getMaterial("Marble"),sceneAtriumNode);
		sceneAtriumNode->scale_Parent(7.0);

		sceneCathedralNode = &(GroupNode::create(RootNode::getSingleton()));
		MeshMan.loadFromFile("mesh/cathedral/cathedral.obj");
		loadOBJMeshList("cathedral",MatMan.getMaterial("Marble"),sceneCathedralNode);
		sceneCathedralNode->scale_Parent(6.5);
		Quaternion invY;
		cml::quaternion_rotation_world_y(invY,Math::PI);
		sceneCathedralNode->rotate_World(invY);

		sceneCathedral2Node = &(GroupNode::create(RootNode::getSingleton()));
//		MeshMan.loadFromFile("mesh/cathedral/cathedral2.obj");
//		loadOBJMeshList("cathedral2",MatMan.getMaterial("Marble"),sceneCathedral2Node);
//		sceneCathedral2Node->scale_Parent(6.5);

		cullAllSceneNodes();
		sceneOutdoorNode->mCullingMode = SceneNode::CULL_DYNAMIC;

		// *********************
		// CAMERA SETUP

		camNode = &(CameraNode::create(RootNode::getSingleton()));
		camNode->translate_World(Vector3(-40.0f,50.0f,0.0f),true);
		Quaternion camRot;
		cml::quaternion_rotation_world_y(camRot,Angle::degree2radian(-90));
		camNode->rotate_World(camRot);

		CameraStereoView& camera(CameraStereoView::create(*camNode));
		camera.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera.setFarDistance(300.0f);
		camera.setNearDistance(0.1f);
		camera.setFieldOfView_y(AngleDegree(45.0f));
		camera.setEyeSeparation(0.3);
		camera.setFocalDistance(25.0);
#ifdef REVERT_VIEW
		camera.mSwapXY = true;
#endif

		RSys.getViewport(0)->mCamera = &camera;

		MVBuffer_Cfg mvbParams;
		mvbParams.viewCount                           = 2;
		mvbParams.type                                = MVBufferType_Ontarget;
		// the compositor aims to work with on-target buffers
//		mvbParams.offtarget.colorFormat               = ImageFormat_RGBA;
//		mvbParams.offtarget.depthFormat               = ImageFormat_D;
//		mvbParams.offtarget.stencilFormat             = ImageFormat_None;
//		mvbParams.offtarget.sharedDepthStencilTargets = true;
//		mvbParams.offtarget.sharedFrameBuffer         = true;
		MultiViewBuffer* myMVB(new MultiViewBuffer);

		RSys.getViewport(0)->mCamera = &camera;
		RSys.getViewport(0)->mDisableMultiView = true;
		RSys.getViewport(0)->attachMVCompositor(new MVC_Anaglyph_OnTarget);
/*		MVC_Parallax*p = new(MVC_Parallax);
#ifdef REVERT_VIEW
		p->setViewAxisTransposed(true);
#endif
		RSys.getViewport(0)->attachMVCompositor(p);
*/		RSys.getViewport(0)->attachMVBuffer(myMVB,mvbParams);

		initGUI();

		return true;
	}

	void loadOBJMeshList(const char* meshBaseName, MaterialPtr theMat, GroupNode* node){
		for(int i=0 ; true ; ++i){
			char meshName[32];
			sprintf(meshName,"%s_%d",meshBaseName,i);
			MeshPtr meshPtr = (MeshManager::getSingleton().getMeshByName(meshName));
			if(meshPtr.get()){
				meshPtr->mMaterial = theMat;
				MeshNode::create(*node).setMesh(meshPtr);
				mMeshes.push_back(meshPtr);
			} else {
				break;
			}
		}

	}


	void initGUI(){
#ifdef RENG_SAMPLE_USECEGUI
		Viewport *vpFull = RenderSystem::getSingleton().getViewport(0);
		Viewport *vp = new Viewport();
		vp->setAbsRect(vpFull->getAbsRect());
		vp->disableRenderQueues_LessThan(REnderQueueID_GUI);
		vp->autoClearBuffer(FrameBufferComponent_Depth,false);
		vp->autoClearBuffer(FrameBufferComponent_Stencil,false);
		//	// Note: GUi viewport should be rendered after (on top of) multi-view viewports
		RenderSystem::getSingleton().addViewport(1,vp);

		CEGUI::REngRenderer* guiRenderer(&CEGUI::REngRenderer::create(*vp));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();
		initSharedCEGUIOverlay(guiRenderer);
		CEGUI::SchemeManager::getSingleton().create("TaharezLook.scheme");
#endif
	}

	bool preRender(float timeLapse){
		camNode->translate_Local(camSpeed*timeLapse);

		if(mAnimateLights){
			Quaternion lightRot;
			static float rot = 0.0f;
			cml::quaternion_rotation_world_y(lightRot,rot);
			lightNode_base ->rotate_World(lightRot,true);
			rot += timeLapse*2.0f;
		}

		mTimer.getElapsedTime(true); // reset
		return true;
	}
	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_1) setSunLightMaterials();
		if(arg.key == OIS::KC_2) setPointLightMaterials();
		if(arg.key == OIS::KC_3) setSpotLightMaterials();
		if(arg.key == OIS::KC_4) setSunLightMaterials_PerPixel();
		if(arg.key == OIS::KC_5) setPointLightMaterials_PerPixel();
		if(arg.key == OIS::KC_6) setSpotLightMaterials_PerPixel();

#ifndef REVERT_VIEW
		if(arg.key == OIS::KC_UP)    camSpeed += Vector3(0,0,-camSpeedVal);
		if(arg.key == OIS::KC_DOWN)  camSpeed += Vector3(0,0,+camSpeedVal);
		if(arg.key == OIS::KC_LEFT)  camSpeed += Vector3(-camSpeedVal,0,0);
		if(arg.key == OIS::KC_RIGHT) camSpeed += Vector3(+camSpeedVal,0,0);
#else
		if(arg.key == OIS::KC_UP)    camSpeed += Vector3(+camSpeedVal,0,0);
		if(arg.key == OIS::KC_DOWN)  camSpeed += Vector3(-camSpeedVal,0,0);
		if(arg.key == OIS::KC_LEFT)  camSpeed += Vector3(0,0,-camSpeedVal);
		if(arg.key == OIS::KC_RIGHT) camSpeed += Vector3(0,0,+camSpeedVal);
#endif

		if(arg.key == OIS::KC_H) {
			cullAllSceneNodes();
			sceneOutdoorNode->mCullingMode = SceneNode::CULL_DYNAMIC;
		}
		if(arg.key == OIS::KC_J) {
			cullAllSceneNodes();
			sceneAtriumNode->mCullingMode = SceneNode::CULL_DYNAMIC;
		}
		if(arg.key == OIS::KC_K) {
			cullAllSceneNodes();
			sceneCathedralNode->mCullingMode = SceneNode::CULL_DYNAMIC;
		}
		if(arg.key == OIS::KC_L) {
			cullAllSceneNodes();
			sceneCathedral2Node->mCullingMode = SceneNode::CULL_DYNAMIC;
		}

		CameraStereoView* c = (CameraStereoView*)(RenderSystem::getSingleton().getViewport(0)->mCamera);
		if(arg.key == OIS::KC_F1) { // 0x3B : 59 separation increase
			float s = c->getEyeSeparation()+0.1f;
			s = Math::clamp(s,0.f,10.f);
			c->setEyeSeparation(s);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New eye separation: "<<s);
		}
		if(arg.key == OIS::KC_F2) { // 0x3C : 60 separation decrease
			float s = c->getEyeSeparation()-0.1f;
			s = Math::clamp(s,0.f,10.f);
			c->setEyeSeparation(s);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New eye separation: "<<s);
		}
		if(arg.key == OIS::KC_F3) { // 0x3D : 61 focus inc
			float f = c->getFocalDistance()+5.f;
			f = Math::clamp(f,10.f,500.f);
			c->setFocalDistance(f);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New focal length: "<<f);
		}
		if(arg.key == OIS::KC_F4) { // 0x3E : 62 focus dec
			float f = c->getFocalDistance()-5.f;
			f = Math::clamp(f,10.f,500.f);
			c->setFocalDistance(f);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New focal length: "<<f);
		}

		if(arg.key == OIS::KC_8) {
			bool& flag(RenderSystem::getSingleton().getViewport(0)->mDisableMultiView);
			flag = !flag;
		}
		if(arg.key == OIS::KC_9) mAnimateLights = !mAnimateLights;
		return true;
	}
	bool keyReleased( const OIS::KeyEvent &arg ) {
#ifndef REVERT_VIEW
		if(arg.key == OIS::KC_UP)    camSpeed += Vector3(0,0,+camSpeedVal);
		if(arg.key == OIS::KC_DOWN)  camSpeed += Vector3(0,0,-camSpeedVal);
		if(arg.key == OIS::KC_LEFT)  camSpeed += Vector3(+camSpeedVal,0,0);
		if(arg.key == OIS::KC_RIGHT) camSpeed += Vector3(-camSpeedVal,0,0);
#else
		if(arg.key == OIS::KC_UP)    camSpeed += Vector3(-camSpeedVal,0,0);
		if(arg.key == OIS::KC_DOWN)  camSpeed += Vector3(+camSpeedVal,0,0);
		if(arg.key == OIS::KC_LEFT)  camSpeed += Vector3(0,0,+camSpeedVal);
		if(arg.key == OIS::KC_RIGHT) camSpeed += Vector3(0,0,-camSpeedVal);
#endif
		return true;
	}
	bool mouseMoved( const OIS::MouseEvent &arg ) {
		static Vector2 mMousePos(0,0);
		Vector2 curMousePos(arg.state.X.abs,arg.state.Y.abs);
		if(arg.state.buttonDown(OIS::MB_Left)){
			Vector2 dif = curMousePos-mMousePos;
			Quaternion rotY, rotX;
			cml::quaternion_rotation_world_x(rotX,-(arg.state.Y.rel*0.009f));
			cml::quaternion_rotation_world_y(rotY,-(arg.state.X.rel*0.009f));
			camNode->rotate_Local(rotX,false);
			camNode->rotate_Local(rotY,false);
		}
		mMousePos = curMousePos;
		return true;
	}
};

int main(){
	new LevelApp();
	return LevelApp::getSingleton().run();
}

