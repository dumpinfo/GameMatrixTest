#include "REng/REng.h"

int main(int argc, char* argv[]){
	if(argc == 1){
		printf("Please supply the names of the file which you want to be parsed as a command line parameter.\n");
		return 0;
	}
	// create singleton instances
	new REng::RenderSystem();

	// create a dummy window
	REng::RenderSystem::getSingleton().createWindowAndGLContext(REng::RectI(20,30,30,20));
	if(!REng::RenderSystem::getSingleton().initSystem()) return false;

	// parse the sample material file

	for(int i=1; i<argc; i++){
		if( REng::MaterialScriptParser::getSingleton().parseFile(argv[i]) == false){
			printf("The file %s could not be parsed. Check log/matParser.log file for details.\n", argv[i]);
		} else {
			printf("The file %s is successfully parsed. Check log/matParser.log file for details.\n", argv[i]);
		}
	}
	REng::MaterialManager::getSingleton().compileMaterialShaders();
	REng::MaterialManager::getSingleton().loadMaterials();

	// done
	return 0;
}
