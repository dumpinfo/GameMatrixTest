// THIS DEMO IS ONLY AIMED TOWARDS OPENGL 3.0> CONTEXTS

// Implements the techniques described in
// http://www.comp.nus.edu.sg/~tants/jfa.html

// This app does not use the scene graph auto rendering

#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include "VoronoiTexture2D.h"

#define WINDOW_WIDTH  700
#define WINDOW_HEIGHT 700

#define RANDOM_SEED_COUNT 50

#include <stdio.h>
#include <time.h>

using namespace REng;

CameraNode* camNode    = 0;
GroupNode*  camNodeBase = 0;

VoronoiTexture2D* mVoronoiPtr;
MeshNode *mVoronoiNode;

CameraPerspective* camera;

class VoronoiApp : public Application_Base {
public:
	VoronoiApp() :mMousePos(0,0){}
	~VoronoiApp() {}

	bool loadApp(){
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		std::cout << "This demo is not supported in OpenGL ES 2.0 configurations" << std::endl;
		return 0;
#endif
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		RSys.createWindowAndGLContext(REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),0,inputStartup);
		if(!RSys.initSystem()) return false;

		mVoronoiNode = &(REng::MeshNode::create(REng::RootNode::getSingleton()));
		mVoronoiNode->scale_Parent(50.0f);

		VoronoiTexture2D::loadVoronoiPrograms();
		mVoronoiPtr = new VoronoiTexture2D();
		mVoronoiPtr->init(512);
		mVoronoiPtr->setIsSeedsDynamic(false);

		// *********************
		// CAMERA SETUP
		camNodeBase = &(GroupNode::create(RootNode::getSingleton()));
		camNode = &(CameraNode::create(*camNodeBase));
		camNode->translate_Parent(Vector3(0.0f,0.0f,130.0f),true);

		camera = &(CameraPerspective::create(*camNode));
		camera->setAspectRatio(700.0f/700.0f);
		camera->setFarDistance(2000.0f);
		camera->setNearDistance(1.f);
		camera->setFieldOfView_y(AngleDegree(45.0f));

		mNoRenderScene = true;
		return true;
	}
	bool preRender(float timeLapse){
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		RenderMatrixManager::getSingleton().setProjection(camera->getProjectionMatrix());
		RenderMatrixManager::getSingleton().setView(camera->getViewMatrix());
		mVoronoiPtr->update(timeLapse);

		mVoronoiPtr->activateScreenProgram();
		REng::RenderMatrixManager::getSingleton().pushModel();
		REng::RenderMatrixManager::getSingleton().setModel(mVoronoiNode->getWorld_Transform(),true);
		REng::GPUDrawer::getSingleton().drawMeshGeom(REng::MeshGeomGenerator::getSingleton().getUnitPlane());
		REng::RenderMatrixManager::getSingleton().popModel();
		mVoronoiPtr->deactivateScreenProgram();

		REng::RenderSystem::getSingleton().checkElapsedTime();
		REng::RenderSystem::getSingleton().swapFrame(false);
		return true;
	}

	Vector2 mMousePos;
	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_SPACE) mVoronoiPtr->setIsSeedsDynamic(!mVoronoiPtr->getIsSeedsDynamic());
		if(arg.key == OIS::KC_R) mVoronoiPtr->fillRandomSeeds(RANDOM_SEED_COUNT);
		// generator options
		if(arg.key == OIS::KC_1) mVoronoiPtr->setDistMetricType(EVOR_DISTMET_EUC);
		if(arg.key == OIS::KC_2) mVoronoiPtr->setDistMetricType(EVOR_DISTMET_MAN);
		if(arg.key == OIS::KC_3) mVoronoiPtr->setIterationType(EVOR_ITER_JFA);
		if(arg.key == OIS::KC_4) mVoronoiPtr->setIterationType(EVOR_ITER_1P_JFA);
		if(arg.key == OIS::KC_5) mVoronoiPtr->setIterationType(EVOR_ITER_JFA_1P);
		if(arg.key == OIS::KC_6) mVoronoiPtr->setIterationType(EVOR_ITER_JFA_2);
		if(arg.key == OIS::KC_7) mVoronoiPtr->setIterationType(EVOR_ITER_FLOOD);
		if(arg.key == OIS::KC_8) mVoronoiPtr->setIterationType(EVOR_ITER_3P_JFA);
		if(arg.key == OIS::KC_9) mVoronoiPtr->setIterationType(EVOR_ITER_JFA_3P);
		if(arg.key == OIS::KC_0) mVoronoiPtr->setIterationType(EVOR_ITER_3P_JFA_3P);
		// renderer options
		if(arg.key == OIS::KC_Q) mVoronoiPtr->setDisplaySeedPos(!mVoronoiPtr->getDisplaySeedPos());
		if(arg.key == OIS::KC_W) mVoronoiPtr->setDisplayRegions(!mVoronoiPtr->getDisplayRegions());
		if(arg.key == OIS::KC_T) mVoronoiPtr->setDisplayVoroEdges(!mVoronoiPtr->getDisplayVoroEdges());
		if(arg.key == OIS::KC_Y) mVoronoiPtr->setDisplayHLType(EVOR_DISTHL_NONE);
		if(arg.key == OIS::KC_U) mVoronoiPtr->setDisplayHLType(EVOR_DISTHL_ISOLINE);
		if(arg.key == OIS::KC_I) mVoronoiPtr->setDisplayHLType(EVOR_DISTHL_TRANS_NEG);
		if(arg.key == OIS::KC_O) mVoronoiPtr->setDisplayHLType(EVOR_DISTHL_TRANS_POS);
		return true;
	}
};

int main(){
	new VoronoiApp();
	return VoronoiApp::getSingleton().run();
}
