#ifndef _VORONOI_SOLVER_H
#define _VORONOI_SOLVER_H

#include <REng/REng.h>
#include <vector>

enum EVorIterationType {
	EVOR_ITER_JFA    = 1,    // standard JFA
	EVOR_ITER_1P_JFA = 2,    // 1+JFA
	EVOR_ITER_JFA_1P = 3,    // JFA+1
	EVOR_ITER_FLOOD  = 4,    // standard flooding
	EVOR_ITER_JFA_2  = 5,    // JFA2 (JFA+JFA)
	EVOR_ITER_3P_JFA = 6,    // 3+JFA
	EVOR_ITER_JFA_3P = 7,    // JFA+3
	EVOR_ITER_3P_JFA_3P = 8  // 3+JFA+3
};

enum EVorDispDistHL {
	EVOR_DISTHL_NONE      = 0, // No highlights
	EVOR_DISTHL_ISOLINE   = 1, // Display iso-lines
	EVOR_DISTHL_TRANS_POS = 2, // display positive distance transform
	EVOR_DISTHL_TRANS_NEG = 3  // display negative distance transform
};

enum EVorDistMetricType {
	EVOR_DISTMET_EUC = 0, // Euclidean Distance Sqr
	EVOR_DISTMET_MAN = 1  // Manhattan distance
};

// an instance of this object can be created and used to calculate and display Voronoi diagrams.
class VoronoiTexture2D{
public:
	// param resolution : sample count along an edge (Voronoi is a square image)
	VoronoiTexture2D();
	~VoronoiTexture2D();

	// OpenGL shader programs are static data (shared between different solver instances)
	static void loadVoronoiPrograms();

	// ********************
	// GET'TERS AND SET'TERS

	// Dynamic seeds update their location in each update call
	bool getIsSeedsDynamic() const { return mIsSeedsDynamic; }
	bool getDisplaySeedPos() const { return mVisDispSeed; }
	EVorDispDistHL getDisplayHLType() const { return mVisDistHLType; }
	bool getDisplayVoroEdges() const { return mVisDispEdge; }
	bool getDisplayRegions() const { return mVisDispRegion; }

	void setIsSeedsDynamic(bool val);
	void setDisplaySeedPos(bool val);
	void setDisplayHLType(EVorDispDistHL val);
	void setDisplayVoroEdges(bool val);
	void setDisplayRegions(bool val);
	void setVisDistHLMax(float val);
	void setVisDistHLMin(float val);
	void setVisDistHLClr(float r, float g, float b);

	void setIterationType(EVorIterationType type);
	void setDistMetricType(EVorDistMetricType type);

	// creates buffers, makes FBO ready
	// param: resolution : the resolution of the Voronoi solver.
	void init(unsigned short resolution);

	void update(float timeSec);

	void initRenderingContext();
	void clearRenderingContext();

	void activateScreenProgram();
	void deactivateScreenProgram();

	void insertSeedPosition(const REng::Vector2& seedPos);
	void dragLastSeed(const REng::Vector2& seedPos);

	// fills in the point seed data randomly
	void fillRandomSeeds(size_t seedCount);

	void logVoroFromTexture();
	void logVoroFromPixmap_Direct();
	void logVoroFromPixmap_Mapped();

private:

	EVorIterationType mIterationType;
	EVorDistMetricType mDistMetricType;

	// the resolution of discretized Voronoi Diagram (texture size)
	unsigned short mResolution;

	// if true, seed locations are dynamically updated
	bool mIsSeedsDynamic;

	// if dirty, Voronoi diagram must be recalculated
	bool mVoronoiDirty;
	// if some seed position is changed, set this value true (used by data generators)
	bool mSeedPosDirty;
	// if seed count is changed, set this value true (used by data generators)
	bool mSeedCountDirty;

	GLfloat* mSeedPosPixelData;
	GLubyte* mSeedColorPixelData;
	GLfloat* mVoronoiInitPixelData;

	// if 1 => 1 is source, 0 is target
	// if 0 => 0 is source, 1 is target
	bool mPingPongState;

	REng::GPUTexture *mVoronoiTexP1;    // pointer to single texture
	REng::GPUTexture *mVoronoiTexP2;    // pointer to single texture
	REng::GPUTexture *mSeedPositionTex; // pointer to single texture
	REng::GPUTexture *mSeedColorTex;    // pointer to single texture
	REng::GPUTexture& getVoronoiFinalTex();

	//! @brief Each Voronoi solver has its own depth render buffer (because the resolutions may vary)
	REng::GPURenderBuffer mDepthRenderBuffer;
	//! @brief Each Voronoi solver has its own framebuffer (because the resolutions may vary)
	REng::GPUFrameBuffer  mFrameBuffer;

	// currently all seeds are point seeds.
	std::vector<REng::Vector2> mSeedLocation;
	// each velocity term is normalized
	std::vector<REng::Vector2> mSeedVelocityList;

	// visualization settings
	EVorDispDistHL mVisDistHLType;
	float mVisDistHLMax;
	float mVisDistHLMin;
	REng::Vector3 mVisDistHLClr;
	bool mVisDispSeed;
	bool mVisDispEdge;
	bool mVisDispRegion;

	// all solvers use the same programs for computation
	static REng::RenderPass *mSolverPass;
	static REng::RenderPass *mRenderPass;

	static REng::RenderProp_Uniform* mStepLengthLoc;
	static REng::RenderProp_Uniform* mDistMetricTypeLoc;
	// used for drawing the Voronoi texture to screen

	// visualization state uniforms
	static REng::RenderProp_Uniform* mVisDispSeedLoc;
	static REng::RenderProp_Uniform* mVisDispEdgesLoc;
	static REng::RenderProp_Uniform* mVisDispRegionLoc;
	static REng::RenderProp_Uniform* mVisDistHLTypeLoc;
	static REng::RenderProp_Uniform* mVisDistHLMaxLoc;
	static REng::RenderProp_Uniform* mVisDistHLMinLoc;
	static REng::RenderProp_Uniform* mVisDistHLClrLoc;
	static REng::RenderProp_Uniform* mVisDistMetTypeLoc;

	//! performs one rendering phase with the given stepLength.
	void jumpIteration(size_t stepLength);

	//! creates texture id's for ping-pong, seed position and seed color textures.
	//! initializes their settings (no data is uploaded here)
	void initTextures();

	// creates the framebuffer and associates it with texture buffers as required
	// Call this only once per Voronoi solver
	void initFrameBuffer();

	float getSeedID(size_t seed_index);

	void initVoroTextureData(REng::GPUTexture& texture, GLfloat* seedData);
	void updateSeedPosTexture(GLfloat* seedPosPixelData);
	void updateSeedColorTexture(GLubyte* seedColorPixelData);

	// for mTexSeedPosID (1D 2 channel float)
	GLfloat* generateSeedPosPixelData();
	// for mTexSeedColorID (1D 3channel unsigned byte)
	GLubyte* generateSeedColorPixelData();
	// for mTexVoroPingPong (2D 1channel float)
	GLfloat* generateVoronoiInitData();

	void generateVoronoi();
};


#endif
