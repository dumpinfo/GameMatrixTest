#include "VoronoiTexture2D.h"

#include <REng/Material/Material.h>
#include <REng/Material/MaterialManager.h>
#include <REng/Material/Technique.h>
#include <REng/Defines.h>
#include <REng/RenderMatrixManager.h>

using namespace REng;

REng::RenderPass *VoronoiTexture2D::mSolverPass = 0;
REng::RenderPass *VoronoiTexture2D::mRenderPass = 0;

REng::RenderProp_Uniform* VoronoiTexture2D::mStepLengthLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mDistMetricTypeLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDispSeedLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDistHLTypeLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDispEdgesLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDispRegionLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDistHLMaxLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDistHLMinLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDistHLClrLoc;
REng::RenderProp_Uniform* VoronoiTexture2D::mVisDistMetTypeLoc;

VoronoiTexture2D::VoronoiTexture2D(){
	mResolution = 0;

	// texel data
	mSeedPosPixelData = 0;
	mSeedColorPixelData = 0;
	mVoronoiInitPixelData = 0;
}

VoronoiTexture2D::~VoronoiTexture2D(){ ; }

void VoronoiTexture2D::loadVoronoiPrograms(){
	// make sure this function is executed only once
	EXEC_ONCE_BEGIN();

	REng::MaterialScriptParser::getSingleton().parseFile("materials/voronoi.material");
	REng::MaterialManager& RMM(REng::MaterialManager::getSingleton());
	RMM.compileMaterialShaders();
	RMM.loadMaterials();

	REng::Material *material = RMM.getMaterial("vorSolverMaterial").get();
	if(material == 0) {
		return;
	}
	mSolverPass = material->getSuitableData()->getRenderPass();
	material = RMM.getMaterial("vorRenderMaterial").get();
	if(material == 0) {
		return;
	}
	mRenderPass = material->getSuitableData()->getRenderPass();

	assert(mSolverPass);
	assert(mRenderPass);

	mStepLengthLoc     = mSolverPass->getUniformProperty("stepLength");
	mDistMetricTypeLoc = mSolverPass->getUniformProperty("distMetric");

	mVisDispSeedLoc    = mRenderPass->getUniformProperty("dispSeed");
	mVisDistHLTypeLoc  = mRenderPass->getUniformProperty("dispHLType");
	mVisDispEdgesLoc   = mRenderPass->getUniformProperty("dispVoroEdges");
	mVisDispRegionLoc  = mRenderPass->getUniformProperty("dispRegionColors");
	mVisDistMetTypeLoc = mRenderPass->getUniformProperty("distMetric");
	mVisDistHLMaxLoc   = mRenderPass->getUniformProperty("distHLMaxLength");
	mVisDistHLMinLoc   = mRenderPass->getUniformProperty("distHLMinLength");
	mVisDistHLClrLoc   = mRenderPass->getUniformProperty("distHLColor");

	EXEC_ONCE_END();
}


void VoronoiTexture2D::init(unsigned short resolution){
	mResolution = resolution;

	fillRandomSeeds(50);
	initTextures();
	initFrameBuffer();

	// generate color data only once
	generateSeedColorPixelData();

	mSeedPosDirty = true;
	mVoronoiDirty = true;
	mSeedCountDirty = true;

	// create space for initial Voronoi Data. (updated in each resolution
	mVoronoiInitPixelData = (GLfloat*) malloc(mResolution*mResolution* sizeof(GLfloat));

	mIsSeedsDynamic = true;
	mIterationType = EVOR_ITER_1P_JFA;
	mDistMetricType = EVOR_DISTMET_EUC;

	// init display settings
	mVisDistHLType = EVOR_DISTHL_NONE;
	mVisDistHLMin = 0.0f;
	mVisDistHLMax = 0.05f;
	mVisDistHLClr = REng::Vector3(0.1f,0.1f,0.1f);
	mVisDispSeed = true;
	mVisDispEdge = true;
	mVisDispRegion = true;
}

void VoronoiTexture2D::initTextures(){
	// INIT VORONOI TEXTURES
	mVoronoiTexP1 = new GPUTexture(TextureType_2D);
	mVoronoiTexP1->setInternalFormat(ImageFormat_R32F);
	mVoronoiTexP1->setMagFilter(MagFilter_Nearest);
	mVoronoiTexP1->setMinFilter(MinFilter_Nearest);
	mVoronoiTexP1->setWrap(WrapAxis_S, WrapMode_ClampToEdge);
	mVoronoiTexP1->setWrap(WrapAxis_T, WrapMode_ClampToEdge);
	mVoronoiTexP1->updateSamplerState();
	initVoroTextureData(*mVoronoiTexP1,0/*data not set*/);

	mVoronoiTexP2 = new GPUTexture(TextureType_2D);
	mVoronoiTexP2->setInternalFormat(ImageFormat_R32F);
	mVoronoiTexP2->setMagFilter(MagFilter_Nearest);
	mVoronoiTexP2->setMinFilter(MinFilter_Nearest);
	mVoronoiTexP2->setWrap(WrapAxis_S, WrapMode_ClampToEdge);
	mVoronoiTexP2->setWrap(WrapAxis_T, WrapMode_ClampToEdge);
	mVoronoiTexP2->updateSamplerState();
	initVoroTextureData(*mVoronoiTexP2,0/*data not set*/);

	// INIT SEED POSITION TEXTURE
	mSeedPositionTex = new GPUTexture(TextureType_1D);
	mSeedPositionTex->setInternalFormat(ImageFormat_RGB32F);
	mSeedPositionTex->setMagFilter(MagFilter_Nearest);
	mSeedPositionTex->setMinFilter(MinFilter_Nearest);
	mSeedPositionTex->setWrap(WrapAxis_S, WrapMode_ClampToEdge);
	mSeedPositionTex->updateSamplerState();
	updateSeedPosTexture(0/*data not set*/);

	// INIT SEED COLOR TEXTURE
	mSeedColorTex = new REng::GPUTexture(TextureType_1D);
	mSeedColorTex->setInternalFormat(ImageFormat_RGB);
	mSeedColorTex->setMagFilter(MagFilter_Nearest);
	mSeedColorTex->setMinFilter(MinFilter_Nearest);
	mSeedColorTex->setWrap(WrapAxis_S, WrapMode_ClampToEdge);
	mSeedColorTex->updateSamplerState();
	updateSeedColorTexture(0/*data not set*/);
}

void VoronoiTexture2D::initFrameBuffer(){
	mDepthRenderBuffer.storage(REng::ImageFormat_D,mResolution,mResolution);
	REng::GPURenderBuffer::unbindResource();

	mFrameBuffer.bindResource();

	mDepthRenderBuffer.attachToActiveFBO();
	mVoronoiTexP1->attachToActiveFBO(FrameBufferAttachType_Color0);
	mVoronoiTexP2->attachToActiveFBO(FrameBufferAttachType_Color1);

	// check FBO status
	GLenum tmp;
	mFrameBuffer.isComplete(tmp);
	REng::GPUFrameBuffer::unbindResource();
}

REng::GPUTexture& VoronoiTexture2D::getVoronoiFinalTex(){
	if(mPingPongState==0)
		return *mVoronoiTexP1;
	else
		return *mVoronoiTexP2;
}

/***************************************
 **  TEXTURE DATA LOADERS
 ***************************************/

void VoronoiTexture2D::initVoroTextureData(REng::GPUTexture& texture, GLfloat* seedData){
	texture.loadFromMemToResource(
		mResolution,mResolution,PixelDataType_Float, PixelDataFormat_R, seedData);
}

void VoronoiTexture2D::updateSeedPosTexture(GLfloat* seedPosPixelData){
	mSeedPositionTex->loadFromMemToResource(
		mSeedLocation.size(),0,PixelDataType_Float, PixelDataFormat_RGB,seedPosPixelData );
}

void VoronoiTexture2D::updateSeedColorTexture(GLubyte* seedColorPixelData){
	mSeedColorTex->loadFromMemToResource(
		mSeedLocation.size(),0,PixelDataType_UByte, PixelDataFormat_RGB,seedColorPixelData );
}


void VoronoiTexture2D::fillRandomSeeds(size_t seedCount){
	mSeedLocation.clear();
	mSeedVelocityList.clear();

	for(size_t i=0 ; i<seedCount ; i++){
		REng::Vector2 vel(rand()%100-50, rand()%100-50);
		vel.normalize();
		mSeedVelocityList.push_back(vel);
		REng::Vector2 pos(rand()%1024/1024.0f, rand()%1024/1024.0f);
		mSeedLocation.push_back(pos);
	}

	mSeedCountDirty = true;
	mSeedPosDirty = true;
	mVoronoiDirty = true;
}

void VoronoiTexture2D::insertSeedPosition(const REng::Vector2& seedPos){
	// validate seed position
	if( seedPos[0]<0.0f || seedPos[1] < 0.0f || seedPos[0] >1.0f || seedPos[1] > 1.0f ) return;

	mSeedLocation.push_back(seedPos);

	// generate a random speed
	REng::Vector2 vel(rand()%100-50, rand()%100-50);
	vel.normalize();
	mSeedVelocityList.push_back(vel);

	// update the seed position and seed color textures
	mSeedCountDirty = true;
	mSeedPosDirty = true;
	mVoronoiDirty = true;
}

void VoronoiTexture2D::dragLastSeed(const REng::Vector2& seedPos){
	// validate seed position
	if( seedPos[0]<0.0f || seedPos[1] < 0.0f || seedPos[0] >1.0f || seedPos[1] > 1.0f ) return;

	mSeedLocation[mSeedLocation.size()-1] = seedPos ;

	// update the seed position and seed color textures
	mSeedPosDirty = true;
	mVoronoiDirty = true;
}

void VoronoiTexture2D::generateVoronoi(){
	initRenderingContext();

	if(mSeedPosDirty){
		updateSeedPosTexture(generateSeedPosPixelData());
	}
	if(mSeedCountDirty){
		updateSeedColorTexture(mSeedColorPixelData);
	}

	// create initial Voronoi data (seed locations holds seed id's)
	if(mSeedPosDirty || mSeedCountDirty)
		generateVoronoiInitData();
	initVoroTextureData(*mVoronoiTexP1,mVoronoiInitPixelData);

	// clear Voronoi texture 2

	mPingPongState = false;

	// 2. iteration steps
	// You can performs step-length based variants of jump flooding here

	size_t stepLength;
	switch(mIterationType){
		case EVOR_ITER_JFA:
			stepLength = mResolution/2;
			while(stepLength>0){
				jumpIteration(stepLength);
				stepLength = stepLength/2;
			}
			break;
		case EVOR_ITER_1P_JFA:
			jumpIteration(1);
			stepLength = mResolution/2;
			while(stepLength>0){
				jumpIteration(stepLength);
				stepLength = stepLength/2;
			}
			break;
		case EVOR_ITER_3P_JFA:
			for(int i=0; i<3 ; i++)
				jumpIteration(1);
			stepLength = mResolution/2;
			while(stepLength>0){
				jumpIteration(stepLength);
				stepLength = stepLength/2;
			}
			break;
		case EVOR_ITER_JFA_3P:
			stepLength = mResolution/2;
			while(stepLength>0){
				jumpIteration(stepLength);
				stepLength = stepLength/2;
			}
			for(int i=0; i<3 ; i++)
				jumpIteration(1);
			break;
		case EVOR_ITER_3P_JFA_3P:
			for(int i=0; i<3 ; i++)
				jumpIteration(1);
			stepLength = 1;
			while(stepLength<=mResolution/2){
				jumpIteration(stepLength);
				stepLength = stepLength*2;
			}
			break;
		case EVOR_ITER_JFA_1P:
			stepLength = mResolution/2;
			while(stepLength>0){
				jumpIteration(stepLength);
				stepLength = stepLength/2;
			}
			break;
			jumpIteration(1);
		case EVOR_ITER_FLOOD:
			// limit is actually mResolution, but it is very very slow then!!
			for(int i=0; i<mResolution/2; i++ )
				jumpIteration(1);
			break;
		case EVOR_ITER_JFA_2:
			for(int i=0;i<2;i++){
				stepLength = mResolution/2;
				while(stepLength>0){
					jumpIteration(stepLength);
					stepLength = stepLength/2;
				}
			}
			break;
		default:
			break;
	}

	clearRenderingContext();
}


void VoronoiTexture2D::jumpIteration(size_t stepLength){
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
	glDrawBuffer(GL_COLOR_ATTACHMENT0 + !mPingPongState);

	// bind the source texture to (active texture unit must be 0)
	getVoronoiFinalTex().bindResource();

	glClear(GL_COLOR_BUFFER_BIT);

	// set step length uniform
	mStepLengthLoc->setDataAtIndex(0,(1.0f/mResolution)*stepLength);
	mStepLengthLoc->activate();

	// off we go... (draw filler quad)
	REng::GPUDrawer::getSingleton().drawMeshGeom(REng::MeshGeomGenerator::getSingleton().getUnitPlane());

	// swap textures
	mPingPongState = !mPingPongState;
#endif // RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
}

void VoronoiTexture2D::setIsSeedsDynamic(bool val) {
	mIsSeedsDynamic = val;
}
void VoronoiTexture2D::setDisplaySeedPos(bool val){
	mVisDispSeed = val;
}
void VoronoiTexture2D::setDisplayHLType(EVorDispDistHL val){
	mVisDistHLType = val;
}
void VoronoiTexture2D::setDisplayVoroEdges(bool val){
	mVisDispEdge = val;
}
void VoronoiTexture2D::setDisplayRegions(bool val){
	mVisDispRegion = val;
}
void VoronoiTexture2D::setVisDistHLMax(float val){
	mVisDistHLMax = val;
}
void VoronoiTexture2D::setVisDistHLMin(float val){
	mVisDistHLMin = val;
}
void VoronoiTexture2D::setVisDistHLClr(float r, float g, float b){
	mVisDistHLClr = REng::Vector3(r,g,b);
}
void VoronoiTexture2D::setIterationType(EVorIterationType type){
	mIterationType = type;
	mVoronoiDirty = true;
}
void VoronoiTexture2D::setDistMetricType(EVorDistMetricType type){
	mDistMetricType = type;
	mVoronoiDirty = true;
}

int tmpVPInfo[4];
void VoronoiTexture2D::initRenderingContext(){
	REng::Matrix4 m;
	glGetIntegerv(GL_VIEWPORT,tmpVPInfo);
	glViewport(0,0,mResolution,mResolution);

	REng::RenderMatrixManager& RRMM(REng::RenderMatrixManager::getSingleton());
	RRMM.pushProjection();
	RRMM.pushView();
	RRMM.pushModel();

	cml::matrix_orthographic_RH(m, -1.0f, +1.0f, -1.0f, +1.0f, -1.0f, +1.0f, cml::z_clip_neg_one);
	RRMM.setProjection(m,true);
	cml::matrix_look_at_RH(m,0.0f,0.0f,1.0f/*pos*/,0.0f,0.0f,0.0f/*target*/,0.0f,1.0f,0.0f/*up*/);
	RRMM.setView(m,true);
	RRMM.setModel(cml::identity_4x4(),true);

	mFrameBuffer.bindResource();
	mSolverPass->prepareState();

	// bind the source texture to texture unit 1 (data is constant through iterations)
	GPUTexture::setActiveTextureUnit(1);
	mSeedPositionTex->bindResource();

	// remaining updates will only be done to texture 0 (which is source Voronoi texture)
	GPUTexture::setActiveTextureUnit(0);

	mDistMetricTypeLoc->setDataAtIndex(0,mDistMetricType);
	mDistMetricTypeLoc->activate();

	CHECKGLERROR_TERM();
}

void VoronoiTexture2D::clearRenderingContext(){
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
	glViewport(tmpVPInfo[0],tmpVPInfo[1],tmpVPInfo[2],tmpVPInfo[3]);
	REng::RenderMatrixManager::getSingleton().popProjection();
	REng::RenderMatrixManager::getSingleton().popView();
	REng::RenderMatrixManager::getSingleton().popModel();

	mSolverPass->clearState();
	mFrameBuffer.unbindResource();

	glDrawBuffer(GL_BACK);
#endif // RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
}

void VoronoiTexture2D::activateScreenProgram(){
	if(mRenderPass){
		GPUTexture::setActiveTextureUnit(0);
		getVoronoiFinalTex().bindResource();

		GPUTexture::setActiveTextureUnit(1);
		mSeedColorTex->bindResource();

		GPUTexture::setActiveTextureUnit(2);
		mSeedPositionTex->bindResource();

		mRenderPass->prepareState();

		mVisDistMetTypeLoc->setDataAtIndex(0,mDistMetricType);
		mVisDispSeedLoc->setDataAtIndex(0,mVisDispSeed);
		mVisDispEdgesLoc->setDataAtIndex(0,mVisDispEdge);
		mVisDispRegionLoc->setDataAtIndex(0,mVisDispRegion);
		mVisDistHLTypeLoc->setDataAtIndex(0,mVisDistHLType);
		mVisDistHLMinLoc->setDataAtIndex(0,mVisDistHLMin);
		mVisDistHLMaxLoc->setDataAtIndex(0,mVisDistHLMax);
		float tmp[4] = {mVisDistHLClr[0], mVisDistHLClr[1], mVisDistHLClr[2], 1.0f};
		mVisDistHLClrLoc->setData(tmp,sizeof(tmp));

		mVisDistMetTypeLoc->activate();
		mVisDispSeedLoc->activate();
		mVisDispEdgesLoc->activate();
		mVisDispRegionLoc->activate();
		mVisDistHLTypeLoc->activate();
		mVisDistHLMinLoc->activate();
		mVisDistHLMaxLoc->activate();
		mVisDistHLClrLoc->activate();

	}
}
void VoronoiTexture2D::deactivateScreenProgram(){
	if(mRenderPass){
		mRenderPass->clearState();
	}
}

float VoronoiTexture2D::getSeedID(size_t seedIndex) {
	return (float)seedIndex / (float)mSeedLocation.size();
}

// using mPointSeedLocation only, create the data which will be given to OpenGL
GLfloat* VoronoiTexture2D::generateSeedPosPixelData(){
	size_t seedCount = mSeedLocation.size();
	if(mSeedCountDirty){
		if(mSeedPosPixelData) free(mSeedPosPixelData);
		mSeedPosPixelData = (GLfloat*) malloc(sizeof(GLfloat)*seedCount*3);
	}
	float texStepSize = 1.0f/mResolution;
	for(size_t seedNo=0 ; seedNo<seedCount; seedNo++){
		GLfloat posS(mSeedLocation[seedNo][0]);
		GLfloat posT(mSeedLocation[seedNo][1]);
		// make sure they correspond to texture coordinates
		posS = ((int)(posS/texStepSize))*texStepSize;
		posT = ((int)(posT/texStepSize))*texStepSize;
		size_t tmpIndex = 3*seedNo;
		mSeedPosPixelData[tmpIndex+0] = posS;
		mSeedPosPixelData[tmpIndex+1] = posT;
	}
	return mSeedPosPixelData;
}

GLubyte* VoronoiTexture2D::generateSeedColorPixelData(){
	// only fill color data once
	if(mSeedColorPixelData==0){
		size_t seedCount = 10000;
		mSeedColorPixelData = (GLubyte*) malloc(sizeof(GLubyte)*seedCount*3);
		// each channel data is random
		size_t dataCount = seedCount*3;
		for(size_t i=0 ; i<dataCount; i++)
			mSeedColorPixelData[i+0] = rand() % 256;
	}
	return mSeedColorPixelData;
}

GLfloat* VoronoiTexture2D::generateVoronoiInitData(){
	size_t texelCount = mResolution*mResolution;

	// fill all texture with invalid seed index (1.0)
	for(size_t curIndex = 0; curIndex < texelCount; curIndex++){
		mVoronoiInitPixelData[curIndex] = 1.0f;
	}

	// fill in the seed id's in their seed locations
	size_t seedCount = mSeedLocation.size();
	for(size_t seedNo=0 ; seedNo<seedCount; seedNo++){
		float seedID = getSeedID(seedNo);
		size_t rowPos = mSeedLocation[seedNo][1]*mResolution-1;
		size_t colPos = mSeedLocation[seedNo][0]*mResolution-1;
		size_t dataIndex = colPos + rowPos * mResolution;
		mVoronoiInitPixelData[dataIndex] = seedID;
	}
	return mVoronoiInitPixelData;
}

void VoronoiTexture2D::update(float timeSec){
	if(timeSec > 1.0f) return;

	if(mIsSeedsDynamic == true) {
		size_t numOfSeeds = mSeedLocation.size();
		float normSec = timeSec * 0.3f;
		for(size_t curSeed=0 ; curSeed < numOfSeeds ; curSeed++){
			// update seed positions
			REng::Vector2 nextPos = mSeedLocation[curSeed] + normSec*mSeedVelocityList[curSeed];
			if(nextPos[0]>=1.0f || nextPos[0]<0.0f)
				mSeedVelocityList[curSeed][0] = -mSeedVelocityList[curSeed][0];
			if(nextPos[1]>=1.0f || nextPos[1]<0.0f)
				mSeedVelocityList[curSeed][1] = -mSeedVelocityList[curSeed][1];

			if(nextPos[0]>1.0f) nextPos[0]=1.0f;
			if(nextPos[0]<0.0f) nextPos[0]=0.0f;
			if(nextPos[1]>1.0f) nextPos[1]=1.0f;
			if(nextPos[1]<0.0f) nextPos[1]=0.0f;
			mSeedLocation[curSeed] = nextPos;
		}
		mSeedPosDirty = true;
		mVoronoiDirty = true;
	}
	
	if(mVoronoiDirty)
		generateVoronoi();

	mVoronoiDirty = false;
	mSeedPosDirty = false;
	mSeedCountDirty = false;
}

