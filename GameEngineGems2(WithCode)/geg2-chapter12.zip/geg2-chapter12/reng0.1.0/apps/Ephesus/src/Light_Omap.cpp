#include "Light_Omap.h"

#if RENG_PLATFORM == RENG_PLATFORM_OMAP

#include "REng/REng.h"

using namespace REng;

REGISTER_LIGHT(Light_Sun_Omap);
REGISTER_LIGHT(Light_Point_Omap);
REGISTER_LIGHT(Light_Spot_Omap);

/************************************************************************/
/* SUN LIGHT                                                            */
/************************************************************************/
Light_Sun_Omap::Light_Sun_Omap(LightNode& node)
	:Light_Base(node),
	mColor(Color_Real(1.0,0.0f,0.0f,1.0f))
{ ; }
Light_Sun_Omap& Light_Sun_Omap::create(LightNode& node){
	Light_Sun_Omap* l = new Light_Sun_Omap(node);
	LightingManager::getSingleton().registerLightToScene(*l);
	return *l;
}
void Light_Sun_Omap::setColor(Color_Real color){
	mColor = color;
	mDirtyFlags = mDirtyFlags | Dirty_Color;
}
Color_Real Light_Sun_Omap::getColor() const{
	return mColor;
}

const char* Light_Sun_Omap::mShaderStructCode = "";
const char* Light_Sun_Omap::getShaderStructCode(){
	return mShaderStructCode;
}
bool Light_Sun_Omap::synchWithPass(RenderPass& pass){
	#ifdef _RENG_DEBUG_BUILD_
		if(mSynchLightIndex >= LightingManager::MaxNumOfLights_PerType){
			// TODO: log warning to a file...
			return false;
		}
	#endif
	bool toRet1 = synchColor(pass);
	bool toRet2 = synchDirection(pass);
	return toRet1 || toRet2;
}
bool Light_Sun_Omap::synchColor(RenderPass& pass){
	sprintf(_uniformName_Param,"re_SunLights_color[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_SunLights_color");
	if(unif==0) return false;
	unif->setDataAtIndex(0,mColor.r);
	unif->setDataAtIndex(1,mColor.g);
	unif->setDataAtIndex(2,mColor.b);
	unif->setDataAtIndex(3,mColor.a);
	return true;
}
bool Light_Sun_Omap::synchDirection(RenderPass& pass){
	// TODO: if not dirty, do not synch
	sprintf(_uniformName_Param,"re_SunLights_direction[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_SunLights_direction");
	if(unif==0) return false;
	const Vector3& dir(getDirection());
	unif->setDataAtIndex(0,dir[0]);
	unif->setDataAtIndex(1,dir[1]);
	unif->setDataAtIndex(2,dir[2]);
	return true;
}
bool Light_Sun_Omap::registerFunc(){
	char varName[64];
	sprintf(varName,"uniform highp vec4 re_SunLights_color[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_SunLights_direction[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	return true;
}

/************************************************************************/
/* POINT LIGHT                                                          */
/************************************************************************/
Light_Point_Omap::Light_Point_Omap(LightNode& node)
	:Light_Base(node) , 
	mColor(Color_Real(1.0,0.0f,0.0f,1.0f)),
	mAttenPos_Constant(1),
	mAttenPos_Linear(0),
	mAttenPos_Quadric(0)
{
	// TODO
}
Light_Point_Omap& Light_Point_Omap::create(LightNode& node){
	Light_Point_Omap* l = new Light_Point_Omap(node);
	LightingManager::getSingleton().registerLightToScene(*l);
	return *l;
}
void Light_Point_Omap::setColor(Color_Real color){
	mColor = color;
	mDirtyFlags = mDirtyFlags | Dirty_Color;
}
Color_Real Light_Point_Omap::getColor() const{
	return mColor;
}
void Light_Point_Omap::setAttenPosFactors(float _cons, float _linear, float _quadric){
	mAttenPos_Constant = _cons;
	mAttenPos_Linear   = _linear;
	mAttenPos_Quadric  = _quadric;
	mDirtyFlags = mDirtyFlags | Dirty_AttenPos;
}
void Light_Point_Omap::getAttenPosFactors(float& _cons, float& _linear, float& _quadric){
	_cons    = mAttenPos_Constant;
	_linear  = mAttenPos_Linear;
	_quadric = mAttenPos_Quadric;
}
const char* Light_Point_Omap::mShaderStructCode = "";
const char* Light_Point_Omap::getShaderStructCode(){
	return mShaderStructCode;
}
bool Light_Point_Omap::synchWithPass(RenderPass& pass){
	#ifdef _RENG_DEBUG_BUILD_
	if(mSynchLightIndex >= LightingManager::MaxNumOfLights_PerType){
		// TODO: log to a file...
		return;
	}
	#endif
	bool toRet1 = synchColor(pass);
	bool toRet2 = synchPosition(pass);
	bool toRet3 = synchAttenuation(pass);
	return toRet1 || toRet2 || toRet3;
}
bool Light_Point_Omap::synchColor(RenderPass& pass){
	sprintf(_uniformName_Param,"re_PointLights_color[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_PointLights_color");
	if(unif==0) return false;
	unif->setDataAtIndex(0,mColor.r);
	unif->setDataAtIndex(1,mColor.g);
	unif->setDataAtIndex(2,mColor.b);
	unif->setDataAtIndex(3,mColor.a);
	return true;
}
bool Light_Point_Omap::synchPosition(RenderPass& pass){
	// TODO: if not dirty, do not synch
	sprintf(_uniformName_Param,"re_PointLights_position[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_PointLights_position");
	if(unif==0) return false;
	const Vector3& pos(getPosition());
	unif->setDataAtIndex(0,pos[0]);
	unif->setDataAtIndex(1,pos[1]);
	unif->setDataAtIndex(2,pos[2]);
	return true;
}
bool Light_Point_Omap::synchAttenuation(RenderPass& pass){
//		if( (mDirtyFlags&Dirty_AttenPos) == 0) return;
	sprintf(_uniformName_Param,"re_PointLights_attenPos[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_PointLights_attenPos");
	if(unif==0) return false;
	unif->setDataAtIndex(0,mAttenPos_Constant);
	unif->setDataAtIndex(1,mAttenPos_Linear);
	unif->setDataAtIndex(2,mAttenPos_Quadric);
	return true;
}
bool Light_Point_Omap::registerFunc(){
	char varName[64];
	sprintf(varName,"uniform highp vec4 re_PointLights_color[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_PointLights_position[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_PointLights_attenPos[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	return true;
}

/************************************************************************/
/* SPOT LIGHT                                                           */
/************************************************************************/
Light_Spot_Omap::Light_Spot_Omap(LightNode& node)
	:Light_Base(node) , 
	mColor(Color_Real(1.0,0.0f,0.0f,1.0f)),
	mAttenPos_Constant(1),
	mAttenPos_Linear(0),
	mAttenPos_Quadric(0),
	mFalloffExponent(0),
	mCutoffAngle(AngleDegree(45))
{
	// TODO
}
Light_Spot_Omap& Light_Spot_Omap::create(LightNode& node){
	Light_Spot_Omap* l = new Light_Spot_Omap(node);
	LightingManager::getSingleton().registerLightToScene(*l);
	return *l;
}
void Light_Spot_Omap::setColor(Color_Real color){
	mColor = color;
	mDirtyFlags = mDirtyFlags | Dirty_Color;
}
Color_Real Light_Spot_Omap::getColor() const{
	return mColor;
}
void Light_Spot_Omap::setAttenPosFactors(float _cons, float _linear, float _quadric){
	mAttenPos_Constant = _cons;
	mAttenPos_Linear   = _linear;
	mAttenPos_Quadric  = _quadric;
	mDirtyFlags = mDirtyFlags | Dirty_AttenPos;
}
void Light_Spot_Omap::getAttenPosFactors(float& _cons, float& _linear, float& _quadric){
	_cons    = mAttenPos_Constant;
	_linear  = mAttenPos_Linear;
	_quadric = mAttenPos_Quadric;
}
void Light_Spot_Omap::setAttenDirFactors(float falloffExp, const Angle& cutoffAngle){
	mFalloffExponent = falloffExp;
	mCutoffAngle = cutoffAngle;
	mDirtyFlags = mDirtyFlags | Dirty_AttenDir;
}
void Light_Spot_Omap::getAttenDirFactors(float& falloffExp, Angle& cutoffAngle){
	falloffExp = mFalloffExponent;
	cutoffAngle = mCutoffAngle;
}
const char* Light_Spot_Omap::mShaderStructCode = "";
const char* Light_Spot_Omap::getShaderStructCode(){
	return mShaderStructCode;
}
bool Light_Spot_Omap::synchWithPass(RenderPass& pass){
	#ifdef _RENG_DEBUG_BUILD_
	if(mSynchLightIndex>= LightingManager::MaxNumOfLights_PerType){
		// TODO: log to a file...
		return;
	}
	#endif
	bool toRet1 = synchColor(pass);
	bool toRet2 = synchPosition(pass);
	bool toRet3 = synchDirection(pass);
	bool toRet4 = synchAttenuation(pass);
	return toRet1 || toRet2 || toRet3 || toRet4; 
}
bool Light_Spot_Omap::synchColor(RenderPass& pass){
	sprintf(_uniformName_Param,"re_SpotLights_color[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_SpotLights_color");
	if(unif==0) return false;
	unif->setDataAtIndex(0,mColor.r);
	unif->setDataAtIndex(1,mColor.g);
	unif->setDataAtIndex(2,mColor.b);
	unif->setDataAtIndex(3,mColor.a);
	return true;
}
bool Light_Spot_Omap::synchPosition(RenderPass& pass){
	// TODO: if not dirty, do not synch
	sprintf(_uniformName_Param,"re_SpotLights_position[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_SpotLights_position");
	if(unif==0) return false;
	const Vector3& pos(getPosition());
	unif->setDataAtIndex(0,pos[0]);
	unif->setDataAtIndex(1,pos[1]);
	unif->setDataAtIndex(2,pos[2]);
	return true;
}
bool Light_Spot_Omap::synchDirection(RenderPass& pass){
	// TODO: if not dirty, do not synch
	sprintf(_uniformName_Param,"re_SpotLights_direction[%u]",mSynchLightIndex);
	RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
	if(unif==0) unif = pass.getUniformProperty("re_SpotLights_direction");
	if(unif==0) return false;
	const Vector3& dir(getDirection());
	unif->setDataAtIndex(0,dir[0]);
	unif->setDataAtIndex(1,dir[1]);
	unif->setDataAtIndex(2,dir[2]);
	return true;
}
bool Light_Spot_Omap::synchAttenuation(RenderPass& pass){
	bool toRet = false;
	if( (mDirtyFlags&Dirty_AttenPos) != 0) {
		sprintf(_uniformName_Param,"re_SpotLights_attenPos[%u]",mSynchLightIndex);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) unif = pass.getUniformProperty("re_SpotLights_attenPos");
		if(unif!=0) {
			unif->setDataAtIndex(0,mAttenPos_Constant);
			unif->setDataAtIndex(1,mAttenPos_Linear);
			unif->setDataAtIndex(2,mAttenPos_Quadric);
			toRet = true;
		}
	}
	if( (mDirtyFlags&Dirty_AttenDir) != 0) {
		sprintf(_uniformName_Param,"re_SpotLights_attenDir[%u]",mSynchLightIndex);
		RenderProp_Uniform* unif = pass.getUniformProperty(_uniformName_Param);
		if(unif==0) unif = pass.getUniformProperty("re_SpotLights_attenDir");
		if(unif!=0) {
			unif->setDataAtIndex(0,(float)cos(mCutoffAngle.getRadian()));
			unif->setDataAtIndex(1,mFalloffExponent);
			toRet = true;
		}
	}
	return toRet;
}
bool Light_Spot_Omap::registerFunc(){
	char varName[64];
	sprintf(varName,"uniform highp vec4 re_SpotLights_color[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_SpotLights_position[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_SpotLights_direction[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec3 re_SpotLights_attenPos[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	sprintf(varName,"uniform highp vec2 re_SpotLights_attenDir[%d];",LightingManager::MaxNumOfLights_PerType);
	MaterialShader::addPreText(varName);
	return true;
}

#endif
