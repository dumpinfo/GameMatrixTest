#include "PhotoFrameGroup.h"

#include <boost/foreach.hpp>

#include <cstdlib>

//! A render queue with specialized pre/post processing steps
class RenderQueue_PictFrames : public REng::RenderQueue_Vector {
public:
	static const REng::uchar RenderQueue_PictFrames_ID = 11;
	REng::RenderProp_CullFace cullProp;
	RenderQueue_PictFrames() {
		cullProp.setMode(REng::FaceType_None);
		REng::RenderQueueMap::getSingleton().registerRenderQueue(this,RenderQueue_PictFrames_ID);
	}
	void preRenderQueueProcess(){
		cullProp.activate();
		REng::GPUDrawer::getSingleton().setAttribBatchOn();
	}
	void postRenderQueueProcess(){
		cullProp.deactivate();
		REng::GPUDrawer::getSingleton().setAttribBatchOff();
	}
};

//! A render queue with specialized pre/post processing steps
class RenderQueue_DrawOpt : public REng::RenderQueue_Vector {
public:
	RenderQueue_DrawOpt() {
	}
	void preRenderQueueProcess(){
		REng::GPUDrawer::getSingleton().setAttribBatchOn();
	}
	void postRenderQueueProcess(){
		REng::GPUDrawer::getSingleton().setAttribBatchOff();
	}
};


PhotoFrameGroup::PhotoFrameGroup(){
	mFrameHalfSize = 4.5f;
	mSelectedFrameFocused = false;
	mSelectedFrameAnimating = false;
	mAnimationLock = false;
}


void PhotoFrameGroup::createMeshes(){
	REng::MeshManager& MeshMan(REng::MeshManager::getSingleton());
	REng::MeshGeomGenerator& MeshGeomGen(REng::MeshGeomGenerator::getSingleton());
	mSphereMesh     = MeshMan.createMesh("sphereMesh");
	mSphereMesh_LR2 = MeshMan.createMesh("sphereMesh_LR2");
	mCylMesh1       = MeshMan.createMesh("cylMesh1");
	mCylMesh3       = MeshMan.createMesh("cylMesh3");
	mSphereMesh    ->createLoDGeom(MeshGeomGen.getUnitSphere(3));
	mSphereMesh_LR2->createLoDGeom(MeshGeomGen.getUnitSphere(0));
	mCylMesh1      ->createLoDGeom(MeshGeomGen.getCyclinder(3,0.5));
	mCylMesh3      ->createLoDGeom(MeshGeomGen.getCyclinder(3,1.0));
	// photo meshes
	for(int i=0; i<7 ; i++){
		char meshName[16]; sprintf(meshName,"pixtureMesh%i",i);
		mPictureMeshes[i] = MeshMan.createMesh(meshName);
		mPictureMeshes[i]->createLoDGeom(MeshGeomGen.getUnitPlane());
	}
}

void PhotoFrameGroup::setFrameMaterials(REng::MaterialPtr mat){
	mSphereMesh->mMaterial = mSphereMesh_LR2->mMaterial = 
		mCylMesh1->mMaterial = mCylMesh3->mMaterial =  mat;
}
void PhotoFrameGroup::setDefaultMaterials(){
	setFrameMaterials(REng::MaterialManager::getSingleton().getMaterial("FrameMat"));
	for(int i=0 ; i<7 ; ++i) mPictureMeshes[i%7]->mMaterial = mPictureMaterials[i];
}
void PhotoFrameGroup::setSephiaMaterials(){
	setFrameMaterials(REng::MaterialManager::getSingleton().getMaterial("FrameMat"));
	for(int i=7 ; i<14 ; ++i) mPictureMeshes[i%7]->mMaterial = mPictureMaterials[i];
}

void PhotoFrameGroup::createPictureMaterials(){
	REng::MaterialManager& MatMan(REng::MaterialManager::getSingleton());
	// set mesh materials
	REng::MaterialPtr basicTexMaterial;
	char matName[64];
	int matIndex=0;
	for(int i=0; i<7 ; ++i, ++matIndex){
		sprintf(matName,"Picture_%i",i);
		MatMan.createMaterial(matName  ,mPictureMaterials[matIndex]);
		basicTexMaterial = MatMan.getMaterial("Picture");
		basicTexMaterial->clone(*(mPictureMaterials[matIndex]),true);
	}
	for(int i=0; i<7 ; ++i, ++matIndex){
		sprintf(matName,"Picture_Sephia_%i",i);
		MatMan.createMaterial(matName  ,mPictureMaterials[matIndex]);
		basicTexMaterial = MatMan.getMaterial("PictureSephia");
		basicTexMaterial->clone(*(mPictureMaterials[matIndex]),true);
	}

	// update the texture bindings for the cloned materials
	REng::MaterialTexturePtr pictTexture1 = MatMan.getMaterialTexture("FramePict1_pvr");
	REng::MaterialTexturePtr pictTexture2 = MatMan.getMaterialTexture("FramePict2_pvr");
	REng::MaterialTexturePtr pictTexture3 = MatMan.getMaterialTexture("FramePict3_pvr");
	REng::MaterialTexturePtr pictTexture4 = MatMan.getMaterialTexture("FramePict4_pvr");
	REng::MaterialTexturePtr pictTexture5 = MatMan.getMaterialTexture("FramePict5_pvr");
	REng::MaterialTexturePtr pictTexture6 = MatMan.getMaterialTexture("FramePict6_pvr");
	REng::MaterialTexturePtr pictTexture7 = MatMan.getMaterialTexture("FramePict7_pvr");
	// check if material texture pointers are complete. If not, fall back to common formats
	if(!pictTexture1->isComplete()) pictTexture1 = MatMan.getMaterialTexture("FramePict1");
	if(!pictTexture2->isComplete()) pictTexture2 = MatMan.getMaterialTexture("FramePict2");
	if(!pictTexture3->isComplete()) pictTexture3 = MatMan.getMaterialTexture("FramePict3");
	if(!pictTexture4->isComplete()) pictTexture4 = MatMan.getMaterialTexture("FramePict4");
	if(!pictTexture5->isComplete()) pictTexture5 = MatMan.getMaterialTexture("FramePict5");
	if(!pictTexture6->isComplete()) pictTexture6 = MatMan.getMaterialTexture("FramePict6");
	if(!pictTexture7->isComplete()) pictTexture7 = MatMan.getMaterialTexture("FramePict7");
	for(int i=0 ; i<7*2; ) { 
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture1);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture2);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture3);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture4);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture5);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture6);
		mPictureMaterials[i++]->getSuitableData()->getRenderPass()->setTextureBinding(0,pictTexture7);
	}
}

void PhotoFrameGroup::createSamplePhotoFrame(){
	mFramesRoot = &(REng::GroupNode::create(REng::RootNode::getSingleton()));
	mFramesRoot->translate_World(REng::Vector3(0,-10,0));

	mFrameNodeBasic = &(REng::GroupNode::create(*mFramesRoot));
	mFrameNodeBasic->translate_Parent(REng::Vector3(0,0,-57),true);
	mFrameNodeBasic->mCullingMode = REng::SceneNode::CULL_ALWAYS;
	// corners: sphere, sides: cylinder
	REng::MeshNode* pFrame1_C[4];
	REng::MeshNode* pFrame1_S[4];
	for(int i=0 ; i<4 ; i++) pFrame1_C[i] = &REng::MeshNode::create(*mFrameNodeBasic);
	for(int i=0 ; i<4 ; i++) pFrame1_S[i] = &REng::MeshNode::create(*mFrameNodeBasic);

	// front and back
	REng::MeshNode& pFrame1_F( REng::MeshNode::create(*mFrameNodeBasic));

	{	// set meshes 
		for(int i=0 ; i<4 ; ++i) pFrame1_C[i]->setMesh(mSphereMesh_LR2);
		for(int i=0 ; i<4 ; ++i) pFrame1_S[i]->setMesh(mCylMesh3);
	} {// set render queues
		new RenderQueue_PictFrames();
		REng::RenderQueueMap::getSingleton().registerRenderQueue(new RenderQueue_DrawOpt(),12);
		REng::RenderQueueMap::getSingleton().registerRenderQueue(new RenderQueue_DrawOpt(),13);
		pFrame1_F.setRenderQueueGroupID(11);
		for(int i=0 ; i<4 ; ++i) pFrame1_C[i]->setRenderQueueGroupID(12);
		for(int i=0 ; i<4 ; ++i) pFrame1_S[i]->setRenderQueueGroupID(13);
	} {// set translation and rotations
		for(int i=0 ; i<4 ; i++) pFrame1_C[i]->scale_Parent(0.8f);
		for(int i=0 ; i<4 ; i++) pFrame1_S[i]->scale_Parent(REng::Vector3(0.4f,mFrameHalfSize*2,0.4f));
		pFrame1_C[0]->translate_Parent(REng::Vector3(-mFrameHalfSize,+mFrameHalfSize,0));
		pFrame1_C[1]->translate_Parent(REng::Vector3(-mFrameHalfSize,-mFrameHalfSize,0));
		pFrame1_C[2]->translate_Parent(REng::Vector3(+mFrameHalfSize,-mFrameHalfSize,0));
		pFrame1_C[3]->translate_Parent(REng::Vector3(+mFrameHalfSize,+mFrameHalfSize,0));
		pFrame1_S[0]->translate_Parent(REng::Vector3(-mFrameHalfSize,-mFrameHalfSize,0));
		pFrame1_S[1]->translate_Parent(REng::Vector3(+mFrameHalfSize,-mFrameHalfSize,0));
		pFrame1_S[2]->translate_Parent(REng::Vector3(+mFrameHalfSize,-mFrameHalfSize,0));
		pFrame1_S[3]->translate_Parent(REng::Vector3(+mFrameHalfSize,+mFrameHalfSize,0));
		REng::Quaternion rotZ_pos90;
		cml::quaternion_rotation_world_z(rotZ_pos90,REng::Angle::degree2radian(90));
		pFrame1_S[2]->rotate_World(rotZ_pos90,true);
		pFrame1_S[3]->rotate_World(rotZ_pos90,true);
		pFrame1_F.scale_Parent(mFrameHalfSize);
	}
}

void PhotoFrameGroup::createFrameGroup(REng::uchar colExtend, REng::uchar rowExtend){
	srand(100);
	mColExtend = colExtend;
	mRowSize = rowExtend*2+1;
	mColSize = colExtend*2+1;
	mFrameCount = mRowSize*mColSize;

	mFrameNodes = (REng::GroupNode**) malloc(sizeof(REng::GroupNode*)*mFrameCount);
	for(int i=0 ; i<mFrameCount ; i++) mFrameNodes[i] = &REng::GroupNode::create(*mFramesRoot);
	mDifAngle = REng::AngleDegree(15).getRadian();
	float curAngle = mDifAngle * mColExtend * -1 + REng::AngleDegree(90).getRadian();
	int frameCounter = 0;

	REng::Quaternion rotY_180;
	cml::quaternion_rotation_world_y(rotY_180,REng::Angle::degree2radian(180));

	for(int i=0 ; i<mColSize ; i++) {
		for(int j=0 ; j<mRowSize ; j++, ++frameCounter) {
			REng::ushort frameID = i+j*mColSize;
			// set rotations
			REng::Quaternion rotator;
			cml::quaternion_rotation_world_y(rotator,curAngle);
			mFrameNodes[frameID]->rotate_Parent(rotator);
			REng::GroupNode& pFrame(mFrameNodeBasic->cloneMeshStruct(*(mFrameNodes[i+j*mColSize])));
			pFrame.mCullingMode = REng::SceneNode::CULL_NEVER;
			pFrame.translate_Parent(REng::Vector3(0,15*j,-10*j),false);
			if(j%2==1){
				cml::quaternion_rotation_world_y(rotator,mDifAngle/2.0f);
				mFrameNodes[frameID]->rotate_Parent(rotator,false);
			}
			REng::uchar meshNo( rand()%7);
			((REng::MeshNode*)pFrame.getChildren()[8])->setMesh(mPictureMeshes[meshNo]);
		}
		curAngle += mDifAngle;
	}
}

void PhotoFrameGroup::cullFrames(float viewAngle){
	float difAngle = REng::AngleDegree(15).getRadian();
	float curAngle = difAngle * mColExtend * -1 + REng::AngleDegree(90).getRadian();
	for(int i=0 ; i<mColSize ; i++) {
		bool cullColumn = false;
		if(curAngle<viewAngle-0.85) cullColumn = true;
		if(curAngle>viewAngle+0.75) cullColumn = true;
		for(int j=0 ; j<mRowSize ; j++) {
			if(cullColumn)
				mFrameNodes[i+j*mColSize]->mCullingMode = REng::SceneNode::CULL_ALWAYS;
			else
				mFrameNodes[i+j*mColSize]->mCullingMode = REng::SceneNode::CULL_NEVER;
		}
		curAngle += difAngle;
	}
}

void PhotoFrameGroup::tick(float timeLapse){
	// TODO : selection animations
	BOOST_FOREACH(FrameAnim& anim, mFrameAnims){
		if(anim.isDead) continue;
		REng::SceneNode* sn = mFrameNodes[anim.frameID]->getChildren()[0];
		anim.elapsedTime += timeLapse;
		if(anim.elapsedTime>=0.4f){
			anim.elapsedTime = 0.4f;
			anim.isDead = true;
			REng::ushort selFrameID = mSelectedFrameCol+mSelectedFrameRow*mColSize;
			if(anim.frameID == selFrameID){
				// if anim is magnification...
				if(anim.isFull){
					if(anim.isGettingCloser) {
						mSelectedFrameFocused = true;
					} else {
						mAnimationLock = false;
						mSelectedFrameFocused = false;
					}
				} else {
					mSelectedFrameFocused = false;
				}
				mSelectedFrameAnimating = false;
			}
		}
		float u = anim.elapsedTime / 0.4f;
		REng::Vector2 defaultDistance;
		REng::Vector2 maxDistance;
		if(anim.isFull){
			maxDistance = REng::Vector2(-14,13);
			defaultDistance = REng::Vector2(-25,13);
		} else {
			maxDistance = REng::Vector2(-25,13);
			defaultDistance = REng::Vector2(anim.defaultTrans[2],anim.defaultTrans[1]);
		}
		REng::Vector2 curDistance;
		if(anim.isGettingCloser)
			REng::Interp::Lerp(defaultDistance,maxDistance,u,curDistance);
		else 
			REng::Interp::Lerp(maxDistance,defaultDistance,u,curDistance);
		REng::Vector3 t(sn->getTranslation_Parent());
		t[2] = curDistance[0];
		t[1] = curDistance[1];
		sn->translate_Parent(t,true);
	}
	std::vector<FrameAnim>::iterator iter = mFrameAnims.begin();
	while( iter != mFrameAnims.end() ) {
		if ((*iter).isDead)
			iter = mFrameAnims.erase( iter );
		else
			++iter;
	}
}

void PhotoFrameGroup::closerSelectedFrame(){
	REng::ushort frameID = mSelectedFrameCol+mSelectedFrameRow*mColSize;
	FrameAnim a;
	a.isGettingCloser = true;
	a.isFull = false;
	a.frameID = frameID;
	a.elapsedTime = 0;
	a.isDead = false;
	a.defaultTrans = REng::Vector3(0,0,-57) + 
		              REng::Vector3(0,15*mSelectedFrameRow,-10*mSelectedFrameRow);
	mFrameAnims.push_back(a);
}
void PhotoFrameGroup::fartherSelectedFrame(){
	REng::ushort frameID = mSelectedFrameCol+mSelectedFrameRow*mColSize;
	FrameAnim a;
	a.isGettingCloser = false;
	a.isFull = false;
	a.frameID = frameID;
	a.elapsedTime = 0;
	a.isDead = false;
	a.defaultTrans = REng::Vector3(0,0,-57) + 
		              REng::Vector3(0,15*mSelectedFrameRow,-10*mSelectedFrameRow);
	mFrameAnims.push_back(a);
}

void PhotoFrameGroup::selectCenterFrame(){
	mSelectedFrameCol = mColSize/2;
	mSelectedFrameRow = mRowSize/2;
	closerSelectedFrame();
}
void PhotoFrameGroup::selectLeftFrame(){
	if(mAnimationLock) return;
	if(mSelectedFrameCol<mColSize-1){
		fartherSelectedFrame();
		mSelectedFrameCol++;
		closerSelectedFrame();
	}
}
void PhotoFrameGroup::selectRightFrame(){
	if(mAnimationLock) return;
	if(mSelectedFrameCol>0){
		fartherSelectedFrame();
		mSelectedFrameCol--;
		closerSelectedFrame();
	}
}
void PhotoFrameGroup::selectUpFrame(){
	if(mAnimationLock) return;
	if(mSelectedFrameRow<mRowSize-1){
		fartherSelectedFrame();
		mSelectedFrameRow++;
		closerSelectedFrame();
	}
}
void PhotoFrameGroup::selectDownFrame(){
	if(mAnimationLock) return;
	if(mSelectedFrameRow>0){
		fartherSelectedFrame();
		mSelectedFrameRow--;
		closerSelectedFrame();
	}
}
void PhotoFrameGroup::magnifySelectedFrame(){
	REng::ushort frameID = mSelectedFrameCol+mSelectedFrameRow*mColSize;
	FrameAnim a;
	a.isGettingCloser = true;
	a.isFull = true;
	a.frameID = frameID;
	a.elapsedTime = 0;
	a.isDead = false;
	mFrameAnims.push_back(a);
	mSelectedFrameAnimating = true;
	mAnimationLock = true;
}
void PhotoFrameGroup::demagnifySelectedFrame(){
	REng::ushort frameID = mSelectedFrameCol+mSelectedFrameRow*mColSize;
	FrameAnim a;
	a.isGettingCloser = false;
	a.isFull = true;
	a.frameID = frameID;
	a.elapsedTime = 0;
	a.isDead = false;
	mFrameAnims.push_back(a);
	mSelectedFrameAnimating = true;
}

void PhotoFrameGroup::focusChangeSelectedFrame(){
	if(mSelectedFrameAnimating) return;
	if(mSelectedFrameFocused){
		demagnifySelectedFrame();
	} else {
		magnifySelectedFrame();
	}
}




float PhotoFrameGroup::getTargetViewAngle(){
	// convert mSelectedFrameCol
	float difAngle = REng::AngleDegree(15).getRadian();
	float curAngle = mDifAngle * mColExtend * -1 + REng::AngleDegree(90).getRadian();
	curAngle += difAngle * mSelectedFrameCol;
	return curAngle;
}

