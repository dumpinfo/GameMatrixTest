#ifndef _LIGHT_OMAP_H_
#define _LIGHT_OMAP_H_

#if RENG_PLATFORM == RENG_PLATFORM_OMAP

// provides non-struct based light sources to be used on OMAP device
// and also shows how the light types can be extended outside the library as required
// Aimed or OpenGL ES 2.0 configurations...

#include "REng/Light.h"
#include "REng/Material/RenderPass.h"
#include "REng/Node.h"

class Light_Sun_Omap : public REng::Light_Base {
public:
	static Light_Sun_Omap& create(REng::LightNode& node);

	bool isPositional() const { return false; }
	bool isDirectional() const { return true; }
	REng::uint getTypeID() const { return REng::LightType_Spot+1; }

	void setColor(REng::Color_Real color);
	REng::Color_Real getColor() const;

	const char* getShaderStructCode();
	bool synchWithPass(REng::RenderPass& pass);

	static bool registerFunc();

private:
	Light_Sun_Omap(REng::LightNode& node);

	static const char* mShaderStructCode;

	REng::Color_Real mColor;

	enum {
		Dirty_Color    = 4,
	};

	//! Synch methods for light parameters
	bool synchColor(REng::RenderPass& pass);
	bool synchDirection(REng::RenderPass& pass);
};

REGISTER_LIGHT_H(Light_Sun_Omap);

class Light_Point_Omap : public REng::Light_Base {
public:
	static Light_Point_Omap& create(REng::LightNode& node);

	bool isPositional() const { return true;}
	bool isDirectional() const { return false; }
	REng::uint getTypeID() const { return REng::LightType_Spot+2; }

	void setColor(REng::Color_Real color);
	REng::Color_Real getColor() const;

	void setAttenPosFactors(float _cons, float _linear, float _quadric);
	void getAttenPosFactors(float& _cons, float& _linear, float& _quadric);

	void setAllDirty(bool _isDirty);

	const char* getShaderStructCode();
	bool synchWithPass(REng::RenderPass& pass);

	static bool registerFunc();
private:
	Light_Point_Omap(REng::LightNode& node);

	static const char* mShaderStructCode;

	REng::Color_Real mColor;

	float mAttenPos_Constant;
	float mAttenPos_Linear;
	float mAttenPos_Quadric;

	enum {
		Dirty_Color    = 4,
		Dirty_AttenPos = 8
	};

	//! Synch methods for light parameters
	bool synchColor(REng::RenderPass& pass);
	bool synchPosition(REng::RenderPass& pass);
	bool synchAttenuation(REng::RenderPass& pass);
};

REGISTER_LIGHT_H(Light_Point_Omap);


class Light_Spot_Omap : public REng::Light_Base {
public:
	// Creates a new spot light and attaches it to the given light node
	static Light_Spot_Omap& create(REng::LightNode& node);

	bool isPositional() const { return true;}
	bool isDirectional() const { return true; }
	REng::uint getTypeID() const { return REng::LightType_Spot+3; }

	void setColor(REng::Color_Real color);
	REng::Color_Real getColor() const;

	void setAttenPosFactors(float _cons, float _linear, float _quadric);
	void getAttenPosFactors(float& _cons, float& _linear, float& _quadric);

	void setAttenDirFactors(float falloffExp, const REng::Angle& cutoffAngle);
	void getAttenDirFactors(float& falloffExp, REng::Angle& cutoffAngle);

	//! This method allows directly setting all the internal data dirty or not
	void setAllDirty(bool _isDirty);

	const char* getShaderStructCode();
	bool synchWithPass(REng::RenderPass& pass);
	void synchToLightAtIndex(REng::RenderPass& pass, REng::uint _index);

	static bool registerFunc();
private:
	Light_Spot_Omap(REng::LightNode& node);

	static const char* mShaderStructCode;

	REng::Color_Real mColor;

	float mAttenPos_Constant;
	float mAttenPos_Linear;
	float mAttenPos_Quadric;

	float mFalloffExponent;
	REng::AngleDegree mCutoffAngle;

	enum {
		Dirty_Color    = 4,
		Dirty_AttenPos = 8,
		Dirty_AttenDir = 16
	};

	//! Synch methods for light parameters
	bool synchColor(REng::RenderPass& pass);
	bool synchPosition(REng::RenderPass& pass);
	bool synchDirection(REng::RenderPass& pass);
	bool synchAttenuation(REng::RenderPass& pass);
};

REGISTER_LIGHT_H(Light_Spot_Omap);

#endif

#endif // _LIGHT_OMAP_H_
