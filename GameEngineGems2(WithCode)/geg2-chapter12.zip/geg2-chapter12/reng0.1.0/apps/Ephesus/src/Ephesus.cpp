#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// EPHESUS

// A photo browser application for the ancient city Ephesus
// Author: Adil Yalcin

#define WINDOW_WIDTH  (850) // (320)
#define WINDOW_HEIGHT (475) // (370)

#include "REng/MVC_Anaglyph.h"
#include "REng/MVC_Parallax.h"

#if RENG_PLATFORM == RENG_PLATFORM_OMAP
#include "Light_Omap.h"
#endif

#include "PhotoFrameGroup.h"

//#define REVERT_VIEW
// #define NO_MULTIVIEW

// common quaternions
Quaternion rotX_neg90, rotX_neg45, rotX_pos90, rotX_pos45;
Quaternion rotZ_neg90, rotZ_neg135, rotZ_pos90, rotZ_pos135, rotZ_180;
Quaternion rotY_180, rotY_90;

void initQuaternions(){
	cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
	cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
	cml::quaternion_rotation_world_y(rotY_180,Angle::degree2radian(180));
	cml::quaternion_rotation_world_y(rotY_90,Angle::degree2radian(90));
	cml::quaternion_rotation_world_z(rotZ_180,Angle::degree2radian(180));
	rotX_pos90 = rotX_neg90; rotX_pos90.inverse();
	rotX_pos45 = rotX_neg45;   rotX_pos45.inverse();
	rotZ_pos90 = rotZ_neg90;   rotZ_pos90.inverse();
	rotZ_pos135 = rotZ_neg135; rotZ_pos135.inverse();
}

class EphesusApp : public Application_Base {
public:
	size_t frameNo;
	float mCurCameraYRot;
	bool captureMV;
	bool animate;
	bool isAnaglyph;
	bool hasLoD;

	ScreenCapturer* scrCap;
	PhotoFrameGroup* photoFrameGroup;
	Viewport* vp;
	CameraNode* camNode;
	SceneNode* lightNode_Sun1;
	SceneNode* lightNode_Sun2;

	MeshPtr planeMesh;

	EphesusApp():
		frameNo(0),
		captureMV(false),
		animate(false),
		scrCap(0),
		vp(0)
	{
		photoFrameGroup = new PhotoFrameGroup();
		camNode = 0;
		lightNode_Sun1 = 0;
		lightNode_Sun2 = 0;
		isAnaglyph = true;
		hasLoD = false;
	}

	~EphesusApp() {}

	void setDefaultMaterials(){
		photoFrameGroup->setDefaultMaterials();
	}
	void setSephiaMaterials(){
		photoFrameGroup->setSephiaMaterials();
	}

	void createLights(){
		lightNode_Sun1 = &(LightNode::create(RootNode::getSingleton()));
		lightNode_Sun1->rotate_World(cml::inverse(rotY_90));
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		Light_Sun_Omap& sunLight1(Light_Sun_Omap::create(*((LightNode*)lightNode_Sun1)));
#else
		Light_Sun& sunLight1(Light_Sun::create(*((LightNode*)lightNode_Sun1)));
#endif
		sunLight1.setColor(Color_Real(1.0f,0.3f,0.3f));
	}

	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		RSys.createWindowAndGLContext(
		#ifdef REVERT_VIEW
			REng::RectI(20,20+WINDOW_HEIGHT,30+WINDOW_WIDTH,30),
		#else
			REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),
		#endif
			0,
			inputStartup);
		if(!RSys.initSystem()) return false;

		MeshManager& MeshMan(MeshManager::getSingleton());
		MaterialManager& MatMan(MaterialManager::getSingleton());
		MeshGeomGenerator& MeshGeomGen(MeshGeomGenerator::getSingleton());

		Logger logger = Logger::getInstance("App");
		// shared materials
		MaterialScriptParser::getSingleton().parseFile("materials/Ephesus/textures.material");
		MaterialScriptParser::getSingleton().parseFile("materials/Ephesus/ground.material");
		MaterialScriptParser::getSingleton().parseFile("materials/Ephesus/lightmat.material");
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
		// we need to use slightly different shaders for omap
		MaterialScriptParser::getSingleton().parseFile("materials/Ephesus/shaders_omap.material");
#else
		MaterialScriptParser::getSingleton().parseFile("materials/Ephesus/shaders.material");
#endif

		// create and initialize material resources
		MatMan.compileMaterialShaders();
		MatMan.loadMaterials();

		initQuaternions();

		//////////////////////////////////////////////////////////////////////////
		// CREATE MESHES
		//////////////////////////////////////////////////////////////////////////
		MeshMan.loadFromFile("mesh/ephesus.obj");
		MeshMan.loadFromFile("mesh/rock.obj");

		planeMesh = MeshMan.createMesh("ground");
		planeMesh ->createLoDGeom(MeshGeomGen.getUnitPlane());
		photoFrameGroup->createMeshes();

		planeMesh->mMaterial = MaterialManager::getSingleton().getMaterial("ground_MultiTex");
		photoFrameGroup->createPictureMaterials();

		// LIGHT SETUP
		createLights();
		setDefaultMaterials();

		REng::RenderSystem::getSingleton().setSkyMeshGeom( REng::MeshGeomGenerator::getSingleton().getUnitAAB() );

		//////////////////////////////////////////////////////////////////////////
		// SET SCENE GRAPH STRUCTURE
		//////////////////////////////////////////////////////////////////////////

		// Ground Node
		MeshNode& groundNode(MeshNode::create(RootNode::getSingleton()));
		groundNode.setMesh(planeMesh);
		groundNode.translate_Local(cml::vector3f(0.0f,-20.0f,0.0f),true);
		groundNode.scale_Parent(270.f,true);
		groundNode.rotate_Parent(rotX_neg90,true);

		// Photo frame group
		photoFrameGroup->createSamplePhotoFrame();
		photoFrameGroup->createFrameGroup(6,1);
		photoFrameGroup->selectCenterFrame();

		Quaternion rotQ;

		// Ephesus Library
		MeshPtr ephesusLib(MeshMan.getMeshByName("ephesus_0"));
		ephesusLib->mMaterial = MatMan.getMaterial("Library");
		MeshNode& ephesusLibNode(MeshNode::create(RootNode::getSingleton()));
		ephesusLibNode.setMesh(ephesusLib);
		ephesusLibNode.translate_Local(cml::vector3f(-120.0f,-39.0f,60.0f),true);
		ephesusLibNode.scale_Parent(5.0f);
		cml::quaternion_rotation_world_y(rotQ,Angle::degree2radian(45));
		ephesusLibNode.rotate_World(rotQ);

		// Rocks on the ground
		MeshPtr rockMesh(MeshMan.getMeshByName("rock_0"));
		rockMesh->mMaterial = MatMan.getMaterial("Library");
		MeshNode& rockNode1(MeshNode::create(RootNode::getSingleton()));
		rockNode1.setMesh(rockMesh);
		rockNode1.translate_Local(cml::vector3f(-80.0f,-20.0f,20.0f),true);
		rockNode1.scale_Parent(5.0f);
		MeshNode& rockNode2(MeshNode::create(RootNode::getSingleton()));
		rockNode2.setMesh(rockMesh);
		rockNode2.translate_Local(cml::vector3f(-120.0f,-20.0f,-120.0f),true);
		rockNode2.scale_Parent(10.0f);
		MeshNode& rockNode3(MeshNode::create(RootNode::getSingleton()));
		rockNode3.setMesh(rockMesh);
		rockNode3.translate_Local(cml::vector3f(-130.0f,-20.0f,-90.0f),true);
		rockNode3.scale_Parent(12.0f);
		cml::quaternion_rotation_world_y(rotQ,Angle::degree2radian(235));
		rockNode3.rotate_World(rotQ);
		MeshNode& rockNode4(MeshNode::create(RootNode::getSingleton()));
		rockNode4.setMesh(rockMesh);
		rockNode4.translate_Local(cml::vector3f(-90.0f,-20.0f,-10.0f),true);
		rockNode4.scale_Parent(9.0f);
		MeshNode& rockNode5(MeshNode::create(RootNode::getSingleton()));
		rockNode5.setMesh(rockMesh);
		rockNode5.translate_Local(cml::vector3f(-90.0f,-20.0f,100.0f),true);
		rockNode5.scale_Parent(7.0f);
		MeshNode& rockNode6(MeshNode::create(RootNode::getSingleton()));
		rockNode6.setMesh(rockMesh);
		rockNode6.translate_Local(cml::vector3f(-20.0f,-20.0f,120.0f),true);
		rockNode6.scale_Parent(11.0f);
		MeshNode& rockNode7(MeshNode::create(RootNode::getSingleton()));
		rockNode7.setMesh(rockMesh);
		rockNode7.translate_Local(cml::vector3f(-40.0f,-20.0f,-190.0f),true);
		rockNode7.scale_Parent(11.0f);
		rockNode7.rotate_World(rotQ);
		MeshNode& rockNode8(MeshNode::create(RootNode::getSingleton()));
		rockNode8.setMesh(rockMesh);
		rockNode8.translate_Local(cml::vector3f(-130.0f,-20.0f,20.0f),true);
		rockNode8.scale_Parent(7.0f);
		MeshNode& rockNode9(MeshNode::create(RootNode::getSingleton()));
		rockNode9.setMesh(rockMesh);
		rockNode9.translate_Local(cml::vector3f(-150.0f,-20.0f,120.0f),true);
		rockNode9.scale_Parent(18.0f);

		// *********************
		// CAMERA SETUP

		camNode = &(CameraNode::create(GroupNode::create(RootNode::getSingleton())));
		camNode->translate_Parent(Vector3(0.0f,3.0f,0.0f),true);
		camNode->rotate_Parent(rotY_90,true);
		mCurCameraYRot = Angle::degree2radian(90);

		vp = RSys.getViewport(0);

		CameraStereoView* csw = &(CameraStereoView::create(*camNode));
		vp->mCamera = csw;
		csw->setEyeSeparation(0.3);
		csw->setFocalDistance(25.0);
		vp->mCamera->setFarDistance(500.0f);
		vp->mCamera->setNearDistance(0.1f);
#ifdef REVERT_VIEW
		vp->mCamera->mSwapXY = true;
#endif
		float aspectR = float(WINDOW_WIDTH)/WINDOW_HEIGHT;
		vp->mCamera->setFieldOfView_y(AngleDegree(45.0f));
		vp->mCamera->setAspectRatio(aspectR);

		vp->mDisableMultiView = true;

#ifndef NO_MULTIVIEW
		attachCompositor();
		attachMVBuffer();
#endif

		initGUI();

		scrCap = new ScreenCapturer();

		return true;
	}

	void attachCompositor(){
		vp->detachMVCompositor();
		MultiViewCompositor* mvc;
		if(isAnaglyph) 
			mvc = new MVC_Anaglyph;
		else{
			mvc = new MVC_Parallax;
			#ifdef REVERT_VIEW
				((MVC_Parallax*)mvc)->setViewAxisTransposed(true);
			#endif
		}
		vp->attachMVCompositor(mvc);
	}
	void attachMVBuffer(){
		vp->detachMVBuffer();

		MultiViewBuffer* myMVB(new MultiViewBuffer);
		
		MVBuffer_Cfg mvbParams;
		mvbParams.viewCount                           = 2;
		mvbParams.type                                = MVBufferType_Offtarget;
		mvbParams.offtarget.colorFormat               = ImageFormat_RGBA;
		mvbParams.offtarget.depthFormat               = ImageFormat_D;
		mvbParams.offtarget.stencilFormat             = ImageFormat_None;
		mvbParams.offtarget.sharedDepthStencilTargets = false; // If true, app can crash.. ?
		mvbParams.offtarget.sharedFrameBuffer         = true;
		mvbParams.offtarget.halfResHeight             = false;
		mvbParams.offtarget.halfResWidth              = !isAnaglyph; // true if parallax
		mvbParams.offtarget.lod.halfResBuffer         = hasLoD;

		vp->attachMVBuffer(myMVB,mvbParams);
	}

	void initGUI(){
#ifdef RENG_SAMPLE_USECEGUI
		Viewport *vpFull = RenderSystem::getSingleton().getViewport(0);
		Viewport *vp = new Viewport();
		vp->setAbsRect(vpFull->getAbsRect());
		vp->disableRenderQueues_LessThan(REnderQueueID_GUI);
		vp->autoClearBuffer(FrameBufferComponent_Depth,false);
		vp->autoClearBuffer(FrameBufferComponent_Stencil,false);
		//	// Note: GUi viewport should be rendered after (on top of) multi-view viewports
		RenderSystem::getSingleton().addViewport(1,vp);

		CEGUI::REngRenderer* guiRenderer(&CEGUI::REngRenderer::create(*vp));
		CEGUI::REngImageCodec& ic = CEGUI::REngRenderer::createImageCodec();
		CEGUI::System::create(*guiRenderer, 0, 0, &ic,0,"","logs/CEGUI.log");

		initialiseResourceGroupDirectories();
		initialiseDefaultResourceGroups();
		initSharedCEGUIOverlay(guiRenderer);
		CEGUI::SchemeManager::getSingleton().create("TaharezLook.scheme");
#endif
	}

	bool preRender(float timeLapse){
		if(captureMV){ captureViews(); }

		if(timeLapse != 0.0){
			{	// camera spring control
				float targetCameraYRot = photoFrameGroup->getTargetViewAngle();
				// constant term
				if(targetCameraYRot>mCurCameraYRot){
					mCurCameraYRot += timeLapse*0.1;
				}
				if(targetCameraYRot<mCurCameraYRot){
					mCurCameraYRot -= timeLapse*0.1;
				}
				// linear term
				if(targetCameraYRot>mCurCameraYRot){
					mCurCameraYRot += timeLapse*1.4*(targetCameraYRot-mCurCameraYRot);
				}
				if(targetCameraYRot<mCurCameraYRot){
					mCurCameraYRot -= timeLapse*1.4*(mCurCameraYRot-targetCameraYRot);
				}
				Quaternion rotY;
				cml::quaternion_rotation_world_y(rotY,mCurCameraYRot);
				camNode->rotate_Parent(rotY,true);
			}
			mTimer.getElapsedTime(true); // reset
		}

		if(timeLapse != 0.0 && animate){
			// rotate lights
			Quaternion rotator2;
			cml::quaternion_rotation_world_y(rotator2,0.05f);
			rotator2 *= timeLapse;
			rotator2.normalize();
			lightNode_Sun1->rotate_World(rotator2);
		}

		photoFrameGroup->cullFrames(mCurCameraYRot);
		photoFrameGroup->tick(timeLapse);
		frameNo++;
		return true;
	}

	void captureViews(){
		if(vp->mDisableMultiView==true) return;
		// store the result of previous frame to an  image file
		MultiViewBuffer* mvb = vp->getMVBuffer();
		if(mvb==0) return;
		GPUFrameBuffer* fb_left =mvb->getFrameBuffer(0);
		GPUFrameBuffer* fb_right=mvb->getFrameBuffer(1);
		if(fb_left==0||fb_right==0) return;
		FrameBufferColorBufferType colorBuf_Left  = FrameBufferColorBufferType_Color0;
		FrameBufferColorBufferType colorBuf_Right = FrameBufferColorBufferType_Color0;
		char fileName[32];

		mvb->setActiveView(0); // updates attached color target
		scrCap->captureFrame(
			*fb_left,
			RectI(0,fb_left->getWidth(),0,fb_left->getHeight()),
			PixelDataFormat_RGBA, 
			colorBuf_Left
			);
		sprintf(fileName,"left_%d",frameNo);
		scrCap->saveCaptureToFile(IFT_BMP,fileName,false,false);

		mvb->setActiveView(1); // updates attached color target
		scrCap->captureFrame(
			*fb_right,
			RectI(0,fb_right->getWidth(),0,fb_right->getHeight()),
			PixelDataFormat_RGBA, 
			colorBuf_Right
			);
		sprintf(fileName,"right_%d",frameNo);
		scrCap->saveCaptureToFile(IFT_BMP,fileName,false,false);
	}

	bool keyPressed( const OIS::KeyEvent &arg ) {
		if(arg.key == OIS::KC_0) {
			static bool switcher = false;
			if(switcher)
				setDefaultMaterials();
			else
				setSephiaMaterials();
			switcher = !switcher;
		}
		if(arg.key == OIS::KC_2) {
			animate = !animate;
		}
		if(arg.key == OIS::KC_3){
//			captureMV = !captureMV;
		}
		if(arg.key == OIS::KC_5) {
			photoFrameGroup->focusChangeSelectedFrame();
		}
		if(arg.key == OIS::KC_8) {
			// enable/disable multiview
			bool& flag(vp->mDisableMultiView);
			flag = !flag;
		}
		if(arg.key == OIS::KC_7) {
			// compositorSwitch
			if(!vp->mDisableMultiView){
				isAnaglyph = !isAnaglyph;
#ifndef NO_MULTIVIEW
				attachCompositor();
#endif
			}
		}
		if(arg.key == OIS::KC_9) {
			// Buffer LoD Switch
			if(!vp->mDisableMultiView){
				hasLoD = !hasLoD;
#ifndef NO_MULTIVIEW
				attachMVBuffer();
#endif
			}
		}

		CameraStereoView* c = (CameraStereoView*)(vp->mCamera);
		if(arg.key == OIS::KC_F1) { // 0x3B : 59 separation increase
			float s = c->getEyeSeparation()+0.1f;
			s = Math::clamp(s,0.f,10.f);
			c->setEyeSeparation(s);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New eye separation: "<<s);
		}
		if(arg.key == OIS::KC_F2) { // 0x3C : 60 separation decrease
			float s = c->getEyeSeparation()-0.1f;
			s = Math::clamp(s,0.f,10.f);
			c->setEyeSeparation(s);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New eye separation: "<<s);
		}
		if(arg.key == OIS::KC_F3) { // 0x3D : 61 focus inc
			float f = c->getFocalDistance()+5.f;
			f = Math::clamp(f,10.f,500.f);
			c->setFocalDistance(f);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New focal length: "<<f);
		}
		if(arg.key == OIS::KC_F4) { // 0x3E : 62 focus dec
			float f = c->getFocalDistance()-5.f;
			f = Math::clamp(f,10.f,500.f);
			c->setFocalDistance(f);
			LOG4CPLUS_INFO(Logger::getInstance("App"),"New focal length: "<<f);
		}

#ifndef REVERT_VIEW
		if(arg.key == OIS::KC_UP)    photoFrameGroup->selectUpFrame();
		if(arg.key == OIS::KC_DOWN)  photoFrameGroup->selectDownFrame();
		if(arg.key == OIS::KC_LEFT)  photoFrameGroup->selectLeftFrame();
		if(arg.key == OIS::KC_RIGHT) photoFrameGroup->selectRightFrame();
#else
		if(arg.key == OIS::KC_UP)    photoFrameGroup->selectRightFrame();
		if(arg.key == OIS::KC_DOWN)  photoFrameGroup->selectLeftFrame();
		if(arg.key == OIS::KC_LEFT)  photoFrameGroup->selectUpFrame();
		if(arg.key == OIS::KC_RIGHT) photoFrameGroup->selectDownFrame();
#endif
		return true;
	}
	bool mouseMoved( const OIS::MouseEvent &arg ) {
		Logger logger = Logger::getInstance("App");
		Vector2 curMousePos(arg.state.X.abs,arg.state.Y.abs);
		if(arg.state.buttonDown(OIS::MB_Left)){
			Quaternion rotY;
			mCurCameraYRot -= (arg.state.X.rel*0.009f);
			if(mCurCameraYRot<0+0.33) mCurCameraYRot=0+0.33;
			if(mCurCameraYRot>Math::PI-0.33) mCurCameraYRot=Math::PI-0.33;
			cml::quaternion_rotation_world_y(rotY,mCurCameraYRot);
			camNode->rotate_Parent(rotY,true);
		}
		return true;
	}
};

int main(){
	new EphesusApp();
	return EphesusApp::getSingleton().run();
}
