#include "REng/REng.h"

#include <vector>

class PhotoFrameGroup{
public:

	PhotoFrameGroup();

	// Call this once
	void createMeshes();

	// Call this once
	void createPictureMaterials();

	// Call this once
	void createSamplePhotoFrame();

	// initializes the photo frame group to hold a circular frame list using the given config
	void createFrameGroup(REng::uchar colExtend, REng::uchar rowExtend);

	// culls the frames given a view angle
	void cullFrames(float viewAngle);

	// animation
	void tick(float timeLapse);

	void selectCenterFrame();
	void selectLeftFrame();
	void selectRightFrame();
	void selectUpFrame();
	void selectDownFrame();

	REng::uchar  mSelectedFrameRow, mSelectedFrameCol;
	REng::ushort mSelectedFrame;

	void closerSelectedFrame();
	void fartherSelectedFrame();

	void magnifySelectedFrame();
	void demagnifySelectedFrame();

	void focusChangeSelectedFrame();

	void setFrameMaterials(REng::MaterialPtr mat);
	void setDefaultMaterials();
	void setSephiaMaterials();

	float getTargetViewAngle();

private:
	REng::uchar  mColSize;
	REng::uchar  mColExtend;
	REng::uchar  mRowSize;
	REng::ushort mFrameCount;

	float mFrameHalfSize;
	float mDifAngle;

	REng::GroupNode *mFramesRoot;
	REng::GroupNode *mFrameNodeBasic;
	REng::GroupNode **mFrameNodes;

	REng::MeshPtr mSphereMesh;
	REng::MeshPtr mSphereMesh_LR2;
	REng::MeshPtr mCylMesh1;
	REng::MeshPtr mCylMesh3;
	REng::MeshPtr mConeMesh2;
	REng::MeshPtr mPictureMeshes[7];

	// 7 materials per 2 basic rendering conditions
	REng::MaterialPtr mPictureMaterials[7*2];

	struct FrameAnim{
		bool isGettingCloser;
		bool isFull;
		float elapsedTime;
		REng::ushort frameID;
		bool isDead;
		REng::Vector3 defaultTrans;
	};

	bool mSelectedFrameFocused;
	bool mSelectedFrameAnimating;
	bool mAnimationLock;

	std::vector<FrameAnim> mFrameAnims;
};
