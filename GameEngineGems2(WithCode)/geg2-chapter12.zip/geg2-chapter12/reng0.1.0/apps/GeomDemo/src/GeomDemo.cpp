#include "REng/REng.h"

#include "../../shared/Application_Base.h"

#include <log4cplus/logger.h>
using namespace log4cplus;
using namespace REng;

//////////////////////////////////////////////////////////////////////////
// GEOM DEMO

// Tests geom picking feature

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

#include "REng/Geom/Geom.h"
using namespace std;
CameraNode* camNode = 0;
GeomRay gPickRay(Vector3(0,15,90),Vector3(0,15,-5),true);
float gWidthRatio = 0.5;
float gHeightRatio = 0.5;

MeshPtr gRaySphereMesh;
MeshNode *gRaySphere;
GroupNode* primitiveGroup;
GroupNode* meshGroup;
MeshNode* mn;
MeshNode* mn2;
MeshNode* mn3;

// common quaternions
Quaternion rotX_neg90;
Quaternion rotX_neg45;
Quaternion rotZ_neg90;
Quaternion rotZ_neg135;
Quaternion rotX_pos90;
Quaternion rotX_pos45;
Quaternion rotZ_pos90;
Quaternion rotZ_pos135;
Quaternion rotY_180;
Quaternion rotY_pos90;
Quaternion rotZ_180;

void initQuaternions(){
	cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
	cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
	cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
	cml::quaternion_rotation_world_y(rotY_180,Angle::degree2radian(180));
	cml::quaternion_rotation_world_y(rotY_pos90,Angle::degree2radian(90));
	cml::quaternion_rotation_world_z(rotZ_180,Angle::degree2radian(180));
	rotX_pos90 = rotX_neg90; rotX_pos90.inverse();
	rotX_pos45 = rotX_neg45;   rotX_pos45.inverse();
	rotZ_pos90 = rotZ_neg90;   rotZ_pos90.inverse();
	rotZ_pos135 = rotZ_neg135; rotZ_pos135.inverse();
}

class GeomDemoApp : public Application_Base {
public:
	GeomDemoApp() {}
	~GeomDemoApp() {}
	bool loadApp(){
		// create render system
		new RenderSystem();
		RenderSystem& RSys(RenderSystem::getSingleton());

		RSys.createWindowAndGLContext(REng::RectI(20,20+WINDOW_WIDTH,30+WINDOW_HEIGHT,30),0,inputStartup);
		if(!RSys.initSystem()) return false;

		initQuaternions();

		// parse required material files
		MaterialScriptParser::getSingleton().parseFile("materials/geomdemo.material");

		// create and initialize material resources
		MaterialManager::getSingleton().compileMaterialShaders();
		MaterialManager::getSingleton().loadMaterials();

		//////////////////////////////////////////////////////////////////////////
		// CREATE MESHES
		//////////////////////////////////////////////////////////////////////////
		// we won't load external meshes...

		MeshPtr groundMesh = MeshManager::getSingleton().createMesh("ground");
		MeshManager::getSingleton().mTmpBoundBoxType = GeomTypeAABox;
		groundMesh->mMaterial = MaterialManager::getSingleton().getMaterial("BaseGround");
		groundMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPlane(),0,0);

		MeshPtr sphereMesh = MeshManager::getSingleton().createMesh("sphereMesh");
		sphereMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMatGreen");
		sphereMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitSphere(3));

		MeshPtr boxMesh = MeshManager::getSingleton().createMesh("boxMesh");
		boxMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMatBlue");
		boxMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB());

		MeshPtr boxMeshWire = MeshManager::getSingleton().createMesh("boxMeshWire");
		boxMeshWire->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		boxMeshWire->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitAAB(false));

		MeshPtr cylMesh = MeshManager::getSingleton().createMesh("cylMesh");
		cylMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		cylMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getCyclinder(3,0.7));

		MeshPtr coneMesh = MeshManager::getSingleton().createMesh("coneMesh");
		coneMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		coneMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getCone(3));

		//////////////////////////////////////////////////////////////////////////
		// SET SCENE GRAPH STRUCTURE
		//////////////////////////////////////////////////////////////////////////

		Quaternion rotX_neg90;
		cml::quaternion_rotation_world_x(rotX_neg90,Angle::degree2radian(-90));
		Quaternion rotX_pos90(rotX_neg90);
		rotX_pos90.inverse();

		Quaternion rotX_neg45;
		cml::quaternion_rotation_world_x(rotX_neg45,Angle::degree2radian(-45));
		Quaternion rotX_pos45(rotX_neg45);
		rotX_pos45.inverse();

		Quaternion rotZ_neg90;
		cml::quaternion_rotation_world_z(rotZ_neg90,Angle::degree2radian(-90));
		Quaternion rotZ_pos90(rotZ_neg90);
		rotZ_pos90.inverse();

		Quaternion rotZ_neg135;
		cml::quaternion_rotation_world_z(rotZ_neg135,Angle::degree2radian(-135));
		Quaternion rotZ_pos135(rotZ_neg135);
		rotZ_pos135.inverse();

		// Ground Node
		MeshNode& groundNode(MeshNode::create(RootNode::getSingleton()));
		groundNode.setMesh(groundMesh);
		groundNode.translate_Local(cml::vector3f(0.0f,-20.0f,0.0f),true);
		groundNode.scale_Parent(70.f,true);
		groundNode.rotate_Parent(rotX_neg90,true);

		// Sky Cube
		RenderSystem::getSingleton().setSkyMeshGeom( MeshGeomGenerator::getSingleton().getUnitAAB() );


		// Geom Primitive Group
		primitiveGroup = &(GroupNode::create(RootNode::getSingleton()));
		primitiveGroup->scale_Parent(0.8);
		primitiveGroup->translate_Local(cml::vector3f(0.0f,-10.0f,0.0f),true);

		MeshNode& boxNode_2(MeshNode::create(*primitiveGroup));
		boxNode_2.setMesh(boxMesh);
		boxNode_2.scale_Parent(Vector3(4.5,3.0,6.0));
		boxNode_2.translate_Parent(Vector3(20,0,0));
		boxNode_2.RenderBoundingVolume=true;

		MeshNode& boxNode_5(MeshNode::create(*primitiveGroup));
		boxNode_5.setMesh(boxMeshWire);
		boxNode_5.translate_Parent(Vector3(0,0,20));
		boxNode_5.scale_Parent(5.0);
		boxNode_5.RenderBoundingVolume=true;

		MeshNode& sphereNode(MeshNode::create(*primitiveGroup));
		sphereNode.setMesh(sphereMesh);
		sphereNode.scale_Parent(5.0f);
		sphereNode.RenderBoundingVolume=true;

		MeshNode& cylNode(MeshNode::create(*primitiveGroup));
		cylNode.setMesh(coneMesh);
		cylNode.translate_Parent(Vector3(0,0,-20));
		cylNode.rotate_World(rotX_pos90);
		cylNode.scale_Parent(Vector3(4.0f,8.0f,4.0f));
		cylNode.RenderBoundingVolume=true;

		MeshNode& cylNode2(MeshNode::create(*primitiveGroup));
		cylNode2.setMesh(cylMesh);
		cylNode2.translate_Parent(Vector3(-20.0,0.0,0.0));
		cylNode2.rotate_World(rotX_pos90.inverse());
		cylNode2.scale_Parent(Vector3(5.6f,2.8f,4.2f));
		cylNode2.RenderBoundingVolume=true;


		// Mesh Group
		meshGroup = &(GroupNode::create(RootNode::getSingleton()));
		meshGroup->scale_Parent(0.8);
		meshGroup->translate_Local(cml::vector3f(0.0f,20.0f,0.0f),true);

		MeshManager::getSingleton().mTmpBoundBoxType = GeomTypeAABox;
		MeshManager::getSingleton().mSwapTexCoordS_T = false;
		MeshManager::getSingleton().loadFromFile("mesh/Teapot.3ds");
		MeshPtr meshPtr(MeshManager::getSingleton().getMeshByName("Teapot01"));
		mn=&(MeshNode::create(*meshGroup));
		meshPtr->mMaterial = MaterialManager::getSingleton().getMaterial("car");
		mn->setMesh(meshPtr);
		mn->RenderBoundingVolume = true;
		mn->scale_Parent(Vector3(0.15,0.15,0.15));
		mn->translate_Parent(Vector3(-7.5,13,0));
		mn->rotate_World(rotZ_pos135);

		MeshManager::getSingleton().mTmpBoundBoxType = GeomTypeOBox;
		MeshManager::getSingleton().mSwapTexCoordS_T = false;
		MeshManager::getSingleton().loadFromFile("mesh/shuttle.3ds");
		MeshPtr meshPtr2(MeshManager::getSingleton().getMeshByName("Shuttle02"));
		mn2 = &(MeshNode::create(*meshGroup));
		meshPtr2->mMaterial = MaterialManager::getSingleton().getMaterial("shuttle");
		mn2->setMesh(meshPtr2);
		mn2->RenderBoundingVolume = true;
		mn2->scale_Parent(Vector3(0.02,0.02,0.02));
		mn2->translate_Parent(Vector3(15,0,0));
		mn2->rotate_World(rotZ_neg135);
		mn2->rotate_World(rotY_pos90.inverse());

		MeshManager::getSingleton().mTmpBoundBoxType = GeomTypeSphere;
		MeshManager::getSingleton().mSwapTexCoordS_T = false;
		MeshManager::getSingleton().loadFromFile("mesh/rock.obj");
		MeshPtr meshPtr3(MeshManager::getSingleton().getMeshByName("rock_0"));
		mn3 = &(MeshNode::create(*meshGroup));
		meshPtr3->mMaterial = MaterialManager::getSingleton().getMaterial("spacefighter01");
		mn3->setMesh(meshPtr3);
		mn3->RenderBoundingVolume = true;
		mn3->scale_Parent(Vector3(0.02,0.02,0.02));
		mn3->translate_Parent(Vector3(-7.5,-13,0));
		mn3->rotate_World(rotZ_neg135);
		mn3->rotate_World(rotY_pos90.inverse());

		// *********************
		// CAMERA SETUP

		camNode = &(CameraNode::create(RootNode::getSingleton()));
		camNode->translate_World(Vector3(0.0f,25.0f,90.0f),true);
		Quaternion camRot;
		cml::quaternion_rotation_world_x(camRot,-0.2f);
		camNode->rotate_World(camRot);

		CameraPerspective& camera(CameraPerspective::create(*camNode));
		camera.setAspectRatio((float)WINDOW_WIDTH/(float)WINDOW_HEIGHT);
		camera.setFarDistance(300.0f);
		camera.setNearDistance(0.1f);
		camera.setFieldOfView_y(AngleDegree(45.0f));

		RSys.getViewport(0)->mCamera = &camera;

		// Pick Ray Visualization
		gRaySphereMesh = MeshManager::getSingleton().createMesh("gRaySphereMesh");
		gRaySphereMesh->mMaterial = MaterialManager::getSingleton().getMaterial("MeshGeomMat");
		gRaySphereMesh->createLoDGeom(MeshGeomGenerator::getSingleton().getUnitPoint());
		gRaySphere=&(MeshNode::create(RootNode::getSingleton()));
		gRaySphere->setMesh(gRaySphereMesh);
		gRaySphere->scale_Parent(0.004,true);
		gRaySphere->translate_Parent((gPickRay.getDirection() + gPickRay.getPosition()),true);

		return true;
	}
	bool preRender(float timeLapse){
		Quaternion rotatorPrimitive;
		cml::quaternion_rotation_world_y(rotatorPrimitive,0.8f*timeLapse);
		Quaternion rotatorMesh;
		cml::quaternion_rotation_world_z(rotatorMesh,0.8f*timeLapse);
		Quaternion rotatorShoes;
		cml::quaternion_rotation_world_z(rotatorShoes,0.8f*timeLapse);

		primitiveGroup->rotate_Parent(rotatorPrimitive);
		meshGroup->rotate_Parent(rotatorMesh);
		mn->rotate_World(rotatorPrimitive);
		mn2->rotate_World(rotatorPrimitive);
		mn3->rotate_World(rotatorPrimitive);
		return true;
	}
	bool keyPressed( const OIS::KeyEvent &arg ) {
	    if(arg.key == OIS::KC_0) {
            // Pick Objects
            SceneNodeList snl=RootNode::getSingleton().pickMesh(gPickRay);

            // Pick Only Nearest Mesh
            if(snl.size()>0 && snl[0]->RenderBoundingVolume) {
                snl[0]->RenderBoundingVolume=false;
            } else if(snl.size()>0 && !snl[0]->RenderBoundingVolume)  {
                snl[0]->RenderBoundingVolume=true;
            }
	    }
		return true;
	}
	bool mouseMoved( const OIS::MouseEvent &arg ) {
		float argX = (float)arg.state.X.abs;
		float argY = (float)arg.state.Y.abs;
		gWidthRatio = argX/(float)arg.state.width;
		gHeightRatio = argY/(float)arg.state.height;
		camNode->getCamera()->generateRay_WS(gWidthRatio,gHeightRatio, gPickRay);
		// Set Picking Ray's Sphere Mesh to Render It
		gRaySphere->scale_Parent(0.0004,true);
		gRaySphere->translate_Parent((gPickRay.getDirection() + gPickRay.getPosition()),true);

		return true;
	}
	bool mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) {
		// Generate Picking Ray
		float argX = (float)arg.state.X.abs;
		float argY = (float)arg.state.Y.abs;

		gWidthRatio = argX/(float)arg.state.width;
		gHeightRatio = argY/(float)arg.state.height;
		camNode->getCamera()->generateRay_WS(gWidthRatio,gHeightRatio, gPickRay);

		// Pick Objects
		SceneNodeList snl=RootNode::getSingleton().pickMesh(gPickRay);

		// Pick Only Nearest Mesh
		if(snl.size()>0 && snl[0]->RenderBoundingVolume) {
			snl[0]->RenderBoundingVolume=false;
		} else if(snl.size()>0 && !snl[0]->RenderBoundingVolume)  {
			snl[0]->RenderBoundingVolume=true;
		}

		// Set Picking Ray's Sphere Mesh to Render It
		gRaySphere->scale_Parent(0.0004,true);
		gRaySphere->translate_Parent((gPickRay.getDirection() + gPickRay.getPosition()),true);

		return true;
	}
	void handleNonBufferedKeys() {
		if(mKeyboard->isKeyDown(OIS::KC_UP))
			gHeightRatio -= 0.005;
		if(mKeyboard->isKeyDown(OIS::KC_DOWN))
			gHeightRatio += 0.005;
		if(mKeyboard->isKeyDown(OIS::KC_LEFT))
			gWidthRatio -= 0.005;
		if(mKeyboard->isKeyDown(OIS::KC_RIGHT))
			gWidthRatio += 0.005;
		camNode->getCamera()->generateRay_WS(gWidthRatio, gHeightRatio, gPickRay);
		gPickRay.normalize();

		// Set Picking Ray's Sphere Mesh to Render It
		gRaySphere->scale_Parent(0.004,true);
		gRaySphere->translate_Parent((gPickRay.getDirection() + gPickRay.getPosition()),true);
	}
};

int main(){
	new GeomDemoApp();
	return GeomDemoApp::getSingleton().run();
}

