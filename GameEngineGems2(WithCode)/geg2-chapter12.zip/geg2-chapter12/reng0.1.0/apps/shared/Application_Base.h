#ifndef _APP_INPUT_MANAGER_H_
#define _APP_INPUT_MANAGER_H_

#ifdef RENG_SAMPLE_USECEGUI
#	include <CEGUI.h>
#	include "CEGUIREngRenderer.h"
#endif

#include <OIS/OIS.h>

#ifdef OIS_LINUX_PLATFORM
#include <X11/Xlib.h>
#endif

#include <REng/Singleton.h>
#include <REng/Timer.h>

#include <REng/sys/OSWindow.h>

//! A sample basic class that allows easy cross-platform input processing
class Application_Base : public OIS::KeyListener, public OIS::MouseListener, 
	public REng::Singleton<Application_Base> 
{
public:
	Application_Base();

	static Application_Base& getSingleton(void);
	static Application_Base* getSingletonPtr(void);

	// Global entry point for use by REng::RenderSystem start-up
	static bool inputStartup(REng::OSWindow* win);

	//! Call this method directly after creating you application object
	int run();

	//! Override this method to load application-specific data
	virtual bool loadApp() = 0;

	//! The function that will be called before a scene is to be rendered
	virtual bool preRender(float timeLapse);

	//! Overwrite this method to process non-buffered keyboard input
	virtual void handleNonBufferedKeys();

	//! Overwrite this method to process non-buffered mouse input
	virtual void handleNonBufferedMouse();

	//! Overwrite this method to process mouse events
	virtual bool mousePressed(const OIS::MouseEvent &arg, OIS::MouseButtonID id);
	//! Overwrite this method to process mouse events
	virtual bool mouseReleased(const OIS::MouseEvent &arg, OIS::MouseButtonID id);
	//! Overwrite this method to process mouse events
	virtual bool mouseMoved( const OIS::MouseEvent &arg );
	//! Overwrite this method to process keyboard events
	virtual bool keyPressed(const OIS::KeyEvent &arg);
	//! Overwrite this method to process keyboard events
	virtual bool keyReleased(const OIS::KeyEvent &arg);

	//! CEGUI-related. Call this if you use CEGUI in you application
	void initialiseResourceGroupDirectories();
	//! CEGUI-related. Call this if you use CEGUI in you application
	void initialiseDefaultResourceGroups();

	void showOverlay(bool flag=true);

protected:
	OIS::InputManager *mInputManager;
	OIS::Keyboard     *mKeyboard;
	OIS::Mouse        *mMouse;

	bool mQuitRequest;
	REng::Timer mTimer;

	//! Can be updated by the application
	bool mNoRenderScene;

	//! Used for tracking mouse position
	void setWindowSize(size_t width, size_t height);

#ifdef RENG_SAMPLE_USECEGUI
	void initSharedCEGUIOverlay(CEGUI::REngRenderer* renderer);
#endif // RENG_SAMPLE_USECEGUI

	//! if RENG_SAMPLE_USECEGUI, converts OIS input to CEGUI input
	bool cegui_keyPressed( const OIS::KeyEvent &arg );
	//! if RENG_SAMPLE_USECEGUI, converts OIS input to CEGUI input
	bool cegui_keyReleased( const OIS::KeyEvent &arg );
	//! if RENG_SAMPLE_USECEGUI, converts OIS input to CEGUI input
	bool cegui_mouseMoved( const OIS::MouseEvent &arg );
	//! if RENG_SAMPLE_USECEGUI, converts OIS input to CEGUI input
	bool cegui_mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id );
	//! if RENG_SAMPLE_USECEGUI, converts OIS input to CEGUI input
	bool cegui_mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id );

#ifdef RENG_SAMPLE_USECEGUI
	bool overlayHandler(const CEGUI::EventArgs& args);
#endif

private:
#ifdef OIS_LINUX_PLATFORM
	Display *xDisp;
#endif

#ifdef RENG_SAMPLE_USECEGUI
	CEGUI::MouseButton convertOISButtonToCegui(int buttonID);
	CEGUI::GeometryBuffer* d_fps_geometry;
	CEGUI::GeometryBuffer* d_logo_geometry;
#endif // RENG_SAMPLE_USECEGUI

	//! Call this once at your system startup
	//! @note Now automatically called by the global input callback entry point
	bool initSystem(REng::OSWindow* windowHandle);

	//! Call this on every frame your want to process the inputs
	void tickEvents();

	bool mShowOverlay;
};

inline bool Application_Base::preRender(float timeLapse) { (void)timeLapse; return true; }
inline void Application_Base::handleNonBufferedKeys() { }
inline void Application_Base::handleNonBufferedMouse() { }
inline bool Application_Base::mouseMoved(const OIS::MouseEvent &arg){
	return cegui_mouseMoved(arg);
}
inline bool Application_Base::mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) {
	return cegui_mousePressed(arg,id);
}
inline bool Application_Base::mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) {
	return cegui_mouseReleased(arg,id);
}
inline bool Application_Base::keyPressed (const OIS::KeyEvent &arg){
	return cegui_keyPressed(arg);
}
inline bool Application_Base::keyReleased(const OIS::KeyEvent &arg){
	return cegui_keyReleased(arg);
}

#endif // _APP_INPUT_MANAGER_H_
