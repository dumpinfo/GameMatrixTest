#include "Application_Base.h"

#include "REng/sys/OSWindow_XWin.h"

#include "REng/RenderSystem.h"
#include "REng/StatsCounter.h"

#include <stdio.h>
#include <time.h>

#include <sstream>

#include <log4cplus/logger.h>
using namespace log4cplus;

// SINGLETON
template<> Application_Base* REng::Singleton<Application_Base>::ms_Singleton = 0;
Application_Base* Application_Base::getSingletonPtr(void) {
	return ms_Singleton;
}
Application_Base& Application_Base::getSingleton(void) {
	assert( ms_Singleton );  return ( *ms_Singleton );
}

bool Application_Base::inputStartup(REng::OSWindow* win){
	return Application_Base::getSingleton().initSystem(win);
}
Application_Base::Application_Base()
	:mInputManager(0)
	,mKeyboard(0)
	,mMouse(0)
	,mQuitRequest(false)
	,mNoRenderScene(false)
#if defined OIS_LINUX_PLATFORM
	,xDisp(0)
#endif
#ifdef RENG_SAMPLE_USECEGUI
	,d_fps_geometry(0)
	,d_logo_geometry(0)
	,mShowOverlay(true)
#endif
{ ; }

void Application_Base::showOverlay(bool flag){
	mShowOverlay = flag;
}

int Application_Base::run(){
	if(!loadApp()) return -1;
	mTimer.reset();
	while(true) {
		tickEvents();
		if(mQuitRequest) {
			REng::RenderSystem::getSingleton().shutdownWindowAndGLContext();
			break;
		}
		float timeLapse = mTimer.getElapsedTime(true);

#ifdef RENG_SAMPLE_USECEGUI
		CEGUI::System* ceguiSys = CEGUI::System::getSingletonPtr();
		if(ceguiSys) ceguiSys->injectTimePulse(timeLapse);
		// update logo rotation
//		static float rot = 0.0f;
//		if(d_logo_geometry) d_logo_geometry->setRotation(CEGUI::Vector3(rot, 0, 0));
//		rot += 180.0f * (timeLapse );
//		if(rot>360.0f) rot-=360.0f;
#endif

		if(!preRender(timeLapse)) return -1;
		if(mNoRenderScene) continue;
		if(!REng::RenderSystem::getSingleton().renderAll()) return -1;
	}
	return 0;
}

bool Application_Base::initSystem(REng::OSWindow* windowHandle){
	OIS::ParamList pl;

#if defined OIS_WIN32_PLATFORM
	std::ostringstream wnd;
	wnd << (size_t)((REng::OSWindow_Win*)windowHandle)->getWindowHandle();

	pl.insert(std::make_pair(std::string("WINDOW"), wnd.str() ));
//	pl.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_FOREGROUND" )));
//	pl.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_NONEXCLUSIVE")));
	pl.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_FOREGROUND")));
	pl.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_NONEXCLUSIVE")));
#elif defined OIS_LINUX_PLATFORM
	xDisp = ((REng::OSWindow_X*)windowHandle)->getDisplay();
	Window xWin = ((REng::OSWindow_X*)windowHandle)->getWindow();
	//Select what events we want to listen to locally
	XSelectInput(xDisp, xWin, StructureNotifyMask);
	XEvent evtent;
	do {
		XNextEvent(xDisp, &evtent);
	} while(evtent.type != MapNotify);

	std::ostringstream wnd;
	wnd << xWin;
	std::ostringstream clrmp;
	clrmp << ((REng::OSWindow_X*)windowHandle)->getColormap();
	std::ostringstream dispStr;
	dispStr << (size_t)(((REng::OSWindow_X*)windowHandle)->getDisplay());

	pl.insert(std::make_pair(std::string("WINDOW"), wnd.str()));
	pl.insert(std::make_pair(std::string("x11_mouse_grab"), std::string("true")));
	pl.insert(std::make_pair(std::string("x11_mouse_hide"), std::string("true")));
	pl.insert(std::make_pair(std::string("x11_keyboard_grab"), std::string("true")));
	pl.insert(std::make_pair(std::string("XAutoRepeatOn"), std::string("false")));
#endif

	//This never returns null.. it will raise an exception on errors
	mInputManager = OIS::InputManager::createInputSystem(pl);

	int numOfMice;
#if RENG_PLATFORM == RENG_PLATFORM_OMAP
	numOfMice = 0;
#else
	numOfMice = mInputManager->getNumberOfDevices(OIS::OISMouse);
#endif

	//Print debugging information
	unsigned int v = mInputManager->getVersionNumber();
	Logger logger = Logger::getInstance("App");
	LOG4CPLUS_INFO(logger,"OIS Version:" << (v>>16 ) << "." << ((v>>8) & 0x000000FF) << "." << (v & 0x000000FF));
	LOG4CPLUS_INFO(logger,"Release Name: " << mInputManager->getVersionName());
	LOG4CPLUS_INFO(logger,"Manager: " << mInputManager->inputSystemName());
	LOG4CPLUS_INFO(logger,"Total Keyboards: " << mInputManager->getNumberOfDevices(OIS::OISKeyboard));
	LOG4CPLUS_INFO(logger,"Total Mice: " << numOfMice);

	if(mInputManager->getNumberOfDevices(OIS::OISKeyboard)!=0) {
		LOG4CPLUS_INFO(logger,"Creating keyboard object...");
		mKeyboard = (OIS::Keyboard*)mInputManager->createInputObject( OIS::OISKeyboard, true );
		mKeyboard->setEventCallback( this );
	}
	if(numOfMice!=0){
		LOG4CPLUS_INFO(logger,"Creating mouse object...");
		mMouse = (OIS::Mouse*)mInputManager->createInputObject( OIS::OISMouse, true );
		mMouse->setEventCallback( this );
	}

	LOG4CPLUS_INFO(logger,"Setting input window size...");
	setWindowSize(windowHandle->getPosition().getWidth(),windowHandle->getPosition().getHeight());
	return true;
}

void Application_Base::setWindowSize(size_t width, size_t height){
	if(mMouse){
		const OIS::MouseState &mouseState = mMouse->getMouseState();
		mouseState.width  = width;
		mouseState.height = height;
	}
}


void Application_Base::tickEvents(){
	//////////////////////////////////////////////////////////////////////////
	#ifdef _WINDOWS
		MSG msg;
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if (msg.message==WM_QUIT) return;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	#else
		XEvent event;

		//Poll x11 for events (keyboard and mouse events are caught here)
		while( XPending(xDisp) > 0 ) {
			XNextEvent(xDisp, &event);
			switch(event.type){
				case ConfigureNotify:
					if( mMouse ) {
						const OIS::MouseState &ms = mMouse->getMouseState();
						ms.width = event.xconfigure.width;
						ms.height = event.xconfigure.height;
					}
					break;
				case DestroyNotify:
					break;
				default:
					std::cout << "\nUnknown X Event: " << event.type << std::endl;
					break;
			}
		}
	#endif
	//////////////////////////////////////////////////////////////////////////

	if( mKeyboard) {
		mKeyboard->capture();
		handleNonBufferedKeys();
		if(mKeyboard->isKeyDown(OIS::KC_ESCAPE)) mQuitRequest=true;
	}
	if( mMouse) {
		mMouse->capture();
		handleNonBufferedMouse();
	}
}


#ifdef RENG_SAMPLE_USECEGUI
CEGUI::MouseButton Application_Base::convertOISButtonToCegui(int buttonID) {
	switch (buttonID){
		case OIS::MB_Left:   return CEGUI::LeftButton;
		case OIS::MB_Right:  return CEGUI::RightButton;
		case OIS::MB_Middle: return CEGUI::MiddleButton;
		default:             return CEGUI::LeftButton;
	}
}
#endif // RENG_SAMPLE_USECEGUI
bool Application_Base::cegui_keyPressed( const OIS::KeyEvent &arg ) {
#ifdef RENG_SAMPLE_USECEGUI
	if(CEGUI::System::getSingletonPtr()==0) return true;
	CEGUI::System& cegui = CEGUI::System::getSingleton();
	cegui.injectKeyDown(arg.key);
	cegui.injectChar(arg.text);
#endif // RENG_SAMPLE_USECEGUI
	return true;
}
bool Application_Base::cegui_keyReleased( const OIS::KeyEvent &arg ) {
#ifdef RENG_SAMPLE_USECEGUI
	if(CEGUI::System::getSingletonPtr()==0) return true;
	CEGUI::System::getSingleton().injectKeyUp(arg.key);
#endif // RENG_SAMPLE_USECEGUI
	return true;
}
bool Application_Base::cegui_mouseMoved( const OIS::MouseEvent &arg ) {
#ifdef RENG_SAMPLE_USECEGUI
	if(CEGUI::System::getSingletonPtr()==0) return true;
	CEGUI::System& cegui = CEGUI::System::getSingleton();
	cegui.injectMouseMove(arg.state.X.rel, arg.state.Y.rel);
	cegui.injectMouseWheelChange(arg.state.Z.rel * 0.03);
#endif // RENG_SAMPLE_USECEGUI
	return true;
}
bool Application_Base::cegui_mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) {
#ifdef RENG_SAMPLE_USECEGUI
	if(CEGUI::System::getSingletonPtr()==0) return true;
	CEGUI::System::getSingleton().injectMouseButtonDown(convertOISButtonToCegui(id));
#endif // RENG_SAMPLE_USECEGUI
	return true;
}
bool Application_Base::cegui_mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id ) {
#ifdef RENG_SAMPLE_USECEGUI
	if(CEGUI::System::getSingletonPtr()==0) return true;
	CEGUI::System::getSingleton().injectMouseButtonUp(convertOISButtonToCegui(id));
#endif // RENG_SAMPLE_USECEGUI
	return true;
}

void Application_Base::initialiseResourceGroupDirectories() {
#ifdef RENG_SAMPLE_USECEGUI
	// initialize the required dirs for the DefaultResourceProvider
	CEGUI::DefaultResourceProvider* rp =
		static_cast<CEGUI::DefaultResourceProvider*>
			(CEGUI::System::getSingleton().getResourceProvider());

	const char* dataPathPrefix = "./cegui";
#ifndef PATH_MAX
#	define PATH_MAX 256
#endif
	char resourcePath[PATH_MAX];

	// for each resource type, set a resource group directory
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "schemes/");
	rp->setResourceGroupDirectory("schemes", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "imagesets/");
	rp->setResourceGroupDirectory("imagesets", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "fonts/");
	rp->setResourceGroupDirectory("fonts", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "layouts/");
	rp->setResourceGroupDirectory("layouts", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "looknfeel/");
	rp->setResourceGroupDirectory("looknfeels", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "lua_scripts/");
	rp->setResourceGroupDirectory("lua_scripts", resourcePath);
	sprintf(resourcePath, "%s/%s", dataPathPrefix, "xml_schemas/");
	rp->setResourceGroupDirectory("schemas", resourcePath);   
#endif // RENG_SAMPLE_USECEGUI
}

#ifdef RENG_SAMPLE_USECEGUI
bool Application_Base::overlayHandler(const CEGUI::EventArgs& args) {
	if(!mShowOverlay) return true;
	if(d_fps_geometry==0 || d_logo_geometry==0) return false;
	if(static_cast<const CEGUI::RenderQueueEventArgs&>(args).queueID != CEGUI::RQ_OVERLAY)
		return false;

//	d_logo_geometry->draw();
	CEGUI::Font* fnt = CEGUI::System::getSingleton().getDefaultFont();
	if(fnt){
		d_fps_geometry->reset();
		char d_fps_textbuff[16];
		sprintf(d_fps_textbuff,"FPS:%i",REng::StatsCounter::getSingleton().getFrameRate());
		fnt->drawText(*d_fps_geometry,d_fps_textbuff,CEGUI::Vector2(10,30),0,CEGUI::colour(0xFFFFFFFF));
		d_fps_geometry->draw();
	}
	return true;
}
void Application_Base::initSharedCEGUIOverlay(CEGUI::REngRenderer* renderer){
	const CEGUI::Rect scrn(CEGUI::Vector2(0, 0), renderer->getDisplaySize());

	CEGUI::ImagesetManager::getSingleton().createFromImageFile("cegui_logo", "logo.png", "imagesets");
	d_logo_geometry = &renderer->createGeometryBuffer();
	d_logo_geometry->setClippingRegion(scrn);
	d_logo_geometry->setPivot(CEGUI::Vector3(50, 24.75f, 0));
	d_logo_geometry->setTranslation(CEGUI::Vector3(0, 19, 0));
	CEGUI::ImagesetManager::getSingleton().get("cegui_logo").
		getImage("full_image").draw(*d_logo_geometry,CEGUI::Rect(0,0,100/2.f,69.5f/2.f),0);

	d_fps_geometry = &renderer->createGeometryBuffer();
	d_fps_geometry->setClippingRegion(scrn);

	// clearing this queue actually makes sure it's created(!)
	renderer->getDefaultRenderingRoot().clearGeometry(CEGUI::RQ_OVERLAY);

	// subscribe handler to render overlay items
	renderer->getDefaultRenderingRoot().
		subscribeEvent(CEGUI::RenderingSurface::EventRenderQueueStarted,
			CEGUI::Event::Subscriber(&Application_Base::overlayHandler,
			this));
}
#endif // RENG_SAMPLE_USECEGUI

void Application_Base::initialiseDefaultResourceGroups() {
#ifdef RENG_SAMPLE_USECEGUI
	// set the default resource groups to be used
	CEGUI::Imageset::setDefaultResourceGroup("imagesets");
	CEGUI::Font::setDefaultResourceGroup("fonts");
	CEGUI::Scheme::setDefaultResourceGroup("schemes");
	CEGUI::WidgetLookManager::setDefaultResourceGroup("looknfeels");
	CEGUI::WindowManager::setDefaultResourceGroup("layouts");
	CEGUI::ScriptModule::setDefaultResourceGroup("lua_scripts");

	// setup default group for validation schemas
	CEGUI::XMLParser* parser = CEGUI::System::getSingleton().getXMLParser();
	if (parser->isPropertyPresent("SchemaDefaultResourceGroup"))
		parser->setProperty("SchemaDefaultResourceGroup", "schemas");        
#endif // RENG_SAMPLE_USECEGUI
}



