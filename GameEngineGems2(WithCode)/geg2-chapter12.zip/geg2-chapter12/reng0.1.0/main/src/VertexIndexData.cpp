/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/VertexIndexData.h"

using namespace boost;

namespace REng{

	/************************************************************************/
	/* VERTEX DATA                                                          */
	/************************************************************************/

	VertexData::VertexData() :mFreeIndexCache(0) { ; }

	VertexData::~VertexData() { 
		clearAttributes();
		clearBufferIndexes();
	}

	size_t VertexData::getAttributeCount() const{
		return mAttributeList.size();
	}

	size_t VertexData::getVertexSize(unsigned char source) const{
		VertexAttributeList::const_iterator i =  mAttributeList.begin();
		VertexAttributeList::const_iterator iend = mAttributeList.end();
		size_t sz = 0;
		for (; i != iend; ++i)
			if (i->getSourceBufferIndex() == source) sz += i->getSizeInBytes();
		return sz;
	}

	const VertexAttribute& VertexData::getAttribute(unsigned short index) const{
		assert(index < mAttributeList.size() && "Index out of bounds");
		VertexAttributeList::const_iterator i = mAttributeList.begin();
		std::advance(i, index);
		return (*i);
	}

	const VertexAttributeList& VertexData::getAttributeElementsAll() const{
		return mAttributeList;
	}

	void VertexData::removeAttribute(size_t index) {
		assert(index < mAttributeList.size() && "Index out of bounds");
		VertexAttributeList::iterator i = mAttributeList.begin();
		std::advance(i, index);
		mAttributeList.erase(i);
	}

	void VertexData::clearAttributes(){
		mAttributeList.clear();
	}

	bool VertexData::attributeOrderBefore(const VertexAttribute& atrib1, const VertexAttribute& atrib2){
		if(atrib1.getSourceBufferIndex()<atrib2.getSourceBufferIndex()) 
			return true;
		return false;
	}

	void VertexData::insertAttribute(const VertexAttribute& attrib) {
		mAttributeList.push_back( attrib );
		mAttributeList.sort(attributeOrderBefore);
	}

	unsigned char VertexData::getMaxSource(void) const{
		VertexAttributeList::const_iterator i    = mAttributeList.begin();
		VertexAttributeList::const_iterator iend = mAttributeList.end();
		unsigned char ret = 0;
		for (; i != iend; ++i) {
			unsigned char tmpVal = i->getSourceBufferIndex();
			if(tmpVal > ret) ret = tmpVal;
		}
		return ret;
	}

	VertexAttributeList VertexData::getAttributeElementsBySource(unsigned char source){
		VertexAttributeList::const_iterator ei    = mAttributeList.begin();
		VertexAttributeList::const_iterator eiend = mAttributeList.end();
		VertexAttributeList retList;
		for(; ei != eiend; ++ei)
			if (ei->getSourceBufferIndex() == source) retList.push_back(*ei);
		return retList;
	}

	void VertexData::linkBufferToIndex(unsigned char index, VertexBufferPtr buffer){
		mBindingMap[index] = buffer;
		if (mFreeIndexCache == index){
			// find a new free index cache
			// TODO: if all indexes are filled, this causes an infinite loop!
			while(true){
				if(isBufferIndexed(mFreeIndexCache++)==false) break;
			}
		}
	}

	void VertexData::unsetBufferIndex(unsigned char index){
		VertexBufferBindingMap::iterator i = mBindingMap.find(index);
		if(i == mBindingMap.end()){
			return;
		}
		mBindingMap.erase(i);
		if(index < mFreeIndexCache) mFreeIndexCache = index;
	}

	void VertexData::clearBufferIndexes(void) {
		mBindingMap.clear();
		mFreeIndexCache = 0;
	}

	const VertexBufferBindingMap& VertexData::getBufferIndexes(void) const{
		return mBindingMap;
	}

	VertexBufferPtr VertexData::getBuffer(unsigned char index) const{
		VertexBufferBindingMap::const_iterator i = mBindingMap.find(index);
		assert(i != mBindingMap.end()); 
		return i->second;
	}

	bool VertexData::isBufferIndexed(unsigned char index) const{
		return mBindingMap.find(index) != mBindingMap.end();
	}

	size_t VertexData::getIndexedBufferCount(void) const{
		return mBindingMap.size();
	}

	unsigned char VertexData::getFreeIndex(void) const{
		return mFreeIndexCache;
	}

	/************************************************************************/
	/* INDEX DATA                                                           */
	/************************************************************************/

	IndexData::IndexData() : primType(PrimitiveType_Points), mBufferPtr(GPUIndexBufferPtr()) { ; }

	IndexData::~IndexData() { ; }

	IndexBufferPtr IndexData::getBufferPtr() const{
		return mBufferPtr;
	}

	bool IndexData::checkRange(size_t start, size_t size){
		if(mBufferPtr.get() == 0 ) return false;
		// TODO: handle integer overflow?
		return true;
		if(start+size>mBufferPtr->getIndexCount()) return false;
	}

	void IndexData::setBufferPtr(IndexBufferPtr buf){
		mBufferPtr = buf;
	}

}

