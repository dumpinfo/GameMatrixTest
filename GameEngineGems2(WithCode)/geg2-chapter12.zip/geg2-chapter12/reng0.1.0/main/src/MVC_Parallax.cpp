/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/MVC_Parallax.h"

// to switch active frame-buffers
#include "REng/GPU/GPUFrameBuffer.h"
// to render compositor geom-mesh
#include "REng/GPU/GPUDrawer.h"
// to bind GPUTextures
#include "REng/GPU/GPUTexture.h"
// viewport
#include "REng/Viewport.h"

#include "REng/Material/MaterialManager.h"
#include "REng/Material/MaterialScriptParser.h"
#include "REng/Material/RenderPass.h"
#include "REng/RenderSystem.h"

// logging to render system logs...
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	MVC_Parallax::MVC_Parallax() 
		: MultiViewCompositor(2)
		,mCompProg(0)
		,mCompFragS(0)
		,mImageSampler_L(0)
		,mImageSampler_R(0)
		,mTransposeViewAxis(false)
	{ ; }

	MVC_Parallax::~MVC_Parallax(){ ; }

	bool MVC_Parallax::isViewAxisTransposed() const{
		return mTransposeViewAxis;
	}
	void MVC_Parallax::setViewAxisTransposed(bool val) const{
		if(val != mTransposeViewAxis){
			mTransposeViewAxis = val;
			updateCompProg();
		}
	}

	bool MVC_Parallax::updateCompProg() const{
		Logger logger = Logger::getInstance("RSys");
		if(!mCompProg){
			// create new GPUProgram, create the default static vertex shader and bind default stuff to program...
			mCompProg = new GPUProgram();

			//////////////////////////////////////////////////////////////////////////
			// CREATE VERTEX SHADER
			REng::GPUShader mVertShader(ShaderType_Vertex); // creates OpenGL object
			const char *vertShaderText[] = {
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				"const lowp vec2 madd=vec2(0.5,0.5);"
				"attribute lowp vec2 vertexIn;",
				"varying mediump vec2 textureCoord;",
#else
				"const vec2 madd=vec2(0.5,0.5);"
				"attribute vec2 vertexIn;",
				"varying vec2 textureCoord;",
#endif
				"void main() {",
				"  textureCoord = vertexIn.xy*madd+madd;",
				"  gl_Position = vec4(vertexIn.xy,0.0,1.0);",
				"}"
			};
			if( !mVertShader.compileFromText( sizeof(vertShaderText)/4, vertShaderText) ){
				LOG4CPLUS_WARN(logger, "MultiViewCompositor Parallax vertex shader could not be compiled.");
				return false;
			}
			mCompProg->attachShader(mVertShader);
			mCompProg->bindAttribLocation(0,"vertexIn");
			mCompProg->bindAttribLocation(1,"texCoordIn");
		}
		if(mCompFragS!= 0) {
			mCompProg->detachShader(*mCompFragS);
			delete mCompFragS;
		}
		//////////////////////////////////////////////////////////////////////////
		// CREATE FRAGMENT SHADER
		mCompFragS = new REng::GPUShader(ShaderType_Fragment); // creates OpenGL object
		const char* w0;
		if(mTransposeViewAxis){
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			w0 = "lowp float w = mod(gl_FragCoord.y,2.0);";
#else
			w0 = "float w = mod(gl_FragCoord.y,2.0);";
#endif
		} else {
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			w0 = "lowp float w = mod(gl_FragCoord.x,2.0);";
#else
			w0 = "float w = mod(gl_FragCoord.x,2.0);";
#endif
		}
		const char* fragShaderText[] = {
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			"uniform lowp sampler2D viewL;",
			"uniform lowp sampler2D viewR;",
			"varying mediump vec2 textureCoord;",
#else
			"uniform sampler2D viewL;",
			"uniform sampler2D viewR;",
			"varying vec2 textureCoord;",
#endif
			"void main() {",
			w0,
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			"  lowp vec4 colorR = texture2D(viewR,textureCoord);",
			"  lowp vec4 colorL = texture2D(viewL,textureCoord);",
#else
			"  vec4 colorR = texture2D(viewR,textureCoord);",
			"  vec4 colorL = texture2D(viewL,textureCoord);",
#endif
			"  gl_FragColor = colorR;",
			"  if(w>0.5) gl_FragColor = colorL;",
			"}"
		};
		if( !mCompFragS->compileFromText( sizeof(fragShaderText)/4, fragShaderText) ){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Parallax fragment shader could not be compiled.");
			return false;
		}

		//////////////////////////////////////////////////////////////////////////
		// CREATE HW PROGRAM
		mCompProg->attachShader(*mCompFragS);
		if(!mCompProg->link()){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Parallax GPU program could not be linked.");
			return false;
		}

		mCompProg->bindResource();
		//////////////////////////////////////////////////////////////////////////
		// RETRIEVE UNIFORM BINDINGS
		if(mImageSampler_L) delete mImageSampler_L;
		mImageSampler_L = new RenderProp_Uniform("viewL",UniformType_Int_1);
		mImageSampler_L->setDataAtIndex(0,0);
		mImageSampler_L->bindToProgram(*mCompProg);
		mImageSampler_L->activate();

		if(mImageSampler_R) delete mImageSampler_R;
		mImageSampler_R = new RenderProp_Uniform("viewR",UniformType_Int_1);
		mImageSampler_R->setDataAtIndex(0,1);
		mImageSampler_R->bindToProgram(*mCompProg);
		mImageSampler_R->activate();

		return true;
	}

	void MVC_Parallax::initCompositorGeom(){
		size_t numVertices = 4;

		mCompositorGeom.mIndexDataPtr.reset(new IndexData());
		mCompositorGeom.mIndexDataPtr->primType = PrimitiveType_TriangleStrip;
		mCompositorGeom.mIndexDataPtr->mRange.set(0,numVertices);

		mCompositorGeom.mVertexDataPtr.reset(new VertexData());
		mCompositorGeom.mVertexDataPtr->mRange.set(0,numVertices);
		VertexAttribute attribVertex  (0,0,VertexAttribDataType_Byte,VertexAttribDataCount2,"vertexIn");
		mCompositorGeom.mVertexDataPtr->insertAttribute(attribVertex);

		GPUVertexBufferPtr bufPtr( new GPUVertexBuffer(
			mCompositorGeom.mVertexDataPtr->getVertexSize(0), numVertices, 
			BufferUsageFreq_Static,BufferUsageNature_Draw) );
		mCompositorGeom.mVertexDataPtr->linkBufferToIndex(0,bufPtr);
		GLbyte geometryArray[4*4];
		int t=0;
		// vertex coordinates
		geometryArray[t++] = -1; geometryArray[t++] = -1;
		geometryArray[t++] =  1; geometryArray[t++] = -1;
		geometryArray[t++] = -1; geometryArray[t++] =  1;
		geometryArray[t++] =  1; geometryArray[t++] =  1;
		bufPtr->writeData(geometryArray);
	}

	bool MVC_Parallax::init(Viewport& vp){
		if(mIsInitialized) return true;
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "MultiViewCompositor Parallax initializing...");

		if(updateCompProg()==false) return false;
		initCompositorGeom();

		mIsInitialized = true;
		mIsSupported = true;
		LOG4CPLUS_INFO(logger, "MVC Parallax initialization completed.");
		return true;
	}

	bool MVC_Parallax::clear(){
		if(mImageSampler_L){ delete mImageSampler_L; mImageSampler_L=0; }
		if(mImageSampler_R){ delete mImageSampler_R; mImageSampler_R=0; }
		if(mCompProg){ delete mCompProg; mCompProg=0; }
		if(mCompFragS){ delete mCompFragS; mCompFragS=0; }
		mIsInitialized = false;
		return true;
	}

	bool MVC_Parallax::mergeViews(MultiViewBuffer& mvb){
		if(!isSupported()) return false;
		glDisable(GL_DEPTH_TEST);

		// activate view buffers
		for(REng::uint i=0; i<getViewCount(); i++){
			GPUTexture::setActiveTextureUnit(i);
			mvb.getColorTarget(i)->bindResource();
		}

		// activate GPU program, send the meshes, and we are done.
		// Note: Does not use model-view-projection variables!
		mCompProg->bindResource();
		GPUDrawer::getSingleton().drawMeshGeom(mCompositorGeom);

		glEnable(GL_DEPTH_TEST);
		return true;
	}

	/************************************************************************/
	/* MVC_Parallax_Stencil                                                 */
	/************************************************************************/

	MVC_Parallax_Stencil::MVC_Parallax_Stencil() 
		: MultiViewCompositor(2)
		,mResetStencilEveryFrame(false)
		,mTransposeViewAxis(false)
	{ ; }

	MVC_Parallax_Stencil::~MVC_Parallax_Stencil(){ ; }

	bool MVC_Parallax_Stencil::isViewAxisTransposed() const{
		return mTransposeViewAxis;
	}
	void MVC_Parallax_Stencil::setViewAxisTransposed(bool val) const{
		if(val != mTransposeViewAxis){
			mTransposeViewAxis = val;
			if(mStencilGenMat.get()==NULL) return;
			updateStencilGenProg();
			updateStencilPattern();
		}
	}
	void MVC_Parallax_Stencil::updateStencilGenProg() const{
		MaterialProgramPtr prog = MaterialManager::getSingleton().getMaterialProgram(
			mTransposeViewAxis?"MV_Parallax_Prog_Trans":"MV_Parallax_Prog");
		if(!prog->isResolved()) prog->resolveAttachAndLinkShaders();
		if(!prog->isLinked()) prog->link();
		mStencilGenMat->getSuitableData()->getRenderPass()->setProgram(prog);
	}


	void MVC_Parallax_Stencil::initFillerGeom(){
		size_t numVertices = 4;

		mFillerGeom.mIndexDataPtr.reset(new IndexData());
		mFillerGeom.mIndexDataPtr->primType = PrimitiveType_TriangleStrip;
		mFillerGeom.mIndexDataPtr->mRange.set(0,numVertices);

		mFillerGeom.mVertexDataPtr.reset(new VertexData());
		mFillerGeom.mVertexDataPtr->mRange.set(0,numVertices);
		VertexAttribute attribVertex(0,0,VertexAttribDataType_Byte,VertexAttribDataCount2,"vertexIn");
		mFillerGeom.mVertexDataPtr->insertAttribute(attribVertex);

		GPUVertexBufferPtr bufPtr( new GPUVertexBuffer(
			mFillerGeom.mVertexDataPtr->getVertexSize(0), numVertices, 
			BufferUsageFreq_Static,BufferUsageNature_Draw) );
		mFillerGeom.mVertexDataPtr->linkBufferToIndex(0,bufPtr);
		GLbyte geometryArray[4*4];
		int t=0;
		// vertex coordinates
		geometryArray[t++] = -1; geometryArray[t++] = -1;
		geometryArray[t++] =  1; geometryArray[t++] = -1;
		geometryArray[t++] = -1; geometryArray[t++] =  1;
		geometryArray[t++] =  1; geometryArray[t++] =  1;
		bufPtr->writeData(geometryArray);
	}

	bool MVC_Parallax_Stencil::init(Viewport& vp){
		if(mIsInitialized) return true;
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "MultiViewCompositor Parallax (using Stencils) initializing...");

		initFillerGeom();

		// Setting up stencil generator pass basics
		const char* stencilSetupScript =
			"shader MV_Parallax_Stc_VS {"
			"  type vertex\n"
			"	source {{\n"
			"#ifdef GL_ES\n"
			"	const lowp vec2 madd=vec2(0.5,0.5);\n"
			"	attribute lowp vec2 vertexIn;\n"
			"	varying mediump vec2 textureCoord;\n"
			"#else\n"
			"	const vec2 madd=vec2(0.5,0.5);\n"
			"	in vec2 vertexIn;\n"
			"	out vec2 textureCoord;\n"
			"#endif\n"
			"	void main() {\n"
			"		textureCoord = vertexIn.xy*madd+madd;\n"
			"		gl_Position = vec4(vertexIn.xy,0.0,1.0);\n"
			"	} }}\n"
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
			"  version 130\n"
#endif
			"}\n"
			"shader MV_Parallax_Stc_FS {\n"
			"  type fragment\n"
			"	source {{ "
			"#ifdef GL_ES\n"
			"	varying mediump vec2 textureCoord;\n"
			"#else\n"
			"	in vec2 textureCoord;\n"
			"#endif\n"
			"	void main() {\n"
			"		if(mod(gl_FragCoord.x,2.0)>0.5) discard;\n"
			"		gl_FragColor = vec4(1,0,0,0);\n"
			"	} }}\n"
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
			"  version 130\n"
#endif
			"}\n"
			"shader MV_Parallax_Stc_FS_Trps {\n"
			"  type fragment\n"
			"	source {{ "
			"#ifdef GL_ES\n"
			"	varying mediump vec2 textureCoord;\n"
			"#else\n"
			"	in vec2 textureCoord;\n"
			"#endif\n"
			"	void main() {\n"
			"		if(mod(gl_FragCoord.y,2.0)>0.5) discard;\n"
			"		gl_FragColor = vec4(1,0,0,0);\n"
			"	} }}\n"
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
			"  version 130\n"
#endif
			"}\n"
			"program MV_Parallax_Prog { \n"
			"	shader_ref MV_Parallax_Stc_VS\n"
			"	shader_ref MV_Parallax_Stc_FS }\n"
			"program MV_Parallax_Prog_Trans { \n"
			"	shader_ref MV_Parallax_Stc_VS\n"
			"	shader_ref MV_Parallax_Stc_FS_Trps }\n"
			"material MV_Parallax_Stc_Mat { technique { pass {\n"
			"	program_ref MV_Parallax_Prog_Trans\n"
			"	render_states {\n"
			"		color_mask off off off off\n"
			"		depth_test off\n"
			"		stencil_test on\n"
			"		stencil_function FRONT_AND_BACK ALWAYS 1 255\n"
			"		stencil_operation FRONT_AND_BACK REPLACE REPLACE REPLACE\n"
			"	}\n"
			"} } }";
		MaterialScriptParser::getSingleton().parseFromMem(stencilSetupScript,strlen(stencilSetupScript));
		REng::MaterialManager::getSingleton().compileMaterialShaders();
		REng::MaterialManager::getSingleton().loadMaterials();

		mStencilGenMat = MaterialManager::getSingleton().getMaterial("MV_Parallax_Stc_Mat");
		updateStencilGenProg();
		RenderSystem::getSingleton().setViewportTrans(vp.getAbsRect());
		updateStencilPattern();

		mIsInitialized = true;
		mIsSupported = true;
		LOG4CPLUS_INFO(logger, "MVC Parallax (Stencil) initialization completed.");
		return true;
	}
	
	bool MVC_Parallax_Stencil::updateStencilPattern() const{
		// clear stencil buffer
		glClearStencil(0);
		glClear(GL_STENCIL_BUFFER_BIT);
		mStencilGenMat->getSuitableData()->getRenderPass()->prepareState();
		GPUDrawer::getSingleton().drawMeshGeom(mFillerGeom);
		mStencilGenMat->getSuitableData()->getRenderPass()->clearState();
		return true;
	}

	bool MVC_Parallax_Stencil::clear(){ 
		return true;
	}
	bool MVC_Parallax_Stencil::beginFrame(){
		if(mResetStencilEveryFrame) {
			updateStencilPattern();
		} else {
			// at least do it once more (TODO: fix this bug-trick)
			EXEC_ONCE_BEGIN();
			updateStencilPattern();
			EXEC_ONCE_END();
		}
		RenderProp_StencilTest stenTest(true);
		RenderProp_StencilOp stenOp(FaceType_FrontAndBack);
		stenTest.activate();
		stenOp.deactivate();
		return true;
	}
	bool MVC_Parallax_Stencil::setActiveView(size_t viewIndex){
		RenderProp_StencilFunc stenFunc(
			FaceType_FrontAndBack,
			viewIndex?CompareFunc_Equal:CompareFunc_NotEqual,
			1);
		stenFunc.activate();
		return true;
	}
	bool MVC_Parallax_Stencil::endFrame(){
		RenderProp_StencilTest stenTest(true);
		stenTest.deactivate();
		return true;
	}

}

