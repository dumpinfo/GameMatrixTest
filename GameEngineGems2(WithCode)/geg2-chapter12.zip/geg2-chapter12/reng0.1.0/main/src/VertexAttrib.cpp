/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/VertexIndexData.h"

namespace REng{

	/************************************************************************/
	/* VERTEX ATTRIBUTE                                                     */
	/************************************************************************/

	VertexAttribute::VertexAttribute(unsigned char source, size_t offset, VertexAttribDataType dataType, 
		VertexAttribDataCount dataCount, VertexAttribSemantic semantic)
		: mNormalize(false),
		mBatchMode(VertexAttribBatch_None),
		mSourceBufferIndex(source),
		mStartOffset(offset),
		mDataType(dataType),
		mDataCount(dataCount),
		mSemantic(semantic) {
		mName = getVertexAttribSemanticStr(mSemantic);
	}

	VertexAttribute::VertexAttribute(unsigned char source, size_t offset, VertexAttribDataType dataType, 
		VertexAttribDataCount dataCount, const std::string& name)
		:	mNormalize(false),
		mBatchMode(VertexAttribBatch_None),
		mSourceBufferIndex(source),
		mStartOffset(offset),
		mDataType(dataType),
		mDataCount(dataCount),
		mSemantic(VertexAttribSem_None),
		mName(name)
		{ ; }

	VertexAttribute::~VertexAttribute(){
	}

	unsigned char VertexAttribute::getSourceBufferIndex(void) const { 
		return mSourceBufferIndex; 
	}
	size_t VertexAttribute::getStartOffset(void) const { 
		return mStartOffset; 
	}
	VertexAttribDataType VertexAttribute::getDataType(void) const { 
		return mDataType; 
	}
	VertexAttribDataCount VertexAttribute::getDataCount(void) const { 
		return mDataCount; 
	}
	VertexAttribSemantic VertexAttribute::getSemantic(void) const { 
		return mSemantic; 
	}
	const std::string& VertexAttribute::getName() const{
		return mName;
	}
	size_t VertexAttribute::getSizeInBytes(void) const{
		// TODO: if the type is not supported, return 0;
		if(mDataType == GL_NONE){
			// the data type is not supported
			return 0;
		}
		switch(mDataType){
			case VertexAttribDataType_Byte:
			case VertexAttribDataType_UByte:
				return 1*mDataCount;
			case VertexAttribDataType_Short:
			case VertexAttribDataType_UShort:
			case VertexAttribDataType_HalfFloat:
				return 2*mDataCount;
			case VertexAttribDataType_Int:
			case VertexAttribDataType_UInt:
			case VertexAttribDataType_Float:
			case VertexAttribDataType_Fixed:
				return 4*mDataCount;
			case VertexAttribDataType_Double:
				return 8*mDataCount;
			default:
				return 0;
		}
	}

	bool VertexAttribute::operator==(const VertexAttribute& rhs) const{
		if(this->mDataCount != rhs.mDataCount)
			return false;
		if(this->mDataType != rhs.mDataType)
			return false;
		if(this->mStartOffset != rhs.mStartOffset)
			return false;
		if(this->mSemantic != rhs.mSemantic)
			return false;
		if(this->mSourceBufferIndex != rhs.mSourceBufferIndex)
			return false;
		return true;
	}

} // namespace REng
