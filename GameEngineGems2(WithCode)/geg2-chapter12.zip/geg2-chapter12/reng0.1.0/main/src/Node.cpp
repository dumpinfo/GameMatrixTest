/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Node.h"
#include <algorithm>
#include <cstdlib> // std::abs

#include "REng/Camera.h"
#include "REng/Light.h"

// used for triad
#include "REng/MeshGeomGenerator.h"
#include "REng/Material/MaterialManager.h"
#include "REng/MeshManager.h"
#include "REng/Geom/Geom.h"

// nodes store illumination info
#include "REng/LightingManager.h"

// default renderqueue ID
#include "REng/RenderQueue.h"

// quaternion-vector extensions
#include "REng/Math.h"

using namespace std;

namespace REng  {

	BillboardTarget::BillboardTarget(){
		target = 0;
	}
	BillboardTarget::~BillboardTarget(){ ; }
	BillboardTarget& BillboardTarget::operator=(const BillboardTarget& target){
		if(this != &target) {
			if(target.upAxis) {
				upAxis.reset(new Vector3(*(target.upAxis)));
			} else {
				upAxis.reset();
			}
			if(target.lookPerpAxis){
				lookPerpAxis.reset(new Vector3(*(target.lookPerpAxis)));
			} else {
				lookPerpAxis.reset();
			}
		}
		return *this;
	}

	/************************************************************************/
	/* SCENE NODE                                                           */
	/************************************************************************/

	/* Node Registry                                                        */
	uint SceneNode::mUniqueNodeIDGen = 0;
	std::vector<SceneNode*> SceneNode::mNodeIDMapping;
	void SceneNode::registerNode(SceneNode& node){
		node.mID = mUniqueNodeIDGen;
		mUniqueNodeIDGen++;
		mNodeIDMapping.push_back(&node);
	}
	void SceneNode::unregisterNode(SceneNode& node){
		if(node.getID()>mUniqueNodeIDGen) return;
		mNodeIDMapping[node.getID()] = 0;
	}

	SceneNode::SceneNode(GroupNode* parent, SceneNodeType type)
		:mParent(parent)
		,mNodeType(type)
		,mUserData(0)
		,mInheritanceFlags(NodeInheritance_Translation | NodeInheritance_Rotation | 
		                  NodeInheritance_Scale | NodeInheritance_Billboard)
		,mDirtyFlags(0)
		,mCullingMode(CULL_DYNAMIC)
	{
		// inform parent
		if(mParent) mParent->addChild(*this);
		// initialize billboard data (done by billboard target constructor)
		// initialize (reset) local transformation data
		_mWorld_Translation.zero();
		_mWorld_Scale.set(1.0f,1.0f,1.0f);
		_mWorld_Rotation.identity();

		RenderBoundingVolume = false;
		mBoundingVolume_WS = 0;
		if(parent==0)
			mRenderQueueID = RenderQueueID_NodeDefault;
		else
			mRenderQueueID = parent->mRenderQueueID;

		translate_Parent(cml::zero_3D(),true);
		Quaternion noRot;
		rotate_Parent(noRot.identity(),true);
		scale_Parent(cml::zero_3D().set(1.0f,1.0f,1.0f),true);

		registerNode(*this);
	}
	SceneNode::~SceneNode() { 
		if(mParent) mParent->removeChild(*this);
		unregisterNode(*this);
	}
	SceneNodeType SceneNode::getType() const{
		return mNodeType;
	}
	uint SceneNode::getID() const{
		return mID;
	}
	SceneNode* SceneNode::getSceneNode(uint id){
		if(id>=mUniqueNodeIDGen) return 0;
		return mNodeIDMapping[id];
	}
	void SceneNode::cloneBasicData(SceneNode& node) const{
		cloneBillboardTarget(node);
		cloneBoundingVolume(node);
		cloneInheritanceFlags(node);
		cloneSpatialData(node);
		node.mCullingMode = this->mCullingMode;
		node.mRenderQueueID = this->mRenderQueueID;
	}

	
	/* Parent Access ********************************************************/
	bool SceneNode::setParent(GroupNode& parent){
		if(&parent == mParent) return false;
		// cyclic graph checking
		//   the parent given in the parameter cannot be a child of the current node.
		//   in other words, the current node cannot be a parent (above) of the given node
		const GroupNode* cyclicNode = parent.getParent();
		while(true){
			// detect safe case
			if(cyclicNode->getType() == SceneNode_Root) break;
			// detect error case
			if(cyclicNode == this) return false;
			cyclicNode = cyclicNode->getParent();
		}
		mParent->removeChild(*this);
		mParent = &parent;
		mParent->addChild(*this);
		return true;
	}
	const GroupNode* SceneNode::getParent() const {
		return mParent;
	}
	GroupNode* SceneNode::getParent() {
		return mParent;
	}
	void SceneNode::detachFromParent(){
		if(mParent){
			mParent->removeChild(*this);
			mParent = 0;
		}
	}


	/* Inheritance Flags ****************************************************/
	void SceneNode::setInheritanceFlag(NodeInheritanceFlag flag){
		mInheritanceFlags = mInheritanceFlags | flag;
		switch(flag){
			case NodeInheritance_Translation: setDirtyFlag(Dirty_World_Translation);  break;
			case NodeInheritance_Rotation:    setDirtyFlag(Dirty_World_Rotation);     break;
			case NodeInheritance_Scale:       setDirtyFlag(Dirty_World_Scale);        break;
			case NodeInheritance_Billboard:   
				if(mParent) mBillboardTarget = mParent->getBillboardTargetNode(); 
				break;
		}
	}
	void SceneNode::unsetInheritanceFlag(NodeInheritanceFlag flag){
		mInheritanceFlags = mInheritanceFlags & ~flag;
		switch(flag){
			case NodeInheritance_Translation: setDirtyFlag(Dirty_World_Translation);  break;
			case NodeInheritance_Rotation:    setDirtyFlag(Dirty_World_Rotation);     break;
			case NodeInheritance_Scale:       setDirtyFlag(Dirty_World_Scale);        break;
			default: break;
		}
	}
	bool SceneNode::isInherited(NodeInheritanceFlag flag) const{
		return (mInheritanceFlags & flag) != 0;
	}
	void SceneNode::cloneInheritanceFlags(SceneNode& node) const{
		node.mInheritanceFlags = this->mInheritanceFlags;
	}

	uchar SceneNode::getRenderQueueGroupID() const{
		return mRenderQueueID;
	}
	void SceneNode::setRenderQueueGroupID(uchar queueID) {
		mRenderQueueID = queueID;
	}


	/* Billboards ***********************************************************/
	void SceneNode::setBillboardTarget(const BillboardTarget& target){
		mBillboardTarget = mBillboardTarget;
	}
	void SceneNode::clearBillboardTarget(){
		mBillboardTarget.target = 0;
	}
	const BillboardTarget& SceneNode::getBillboardTargetNode() const{
		return mBillboardTarget;
	}
	void SceneNode::cloneBillboardTarget(SceneNode& node) const{
		node.mBillboardTarget = this->mBillboardTarget;
	}

	/* Dirty Flags **********************************************************/
	void SceneNode::setDirtyFlag(SceneNode::DirtyFlag flag) const{
		mDirtyFlags = mDirtyFlags | flag;
		switch(flag){
			case Dirty_World_Scale:
			case Dirty_World_Translation:
			case Dirty_World_Rotation:
				setDirtyFlag(Dirty_World_Transform);
				setDirtyFlag(Dirty_Bounding_Volume);
				break;
			case Dirty_Bounding_Volume:
				if(hasBoundingVolume() && mParent){
					mParent->notifyChildBoundUpdate();
				}
				break;
			default:
				break;
		}
	}
	void SceneNode::unsetDirtyFlag(SceneNode::DirtyFlag flag) const{
		mDirtyFlags = mDirtyFlags & ~flag;
	}
	bool SceneNode::isDirtyFlag(SceneNode::DirtyFlag flag) const{
		return (mDirtyFlags & flag) != 0;
	}

	/* Bounding Boxes ********************************************************/
	const GeomVolume* SceneNode::getBoundingVolume_WS() const{
		if(mBoundingVolume_WS==0) return 0;
		if(isDirtyFlag(Dirty_Bounding_Volume)) updateBoundingVolume();
		return mBoundingVolume_WS;
	}
	bool SceneNode::hasBoundingVolume() const{
		return mBoundingVolume_WS!=0;
	}
	// Note: this method is not public and is called only when there is a bounding volume of the node.
	void SceneNode::updateBoundingVolume() const{
		// TODO-review
		// Needs to use world-space translation, rotation and orientation. Update those.
		updateWorld_Rotation();
		updateWorld_Scale();
		updateWorld_Translation();

		// reset the world-space bounding volume to mesh-space volume
		resetBoundingVolume();

		// update mesh-space to world-space using node's world transformation data.
		Vector3 translator;
		translator.set(0,0,0);
		// SCALE
		{
			mBoundingVolume_WS->scale(_mWorld_Scale);
			// apply position offset correction
			if(mPosOffsetActive){
				//translator += comp_product( mBoundingVolume_WS->getPosition(), _mWorld_Scale-Vector3(1.0f,1.0f,1.0f) );
				translator[0] = mBoundingVolume_WS->getPosition()[0]*_mWorld_Scale[0];
				translator[1] = mBoundingVolume_WS->getPosition()[1]*_mWorld_Scale[1];
				translator[2] = mBoundingVolume_WS->getPosition()[2]*_mWorld_Scale[2];
			}
		}
		// ROTATE
		{
			mBoundingVolume_WS->rotate_World(_mWorld_Rotation);
			// apply position offset correction
			if(mPosOffsetActive){
				Matrix4 correctorMatrix;
				cml::matrix_rotation_quaternion(correctorMatrix,_mWorld_Rotation);
				translator = cml::transform_vector(correctorMatrix,translator);
				translator -= mBoundingVolume_NS->getPosition();
				//translator += comp_product( correctorV, _mWorld_Scale);
			}
		}
		// TRANSLATE
		{
			translator+=_mWorld_Translation;
			mBoundingVolume_WS->translate_World(translator);
		}

		unsetDirtyFlag(Dirty_Bounding_Volume);
		return;
	}
	void SceneNode::resetBoundingVolume() const{
		switch(mBoundingVolume_NS->getType()){
			case GeomTypeAABox: {
					const GeomAxisAlignedBox* from(static_cast<const GeomAxisAlignedBox*>(mBoundingVolume_NS));
					GeomAxisAlignedBox* to(static_cast<GeomAxisAlignedBox*>(mBoundingVolume_WS));
					to->setGeom(from->getPosition(),from->getHalfSize(),GeomAxisAlignedBox::Set_CenterHSize);
				}
				break;
			case GeomTypeOBox: {
					const GeomOrientedBox* from(static_cast<const GeomOrientedBox*>(mBoundingVolume_NS));
					GeomOrientedBox* to(static_cast<GeomOrientedBox*>(mBoundingVolume_WS));
					to->setGeom(from->getPosition(),from->getHalfSize(),from->getWorldOrientation());
				}
				break;
			case GeomTypeSphere:{
					const GeomSphere* from(static_cast<const GeomSphere*>(mBoundingVolume_NS));
					GeomSphere* to(static_cast<GeomSphere*>(mBoundingVolume_WS));
					to->setGeom(from->getPosition(),from->getRadius());
				}
				break;
			case GeomTypeCyclinder:{
				// TODO
				}
				break;
			case GeomTypePBV:
				// TODO
				break;
			// non-volumetric geom types
			case GeomTypePlane:
			case GeomTypeLine:
			case GeomTypePoint:
			default:
				break;
		}
	}
	void SceneNode::cloneBoundingVolume(SceneNode& node) const{
		node.RenderBoundingVolume = this->RenderBoundingVolume;
		node.mBoundingVolume_NS = this->mBoundingVolume_NS;
		node.setDirtyFlag(Dirty_Bounding_Volume);
		node.mPosOffsetActive = this->mPosOffsetActive;
	}


	/* Spatial Methods - Getters *********************************************/
	const Vector3& SceneNode::getTranslation_Parent() const{
		return _mParent_Translation;
	}
	const Quaternion& SceneNode::getRotation_Parent() const{
		return _mParent_Rotation;
	}
	const Vector3& SceneNode::getScale_Parent() const{
		return _mParent_Scale;
	}
	const Vector3& SceneNode::getTranslation_World() const{
		updateWorld_Translation();
		return _mWorld_Translation;
	}
	const Quaternion& SceneNode::getRotation_World() const{
		updateWorld_Rotation();
		return _mWorld_Rotation;
	}
	const Vector3& SceneNode::getScale_World() const{
		updateWorld_Scale();
		return _mWorld_Scale;
	}
	const Matrix4& SceneNode::getWorld_Transform() const {
		updateWorld_Transform();
		return _mWorld_Transform;
	}

	Vector3 SceneNode::getUp() const{
		return cml::normalize(cml::quaternion_get_y_basis_vector(getRotation_World()));
//		updateWorld_Rotation();
//		Vector3 vec(0.0f,1.0f,0.0f);
//		return Math::rotateVector(_mWorld_Rotation,vec);
	}
	Vector3 SceneNode::getRight() const{
		return cml::normalize(cml::quaternion_get_x_basis_vector(getRotation_World()));
//		updateWorld_Rotation();
//		Vector3 vec(1.0f,0.0f,0.0f);
//		return Math::rotateVector(_mWorld_Rotation,vec);
	}
	Vector3 SceneNode::getDirection() const{
		return cml::normalize(-1*cml::quaternion_get_z_basis_vector(getRotation_World()));
//		updateWorld_Rotation();
//		Vector3 vec(0.0f,0.0f,-1.0f);
//		return Math::rotateVector(_mWorld_Rotation,vec);
	}

	void SceneNode::cloneSpatialData(SceneNode& node) const{
		// below will set the dirty flags as necessary
		node.translate_Parent(this->getTranslation_Parent(),true);
		node.rotate_Parent(this->getRotation_Parent(),true);
		node.scale_Parent(this->getScale_Parent(),true);
	}

	/* Spatial Methods - Updaters *******************************************/
	bool SceneNode::updateWorld_Translation() const{
		if(!isDirtyFlag(Dirty_World_Translation)) return false; 
		if(mParent!=0 && isInherited(NodeInheritance_Translation)){
			// create the parent rotation matrix (to transform the translation)
			const Vector3& parentTrans(mParent->getTranslation_World());
			const Vector3& parentScale(mParent->getScale_World());
			const Quaternion& parentQuat(mParent->getRotation_World());
			_mWorld_Translation = 
				parentTrans + Math::rotateVector(parentQuat, comp_product(_mParent_Translation, parentScale));
			// TODO: option 2: only inherit the parent's position
		} else {
			_mWorld_Translation = _mParent_Translation;
		}
		unsetDirtyFlag(Dirty_World_Translation);
		return true;
	}
	bool SceneNode::updateWorld_Rotation() const{
		if(!isDirtyFlag(Dirty_World_Rotation)) return false; 
		if(mParent!=0 && isInherited(NodeInheritance_Rotation)){
			// local rotation is applied after parent's rotation
			_mWorld_Rotation = _mParent_Rotation * mParent->getRotation_World();
		} else {
			_mWorld_Rotation = _mParent_Rotation;
		}
		unsetDirtyFlag(Dirty_World_Rotation);
		return true;
	}
	bool SceneNode::updateWorld_Scale() const{
		if(!isDirtyFlag(Dirty_World_Scale)) return false; 
		if (mParent!=0 && isInherited(NodeInheritance_Scale)){
			_mWorld_Scale = comp_product(_mParent_Scale, mParent->getScale_World());
		} else {
			_mWorld_Scale = _mParent_Scale;
		}
		unsetDirtyFlag(Dirty_World_Scale);
		return true;
	}
	bool SceneNode::updateWorld_Transform() const {
		if(isDirtyFlag(Dirty_World_Transform) == false) return false;
		updateWorld_Translation();
		updateWorld_Rotation();
		updateWorld_Scale();
		Matrix4 matMult;
		_mWorld_Transform.identity();
		// 3. translation
		cml::matrix_translation(matMult,_mWorld_Translation);
		_mWorld_Transform *= matMult;
		// 2. rotation
		cml::matrix_rotation_quaternion(matMult,_mWorld_Rotation);
		_mWorld_Transform *= matMult;
		// 1. scale
		cml::matrix_scale(matMult,_mWorld_Scale);
		_mWorld_Transform *= matMult;
		unsetDirtyFlag(Dirty_World_Transform);
		return true;
	}

	void SceneNode::translate_Local(const Vector3& pos, bool reset) {
		// convert local base-axis translation to parent base-axis translation
		Vector3 updater(Math::rotateVector(_mParent_Rotation,pos));
		if(reset) _mParent_Translation  = updater;
		else      _mParent_Translation += updater;
		setDirtyFlag(Dirty_World_Translation);
	}
	void SceneNode::translate_Parent(const Vector3& pos, bool reset) {
		if(reset) _mParent_Translation  = pos;
		else      _mParent_Translation += pos;
		setDirtyFlag(Dirty_World_Translation);
	}

	void SceneNode::translate_World(const Vector3& pos, bool reset) {
		// update current world position
		if(reset) {
			_mWorld_Translation = pos;
		} else {
			updateWorld_Translation();
			_mWorld_Translation += pos;
		}
		{	// update parent translation using world translation
			const Vector3& parentTrans(mParent->getTranslation_World());
			const Vector3& parentScale(mParent->getScale_World());
			const Quaternion& parentQuat(mParent->getRotation_World());
			_mParent_Translation = Math::rotateVector(cml::inverse(parentQuat),_mWorld_Translation-parentTrans);
			_mParent_Translation[0] /= parentScale[0];
			_mParent_Translation[1] /= parentScale[1];
			_mParent_Translation[2] /= parentScale[2];
		}
		setDirtyFlag(Dirty_World_Translation);
		unsetDirtyFlag(Dirty_World_Translation);
		setDirtyFlag(Dirty_World_Transform);
		setDirtyFlag(Dirty_Bounding_Volume);
/*
		Vector3 updater;
		Matrix4 matRot;
		// update local transformation (to keep the state consistent)
		if(mParent){
			// apply inverse of "updateWorld_Translation" operation
			// TODO: update / simplify
			quaternionf_n parentWorldRotation(mParent->getRotation_World());
			parentWorldRotation.inverse();
			matrix_rotation_quaternion(matRot,parentWorldRotation);
			updater = transform_vector(matRot, pos);
			updater[0] /= mParent->getScale_World()[0];
			updater[1] /= mParent->getScale_World()[1];
			updater[2] /= mParent->getScale_World()[2];
		} else {
			updater = pos;
		}
		// TODO... continue
*/
	}

	void SceneNode::rotate_Parent(const Quaternion& orient, bool reset) {
		if(reset) _mParent_Rotation.identity();
		// new rotation is applied after previous rotation
		_mParent_Rotation = orient * _mParent_Rotation;
		setDirtyFlag(Dirty_World_Rotation);
	}
	void SceneNode::rotate_World(const Quaternion& orient, bool reset) {
		if(reset){
			_mWorld_Rotation = orient;
		} else {
			// first you apply the new provided rotation, then the old rotation
			_mWorld_Rotation = _mWorld_Rotation * orient;
		}
		_mParent_Rotation = _mWorld_Rotation * inverse(mParent->getRotation_World());
		// we will not make world rotation dirty, we update it directly!
		setDirtyFlag(Dirty_World_Rotation);
		unsetDirtyFlag(Dirty_World_Rotation);
	}
	void SceneNode::rotate_Local(const Quaternion& _rotate, bool reset){
		if(reset==true){ rotate_Parent(_rotate,true); return; }
		// convert given local-axis rotation to parent-axis rotation
		updateWorld_Rotation();
		Quaternion newWorldRot(_rotate * _mWorld_Rotation);
		rotate_World(newWorldRot,true);
	}
	void SceneNode::scale_Parent(const Vector3& _scale, bool reset){
		if(reset) _mParent_Scale.set(1.0f,1.0f,1.0f);
		_mParent_Scale = comp_product(_mParent_Scale,_scale);
		setDirtyFlag(Dirty_World_Scale);
	}
	void SceneNode::scale_Parent(float ratio, bool reset){
		scale_Parent(Vector3(ratio,ratio,ratio),reset);
	}
	
	/************************************************************************/
	/* GROUP NODE                                                           */
	/************************************************************************/
	
	GroupNode::GroupNode() : SceneNode(0, SceneNode_Group) { ; }
	GroupNode::GroupNode(GroupNode& parent) 
		: SceneNode(&parent, SceneNode_Group), 
		mGenDynBoundingVol(false) { ; }
	GroupNode::~GroupNode() { 
		SceneNodeList::iterator it = mChildNodes.begin();
		SceneNodeList::iterator it_end = mChildNodes.end();
		for( ; it != it_end ; it++) {
			SceneNode* curNode = (*it);
			delete curNode;
		}
	}
	GroupNode& GroupNode::cloneMeshStruct(GroupNode& parent) const{
		GroupNode* topNode = new GroupNode(parent);

		// cloning
		this->cloneBasicData(*topNode);

		SceneNodeList::const_iterator it = mChildNodes.begin(), it_end = mChildNodes.end();
		for( ; it != it_end ; it++) {
			SceneNode* curNode = (*it);
			switch(curNode->getType()){
				case SceneNode_Group:
					// let recursion handle the rest
					topNode->addChild(((GroupNode*)curNode)->cloneMeshStruct(*topNode));
					break;
				case SceneNode_Mesh:
					{
						MeshNode& meshNode(MeshNode::create(*topNode));
						meshNode.setMesh(((MeshNode*)curNode)->getMesh());
						curNode->cloneBasicData(meshNode);
					}
					break;
				default: // all other types of nodes are not cloned
					break;
			}
		}
		return *topNode;
	}

	void GroupNode::notifyChildBoundUpdate(){
		setDirtyFlag(Dirty_Bounding_Volume);
	}
	void GroupNode::updateBoundingVolume() const{
		unsetDirtyFlag(Dirty_Bounding_Volume);
	}
	GroupNode& GroupNode::create(GroupNode& parent){
		return *(new GroupNode(parent));
	}
	void GroupNode::setNodeType(SceneNodeType type){
		mNodeType = type;
	}
	bool GroupNode::isChild(const SceneNode& node) const{
		SceneNodeList::const_iterator it = mChildNodes.begin();
		SceneNodeList::const_iterator it_end = mChildNodes.end();
		for( ; it != it_end ; it++) if((*it) == &node) return true;
		return false;
	}
	void GroupNode::addChild(SceneNode &node){
		if(isChild(node)) return;
		mChildNodes.push_back(&node);
	}
	void GroupNode::removeChild(SceneNode &child){
		SceneNodeList::iterator it = mChildNodes.begin();
		SceneNodeList::iterator it_end = mChildNodes.end();
		for( ; it != it_end ; it++){
			if((*it) == &child) {
				mChildNodes.erase(it);
				return;
			}
		}
	}
	void GroupNode::clearChildren(){
		mChildNodes.clear();
	}
	size_t GroupNode::getChildCount() const{
		return mChildNodes.size();
	}
	SceneNodeList& GroupNode::getChildren(){
		return mChildNodes;
	}
	SceneNode* GroupNode::getChild(size_t index){
		return mChildNodes[index];
	}

	void GroupNode::setRenderQueueGroupID(uchar groupID){
		SceneNode::setRenderQueueGroupID(groupID);
		SceneNodeList::iterator it = mChildNodes.begin();
		SceneNodeList::iterator it_end = mChildNodes.end();
		for( ; it != it_end ; it++){
			(*it)->setRenderQueueGroupID(groupID);
		}
	}

	void GroupNode::setBillboardTarget(const BillboardTarget& target){
		SceneNode::setBillboardTarget(target);
		SceneNodeList::iterator it = mChildNodes.begin();
		SceneNodeList::iterator it_end = mChildNodes.end();
		for( ; it != it_end ; it++){
			if((*it)->isInherited(NodeInheritance_Billboard)) {
				(*it)->setBillboardTarget(target);
			}
		}
	}

	void GroupNode::setDirtyFlag(SceneNode::DirtyFlag flag) const{
		uint checkChange = mDirtyFlags | flag;
		if(mDirtyFlags != checkChange){
			// notify children
			SceneNodeList::const_iterator it = mChildNodes.begin(), it_end = mChildNodes.end();
			switch(flag){
				case Dirty_World_Scale:
					for( ; it != it_end ; it++){
						if((*it)->isInherited(NodeInheritance_Scale))
							(*it)->setDirtyFlag(Dirty_World_Scale);
					}
					break;
				case Dirty_World_Translation:
					for( ; it != it_end ; it++){
						if((*it)->isInherited(NodeInheritance_Translation))
							(*it)->setDirtyFlag(Dirty_World_Translation);
					}
					break;
				case Dirty_World_Rotation:
					for( ; it != it_end ; it++){
						if((*it)->isInherited(NodeInheritance_Rotation)){
							(*it)->setDirtyFlag(Dirty_World_Rotation);
							(*it)->setDirtyFlag(Dirty_World_Translation);
						}
					}
					break;
				default: break;
			}
		}
		// do the regular update
		SceneNode::setDirtyFlag(flag);
	}

	/************************************************************************/
	/* ROOT NODE                                                            */
	/************************************************************************/

	// singleton stuff
	template<> RootNode* Singleton<RootNode>::ms_Singleton = 0;
	RootNode* RootNode::getSingletonPtr(void) {
		return ms_Singleton;
	}
	RootNode& RootNode::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}
	RootNode::RootNode() : GroupNode() { GroupNode::setNodeType(SceneNode_Root); }
	RootNode::~RootNode(){ ; }

	/************************************************************************/
	/* SWITCH GROUP NODE                                                    */
	/************************************************************************/

	SwitchGroupNode::SwitchGroupNode(GroupNode& parent) : GroupNode(parent), mActiveChildPtr(0){ 
		GroupNode::setNodeType(SceneNode_Switch);
	}
	SwitchGroupNode::~SwitchGroupNode() { ; }
	SwitchGroupNode& SwitchGroupNode::create(GroupNode& parent){
		return *(new SwitchGroupNode(parent));
	}
	void SwitchGroupNode::setNodeType(SceneNodeType type){
		GroupNode::setNodeType(type);
	}
	void SwitchGroupNode::removeChild(SceneNode &child){
		if(&child == mActiveChildPtr) mActiveChildPtr = 0;
		GroupNode::removeChild(child);
	}
	void SwitchGroupNode::setActiveNode(SceneNode& node){
		if(isChild(node)) mActiveChildPtr = &node;
	}
	SceneNode* SwitchGroupNode::getActiveNode(){
		return mActiveChildPtr;
	}
	const SceneNode* SwitchGroupNode::getActiveNode() const{
		return mActiveChildPtr;
	}

	/************************************************************************/
	/* LOD GROUP NODE                                                       */
	/************************************************************************/

	// TODO
	LODGroupNode::LODGroupNode(GroupNode& parent): SwitchGroupNode(parent) { ; }
	LODGroupNode& LODGroupNode::create(GroupNode& parent){
		return *(new LODGroupNode(parent));
	}
	LODGroupNode::~LODGroupNode(){ ;}
	void LODGroupNode::setActiveNode(SceneNode& node){}
	void LODGroupNode::addChild(SceneNode &child){}


	/************************************************************************/
	/* MESH NODE                                                            */
	/************************************************************************/

	MeshNode::MeshNode(GroupNode& parent) : SceneNode(&parent, SceneNode_Mesh){ ; }
	MeshNode::~MeshNode() { ; } // no special treatment is necessary
	MeshNode& MeshNode::create(GroupNode& parent){
		return *(new MeshNode(parent));
	}
	void MeshNode::setMesh(MeshPtr mesh){
		mMesh = mesh;
		// set bounding volume of this mesh node
		// TODO: Do not share pointers, create a new bounding volume object!!!
		if(mesh.get() != 0){
			const GeomVolume* gv = mesh->getSuitableData()->getBoundingVolume();
			if(gv==0) {
				mBoundingVolume_WS = 0;
				return;
			}
			// delete old bounding volume
			delete mBoundingVolume_WS;
			mBoundingVolume_WS = 0;
			mBoundingVolume_NS = 0;
			mPosOffsetActive = false;
			switch(gv->getType()){
				case GeomTypeAABox: {
						const GeomAxisAlignedBox* gv_aab = static_cast<const GeomAxisAlignedBox*>(gv);
						mBoundingVolume_WS = new GeomAxisAlignedBox(
							gv_aab->getPosition(), gv_aab->getHalfSize(), GeomAxisAlignedBox::Set_CenterHSize
							);
						mBoundingVolume_NS = new GeomAxisAlignedBox(
							gv_aab->getPosition(), gv_aab->getHalfSize(), GeomAxisAlignedBox::Set_CenterHSize
							);
						// check for equality in an epsilon range
						const Vector3& posDif(gv_aab->getPosition()-Vector3(0.0f,0.0f,0.0f));
						if( std::abs(posDif[0])>1e-7 ){
							mPosOffsetActive = true;
						} else if( std::abs(posDif[1])>1e-7 ){
							mPosOffsetActive = true;
						} else if( std::abs(posDif[2])>1e-7 ){
							mPosOffsetActive = true;
						}
					}
					break;
				case GeomTypeOBox: {
						const GeomOrientedBox* gv_ob = static_cast<const GeomOrientedBox*>(gv);
						mBoundingVolume_NS = new GeomOrientedBox(
							gv_ob->getPosition(), gv_ob->getHalfSize(), gv_ob->getWorldOrientation()
							);
						mBoundingVolume_WS = new GeomOrientedBox(
							gv_ob->getPosition(), gv_ob->getHalfSize(), gv_ob->getWorldOrientation()
							);
						if(gv_ob->getPosition() != Vector3(0.0f,0.0f,0.0f)){
							mPosOffsetActive = true;
						}
					}
					break;
				case GeomTypeSphere:{
						const GeomSphere* gv_sp = static_cast<const GeomSphere*>(gv);
						mBoundingVolume_WS = new GeomSphere(gv_sp->getPosition(), gv_sp->getRadius());
						mBoundingVolume_NS = new GeomSphere(gv_sp->getPosition(), gv_sp->getRadius());
						if(gv_sp->getPosition() != Vector3(0.0f,0.0f,0.0f)){
							mPosOffsetActive = true;
						}
					}
					break;
				case GeomTypeCyclinder:{
						const GeomCylinder* gv_c = static_cast<const GeomCylinder*>(gv);
						mBoundingVolume_WS = new GeomCylinder(
							gv_c->getHeight(), gv_c->getRadius(), gv_c->getPosition() );
						mBoundingVolume_NS = new GeomCylinder(
							gv_c->getHeight(), gv_c->getRadius(), gv_c->getPosition() );
						if(gv_c->getPosition() != Vector3(0.0f,0.0f,0.0f)){
							mPosOffsetActive = true;
					}
					}
					break;
				case GeomTypePBV:
					// TODO
					break;
				// non-volumetric geom types
				case GeomTypePlane:
				case GeomTypeLine:
				case GeomTypePoint:
				default:
					break;
			}
		}
	}
	MeshPtr MeshNode::getMesh(){
		return mMesh;
	}
	const MeshPtr MeshNode::getMesh() const{
		return mMesh;
	}
	bool MeshNode::isMeshAttached() const{
		return (mMesh.get() != 0);
	}

	/************************************************************************/
	/* CAMERA NODE                                                          */
	/************************************************************************/

	CameraNode::CameraNode(GroupNode& parent) : SceneNode(&parent, SceneNode_Camera), mCamera(0) {
		unsetInheritanceFlag(NodeInheritance_Scale);
	}
	CameraNode::~CameraNode(){ 
		delete mCamera;
	}
	CameraNode& CameraNode::create(GroupNode& parent){
		return *(new CameraNode(parent));
	}
	Camera* CameraNode::getCamera(){
		return mCamera;
	}
	bool CameraNode::isCameraAttached() const{
		return (mCamera!=0);
	}
/*	void CameraNode::rotateLookAt(const Vector3& eye, const Vector3& target, const Vector3& up){
		// 1. update inheritance modes (inherit no spatial data from parent)
		unsetInheritanceFlag(NodeInheritance_Rotation);
		unsetInheritanceFlag(NodeInheritance_Translation);

		// 2. generate the camera transformation matrix
//		Matrix4 transform;
//		matrix_look_at_RH(transform,eye,target,up); 
		// 3. decompose the transformation matrix and update the node transformation data.
//		float tmp;
//		Quaternion rotator;
//		Vector3 translator;
//		matrix_decompose_SRT(transform,tmp,tmp,tmp,rotator,translator);
//		translateLocal(translator,TS_PARENT,true);
//		rotateLocal(rotator,true);

		translateWorld(eye,true);
		Quaternion rotator;
		cml::quaternion_rotation_aim_at_axial(rotator,eye,target,up,cml::axis_order_xyz);
//		rotator = rotator.inverse();
		rotateLocal(rotator,true);

		getWorld_Translation();
		getRotation_World();
	}*/
	const Matrix4& CameraNode::getViewMatrix() const{
		calculateViewMatrix(getRotation_World(),getTranslation_World(),mViewMatrix);
		return mViewMatrix;
	}

	void CameraNode::updateBoundingVolume() const{
		if(mCamera==0) mBoundingVolume_WS = 0;
		mCamera->invalidateFrustum();
		mBoundingVolume_WS = const_cast<GeomPlaneBoundedVolume*>(&(mCamera->getFrustum_WS()));
		unsetDirtyFlag(Dirty_Bounding_Volume);
	}

	void CameraNode::calculateViewMatrix(const Quaternion& rotW, const Vector3& transW, Matrix4& result){
		// update mViewMatrix (reference : modified from OGRE source)
			// convert current quaternion rotation to a rotation matrix
		Matrix3 rotMat;
		cml::matrix_rotation_quaternion(rotMat,rotW);
			// transpose the rotation matrix
		rotMat.transpose();
			// translation is relative to rotation matrix
		Vector3 trans = -(cml::transform_vector(rotMat,transW));
		result.identity();
		result(0,0) = rotMat(0,0);
		result(0,1) = rotMat(0,1);
		result(0,2) = rotMat(0,2);
		result(1,0) = rotMat(1,0);
		result(1,1) = rotMat(1,1);
		result(1,2) = rotMat(1,2);
		result(2,0) = rotMat(2,0);
		result(2,1) = rotMat(2,1);
		result(2,2) = rotMat(2,2);
		cml::matrix_set_translation(result,trans);
	}





	/************************************************************************/
	/* LIGHT NODE                                                           */
	/************************************************************************/

	LightNode::LightNode(GroupNode& parent) : SceneNode(&parent, SceneNode_Light), mLight(0) { ; }
	LightNode::~LightNode(){ 
		delete mLight;
	}
	LightNode& LightNode::create(GroupNode& parent){
		return *(new LightNode(parent));
	}
	Light_Base* LightNode::getLight(){
		return mLight;
	}
	bool LightNode::isLightAttached() const{
		return (mLight!=0);
	}

	void LightNode::setDirtyFlag(SceneNode::DirtyFlag flag) const{
		if(mLight!=0){
			uint checkChange = mDirtyFlags | flag;
			if(mDirtyFlags != checkChange){
				switch(flag){
					case Dirty_World_Translation:
					case Dirty_World_Rotation:
						mLight->setNodeDirty();
						break;
					default:
						break;
				}
			}
		}
		// do the regular update
		SceneNode::setDirtyFlag(flag);
	}

	//Sort Them
	class Pick{
	public:
		Pick(SceneNode* _SceneNode, float _Distance):mSceneNode(_SceneNode),mDistance(_Distance){};
		SceneNode * mSceneNode;
		float mDistance;
		bool operator<(const Pick& a) const{
			return mDistance < a.mDistance;
		};
	};

	SceneNodeList GroupNode::pickMesh(GeomRay& ray){
		// Cansin & I.Doga
		SceneNodeList snl;

		//Get Picked Children/Grand Children Meshes
		for(size_t i=0;i<mChildNodes.size();++i){
			SceneNodeList tmp;
			if(mChildNodes[i]->getType()==SceneNode_Group)
				tmp = ((GroupNode*)mChildNodes[i])->pickMesh(ray);
			else if(mChildNodes[i]->getType()==SceneNode_Mesh)
				tmp = ((MeshNode*)mChildNodes[i])->pickMesh(ray);

			SceneNodeList tmpResult(snl.size()+tmp.size());
			sort(snl.begin(),snl.end());
			sort(tmp.begin(),tmp.end());
			merge(snl.begin(), snl.end(), tmp.begin(), tmp.end(), tmpResult.begin());
			snl=tmpResult;
		}
		
		std::vector<Pick> picks;
		for(unsigned int i=0;i<snl.size();i++){
			picks.push_back(Pick( snl[i] , GeomHelper::getDistanceSquared(ray.getPosition(),snl[i]->getBoundingVolume_WS()->getPosition() ) ) );
		}

		std::sort(picks.begin(),picks.end());
		
		snl.clear();
		for(unsigned int i=0;i<picks.size();i++){
			snl.push_back(picks[i].mSceneNode);
		}
		
		return snl;
	}

	SceneNodeList MeshNode::pickMesh(GeomRay& ray){
		SceneNodeList snl;
		
		if(hasBoundingVolume() && GeomHelper::intersects(ray,*getBoundingVolume_WS())){
			snl.push_back(this);
		}

		return snl;
	}

}
