/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include <boost/foreach.hpp>

#include "REng/RenderSystem.h"

// render system has its own logger
#include <log4cplus/logger.h>
#include <log4cplus/configurator.h>

// render system initializes image loading libraries
#if IMLOAD_LIB == IMLOAD_DEVIL
	#include <il/il.h>
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
	#include <FreeImage.h>
#endif

#include "REng/Defines.h"

// singleton instantiation
#include "REng/Material/MaterialManager.h"
#include "REng/Material/MaterialScriptParser.h"
#include "REng/Material/RenderPass.h"

#include "REng/MeshManager.h"
#include "REng/MeshGeomGenerator.h"
#include "REng/GeomRenderer.h"
#include "REng/LightingManager.h"

// getting up-to-date render matrices
#include "REng/RenderMatrixManager.h"

#include "REng/Node.h"
#include "REng/NodeVisibiltyVisitor.h"

// sys abstractions
// stores OS Window handle
#include "REng/sys/OSWindow_XWin.h"
#include "REng/sys/GLContext_EGL.h"
#include "REng/sys/GLContext_WGL.h"
#include "REng/sys/GLContext_GLX.h"

#include "REng/StatsCounter.h"

// to create GPUDrawer and render meshes
#include "REng/GPU/GPUDrawer.h"
#include "REng/GPU/GPUConfig.h"

// Viewport activation
#include "REng/Viewport.h"

using namespace log4cplus;
using namespace boost;
using namespace std;

namespace REng {

	// SINGLETON
	template<> RenderSystem* Singleton<RenderSystem>::ms_Singleton = 0;
	RenderSystem* RenderSystem::getSingletonPtr(void) {
		return ms_Singleton;
	}
	RenderSystem& RenderSystem::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	RenderSystem::RenderSystem()
		:mIsInited(false)
		,mOSWindowHandle(NULL)
		,mGLContext(NULL)
		,mColorTarget(NULL)
		,mDepthStencilTarget(NULL)
		,mDisableInternalSGRenderer(false)
		,mActiveViewport(NULL)
		,mActivePass(NULL)
		,mActiveCamera(NULL)
	{
		{
			log4cplus::PropertyConfigurator config("log.property");
			config.configure();
		}
		// create REng instances
		new RenderMatrixManager();
		new MaterialManager();
		new MaterialScriptParser();
		new MeshManager();
		new RootNode();
		new GPUConfig();
		new GeomRenderer();
		new MeshGeomGenerator();
		new StatsCounter();
		new GPUDrawer();
		new LightingManager();
		new RenderQueueMap();

		new RenderQueue_Background();
		mRenderQueue_BVs = new RenderQueue_BVs();
		RenderQueueMap::getSingleton().registerRenderQueue(new RenderQueue_Vector(),10);
		RenderQueueMap::getSingleton().registerRenderQueue(new RenderQueue_Vector(),2);

		#if defined USING_XLIB
			mOSWindowHandle = new OSWindow_X();
		#elif defined USING_WINCLS
			mOSWindowHandle = new OSWindow_Win();
		#else
			assert(0);
		#endif

		#if defined USING_EGL
			mGLContext = new GLContext_EGL();
		#elif defined USING_WGL
			mGLContext = new GLContext_WGL();
		#elif defined USING_GLX
			mGLContext = new GLContext_GLX();
		#else
			assert(0);
		#endif
	}

	RenderSystem::~RenderSystem(){ 
		shutdownWindowAndGLContext();
#if IMLOAD_LIB == IMLOAD_FREEIMAGE
		; // FreeImage_DeInitialise(); // call only when linking statically
#endif
	}
	OSWindow*  RenderSystem::getOSWindow() {
		return mOSWindowHandle;
	}
	GLContext* RenderSystem::getGLContext(){
		return mGLContext;
	}
	const RenderTarget_Window* RenderSystem::getWindowColorTarget() const{
		return mColorTarget;
	}
	const RenderTarget_Window* RenderSystem::getWindowDepthStencilTarget() const{
		return mDepthStencilTarget;
	}

	bool RenderSystem::createWindowAndGLContext(const RectI& position, const int* contextParams,
			inputCallback cb,const char* windowTitle, bool fullscreen)
	{
		Logger logger = Logger::getInstance("RSys");
		mGLContext->setContextParams(contextParams);

		// 1. Create OSWindow
		#ifdef USING_GLX
		((OSWindow_X*)mOSWindowHandle)->mGLX = (GLContext_GLX*) mGLContext;
		#endif
		bool success = mOSWindowHandle->createWindow(position,fullscreen,windowTitle);
		if(!success){
			return false;
		}
		
		#ifdef USING_GLX
		if(cb) { if(cb(mOSWindowHandle)==false) return false; }
		#endif

		// 2. Create OpenGL context
		success = mGLContext->init(mOSWindowHandle);
		if(!success){
			mOSWindowHandle->destroyWindow();
			return false;
		}

		#ifdef USING_WINCLS
		if(cb) { if(cb(mOSWindowHandle)==false) return false; }
		#endif

		// 3. Create Default frame buffer and window render targets
		mColorTarget = new RenderTarget_Window();
		mColorTarget->mWidth  = mOSWindowHandle->getPosition().getWidth();
		mColorTarget->mHeight = mOSWindowHandle->getPosition().getHeight();
		mColorTarget->mInternalFormat = ImageFormat_RGBA; // TODO
		mColorTarget->mSamples                   = mGLContext->getSamples();
		mColorTarget->mBitSize_Comp[RTC_Red]     = mGLContext->getResolution(RTC_Red);
		mColorTarget->mBitSize_Comp[RTC_Green]   = mGLContext->getResolution(RTC_Green);
		mColorTarget->mBitSize_Comp[RTC_Blue]    = mGLContext->getResolution(RTC_Blue);
		mColorTarget->mBitSize_Comp[RTC_Alpha]   = mGLContext->getResolution(RTC_Alpha);
		mColorTarget->mBitSize_Comp[RTC_Depth]   = 0;
		mColorTarget->mBitSize_Comp[RTC_Stencil] = 0;
		mDepthStencilTarget = new RenderTarget_Window();
		mDepthStencilTarget->mWidth  = mOSWindowHandle->getPosition().getWidth();
		mDepthStencilTarget->mHeight = mOSWindowHandle->getPosition().getHeight();
		mDepthStencilTarget->mSamples                   = mGLContext->getSamples();
		mDepthStencilTarget->mBitSize_Comp[RTC_Red]     = 0;
		mDepthStencilTarget->mBitSize_Comp[RTC_Green]   = 0;
		mDepthStencilTarget->mBitSize_Comp[RTC_Blue]    = 0;
		mDepthStencilTarget->mBitSize_Comp[RTC_Alpha]   = 0;
		mDepthStencilTarget->mBitSize_Comp[RTC_Depth]   = mGLContext->getResolution(RTC_Depth);
		mDepthStencilTarget->mBitSize_Comp[RTC_Stencil] = mGLContext->getResolution(RTC_Stencil);
		// set image format using depth-stencil resolutions
		if(mGLContext->getResolution(RTC_Depth)>0){
			if(mGLContext->getResolution(RTC_Stencil)>0)
				mDepthStencilTarget->mInternalFormat = ImageFormat_DS;
			else
				mDepthStencilTarget->mInternalFormat = ImageFormat_D;
		} else {
			if(mGLContext->getResolution(RTC_Stencil)>0)
				mDepthStencilTarget->mInternalFormat = ImageFormat_S;
			else
				mDepthStencilTarget->mInternalFormat = ImageFormat_None;
		}

		// TODO: attach color target to default frame buffer
		// TODO: attach depth-stencil target to default frame buffer
		
		// 4. Create the default viewport
		Viewport* vp= new Viewport();
		vp->setAbsRect(RectI(0,position.getWidth(),0,position.getHeight()));
		addViewport(0,vp);
		vp->autoClearColor(Color_Real(180.0f/256, 180.0f/256, 210.0f/256));
		vp->autoClearBuffer(FrameBufferComponent_Color,true);
		return true;
	}

	bool RenderSystem::shutdownWindowAndGLContext(){
		Logger logger = Logger::getInstance("RSys");
		bool success;
		if(!mGLContext->isInited()){
			// no valid window and OpenGL context was automatically created.
			return false;
		}
		// 1. release OpenGL context
		success = mGLContext->release();
		if(success==false){
			LOG4CPLUS_INFO(logger,"OpenGL context cannot be released.");
			return false;
		}
		// 2. release OSWindow handle
		success = mOSWindowHandle->destroyWindow();
		if(success==false){
			LOG4CPLUS_INFO(logger,"OSWindow handle cannot be destroyed.");
			return false;
		}
		return true;
	}

	bool RenderSystem::initSystem(bool loadDefaultMaterial) {
		CHECKGLERROR_TERM();
		if(mGLContext) { if(mGLContext->isInited()) mGLContext->logConfig(); }

		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"");
		LOG4CPLUS_INFO(logger,"++++++++++++++++++++++++++++++++++++++++++++++++++++++");
#ifdef RENG_DEBUG_BUILD
		LOG4CPLUS_INFO(logger,"+ Initializing Render System           (Debug Build) +");
#else
		LOG4CPLUS_INFO(logger,"+ Initializing Render System         (Release Build) +");
#endif
		LOG4CPLUS_INFO(logger,"++++++++++++++++++++++++++++++++++++++++++++++++++++++");

		CHECKGLERROR_TERM();
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		GLenum err = glewInit();
		if(GLEW_OK != err){
			// Problem: glewInit failed, something is seriously wrong.
			LOG4CPLUS_FATAL(logger,"GLEW initialization error : " << glewGetErrorString(err));
			return false;
		} else {
			LOG4CPLUS_INFO(logger,"GLEW initialized...");
		}
#endif
		CHECKGLERROR_TERM();
		{
			GPUConfig::getSingleton().update();
		}
		CHECKGLERROR_TERM();
		//////////////////////////////////////////////////////////////////////////
		// CHECK IF OPENGL VERSION SUPPORTS OPENRENG
		{
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			if( (GPUConfig::getSingleton().getGLVersionMajor()!=2) ||
				 (GPUConfig::getSingleton().getGLVersionMinor()!=0)){
				LOG4CPLUS_FATAL(logger,"OpenREng requires OpenGL ES 2.0 for ES support");return false;
			}
		#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
			if(GPUConfig::getSingleton().getGLVersionMajor()<3){
				LOG4CPLUS_FATAL(logger,"OpenREng requires an OpenGL Context supporting v3.0 or above.");return false;
			}
		#endif
		}
		GPUConfig::getSingleton().log();
		{
			// init DevIL
#if IMLOAD_LIB == IMLOAD_DEVIL
			LOG4CPLUS_INFO(logger,"Initializing DevIL library...");
			ilInit();
			ilEnable(IL_ORIGIN_SET);
			ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
			LOG4CPLUS_INFO(logger,"Initializing FreeImage library...");
			// FreeImage_Initialise(); // call only when linking statically
#endif
		}
		CHECKGLERROR_TERM();
		{
			// update initial generic render properties
			LOG4CPLUS_INFO(logger,"Setting generic render property defaults...");
			RenderProp_DepthFunc::setDefault();
			RenderProp_DepthMask::setDefault();
			RenderProp_FrontFace::setDefault();
			RenderProp_ColorMask::setDefault();
			RenderProp_CullFace::setDefault();
			RenderProp_Blending::setDefault();
			RenderProp_StencilTest::setDefault();
			RenderProp_DepthTest::setDefault();
			RenderProp_PolyMode::setDefault();
			// TODO: extend this later
			glPolygonOffset(-0.7f, 0.01f);
			glDisable(GL_SCISSOR_TEST);
			glEnable(GL_MULTISAMPLE);
		}
		CHECKGLERROR_TERM();
		{
			LOG4CPLUS_INFO(logger,"Initializing OpenGL Hints...");
			// initialize OpenGL hints
			// hint modes can be: GK_FASTEST, GL_NICEST, GL_DONTCARE

			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				glHint(GL_GENERATE_MIPMAP_HINT, GL_FASTEST);
			#else
				glHint(GL_LINE_SMOOTH_HINT, GL_FASTEST);
				glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
				glHint(GL_TEXTURE_COMPRESSION_HINT, GL_NICEST);
				glHint(GL_FRAGMENT_SHADER_DERIVATIVE_HINT, GL_NICEST);
				// deprecated : 
				// - GL_GENERATE_MIPMAP_HINT
				// - GL_FOG_HINT
				// - GL_PERSPECTIVE_CORRECTION_HINT
				// - GL_POINT_SMOOTH_HINT
			#endif
		}
		CHECKGLERROR_TERM();
		{
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				;
			#else
				// enabled/disabled states
				glDisable(GL_LINE_SMOOTH);
			#endif
		}
		CHECKGLERROR_TERM();
		{
			// auto-named variables will be declared for each shader
			MaterialShader::addPreText(
				#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
					"precision highp float;"
				#endif
				"uniform mat4 re_ModelMatrix,re_ModelMatrixInverse,re_ModelMatrixTranspose,"
				"re_ModelMatrixInverseTranspose,re_ViewMatrix,re_ViewMatrixInverse,re_ViewMatrixTranspose,"
				"re_ViewMatrixInverseTranspose,re_ProjectionMatrix,re_ProjectionMatrixInverse,"
				"re_ProjectionMatrixTranspose,re_ProjectionMatrixInverseTranspose,re_ModelViewMatrix,"
				"re_ModelViewMatrixInverse,re_ModelViewMatrixTranspose,re_ModelViewMatrixInverseTranspose,"
				"re_ViewProjectionMatrix,re_ViewProjectionMatrixInverse,re_ViewProjectionMatrixTranspose,"
				"re_ViewProjectionMatrixInverseTranspose,re_ModelViewProjectionMatrix,"
				"re_ModelViewProjectionMatrixInverse,re_ModelViewProjectionMatrixTranspose,"
				"re_ModelViewProjectionMatrixInverseTranspose;"
				"uniform mat3 re_NormalMatrix;"
				"uniform int re_FPS,re_ViewportWidth,re_ViewportHeight,re_MultiViewNo;"
				"uniform vec3 re_ViewPosition,re_ViewDirection,re_ViewUp,re_ViewRight;"
				#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
					"precision mediump float;\n"
//					"#define GL_ES\n" // some emulators do not seem to define this macro, may I ask why???
				#endif
				#if RENG_PLATFORM == RENG_PLATFORM_OMAP
					"#define OMAP\n"
				#endif
				);
			// register lights
			LightRegFuncList::iterator it=LightRegistry::getSingleton().begin();
			LightRegFuncList::iterator it_end=LightRegistry::getSingleton().end();
			for( ; it!=it_end ; it++) (*it)();
		}
		CHECKGLERROR_TERM();
		{
			const char* defMatSource = "// vertex transformation only, using REng variables \n"
				"shader re_vs_trans {\n"
				"  type vertex\n"
				"	source {{\n"
				"	#ifdef GL_ES\n"
				"		precision mediump float;\n"
				"	#endif\n"
				"	attribute vec4 re_Position;\n"
				"	void main (void){ gl_Position = re_ModelViewProjectionMatrix * re_Position; }\n"
				"	}}\n"
				"}\n"
				"\n"
				"// vertex transformation + texture coordinate pass\n"
				"shader re_vs_trans_tex {\n"
				"  type vertex\n"
				"	source {{\n"
				"	#ifdef GL_ES\n"
				"		precision mediump float;\n"
				"	#endif\n"
				"	//per vertex input\n"
				"	attribute vec4 re_Position;\n"
				"	attribute vec4 re_TexCoord0;\n"
				"	//per vertex output\n"
				"	varying vec4 vTexCoord;\n"
				"	void main (void) {\n"
				"		gl_Position = re_ModelViewProjectionMatrix * re_Position;\n"
				"		vTexCoord = re_TexCoord0;\n"
				"	}\n"
				"	}}\n"
				"}\n"
				"\n"
				"// a specialized sky vertex shader\n"
				"shader re_vs_sky { \n"
				"  type vertex\n"
				"	source {{\n"
				"	attribute vec4 re_Position;\n"
				"	attribute vec3 re_TexCoord0;\n"
				"	varying  vec3  vTexCoord;\n"
				"	void main (void) {\n"
				"		gl_Position = re_ModelViewProjectionMatrix * re_Position;\n"
				"		vTexCoord   = re_TexCoord0.xyz;\n"
				"		vTexCoord.y = -vTexCoord.y;\n"
				"	}\n"
				"	}}\n"
				"}\n"
				"\n"
				"// a specialized sky fragment shader\n"
				"shader re_fs_sky { \n"
				"  type fragment\n"
				"	source {{\n"
				"	uniform samplerCube skyTexture;\n"
				"	varying vec3 vTexCoord;\n"
				"	void main(void) { gl_FragColor = textureCube(skyTexture, vTexCoord ); }\n"
				"	}}\n"
				"	uniform_defaults { skyTexture int 0 }\n"
				"}\n"
				"\n"
				"// outputs a constant color\n"
				"shader re_fs_scolor {\n"
				"  type fragment\n"
				"	source {{\n"
				"	#ifdef GL_ES\n"
				"		precision mediump float;\n"
				"	#endif\n"
				"	uniform vec4 color;\n"
				"	void main(void) { gl_FragColor = color; }\n"
				"	}}\n"
				"	uniform_defaults { color vec4 1.0 0.00 0.0 1.0 }\n"
				"}\n"
				"// samples a texture and outputs the result directly\n"
				"shader re_fs_tex {\n"
				"  type fragment\n"
				"	source {{\n"
				"	#ifdef GL_ES\n"
				"		precision mediump float;\n"
				"	#endif\n"
				"	uniform sampler2D texSource; \n"
				"	uniform vec2 scaleFactor;\n"
				"	varying vec4 vTexCoord;\n"
				"	void main(void) {\n"
				"		gl_FragColor = texture2D(texSource, vTexCoord.xy*scaleFactor );\n"
				"	}\n"
				"	}}\n"
				"	uniform_defaults { \n"
				"		texSource int 0\n"
				"		scaleFactor vec2 10.0 10.0\n"
				"	}\n"
				"}\n"
				"\n"
				"///////////////////////////////////////////////////////////\n"
				"//\n"
				"//            Pre-defined materials\n"
				"//\n"
				"///////////////////////////////////////////////////////////\n"
				"\n"
				"material re_Sky {\n"
				"	technique {\n"
				"		pass {\n"
				"			shader_ref re_vs_sky\n"
				"			shader_ref re_fs_sky\n"
				"			render_states {\n"
				"				depth_test off\n"
				"				cull_face NONE\n"
				"				depth_mask off\n"
				"			}\n"
				"			texture_binding {\n"
				"				unit 0 texture_ref skyTexture\n"
				"			}\n"
				"		}\n"
				"	}\n"
				"}\n"
				"\n"
				"// A wireframe rendering shader\n"
				"// update color uniform of attached fragment shader to set output color\n"
				"material re_Wireframe {\n"
				"	technique {\n"
				"		pass {\n"
				"			shader_ref re_vs_trans\n"
				"			shader_ref re_fs_scolor\n"
				"			uniform_states {\n"
				"				color vec4 1.0 0.0 0.0 1.0\n"
				"			}\n"
				"			render_states {\n"
//				"				blending on\n"
//				"				line_width 1.0\n"
//				"				blend_function SRC_ALPHA ONE_MINUS_SRC_ALPHA SRC_ALPHA ONE_MINUS_SRC_ALPHA\n"
				"           poly_mode FRONT_AND_BACK LINE\n"
				"			}\n"
				"		}\n"
				"	}\n"
				"}\n"
				"\n"
				"program SimpleStaticColor {\n"
				"	shader_ref re_vs_trans\n"
				"	shader_ref re_fs_scolor\n"
				"}\n"
				"\n"
				"// The object is transformed and output to screen using constant color\n"
				"material re_Debug {\n"
				"	technique {\n"
				"		pass {\n"
				"			program_ref   SimpleStaticColor\n"
				"			uniform_states { color vec4 0.4 0.95 0.3 1.0 }\n"
				"		}\n"
				"	}\n"
				"}\n"
				"\n"
				"\n"
				"material re_Red {\n"
				"	technique {\n"
				"		pass {\n"
				"			program_ref SimpleStaticColor\n"
				"			uniform_states { color vec4 1.0 0.0 0.0 1.0 }\n"
				"			render_states { cull_face NONE }\n"
				"		}\n"
				"	}\n"
				"}\n"
				"material re_Green {\n"
				"	technique {\n"
				"		pass {\n"
				"			program_ref SimpleStaticColor\n"
				"			uniform_states { color vec4 0.0 1.0 0.0 1.0 }\n"
				"			render_states { cull_face NONE }\n"
				"		}\n"
				"	}\n"
				"}\n"
				"material re_Blue {\n"
				"	technique {\n"
				"		pass {\n"
				"			program_ref SimpleStaticColor\n"
				"			uniform_states { color vec4 0.0 0.0 1.0 1.0 }\n"
				"			render_states { cull_face NONE }\n"
				"		}\n"
				"	}\n"
				"}\n";
			if(loadDefaultMaterial){
				LOG4CPLUS_INFO(logger,"Loading default assets...");
				// load default default resources
				REng::MaterialScriptParser::getSingleton().parseFromMem(defMatSource,sizeof(defMatSource));

				// create and initialize material resources
				REng::MaterialManager::getSingleton().compileMaterialShaders();
				CHECKGLERROR_TERM();
				REng::MaterialManager::getSingleton().loadMaterials();
				CHECKGLERROR_TERM();
			}
		}
		CHECKGLERROR_TERM();
		mSkyMesh.reset(); // null pointer = no sky mesh
		mSkyMesh = MeshManager::getSingleton().getSkyMesh();

		CHECKGLERROR_TERM();
		LOG4CPLUS_INFO(logger,"RenderSystem initialization is completed.");

		mFPSTimer.reset(); // start timer 

		mIsInited = true;
		return true;
	}

	bool RenderSystem::isInited() const{
		return mIsInited;
	}

	bool RenderSystem::updateUniformIfSpecical(RenderProp_Uniform& uniform) const {
		// if is a render matrix uniform, fill it using render matrix manager
		if(RenderMatrixManager::getSingletonPtr()->updateUniform(uniform)==true) return true;
		// handle other named uniforms...
		switch(uniform.getAutoName()){
			case UAN_FPS:
				uniform.setDataAtIndex(0,(GLint)StatsCounter::getSingleton().getFrameRate()); break;
			case UAN_ViewportWidth:
				uniform.setDataAtIndex(0,(GLint)mViewportWidth); break;
			case UAN_ViewportHeight:
				uniform.setDataAtIndex(0,(GLint)mViewportHeight); break;
			case UAN_ViewportDimensions:
				uniform.setDataAtIndex(0,(GLint)mViewportWidth);
				uniform.setDataAtIndex(1,(GLint)mViewportHeight); break;
			case UAN_InvViewportWidth:
				uniform.setDataAtIndex(0,1.0f/mViewportWidth); break;
			case UAN_InvViewportHeight:
				uniform.setDataAtIndex(1,1.0f/mViewportHeight); break;
			case UAN_InvViewportDimensions:
				uniform.setDataAtIndex(0,1.0f/mViewportWidth);
				uniform.setDataAtIndex(1,1.0f/mViewportHeight); break;
			case UAN_MultiViewNo:
				if(mActiveViewport->isMVActive()){
					uniform.setDataAtIndex(0,(GLint)0);
				} else {
					uniform.setDataAtIndex(0,(GLint)mActiveViewport->getActiveViewNo());
				}
				break;
			case UAN_RenderPassIndex:
				uniform.setDataAtIndex(0,(GLint)mActivePass); break;
			case UAN_ViewPosition:
				if(mActiveCamera){
					const Vector3& pos(mActiveCamera->getNode().getTranslation_World());
					uniform.setData(pos.data(),sizeof(GLfloat)*3);
				}
				break;
			case UAN_ViewDirection:
				if(mActiveCamera){
					const Vector3& dir(mActiveCamera->getNode().getDirection());
					uniform.setData(dir.data(),sizeof(GLfloat)*3);
				}
				break;
			case UAN_ViewRight:
				if(mActiveCamera){
					const Vector3& right(mActiveCamera->getNode().getRight());
					uniform.setData(right.data(),sizeof(GLfloat)*3);
				}
				break;
			case UAN_ViewUp:
				if(mActiveCamera){
					const Vector3& up(mActiveCamera->getNode().getUp());
					uniform.setData(up.data(),sizeof(GLfloat)*3);
				}
				break;
			default:
				return false;
		}
		return true;
	}
	
	bool RenderSystem::swapFrame(bool noSwap) {
		// checks opengl errors in debug mode, good to do at least once per frame when debugging!
		CHECKGLERROR_TERM();

		StatsCounter::getSingleton().incFrameRate();
		if(noSwap) return true;
		return mGLContext->swapBuffers();
	}

	void RenderSystem::queueMesh(MeshPtr mesh, const Matrix4& transformation, uchar groupID){
		assert(mesh.get()); // must be a valid pointer
		assert(mesh->mMaterial.get()); // must have a valid material
		assert(mActiveViewport);

		uchar distIndex = 0 ; // TODO

		uchar maxMeshViewIndex;
		{	// calculate the maximum view index used by the mesh
			uchar maxMeshGeomViewIndex = mesh->getMaxViewIndex();
			uchar maxMaterialViewIndex = mesh->mMaterial->getMaxViewIndex();
			if(maxMaterialViewIndex>maxMeshGeomViewIndex) 
				maxMeshViewIndex = maxMaterialViewIndex;
			else
				maxMeshViewIndex = maxMeshGeomViewIndex;
		}
		uchar viewMax = mActiveViewport->getViewCount();
		for(int viewIndex = 0 ; viewIndex<viewMax ; ++viewIndex){
			const MeshGeom* theMeshGeom = mesh->getSuitableData(viewIndex, distIndex);
			REng::Technique* theTechnique = mesh->mMaterial->getSuitableData(viewIndex, distIndex);
			assert(theMeshGeom);
			assert(theTechnique);
			
			uchar lim = theTechnique->getRenderPassCount();
			for(uchar passNo=0 ; passNo<lim ; passNo++){
				Renderable r(transformation,*theMeshGeom,theTechnique->getRenderPass(passNo));
				r.viewNo = viewIndex;
				RenderQueueMap::getSingleton().addRenderable(r,groupID);
			}
		}
	}

	void RenderSystem::processRenderQueues(){
		RenderMatrixManager &RMM(RenderMatrixManager::getSingleton());

		uchar activeViewIndex = mActiveViewport->getActiveViewNo();

		RenderQueueMap::iterator i   =RenderQueueMap::getSingleton().begin();
		RenderQueueMap::iterator iend=RenderQueueMap::getSingleton().end();
		for( ; i!=iend ; i++){
			if(i->second == 0) continue; // no render queue defined

			RenderQueue& theQueue = *(i->second);
			if(theQueue.mEnabled==false) continue; // skip disabled render queues

			if(mActiveViewport){
				if(!mActiveViewport->isRenderQueueEnabled(theQueue.getQueueID())) continue;
			}

			theQueue.preRenderQueueProcess();
			CHECKGLERROR_TERM();

			BOOST_FOREACH(Renderable& r, theQueue) {
				if(r.viewNo!=activeViewIndex) continue;
				// 15th render queue is the bounding box queue, we need a "true" parameter
				// TODO fix
				RMM.setModel(r.getModelTransform(),(i->first == REnderQueueID_BoundingVol));
				RenderPass* pass = r.getRenderPass();
				if(pass!=0) {
					mActivePass = pass->getIndex();
					pass->prepareState();
				}
				GPUDrawer::getSingleton().drawMeshGeom(r.getMeshGeom());
				if(pass!=0) {
					pass->clearState();
				}
			}

			theQueue.postRenderQueueProcess();
			CHECKGLERROR_TERM();
		}
	}

	void RenderSystem::setActiveCamera(Camera& camera){
		mActiveCamera = &camera;
	}
	bool RenderSystem::renderAll(){
		BOOST_FOREACH(ViewportMapping::value_type val, mWindowViewports){
			setActiveViewport(*val.second);
			mActiveViewport->renderToTarget();
		}
		// swap the current rendering to the screen
		swapFrame(false);
		LightingManager::getSingleton().clearSceneLightsDirt();
		checkElapsedTime();
		return true;
	}

	void RenderSystem::checkElapsedTime(){
		// if one second has passed from the timer
		if(mFPSTimer.getElapsedTime(true,1.0f)){
			StatsCounter::getSingleton().clearStats();
		}
	}

	void RenderSystem::queueSG(){
		if(!mActiveCamera) return;

		NodeVisitor_Visibility visitor;
		NodeVisitor_Visibility_BoundVol visitorBV;

		// updates cam bounding volume if spatial info is updated
		mActiveCamera->getNode().getBoundingVolume_WS();

		// set camera bounding volumes and initialize SceneGraph visiting
		visitor.mCullVolume   = &mActiveCamera->getFrustum_WS();
		visitorBV.mCullVolume = &mActiveCamera->getFrustum_WS();
		visitor  .visit(RootNode::getSingleton());
		visitorBV.visit(RootNode::getSingleton());
	}

	RenderQueue_BVs& RenderSystem::getRenderQueue_BVs(){
		return *mRenderQueue_BVs;
	}

	void RenderSystem::setSkyMeshGeom(MeshGeom& theGeom){
		mSkyMesh->destroyLodedData(0,0);
		MeshGeom* g=mSkyMesh->createLoDedData(0,0);
		g->mIndexDataPtr = theGeom.mIndexDataPtr;
		g->mVertexDataPtr = theGeom.mVertexDataPtr;
	}

	void RenderSystem::queueBackground(bool renderSky){
		Matrix4 transform;
		if(renderSky ){
			if(mSkyMesh->getSuitableData() != 0){
				queueSkyMesh();
				return;
			}
		}
	}
	void RenderSystem::queueSkyMesh(){
		static Matrix4 transform; // NOTE: render queue processing holds pointers to transform matrices
		if(mSkyMesh.get() != 0){
			// model should scale to your view frustum
			transform.identity();
			float scaleCoef = mActiveCamera->getFarDistance() * 0.50;
			cml::matrix_scale(transform, scaleCoef, scaleCoef, scaleCoef);
			queueMesh(mSkyMesh,transform,1);
		} 
	}

	void RenderSystem::setDepthRange(float nearVal, float farVal){
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES 
		glDepthRangef(nearVal,farVal);
#else
		glDepthRange(nearVal,farVal);
#endif
	}
	void RenderSystem::setScissorTest(bool isEnabled, 
		size_t left, size_t bottom, size_t width, size_t height)
	{
		if(isEnabled){
			glEnable(GL_SCISSOR_TEST);
			glScissor(left,bottom,width,height);
		} else {
			glDisable(GL_SCISSOR_TEST);
		}
	}

	const Camera* RenderSystem::getActiveCamera() const{
		return mActiveCamera;
	}
	
	/************************************************************************/
	/* Viewport Management                                                  */
	/************************************************************************/

	bool RenderSystem::addViewport(uchar depth, Viewport* vp){
		if(getViewport(depth)!=0) return false;
		mWindowViewports.insert(ViewportMapping::value_type(depth,vp));
		return true;
	}
	Viewport* RenderSystem::getViewport(uchar depth){
		ViewportMapping::iterator r_iter = mWindowViewports.find(depth);
		if(r_iter == mWindowViewports.end()){
			return 0;
		} else {
			return r_iter->second;
		}
	}
	void RenderSystem::setActiveViewport(Viewport& vp){
		mActiveViewport = &vp;
	}
	Viewport* RenderSystem::getActiveViewport(Viewport* vp){
		return mActiveViewport;
	}
	bool RenderSystem::setViewportTrans(const RectI& r){
		int x = r.getLeft();
		int y = r.getBottom();
		size_t width = r.getWidth();
		size_t height = r.getHeight();
		if(width > (size_t)GPUConfig::getSingleton().getGLMaxViewportDims()[0]) return false;
		if(height > (size_t)GPUConfig::getSingleton().getGLMaxViewportDims()[1]) return false;
		glViewport(x,y,(GLsizei)width,(GLsizei)height);
		mViewportWidth = width;
		mViewportHeight = height;
		return true;
	}

}
