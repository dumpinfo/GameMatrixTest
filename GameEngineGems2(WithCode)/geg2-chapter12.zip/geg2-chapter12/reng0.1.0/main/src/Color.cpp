/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Color.h"

#include <assert.h>

namespace REng{

	const Color_Real Color_Real::ZERO  = Color_Real(MIN_VAL, MIN_VAL, MIN_VAL, MIN_VAL );
	const Color_Real Color_Real::Black = Color_Real(MIN_VAL, MIN_VAL, MIN_VAL, MAX_VAL );
	const Color_Real Color_Real::White = Color_Real(MAX_VAL, MAX_VAL, MAX_VAL, MAX_VAL );
	const Color_Real Color_Real::Red   = Color_Real(MAX_VAL, MIN_VAL, MIN_VAL, MAX_VAL );
	const Color_Real Color_Real::Green = Color_Real(MIN_VAL, MAX_VAL, MIN_VAL, MAX_VAL );
	const Color_Real Color_Real::Blue  = Color_Real(MIN_VAL, MIN_VAL, MAX_VAL, MAX_VAL );

	const Color_Real::ChType Color_Real::MAX_VAL = Color_Real::ChType(1.0);
	const Color_Real::ChType Color_Real::MIN_VAL = Color_Real::ChType(0.0);

	const Color_Int Color_Int::ZERO  = Color_Int(MIN_VAL, MIN_VAL, MIN_VAL, MIN_VAL );
	const Color_Int Color_Int::Black = Color_Int(MIN_VAL, MIN_VAL, MIN_VAL, MAX_VAL );
	const Color_Int Color_Int::White = Color_Int(MAX_VAL, MAX_VAL, MAX_VAL, MAX_VAL );
	const Color_Int Color_Int::Red   = Color_Int(MAX_VAL, MIN_VAL, MIN_VAL, MAX_VAL );
	const Color_Int Color_Int::Green = Color_Int(MIN_VAL, MAX_VAL, MIN_VAL, MAX_VAL );
	const Color_Int Color_Int::Blue  = Color_Int(MIN_VAL, MIN_VAL, MAX_VAL, MAX_VAL );

	const Color_Int::ChType Color_Int::MAX_VAL = Color_Int::ChType(0)-1;
	const Color_Int::ChType Color_Int::MIN_VAL = 0;
	
	const uint Color_Packed::VAL_0 = 0xFF000000;
	const uint Color_Packed::VAL_1 = 0x00FF0000;
	const uint Color_Packed::VAL_2 = 0x0000FF00;
	const uint Color_Packed::VAL_3 = 0x000000FF;

	//////////////////////////////////////////////////////////////////////////
	// Converters
	//////////////////////////////////////////////////////////////////////////
	Color_Int Color_Real::get_Int() const{
		Color_Real tmp(*this);
		// all components between 0.0 and 1.0
		tmp.compress();
		return Color_Int(
			tmp.r*Color_Int::MAX_VAL, 
			tmp.g*Color_Int::MAX_VAL, 
			tmp.b*Color_Int::MAX_VAL, 
			tmp.a*Color_Int::MAX_VAL);
	}
	void Color_Real::setFrom_Int(const Color_Int& cp){
		// map 0-255 int. value to 0-1 float values
		ChType mult(1.0/Color_Int::MAX_VAL);
		r = cp.r*mult;
		g = cp.g*mult;
		b = cp.b*mult;
		a = cp.a*mult;
	}

	Color_Real Color_Int::get_Real() const{
		Color_Real toRet;
		Color_Real::ChType mult(1.0f/Color_Int::MAX_VAL);
		// map 0-255 int. value to 0-1 float values
		toRet.r = r*mult;
		toRet.g = g*mult;
		toRet.b = b*mult;
		toRet.a = a*mult;
		return toRet;
	}
	void Color_Int::setFrom_Real(const Color_Real& cp){
		Color_Real tmp(cp);
		tmp.compress();
		r = tmp.r*Color_Int::MAX_VAL;
		g = tmp.g*Color_Int::MAX_VAL;
		b = tmp.b*Color_Int::MAX_VAL;
		a = tmp.a*Color_Int::MAX_VAL;
	}

	Color_Int Color_Packed::get_Int() const{
		Color_Int toRet;
		uchar scaleFac = sizeof(Color_Int::ChType) / 1;
		uchar comp[4]; get(comp);
		toRet.r = comp[0]*scaleFac;
		toRet.g = comp[1]*scaleFac;
		toRet.b = comp[2]*scaleFac;
		toRet.a = comp[3]*scaleFac;
		return toRet;
	}
	void Color_Packed::setFrom_Int(const Color_Int& cp){
		mType = Color_Pack_RGBA;
		uchar scaleFac = sizeof(Color_Int::ChType) / 1;
		uchar _r = cp.r/scaleFac;
		uchar _g = cp.g/scaleFac;
		uchar _b = cp.b/scaleFac;
		uchar _a = cp.a/scaleFac;
		mColor = (_r<<24) + (_g<<16) + (_b<<8) + (_a);
	}

	Color_Real::ChType Color_Real::getHue() const{
		ChType _max, _min;
		getMinMax(_min,_max);

		ChType mult(1.0/(_max-_min));

		ChType toRet(0.0);
		if(_min == _max) return 0;
		else if(_max == r) {
			toRet = (g-b)*mult / 6.0;
		}
		else if(_max == g) {
			toRet = (b-r)*mult / 6.0 + 1/3.0;
		}
		else if(_max == b) {
			toRet = (r-g)*mult / 6.0 + 2/3.0;
		}
		// TODO: implement a complete modulus operation
		if(toRet<0) toRet += 1.0;
		if(toRet>1) toRet -= 1.0;
		return toRet;
	}

	Color_Real::ChType Color_Real::getSaturation() const{
		ChType _max, _min;
		getMinMax(_min,_max);
		if(_max==0) return 0;
		return (_max-_min)/_max;
	}

	Color_Real::ChType Color_Real::getBrightness() const{
		ChType _max, _min;
		getMinMax(_min,_max);
		return _max;
	}

	void Color_Real::getHSB(ChType& _h, ChType& _s, ChType & _b) const{
		ChType _max, _min;
		getMinMax(_min,_max);

		ChType mult(1.0/(_max-_min));

		if(_min == _max) _h = 0;
		else if(_max == r) {
			_h = (g-b)*mult / 6.0;
		}
		else if(_max == g) {
			_h = (b-r)*mult / 6.0 + 1/3.0;
		}
		else if(_max == b) {
			_h = (r-g)*mult / 6.0 + 2/3.0;
		}
		// TODO: implement a complete modulus operation
		if(_h<0) _h += 1.0;
		if(_h>1) _h -= 1.0;

		if(_max==0) _s = 0;
		else _s = (_max-_min)/_max;

		_b = _max;
	}

	void Color_Real::setFrom_HSB(ChType _h, ChType _s, ChType _b){
		// based on:
		// http://en.wikipedia.org/wiki/HSL_and_HSV#Conversion_from_HSV_to_RGB
		if(_b == 0.0) { // Black
			r = g = b = ChType(0.0);
			return;
		}	
		if(_s == 0.0f) { // A shade of gray
			r = g = b = _b;
			return;
		}
		ChType __h(_h*6.0); // __h is between 0 and 6
		uchar mode(__h);
		ChType f(__h - mode);
		ChType f1( _b * (1 - _s         ) );
		ChType f2( _b * (1 - _s * f     ) );
		ChType f3( _b * (1 - _s * (1-f) ) );

		switch(mode){
			case 0:
				r = _b;
				g = f3;
				b = f1;
				break;
			case 1:
				r = f2;
				g = _b;
				b = f1;
				break;
			case 2:
				r = f1;
				g = _b;
				b = f3;
				break;
			case 3:
				r = f1;
				g = f2;
				b = _b;
				break;
			case 4:
				r = f3;
				g = f1;
				b = _b;
				break;
			case 5:
				r = _b;
				g = f1;
				b = f2;
				break;
			default:
				// no way
				break;
		}
	}
	void Color_Packed::setType(Color_Pack_Type _type){ 
		if(mType == _type) return;
		// 1 . convert current to RGBA
		switch(mType){
			case Color_Pack_RGBA:
				break;
			case Color_Pack_ARGB: // to RGBA
				mColor = ((mColor<<8)&0xFFFFFF00) + ((mColor>>24)&0x000000FF);
				break;
			case Color_Pack_BGRA: // to RGBA
				mColor = ((mColor)&0x00FF00FF) + ((mColor<<16)&VAL_0) + ((mColor>>16)&VAL_2);
				break;
			case Color_Pack_ABGR: // to RGBA
				mColor = ((mColor<<24)&VAL_0) + ((mColor<<8)&VAL_1) + ((mColor>>8)&VAL_2) + ((mColor>>24)&VAL_3);
				break;
		}
		// 2. convert RGBA to current
		switch(_type){
			case Color_Pack_RGBA:
				break;
			case Color_Pack_ARGB:
				mColor = ((mColor>>8)&0x00FFFFFF) + ((mColor<<24)&0xFF000000);
				break;
			case Color_Pack_BGRA:
				mColor = ((mColor)&0x00FF00FF) + ((mColor>>16)&VAL_2) + ((mColor<<16)&VAL_0);
				break;
			case Color_Pack_ABGR:
				mColor = ((mColor<<24)&VAL_0) + ((mColor<<8)&VAL_1) + ((mColor>>8)&VAL_2) + ((mColor>>24)&VAL_3);
				break;
		}
		mType = _type;
	}

	void Color_Packed::get(uchar& _red, uchar& _green, uchar& _blue, uchar& _alpha) const{
		switch(mType){
			case Color_Pack_RGBA:
				_red   = ((mColor & VAL_0) >> 24);
				_green = ((mColor & VAL_1) >> 16);
				_blue  = ((mColor & VAL_2) >> 8 );
				_alpha = ((mColor & VAL_3)      );
				return;
			case Color_Pack_ARGB:
				_alpha = ((mColor & VAL_0) >> 24);
				_red   = ((mColor & VAL_1) >> 16);
				_green = ((mColor & VAL_2) >> 8 );
				_blue  = ((mColor & VAL_3)      );
				return;
			case Color_Pack_BGRA:
				_blue  = ((mColor & VAL_0) >> 24);
				_green = ((mColor & VAL_1) >> 16);
				_red   = ((mColor & VAL_2) >> 8 );
				_alpha = ((mColor & VAL_3)      );
				return;
			case Color_Pack_ABGR:
				_alpha = ((mColor & VAL_0) >> 24);
				_blue  = ((mColor & VAL_1) >> 16);
				_green = ((mColor & VAL_2) >> 8 );
				_red   = ((mColor & VAL_3)      );
				return;
		}
	}

	std::string Color_Packed::toString() const{
		char toRet[50]; // large enough
		uchar comp[4]; get(comp);
		sprintf(toRet,"R:%3d G:%3d B:%3d A:%3d",comp[0], comp[1], comp[2], comp[3]);
		std::string s(toRet);
		return s;
	}
	std::ostream& operator<<( std::ostream& o, const Color_Packed& c ) {
		o << c.toString();
		return o;
	}
}

