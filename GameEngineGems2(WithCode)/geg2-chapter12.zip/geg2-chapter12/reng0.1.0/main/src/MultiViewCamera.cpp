/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/MultiViewCamera.h"

namespace REng{

	/************************************************************************/
	/* MULTIVIEW CAMERA BASICS                                              */
	/************************************************************************/

	// TODO: inline
	CameraMultiView::CameraMultiView(CameraNode& node) 
		:CameraPerspective(node)
		,mActiveView(0)
	{ ; }
	void CameraMultiView::setActiveView(uchar viewIndex){
		if(viewIndex >= getViewCount()) viewIndex = 0;
		mActiveView = viewIndex;
		mProjectionMatrix_Dirty = true;
	}

	/************************************************************************/
	/* STEREO VIEW CAMERA                                                   */
	/************************************************************************/

	CameraStereoView::CameraStereoView(CameraNode& node) 
		: CameraMultiView(node)
		,mFocalDistance(1.)
		,mEyeSeparation(0.1)
		,mType(TypeSkewed)
		{ ; }
	CameraStereoView& CameraStereoView::create(CameraNode& node){
		return *(new CameraStereoView(node));
	}
	uchar CameraStereoView::getViewCount() const{
		return 2;
	}
	void CameraStereoView::setEyeSeparation(float distance){
		if(distance<0) return;
		mEyeSeparation = distance;
	}
	void CameraStereoView::setFocalDistance(float distance){
		if(distance<0) return;
		mFocalDistance = distance;
	}
	float CameraStereoView::getFocalDistance() const{
		return mFocalDistance;
	}
	float CameraStereoView::getEyeSeparation() const{
		return mEyeSeparation;
	}
	void CameraStereoView::setStereoType(StereoType _type){
		mType = _type;
		mProjectionMatrix_Dirty = true;
	}
	CameraStereoView::StereoType CameraStereoView::getStereoType() const{
		return mType;
	}
	Vector3 CameraStereoView::getLeftViewPosOffset() const{
		// move the camera to the left side
		return getNode().getRight() * -mEyeSeparation/2;
	}
	Vector3 CameraStereoView::getRightViewPosOffset() const{
		// move the camera to the right side
		return getNode().getRight() * +mEyeSeparation/2;
	}
	Vector3 CameraStereoView::getLeftViewPos() const{
		return getNode().getTranslation_World()+getLeftViewPosOffset();
	}
	Vector3 CameraStereoView::getRightViewPos() const{
		return getNode().getTranslation_World()+getRightViewPosOffset();
	}
	const Matrix4& CameraStereoView::getViewMatrix() const {
		Vector3 transW;
		if(mActiveView == LeftView){
			transW = getLeftViewPos();
		} else { // mActiveView == RightView
			transW = getRightViewPos();
		}
		Quaternion rotateW(getNode().getRotation_World());
		if(mType==TypeOriented){
			double tanAngle = mEyeSeparation/(2*mFocalDistance+mEyeSeparation*std::tan(getFieldOfView_y().getRadian()));
			double angle = std::atan(tanAngle);
			// works at the first try :)
			if(mActiveView == LeftView){
				cml::quaternion_rotate_about_world_y(rotateW,-float(angle));
			} else { // mActiveView == RightView
				cml::quaternion_rotate_about_world_y(rotateW,+float(angle));
			}
		}
		CameraNode::calculateViewMatrix(rotateW,transW,mActiveViewMatrix);
		return mActiveViewMatrix;
	}
	void CameraStereoView::updateProjectionMatrix() const {
		if(mType==TypeParallel||mType==TypeOriented){
			cml::matrix_perspective_yfov_RH( mProjectionMatrix_Cache,
				mFoV_y.getRadian(), mAspectRatio, mNearDistance, mFarDistance,
				cml::z_clip_neg_one);
			mProjectionMatrix_Dirty = false;
			return;
		}

		if(false){
			// from: Rendering anaglyph stereographics in real-time
			// calculate a skew matrix for projection
			// (see 3D in 3D: Rendering Anaglyph Stereoscopic)
			float skewFactor;
			switch(mActiveView){
				case LeftView:
					skewFactor = +mEyeSeparation/2.0f;
					break;
				case RightView:
					skewFactor = -mEyeSeparation/2.0f;
					break;
				default:
					return; // is not specified
			}
			Matrix4 skewMatrix(cml::identity<4>());
			// (row,column)
			skewMatrix(0,2) = -skewFactor / mFocalDistance;
			skewMatrix(0,3) = skewFactor;

			// 1 set ProjectionMatrixCache to regular perspective projection matrix
			cml::matrix_perspective_yfov_RH( mProjectionMatrix_Cache,
				mFoV_y.getRadian(),
				mAspectRatio,
				getNearDistance(), getFarDistance(),
				cml::z_clip_neg_one);
			// 2 then skew it
			mProjectionMatrix_Cache = skewMatrix * mProjectionMatrix_Cache;
		}
		else 
		{
			// glfrustum based method References:
			// - http://www.orthostereo.com/geometryopengl.html
			// - Ogre Frustum class

			// 1. generate symmetric frustum
			float ftop    = getNearDistance()*tan(getFieldOfView_y().getRadian()/2.);
			float fbottom = -ftop;
			float fleft   = -ftop * getAspectRatio();
			float fright  = -fleft;

			// 2. generate frustum shift
			float frustumShift = (mEyeSeparation/2.0)*(getNearDistance()/mFocalDistance);

			// 3. apply frustum shift
			switch(mActiveView){
				case LeftView:
					// move the frustum to the right...
					cml::matrix_perspective_RH(
						mProjectionMatrix_Cache,
						fleft+frustumShift, fright+frustumShift,
						fbottom,ftop,
						getNearDistance(),getFarDistance(),cml::z_clip_neg_one);
					break;
				case RightView:
					// move the frustum to the left...
					cml::matrix_perspective_RH(
						mProjectionMatrix_Cache,
						fleft-frustumShift, fright-frustumShift,
						fbottom,ftop,
						getNearDistance(),getFarDistance(),cml::z_clip_neg_one);
					break;
				default:
					return; // is not specified
			}
		}
		if(mSwapXY) swapXY(mProjectionMatrix_Cache);
		mProjectionMatrix_Dirty = false;
	}
	void CameraStereoView::generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay){
		// assume the camera is symmetric perspective on the convergePos of the node.
		CameraPerspective::generateRay_WS(widthRatio, heightRatio, pickRay);
	}

	void CameraStereoView::updateFrustum() const{
		float nWHalf, nHHalf, fWHalf, fHHalf;

		nHHalf = getNearDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		nWHalf = nHHalf * getAspectRatio();
		fHHalf = getFarDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		fWHalf = fHHalf * getAspectRatio();

		const Vector3& position(getPosition());
		const Vector3& dirVec(mNode.getDirection());
		const Vector3& rightVec(mNode.getRight());
		const Vector3& upVec(mNode.getUp());

		Vector3 dirNear(dirVec*getNearDistance());
		Vector3 dirFar(dirVec*getFarDistance());

		Vector3 nc(position + dirNear);   // center point on the near plane
		Vector3 fc(position + dirFar);    // center point on the far plane
		Vector3 rNear(rightVec * nWHalf); // the right-vector to the corner on near plane 
		Vector3 uNear(upVec    * nHHalf); // the up-vector    to the corner on near plane 
		Vector3 rFar(rightVec  * fWHalf); // the right-vector to the corner on near plane 
		Vector3 uFar(upVec     * fHHalf); // the up-vector    to the corner on near plane 

		//////////////////////////////////////////////////////////////////////////
		// TOP-BOTTOM BOUNDING PLANES

		// Stereo camera setups do not modify the top-bottom bounding planes, the view points are
		// parallel to the left-right axis

		Vector3 a;
		a = dirVec*getFarDistance() + uFar;
		GeomPlane upPlane(getPosition(),cml::cross(a.normalize(),rightVec));
		a = dirVec*getFarDistance() - uFar;
		GeomPlane downPlane(getPosition(),cml::cross(rightVec,a.normalize()));

		//////////////////////////////////////////////////////////////////////////
		// NEAR-FAR BOUNDING PLANES

		// Assume that near and far planes do not change either 
		// Note: they only change in oriented case, but difference will be minor

		// near plane can be defined with dirVec as a normal and nc as a point on the plane.
		GeomPlane nearPlane(nc,dirVec);
		// far plane can be defined with -dirVec as a normal and fc as a point on the plane.
		GeomPlane farPlane(fc,-dirVec);

		//////////////////////////////////////////////////////////////////////////
		// LEFT-RIGHT BOUNDING PLANES

		GeomPlane rightPlane;
		GeomPlane leftPlane;

		if(mType==TypeParallel){
			// similar to regular case (normals do not change, but points on the left-right plane are
			Vector3 a;
			a = dirFar + rFar;
			rightPlane.setGeom(getRightViewPos(),cml::cross(upVec,a.normalize()));
			a = dirFar - rFar;
			leftPlane.setGeom(getLeftViewPos(),cml::cross(a.normalize(),upVec));
		}
		if(mType==TypeSkewed || mType==TypeOriented){ // TODO: Fix, check the method below
			// calculate the convergence point of the symmetric frustum
			float focalPlaneWidth = 2*std::tan(getFieldOfView_y().getRadian()/2.0f)*getAspectRatio()*mFocalDistance;
			// assume that the viewpoint is to the back of the camera
			float backPointDistance = mEyeSeparation*mFocalDistance/(focalPlaneWidth-mEyeSeparation);
			Vector3 convergePos(getPosition()-dirVec*backPointDistance);

			Vector3 dirNear(dirVec * (getNearDistance()+backPointDistance) );
			Vector3 dirFar (dirVec * (getFarDistance() +backPointDistance) );

			Vector3 a;
			a = getRightViewPos()-convergePos;
			rightPlane.setGeom(convergePos,cml::cross(upVec,a.normalize()));
			a = getLeftViewPos()-convergePos;
			leftPlane.setGeom(convergePos,cml::cross(a.normalize(),upVec));
		}

		mFrustum_Cache.clearPlaneList();
		mFrustum_Cache.addPlane(rightPlane);
		mFrustum_Cache.addPlane(leftPlane);
		mFrustum_Cache.addPlane(upPlane);
		mFrustum_Cache.addPlane(downPlane);
		mFrustum_Cache.addPlane(nearPlane);
		mFrustum_Cache.addPlane(farPlane);

		mFrustum_Dirty = false;
	}

}

