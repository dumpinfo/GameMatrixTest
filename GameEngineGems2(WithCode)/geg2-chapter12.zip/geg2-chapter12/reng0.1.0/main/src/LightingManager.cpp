/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/LightingManager.h"

#include <boost/foreach.hpp>

using namespace std;

namespace REng{

	/************************************************************************/
	/* LIGHTING                                                             */
	/************************************************************************/

	// singleton stuff
	template<> LightingManager* Singleton<LightingManager>::ms_Singleton = 0;
	LightingManager* LightingManager::getSingletonPtr(void) {
		return ms_Singleton;
	}
	LightingManager& LightingManager::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	LightingManager::LightingManager() { 
		mLights_PerMesh.resize(LightRegistry::getSingleton().getLightTypeCount());
		mLights_Scene.resize(LightRegistry::getSingleton().getLightTypeCount());
	}
	LightingManager::~LightingManager() { ; }

	void LightingManager::registerLightToScene(Light_Base& light){
		// Note: The number of lights per type can exceed tge maximum number of supported
		// lights per type, because some of the lights may not be linked to a render pass
		// on light synch time (not lit or is culled).
		mLights_Scene[light.getTypeID()].push_back(&light);
	}

	void LightingManager::illuminateNode(Light_Base& light, SceneNode& node, uint maxDepth){
		mMode = Visit_Illum;
		visit(node);
	}
	void LightingManager::illuminateNodeNot(Light_Base& light, SceneNode& node, uint maxDepth){
		mMode = Visit_IllumNot;
		visit(node);
	}

	void LightingManager::visit(GroupNode& node){
		SceneNodeList::iterator it = node.getChildren().begin(), it_end = node.getChildren().end();
		for( ; it!=it_end ; it++) (*it)->accept(*this);
	}
	void LightingManager::visit(RootNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void LightingManager::visit(SwitchGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void LightingManager::visit(LODGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void LightingManager::visit(MeshNode& node){
		// TODO
		switch(mMode){
			case Visit_Illum:
				// mark mesh node as illuminated by this lighting
				break;
			case Visit_IllumNot:
				// mark mesh node as NOT illuminated by this lighting
				break;
			case Visit_Cull:
				// Note: If bounding volume is not defined for lighting, is never called, so no check here
				break;
		}
	}
	void LightingManager::visit(SceneNode& node) { ; }
	void LightingManager::visit(CameraNode& node){ ; }
	void LightingManager::visit(LightNode& node) { ; }

	const uchar LightingManager::MaxNumOfLights_PerType = 16;

	void LightingManager::_updateMeshLightPairs(){
		std::vector<Light_Base*>::iterator it = mLights_PerMesh[0].begin(), it_end = mLights_PerMesh[0].end();
		for( ; it!=it_end ; it++) {
			// for each of the meshes illuminated by this light
				// if bounding volumes exist, check intersection
		}
	}

	bool LightingManager::uploadLightingParameters(RenderPass& pass){
		static uint lightTypeCount = LightRegistry::getSingleton().getLightTypeCount();
		// 1. Prepare / init supporting data
		static uchar *lightCountOfType = (uchar*) malloc(lightTypeCount);
		memset(lightCountOfType,0,lightTypeCount);
		
		bool toRet = false;

		// 1. Upload default lights in the scene
		//    TODO -> Refresh only the lights that need to synch themselves
		for(uint lightType=0 ; lightType<lightTypeCount ; lightType++ ){
			std::vector<Light_Base*>& lightList(mLights_Scene[lightType]);
			BOOST_FOREACH(Light_Base *light, lightList){
				if(!light->isLit()) continue;
				if(lightCountOfType[lightType] >= MaxNumOfLights_PerType) break;
				light->mSynchLightIndex = lightCountOfType[lightType]++;
				toRet = toRet || light->synchWithPass(pass);
			}
		}

		// 2. Upload per-mesh light in the scene
		//    TODO -> Finish this off
		/*
		for(int lightType=0 ; lightType<lightTypeCount ; lightType++ ){
			vector<Light_Base*>::iterator it     = mLights_PerMesh[lightType].begin();
			vector<Light_Base*>::iterator it_end = mLights_PerMesh[lightType].end();
			for( ; it!=it_end ; it++) {
				Light_Base *light = (*it);
				if(lightCountOfType[lightType] >= MaxNumOfLights_PerType) break;
				if(!light->isLit()) continue;
				// TODO: Check if this mesh is illuminated by this light!
				if(true){
					light->mSynchLightIndex = lightCountOfType[lightType]++;
					toRet = toRet || light->synchWithPass(pass);
				}
			}
		}
		*/
		return toRet;
	}

	void LightingManager::clearSceneLightsDirt(){
		return;
		static uint lightTypeCount = LightRegistry::getSingleton().getLightTypeCount();
		for(uint lightType=0 ; lightType<lightTypeCount ; lightType++ ){
			vector<Light_Base*>::iterator it     = mLights_Scene[lightType].begin(),
			                          	  it_end = mLights_Scene[lightType].end();
			for( ; it!=it_end ; it++) {
				(*it)->setAllDirty(false);
			}
		}
	}

}
