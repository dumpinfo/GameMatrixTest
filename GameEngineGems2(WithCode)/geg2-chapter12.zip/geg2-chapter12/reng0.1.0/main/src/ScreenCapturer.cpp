/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/ScreenCapturer.h"

#include <assert.h>
#include <time.h>

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{
	
#if IMLOAD_LIB == IMLOAD_DEVIL
	uint convertImageType(ImageFileType _type){
		switch(_type){
			case IFT_BMP : return IL_BMP;
			case IFT_DDS : return IL_DDS;
			case IFT_GIF : return IL_GIF;
			case IFT_HDR : return IL_HDR;
			case IFT_JPG : return IL_JPG;
			case IFT_PNG : return IL_PNG;
			case IFT_RAW : return IL_RAW;
			case IFT_TGA : return IL_TGA;
			case IFT_TIFF: return IL_TIF;
			default: return 0;
		}
	}
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
	FREE_IMAGE_FORMAT convertImageType(ImageFileType _type){
		switch(_type){
			case IFT_BMP : return FIF_BMP;
			case IFT_DDS : return FIF_DDS;
			case IFT_GIF : return FIF_GIF;
			case IFT_HDR : return FIF_HDR;
			case IFT_JPG : return FIF_JPEG;
			case IFT_PNG : return FIF_PNG;
			case IFT_RAW : return FIF_UNKNOWN; // unsupported
			case IFT_TGA : return FIF_TARGA;
			case IFT_TIFF: return FIF_TIFF;
			default:       return FIF_UNKNOWN;
		}
	}
#endif

	/************************************************************************/
	/* Screen Capturer                                                      */
	/************************************************************************/

	ScreenCapturer::ScreenCapturer(){
#if IMLOAD_LIB == IMLOAD_DEVIL
		ilGenImages(1, &mScreenShotImage);
#endif
		mWidthCache = 0;
		mHeightCache = 0;
	}
	ScreenCapturer::~ScreenCapturer(){
#if IMLOAD_LIB == IMLOAD_DEVIL
		ilDeleteImages(1, &mScreenShotImage);
#endif
	}

	bool ScreenCapturer::saveCaptureToFile(ImageFileType ext, const std::string& name, 
		bool useTimestamp, bool useUniqueID) const 
	{
		std::string fileName(name);

		const char* extension=0;
		switch(ext){
			case IFT_BMP: extension = (const char*)"bmp"; break;
			case IFT_DDS: extension = (const char*)"dds"; break;
			case IFT_GIF: extension = (const char*)"gif"; break;
			case IFT_HDR: extension = (const char*)"hdr"; break;
			case IFT_JPG: extension = (const char*)"jpg"; break;
			case IFT_PNG: extension = (const char*)"png"; break;
			case IFT_RAW: extension = (const char*)"raw"; break;
			case IFT_TGA: extension = (const char*)"tga"; break;
			case IFT_TIFF: extension =(const char*) "tiff"; break;
			default: break;
		}
		assert(extension);

		// generate a non-existing file name, returns false if cannot generate such a name
		{
			FILE *outFile;
			char tfn[155];
			if(useTimestamp){
				time_t rawtime;
				struct tm * timeinfo;
				char timestr [80];

				time(&rawtime);
				timeinfo = localtime(&rawtime);

				strftime(timestr,80,"%Y%m%d_%H%M%S",timeinfo);
				puts(timestr);

				sprintf(tfn,"%s_%s.%s",fileName.c_str(),timestr,extension);
				outFile = fopen(tfn, "rb");
				if(outFile) {
					// file exists, cannot write over that file.
					fclose(outFile);
					return false; 
				}
			} else {
				if(useUniqueID){
					// find a file name with an available id
					for(int fileID=1 ; true ; fileID++){
						sprintf(tfn,"%s_%d.%s",fileName.c_str(),fileID,extension);
						outFile = fopen(tfn, "rb");
						if(!outFile) {
							// file does not exist, you may proceed
							fileName = tfn;
							break; 
						}
						fclose(outFile);
					}
				} else {
					sprintf(tfn,"%s.%s",fileName.c_str(),extension);
					outFile = fopen(tfn, "rb");
					if(outFile) {
						// file exists, cannot write over that file.
						fclose(outFile);
						return false; 
					}
				}
			}
			fileName = tfn;
		}

#if IMLOAD_LIB == IMLOAD_DEVIL
		// ILuint rollback = ilGetCurName(); TODO Available in DevIL internal only
		ilBindImage(mScreenShotImage);
		bool toRet = ilSave(convertImageType(ext), fileName.c_str()) != 0;
		// ilBindImage(rollback);
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
		bool toRet = FreeImage_Save(convertImageType(ext),mScreenShotImage,fileName.c_str());
#endif

		return toRet;
	}

	bool ScreenCapturer::captureFrame(
		const GPUFrameBuffer& frameBufObj, 
		RectI region,
		PixelDataFormat format,
		FrameBufferColorBufferType source
	){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(source != FrameBufferColorBufferType_Color0){
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),"Only Color source 0 is supported in ES configurations.");
			return false;
		}
		#endif

		frameBufObj.bindResource();
		glPixelStorei(GL_PACK_ALIGNMENT,1);
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		glReadBuffer(source);
#else
		(void) source;
#endif

		if(region==RectI(0,0,0,0)){
			region.setLimits(0,frameBufObj.getWidth(),0,frameBufObj.getHeight());
		}

#if IMLOAD_LIB == IMLOAD_DEVIL
		ilBindImage(mScreenShotImage);
		if(region.getWidth()!= mWidthCache || region.getHeight() != mHeightCache ){
			mWidthCache = region.getWidth();
			mHeightCache = region.getHeight();
			// update screen-shot texture to hold an image compatible with current capture configuration
			ushort bytes_per_pixel = 4;
			ILenum imgFormat = IL_RGBA;
			ILenum imgType   = IL_UNSIGNED_BYTE;
			ilTexImage(
				mWidthCache, mHeightCache, 
				0/*depth*/,
				bytes_per_pixel,
				imgFormat,
				imgType, 
				NULL);
		}
		glReadPixels(
			region.getLeft(),region.getBottom(),region.getWidth(), region.getHeight(),
			format, GL_UNSIGNED_BYTE, ilGetData() );
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
		// TODO
#endif

		return true;
	}

	bool ScreenCapturer::captureFrame(
		RectI region, PixelDataFormat format, WindowBufferSource source
	){
		GPUFrameBuffer::unbindResource();
		glPixelStorei(GL_PACK_ALIGNMENT,1);
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		glReadBuffer(source);
#else
		(void) source;
#endif

#if IMLOAD_LIB == IMLOAD_DEVIL
		ilBindImage(mScreenShotImage);
		if(region.getWidth()!= mWidthCache || region.getHeight() != mHeightCache ){
			mWidthCache = region.getWidth();
			mHeightCache = region.getHeight();
			// update screen-shot texture to hold an image compatible with current capture configuration
			ushort bytes_per_pixel = 4;
			ILenum imgFormat = IL_RGBA;
			ILenum imgType   = IL_UNSIGNED_BYTE;
			ilTexImage(
				mWidthCache, mHeightCache, 
				0/*depth*/,
				bytes_per_pixel,
				imgFormat,
				imgType, 
				NULL);
		}
		glReadPixels(
			region.getLeft(),region.getBottom(),region.getWidth(), region.getHeight(),
			format, GL_UNSIGNED_BYTE, ilGetData() );
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
		// TODO
#endif
		return true;
	}

}
