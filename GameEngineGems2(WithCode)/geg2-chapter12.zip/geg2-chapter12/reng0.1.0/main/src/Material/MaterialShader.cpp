/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Material/MaterialShader.h"

#include <log4cplus/logger.h>
#include <assert.h>
#include <fstream>

using namespace log4cplus;
using namespace std;

namespace REng{

	std::vector<std::string> MaterialShader::mPreTextList;

	MaterialShader::MaterialShader(const string& name, ShaderType shaderType) 
		:GPUShader(shaderType)
		,mName(name)
		,mIsCompiled(false)
		,mShaderVersion(ShaderVersion_Default)
		,mSourceIsText(false)
	{
	}

	MaterialShader::~MaterialShader() { ; }

	const std::string& MaterialShader::getName() const{
		return mName;
	}
	ShaderVersion MaterialShader::getShaderVersion() const {
		return mShaderVersion;
	}
	const UniformPropertyList& MaterialShader::getUniformDefaults() const{
		return mUniformDefaults;
	}
	const string& MaterialShader::getSourceFileName() const{
		return mSourceFileOrText;
	}

	void MaterialShader::setSourceFileName(const string& name){
		if(mIsCompiled) return;
		mSourceFileOrText = name;
		mSourceIsText = false;
	}
	void MaterialShader::setSourceText(const std::string& text){
		if(mIsCompiled) return;
		mSourceFileOrText = text;
		mSourceIsText = true;
	}
	void MaterialShader::setShaderVersion(ShaderVersion _ver){
		if(mIsCompiled) return;
		if(!isSupported(_ver)) return;
		mShaderVersion = _ver;
	}

	bool MaterialShader::isSourceText() const{
		return mSourceIsText;
	}
	bool MaterialShader::isCompiled() const {
		return mIsCompiled;
	}

	void MaterialShader::addUniformDefault(RenderProp_Uniform* prop){
		assert(prop);
		mUniformDefaults.push_back(prop);
	}

	void MaterialShader::clearUniformDefaults(){
		mUniformDefaults.clear();
	}

	void MaterialShader::removeUniformDefault(size_t index){
		assert(index < mUniformDefaults.size());
		mUniformDefaults.erase(mUniformDefaults.begin()+index);
	}

	size_t MaterialShader::getUniformDefaultCount() const{
		return mUniformDefaults.size();
	}

	RenderProp_Uniform* MaterialShader::getUniformDefault(size_t index){
		assert(index < mUniformDefaults.size());
		return mUniformDefaults[index];
	}

	RenderProp_Uniform* MaterialShader::getUniformDefault(const string& uniformName){
		size_t uniformCount = mUniformDefaults.size();
		for(size_t i=0 ; i<uniformCount ; i++){
			if ( mUniformDefaults[i]->getName() == uniformName)
				return mUniformDefaults[i];
		}
		return 0;
	}

	/*
	void MaterialShader::activateUniforms(){
		size_t uniCount = mUniformDefaults.size();
		for(size_t i=0 ; i<uniCount ; i++){
			if (mUniformDefaults[i]->requiresSynch()) {
				mUniformDefaults[i]->activate();
			}
		}
	}
	*/

	void MaterialShader::addPreText(const char* text){
		mPreTextList.push_back(text);
	}

	bool MaterialShader::compile(){
		if(isCompiled()) return true;

		Logger logger = Logger::getInstance("mtrl");

		// 2. create the text pointer array that will store shader source
		// 2.1 The input file is read into a single array
		// 2.2 The user may predefine some values through material shader, use them
		// 2.3 Auto REng name are inserted automatically (TODO)
		// 2.4 Each light struct type is defined initially
		size_t textCount = 2 + mPreprocDefines.size() + mPreTextList.size();
		if(mShaderVersion!=ShaderVersion_Default) textCount++;
		const char** shaderText = (const char**) malloc( sizeof(const char**) * textCount);

		uint textIndex = 0;
		switch(mShaderVersion){
			case ShaderVersion_100ES:   shaderText[textIndex++] = "#version 100\n"; break;
			case ShaderVersion_130:     shaderText[textIndex++] = "#version 130\n"; break;
			case ShaderVersion_140:     shaderText[textIndex++] = "#version 140\n"; break;
			case ShaderVersion_150:     shaderText[textIndex++] = "#version 150\n"; break;
			case ShaderVersion_330:     shaderText[textIndex++] = "#version 330\n"; break;
			case ShaderVersion_Default: break;
		}
		// 2.1 copy preprocessor defines 
		for(uint i=0 ; i<mPreprocDefines.size() ; i++)
			shaderText[textIndex++] = mPreprocDefines[i].c_str();
		// 2.2 copy pre-text defines
		for(uint i=0 ; i<mPreTextList.size() ; i++)
			shaderText[textIndex++] = mPreTextList[i].c_str();
		
		shaderText[textIndex++] = "\n";

		// 1. Read file contents
		std::string fileText(""); // here, because file content needs to persist
		if(mSourceIsText==false){
			ifstream fileStream;
			fileStream.open(mSourceFileOrText.c_str());
			if(!fileStream.is_open()) {
				LOG4CPLUS_ERROR(logger,"MaterialShader["<<mName.c_str()<<"] | Compile | Cannot open file: "<<mSourceFileOrText.c_str()<<"");

				return false;
			}
			fileText = std::string((istreambuf_iterator<char>(fileStream)), istreambuf_iterator<char>());
			fileStream.close();
			shaderText[textIndex] = fileText.c_str();
		} else {
			shaderText[textIndex] = mSourceFileOrText.c_str();
		}

		if(compileFromText(textCount, shaderText)==false){
			LOG4CPLUS_ERROR(logger,"MaterialShader["<<mName.c_str()<<"] | Compilation Fail | Source: "<<
				(mSourceIsText?"text":mSourceFileOrText.c_str()));
			// uncomment the following to print complete shader text for debugging
//			std::string toPrint;
//			for(size_t i=0; i!=textIndex+1; i++) toPrint.append(shaderText[i]);
//			LOG4CPLUS_ERROR(logger,"Text:\n" << toPrint << "\n");
			return false;
		} else {
			LOG4CPLUS_INFO(logger,"MaterialShader["<<mName.c_str()<<"] | Compilation Success | Source: "<<
				(mSourceIsText?"text":mSourceFileOrText.c_str()));
		}
		mSourceFileOrText.clear();
		mIsCompiled = true;
		return true;
	}

	void MaterialShader::addPreprocDef(const std::string& name){
		string command = "#";
		command.append("define ").append(name).append("\n");
		mPreprocDefines.push_back(command);
	}
	void MaterialShader::addPreprocUndef(const std::string& name){
		string command = "#";
		command.append("undef ").append(name).append("\n");
		mPreprocDefines.push_back(command);
	}
	void MaterialShader::addPreprocSet(const std::string& name, const std::string& _val){
		string command = "#";
		command.append("define ").append(name).append(" ").append(_val).append("\n");
		mPreprocDefines.push_back(command);
	}

/*
	size_t MaterialShader::loadUniformDefaults(const CHWProgram& prog){
		size_t uniformCount = mUniformDefaults.size();
		if(uniformCount == 0)
			return 0;

		Logger logger = Logger::getInstance("mtrl");
		size_t unbounded = 0;
		size_t bounded = 0;
		LOG4CPLUS_INFO(logger,"MaterialShader["<<mName.c_str()<<"] Loading uniform defaults to program [Id="<<prog.getProgram()<<"].");
		for(int i=0 ; i<uniformCount ; i++){
			if( mUniformDefaults[i]->bindToProgram(prog) == false){
				unbounded++;
				LOG4CPLUS_WARN(logger,"MaterialShader["<<mName.c_str()<<"] Uniform default "<<mUniformDefaults[i]->getName()<<" cannot be bound...");
			} else {
				bounded++;
				LOG4CPLUS_INFO(logger,"MaterialShader["<<mName.c_str()<<"] Uniform default "<<mUniformDefaults[i]->getName()<<" is bound...");
				mUniformDefaults[i]->activate();
			}
		}
		LOG4CPLUS_INFO(logger,"MaterialShader["<<mName.c_str()<<"] Uniform defaults loaded (+"<<bounded<<") (-"<<unbounded<<")...");
		return unbounded;
	}
*/
}

