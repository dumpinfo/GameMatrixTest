/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include <boost/foreach.hpp>

#include "REng/Material/MaterialManager.h"

#include <log4cplus/logger.h>

using namespace log4cplus;
using namespace boost;

namespace REng{
	template<> MaterialManager* Singleton<MaterialManager>::ms_Singleton = 0;
	MaterialManager* MaterialManager::getSingletonPtr(void) {
		return ms_Singleton;
	}
	MaterialManager& MaterialManager::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	MaterialManager::MaterialManager(void) { 
	}

	MaterialManager::~MaterialManager(void) { ; }

	bool MaterialManager::createMaterial(const std::string& name, MaterialPtr& material){
		// create a new material with given name
		MaterialPtr newMaterial(new Material(name));

		std::pair<MaterialList::iterator,bool> insertResult;
		insertResult = mMaterials.insert( std::pair<std::string,MaterialPtr>(name, newMaterial) );
		material = insertResult.first->second;
		if(insertResult.second == true){
			return true;
		} else {
			return false;
		}
	}

	bool MaterialManager::createMaterialShader(const std::string& name, ShaderType type, MaterialShaderPtr& materialShader){
		// create a new material shader with given name
		MaterialShaderPtr newMatShader(new MaterialShader(name,type));

		std::pair<MaterialShaderList::iterator,bool> insertResult;
		insertResult = mMaterialShaders.insert( std::pair<std::string,MaterialShaderPtr>(name, newMatShader) );
		materialShader = insertResult.first->second;
		if(insertResult.second == true){
			return true;
		} else {
			return false;
		}
	}

	bool MaterialManager::createMaterialTexture(const std::string& name, TextureType type, MaterialTexturePtr& materialtexture){
		MaterialTexturePtr newTexture( new MaterialTexture(name, type) );

		std::pair<MaterialTextureList::iterator,bool> insertResult;
		const std::pair<std::string,MaterialTexturePtr> insPair(name,newTexture);
		insertResult = mMaterialTextures.insert(insPair);
		materialtexture = insertResult.first->second;
		if(insertResult.second == true){
			return true;
		} else {
			return false;
		}
	}

	bool MaterialManager::createMaterialProgram(const std::string& name, MaterialProgramPtr& materialProgram){
		MaterialProgramPtr newProgram( new MaterialProgram(name) );

		std::pair<MaterialProgramList::iterator,bool> insertResult;
		const std::pair<std::string,MaterialProgramPtr> insPair(name,newProgram);
		insertResult = mMaterialPrograms.insert(insPair);
		materialProgram = insertResult.first->second;
		if(insertResult.second == true){
			return true;
		} else {
			return false;
		}
	}
	
	bool MaterialManager::createSampler(const std::string& name, GPUSamplerPtr& sampler){
		bool resourceSupport=GPUSamplerResource::isSupported();
		GPUSamplerPtr newSampler;
		if(resourceSupport){
			newSampler.reset(new GPUSamplerResource(0));
		} else {
			newSampler.reset(new GPUSamplerTexture());
		}

		std::pair<SamplerList::iterator,bool> insertResult;
		const std::pair<std::string,GPUSamplerPtr> insPair(name,newSampler);
		insertResult = mSamplers.insert(insPair);
		sampler = insertResult.first->second;
		if(insertResult.second == true){
			return true;
		} else {
			return false;
		}
	}

	MaterialPtr MaterialManager::getMaterial(const char* name){
		if(name == 0) return MaterialPtr(); // TODO: log error message

		MaterialList::iterator it;
		it = mMaterials.find(name);
		if(it == mMaterials.end() ){
			// material name not found
			return MaterialPtr();
		} else {
			return it->second;
		}
	}

	MaterialShaderPtr MaterialManager::getMaterialShader(const char* name){
		if(name == 0) return MaterialShaderPtr(); // TODO: log error message

		MaterialShaderList::iterator it;
		it = mMaterialShaders.find(name);
		if(it == mMaterialShaders.end() ){
			// material name not found
			return MaterialShaderPtr();
		} else {
			return it->second;
		}
	}

	MaterialTexturePtr MaterialManager::getMaterialTexture(const char* name){
		if(name == 0) return MaterialTexturePtr(); // TODO: log error message

		MaterialTextureList::iterator it;
		it = mMaterialTextures.find(name);
		if(it == mMaterialTextures.end() ){
			// material name not found
			return MaterialTexturePtr();
		} else {
			MaterialTexturePtr texture = it->second;
			// try to load from resources, don't care if it fails...
			texture->loadFromFilesToResource();
			return texture;
		}
	}
	
	GPUSamplerPtr MaterialManager::getSampler(const char* name){
		if(name == 0) return GPUSamplerPtr(); // TODO: log error message

		SamplerList::iterator it;
		it = mSamplers.find(name);
		if(it == mSamplers.end() ){
			return GPUSamplerPtr();
		}
		return it->second;
	}

	MaterialProgramPtr MaterialManager::getMaterialProgram(const char* name){
		if(name == 0) return MaterialProgramPtr(); // TODO: log error message

		MaterialProgramList::iterator it;
		it = mMaterialPrograms.find(name);
		if(it == mMaterialPrograms.end() ){
			// material name not found
			return MaterialProgramPtr();
		} else {
			MaterialProgramPtr prog = it->second;
			// TODO : Program need to be updated?
			return prog;
		}
	}

	size_t MaterialManager::getMaterialCount() const{
		return mMaterials.size();
	}
	size_t MaterialManager::getMaterialShaderCount() const{
		return mMaterialShaders.size();
	}
	size_t MaterialManager::getMaterialTextureCount() const{
		return mMaterialTextures.size();
	}
	size_t MaterialManager::getMaterialProgramCount() const{
		return mMaterialPrograms.size();
	}

	size_t MaterialManager::compileMaterialShaders(){
		size_t err = 0;
		typedef std::pair<std::string, MaterialShaderPtr> Pair;
		BOOST_FOREACH(Pair p, mMaterialShaders){
			// if the material shader is compiled, has no effect
			err += p.second->compile();
		}
		return err;
	}

	size_t MaterialManager::loadMaterials(){
		size_t failCount(0);
		typedef std::pair<std::string, MaterialPtr> Pair;
		BOOST_FOREACH(Pair p, mMaterials){
			failCount += (p.second->load()>0);
		}
		return failCount;
	}

	void MaterialManager::loadTexturesFromFiles(){
		typedef std::pair<std::string, MaterialTexturePtr> Pair;
		BOOST_FOREACH(Pair p, mMaterialTextures){
			p.second->loadFromFilesToResource();
		}
	}

}



