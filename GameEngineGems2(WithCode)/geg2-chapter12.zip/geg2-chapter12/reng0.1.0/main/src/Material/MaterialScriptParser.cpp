/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Material/MaterialScriptParser.h"

#include "REng/Defines.h"

// include all material system
#include "REng/Material/Material.h"
#include "REng/Material/MaterialProgram.h"
#include "REng/Material/MaterialShader.h"
#include "REng/Material/MaterialTexture.h"
#include "REng/Material/MaterialManager.h"
#include "REng/Material/RenderPass.h"
#include "REng/Material/Technique.h"

// logging
#include <log4cplus/logger.h>
using namespace log4cplus;

#include <cstdio>
#include <string.h>
#include <iostream>
#include <fstream>

namespace REng{
	// singleton stuff
	template<> MaterialScriptParser* Singleton<MaterialScriptParser>::ms_Singleton = 0;
	MaterialScriptParser* MaterialScriptParser::getSingletonPtr(void) {
		return ms_Singleton;
	}
	MaterialScriptParser& MaterialScriptParser::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	// helper macros
#define CONVERT_STR_TO_ENUM( gl_str ) if(!strcmp(str,"#gl_str")) { ret = GL_##gl_str## ; return true; } 
#define CONVERT_STR_TO_ENUM_OES( gl_str ) if(!strcmp(str,"#gl_str")) { ret = GL_##gl_str##_OES ; return true; } 
#define CONVERT_STR_TO_RPT( prop_str) if(!strcmp(str,"#prop_str")) { rpt = RPT_##prop_str## ; return true; }

	bool MaterialScriptParser::getGLenum(const char* str, GLenum &ret){
		if(!strcmp(str,"FUNC_ADD")) { ret = GL_FUNC_ADD ; return true; }
		if(!strcmp(str,"FUNC_SUBTRACT")) { ret = GL_FUNC_SUBTRACT; return true; }
		if(!strcmp(str,"FUNC_REVERSE_SUBTRACT")) { ret = GL_FUNC_REVERSE_SUBTRACT; return true; }
		if(!strcmp(str,"ZERO")) { ret = GL_ZERO; return true; }
		if(!strcmp(str,"ONE")) { ret = GL_ONE; return true; }
		if(!strcmp(str,"SRC_COLOR")) { ret = GL_SRC_COLOR; return true; }
		if(!strcmp(str,"ONE_MINUS_SRC_COLOR")) { ret = GL_ONE_MINUS_SRC_COLOR; return true; }
		if(!strcmp(str,"DST_COLOR")) { ret = GL_DST_COLOR; return true; }
		if(!strcmp(str,"ONE_MINUS_DST_COLOR")) { ret = GL_ONE_MINUS_DST_COLOR; return true; }
		if(!strcmp(str,"SRC_ALPHA")) { ret = GL_SRC_ALPHA; return true; }
		if(!strcmp(str,"ONE_MINUS_SRC_ALPHA")) { ret = GL_ONE_MINUS_SRC_ALPHA; return true; }
		if(!strcmp(str,"DST_ALPHA")) { ret = GL_DST_ALPHA; return true; }
		if(!strcmp(str,"ONE_MINUS_DST_ALPHA")) { ret = GL_ONE_MINUS_DST_ALPHA; return true; }
		if(!strcmp(str,"CONSTANT_COLOR")) { ret = GL_CONSTANT_COLOR; return true; }
		if(!strcmp(str,"ONE_MINUS_CONSTANT_COLOR")) { ret = GL_ONE_MINUS_CONSTANT_COLOR; return true; }
		if(!strcmp(str,"CONSTANT_ALPHA")) { ret = GL_CONSTANT_ALPHA; return true; }
		if(!strcmp(str,"ONE_MINUS_CONSTANT_ALPHA")) { ret = GL_ONE_MINUS_CONSTANT_ALPHA; return true; }
		if(!strcmp(str,"SRC_ALPHA_SATURATE")) { ret = GL_SRC_ALPHA_SATURATE; return true; }
		if(!strcmp(str,"NONE")) { ret = GL_NONE; return true; }
		if(!strcmp(str,"FRONT")) { ret = GL_FRONT; return true; }
		if(!strcmp(str,"BACK")) { ret = GL_BACK; return true; }
		if(!strcmp(str,"FRONT_AND_BACK")) { ret = GL_FRONT_AND_BACK; return true; }
		if(!strcmp(str,"NEVER")) { ret = GL_NEVER; return true; }
		if(!strcmp(str,"LESS")) { ret = GL_LESS; return true; }
		if(!strcmp(str,"LEQUAL")) { ret = GL_LEQUAL; return true; }
		if(!strcmp(str,"GREATER")) { ret = GL_GREATER; return true; }
		if(!strcmp(str,"GEQUAL")) { ret = GL_GEQUAL; return true; }
		if(!strcmp(str,"EQUAL")) { ret = GL_EQUAL; return true; }
		if(!strcmp(str,"NOTEQUAL")) { ret = GL_NOTEQUAL; return true; }
		if(!strcmp(str,"ALWAYS")) { ret = GL_ALWAYS; return true; }
		if(!strcmp(str,"KEEP")) { ret = GL_KEEP; return true; }
		if(!strcmp(str,"ZERO")) { ret = GL_ZERO; return true; }
		if(!strcmp(str,"REPLACE")) { ret = GL_REPLACE; return true; }
		if(!strcmp(str,"INCR")) { ret = GL_INCR; return true; }
		if(!strcmp(str,"INCR_WRAP")) { ret = GL_INCR_WRAP; return true; }
		if(!strcmp(str,"DECR")) { ret = GL_DECR; return true; }
		if(!strcmp(str,"DECR_WRAP")) { ret = GL_DECR_WRAP; return true; }
		if(!strcmp(str,"INVERT")) { ret = GL_INVERT; return true; }
		if(!strcmp(str,"CW")) { ret = GL_CW; return true; }
		if(!strcmp(str,"CCW")) { ret = GL_CCW; return true; }
		if(!strcmp(str,"NEAREST")) { ret = GL_NEAREST; return true; }
		if(!strcmp(str,"LINEAR")) { ret = GL_LINEAR; return true; }
		if(!strcmp(str,"NEAREST_MIPMAP_NEAREST")) { ret = GL_NEAREST_MIPMAP_NEAREST; return true; }
		if(!strcmp(str,"NEAREST_MIPMAP_LINEAR")) { ret = GL_NEAREST_MIPMAP_LINEAR; return true; }
		if(!strcmp(str,"LINEAR_MIPMAP_NEAREST")) { ret = GL_LINEAR_MIPMAP_NEAREST; return true; }
		if(!strcmp(str,"LINEAR_MIPMAP_LINEAR")) { ret = GL_LINEAR_MIPMAP_LINEAR; return true; }
		if(!strcmp(str,"CLAMP_TO_EDGE")) { ret = GL_CLAMP_TO_EDGE; return true; }
		if(!strcmp(str,"CLAMP_TO_BORDER")) { ret = GL_CLAMP_TO_BORDER; return true; }
		if(!strcmp(str,"REPEAT")) { ret = GL_REPEAT; return true; }
		if(!strcmp(str,"MIRRORED_REPEAT")) { ret = GL_MIRRORED_REPEAT; return true; }

		if(!strcmp(str,"BGR")) { ret = GL_BGR; return true; }
		if(!strcmp(str,"BGRA")) { ret = GL_BGRA; return true; }
		if(!strcmp(str,"G")) { ret = GL_GREEN; return true; }
		if(!strcmp(str,"B")) { ret = GL_BLUE; return true; }

		// ImageFormats
		if(!strcmp(str,"R")) { ret = GL_RED; return true; }
		if(!strcmp(str,"RG")) { ret = GL_RG; return true; }
		if(!strcmp(str,"RGB")) { ret = GL_RGB; return true; }
		if(!strcmp(str,"RGBA")) { ret = GL_RGBA; return true; }
		if(!strcmp(str,"A")) { ret = GL_ALPHA; return true; }
		if(!strcmp(str,"L")) { ret = GL_LUMINANCE; return true; }
		if(!strcmp(str,"LA")) { ret = GL_LUMINANCE_ALPHA; return true; }

		//! In ES 2.0 configurations, the following are equal to GL_NONE
		if(!strcmp(str,"POINT")) { ret = GL_POINT; return true; }
		if(!strcmp(str,"LINE")) { ret = GL_LINE; return true; }
		if(!strcmp(str,"FILL")) { ret = GL_FILL; return true; }
/*
		CONVERT_STR_TO_ENUM_OES(PALETTE4_RGB8);
		CONVERT_STR_TO_ENUM_OES(PALETTE4_RGBA8);
		CONVERT_STR_TO_ENUM_OES(PALETTE4_R5_G6_B5);
		CONVERT_STR_TO_ENUM_OES(PALETTE4_RGBA4);
		CONVERT_STR_TO_ENUM_OES(PALETTE4_RGB5_A1);
		CONVERT_STR_TO_ENUM_OES(PALETTE8_RGB8);
		CONVERT_STR_TO_ENUM_OES(PALETTE8_RGBA8);
		CONVERT_STR_TO_ENUM_OES(PALETTE8_R5_G6_B5);
		CONVERT_STR_TO_ENUM_OES(PALETTE8_RGBA4);
		CONVERT_STR_TO_ENUM_OES(PALETTE8_RGB5_A1);
*/
		return false;
	}

	bool MaterialScriptParser::readImageFormat(ImageFormat& format){
		if(!strcmp(str,"R")) { format = ImageFormat_R; return true; }
		if(!strcmp(str,"RG")) { format = ImageFormat_RG; return true; }
		if(!strcmp(str,"RGB")) { format = ImageFormat_RGB; return true; }
		if(!strcmp(str,"RGBA")) { format = ImageFormat_RGBA; return true; }
		if(!strcmp(str,"A")) { format = ImageFormat_A; return true; }
		if(!strcmp(str,"L")) { format = ImageFormat_L; return true; }
		if(!strcmp(str,"LA")) { format = ImageFormat_LA; return true; }

		if(!strcmp(str,"D")) { format = ImageFormat_D; return true; }
		if(!strcmp(str,"D16")) { format = ImageFormat_D16; return true; }
		if(!strcmp(str,"D24")) { format = ImageFormat_D24; return true; }
		if(!strcmp(str,"D32")) { format = ImageFormat_D32; return true; }
		if(!strcmp(str,"D32F")) { format = ImageFormat_D32F; return true; }

		if(!strcmp(str,"S")) { format = ImageFormat_S; return true; }
		if(!strcmp(str,"S1")) { format = ImageFormat_S1; return true; }
		if(!strcmp(str,"S4")) { format = ImageFormat_S4; return true; }
		if(!strcmp(str,"S8")) { format = ImageFormat_S8; return true; }
		if(!strcmp(str,"S16")) { format = ImageFormat_S16; return true; }

		// TODO : Extend signed color types

		// Compressed types
		if(!strcmp(str,"Compr_R_Signed_RGTC")) { format = ImageFormat_Compr_R_Signed_RGTC; return true;}
		if(!strcmp(str,"Compr_RG_RGTC")) { format = ImageFormat_Compr_RG_RGTC; return true;}
		if(!strcmp(str,"Compr_RG_SIGNED_RGTC")) { format = ImageFormat_Compr_RG_SIGNED_RGTC; return true;}
		if(!strcmp(str,"Compr_RGB_S3TC_DXT1")) { format = ImageFormat_Compr_RGB_S3TC_DXT1; return true;}
		if(!strcmp(str,"Compr_RGBA_S3TC_DXT1;")) { format = ImageFormat_Compr_RGBA_S3TC_DXT1; return true;}
		if(!strcmp(str,"RGBA_S3TC_DXT3")) { format = ImageFormat_Compr_RGBA_S3TC_DXT3; return true;}
		if(!strcmp(str,"Compr_RGBA_S3TC_DXT5")) { format = ImageFormat_Compr_RGBA_S3TC_DXT5; return true;}
		if(!strcmp(str,"Compr_RGB_PVRTC_4")) { format = ImageFormat_Compr_RGB_PVRTC_4; return true; }
		if(!strcmp(str,"Compr_RGB_PVRTC_2")) { format = ImageFormat_Compr_RGB_PVRTC_2; return true; }
		if(!strcmp(str,"Compr_RGBA_PVRTC_4")) { format = ImageFormat_Compr_RGBA_PVRTC_4; return true; }
		if(!strcmp(str,"Compr_RGBA_PVRTC_2")) { format = ImageFormat_Compr_RGBA_PVRTC_2; return true; }
		if(!strcmp(str,"Compr_RGB_ETC1")) { format = ImageFormat_Compr_RGB_ETC1; return true; }
		if(!strcmp(str,"Compr_RGB_ETC1")) { format = ImageFormat_Compr_R_RGTC; return true; }
		format = ImageFormat_None;
		return false;
	}

	bool MaterialScriptParser::getRPT(const char* str, RenderPropertyType &rpt){
		if(!strcmp(str,"blending")) { rpt = RPT_blending; return true; }
		if(!strcmp(str,"blend_equation")) { rpt = RPT_blend_equation; return true; }
		if(!strcmp(str,"blend_function")) { rpt = RPT_blend_function; return true; }
		if(!strcmp(str,"stencil_test")) { rpt = RPT_stencil_test; return true; }
		if(!strcmp(str,"stencil_function")) { rpt = RPT_stencil_function; return true; }
		if(!strcmp(str,"stencil_mask")) { rpt = RPT_stencil_mask; return true; }
		if(!strcmp(str,"stencil_operation")) { rpt = RPT_stencil_operation; return true; }
		if(!strcmp(str,"depth_test")) { rpt = RPT_depth_test; return true; }
		if(!strcmp(str,"depth_function")) { rpt = RPT_depth_function; return true; }
		if(!strcmp(str,"depth_mask")) { rpt = RPT_depth_mask; return true; }
		if(!strcmp(str,"color_mask")) { rpt = RPT_color_mask; return true; }
		if(!strcmp(str,"cull_face")) { rpt = RPT_cull_face; return true; }
		if(!strcmp(str,"front_face")) { rpt = RPT_front_face; return true; }
		if(!strcmp(str,"min_filter")) { rpt = RPT_min_filter; return true; }
		if(!strcmp(str,"mag_filter")) { rpt = RPT_mag_filter; return true; }
		if(!strcmp(str,"wrap_mode")) { rpt = RPT_wrap_mode; return true; }
		// Note: OpenGL ES 2.0 configurations can still parse poly_mode render properties (WARN's are generated)
		if(!strcmp(str,"poly_mode")) { rpt = RPT_poly_mode; return true; }
		if(!strcmp(str,"line_width")) { rpt = RPT_line_width; return true; }
		return false;
	}
	


	MaterialScriptParser::MaterialScriptParser(){
		mScriptLineNo = 0;
		matText = 0;
		noSkipComments = false;
	}

	MaterialScriptParser::~MaterialScriptParser() { ; }

	const char* MaterialScriptParser::readString(){
		mPostLine = false;
		mPreLineCount = 0;
		assert(matText);
		size_t str_index = 0;
		bool tokenStarted = false;
		while(true){
			if(matTextReadPos==matTextSize) break;
			char c = matText[matTextReadPos++];
			if(c == '\n') {
				mScriptLineNo++;
				if(tokenStarted) mPostLine = true;
				else ++mPreLineCount;
			}
			if(isWhiteSpace(c)){
				if(!tokenStarted) continue;
				break;
			} else{
				tokenStarted = true;
				str[str_index++] = c;
				if(!noSkipComments){
					if(str_index == 2){
						if(str[0] == '/' && str[1] == '/'){
							// rest of the line is comment
							while(matText[matTextReadPos++]!='\n');
							mScriptLineNo++;
							tokenStarted = false;
							str_index = 0;
						}
					}
				}
				if(str_index == MAX_STR_LEN){
					str_index--;
					break;
				}
			}
		}
		str[str_index] = 0; // set string terminator
		return str;
	}
	bool MaterialScriptParser::readFloat(float& data){
		size_t oldPos = matTextReadPos;
		int n;
		sscanf(matText+matTextReadPos," %f%n", &data, &n);
		matTextReadPos += n;
		return (oldPos!=matTextReadPos);
	}
	bool MaterialScriptParser::readBool(bool& data){
		int tempData;
		size_t oldPos = matTextReadPos;
		int n;
		sscanf(matText+matTextReadPos," %d%n", &tempData, &n);
		matTextReadPos += n;
		if(oldPos==matTextReadPos)return false;
		data = (tempData!=0);
		return true;
	}
	bool MaterialScriptParser::readUnsignedInt( unsigned int& data){
		size_t oldPos = matTextReadPos;
		int n;
		sscanf(matText+matTextReadPos," %d%n", &data, &n);
		matTextReadPos += n;
		return (oldPos!=matTextReadPos);
	}
	bool MaterialScriptParser::readInt( int& data){
		size_t oldPos = matTextReadPos;
		int n;
		sscanf(matText+matTextReadPos," %d%n", &data, &n);
		matTextReadPos += n;
		return (oldPos!=matTextReadPos);
	}
	bool MaterialScriptParser::readUniformType(UniformType& type){
		readString();
		if(!strcmp(str,"float")){ type = UniformType_Float_1;   return true; }
		if(!strcmp(str,"vec2")) { type = UniformType_Float_2;   return true; }
		if(!strcmp(str,"vec3")) { type = UniformType_Float_3;   return true; }
		if(!strcmp(str,"vec4")) { type = UniformType_Float_4;   return true; }
		if(!strcmp(str,"int"))  { type = UniformType_Int_1;     return true; }
		if(!strcmp(str,"ivec2")){ type = UniformType_Int_2;     return true; }
		if(!strcmp(str,"ivec3")){ type = UniformType_Int_3;     return true; }
		if(!strcmp(str,"ivec4")){ type = UniformType_Int_4;     return true; }
		if(!strcmp(str,"mat2")) { type = UniformType_Matrix_22; return true; }
		if(!strcmp(str,"mat3")) { type = UniformType_Matrix_33; return true; }
		if(!strcmp(str,"mat4")) { type = UniformType_Matrix_44; return true; }
		logUnrecogTokenError(str,"uniform_type");
		return false;
	}
	/*
	bool MaterialScriptParser::readAttributeType(VertexAttribShaderType& type){
		readString();
		if(!strcmp(str,"float")){ type = VertexAttribShaderType_float; return true; }
		if(!strcmp(str,"vec2")) { type = VertexAttribShaderType_vec2;  return true; }
		if(!strcmp(str,"vec3")) { type = VertexAttribShaderType_vec3;  return true; }
		if(!strcmp(str,"vec4")) { type = VertexAttribShaderType_vec4;  return true; }
		if(!strcmp(str,"mat2")) { type = VertexAttribShaderType_mat2;  return true; }
		if(!strcmp(str,"mat3")) { type = VertexAttribShaderType_mat3;  return true; }
		if(!strcmp(str,"mat4")) { type = VertexAttribShaderType_mat4;  return true; }
		logUnrecogTokenError(str,"attribute type");
		return false;
	}
	*/
	bool MaterialScriptParser::readGLenum(GLenum& glenum){
		return getGLenum(readString(),glenum);
	}
	bool MaterialScriptParser::readOnOff(bool& data){
		readString();
		if(!strcmp(str,"on")) { data = true;  return true; }
		if(!strcmp(str,"off")){ data = false; return true; }
		logUnrecogTokenError(str,"on-off");
		return false;
	}

	bool MaterialScriptParser::isWhiteSpace(char c){
		if(c==' ' || c=='\t' || c=='\n') return true;
		return false;
	}

	bool MaterialScriptParser::parseFile(const char* fileName){
		Logger logger = Logger::getInstance("matScriptParser");
		std::ifstream fileStream;
		fileStream.open(fileName);
		size_t memSize = 0;
		char* mem = 0;
		if(!fileStream.is_open()) {
			LOG4CPLUS_ERROR(logger, "File ["<<fileName<<"] could not be opened.");
			return false;
		} else {
			std::string matTextStr((std::istreambuf_iterator<char>(fileStream)), std::istreambuf_iterator<char>());
			fileStream.close();
			memSize = matTextStr.length();
			mem = (char*)malloc(memSize+1);
			strcpy(mem,matTextStr.c_str());
		}
		LOG4CPLUS_INFO(logger, "Parsing file ["<<fileName<<"].");

		parseFromMem(mem,memSize);
		free(mem);
		return true;
	}

	bool MaterialScriptParser::parseFromMem(const char* mem, size_t memSize){
		Logger logger = Logger::getInstance("matScriptParser");
		LOG4CPLUS_INFO(logger, "Parsing...");

		matTextSize = memSize;
		matText = mem;
		matTextReadPos = 0;

		// clear script position information
		mScriptLineNo = 0;

		bool errorFlag = false;
		while(matTextReadPos!=matTextSize){
			if(!strcmp(readString(),"shader")){
				std::string shaderName(readString());
				if(!parseShader(shaderName)){
					errorFlag = true; break;
				}
			} else if(!strcmp(str,"sampler")){
				std::string samplerName(readString());
				GPUSamplerPtr sampler;
				if(!parseSampler(samplerName,0,sampler)){
					errorFlag = true; break;
				}
			} else if(!strcmp(str,"texture")){
				std::string textureName(readString());
				if(!parseTexture(textureName)){
					errorFlag = true; break;
				}
			} else if(!strcmp(str,"program")){
				std::string progName(readString());
				if(!parseProgram(progName)){
					errorFlag = true; break;
				}
			} else if(!strcmp(str,"material")){
				std::string matName(readString());
				if(!parseMaterial(matName)){
					errorFlag = true; break;
				}
			} else {
				if(!strcmp(str,"")) break;
				logUnrecogTokenError(str,"top-level");
				errorFlag = true; break;
			}
		}
		if(!errorFlag) LOG4CPLUS_INFO(logger,"Material script is successfully parsed.");
		return !errorFlag;
	}

	bool MaterialScriptParser::parseShader(const std::string& name){
		Logger logger = Logger::getInstance("matScriptParser");
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{"); return false;
		}
		// 2. "type"
		if(strcmp(readString(),"type")){
			logWrongTokenError(str,"type"); return false;
		}
		// 3. <ShaderType>
		ShaderType type;
		readString();
		if(strcmp(str,"vertex")==0)        { type = ShaderType_Vertex;
		}else if(strcmp(str,"fragment")==0){ type = ShaderType_Fragment;
		}else{
			logWrongTokenError(str,"vertex/fragment"); return false;
		}
		// Create The GPU resource and its material wrapper
		MaterialShaderPtr shader;
		bool exists = (name=="");
		if(!exists) {
			if(!MaterialManager::getSingleton().createMaterialShader(name, type, shader)){
				LOG4CPLUS_WARN(logger,"Another material shader ["<<name<<"] already exists.");
				exists = true;
			}
		}
		// 4. "source"
		if(strcmp(readString(),"source")){
			logWrongTokenError(str,"source"); return false;
		}
		// 5. <sourceFileName> or the source Text
		if(strcmp(readString(),"{{")){
			shader->setSourceFileName(str);
		} else {
			noSkipComments = true;
			// read the source text
			std::string sourceText("");
			size_t lastScriptLineNo = mScriptLineNo;
			while(strcmp(readString(),"}}")){
				if(lastScriptLineNo!=mScriptLineNo) {
					for(int j=0;j<mPreLineCount;++j) sourceText += std::string("\n");
					sourceText +=  std::string(" ") + str;
					if(mPostLine) sourceText += std::string("\n");
					lastScriptLineNo = mScriptLineNo;
				} else 
					sourceText += std::string(" ") + str;
			}
			noSkipComments = false;
			if(!exists) shader->setSourceText(sourceText);
		}

		// 4. <AttributeList> (vertex shader only)
		// NOTE: This part is skipped. The code is not removed for future reference if required.
/*		if(shader->getType() == ShaderType_Vertex && false){
			// 4.1 "attributes"
			if(strcmp(readString(),"attributes")){
				logWrongTokenError(str,"attributes");
				return false;
			}
			// 4.2 "{"
			if(strcmp(readString(),"{")){
				logWrongTokenError(str,"{");
				return false;
			}
			// parse attribute elements
			while(strcmp(readString(),"}")){
				// str holds shader attribute name string, TODO : check auto mapping
				
				VertexAttribShaderType attribType;
				if(!readAttributeType(attribType)) return false;

				// TODO: check type validity
				// TODO: Add attribute mapping to shader
			}
		}
*/
		readString();

		// 6. <ShaderVersion>
		if(strcmp(str,"version") == 0){
			readString();
			if(strcmp(str,"100ES")    == 0) {if(!exists) shader->setShaderVersion(ShaderVersion_100ES);}
			else if(strcmp(str,"130") == 0) {if(!exists) shader->setShaderVersion(ShaderVersion_130);}
			else if(strcmp(str,"140") == 0) {if(!exists) shader->setShaderVersion(ShaderVersion_140);}
			else if(strcmp(str,"150") == 0) {if(!exists) shader->setShaderVersion(ShaderVersion_150);}
			else if(strcmp(str,"330") == 0) {if(!exists) shader->setShaderVersion(ShaderVersion_330);}
			else logWrongTokenError(str,"incorrect GLSLversion specification");
			readString();
		}

		// 7. <UniformDefaults>+
		if(strcmp(str,"uniform_defaults")==0){
			if(strcmp(readString(),"{")){
				logWrongTokenError(str,"{"); return false;
			}

			// 7.1. read uniform defaults list
			while(strcmp(readString(),"}")){
				std::string uniformName(str);
				UniformAutoName autoName;
				if(convertStrToUAN(str,autoName) == false){
					// custom uniform
					UniformType uniformType;
					if(!readUniformType(uniformType)) return false;
					RenderProp_Uniform *prop = new RenderProp_Uniform(uniformName, uniformType);
					if(!prop->parseFromFile()) return false;
					if(!exists) shader->addUniformDefault(prop);
				} else {
					LOG4CPLUS_WARN(logger, "Default values cannot be set for auto-named uniforms");
				}
			}
			readString();
		}

		// 8. <PreprocData>*
		while(true){
			if(!strcmp(str,"preproc_def")){
				std::string _temp(readString());
				if(!exists) shader->addPreprocDef(_temp);
			}
			else if(!strcmp(str,"preproc_undef")){
				std::string _temp(readString());
				if(!exists) shader->addPreprocUndef(_temp);
			}
			else if(!strcmp(str,"preproc_set")){
				std::string _temp(readString());
				std::string _temp2(readString());
				if(!exists) shader->addPreprocSet(_temp,_temp2);
			} else {
				break; // preproc defines ends here
			}
			readString();
		}
		// 8. "}"
		if(strcmp(str,"}")){
			logWrongTokenError(str,"}"); return false;
		}
		// FINAL
		if(!exists) 
			LOG4CPLUS_INFO(logger, "New shader ["<<shader->getName()<<"] is successfully created.");
		return true;
	}

	bool MaterialScriptParser::parseSampler(const std::string& name,
		MaterialTexture* texture, GPUSamplerPtr& fillThisIn)
	{
		Logger logger = Logger::getInstance("matScriptParser");

		// Create new sampler if required (either using MaterialManager or a local, non-shared GPU resource
		GPUSamplerPtr sampler; sampler.reset();
		if(texture==0){
			if(name!="") {
				if(false==MaterialManager::getSingleton().createSampler(name,sampler)){
					LOG4CPLUS_WARN(logger,"Another sampler ["<<name<<"] already exists.");
					sampler.reset();
				}
			} else {
				if(GPUSamplerResource::isSupported()){
					sampler.reset(new GPUSamplerResource(0));
				} else {
					sampler.reset(new GPUSamplerTexture());
				}
			}
		}

		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{");
			return false;
		}
		readString();
		// 2. <SamplerProp>*
		while(true){
			if(!strcmp(str,"min_filter")){
				SamplerProp_MinFilter prop;
				if(!prop.parseFromFile()) return false;

				// update states
				if(texture) texture->setSamplerProperty(prop);
				if(sampler.get()) sampler->setSamplerProperty(prop);

			} else if(!strcmp(str,"mag_filter")){
				SamplerProp_MagFilter prop;
				if(!prop.parseFromFile()) return false;

				// update states
				if(texture) texture->setSamplerProperty(prop);
				if(sampler.get()) sampler->setSamplerProperty(prop);

			} else if(!strcmp(str,"wrap_mode")){
				SamplerProp_WrapMode prop;
				if(!prop.parseFromFile()) return false;

				// update states
				if(texture) texture->setSamplerProperty(prop);
				if(sampler.get()) sampler->setSamplerProperty(prop);

			} else {
				break;
			}
			readString();
		}
		// 3. "}"
		if(strcmp(str,"}")){
			logWrongTokenError(str,"}"); return false;
		}
		// FINAL
		fillThisIn = sampler;
		if(name!="" && sampler.get()) {
			LOG4CPLUS_INFO(logger, "New sampler ["<<name<<"] is successfully created");
		}
		return true;
	}

	bool MaterialScriptParser::parseProgram(const std::string& name){
		Logger logger = Logger::getInstance("matScriptParser");
		// Create material program
		MaterialProgramPtr program;
		bool exists = (name=="");
		if(!exists) {
			if(false==MaterialManager::getSingleton().createMaterialProgram(name, program)){
				LOG4CPLUS_WARN(logger,"Another material program ["<<name<<"] already exists.");
				exists=true;
			}
		}
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{"); return false;
		}
		// 2. "shader_ref/shader"
		if(!strcmp(readString(),"shader_ref")){
			// 2.1. <ShaderName>
			char vertShaderName[MAX_STR_LEN];
			strcpy(vertShaderName, readString());
			if(!exists)program->setShaderName1(vertShaderName);
		} else if(!strcmp(str,"shader")){
			// 2.1. <ShaderBlock>
			std::string shaderName(name+"_shader1");
			if(!parseShader(shaderName)) return false;
			if(!exists)program->setShaderPtr1(MaterialManager::getSingleton().getMaterialShader(shaderName.c_str()));
		} else {
			logWrongTokenError(str,"shader-shader_ref"); return false;
		}
		// 3. "shader_ref/shader"
		if(!strcmp(readString(),"shader_ref")){
			// 2.1. <ShaderName>
			char vertShaderName[MAX_STR_LEN];
			strcpy(vertShaderName, readString());
			if(!exists)program->setShaderName2(vertShaderName);
		} else if(!strcmp(readString(),"shader")){
			// 2.1. <ShaderBlock>
			std::string shaderName(name+"_shader2");
			if(!parseShader(shaderName)) return false;
			if(!exists)program->setShaderPtr2(MaterialManager::getSingleton().getMaterialShader(shaderName.c_str()));
		} else {
			logWrongTokenError(str,"shader-shader_reff"); return false;
		}
		readString();
		// 4. <UniformDefaults>+
		if(strcmp(str,"uniform_defaults")==0){
			if(strcmp(readString(),"{")){
				logWrongTokenError(str,"{");
				return false;
			}
			// 4.1. read uniform defaults list
			while(strcmp(readString(),"}")){
				std::string uniformName(str);
				UniformAutoName autoName;
				if(convertStrToUAN(str,autoName) == false){
					// custom uniform
					UniformType uniformType;
					if(!readUniformType(uniformType)) return false;
					RenderProp_Uniform *prop = new RenderProp_Uniform(uniformName, uniformType);
					if(!prop->parseFromFile()) return false;
					if(!exists)program->addUniformDefault(prop);
				} else {
					LOG4CPLUS_WARN(logger, "Default values cannot be set for auto-named uniforms");
				}
			}
			readString();
		}
		// 5. "}"
		if(strcmp(str,"}")){
			logWrongTokenError(str,"}"); return false;
		}
		// FINAL
		if(!exists)
			LOG4CPLUS_INFO(logger, "New program ["<<program->getName()<<"] is successfully created.");
		return true;
	}

	bool MaterialScriptParser::parseTexture(const std::string& name){
		Logger logger = Logger::getInstance("matScriptParser");
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{"); return false;
		}
		// 2. "type"
		if(strcmp(readString(),"type")){
			logWrongTokenError(str,"type"); return false;
		}
		// 3. <textureType>
		TextureType texType;
		if(!strcmp(readString(),"2D"))  { texType = TextureType_2D;   } 
		else if(!strcmp(str,"3D"))      { texType = TextureType_3D;   }
		else if(!strcmp(str,"1D"))      { texType = TextureType_1D;   }
		else if(!strcmp(str,"CubeMap")) { texType = TextureType_Cube; }
		else {logUnrecogTokenError(str,"texture type"); return false; }
		// create material texture
		MaterialTexturePtr texture;
		bool exists = (name=="");
		if(!exists) {
			if(false==MaterialManager::getSingleton().createMaterialTexture(name,texType, texture)){
				LOG4CPLUS_WARN(logger,"Another texture ["<<name<<"] already exists.");
				exists=true;
			}
		}
		// 4. "source"
		if(strcmp(readString(),"source")){
			logWrongTokenError(str,"source"); return false;
		}
		// 5. <FileNames>
		int loop = 1;
		if(texType==TextureType_Cube) loop = 6;
		for(int i=0 ; i<loop ; i++) {
			std::string _temp(readString());
			if(!exists)texture->setSourceFileName(_temp,i);
		}
		// 6. <TexParams>*
		while(readString()){
			if(!strcmp(str,"format")){
				readString();
				ImageFormat imgFormat;
				if(false==readImageFormat(imgFormat)){
					MaterialScriptParser::logUnrecogTokenError(str,"internal image format enumeration");
					return false;
				}
				if(!exists)texture->setInternalFormat(imgFormat);
			} else if(!strcmp(str,"gen_mipmaps")){
				bool flag;
				if(!readOnOff(flag)) return false;
				texture->setGenMipmaps(flag);
			} else {
				break;
			}
		}
		// 7. <SamplerDef>+
		if(strcmp(str,"sampler_ref")==0){
			readString(); // samplerName
			// TODO
			readString();
		} else if(strcmp(str,"sampler")==0){
			// 2.1. <SamplerBlock>
			MaterialTexture* mt(0);
			if(!exists) mt = texture.get();
			GPUSamplerPtr sampler;
			// Note: since material texture pointer is given to sampler parser, it automatically
			// updates the material texture state
			if(!parseSampler("",mt,sampler)) return false;
			readString();
		}
		// 8. "}"
		if(strcmp(str,"}")){
			logWrongTokenError(str,"}"); return false;
		}
		// FINAL
		if(!exists)
			LOG4CPLUS_INFO(logger, "New texture ["<<texture->getName()<<"] is successfully created.");
		return true;
	}

	bool MaterialScriptParser::parseTextureBinding(RenderPass* pass){
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{"); return false;
		}
		// 2. "unit"
		if(strcmp(readString(),"unit")){
			logWrongTokenError(str,"unit"); return false;
		}
		// 3. <textureUnit>
		unsigned int unit;
		if(readUnsignedInt(unit)==false){
			logDefaultError("Texture unit must be an integer>=0.");
			return false;
		}
		while(readString()){
			// 5. "}"
			if(!strcmp(str,"}")){
				return true;

			} else if(!strcmp(str,"texture_ref")){
				std::string textureName(readString());
				if(pass) pass->setTextureBinding(unit, textureName);

			} else if (!strcmp(str,"sampler_ref")){
				std::string samplerName(readString());
				if(pass) pass->setSamplerState(unit,samplerName);

			} else if (!strcmp(str,"sampler")){
				// TODO: what is pas is invalid and we ar only parsing, not updating state?
				GPUSamplerPtr sampler;
				if(!parseSampler("",0,sampler)) return false;
				if(pass) pass->setSamplerState(unit,sampler);

			} else { break; }
		}
		logWrongTokenError(str,"}");
		return false;
	}

	bool MaterialScriptParser::parseMaterial(const std::string& name){
		Logger logger = Logger::getInstance("matScriptParser");
		// Create Material
		MaterialPtr material;
		bool exists = (name=="");
		if(!exists) {
			if(false==MaterialManager::getSingleton().createMaterial(name, material)){
				LOG4CPLUS_WARN(logger,"Another material ["<<name<<"] already exists.");
				exists=true;
			}
		}
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{"); return false;
		}
		// 2. <TechniqueBlock>*
		while(strcmp(readString(),"}")){
			if(!strcmp(str,"technique")){
				if(!exists) {
					if( !parseTechnique(material.get()) ) return false;
				} else {
					if( !parseTechnique(0)) return false;
				}
			} else {
				logUnrecogTokenError(str,"technique list"); return false;
			}
		}
		// FINAL
		if(!exists)
			LOG4CPLUS_INFO( logger, "New material ["<<name<<"] is successfully created." );
		return true;
	}

	bool MaterialScriptParser::parseTechnique(Material* material){
		int viewIndex = 0; // default
		int lodIndex  = 0; // default
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{");
			return false;
		}
		// 2. <lodIndexBlock>, <viewIndexBlock>
		while(strcmp(readString(),"pass")){
			// read viewIndex
			if(!strcmp(str,"viewIndex")){
				int n;
				sscanf(matText+matTextReadPos,"%d%n",&viewIndex,&n);
				matTextReadPos += n;
				if(viewIndex <0 || viewIndex >255){
					logDefaultError("viewIndex is not in valid range [0-256]");
					return false;
				}
			} else if(!strcmp(str,"lodIndex")){
				int n;
				sscanf(matText+matTextReadPos,"%d%n",&lodIndex,&n);
				matTextReadPos += n;
				if(viewIndex <0 || lodIndex >255){
					logDefaultError("lodIndex is not in valid range [0-256]");
					return false;
				}
			} else{
				logUnrecogTokenError(str,"technique");
				return false;
			}
		}
		// create technique
		Technique* tech(0);
		if(material) tech = material->createLoDedData(viewIndex, lodIndex);
		// 3. <PassBlock>*
		while(strcmp(str,"}")){
			if(!strcmp(str,"pass")){
				RenderPass* pass(0);
				if(tech){
					pass = tech->createRenderPass();
					if(pass == 0){
						logDefaultError("Render pass could not be created. (Exceeded render pass count limit)");
						return false;
					}
				}
				if(!parsePass(pass)) return false;
			} else {
				logUnrecogTokenError(str,"pass list"); return false;
			}
			readString();
		}
		return true;
	}


	bool MaterialScriptParser::parsePass(RenderPass* pass){
		// 1. "{"
		if(strcmp(readString(),"{")){
			logWrongTokenError(str,"{");
			return false;
		}
		// 2. <PassProgramBlock>
		if(!strcmp(readString(),"program_ref")){
			// 1.2 <programName>
			char programName[MAX_STR_LEN];
			strcpy(programName, readString());
			if(pass)pass->setProgramName(programName);
		} else {
			char progAutoName[128];
			if(pass){
				sprintf(progAutoName,"%s_T_P%i",
					pass->getOwnerTechnique().getOwnerMaterial()->getName().c_str(),
					int(pass->getIndex())
					);
			}

			// Note: if parsing fails below, new program is automatically destructed
			MaterialProgramPtr newProgram;
			if(pass) newProgram.reset(new MaterialProgram(progAutoName));
			// 2. First shader
			if(strcmp(str,"shader_ref")==0){ // reference
				std::string _temp(readString());
				if(pass) newProgram->setShaderName1(_temp);
			} else {
				if(strcmp(str,"shader")==0){ // new, internal
					std::string shaderName(std::string(progAutoName)+"_S1");
					if(!parseShader(shaderName)) return false;
					if(pass) newProgram->setShaderPtr1(MaterialManager::getSingleton().getMaterialShader(shaderName.c_str()));
				} else {
					logWrongTokenError(str,"shader_ref or shader");
					return false;
				}
			}
			readString();
			// 3. Second shader
			if(strcmp(str,"shader_ref")==0){ // reference
				std::string _temp = readString();
				if(pass) newProgram->setShaderName2(_temp);
			} else {
				if(strcmp(str,"shader")==0){ // new, internal
					std::string shaderName(std::string(progAutoName)+"_S2");
					if(!parseShader(shaderName)) return false;
					if(pass) newProgram->setShaderPtr2(MaterialManager::getSingleton().getMaterialShader(shaderName.c_str()));
				} else {
					logWrongTokenError(str,"shader_ref or shader");
					return false;
				}
			}
			// copy the pointer
			if(pass) pass->setProgram(newProgram);
		}
		// 3. <UniformStateBlock>+
		if(strcmp(readString(),"uniform_states") == 0){
			// 3.1. "{"
			if(strcmp(readString(),"{")){
				logWrongTokenError(str,"{");
				return false;
			}
			// 3.2. <uniformMatEntry>*
			while(strcmp(readString(),"}")){
				// NOTE: can only be a custom uniform
				// Read material uniform name
				std::string uniformName(str);
				// Read material uniform type
				UniformType uniformType;
				if(!readUniformType(uniformType)) return false;
				// Create material uniform
				RenderProp_Uniform *prop = new RenderProp_Uniform(uniformName, uniformType);
				// Parse material data from file
				if(!prop->parseFromFile()) return false;
				if(pass) pass->addUniformDefault(prop);
			}
			readString();
		}
		// 4. <RenderStateBlock>+
		if(strcmp(str,"render_states")==0){
			// 4.1. "{"
			if(strcmp(readString(),"{")){
				logWrongTokenError(str,"{"); return false;
			}
			// 4.2. Read render states
			while(strcmp(readString(),"}")){
				// convert string to a render state type
				RenderPropertyType rsType;
				if(getRPT(str,rsType)==false){
					logGLConverstionError(str);
					return false;
				}
				RenderProp_Generic *prop = 0;
				switch(rsType){
				case RPT_blending:
					prop = new RenderProp_Blending();
					if(! static_cast<RenderProp_Blending*>(prop)->parseFromFile()) return false;
					break;
				case RPT_blend_equation:
					prop = new RenderProp_BlendEq();
					if(! static_cast<RenderProp_BlendEq*>(prop)->parseFromFile()) return false;
					break;
				case RPT_blend_function:
					prop = new RenderProp_BlendFunc();
					if(! static_cast<RenderProp_BlendFunc*>(prop)->parseFromFile()) return false;
					break;
				case RPT_stencil_test:
					prop = new RenderProp_StencilTest();
					if(! static_cast<RenderProp_StencilTest*>(prop)->parseFromFile()) return false;
					break;
				case RPT_stencil_function:
					prop = new RenderProp_StencilFunc();
					if(! static_cast<RenderProp_StencilFunc*>(prop)->parseFromFile()) return false;
					break;
				case RPT_stencil_mask:
					prop = new RenderProp_StencilMask();
					if(! static_cast<RenderProp_StencilMask*>(prop)->parseFromFile()) return false;
					break;
				case RPT_stencil_operation:
					prop = new RenderProp_StencilOp();
					if(! static_cast<RenderProp_StencilOp*>(prop)->parseFromFile()) return false;
					break;
				case RPT_depth_test:
					prop = new RenderProp_DepthTest();
					if(! static_cast<RenderProp_DepthTest*>(prop)->parseFromFile()) return false;
					break;
				case RPT_depth_mask:
					prop = new RenderProp_DepthMask();
					if(! static_cast<RenderProp_DepthMask*>(prop)->parseFromFile()) return false;
					break;
				case RPT_color_mask:
					prop = new RenderProp_ColorMask();
					if(! static_cast<RenderProp_ColorMask*>(prop)->parseFromFile()) return false;
					break;
				case RPT_depth_function:
					prop = new RenderProp_DepthFunc();
					if(! static_cast<RenderProp_DepthFunc*>(prop)->parseFromFile()) return false;
					break;
				case RPT_cull_face:
					prop = new RenderProp_CullFace();
					if(! static_cast<RenderProp_CullFace*>(prop)->parseFromFile()) return false;
					break;
				case RPT_front_face:
					prop = new RenderProp_FrontFace();
					if(! static_cast<RenderProp_FrontFace*>(prop)->parseFromFile()) return false;
					break;
				case RPT_line_width:
					prop = new RenderProp_LineWidth();
					if(! static_cast<RenderProp_LineWidth*>(prop)->parseFromFile()) return false;
					break;
				case RPT_poly_mode:
					prop = new RenderProp_PolyMode();
					if(! static_cast<RenderProp_PolyMode*>(prop)->parseFromFile()) return false;
					#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
						logDefaultWarning("Polygon Mode Render Properties are not supported in ES 2.0. This property will have no affect.");
						prop = 0;
					#endif
					break;
					// these cannot be generic render states
				case RPT_wrap_mode:
				case RPT_mag_filter:
				case RPT_min_filter:
					logDefaultError("non-generic type render property found.");
					return false;
				default: break;
				}
				if(pass) pass->addGenericProperty(prop);
			}
			readString();
		}
		// 5. <TextureBinding>+
		while(strcmp(str,"}")){
			if(!strcmp(str,"texture_binding")){
				if(!parseTextureBinding(pass)) return false;
			} else {
				logUnrecogTokenError(str,"pass texture-binding - final");
				return false;
			}
			readString();
		}

		return true;
	}

	void MaterialScriptParser::logGLConverstionError(const char* token){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": Cannot convert ["<<token<<"] to GL type.");
	}
	void MaterialScriptParser::logUnrecogTokenError(const char* token, const char* state){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": Unrecognized token ["<<token<<"] when parsing "<<state<<".");
	}
	void MaterialScriptParser::logWrongTokenError(const char* token, const char * expected){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": Mismatched token ["<<token<<"]. Expected = ["<<expected<<"].");
	}
	void MaterialScriptParser::logMultipleDefError(const char * deftype){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": Previous definition of " << deftype << " exists.");
	}
	void MaterialScriptParser::logUnsignedIntError(){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": no unsigned integer could be read");
	}
	void MaterialScriptParser::logUniformDataError(){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": uniform data invalid.");
	}
	void MaterialScriptParser::logDefaultError(const char* token){
		LOG4CPLUS_ERROR( Logger::getInstance("matScriptParser"), mScriptLineNo << ": " << token);
	}
	void MaterialScriptParser::logDefaultWarning(const char* token){
		LOG4CPLUS_WARN( Logger::getInstance("matScriptParser"), mScriptLineNo << ": " << token);
	}

}
