/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Material/PVRLoader.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#include "REng/GPU/GPUConfig.h"

#include <cstdio>
#include <string.h>
#include <iostream>
#include <fstream>

namespace REng{

	const uint PVRTEX_MIPMAP      = (1<<8);     // has mipmap levels
	const uint PVRTEX_TWIDDLE     = (1<<9);     // is twiddled
	const uint PVRTEX_BUMPMAP     = (1<<10);    // has normals encoded for a bump map
	const uint PVRTEX_TILING      = (1<<11);    // is bordered for tiled pvr
	const uint PVRTEX_CUBEMAP     = (1<<12);    // is a cubemap/skybox
	const uint PVRTEX_FALSEMIPCOL = (1<<13);    //
	const uint PVRTEX_VOLUME      = (1<<14);    // is a volumetric texture
	const uint PVRTEX_PIXELTYPE   = 0xff;       // pixel type is always in the last 16bits of the flags
	const uint PVRTEX_IDENTIFIER  = 0x21525650; // the pvr identifier is the characters 'P','V','R','!'

	const uint PVRTEX_V1_HEADER_SIZE = 44;      // old header size was 44 for identification purposes

	const uint PVRTC2_MIN_TEXWIDTH  = 16;
	const uint PVRTC2_MIN_TEXHEIGHT = 8;
	const uint PVRTC4_MIN_TEXSIZE   = 8; // width & height
	const uint ETC_MIN_TEXSIZE      = 4; // width & height

	const uint PVR_MAX_SURFACES = 16;

	const char* pvrLogStrIn = "PVRLoader | ";

	PVRLoader::PVRLoader():
		mMipmapCount(0),
		mTextureDataPtr(0),
		mTextureSurfaceMipMapDataPtr(0),
		mTextureSurfaceMipMapSize(0)
	{ ; }
	PVRLoader::~PVRLoader(){
		if(mTextureDataPtr) free(mTextureDataPtr);
		if(mTextureSurfaceMipMapDataPtr) free(mTextureSurfaceMipMapDataPtr);
		if(mTextureSurfaceMipMapSize) free(mTextureSurfaceMipMapSize);
	}

	bool PVRLoader::loadFromFile(const char* fileName){
		log4cplus::Logger logger = Logger::getInstance("mtrl");
		std::ifstream fileStream;
		fileStream.open(fileName, std::ios::in | std::ios::binary);
		char* mem = 0;
		if(!fileStream.is_open()) {
			LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"File ["<<fileName<<"] could not be opened.");
			return false;
		} else {
			fileStream.seekg(0, std::ios::end);
			int memSize = fileStream.tellg();
			fileStream.seekg(0, std::ios::beg);

			mem = (char*)malloc(memSize);
			fileStream.read(mem,memSize);
			fileStream.close();
		}
		LOG4CPLUS_INFO(logger, pvrLogStrIn<<"File ["<<fileName<<"] loading...");

		bool toRet = loadFromMem(mem);
		free(mem);
		return toRet;
	}

	bool PVRLoader::loadFromMem(const void* data){
		log4cplus::Logger logger = Logger::getInstance("mtrl");
		PVRHeader header; // copy data, we may modify numSurfaces field
		memcpy(&header,data,sizeof(PVRHeader));

		// Check PVR identifier
		if(PVRTEX_IDENTIFIER != header.pvrID) {
			LOG4CPLUS_WARN(logger, pvrLogStrIn<<"Invalid identifier. Expected:"<<PVRTEX_IDENTIFIER<<"(PVR!) Found:"<<header.pvrID);
			return false;
		}

		// Check header size & adjust header.numSurfaces if required
		if(header.headerSize != sizeof(PVRHeader)) {
			if(header.headerSize==PVRTEX_V1_HEADER_SIZE) { // Header V1
				LOG4CPLUS_WARN(logger, pvrLogStrIn<<"File format is old (V1). You can use PVRTexTool to update its header.");
				header.numSurfaces = (header.pixelFormatFlags&PVRTEX_CUBEMAP)?6:1;
			} else {
				LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Invalid PVR header size. Expected:"<<sizeof(PVRHeader)<<" Found:"<<header.headerSize);
				return false;
			}
		} else {
			if(header.numSurfaces<1) { // Header V2
				// encoded with old version of PVRTexTool before zero numsurfs bug found.
				LOG4CPLUS_WARN(logger, pvrLogStrIn<<"File format is old (V2). You can use PVRTexTool to update its header.");
				header.numSurfaces = (header.pixelFormatFlags&PVRTEX_CUBEMAP)?6:1;
			}
		}

		// Check TWIDDLE flag correctness
		if(((header.pixelFormatFlags&PVRTEX_TWIDDLE)  ==PVRTEX_TWIDDLE) &&
			((header.pixelFormatFlags&PVRTEX_PIXELTYPE)!=OGL_PVRTC2)     &&
			((header.pixelFormatFlags&PVRTEX_PIXELTYPE)!=OGL_PVRTC4)     )
		{
			// We need to load untwiddled textures -- hw will twiddle for us.
			LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Twiddled data is only valid for PVRTC formats. Untwittle the texture and try again...");
			return false;
		}

		// Check surface count
		if(header.numSurfaces>1){
			LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Currently the loader only supports 1 surface.");
			return false;
		}

		mWidth        = header.width;
		mHeight       = header.height;
		mMipmapCount  = header.mipmapCount;
		mBitsPerPixel = header.bitsPerPixel;
		mBitmaskRed   = header.bitmaskRed;
		mBitmaskGreen = header.bitmaskGreen;
		mBitmaskBlue  = header.bitmaskBlue;
		mBitmaskAlpha = header.bitmaskAlpha;
		mNumSurfaces  = header.numSurfaces;
		mTextureDataSize = header.textureDataSize;
		
		// check pixel format flags
		mMipmapCount =  (header.pixelFormatFlags&PVRTEX_MIPMAP)?mMipmapCount:0;
		const char* pvrLogStrPixelType = "PixelType | ";

		switch(header.pixelFormatFlags&PVRTEX_PIXELTYPE){
			case OGL_RGBA_4444:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:RGBA | DataType:UShort_4_4_4_4");
				mPixelDataType = PixelDataType_UShort_4_4_4_4;
				mPixelDataFormat = PixelDataFormat_RGBA;
				mGLFormat = ImageFormat_RGBA;
				break;
			case OGL_RGBA_5551:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:RGBA | DataType:UShort_5_5_5_1");
				mPixelDataType = PixelDataType_UShort_5_5_5_1;
				mPixelDataFormat = PixelDataFormat_RGBA;
				mGLFormat = ImageFormat_RGBA;
				break;
			case OGL_RGBA_8888:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:RGBA | DataType:UShort_8_8_8_8");
				mPixelDataType = PixelDataType_UByte;
				mPixelDataFormat = PixelDataFormat_RGBA;
				mGLFormat = ImageFormat_RGBA;
				break;
			case OGL_RGB_565:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:RGB | DataType:UShort_5_6_5");
				mPixelDataType = PixelDataType_UShort_5_6_5;
				mPixelDataFormat = PixelDataFormat_RGB;
				mGLFormat = ImageFormat_RGB;
				break;
			case OGL_RGB_555:
				LOG4CPLUS_ERROR(logger, pvrLogStrIn<<pvrLogStrPixelType<<"Unsupported pixel type : OGL_RGB_555");
				return false;
			case OGL_RGB_888:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:RGB | DataType:UByte_8_8_8");
				mPixelDataType = PixelDataType_UByte;
				mPixelDataFormat = PixelDataFormat_RGB;
				mGLFormat = ImageFormat_RGB;
				break;
			case OGL_I_8:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:L | DataType:UByte");
				mPixelDataType = PixelDataType_UByte;
				mPixelDataFormat = PixelDataFormat_L;
				mGLFormat = ImageFormat_L;
				break;
			case OGL_AI_88:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:LA | DataType:UByte");
				mPixelDataType = PixelDataType_UByte;
				mPixelDataFormat = PixelDataFormat_LA;
				mGLFormat = ImageFormat_LA;
				break;
			case OGL_PVRTC2:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:PVRTC2");
				mGLFormat = (header.bitmaskAlpha==0)?ImageFormat_Compr_RGB_PVRTC_2:ImageFormat_Compr_RGBA_PVRTC_2;
				if(!GPUConfig::getSingleton().isCompressedImageFormatSupported(mGLFormat)) {
					LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Unsupported pixel type : "<<((header.bitmaskAlpha==0)?"RGB_PVRTC2":"RGBA_PVRTC2")<<
						". Converting data to RGBA88 instead... NOT SUPPORTED. ERROR!");
					mPixelDataType = PixelDataType_UByte;
					mPixelDataFormat = PixelDataFormat_RGBA;
					mGLFormat = ImageFormat_RGBA;
					// TODO: Uncompress PVRTC
					return false;
				}
				break;
			case OGL_PVRTC4:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:PVRTC4");
				mGLFormat = (header.bitmaskAlpha==0)?ImageFormat_Compr_RGB_PVRTC_4:ImageFormat_Compr_RGBA_PVRTC_4;
				if(!GPUConfig::getSingleton().isCompressedImageFormatSupported(mGLFormat)) {
					LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Unsupported pixel type : "<<((header.bitmaskAlpha==0)?"RGB_PVRTC4":"RGBA_PVRTC4")<<
						". Converting data to RGBA88 instead... NOT SUPPORTED. ERROR!");
					mPixelDataType = PixelDataType_UByte;
					mPixelDataFormat = PixelDataFormat_RGBA;
					mGLFormat = ImageFormat_RGBA;
					// TODO: Uncompress PVRTC
					return false;
				}
				break;
			case ETC_RGB_4BPP:
				LOG4CPLUS_INFO(logger, pvrLogStrIn<<pvrLogStrPixelType<<"InternalFormat:ETC");
				if(GPUConfig::getSingleton().isCompressedImageFormatSupported(ImageFormat_Compr_RGB_ETC1)){
					mGLFormat = ImageFormat_Compr_RGB_ETC1;
				} else {
					LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Unsupported pixel type : ETC. Converting data to RGBA88 instead...");
					mPixelDataType = PixelDataType_UByte;
					mPixelDataFormat = PixelDataFormat_RGBA;
					mGLFormat = ImageFormat_RGBA;
					// TODO: Uncompress ETC
					return false;
				}
				break;

			default:
				LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Unsupported pixel type : Other");
				return false;
		}

		// Copy all texture data
		size_t totalDataSize = mTextureDataSize*mNumSurfaces;
		mTextureDataPtr = malloc(totalDataSize);
		memset(mTextureDataPtr,0,totalDataSize);
		memcpy(mTextureDataPtr,(char*)data+header.headerSize,totalDataSize);

		// Set up pointers to surfaces & mipmap layers
		mTextureSurfaceMipMapDataPtr  = (void**)malloc(mNumSurfaces*(mMipmapCount+1)*sizeof(void*));
		mTextureSurfaceMipMapSize     = (uint* )malloc((mMipmapCount+1)*sizeof(uint ));

		uint j=0;
		// TODO: I am doing some unnecessary loops here, may optimize this part later ...
		for(uint surfaceNo=0; surfaceNo<mNumSurfaces ; ++surfaceNo){
			char* textureDataPtr = (char*)mTextureDataPtr + mTextureDataSize*surfaceNo;
			uint nSizeX(mWidth), nSizeY(mHeight);
			for(uint mipmapLevel=0 ; mipmapLevel<=mMipmapCount ; ++mipmapLevel, ++j){
				mTextureSurfaceMipMapDataPtr[j] = textureDataPtr;

				uint textureDataSize=0;
				if(isCompressedFormat(mGLFormat)){
					if(mGLFormat==ImageFormat_Compr_RGB_PVRTC_2||mGLFormat==ImageFormat_Compr_RGBA_PVRTC_2){
						textureDataSize = ( Math::max(nSizeX, PVRTC2_MIN_TEXWIDTH) * Math::max(nSizeY, PVRTC2_MIN_TEXHEIGHT)*mBitsPerPixel+7) / 8;
					} else if(mGLFormat==ImageFormat_Compr_RGB_PVRTC_4||mGLFormat==ImageFormat_Compr_RGBA_PVRTC_4){
						textureDataSize = ( Math::max(nSizeX, PVRTC4_MIN_TEXSIZE) * Math::max(nSizeY, PVRTC4_MIN_TEXSIZE)*mBitsPerPixel+7) / 8;
					} else if(mGLFormat==ImageFormat_Compr_RGB_ETC1){
						textureDataSize = ( Math::max(nSizeX, ETC_MIN_TEXSIZE) * Math::max(nSizeY, ETC_MIN_TEXSIZE)*mBitsPerPixel+7) / 8;
					} else {
						LOG4CPLUS_ERROR(logger, pvrLogStrIn<<"Cannot compute size of compressed texture data.");
					}
				} else {
					textureDataSize = (nSizeX*nSizeY*mBitsPerPixel)/8;
				}
				mTextureSurfaceMipMapSize[mipmapLevel] = textureDataSize;
				textureDataPtr += textureDataSize;

				nSizeX=Math::max(nSizeX/2,uint(1));
				nSizeY=Math::max(nSizeY/2,uint(1));
			}
		}
		/*
		switch(header.pixelFormatFlags&PVRTEX_PIXELTYPE){
			case OGL_RGBA_8888: 
				for(uint i=0; i<10; i++){
					LOG4CPLUS_INFO(logger," "<<uint(((uchar*)mTextureDataPtr)[i]));
				}
				break;
			default: break;
		}
	*/
		return true;
	}

}
