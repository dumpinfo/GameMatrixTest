/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Material/MaterialProgram.h"

#include "REng/Material/MaterialManager.h"

#include <log4cplus/logger.h>
#include <assert.h>
#include <fstream>

using namespace log4cplus;
using namespace std;

namespace REng{

	MaterialProgram::MaterialProgram(const string& name) 
	: GPUProgram(),
		mName(name),
		mIsResolved(false)
	{
	}

	MaterialProgram::~MaterialProgram() { ; }

	const std::string& MaterialProgram::getName() const{
		return mName;
	}

	void MaterialProgram::setShaderName1(const std::string& name){
		mVertMatShaderName = name;
		mIsLinked = false;
		mIsResolved = false;
	}
	void MaterialProgram::setShaderName2(const std::string& name){
		mFragMatShaderName = name;
		mIsLinked = false;
		mIsResolved = false;
	}
	void MaterialProgram::setShaderPtr1(MaterialShaderPtr shader){
		mVertMatShaderName = shader->getName();
		mVertMatShader = shader;
		mIsLinked = false;
		mIsResolved = false;
	}
	void MaterialProgram::setShaderPtr2(MaterialShaderPtr shader){
		mFragMatShaderName = shader->getName();
		mFragMatShader = shader;
		mIsLinked = false;
		mIsResolved = false;
	}
	bool MaterialProgram::isResolved(){
		return mIsResolved;
	}

	bool MaterialProgram::resolveAttachAndLinkShaders(){
		Logger logger = Logger::getInstance("mtrl");
		// TODO: detach all attached shaders from the GPU Program
		if(mIsResolved) return true;

		// 1. check if shader names are set
		if( mVertMatShaderName == std::string("")) {
			LOG4CPLUS_ERROR(logger, "MaterialProgram["<<mName<<"] | Shader Resolve Fail | Vertex material shader name not set.");
			return false;
		}
		if(mFragMatShaderName == std::string("")) {
			LOG4CPLUS_ERROR(logger, "MaterialProgram["<<mName<<"] | Shader Resolve Fail | Fragment material shader name not set");
			return false;
		}

		// 2. check is material shaders are defined with the given names
		mVertMatShader = MaterialManager::getSingleton().getMaterialShader(mVertMatShaderName.c_str());
		mFragMatShader = MaterialManager::getSingleton().getMaterialShader(mFragMatShaderName.c_str());
		if(mVertMatShader == MaterialShaderPtr() || mFragMatShader == MaterialShaderPtr()){
			if(mVertMatShader==MaterialShaderPtr()) 
				LOG4CPLUS_ERROR(logger, "MaterialProgram["<<mName<<"] | Shader Resolve Fail | Material shader name ["<<mVertMatShaderName.c_str()<<"] not resolved.");
			if(mFragMatShader==MaterialShaderPtr()) 
				LOG4CPLUS_ERROR(logger, "MaterialProgram["<<mName<<"] | Shader Resolve Fail | Material shader name ["<<mFragMatShaderName.c_str()<<"] not resolved.");
			mFragMatShader = MaterialShaderPtr();
			mVertMatShader = MaterialShaderPtr();
			return false;
		}

		// temp fix: make sure the names reference correct type of shader
		if(mVertMatShader->getType()!=ShaderType_Vertex){
			MaterialShaderPtr _swap=mVertMatShader;
			mVertMatShader=mFragMatShader;
			mFragMatShader=_swap;
		}

		// 3. Compile shaders (they are not re-complied if already compiled)
		if(!mVertMatShader->compile()){
			return false;
		}
		if(!mFragMatShader->compile()){
			return false;
		}
		// 4. Create and link GL program associated with this render pass
		attachShader(*mFragMatShader);
		attachShader(*mVertMatShader);
		if(!link()) {
			LOG4CPLUS_ERROR(logger, "MaterialProgram["<<mName<<"] | Linkage Fail | Shaders ["<<mVertMatShaderName.c_str()<<","<<mFragMatShaderName.c_str()<<"]");
			return false;
		} else {
			LOG4CPLUS_INFO(logger, "MaterialProgram["<<mName<<"] | Linkage Success | Shaders ["<<mVertMatShaderName.c_str()<<","<<mFragMatShaderName.c_str()<<"]");
		}

		CHECKGLERROR_TERM();
		updateUniformPropsFromProgram();
		CHECKGLERROR_TERM();

		mIsResolved = true;
		return true;
	}

	void MaterialProgram::updateUniformPropsFromProgram(){

	}

	void MaterialProgram::addUniformDefault(RenderProp_Uniform* prop){
		assert(prop);
		mUniformDefaults.push_back(prop);
	}
	void MaterialProgram::clearUniformDefaults(){
		mUniformDefaults.clear();
	}
	void MaterialProgram::removeUniformDefault(size_t index){
		assert(index < mUniformDefaults.size());
		mUniformDefaults.erase(mUniformDefaults.begin()+index);
	}
	size_t MaterialProgram::getUniformDefaultsCount() const{
		return mUniformDefaults.size();
	}
	const UniformPropertyList& MaterialProgram::getUniformDefaults() const{
		return mUniformDefaults;
	}
	RenderProp_Uniform* MaterialProgram::getUniformDefault(size_t index){
		assert(index < mUniformDefaults.size());
		return mUniformDefaults[index];
	}
	RenderProp_Uniform* MaterialProgram::getUniformDefault(const string& uniformName){
		size_t uniformCount = mUniformDefaults.size();
		for(size_t i=0 ; i<uniformCount ; i++){
			if ( mUniformDefaults[i]->getName() == uniformName)
				return mUniformDefaults[i];
		}
		return 0;
	}

}

