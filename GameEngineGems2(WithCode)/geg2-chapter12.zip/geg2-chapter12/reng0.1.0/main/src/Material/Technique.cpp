/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include <boost/foreach.hpp>

#include "REng/Material/Technique.h"

#include "REng/Material/RenderPass.h"

namespace REng{

	Technique::Technique() { mOwnerMaterial = 0; }

	Technique::Technique(Material *ownerMaterial) {
		assert(ownerMaterial && "Owner Material cannot be 0");
		mOwnerMaterial = ownerMaterial;
	}

	Technique::~Technique(void) {
		clearPasses();
	}

	const Material* Technique::getOwnerMaterial() const { 
		return mOwnerMaterial; 
	}

	void Technique::clone(Technique& _to) const{
		_to.clearPasses();
		BOOST_FOREACH(RenderPass* pass, mRenderPasses){
			RenderPass* passnew(_to.createRenderPass());
			pass->clone(*passnew);
		}
	}

	bool Technique::isValid() const{
		size_t lim = getRenderPassCount();
		// check that at least one render pass exists
		if(lim == 0) return false;
		// check that all render passes are valid
		BOOST_FOREACH(RenderPass* pass, mRenderPasses){
			if( pass->isLoaded() == false) return false;
		}
		return true;
	}

	RenderPass* Technique::createRenderPass(void){
		// if number of render passes exceed unsigned char limit (255), return 0;
		if( mRenderPasses.size() >= 255 ){
			return 0;
		}
		RenderPass* newPass = new RenderPass(this, static_cast<unsigned char>(mRenderPasses.size()));
		mRenderPasses.push_back(newPass);
		return newPass;
	}

	RenderPass* Technique::getRenderPass(unsigned char index){
		assert(index < mRenderPasses.size() && "Index out of bounds");
		return mRenderPasses[index];
	}

	unsigned char Technique::getRenderPassCount(void) const{
		return (unsigned char) mRenderPasses.size();
	}

	void Technique::removeRenderPass(uchar index){
		assert(index < mRenderPasses.size() && "Index out of bounds");
		RenderPassList::iterator i = mRenderPasses.begin() + index;
		delete (*i);
		i = mRenderPasses.erase(i);
		// Adjust remaining pass'es index
		for (; i != mRenderPasses.end(); ++i, ++index) {
			(*i)->setIndex(index);
		}
	}

	void Technique::clearPasses(void){
		BOOST_FOREACH(RenderPass* pass, mRenderPasses) delete pass;
		mRenderPasses.clear();
	}

	bool Technique::movePass(const ushort sourceIndex, const ushort destinationIndex){

		bool moveSuccessful = false;

		// don't move the pass if source == destination
		if (sourceIndex == destinationIndex) return true;

		// check if both source and destination indices are valid
		if( sourceIndex >= mRenderPasses.size()) return false;
		if( destinationIndex >= mRenderPasses.size()) return false;

		RenderPassList::iterator i = mRenderPasses.begin() + sourceIndex;
		//Passes::iterator DestinationIterator = mPasses.begin() + destinationIndex;

		RenderPass* pass = (*i);
		mRenderPasses.erase(i);

		i = mRenderPasses.begin() + destinationIndex;

		// compensate for source erase if destination is greater than source
		if (destinationIndex > sourceIndex) --i;

		mRenderPasses.insert(i, pass);

		// Adjust passes index
		ushort beginIndex, endIndex;

		if(destinationIndex > sourceIndex) {
			beginIndex = sourceIndex;
			endIndex = destinationIndex;
		} else {
			beginIndex = destinationIndex;
			endIndex = sourceIndex;
		}

		for(ushort index = beginIndex; index <= endIndex; ++index) {
			mRenderPasses[index]->setIndex(index);
		}

		moveSuccessful = true;

		return moveSuccessful;
	}

	void Technique::preparePassState(size_t passIndex){
		assert(passIndex < mRenderPasses.size());
		mRenderPasses[passIndex]->prepareState();
	}

	void Technique::clearPassState(size_t passIndex){
		assert(passIndex < mRenderPasses.size());
		mRenderPasses[passIndex]->clearState();
	}

	bool Technique::load(){
		CHECKGLERROR_TERM();
		BOOST_FOREACH(RenderPass* pass, mRenderPasses){
			if( pass->load() == false){
				CHECKGLERROR_TERM();
				// TODO: unload previously loaded render programs of this technique?
				return false;
			}
		}
		CHECKGLERROR_TERM();
		return true;
	}

}


