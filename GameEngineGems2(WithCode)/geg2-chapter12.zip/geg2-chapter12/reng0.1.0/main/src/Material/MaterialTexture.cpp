/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Material/MaterialTexture.h"

// logging support
#include <log4cplus/logger.h>
using namespace log4cplus;

// for loading images from external files
#include "REng/Material/PVRLoader.h"
#if IMLOAD_LIB == IMLOAD_DEVIL
	#include <il/il.h>
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
	#include <FreeImage.h>
#endif

namespace REng{

	// follows OpenGL enumeration order
	const CubeMapFace MaterialTexture::cubeMapFaceOrder[] = {
		CubeMapFace_Positive_X, CubeMapFace_Negative_X,
		CubeMapFace_Positive_Y, CubeMapFace_Negative_Y,
		CubeMapFace_Positive_Z, CubeMapFace_Negative_Z,
	};

	MaterialTexture::MaterialTexture(const std::string& name, TextureType type) 
	:	GPUTexture(type),
	mName(name), 
	mRequestLoadFromFile(false)
	{
	}

	MaterialTexture::~MaterialTexture(){
	}

	const std::string& MaterialTexture::getName() const{
		return mName;
	}

	void MaterialTexture::setSourceFileName(const std::string& fileName, unsigned char index){
		Logger logger = Logger::getInstance("mtrl");
		if(mType == TextureType_Cube){
			if(index > 6) {
				LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | setSourceFileName | index ["<<char(index)<<"] is invalid. Expected 0<=index<6");
				return;
			}
			mSourceFileNames[index] = fileName;
			mRequestLoadFromFile = true;
			return;
		}
		if(index != 0){
			LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | setSourceFileName | index ["<<char(index)<<"] is invalid. Expected 0=index");
			return;
		} else {
			mSourceFileNames[0] = fileName;
			mRequestLoadFromFile = true;
			return;
		}
	}

	const std::string& MaterialTexture::getSourceFileName(unsigned char index){
		if(mType == TextureType_Cube){
			if(index > 6) {
				return mSourceFileNames[0];
			}
			return mSourceFileNames[index];
		}
		return mSourceFileNames[0];
	}

#if IMLOAD_LIB == IMLOAD_DEVIL
	bool getImgDataParam(int ilID, uint &imWidth, uint &imHeight, 
										PixelDataFormat &imFormat,PixelDataType &imType){
		Logger logger = Logger::getInstance("mtrl");
		ilBindImage(ilID);

		imWidth = ilGetInteger(IL_IMAGE_WIDTH);
		imHeight = ilGetInteger(IL_IMAGE_HEIGHT);

		char compCount = 1;
		ILint imageFormat = ilGetInteger(IL_IMAGE_FORMAT);
		switch(imageFormat){
			case IL_ALPHA: 
				imFormat = PixelDataFormat_A; compCount=1; break;
			case IL_RGB:   
				imFormat = PixelDataFormat_RGB;   compCount=3; break;
			case IL_BGR:  
				imFormat = PixelDataFormat_BGR;   compCount=3; break;
			case IL_RGBA:  
				imFormat = PixelDataFormat_RGBA;  compCount=4; break;
			case IL_BGRA:   
				imFormat = PixelDataFormat_BGRA;  compCount=4; break;
			case IL_LUMINANCE:   
				imFormat = PixelDataFormat_L;   compCount=2; break;
			case IL_LUMINANCE_ALPHA:   
				imFormat = PixelDataFormat_LA;   compCount=1; break;
			case IL_COLOR_INDEX: // IL_COLOUR_INDEX
				LOG4CPLUS_WARN(logger, "MaterialTexture | DEVIL | Invalid image format | Color index type is deprecated in current OpenGL funtion.");
				return false;
			default:
				assert(0);
				// TODO : error
				return false;
		}

		ILint imageBBP = ilGetInteger(IL_IMAGE_BPP);
		switch(imageBBP / compCount){
			case 1: imType = PixelDataType_UByte;  break;
			case 2: imType = PixelDataType_UShort; break;
			case 4: imType = PixelDataType_UInt;   break;
			default: break;
		}
		return true;
	}
#endif

	#if IMLOAD_LIB == IMLOAD_FREEIMAGE
	bool getImgDataParam(FIBITMAP* img, uint &imWidth, uint &imHeight, 
										PixelDataFormat &imFormat,PixelDataType &imType){
		Logger logger = Logger::getInstance("mtrl");

		imWidth = FreeImage_GetWidth(img);
		imHeight = FreeImage_GetHeight(img);

		char compCount = 1;
		FREE_IMAGE_COLOR_TYPE imageFormat = FreeImage_GetColorType(img);
		switch(imageFormat){
			case FIC_RGB: // RGB color model
				imFormat = PixelDataFormat_RGB;  compCount=3; break;
			case FIC_RGBALPHA: // RGB color model with alpha channel
				imFormat = PixelDataFormat_RGBA;   compCount=4; break;
			case FIC_CMYK: // CMYK color model
				LOG4CPLUS_WARN(logger, "MaterialTexture | FREEIMAGE | Invalid format: CMYK space is not supported.");
				return false;
			case FIC_PALETTE: // color map indexed
				LOG4CPLUS_WARN(logger, "MaterialTexture | FREEIMAGE | Invalid format: Color index type is deprecated in current OpenGL funtion.");
				return false;
			case FIC_MINISWHITE: // monochrome bitmap, min value is white
			case FIC_MINISBLACK: // monochrome bitmap, min value is black
			default:
				assert(0);
				// TODO : error
				return false;
		}

		uint imageBBP = FreeImage_GetBPP(img);
		switch(imageBBP / compCount){
			case 8: imType = PixelDataType_UByte;  break;
			case 16: imType = PixelDataType_UShort; break;
			case 32: imType = PixelDataType_UInt;   break;
			default: break;
		}
		return true;
	}
	#endif

	#if IMLOAD_LIB == IMLOAD_DEVIL
	void _deleteImages(ILuint *extImg){ 
		ilDeleteImages(6, extImg);
	}
	void* _getImageData(ILuint extImg) {
		ilBindImage(extImg);
		return ilGetData();
	}
	#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
	void _deleteImages(FIBITMAP* extImg[]){ 
		for(int i=0 ; i<6 ; i++) FreeImage_Unload(extImg[i]);
	}
	void* _getImageData(FIBITMAP* extImg) {
		return FreeImage_GetBits(extImg);
	}
	#endif

	bool MaterialTexture::loadFromFilesToResource(){
		if(!isSupported())  return false;
		if(!mRequestLoadFromFile) return true;

		Logger logger = Logger::getInstance("mtrl");
		char imgCount = (mType==TextureType_Cube) ? 6 : 1;
		for(uchar i=0 ; i<imgCount; ++i){
			if(mSourceFileNames[i] == ""){
				LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | loadFromFileSources | File name empty | index:"<<i);
				return false;
			}
		}

		// Reserve image loaders
		PVRLoader extImgPvr[6];
#if IMLOAD_LIB == IMLOAD_DEVIL
		ILuint extImg[6]; ilGenImages(6, extImg);
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
		FIBITMAP *extImg[6] = {0,0,0,0,0,0};
#endif

		bool loadingPVR=false;
		for(uchar i=0; i<imgCount; ++i){
			std::string fileNameStr(mSourceFileNames[i].c_str());
			size_t dotPos = fileNameStr.find_last_of('.');
			if(dotPos!=std::string::npos){
				if(fileNameStr.substr(dotPos)==std::string(".pvr")) { loadingPVR = true; break; }
			}
		}

		for(uchar i=0; i<imgCount; ++i){
			const char* fileName = mSourceFileNames[i].c_str();
			if(loadingPVR){
				if(extImgPvr->loadFromFile(fileName)==false){
					LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | Load from file failed :"<<fileName<<" | Codec:PVRLoader");
					return false;
				} else {
					LOG4CPLUS_INFO(logger,"MaterialTexture["<<mName<<"] | Load from file success :"<<fileName<<" | Codec:PVRLoader");
				}
			} else {
			#if IMLOAD_LIB == IMLOAD_DEVIL
			ilBindImage(extImg[i]);
			if(ilLoadImage(fileName)==IL_FALSE){
				LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | Load from file failed :"<<fileName<<" | Codec:Devil");
				_deleteImages(extImg);
				return false;
			} else {
				LOG4CPLUS_INFO(logger,"MaterialTexture["<<mName<<"] | Load from file success :"<<fileName<<" | Codec:Devil");
			}
			#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
			FREE_IMAGE_FORMAT fif = FreeImage_GetFileType(fileName, 0);
			if(fif==FIF_UNKNOWN) fif = FreeImage_GetFIFFromFilename(fileName);
			if(fif==FIF_UNKNOWN) {
				LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] FreeImage : Unknown texture format:" << fileName);
				_deleteImages(extImg);
				return false;
			}
			if(FreeImage_FIFSupportsReading(fif)) extImg[i] = FreeImage_Load(fif, fileName);
			if(!extImg[i]) {
				LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] Cannot load texture from file:" << fileName);
				_deleteImages(extImg);
				return false;
			} else {
				LOG4CPLUS_INFO(logger,"MaterialTexture["<<mName<<"] Texture is loaded from file:" << fileName);
			}
			#endif
			}
		}

		// check cube-map completeness
		int checkDim = 0;
		if(mType == TextureType_Cube){
			for(uchar i=0; i<6; i++){
				int imWidth, imHeight;
				if(loadingPVR){
					imWidth  = extImgPvr->getWidth();
					imHeight = extImgPvr->getHeight();
				} else {
					#if IMLOAD_LIB == IMLOAD_DEVIL
					ilBindImage(extImg[i]);
					imWidth  = ilGetInteger(IL_IMAGE_WIDTH);
					imHeight = ilGetInteger(IL_IMAGE_HEIGHT);
					#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
					imWidth  = FreeImage_GetWidth(extImg[i]);
					imHeight = FreeImage_GetHeight(extImg[i]);
					#endif
				}
				if(imWidth!=imHeight){
					LOG4CPLUS_WARN(logger,"MaterialTexture["<<mName<<"] | Cubemap image ["<<i<<"] is not a square image. [W:"<<imWidth<<" H:"<<imHeight<<"]");
					_deleteImages(extImg);
					return false;
				}
				if(checkDim==0) checkDim = imWidth; // first pass, set expected value
				if(checkDim != imWidth){
					LOG4CPLUS_INFO(logger,"MaterialTexture["<<mName<<"] Cubemap images do not have identical dim's. ["<<checkDim<<"vs."<<imWidth<<"]");
					_deleteImages(extImg);
					return false;
				}
			}
		}
		if(loadingPVR) setInternalFormat(extImgPvr[0].getFormat());

		// handle some of the platform related problem
		if(!isCompressed()){
			// 1. convert BGR formats into RGB
			for(uchar i=0; i<imgCount; i++){
				PixelDataFormat dataFormat;
				PixelDataType dataType;
				uint width, height;
				if(!loadingPVR){
					if(getImgDataParam(extImg[0],width, height, dataFormat, dataType) == false){
						_deleteImages(extImg);
						return false;
					}
					#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES && IMLOAD_LIB == IMLOAD_DEVIL
					if(dataFormat == PixelDataFormat_BGR){
						ilConvertImage(PixelDataFormat_RGB,dataType);
						LOG4CPLUS_INFO(logger, "MaterialTexture["<<mName<<"] Image["<<(int)i<<"] format converted. BGR->RGB.");
					} else if(dataFormat == PixelDataFormat_BGRA){
						ilConvertImage(PixelDataFormat_RGBA,dataType);
						LOG4CPLUS_INFO(logger, "MaterialTexture["<<mName<<"] Image["<<(int)i<<"] format converted. BGRA->RGBA.");
					}
					#endif
				} else {
					// TODO
				}
			}
		}

		bindResource();
		updateSamplerState();

		// TODO: a single pvr file can contain multiple layers for all sides of the cube.

		uint width, height;
		const void* texData;
		if(!isCompressed()) {
			//////////////////////////////////////////////////////////////////////////
			// LOADING UNCOMPRESSED STREAMS
			PixelDataFormat dataFormat;
			PixelDataType dataType;
			// upload image data to OpenGL
			for(uchar i=0; i<imgCount; i++){
				uint mipmaplevels=0;
				if(loadingPVR) mipmaplevels = extImgPvr[i].getMipmapCount();
				for(uint curMipMap=0; curMipMap<=mipmaplevels; ++curMipMap){
					bool fail = false;
					if(!loadingPVR){
						getImgDataParam(extImg[i],width, height, dataFormat, dataType);
						texData = _getImageData(extImg[i]);
					} else {
						extImgPvr[i].getTextureSize(width,height,curMipMap);
						texData    = extImgPvr[i].getTextureData(0,curMipMap);
						dataType   = extImgPvr[i].getPixelDataType();
						dataFormat = extImgPvr[i].getPixelDataFormat();
					}
					switch(mType){
					case TextureType_1D:
						if(!loadFromMemToResource(width,height,dataType,dataFormat,texData,curMipMap)) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:1D");
							fail = true;
						}
						break;
					case TextureType_2D:
						if(!loadFromMemToResource(width,height,dataType,dataFormat,texData,curMipMap)) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:2D");
							fail = true;
						}
						break;
					case TextureType_3D:
						LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] 3D Textures are not currently supported.");
						break;
					case TextureType_Cube:
						if(!loadFromMemToResource(width,height,dataType,dataFormat,texData,curMipMap,cubeMapFaceOrder[i])) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:Cubemap | FaceOrder: " << i);
							fail = true;
						}
						break;
					}
					if(fail){
						_deleteImages(extImg);
						return false;
					}
				}
			}
		} else {
			//////////////////////////////////////////////////////////////////////////
			// LOADING COMPRESSED STREAMS
			assert(loadingPVR);
			uint texDataSize;
			for(uchar i=0; i<imgCount; i++){
				uint mipmaplevels=0;
				if(loadingPVR) mipmaplevels = extImgPvr[i].getMipmapCount();
				for(uint curMipMap=0; curMipMap<=mipmaplevels; ++curMipMap){
					bool fail = false;
					extImgPvr[i].getTextureSize(width,height,curMipMap);
					texData = extImgPvr[i].getTextureData(0,curMipMap); 
					texDataSize = extImgPvr[i].getTextureDataSize(curMipMap);
					switch(mType){
					case TextureType_1D:
						if(!loadComprFromMemToResource(width,height,texDataSize,texData,curMipMap)) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:1D");
							fail = true;
						}
						break;
					case TextureType_2D:
						if(!loadComprFromMemToResource(width,height,texDataSize,texData,curMipMap)) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:2D");
							fail = true;
						}
						break;
					case TextureType_3D:
						LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] 3D Textures are not currently supported.");
						break;
					case TextureType_Cube:
						if(!loadComprFromMemToResource(width,height,texDataSize,texData,curMipMap,cubeMapFaceOrder[i])) {
							LOG4CPLUS_WARN(logger, "MaterialTexture["<<mName<<"] | OpenGL upload failed | Type:Cubemap | FaceOrder: " << i);
							fail = true;
						}
						break;
					}
					if(fail){
						_deleteImages(extImg);
						return false;
					}
				}
			}

		}

		// For cube-maps, you need to generate mipmaps after your upload all faces
		if(mType==TextureType_Cube && mGenMipmaps){
			generateMipmaps();
		}

		// release image data sources
		_deleteImages(extImg);

		mRequestLoadFromFile = false;

		return true;
	}

}
