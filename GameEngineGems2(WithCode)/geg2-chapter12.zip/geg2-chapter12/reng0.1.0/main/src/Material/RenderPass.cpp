/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include <boost/foreach.hpp>

#include "REng/Material/RenderPass.h"

// binds to other material stuff...
#include "REng/Material/MaterialManager.h"
// updates uniform data from RenderSystem
#include "REng/RenderSystem.h"

#include "REng/LightingManager.h"

#include "assert.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{
	RenderPass::RenderPass(Technique* ownerTechnique, uchar index)
		:mOwnerTechnique(ownerTechnique)
		,mIndex(index)
		,mLoaded(false)
		,mProgram(MaterialProgramPtr())
		,mUsesLights(false)
	{ ; }

	RenderPass::~RenderPass(void) {
		BOOST_FOREACH(RenderProp_Generic* prop, mRenderProperties ) delete prop;
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) delete uni;
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults   ) delete uni;
	}

	Technique& RenderPass::getOwnerTechnique(){
		return *mOwnerTechnique;
	}
	void RenderPass::clone(RenderPass& _to) const{
		_to.mLoaded  = false;
		_to.mProgram = this->mProgram;
		_to.mProgramName = this->mProgramName;
		// generic render properties
		_to.clearGenericProperties();
		BOOST_FOREACH(RenderProp_Generic* prop, mRenderProperties) {
			_to.addGenericProperty((RenderProp_Generic*)prop->clone());;
		}
		// uniform render properties...
		_to.clearUniformDefaults();
		_to.clearUniformNonDefaults();
		_to.clearUniformDefaultRollBacks();
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults) {
			_to.addUniformDefault((RenderProp_Uniform*)uni->clone());;
		}
		// the render pass will be loaded later
//		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) {
//			_to.addUniformDefault((RenderProp_Uniform*)uni->clone());;
//		}
//		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaultRollBacks) {
//			_to.addUniformDefault((RenderProp_Uniform*)uni->clone());;
//		}
//		_to.bindUniformsToProgram();
		// texture bindings
		_to.mTextureBindings.clear();
		BOOST_FOREACH(const STexturePassBinding& binding, mTextureBindings) {
			STexturePassBinding newBinding;
			newBinding.texUnitID   = binding.texUnitID;
			newBinding.textureName = binding.textureName;
			newBinding.materialTexture = binding.materialTexture;
			newBinding.sampler = binding.sampler;
			newBinding.samplerName = binding.samplerName;
			_to.mTextureBindings.push_back(newBinding);
		}
	}

	bool RenderPass::isLoaded(){
		return mLoaded;
	}
	uchar RenderPass::getIndex() const{
		return mIndex;
	}
	void RenderPass::setIndex(uchar index){
		mIndex = index;
	}

	void RenderPass::setProgram(MaterialProgramPtr prog){
		mProgram = prog;
		mProgramName.clear();
	}
	void RenderPass::setProgramName(const std::string& progName){
		mProgram = MaterialProgramPtr();
		mProgramName = progName;
	}
	MaterialProgramPtr RenderPass::getProgram(){
		return mProgram;
	}


	//////////////////////////////////////////////////////////////////////////
	// TEXTURE BINDINGS
	//////////////////////////////////////////////////////////////////////////
	bool RenderPass::setTextureBinding(uchar texUnitID, MaterialTexturePtr matTexturePtr){
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			if(binding.texUnitID == texUnitID){
				// update old definition
				binding.textureName = matTexturePtr->getName();
				binding.materialTexture = matTexturePtr;
				return true;
			}
		}
		STexturePassBinding newBinding;
		newBinding.texUnitID = texUnitID;
		newBinding.textureName = matTexturePtr->getName();
		newBinding.materialTexture = matTexturePtr;
		newBinding.sampler.reset();
		mTextureBindings.push_back(newBinding);
		return true;
	}
	bool RenderPass::setTextureBinding(uchar texUnitID, const std::string& matTextureName){
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			if(binding.texUnitID == texUnitID){
				// update old definition
				binding.textureName = matTextureName;
				binding.materialTexture = MaterialTexturePtr();
				return true;
			}
		}
		STexturePassBinding newBinding;
		newBinding.texUnitID = texUnitID;
		newBinding.textureName = matTextureName;
		newBinding.materialTexture = MaterialTexturePtr();
		newBinding.sampler.reset();
		mTextureBindings.push_back(newBinding);
		return true;
	}
	bool RenderPass::setSamplerState(uchar texUnitID, GPUSamplerPtr sampler){
		assert(sampler.get());
		GPUSamplerPtr _sampler = sampler;
		// if sampler resources are supported, make sure that we are pointing to a GPUSamplerResource
		if(GPUSamplerResource::isSupported()){
			if(sampler->getType()==GPUSamplerType_Tex){
				// convert texture type sampler to resource sampler
				_sampler.reset(new GPUSamplerResource(0));
				_sampler->copyState(*(sampler.get()));
			}
		}
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			if(binding.texUnitID==texUnitID){
				binding.sampler=_sampler; return true;
			}
		}
		STexturePassBinding newBinding;
		newBinding.texUnitID = texUnitID;
		newBinding.textureName = "";
		newBinding.materialTexture = MaterialTexturePtr();
		newBinding.sampler = _sampler;
		newBinding.samplerName = "";
		mTextureBindings.push_back(newBinding);
		return true;
	}
	bool RenderPass::setSamplerState(uchar texUnitID, const std::string& samplerName){
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			if(binding.texUnitID==texUnitID){
				binding.samplerName=samplerName; return true;
			}
		}
		STexturePassBinding newBinding;
		newBinding.texUnitID = texUnitID;
		newBinding.textureName = "";
		newBinding.materialTexture = MaterialTexturePtr();
		newBinding.sampler.reset();
		newBinding.samplerName = samplerName;
		mTextureBindings.push_back(newBinding);
		return true;
	}

	uchar RenderPass::loadTextureBindings(){
		Logger logger = Logger::getInstance("mtrl");
		uchar unbounded = 0;
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			if(binding.materialTexture.get() == 0){
				if(binding.textureName==std::string("")) continue;
				binding.materialTexture = 
					MaterialManager::getSingleton().getMaterialTexture(binding.textureName.c_str());
				if(binding.materialTexture .get() == 0){
					LOG4CPLUS_WARN(logger,"RenderPass | Texture ["<<binding.textureName<<"] not bound.");
					unbounded++;
				}
			}
			if(binding.sampler.get() == 0){
				if(binding.samplerName==std::string("")) continue;
				binding.sampler = 
					MaterialManager::getSingleton().getSampler(binding.samplerName.c_str());
				if(binding.sampler == 0){
					LOG4CPLUS_WARN(logger,"RenderPass | Sampler ["<<binding.samplerName<<"] not bound.");
					unbounded++;
				}
			}
		}
		return unbounded;
	}

	//////////////////////////////////////////////////////////////////////////
	// GENERIC RENDER PROPERTIES
	//////////////////////////////////////////////////////////////////////////
	void RenderPass::clearGenericProperties(){
		BOOST_FOREACH(RenderProp_Generic* prop, mRenderProperties) delete prop;
		mRenderProperties.clear();
	}
	void RenderPass::addGenericProperty(RenderProp_Generic* prop){
		if(prop == 0) return;
		// some properties can only be defined once. First, search using property types

		RenderPropGenericList::iterator i = mRenderProperties.begin();
		RenderPropGenericList::iterator iend = mRenderProperties.end();
		for(; i!=iend; i++){
			bool breakLoop = false;
			if((*i)->getType() == prop->getType()){
				RenderProp_StencilFunc* p1, *p2;
				RenderProp_StencilMask* p3, *p4;
				RenderProp_StencilOp*   p5, *p6;
				RenderProp_PolyMode*    p9, *p10;
				switch((*i)->getType()){
					// these can only have one value at a time
				case RPT_blend_equation:
				case RPT_blend_function:
				case RPT_depth_function:
				case RPT_depth_mask:
				case RPT_color_mask:
				case RPT_front_face:
				case RPT_cull_face:
				case RPT_depth_test:
				case RPT_stencil_test:
				case RPT_blending:
				case RPT_line_width:
					mRenderProperties.erase(i);
					breakLoop = true;
					break;
				case RPT_stencil_function:
					p1 = dynamic_cast<RenderProp_StencilFunc*>(prop);
					p2 = dynamic_cast<RenderProp_StencilFunc*>((*i));
					if(p1->getFace() == p2->getFace()){
						mRenderProperties.erase(i);
						breakLoop = true;
					}
					break;
				case RPT_stencil_mask:
					p3 = dynamic_cast<RenderProp_StencilMask*>(prop);
					p4 = dynamic_cast<RenderProp_StencilMask*>((*i));
					if(p3->getFace() == p4->getFace()){
						mRenderProperties.erase(i);
						breakLoop = true;
					}
					break;
				case RPT_stencil_operation:
					p5 = dynamic_cast<RenderProp_StencilOp*>(prop);
					p6 = dynamic_cast<RenderProp_StencilOp*>((*i));
					if(p5->getFace() == p6->getFace()){
						mRenderProperties.erase(i);
						breakLoop = true;
					}
					break;
				case RPT_poly_mode:
					p9  = dynamic_cast<RenderProp_PolyMode*>(prop);
					p10 = dynamic_cast<RenderProp_PolyMode*>((*i));
					if(p9->getFaceMode() == p10->getFaceMode()){
						mRenderProperties.erase(i);
						breakLoop = true;
					}
					break;
				// these are invalid types:
				case RPT_uniform:
				case RPT_min_filter:
				case RPT_mag_filter:
				case RPT_wrap_mode:
				case RPT_none:
					break;
				}
			}
			if(breakLoop) break;
		}
		mRenderProperties.push_back(prop);
	}

	//////////////////////////////////////////////////////////////////////////
	// UNIFORM PROPERTIES
	//////////////////////////////////////////////////////////////////////////
	void RenderPass::addUniformDefault(RenderProp_Uniform* prop){
		assert(prop);
		removeUniformDefault(prop->getName());
		mUniformDefaults.push_back(prop);
		removeUniformNonDefault(prop->getName());
	}
	void RenderPass::clearUniformDefaults(){
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults   ) { delete uni; }
		mUniformDefaults.clear();
	}
	void RenderPass::clearUniformNonDefaults(){
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) { delete uni; }
		mUniformNondefaults.clear();
	}
	void RenderPass::clearUniformDefaultRollBacks(){
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaultRollBacks) { delete uni; }
		mUniformDefaultRollBacks.clear();
	}

	void RenderPass::removeUniformDefault(const std::string& uniformName){
		UniformPropertyList::iterator i   =mUniformDefaults.begin();
		UniformPropertyList::iterator iend=mUniformDefaults.end();
		for( ; i!=iend ; i++){
			if ((*i)->getName() == uniformName ){
				mUniformDefaults.erase(i);
				break;
			}
		}
	}
	void RenderPass::removeUniformNonDefault(const std::string& uniformName){
		UniformPropertyList::iterator i   =mUniformNondefaults.begin();
		UniformPropertyList::iterator iend=mUniformNondefaults.end();
		for( ; i!=iend ; i++){
			if ((*i)->getName() == uniformName ){
				mUniformNondefaults.erase(i);
				break;
			}
		}
	}
	bool RenderPass::isADefaultUniform(const std::string& uniformName){
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults) { 
			if ( uni->getName() == uniformName) return true;
		}
		return false;
	}
	size_t RenderPass::getUniformDefaultsCount() const{
		return mUniformDefaults.size();
	}
	size_t RenderPass::getUniformTotalCount() const{
		return mUniformDefaults.size() + mUniformNondefaults.size();
	}
	RenderProp_Uniform* RenderPass::getUniformProperty(const std::string& uniformName){
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) { 
			if ( uni->getName() == uniformName) return uni;
		}
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults) { 
			if ( uni->getName() == uniformName) return uni;
		}
		return 0;
	}


	//////////////////////////////////////////////////////////////////////////
	// PREPARE / CLEAR STATE
	//////////////////////////////////////////////////////////////////////////
	void RenderPass::prepareState(){
		if(!mLoaded) return;
		if(mUsesLights){
			LightingManager &LM(LightingManager::getSingleton());
			mUsesLights = LM.uploadLightingParameters(*this);
		}
		// 1. activate generic render properties
		BOOST_FOREACH(RenderProp_Generic* prop, mRenderProperties) prop->activate();
		// 2. activate shader program
		mProgram->bindResource();
		// 3. The uniform default parameters are set on program creation time.
		synchDefaultUniforms();
		// 4. update the uniforms this render pass holds
		synchDirtyUniforms();
		// 5. bind textures
		BOOST_FOREACH(STexturePassBinding& binding, mTextureBindings) {
			GPUTexture::setActiveTextureUnit(binding.texUnitID);
			// bind the texture
			if(binding.materialTexture.get()) {
				// binds the texture resource as well
				binding.materialTexture->updateSamplerState(); 
			}
			// update set sampling state if required
			GPUSampler* samplerPtr = binding.sampler.get();
			if(GPUSamplerResource::isSupported()){
				if(samplerPtr!=0){
					assert(samplerPtr->getType()==GPUSamplerType_Res); // only accepts resource type
					((GPUSamplerResource*)samplerPtr)->bindResource(binding.texUnitID);
				} else {
					GPUSamplerResource::unbindResource(binding.texUnitID);
				}
			} else {
				if(samplerPtr!=0){
					samplerPtr->updateState(); // updates attached texture's state
					// Set texture's own sampling state as dirty!
					if(binding.materialTexture.get())
						binding.materialTexture->invalidateSamplerState();
					// TODO: Fix bug: the bound texture may not be within this render-state, track
					// the currently bound texture globally!
				}
			}
		}
	}
	void RenderPass::clearState(){
		if(!mLoaded) return;
		BOOST_FOREACH(RenderProp_Generic* prop, mRenderProperties) {
			prop->deactivate();
		}
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaultRollBacks) {
			uni->activate();
		}
	}

	void RenderPass::synchDirtyUniforms(){
		// cannot update light parameters here, light parameters depend of the MESH / object to be rendered.
		// since different lights may light the object
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) { 
			RenderSystem::getSingleton().updateUniformIfSpecical(*uni);
			if(uni->requiresSynch()) uni->activate();
		}
	}
	void RenderPass::synchDefaultUniforms(){
		//! Note, It is not checked whether uniform requires synch or not!
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults) uni->activate();
	}

	bool RenderPass::load(){
		if(isLoaded()) return true;
		Logger logger = Logger::getInstance("mtrl");

		if(mProgram.get()==0) {
			// try to resolve from program name
			MaterialProgramPtr prog = MaterialManager::getSingleton().getMaterialProgram(mProgramName.c_str());
			if(prog.get()==0) {
				LOG4CPLUS_ERROR(logger,"RenderPass | Load | Material Program reference cannot be set.");
				return false;
			}
			mProgram = prog;
		}

		if(!mProgram->isLinked()) 
			if(mProgram->resolveAttachAndLinkShaders()==false) return false;

		CHECKGLERROR_TERM();
		updateUniformData();
		CHECKGLERROR_TERM();
		// TODO Catch unbounded uniforms info? (Unbounded uniforms do NOT make a render pass unloaded)
		bindUniformsToProgram();
		CHECKGLERROR_TERM();
		mLoaded = (loadTextureBindings()==0);
		CHECKGLERROR_TERM();
		mUsesLights = true;
		return isLoaded();
	}

	void RenderPass::updateUniformData(){
		if(mProgram==0) return; 
		// 1. read uniform data from program object
		size_t progActiveUniCount = mProgram->getActiveUniformCount();
		size_t bufSize = mProgram->getActiveUniformMaxLength();
		char* uniformName = (char*) malloc(sizeof(char)*bufSize);

		GLenum uniformType;
		int uniformSize;
		size_t uniformLength;
		// for each uniform in the GPU program...
		clearUniformNonDefaults();
		clearUniformDefaultRollBacks();
		for(size_t progActiveUniIndex=0 ; progActiveUniIndex<progActiveUniCount ; progActiveUniIndex++){
			mProgram->getActiveUniform(progActiveUniIndex, &uniformLength,&uniformSize, &uniformType, uniformName);

			// escape if the uniform name was already defined previously (by the application / mat file)
			if(isADefaultUniform(uniformName)) continue;
			
			UniformType rengType;
			// convert the received type info the REng uniform type enumerations
			switch(uniformType){
				case GL_FLOAT:
					rengType = UniformType_Float_1;
					break;
				case GL_FLOAT_VEC2:
					rengType = UniformType_Float_2;
					break;
				case GL_FLOAT_VEC3:
					rengType = UniformType_Float_3;
					break;
				case GL_FLOAT_VEC4:
					rengType = UniformType_Float_4;
					break;
				case GL_INT:
				case GL_BOOL:
				case GL_SAMPLER_1D:
				case GL_SAMPLER_2D:
				case GL_SAMPLER_3D:
				case GL_SAMPLER_CUBE:
				case GL_INT_SAMPLER_1D:
				case GL_INT_SAMPLER_2D:
				case GL_INT_SAMPLER_3D:
				case GL_UNSIGNED_INT_SAMPLER_1D:
				case GL_UNSIGNED_INT_SAMPLER_2D:
				case GL_UNSIGNED_INT_SAMPLER_3D:
				case GL_UNSIGNED_INT:
					rengType = UniformType_Int_1;
					break;
				case GL_INT_VEC2:
				case GL_BOOL_VEC2:
				case GL_UNSIGNED_INT_VEC2:
					rengType = UniformType_Int_2;
					break;
				case GL_INT_VEC3:
				case GL_BOOL_VEC3:
				case GL_UNSIGNED_INT_VEC3:
					rengType = UniformType_Int_3;
					break;
				case GL_INT_VEC4:
				case GL_BOOL_VEC4:
				case GL_UNSIGNED_INT_VEC4:
					rengType = UniformType_Int_4;
					break;
				case GL_FLOAT_MAT2:
					rengType = UniformType_Matrix_22;
					break;
				case GL_FLOAT_MAT3:
					rengType = UniformType_Matrix_33;
					break;
				case GL_FLOAT_MAT4:
					rengType = UniformType_Matrix_44;
					break;
				default:
					rengType = UniformType_Matrix_44;
					assert(0);
					break;
			}

			UniformAutoName autoName = UAN_None;
			convertStrToUAN(uniformName,autoName);

			RenderProp_Uniform *prop = new RenderProp_Uniform(uniformName, rengType,autoName);
			mUniformNondefaults.push_back(prop);
		}
		free(uniformName);

		if(progActiveUniCount != getUniformTotalCount()){
			Logger logger = Logger::getInstance("mtrl");
			LOG4CPLUS_WARN(logger,"RenderPass | Uniform counts do not match. You may have a buggy OpenGL driver, sorry, there may be some errors in your uniforms... "
				"Expected:" << progActiveUniCount << " Receieved:" << mUniformNondefaults.size() );
			progActiveUniCount = mUniformNondefaults.size();
		}

		// Copy default uniform data from vertex shader to nondefault uniforms in this pass
		// They will be synched only once in the first prepare call
		BOOST_FOREACH(const RenderProp_Uniform* uni, mProgram->mVertMatShader->getUniformDefaults() ){
			copydataToNondefaultUniform(uni);
		}
		BOOST_FOREACH(const RenderProp_Uniform* uni, mProgram->mFragMatShader->getUniformDefaults() ){
			copydataToNondefaultUniform(uni);
		}
		BOOST_FOREACH(const RenderProp_Uniform* uni, mProgram->getUniformDefaults() ){
			copydataToNondefaultUniform(uni);
		}
	}

	void RenderPass::copydataToNondefaultUniform(const RenderProp_Uniform* uni){
		BOOST_FOREACH(RenderProp_Uniform* uniND, mUniformNondefaults) { 
			if(uniND->getName()==uni->getName()){
				uni->copyData(*uniND); // from given uniform to self non-default uniform
				break;
			}
		}
		BOOST_FOREACH(RenderProp_Uniform* uniD, mUniformDefaults) { 
			if(uniD->getName()==uni->getName()){
				// this pass has updated some uniform data with its own defaults, we need to
				// keep track of old default value
				RenderProp_Uniform *prop = new RenderProp_Uniform(
					uni->getName(), uni->getType(),uni->getAutoName());
				uni->copyData(*prop);
				mUniformDefaultRollBacks.push_back(prop);
				break;
			}
		}
	}


	size_t RenderPass::bindUniformsToProgram(){
		if(mProgram == 0) return mUniformNondefaults.size();
		Logger logger = Logger::getInstance("mtrl");

		size_t bounded = 0;
		size_t unbounded = 0;
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformNondefaults) { 
			if(bindUniformToProgram(uni)==true) {
				++bounded;
			} else {
				++unbounded;
				if( uni->getName().compare(0,3,"gl_") != 0) {
					LOG4CPLUS_WARN(logger,"RenderPass | Uniform Bind | ["<<uni->getName()<<"] | Fail");
				}
			}
		}
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaults) { 
			if(bindUniformToProgram(uni)==true) { 
				++bounded;
			} else { 
				++unbounded;
				if( uni->getName().compare(0,3,"gl_") != 0) {
					LOG4CPLUS_WARN(logger,"RenderPass | Uniform Bind | ["<<uni->getName()<<"] | Fail");
				}
			}
		}
		BOOST_FOREACH(RenderProp_Uniform* uni, mUniformDefaultRollBacks) { 
			bindUniformToProgram(uni);
		}
		return unbounded;
	}
	bool RenderPass::bindUniformToProgram(RenderProp_Uniform* uni){
		if( uni->isBoundToProgram() ) return true;
		// TODO: remove this section, it is used for backwards compatibility
		if( uni->getName().compare(0,3,"gl_") == 0) return false;
		if( uni->bindToProgram(*mProgram) == false){
			return false;
		} else {
			return true;
		}
	}

}
