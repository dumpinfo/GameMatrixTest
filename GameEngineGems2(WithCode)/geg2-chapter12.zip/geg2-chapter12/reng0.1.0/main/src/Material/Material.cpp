/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include <boost/foreach.hpp>

#include "REng/Material/Material.h"

namespace REng{

	Material::Material(const std::string& name) {
		mName = name;
		mMaxViewIndex = 0;
		mMaxDistIndex  = 0;
	}

	Material::~Material(void) {; }

	const std::string& Material::getName() const{
		return mName;
	}

	bool Material::isValid(void) const{
		size_t techniqueCount = mLoDList.size();

		// Check if view 0, LoD 0 material exists (also handles techniqueCount == 0 case)
		size_t i;
		for(i=0 ; i<techniqueCount ; i++){
			if(0==mLoDList[i].mDistIndex && 0==mLoDList[i].mViewIndex){
				break;
			}
		}
		if(i == techniqueCount) return false;

		// Check if each technique is valid
		for(size_t i=0 ; i<techniqueCount ; i++){
			if(mLoDList[i].mLoDData->isValid()==false) return false;
		}

		// all checks passed
		return true;
	}

	void Material::clone(Material& _to, bool loadMaterial) const{
		_to.clear(); // clear old LoD'ed techniques
		LoDMappingList::const_iterator curTech(begin());
		LoDMappingList::const_iterator lastTech(end());
		for( ; curTech != lastTech ; curTech++){
			if( curTech->mLoDData == 0) continue;
			curTech->mLoDData->clone(*(_to.createLoDedData(curTech->mViewIndex,curTech->mDistIndex)));
		}
		if(loadMaterial) _to.load();
	}

	size_t Material::load(){
		size_t failCount = 0;
		CHECKGLERROR_TERM();
		size_t loop = mLoDList.size();
		for(size_t i=0 ; i<loop ; i++){
			failCount += (mLoDList[i].mLoDData->load()!=true);
		}
		CHECKGLERROR_TERM();
		return failCount;
	}


	Technique* Material::constructLoDData(){
		return new Technique(this);
	}

}
