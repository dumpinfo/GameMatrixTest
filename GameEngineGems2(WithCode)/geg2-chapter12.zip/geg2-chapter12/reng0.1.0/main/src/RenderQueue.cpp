/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/

#include "REng/RenderQueue.h"

// pre-post rendering related
#include "REng/Material/MaterialManager.h"
#include "REng/GPU/GPUDrawer.h"
#include "REng/RenderMatrixManager.h"
#include "REng/RenderSystem.h"

namespace REng{

	/************************************************************************/
	/* RENDERABLE                                                           */
	/************************************************************************/

	Renderable::Renderable(const Matrix4& mt, const MeshGeom& mg, RenderPass* rp)
		:modelTransform(&mt)
		,modelTransformPtr(0)
		,meshGeom(mg)
		,pass(rp)
	{ viewNo=0; }
	Renderable::Renderable(Matrix4* mt, const MeshGeom& mg, RenderPass* rp)
		:modelTransform(mt)
		,modelTransformPtr(mt)
		,meshGeom(mg)
		,pass(rp)
	{ viewNo=0; }
	Renderable::~Renderable(){ ; }
	void Renderable::clear(){
		if(modelTransformPtr!=0) delete modelTransformPtr;
	}

	Renderable& Renderable::operator=(const Renderable& rhs){
		modelTransform = rhs.modelTransform;
		modelTransformPtr = rhs.modelTransformPtr;
		pass = rhs.pass;
		meshGeom = rhs.meshGeom;
		viewNo = rhs.viewNo;
		return *this;
	}
	const Matrix4& Renderable::getModelTransform() const{
		if(modelTransformPtr) return *modelTransformPtr;
		return *modelTransform;
	}
	MeshGeom& Renderable::getMeshGeom(){
		return meshGeom;
	}
	RenderPass* Renderable::getRenderPass(){
		return pass;
	}

	/************************************************************************/
	/* RENDERQUEUE                                                          */
	/************************************************************************/

	RenderQueue::RenderQueue() 
		:mEnabled(true)
		,mRenderableCount(0)
	{ ; }

	RenderQueue::IteratorGeneric::IteratorGeneric(IteratorImp* impP) : imp(impP) { }
	RenderQueue::IteratorGeneric::IteratorGeneric(const IteratorGeneric& rhs){
		this->imp = rhs.imp;
	}
	RenderQueue::IteratorGeneric::~IteratorGeneric(){ }
	bool RenderQueue::IteratorGeneric::operator==(const RenderQueue::IteratorGeneric& i) const { 
		return (*(this->imp))==(*(i.imp));
	}

	Renderable& RenderQueue::IteratorGeneric::operator*() { 
		return *(*imp);
	}
	RenderQueue::IteratorGeneric& RenderQueue::IteratorGeneric::operator++() { 
		++(*imp);
		return (*this);
	}
	bool RenderQueue::IteratorGeneric::operator!=(const IteratorGeneric& i) const { 
		return !(*this==i);
	}

	bool RenderQueue_Vector::RIteratorImp_Vector::operator==(const IteratorImp& i) const{
		const RIteratorImp_Vector& ii(static_cast<const RIteratorImp_Vector&>(i));
		return (ii.it)==(this->it);
	}
	Renderable& RenderQueue_Vector::RIteratorImp_Vector::operator*(){
		return *(this->it);
	}
	RenderQueue::IteratorImp& RenderQueue_Vector::RIteratorImp_Vector::operator++(){
		++(this->it);
		return *this;
	}
	RenderQueue_Vector::RIteratorImp_Vector::RIteratorImp_Vector(RenderableList::iterator it){
		this->it = it;
	}
	RenderQueue_Vector::RIteratorImp_Vector::~RIteratorImp_Vector() { }

	void RenderQueue_Vector::clear(){
		RenderQueue::clear();
		mRenderableList.clear();
	}
	void RenderQueue_Vector::addRenderable(Renderable& r){
		if(mRenderableCount<mRenderableList.size()) {
			// delete the old renderable
			mRenderableList[mRenderableCount].clear();
			mRenderableList[mRenderableCount++] = r;
		} else {
			mRenderableList.push_back(r);
			mRenderableCount++;
		}
	}
	RenderQueue_Vector::IteratorGeneric RenderQueue_Vector::begin(){
		return IteratorGeneric(new RIteratorImp_Vector(mRenderableList.begin()));
	}
	RenderQueue_Vector::IteratorGeneric RenderQueue_Vector::end(){
		RenderableList::iterator i=mRenderableList.end();
		// we may not be using all vector elements!
		for(size_t rdif = mRenderableList.size() - getRenderableCount() ; rdif>0 ; rdif--) i--;
		return IteratorGeneric(new RIteratorImp_Vector(i));
	}

	//////////////////////////////////////////////////////////////////////////
	// RenderQueue_BVs

	const uchar RenderQueue_BVs::RenderQueue_BVs_ID = REnderQueueID_BoundingVol;
	RenderQueue_BVs::RenderQueue_BVs(){
		RenderQueueMap::getSingleton().registerRenderQueue(this,RenderQueue_BVs_ID);
		mEnableSetAttribBatch = false;
	}
	void RenderQueue_BVs::preRenderQueueProcess(){
		MaterialPtr wireFrameMaterial = MaterialManager::getSingleton().getMaterial("re_Wireframe");
		if(wireFrameMaterial.get()==0) return;
		// activate render pass
		static RenderPass* pass = wireFrameMaterial->getSuitableData()->getRenderPass();
		pass->prepareState();

		if(mEnableSetAttribBatch) GPUDrawer::getSingleton().setAttribBatchOn();
	}
	void RenderQueue_BVs::postRenderQueueProcess(){
		if(mEnableSetAttribBatch) GPUDrawer::getSingleton().setAttribBatchOff();
		MaterialPtr wireFrameMaterial = MaterialManager::getSingleton().getMaterial("re_Wireframe");
		if(wireFrameMaterial.get()==0) return;
		// activate render pass
		static RenderPass* pass = wireFrameMaterial->getSuitableData()->getRenderPass();
		pass->clearState();
	}

	//////////////////////////////////////////////////////////////////////////
	// RenderQueue_Background

	const uchar RenderQueue_Background::RenderQueue_Background_ID = RenderQueueID_Background;
	RenderQueue_Background::RenderQueue_Background(){
		RenderQueueMap::getSingleton().registerRenderQueue(this,RenderQueue_Background_ID);
	}
	void RenderQueue_Background::preRenderQueueProcess(){
		if(getRenderableCount()==0) {
			return;
		}

		// temporarily set the camera to world center position
		Matrix3 rotMatrix;
		cml::matrix_rotation_quaternion(
			rotMatrix,
			RenderSystem::getSingleton().getActiveCamera()->getNode().getRotation_World());
		rotMatrix.transpose();
		// translation is relative to rotation matrix
		Matrix4 viewMatrix; // convert 3x3 rot matrix to 4x4 view matrix
		viewMatrix.identity();
		viewMatrix(0,0) = rotMatrix(0,0);
		viewMatrix(0,1) = rotMatrix(0,1);
		viewMatrix(0,2) = rotMatrix(0,2);
		viewMatrix(1,0) = rotMatrix(1,0);
		viewMatrix(1,1) = rotMatrix(1,1);
		viewMatrix(1,2) = rotMatrix(1,2);
		viewMatrix(2,0) = rotMatrix(2,0);
		viewMatrix(2,1) = rotMatrix(2,1);
		viewMatrix(2,2) = rotMatrix(2,2);
		RenderMatrixManager::getSingleton().pushView();
		RenderMatrixManager::getSingleton().setView(viewMatrix);
	}
	void RenderQueue_Background::postRenderQueueProcess(){
		if(getRenderableCount()==0) return;
		RenderMatrixManager::getSingleton().popView();
	}


	/************************************************************************/
	/* RENDERQUEUEMAP                                                       */
	/************************************************************************/

	// singleton stuff
	template<> RenderQueueMap* Singleton<RenderQueueMap>::ms_Singleton = 0;
	RenderQueueMap* RenderQueueMap::getSingletonPtr(void) {
		return ms_Singleton;
	}
	RenderQueueMap& RenderQueueMap::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	RenderQueueMap::RenderQueueMap() 
		: mDefaultQueueID(RenderQueueID_NodeDefault)
	{ ; }

	void RenderQueueMap::resetQueues() {
		iterator i=mRenderableListMap.begin();
		iterator iend=mRenderableListMap.end();
		for( ; i!=iend ; i++) i->second->reset();
	}

	bool RenderQueueMap::registerRenderQueue(RenderQueue* queue, uchar queueID){
		if(queueID==RenderQueueID_Null) return false;
		assert(queue);
		// if a group with the same ID exists, return false
		if(getRenderQueue(queueID)!=0) return false;
		mRenderableListMap.insert(RenderQueueMapping::value_type(queueID,queue));
		queue->mQueueID = queueID;
		return true;
	}

	void RenderQueueMap::setDefaultQueueID(uchar queueID){
		if(queueID!=RenderQueueID_Null) mDefaultQueueID = queueID;
	}
	uchar RenderQueueMap::getDefaultQueueID() const {
		return mDefaultQueueID;
	}

	void RenderQueueMap::addRenderable(Renderable& r, uchar queueID){
		if(queueID==RenderQueueID_Null) queueID = mDefaultQueueID;
		iterator r_iter = mRenderableListMap.find(queueID);
		if(r_iter == mRenderableListMap.end()){
			// a new group ID has been specified
			return;
		}
		// add the given renderable to existing renderable group
		r_iter->second->addRenderable(r);
	}

	RenderQueue* RenderQueueMap::getRenderQueue(uchar queueID){
		iterator r_iter = mRenderableListMap.find(queueID);
		if(r_iter == mRenderableListMap.end()){
			return 0;
		} else {
			return r_iter->second;
		}
	}

	RenderQueueMap::iterator RenderQueueMap::begin(){
		return mRenderableListMap.begin();
	}

	RenderQueueMap::iterator RenderQueueMap::end(){
		return mRenderableListMap.end();
	}


} // namespace REng
