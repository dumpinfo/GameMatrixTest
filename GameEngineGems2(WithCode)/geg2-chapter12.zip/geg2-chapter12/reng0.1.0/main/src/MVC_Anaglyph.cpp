/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/MVC_Anaglyph.h"

// to switch active frame-buffers
#include "REng/GPU/GPUFrameBuffer.h"
// to render compositor geom-mesh
#include "REng/GPU/GPUDrawer.h"
// to bind GPUTextures
#include "REng/GPU/GPUTexture.h"
// viewport
#include "REng/Viewport.h"

// logging to render system logs...
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{
	MVC_Anaglyph::MVC_Anaglyph() 
		: MultiViewCompositor(2)
		,mType(Anaglyh_R_GB)
		,mViewsReversed(false)
		,mCompProg(0)
		,mCompFragS(0)
		,mImageSampler_L(0)
		,mImageSampler_R(0)
	{ ; }

	MVC_Anaglyph::~MVC_Anaglyph(){ ; }

	void MVC_Anaglyph::setType(AnaglyphType _type) const{
		mType = _type;
		updateCompProg();
	}
	AnaglyphType MVC_Anaglyph::getType() const{
		return mType;
	}
	void MVC_Anaglyph::setViewsReversed(bool flag) const{
		mViewsReversed = flag;
		updateCompProg();
	}
	bool MVC_Anaglyph::isViewsReversed() const{
		return mViewsReversed;
	}


	bool MVC_Anaglyph::updateCompProg() const{
		Logger logger = Logger::getInstance("RSys");
		if(!mCompProg){
			mCompProg = new GPUProgram();
			REng::GPUShader vertShader(ShaderType_Vertex); // creates OpenGL object
			const char *vertShaderText[] = {
				" #ifdef GL_ES\n",
				"   precision highp float;\n",
				" #endif\n",
				" attribute vec2 vertexIn; ",
				" attribute vec2 texCoordIn; ",
				" varying   vec2 textureCoord; ",
				" void main() { ",
				"   textureCoord = texCoordIn; ",
				"   gl_Position = vec4(vertexIn.xy,0.0,1.0); ",
				" }"
			};
			if(!vertShader.compileFromText( 10, vertShaderText)){
				LOG4CPLUS_WARN(logger, "MultiViewCompositor Anaglyph vertex shader could not be compiled.");
				return false;
			}
			mCompProg->attachShader(vertShader);
			mCompProg->bindAttribLocation(0,"vertexIn");
			mCompProg->bindAttribLocation(1,"texCoordIn");
		}
		if(mCompFragS!= 0) {
			mCompProg->detachShader(*mCompFragS);
			delete mCompFragS;
		}
		const char* color0 = 0;
		const char* color1 = 0;
		const char* flagColor = 0;
		if(!mViewsReversed){
			color0 = "vec4 color0=texture2D(viewL,textureCoord);";
			color1 = "vec4 color1=texture2D(viewR,textureCoord);";
		} else {
			color0 = "vec4 color0=texture2D(viewR,textureCoord);";
			color1 = "vec4 color1=texture2D(viewL,textureCoord);";
		}
		switch(mType){
			case Anaglyh_R_GB:
				flagColor = "gl_FragColor = vec4(color0.r,color1.g,color1.b,1.0);";
				break;
			case Anaglyh_Mono_R_B:
				flagColor = "gl_FragColor = vec4(color0.r,0.0,color1.b,1.0);";
				break;
			case Anaglyh_Mono_R_G:
				flagColor = "gl_FragColor = vec4(color0.r,color1.g,0.0,1.0);";
				break;
			default: break;
		}

		//////////////////////////////////////////////////////////////////////////
		// CREATE FRAGMENT SHADER
		mCompFragS = new REng::GPUShader(ShaderType_Fragment); // creates OpenGL object
		const char* fragShaderText[] = {
			" #ifdef GL_ES            \n",
			"   precision highp float;\n",
			" #endif                  \n",
			" uniform sampler2D viewL; ",
			" uniform sampler2D viewR; ",
			" varying vec2      textureCoord; ",
			" void main() { ",
			color0,
			color1,
			flagColor,
			" }"
		};
		if( !mCompFragS->compileFromText( sizeof(fragShaderText)/4, fragShaderText) ){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Anaglyph fragment shader could not be compiled.");
			return false;
		}

		//////////////////////////////////////////////////////////////////////////
		// CREATE HW PROGRAM
		mCompProg->attachShader(*mCompFragS);
		if(!mCompProg->link()){
			LOG4CPLUS_WARN(logger, "MultiViewCompositor Anaglyph GPU program could not be linked.");
			return false;
		}

		mCompProg->bindResource();
		//////////////////////////////////////////////////////////////////////////
		// RETRIEVE UNIFORM BINDINGS
		if(mImageSampler_L) delete mImageSampler_L;
		mImageSampler_L = new RenderProp_Uniform("viewL",UniformType_Int_1);
		mImageSampler_L->setDataAtIndex(0,0);
		mImageSampler_L->bindToProgram(*mCompProg);
		mImageSampler_L->activate();

		if(mImageSampler_R) delete mImageSampler_R;
		mImageSampler_R = new RenderProp_Uniform("viewR",UniformType_Int_1);
		mImageSampler_R->setDataAtIndex(0,1);
		mImageSampler_R->bindToProgram(*mCompProg);
		mImageSampler_R->activate();
		return true;
	}

	void MVC_Anaglyph::initCompositorGeom(){
		//////////////////////////////////////////////////////////////////////////
		// SET RENDER MESH
		size_t numVertices = 4;

		// the index setting will correspond to glDrawArrays(Triangles,0,3) 
		// with no index buffer bindings on render time...
		mCompositorGeom.mIndexDataPtr.reset(new IndexData());
		mCompositorGeom.mIndexDataPtr->primType = PrimitiveType_TriangleStrip;
		mCompositorGeom.mIndexDataPtr->mRange.set(0,numVertices);

		mCompositorGeom.mVertexDataPtr.reset(new VertexData());
		mCompositorGeom.mVertexDataPtr->mRange.set(0,numVertices);
		VertexAttribute attribVertex  (0,0,VertexAttribDataType_Byte,VertexAttribDataCount2,"vertexIn");
		VertexAttribute attribTexCoord(0,attribVertex.getSizeInBytes(),VertexAttribDataType_Byte,VertexAttribDataCount2,"texCoordIn");
		mCompositorGeom.mVertexDataPtr->insertAttribute(attribVertex);
		mCompositorGeom.mVertexDataPtr->insertAttribute(attribTexCoord);

		GPUVertexBufferPtr bufPtr( new GPUVertexBuffer(
			mCompositorGeom.mVertexDataPtr->getVertexSize(0), numVertices, 
			BufferUsageFreq_Static,BufferUsageNature_Draw) );
		mCompositorGeom.mVertexDataPtr->linkBufferToIndex(0,bufPtr);
		GLbyte geometryArray[4*4];
		int t=0;
		// vertex coordinates                         // texture coordinates
		geometryArray[t++] = -1; geometryArray[t++] = -1; geometryArray[t++] = 0; geometryArray[t++] = 0;
		geometryArray[t++] =  1; geometryArray[t++] = -1; geometryArray[t++] = 1; geometryArray[t++] = 0;
		geometryArray[t++] = -1; geometryArray[t++] =  1; geometryArray[t++] = 0; geometryArray[t++] = 1;
		geometryArray[t++] =  1; geometryArray[t++] =  1; geometryArray[t++] = 1; geometryArray[t++] = 1;
		bufPtr->writeData(geometryArray);
	}

	bool MVC_Anaglyph::init(Viewport& vp){
		if(mIsInitialized) return true;
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "MultiViewCompositor Anaglyph initializing...");

		if(updateCompProg()==false) return false;
		initCompositorGeom();

		mIsInitialized = true;
		mIsSupported = true;
		LOG4CPLUS_INFO(logger, "MVC Anaglyph initialization completed.");
		return true;
	}

	bool MVC_Anaglyph::clear(){
		if(mImageSampler_L){
			delete mImageSampler_L; mImageSampler_L=0;
		}
		if(mImageSampler_R){
			delete mImageSampler_R; mImageSampler_R=0;
		}
		if(mCompProg){
			delete mCompProg; mCompProg=0;
		}
		if(mCompFragS){
			delete mCompFragS; mCompFragS=0;
		}
		mIsInitialized = false;
		return true;
	}

	bool MVC_Anaglyph::mergeViews(MultiViewBuffer& mvb){
		if(!isSupported()) return false;
		glDisable(GL_DEPTH_TEST);

		// activate view buffers
		for(REng::uint i=0; i<getViewCount(); i++){
			GPUTexture::setActiveTextureUnit(i);
			mvb.getColorTarget(i)->bindResource();
		}

		// activate GPU program, send the meshes, and we are done.
		mCompProg->bindResource();
		GPUDrawer::getSingleton().drawMeshGeom(mCompositorGeom);

		glEnable(GL_DEPTH_TEST);
		return true;
	}


	MVC_Anaglyph_OnTarget::MVC_Anaglyph_OnTarget() 
		: MultiViewCompositor(2)
		,mType(Anaglyh_R_GB)
	{ setType(Anaglyh_R_GB); }

	MVC_Anaglyph_OnTarget::~MVC_Anaglyph_OnTarget(){;}

	void MVC_Anaglyph_OnTarget::setType(AnaglyphType _type) const{
		mType = _type;
		switch(mType){
			case Anaglyh_R_GB:
				mLeftColorMask .setFlags(true ,false,false,false);
				mRightColorMask.setFlags(false,true ,true ,false);
				break;
			case Anaglyh_Mono_R_B:
				mLeftColorMask .setFlags(true ,false,false,false);
				mRightColorMask.setFlags(false,true ,false,false);
				break;
			case Anaglyh_Mono_R_G:
				mLeftColorMask .setFlags(true ,false,false,false);
				mRightColorMask.setFlags(false,false,true ,false);
				break;
		}
	}
	AnaglyphType MVC_Anaglyph_OnTarget::getType() const{
		return mType;
	}

	bool MVC_Anaglyph_OnTarget::init(Viewport& vp){
		mIsInitialized = true;
		mIsSupported = true;
		LOG4CPLUS_INFO(Logger::getInstance("RSys"), "MVC Anaglyh (OnTarget) initialization completed.");
		return true;
	}
	bool MVC_Anaglyph_OnTarget::clear(){
		RenderProp_ColorMask::setDefault();
		mIsInitialized = false;
		return true;
	}
	bool MVC_Anaglyph_OnTarget::setActiveView(size_t viewIndex){
		if(viewIndex==0){
			mLeftColorMask.activate();
		} else {
			mRightColorMask.activate();
		}
		return true;
	}
	bool MVC_Anaglyph_OnTarget::beginFrame(){
		RenderProp_ColorMask::setDefault();
		return true;
	}
	bool MVC_Anaglyph_OnTarget::endFrame(){
		RenderProp_ColorMask::setDefault();
		return true;
	}

}

