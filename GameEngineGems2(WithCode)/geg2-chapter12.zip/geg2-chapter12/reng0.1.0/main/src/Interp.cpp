/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Interp.h"

namespace REng {

	/************************************************************************/
	/* Linear interpolations                                                */
	/************************************************************************/

	Quaternion& Interp::NLerp(const Quaternion& q1, const Quaternion& q2, float u, 
		Quaternion& result, bool shortestPath)
	{
		if(shortestPath){
			if( cml::dot(q1,q2) < 0.0f){
				// use inverse q2
				result = q1 + u*(-q2 - q1);
			} else {
				// same as linear interpolation
				result = q1 + u*(q2 - q1);
			}
		} else {
			// same as linear interpolation
			result = q1 + u*(q2 - q1);
		}
		result.normalize();
		return result;
	}

	Quaternion& Interp::SLerp(const Quaternion& q1, const Quaternion& q2, 
		float u, Quaternion& result, bool shortestPath)
	{
		result = cml::slerp(q1, q2, u); // TODO: always returns shortest path!
		return result;
	}

	/************************************************************************/
	/* Cubic Interpolations                                                 */
	/************************************************************************/

	// http://msdn.microsoft.com/en-us/library/ee415572%28VS.85%29.aspx
	//
	// Using the Hermite spline equation:
	// Q(s) = (2s3 - 3s2 + 1)v1 + (-2s3 + 3s2)v2 + (s3 - 2s2 + s)t1 + (s3 - s2)t2
	// and substituting for v1, v2, t1, t2 yields:
	// Q(s) = (2s3 - 3s2 + 1)p2 + (-2s3 + 3s2)p3 + (s3 - 2s2 + s)(p3 - p1) / 2 + (s3 - s2)(p4 - p2) / 2
	// This can be rearranged as:
	// Q(s) = [(-s3 + 2s2 - s)p1 + (3s3 - 5s2 + 2)p2 + (-3s3 + 4s2 + s)p3 + (s3 - s2)p4] / 2

	Quaternion& Interp::CatmullRom(const Quaternion& q1_pre, const Quaternion& q1,
		const Quaternion& q2, const Quaternion& q2_post, float u, Quaternion& result)
	{
		Quaternion q1_tang, q2_tang;
		Tangent(q1_pre, q1, q2,  u, q1_tang);
		Tangent(q1, q2, q2_post, u, q2_tang);
		return Squad(q1,q1_tang,q2,q2_tang,u,result);
	}

	//! Performs spherical quadratic interpolation
	//! @param q1 The quaternion that is returned when u=0
	//! @param q2 The quaternion that is returned when u=1
	//! @param q1_tang The tangent quaternion at q1
	//! @param q2_tang The tangent quaternion at q2
	Quaternion& Interp::Squad(const Quaternion& q1, const Quaternion& q1_tang, 
		const Quaternion& q2, const Quaternion& q2_tang,float u, Quaternion& result)
	{
		Quaternion tmp1, tmp2;
		SLerp(
			SLerp(q1, q2, u, tmp1, true), 
			SLerp(q1_tang, q2_tang, u, tmp2, false), 
			2.0*u*(1.0-u), 
			result,
			false
			);
		return result;
	}

	// With help from libQGLViewer source
	Quaternion lnDif(const Quaternion& a, const Quaternion& b)
	{
		Quaternion tmpA(a);
		tmpA.inverse();
		Quaternion dif = tmpA*b;
		dif.normalize();
		return dif.log();
	}

	Quaternion& Interp::Tangent(const Quaternion& q_pre, const Quaternion& q,
		const Quaternion& q_post, float u, Quaternion& result)
	{
		Quaternion tmpL = lnDif(q,q_pre);
		Quaternion tmpR = lnDif(q,q_post);
		Quaternion e;
		for(int i=0; i<4; ++i) e[i] = -0.25f*(tmpL[i] + tmpR[i]);
		e = q*(e.exp());
		result = e;
		return result;
	}

}


