/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/NodeVisibiltyVisitor.h"

#include "REng/RenderSystem.h"
#include "REng/GeomRenderer.h"
#include "REng/Geom/GeomHelper.h"

#include <boost/foreach.hpp>

namespace REng{

	NodeVisitor_Visibility::NodeVisitor_Visibility() :mCullVolume(0),mTreeNoCull(false) { ; }

	void NodeVisitor_Visibility::visit(GroupNode& node){
		bool preTreeNoCull=mTreeNoCull;
		if(!isVisible(node)) return;
		SceneNodeList& children(node.getChildren());
		BOOST_FOREACH(SceneNode* node, children) node->accept(*this);
		if(preTreeNoCull!=mTreeNoCull) mTreeNoCull = !mTreeNoCull;
	}
	void NodeVisitor_Visibility::visit(RootNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility::visit(SwitchGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility::visit(LODGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility::visit(MeshNode& node){
		if(!node.isMeshAttached()) return;
		bool preTreeNoCull=mTreeNoCull;
		if(!isVisible(node)) return;

		RenderSystem::getSingleton().queueMesh(
			node.getMesh(),
			node.getWorld_Transform(),
			node.getRenderQueueGroupID());
		if(preTreeNoCull!=mTreeNoCull) mTreeNoCull = !mTreeNoCull;
	}
	void NodeVisitor_Visibility::visit(SceneNode& node){ ; }
	void NodeVisitor_Visibility::visit(CameraNode& node){ ; }
	void NodeVisitor_Visibility::visit(LightNode& node){ ; }

	bool NodeVisitor_Visibility::isVisible(SceneNode& node){
		if(mTreeNoCull) return true;
		if(mCullVolume==0) return true;
		switch(node.mCullingMode){
			case SceneNode::CULL_ALWAYS:     return false;
			case SceneNode::CULL_NEVER:      return true;
			case SceneNode::CULL_NEVER_TREE: mTreeNoCull= true; return true;
			case SceneNode::CULL_DYNAMIC:{
				const GeomVolume* nodeVol = node.getBoundingVolume_WS();
				if(nodeVol==0) break;
				switch(GeomHelper::intersects(*mCullVolume,*nodeVol)){
					case GeomHelper::BoolQueryT: 
						// check if node volume is contained within the culling volume
						if(GeomHelper::contains(*mCullVolume,*nodeVol)==GeomHelper::BoolQueryT) mTreeNoCull = true;
						return true; // the node itself is visible
					case GeomHelper::BoolQueryF: return false;
					case GeomHelper::BoolQueryX: return true; // not implemented, assume visible
					case GeomHelper::BoolQueryU: return false; // not logical, assume visible anyway
				}};
		}
		return true;		
	}

	NodeVisitor_Visibility_BoundVol::NodeVisitor_Visibility_BoundVol() :mCullVolume(0),mTreeNoCull(false) {
	}

	void NodeVisitor_Visibility_BoundVol::visit(GroupNode& node){
		bool preTreeNoCull=mTreeNoCull;
		if(!isVisible(node)) return;
		SceneNodeList& children(node.getChildren());
		BOOST_FOREACH(SceneNode* node, children) node->accept(*this);
		if(preTreeNoCull!=mTreeNoCull) mTreeNoCull = !mTreeNoCull;
	}
	void NodeVisitor_Visibility_BoundVol::visit(RootNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility_BoundVol::visit(SwitchGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility_BoundVol::visit(LODGroupNode& node){
		visit(static_cast<GroupNode&>(node));
	}
	void NodeVisitor_Visibility_BoundVol::visit(MeshNode& node){
		bool preTreeNoCull=mTreeNoCull;
		if(!isVisible(node)) return;
		if(preTreeNoCull!=mTreeNoCull) mTreeNoCull = !mTreeNoCull;
		if(!node.RenderBoundingVolume) return;
		GeomRenderer& GR(GeomRenderer::getSingleton());
		if(node.getBoundingVolume_WS()){
			Renderable r(GR.getRenderable(*(node.getBoundingVolume_WS()), GeomRender_Wire));
			RenderSystem::getSingleton().getRenderQueue_BVs().addRenderable(r);
		}
	}
	void NodeVisitor_Visibility_BoundVol::visit(SceneNode& node){ ; }
	void NodeVisitor_Visibility_BoundVol::visit(CameraNode& node){ ; }
	void NodeVisitor_Visibility_BoundVol::visit(LightNode& node){ ; }

	bool NodeVisitor_Visibility_BoundVol::isVisible(SceneNode& node){
		if(mTreeNoCull) return true;
		if(mCullVolume==0) return true;
		switch(node.mCullingMode){
			case SceneNode::CULL_ALWAYS:     return false;
			case SceneNode::CULL_NEVER:      return true;
			case SceneNode::CULL_NEVER_TREE: mTreeNoCull= true; return true;
			case SceneNode::CULL_DYNAMIC:{
				const GeomVolume* nodeVol = node.getBoundingVolume_WS();
				if(nodeVol==0) break;
				switch(GeomHelper::intersects(*mCullVolume,*nodeVol)){
					case GeomHelper::BoolQueryT: 
						// check if node volume is contained within the culling volume
						if(GeomHelper::contains(*mCullVolume,*nodeVol)==GeomHelper::BoolQueryT) mTreeNoCull = true;
						return true; // the node itself is visible
					case GeomHelper::BoolQueryF: return false;
					case GeomHelper::BoolQueryX: return true; // not implemented, assume visible
					case GeomHelper::BoolQueryU: return false; // not logical, assume visible anyway
				}};
		}
		return true;		
	}

} // namespace REng

