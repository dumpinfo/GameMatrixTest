/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomHelper.h"

#include "REng/Math.h"

#include <limits>
#include <iostream>

#include <boost/foreach.hpp>

using namespace std;

namespace REng {

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box1, const GeomAxisAlignedBox& box2){
		const Vector3& p1min(box1.getCorner(Corner_mXmYmZ));
		const Vector3& p1max(box1.getCorner(Corner_MXMYMZ));
		const Vector3& p2min(box2.getCorner(Corner_mXmYmZ));
		const Vector3& p2max(box2.getCorner(Corner_MXMYMZ));

		if(p1max[0] < p2min[0]) return BoolQueryF;
		if(p1max[1] < p2min[1]) return BoolQueryF;
		if(p1max[2] < p2min[2]) return BoolQueryF;
		if(p1min[0] > p2max[0]) return BoolQueryF;
		if(p1min[1] > p2max[1]) return BoolQueryF;
		if(p1min[2] > p2max[2]) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomLine& line){
		GeomRay ray1(line.getPosition(),line.getDirection());
		GeomRay ray2(line.getPosition(),-line.getDirection());
		if(intersects(ray1,box)==BoolQueryF) return BoolQueryF;
		if(intersects(ray2,box)==BoolQueryF) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomPlane& plane){
		return (GeomHelper::getSide(plane,box)==PlaneSide_Both)?BoolQueryT:BoolQueryF;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomPlaneBoundedVolume& planeVolume){
		// if the box falls completely to the outside of a plane in the volume, than box does not intersect the volume
		const GeomPlaneList& planeList(planeVolume.getPlaneList());
		BOOST_FOREACH(const GeomPlane& plane, planeList) if(getSide(plane,box)==PlaneSide_Negative) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomPoint& point){
		const Vector3& pmin(box.getCorner(Corner_mXmYmZ));
		const Vector3& pmax(box.getCorner(Corner_MXMYMZ));

		if( point[0] < pmin[0] ) return BoolQueryF;
		if( point[1] < pmin[1] ) return BoolQueryF;
		if( point[2] < pmin[2] ) return BoolQueryF;
		if( point[0] > pmax[0] ) return BoolQueryF;
		if( point[1] > pmax[1] ) return BoolQueryF;
		if( point[2] > pmax[2] ) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomRay& r){
		float t1, t2, tmp;
		float tfar = numeric_limits<float>::max( );
		float tnear = numeric_limits<float>::min( );
		GeomRay rNorm(r);
		rNorm.normalize();

		// check X slab
		if (rNorm.getDirection()[0] == 0) {
			if (rNorm.getPosition()[0] > box.getCorner(Corner_MXMYMZ)[0] || 
				 rNorm.getPosition()[0] < box.getCorner(Corner_mXmYmZ)[0])
				return BoolQueryF;	// ray is parallel to the planes & outside slab
		} else {
			tmp = 1.0 / rNorm.getDirection()[0];
			t1 = (box.getCorner(Corner_mXmYmZ)[0] - rNorm.getPosition()[0]) * tmp;
			t2 = (box.getCorner(Corner_MXMYMZ)[0] - rNorm.getPosition()[0]) * tmp;
			if (t1 > t2) {
				float swap=t1;
				t1=t2;
				t2=swap;
			}
			if (t1 > tnear) tnear = t1;
			if (t2 < tfar) tfar = t2;
			if (tnear > tfar || tfar < 0.0)
				return BoolQueryF;	// ray missed box or box is behind ray
		}
		// check Y slab
		if (rNorm.getDirection()[1] == 0) {
			if (rNorm.getPosition()[1] > box.getCorner(Corner_MXMYMZ)[1] || 
				 rNorm.getPosition()[1] < box.getCorner(Corner_mXmYmZ)[1])
				return BoolQueryF;	// ray is parallel to the planes & outside slab
		} else {
			tmp = 1.0 / rNorm.getDirection()[1];
			t1 = (box.getCorner(Corner_mXmYmZ)[1] - rNorm.getPosition()[1]) * tmp;
			t2 = (box.getCorner(Corner_MXMYMZ)[1] - rNorm.getPosition()[1]) * tmp;
			if (t1 > t2) {
				float swap=t1;
				t1=t2;
				t2=swap;
			}
			if (t1 > tnear) tnear = t1;
			if (t2 < tfar) tfar = t2;
			if (tnear > tfar || tfar < 0)
				return BoolQueryF;	// ray missed box or box is behind ray
		}
		// check Z slab
		if (rNorm.getDirection()[2] == 0) {
			if (rNorm.getPosition()[2] > box.getCorner(Corner_MXMYMZ)[2] || 
				 rNorm.getPosition()[2] < box.getCorner(Corner_mXmYmZ)[2])
				return BoolQueryF;	// ray is parallel to the planes & outside slab
		} else {
			tmp = 1.0 / rNorm.getDirection()[2];
			t1 = (box.getCorner(Corner_mXmYmZ)[2] - rNorm.getPosition()[2]) * tmp;
			t2 = (box.getCorner(Corner_MXMYMZ)[2] - rNorm.getPosition()[2]) * tmp;
			if (t1 > t2) {
				float swap=t1;
				t1=t2;
				t2=swap;
			}
			if (t1 > tnear) tnear = t1;
			if (t2 < tfar) tfar = t2;
			if (tnear > tfar || tfar < 0)
				return BoolQueryF;	// ray missed box or box is behind ray
		}
		return (tnear>0)?BoolQueryT:BoolQueryF;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& box, const GeomSphere& sphere){
		// Get the center of the sphere relative to the center of the box
		Vector3 sphereCenterRelBox = sphere.getPosition() - box.getPosition();
		// Point on surface of box that is closest to the center of the sphere
		Vector3 boxPoint;

		// Check sphere center against box along the X axis alone.
		// If the sphere is off past the left edge of the box,
		// then the left edge is closest to the sphere.
		// Similar if it's past the right edge. If it's between
		//	the left and right edges, then the sphere's own X
		// is closest, because that makes the X distance 0,
		// and you can't get much closer than that :)
		if (sphereCenterRelBox[0] < -box.getHalfSize()[0])
			boxPoint[0] = -box.getHalfSize()[0];
		else if (sphereCenterRelBox[0] > box.getHalfSize()[0])
			boxPoint[0] = box.getHalfSize()[0];
		else
			boxPoint[0] = sphereCenterRelBox[0];

		if (sphereCenterRelBox[1] < -box.getHalfSize()[1])
			boxPoint[1] = -box.getHalfSize()[1];
		else if (sphereCenterRelBox[1] > box.getHalfSize()[1])
			boxPoint[1] = box.getHalfSize()[1];
		else
			boxPoint[1] = sphereCenterRelBox[1];

		if (sphereCenterRelBox[2] < -box.getHalfSize()[2])
			boxPoint[2] = -box.getHalfSize()[2];
		else if (sphereCenterRelBox[2] > box.getHalfSize()[2])
			boxPoint[2] = box.getHalfSize()[2];
		else
			boxPoint[2] = sphereCenterRelBox[2];

		// Now we have the closest point on the box, so get the distance from
		// that to the sphere center, and see if it's less than the radius

		Vector3 dist = sphereCenterRelBox - boxPoint;

		if (dist[0]*dist[0] + dist[1]*dist[1] + dist[2]*dist[2] < sphere.getRadius()*sphere.getRadius())
			return BoolQueryT;
		else
			return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomLine& line, const GeomPlane& plane){
		if(std::abs(cml::dot(line.getDirection(),plane.getNormal())) < std::numeric_limits<float>::epsilon() )
			return BoolQueryT;
		return BoolQueryF;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomLine& line, const GeomSphere& sphere){
		GeomPoint center(sphere.getPosition());
		return (getDistance(center,line) > sphere.getRadius())?BoolQueryF:BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomOrientedBox& obox, const GeomRay& ray){
		GeomAxisAlignedBox aab(Vector3(0,0,0),obox.getHalfSize(),GeomAxisAlignedBox::Set_CenterHSize);

		Matrix4 matRot;
		Quaternion qua = obox.getWorldOrientation();
		qua = qua.inverse();
		cml::matrix_rotation_quaternion(matRot,qua);
		Vector3 rotatedPos = cml::transform_vector(matRot, ray.getPosition()-obox.getPosition());
		Vector3 rotatedDir = cml::transform_vector(matRot, ray.getDirection());

		return intersects(aab,GeomRay(rotatedPos,rotatedDir,false));
   }

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlane& plane, const GeomRay& ray){
		// from OGRE source
		float denom = cml::dot(plane.getNormal(),ray.getDirection());
		// Check if parallel
		if(!(std::abs(denom) < std::numeric_limits<float>::epsilon())) {
			float nom = cml::dot(plane.getNormal(), ray.getOrigin()) + plane.D();
			float t = -(nom/denom);
			if(t>=0) return BoolQueryT;
		}
		return BoolQueryF;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlane& plane, const GeomSphere& sphere){
		GeomPoint center(sphere.getPosition());
		return (getDistance(center,plane) > sphere.getRadius())?BoolQueryF:BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlaneBoundedVolume& planeVolume , const GeomPoint& point){
		const GeomPlaneList& planes(planeVolume.getPlaneList());
		BOOST_FOREACH(const GeomPlane& plane, planes) if(getSide(plane,point)==PlaneSide_Negative) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlaneBoundedVolume& planeVolume, const GeomSphere& sphere){
		const GeomPlaneList& planes(planeVolume.getPlaneList());
		GeomPoint center(sphere.getPosition());
		float radius = sphere.getRadius();
		BOOST_FOREACH(const GeomPlane& plane, planes){
			if(getSignedDistance(center, plane) < -radius) return BoolQueryF; // on the negative side of a bounding plane
		}
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomRay& ray, const GeomSphere& sphere){
		//! @see http://www.devmaster.net/wiki/Ray-sphere_intersection
		Vector3 dst = ray.getPosition()-sphere.getPosition();
		Vector3 rayDir(ray.getDirection());
		rayDir.normalize(); // a unit vector
		float B = cml::dot(dst,rayDir);
		float C = cml::dot(dst,dst) - sphere.getRadius()*sphere.getRadius();
		float D = B*B - C;
		if (D > 0)
			return BoolQueryT; /*-B - sqrt(D)*/
		else
			return BoolQueryF;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomPoint& point, const GeomSphere& sphere){
		GeomPoint center(sphere.getPosition());
		return (getDistance(center,point) > sphere.getRadius())?BoolQueryF:BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere1, const GeomSphere& sphere2){
		float center_distance = getDistance(sphere1.getPosition(),sphere2.getPosition());
		return (center_distance < (sphere1.getRadius() + sphere2.getRadius()))?BoolQueryT:BoolQueryF;
	}

	GeomAxisAlignedBox GeomHelper::getIntersection(
			const GeomAxisAlignedBox& box1, const GeomAxisAlignedBox& box2)
	{
		Vector3 p1min(box1.getCorner(Corner_mXmYmZ));
		Vector3 p1max(box1.getCorner(Corner_MXMYMZ));
		const Vector3& p2min(box2.getCorner(Corner_mXmYmZ));
		const Vector3& p2max(box2.getCorner(Corner_MXMYMZ));

		p1min.maximize(p2min);
		p1max.minimize(p2max);

      if( p1min[0] < p1max[0] && p1min[1] < p1max[1] && p1min[2] < p1max[2])
          return GeomAxisAlignedBox(p1min, p1max,GeomAxisAlignedBox::Set_MinMax);

		return GeomAxisAlignedBox( Vector3(0.0f,0.0f,0.0f), Vector3(0.0f,0.0f,0.0f),
			GeomAxisAlignedBox::Set_CenterHSize);
	}

}
