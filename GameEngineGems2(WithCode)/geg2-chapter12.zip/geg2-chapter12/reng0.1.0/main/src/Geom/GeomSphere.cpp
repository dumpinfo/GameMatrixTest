/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomSphere.h"

#include "REng/Math.h"

using namespace cml;
/************************************************************************/
/* GEOM SPHERE                                                          */
/************************************************************************/

namespace REng{
	GeomSphere::GeomSphere()
		: mRadius(1.0f){ ; }
	GeomSphere::GeomSphere(float _radius)
		: mRadius(_radius) { ; }
	GeomSphere::GeomSphere(const Vector3& _pos, float _radius)
		: GeomVolume(_pos), mRadius(_radius) { ; }
	GeomType GeomSphere::getType() const {
		return GeomTypeSphere;
	}
	void GeomSphere::setPosition(const Vector3& _pos){
		mPosition = _pos;
	}
	void GeomSphere::setRadius(float _radius){
		mRadius = _radius;
	}
	void GeomSphere::setGeom(const Vector3& _pos, float _radius){
		mPosition = _pos;
		mRadius = _radius;
	}
	float GeomSphere::getRadius() const{
		return mRadius;
	}
	float GeomSphere::getVolume() const{
		static float cache = 4.0f*Math::PI/3.0f;
		return cache*mRadius*mRadius*mRadius;
	}
	void GeomSphere::scale(const Vector3& vec){
		float maxVal(vec[0]);
		if(maxVal<vec[1]) maxVal = vec[1];
		if(maxVal<vec[2]) maxVal = vec[2];
		scale(maxVal);
	}
	void GeomSphere::scale(float ratio){
		mRadius *= ratio;
	}
	void GeomSphere::rotate_World(const Quaternion& qua){
		return;
	}

}
