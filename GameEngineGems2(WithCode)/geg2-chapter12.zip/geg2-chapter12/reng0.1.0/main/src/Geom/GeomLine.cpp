/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomLine.h"

namespace REng{

	GeomLine::GeomLine(): mDirection(Vector3(1,0,0)){};
	GeomLine::GeomLine(const Vector3 &p1, const Vector3 &p2, bool funcType){
		setGeom(p1,p2,funcType);
	}

	bool GeomLine::canRotate() {
		return true;
	};
	bool GeomLine::canScale() {
		return false;
	};
	bool GeomLine::canTranslate() {
		return true;
	};
	GeomType GeomLine::getType() const {
		return GeomTypeLine;
	};

	void GeomLine::normalize(){
		mDirection.normalize();
	}

	const Vector3& GeomLine::getDirection() const {
		return mDirection;
	};

	GeomPoint GeomLine::getPoint(float u) const{
		return GeomPoint(mPosition + u*cml::normalize(mDirection));
	}

	void GeomLine::setPosition(const Vector3& pos){
		mPosition = pos;
	}
	void GeomLine::setDirection(const Vector3& p1, bool funcType){
		if(funcType) {
			mDirection=p1-mPosition;
		} else {
			mDirection=p1;
		}
		normalize();
	}
	void GeomLine::setGeom(const Vector3& p1, const Vector3& p2, bool funcType){
		mPosition=p1;
		setDirection(p2,funcType);
		normalize();
	}


	void GeomLine::rotate_World(const Quaternion& qua){
		Matrix4 matRot;
		matrix_rotation_quaternion(matRot,qua);
		mDirection = transform_vector(matRot, mDirection);
        normalize();
	}
}
