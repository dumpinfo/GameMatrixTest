/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomHelper.h"
#include "REng/Math.h"

#include <boost/foreach.hpp>

#include <limits>
#include <iostream>

using namespace std;

namespace REng {

	bool GeomHelper::getRayIntersect(const GeomRay& ray, const GeomTri& tri, float& dist) {
		const REng::Vector3& triNorm(tri.getNormal());
		float denom = cml::dot(triNorm,ray.getDirection());

		// If line is parallel to plane of the triangle
		if(denom < std::numeric_limits<float>::epsilon() && denom > std::numeric_limits<float>::epsilon()) {
			return false;
		}

		// t represents the intersection point between the ray and the plane of triangle
		float t = cml::dot(triNorm,tri.getP1() - ray.getOrigin()) / denom;

		// Intersection is on the other side of the ray
		if(t < 0){
			return false;
		}

		// Calculate the largest area projection plane in X, Y or Z.
		float n0 = std::abs(triNorm[0]);
		float n1 = std::abs(triNorm[1]);
		float n2 = std::abs(triNorm[2]);

		size_t i0 = 1, i1 = 2;
		if (n1 > n2 && n1 > n0) {
			i0 = 0;
		}
		else if (n2 > n0) i1 = 0;

		// Check the intersection point is inside the triangle.
		{
			const REng::GeomPoint& a(tri.getP1());
			const REng::GeomPoint& b(tri.getP2());
			const REng::GeomPoint& c(tri.getP3());
			float u1 = b[i0] - a[i0];
			float v1 = b[i1] - a[i1];
			float u2 = c[i0] - a[i0];
			float v2 = c[i1] - a[i1];
			float u0 = t * ray.getDirection()[i0] + ray.getOrigin()[i0] - a[i0];
			float v0 = t * ray.getDirection()[i1] + ray.getOrigin()[i1] - a[i1];

			float alpha = u0 * v2 - u2 * v0;
			float beta  = u1 * v0 - u0 * v1;
			float area  = u1 * v2 - u2 * v1;

			// epsilon to avoid float precision error
			const float EPSILON = 1e-6f;

			float tolerance = - EPSILON * area;

			if (area > 0) {
				if (alpha < tolerance || beta < tolerance || alpha+beta > area-tolerance)
					return false;
			} else {
				if (alpha > tolerance || beta > tolerance || alpha+beta < area-tolerance)
					return false;
			}
		}
		dist = t;
		return true;
	}

	bool GeomHelper::getRayIntersect(const GeomRay& ray, const GeomAxisAlignedBox& aab, float& dist){
		// Taken partly from OGRE source code

		Vector3 hitpoint;
		const Vector3& aabMin = aab.getCorner(Corner_mXmYmZ);
		const Vector3& aabMax = aab.getCorner(Corner_MXMYMZ);
		const Vector3& rayOrig = ray.getOrigin();
		const Vector3& rayDir = ray.getDirection();

		// Check origin inside first
		if(intersects(aab,rayOrig)){ dist = 0; return true; }

		float lowt = 0.0f;
		float t=0.0f;
		bool hit = false;
		bool _check;

		// Only checks closest faces in 3 orientations

		// Min x - else - Max x
		if(rayOrig[0] <= aabMin[0] && rayDir[0] > 0) {
			t = (aabMin[0] - rayOrig[0]) / rayDir[0]; _check=true;
		} else if(rayOrig[0] >= aabMax[0] && rayDir[0] < 0) {
			t = (aabMax[0] - rayOrig[0]) / rayDir[0]; _check=true;
		} else _check = false;
		if(t>=0&&_check){
			hitpoint = rayOrig + rayDir*t;
			if(hitpoint[1] >= aabMin[1] && hitpoint[1] <= aabMax[1] &&
				hitpoint[2] >= aabMin[2] && hitpoint[2] <= aabMax[2])
			{ if(!hit || t<lowt) { hit=true; lowt=t; } }
		}
		
		// Min y - else - Max y
		if(rayOrig[1] <= aabMin[1] && rayDir[1] > 0) {
			t = (aabMin[1] - rayOrig[1]) / rayDir[1]; _check=true;
		} else if(rayOrig[1] >= aabMax[1] && rayDir[1] < 0) {
			t = (aabMax[1] - rayOrig[1]) / rayDir[1]; _check=true;
		} else _check=false;
		if(t>=0&&_check) {
			hitpoint = rayOrig + rayDir*t;
			if(hitpoint[0] >= aabMin[0] && hitpoint[0] <= aabMax[0] &&
				hitpoint[2] >= aabMin[2] && hitpoint[2] <= aabMax[2])
			{ if(!hit || t<lowt) { hit=true; lowt=t; } }
		}

		// Min z - else - Max z
		if(rayOrig[2] <= aabMin[2] && rayDir[2] > 0) {
			t = (aabMin[2] - rayOrig[2]) / rayDir[2]; _check=true;
		} else if(rayOrig[2] >= aabMax[2] && rayDir[2] < 0) {
			t = (aabMax[2] - rayOrig[2]) / rayDir[2]; _check=true;
		} else _check = false;
		if(t>=0&&_check) {
			hitpoint = rayOrig + rayDir*t;
			if(hitpoint[0] >= aabMin[0] && hitpoint[0] <= aabMax[0] &&
				hitpoint[1] >= aabMin[1] && hitpoint[1] <= aabMax[1])
			{ if(!hit || t<lowt) { hit=true; lowt=t; } }
		}

		if(hit) dist = lowt;
		return hit;
	}

	bool GeomHelper::getRayIntersect(const GeomRay& ray, const GeomPlane& plane, float& dist){
		// from OGRE source
		float denom = cml::dot(plane.getNormal(),ray.getDirection());
		// Check if parallel
		if(!(std::abs(denom) < std::numeric_limits<float>::epsilon())) {
			float nom = cml::dot(plane.getNormal(), ray.getOrigin()) + plane.D();
			float t = -(nom/denom);
			if(t>=0) {
				dist = t;
				return true;
			}
		}
		return false;
	}
	bool GeomHelper::getRayIntersect(const GeomRay& ray, 
		const GeomPlaneBoundedVolume& convexVol, float& dist)
	{
		bool rayInside = true;

		std::pair<bool, float> ret;
		std::pair<bool, float> end;
		ret.first = false;
		ret.second = 0.0f;
		end.first = false;
		end.second = 0;

		// derive side
		// NB we don't pass directly since that would require Plane::Side in 
		// interface, which results in recursive includes since Math is so fundamental
//		Plane::Side outside = normalIsOutside ? Plane::POSITIVE_SIDE : Plane::NEGATIVE_SIDE;

		const GeomPlaneList& planeList(convexVol.getPlaneList());
		BOOST_FOREACH(const GeomPlane& plane,planeList){
			// ray origin is in the normal-directed half-space
			if(getSide(plane,ray.getOrigin())==PlaneSide_Positive) {
				rayInside = false;
				// Test single plane
				float dist;
				if(GeomHelper::getRayIntersect(ray,plane,dist)) {
					// Ok, we intersected
					ret.first = true;
					// Use the most distant result since convex volume
					ret.second = Math::max(ret.second, dist);
				} else {
					// no intersection, ray points outside the volume
					return false;
				}
			} else {
				float dist;
				if(GeomHelper::getRayIntersect(ray,plane,dist)) {
					if(!end.first) {
						end.first = true;
						end.second = dist;
					} else {
						end.second = Math::min( end.second, dist);
					}
				}
			}
		}

		if(rayInside){ dist = 0.0f; return true; }

		if(end.first) {
			if( end.second < ret.second ) {
				return false;
			}
		}
		if(ret.first==true){ dist = ret.second; return true;}
		return false;
	}


	/************************************************************************/
	/* CONTAINMENT TESTS                                                    */
	/************************************************************************/
	GeomHelper::BoolQuery GeomHelper::contains(const GeomAxisAlignedBox& box1, const GeomAxisAlignedBox& box2){
		const Vector3& p1min(box1.getCorner(Corner_mXmYmZ));
		const Vector3& p1max(box1.getCorner(Corner_MXMYMZ));
		const Vector3& p2min(box2.getCorner(Corner_mXmYmZ));
		const Vector3& p2max(box2.getCorner(Corner_MXMYMZ));

		if(p1min[0] > p2min[0]) return BoolQueryF; 
		if(p1min[1] > p2min[1]) return BoolQueryF;
		if(p1min[2] > p2min[2]) return BoolQueryF;
		if(p2max[0] > p1max[0]) return BoolQueryF;
		if(p2max[1] > p1max[1]) return BoolQueryF;
		if(p2max[2] > p1max[2]) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::contains(const GeomAxisAlignedBox& box, const GeomSphere& sphere){
		Vector3 boxHalfSize = box.getHalfSize();
		Vector3 sphereCenterRelBox = sphere.getPosition() - box.getPosition();

		sphereCenterRelBox[0] = abs(sphereCenterRelBox[0]);
		sphereCenterRelBox[1] = abs(sphereCenterRelBox[1]);
		sphereCenterRelBox[2] = abs(sphereCenterRelBox[2]);

		if(sphereCenterRelBox[0] + sphere.getRadius() >= boxHalfSize[0]) return BoolQueryF;
		if(sphereCenterRelBox[1] + sphere.getRadius() >= boxHalfSize[1]) return BoolQueryF;
		if(sphereCenterRelBox[2] + sphere.getRadius() >= boxHalfSize[2]) return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::contains(const GeomPlaneBoundedVolume& planeVolume, const GeomAxisAlignedBox& box){
		const GeomPlaneList& planeList(planeVolume.getPlaneList());
		BOOST_FOREACH(const GeomPlane& plane, planeList) if(getSide(plane,box)!=PlaneSide_Positive) return BoolQueryF;
		// the box is in the positive side for all of the planes
		return BoolQueryT;
	}
	GeomHelper::BoolQuery GeomHelper::contains(const GeomPlaneBoundedVolume& planeVolume, const GeomSphere& sphere){
		const GeomPlaneList& planes(planeVolume.getPlaneList());
		GeomPoint center(sphere.getPosition());
		float radius = sphere.getRadius();
		BOOST_FOREACH(const GeomPlane& plane, planes){
			if(getSignedDistance(center, plane) < radius) return BoolQueryF;
		}
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::contains(const GeomSphere& sphere,const GeomAxisAlignedBox& box){
		Vector3 boxHalfSize = box.getHalfSize();
		Vector3 boxCenterRelSphere = box.getPosition() - sphere.getPosition();
		boxCenterRelSphere[0] = abs(boxCenterRelSphere[0]);
		boxCenterRelSphere[1] = abs(boxCenterRelSphere[1]);
		boxCenterRelSphere[2] = abs(boxCenterRelSphere[2]);

		if(sphere.getRadius() < boxCenterRelSphere[0] + boxHalfSize[0])
			return BoolQueryF;
		if(sphere.getRadius() < boxCenterRelSphere[1] + boxHalfSize[1])
			return BoolQueryF;
		if(sphere.getRadius() < boxCenterRelSphere[2] + boxHalfSize[2])
			return BoolQueryF;
		return BoolQueryT;
	}

	GeomHelper::BoolQuery GeomHelper::contains(const GeomSphere& sphere1, const GeomSphere& sphere2){
		Vector3 sphere2RelSphere1 = sphere2.getPosition() - sphere1.getPosition();
		sphere2RelSphere1[0] = abs(sphere2RelSphere1[0]);
		sphere2RelSphere1[1] = abs(sphere2RelSphere1[1]);
		sphere2RelSphere1[2] = abs(sphere2RelSphere1[2]);
		return (length(sphere2RelSphere1) + sphere2.getRadius() > sphere1.getRadius())?BoolQueryF:BoolQueryT;
	}

	/************************************************************************/
	/* MERGING BOUNDING VOLUMES                                             */
	/************************************************************************/

	// The second parameter is merged into the geom of the first parameter.

	void GeomHelper::mergeBounding(GeomAxisAlignedBox& box, const GeomAxisAlignedBox& boxExtend){
		Vector3 p1min(box.getCorner(Corner_mXmYmZ));
		Vector3 p1max(box.getCorner(Corner_MXMYMZ));

		p1min.minimize(boxExtend.getCorner(Corner_mXmYmZ));
		p1max.maximize(boxExtend.getCorner(Corner_MXMYMZ));
		box.setGeom(p1min, p1max,GeomAxisAlignedBox::Set_MinMax);
	}
	void GeomHelper::mergeBounding(GeomAxisAlignedBox& box, const GeomPoint& point){
		Vector3 p1min(box.getCorner(Corner_mXmYmZ));
		Vector3 p1max(box.getCorner(Corner_MXMYMZ));

		p1min.minimize(point);
		p1max.maximize(point);
		box.setGeom(p1min, p1max,GeomAxisAlignedBox::Set_MinMax);
	}

	void GeomHelper::mergeBounding(GeomSphere& sphere, const GeomAxisAlignedBox& box){
		//float max=sqrt(box.getHalfSize()[0]*box.getHalfSize()[0]+box.getHalfSize()[1]*box.getHalfSize()[1]+box.getHalfSize()[2]*box.getHalfSize()[2]);
		float max=box.getHalfSize()[0];
		if(max<box.getHalfSize()[1])
			max=box.getHalfSize()[1];
		if(max<box.getHalfSize()[2])
			max=box.getHalfSize()[2];
		sphere.setGeom(box.getPosition(),max);
	}

	void GeomHelper::mergeBounding(GeomSphere& sphere, const GeomSphere& sphereExtend){
		if(contains(sphere,sphereExtend)) return;
		Vector3 center;
		Vector3 sphereRelSphereExtend = sphere.getPosition() - sphereExtend.getPosition();
		float radius = sphere.getRadius() + sphereExtend.getRadius()
						+ length(sphereRelSphereExtend);

		center = sphere.getPosition() +
			(sphereRelSphereExtend * (radius - sphere.getRadius())/ (length(sphereRelSphereExtend)));
		sphere.setGeom(center, radius);
		return;
	}

	/************************************************************************/
	/* MISC                                                                 */
	/************************************************************************/

	void GeomHelper::generateBoundingBox(GeomAxisAlignedBox& aab, const GeomOrientedBox& ob){
		Vector3 pMin(ob.getCorners()[0]);
		Vector3 pMax(ob.getCorners()[0]);

		pMin.minimize(ob.getCorners()[1]);
		pMax.maximize(ob.getCorners()[1]);
		pMin.minimize(ob.getCorners()[2]);
		pMax.maximize(ob.getCorners()[2]);
		pMin.minimize(ob.getCorners()[3]);
		pMax.maximize(ob.getCorners()[3]);
		pMin.minimize(ob.getCorners()[4]);
		pMax.maximize(ob.getCorners()[4]);
		pMin.minimize(ob.getCorners()[5]);
		pMax.maximize(ob.getCorners()[5]);
		pMin.minimize(ob.getCorners()[6]);
		pMax.maximize(ob.getCorners()[6]);
		pMin.minimize(ob.getCorners()[7]);
		pMax.maximize(ob.getCorners()[7]);

		aab.setGeom(pMin, pMax,GeomAxisAlignedBox::Set_MinMax);
	}


	/************************************************************************/
	/* Get Distance Squared                                                 */
	/************************************************************************/

	float GeomHelper::getDistanceSquared(const GeomLine& line, const GeomPoint& point){
		Vector3 lpoint1 = line.getPosition();
		Vector3 lpoint2 = lpoint1 + line.getDirection() ;

		Vector3 BA = (lpoint2 - lpoint1);
		Vector3 PA = (point - lpoint1);

		// dist = BA (cross) PA / sqrt ( BA (dot) BA)
		return Math::sqr(cml::length((cml::cross(BA,PA))/sqrt(cml::dot(BA,BA))));
	}
	float GeomHelper::getDistanceSquared(const GeomPoint& point, const GeomPlane& plane){
		Vector3 lpoint1 = plane.getPosition();
		Vector3 ldirection = plane.getNormal() ;

		Vector3 v = ldirection;
		Vector3 w = -(lpoint1 - point);

		float abs_projection = Math::abs(cml::dot(v,w))/cml::length(w);
		return Math::sqr(abs_projection);
	}
	float GeomHelper::getSignedDistance(const GeomPoint& point, const GeomPlane& plane){
		return (cml::dot(point,plane.ABC())+plane.D())/cml::length(plane.ABC());
	}

	/************************************************************************/
	/* Get Side                                                             */
	/************************************************************************/

	GeomHelper::PlaneSide GeomHelper::getSide(const GeomPlane& plane, const GeomAxisAlignedBox& aabox){
		const Vector3& normal(plane.getNormal());
		const Vector3& hs(aabox.getHalfSize());
		float dist    = cml::dot(plane.ABC(),aabox.getPosition())+plane.D();
		float maxDist = Math::abs(normal[0]*hs[0])+Math::abs(normal[1]*hs[1])+Math::abs(normal[2]*hs[2]);

		if(dist<-maxDist) return PlaneSide_Negative;
		if(dist>+maxDist) return PlaneSide_Positive;
		return PlaneSide_Both;
	}
	GeomHelper::PlaneSide GeomHelper::getSide(const GeomPlane& plane, const GeomPoint& point){
		float dist = cml::dot(plane.ABC(),point)+plane.D();
		if(dist<0.0) return PlaneSide_Negative;
		if(dist>0.0) return PlaneSide_Positive;
		return PlaneSide_On;
	}

} // namespace REng
