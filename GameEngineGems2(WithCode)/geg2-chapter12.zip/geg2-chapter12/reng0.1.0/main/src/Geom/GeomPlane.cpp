/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Geom/GeomPlane.h"

using namespace cml;

/************************************************************************/
/* GEOM PLANE                                                           */
/************************************************************************/

namespace REng{
	GeomPlane::GeomPlane() : Geom(Vector3(0,0,1)), mD(0) {}
	GeomPlane::GeomPlane(const Vector3& _pos, const Vector3& _normal){
		setGeom(_pos, _normal);
	}
	GeomPlane::GeomPlane(const Vector3& p1, const Vector3& p2, const Vector3& p3){
		setGeom(p1,p2,p3);
	}
	GeomPlane::GeomPlane(const Vector3& _normal, float distance){
		setGeom(_normal,distance);
	}

	bool GeomPlane::canRotate() {
		return true;
	};
	bool GeomPlane::canScale() {
		return false;
	};
	bool GeomPlane::canTranslate() {
		return true;
	};
	GeomType GeomPlane::getType() const {
		return GeomTypePlane;
	}

	const Vector3& GeomPlane::getNormal() const{
		return mPosition;
	}
	float GeomPlane::getDistanceFromOrigin() const{
		return -mD;
	}
	const Vector3& GeomPlane::ABC() const{
		return mPosition;
	}
	float GeomPlane::D() const{
		return mD;
	}
	Vector3 GeomPlane::getBasePoint() const {
		return mPosition*-mD;
	}

	void GeomPlane::setGeom(const Vector3& _normal, float _distance){
		mPosition = _normal;
		mD = -_distance;
		mPosition.normalize();
	}
	void GeomPlane::setGeom(const Vector3& _pos, const Vector3& _normal){
		mPosition = _normal;
		mPosition.normalize();
		mD = -(cml::dot(_pos,mPosition));
	}

	void GeomPlane::setGeom(const Vector3& p1, const Vector3& p2, const Vector3& p3){
		Vector3 p21(p1-p2); // line from p2 to p1
		Vector3 p23(p3-p2); // line from p2 to p3
		mPosition = cml::cross(p21,p23).normalize();
		mD = -(cml::dot(p2,mPosition));
	}

	void GeomPlane::translate_World(const Vector3& vec){
		// Note: The normal of the plane does not change, but distance to origin changes!
		// Haha, this one turns out to be simple
		mD -= cml::dot(vec,mPosition);
	}

	void GeomPlane::rotateAroundOrigin(const Quaternion& qua){
		// Note: The normal of the plane changes, but distance to origin does not change!
		Vector3 _axis;
		float   _angle;
		cml::quaternion_to_axis_angle(qua,_axis,_angle);
		cml::rotate_vector(mPosition,_axis,_angle);
	}

	void GeomPlane::rotate_World(const Quaternion& qua){
		// both the normal and distance changes
		// 1. Remember the point on the plane that will not move
		const Vector3& bp(getBasePoint());
		// 1. assume that we are rotating wrt world center
		rotateAroundOrigin(qua);
		// 2. but we were rotating wrt the base point, so move your plane by changing distance variable
		mD = -(bp[0]*mPosition[0] + bp[1]*mPosition[1] + bp[2]*mPosition[2]);
	}
}
