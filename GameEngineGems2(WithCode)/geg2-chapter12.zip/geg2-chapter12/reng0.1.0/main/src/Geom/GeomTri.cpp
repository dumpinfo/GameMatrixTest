/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomTri.h"

namespace REng{

	// Constructs a triangle from points (0,0,0), (0,0,1) and (0,1,0)
	GeomTri::GeomTri() : Geom(Vector3(0,0,0)) , mPoint2(0,0,1), mPoint3(0,1,0) { ; }
	GeomTri::GeomTri(const GeomPoint& p1, const GeomPoint& p2, const GeomPoint& p3){
		setGeom(p1,p2,p3);
	}

	bool GeomTri::canRotate(){ 
		return true;
	}
	bool GeomTri::canScale(){ 
		return true;
	}
	bool GeomTri::canTranslate(){ 
		return true;
	}
	GeomType GeomTri::getType() const{ 
		return GeomTypeTri;
	}

	Vector3 GeomTri::getNormal() const{
		return cml::cross(getP2()- getP1(),getP3() - getP1());
	}

	const Vector3& GeomTri::getP1() const {
		return mPosition;
	}
	const Vector3& GeomTri::getP2() const {
		return mPoint2;
	}
	const Vector3& GeomTri::getP3() const {
		return mPoint3;
	}

	void GeomTri::rewind(){
		GeomPoint p = mPoint2;
		mPoint2 = mPoint3;
		mPoint3 = p;
	}

	void GeomTri::setGeom(const GeomPoint& p1, const GeomPoint& p2, const GeomPoint& p3){
		mPosition = p1;
		mPoint2   = p2;
		mPoint3   = p3;
	}

} // namespace REng

