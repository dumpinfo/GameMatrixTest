/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomCapsule.h"

#include "REng/Math.h"

namespace REng{
	GeomCapsule::GeomCapsule() : mHeight(1.0f), mRadius(1.0f){ ; }
	GeomCapsule::GeomCapsule(float h, float r) : mHeight(h), mRadius(r) { ; }
	GeomCapsule::GeomCapsule(float h, float r, const Vector3& pos)
		: GeomVolume(pos),mHeight(h), mRadius(r) { ; }
	GeomType GeomCapsule::getType() const {
		return GeomTypeCapsule; 
	}

	void GeomCapsule::setHeight(float h){
		mHeight = h;
	}
	void GeomCapsule::setRadius(float r){
		mRadius = r;
	}
	void GeomCapsule::setPosition(const Vector3& pos){
		mPosition = pos;
	}
	float GeomCapsule::getHeight() const{
		return mHeight;
	}
	float GeomCapsule::getRadius() const{
		return mRadius;
	}
	float GeomCapsule::getVolume() const{
		return Math::PI*mRadius*mRadius*mHeight;
	}

	bool GeomCapsule::canRotate(){
		return true;
	}
	bool GeomCapsule::canScale(){
		return true;
	}
	bool GeomCapsule::canTranslate(){
		return true;
	}

	void GeomCapsule::rotate_World(const Quaternion& qua){
	    /**
         * @note To have an OpenGL like rotate, (rotate position of the cylinder
         * according to origin) uncomment this code block.
         * @remark Since GeomCylinder representation has no rotation quaternion
         * to hold orientation information, its orientation cannot be changed.
         */
		/*Matrix4 matRot;
		cml::matrix_rotation_quaternion(matRot,qua);
		mPosition = cml::transform_vector(matRot, mPosition);*/
	}
	void GeomCapsule::scale(const Vector3& vec){
		float minVal(vec[0]);
		if(minVal>vec[1]) minVal = vec[1];
		mRadius *= minVal;
		mHeight *= vec[2];
	}
}
