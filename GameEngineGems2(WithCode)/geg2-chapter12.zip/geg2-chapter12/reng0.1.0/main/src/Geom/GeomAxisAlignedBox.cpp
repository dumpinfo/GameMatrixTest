/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Geom/GeomAxisAlignedBox.h"

using namespace cml;

/************************************************************************/
/* GEOM AXIS ALIGNED BOX                                                */
/************************************************************************/


namespace REng{
	const GeomAxisAlignedBox BOX_UNIT();

	const GeomAxisAlignedBox BOX_NULL(); // TODO
	const GeomAxisAlignedBox BOX_INFINITE(); // TODO

	GeomAxisAlignedBox::GeomAxisAlignedBox(){ 
		mPosition.set(0,0,0);  
		mHalfSize.set(1,1,1);
	}
	GeomAxisAlignedBox::GeomAxisAlignedBox(const Vector3& v1, const Vector3& v2, SetFunc funcType){
		setGeom(v1,v2, funcType);
	}
	GeomType GeomAxisAlignedBox::getType() const {
		return GeomTypeAABox;
	}
	bool GeomAxisAlignedBox::canRotate(){ 
		return true;
	}
	bool GeomAxisAlignedBox::canScale(){
		return true;
	}
	bool GeomAxisAlignedBox::canTranslate(){
		return true;
	}

	const GeomPoint& GeomAxisAlignedBox::getCorner(CornerTypeAAB corner) const{
		if(mCornersDirty) updateCorners();
		return mCorners_cache[corner];
	}

	float GeomAxisAlignedBox::get(BoundTypeAAB b) const{
		if(mCornersDirty) updateCorners();
		switch(b){
			case BoundAABMinX: return mCorners_cache[0][0];
			case BoundAABMaxX: return mCorners_cache[7][0];
			case BoundAABMinY: return mCorners_cache[0][1];
			case BoundAABMaxY: return mCorners_cache[7][1];
			case BoundAABMinZ: return mCorners_cache[0][2];
			case BoundAABMaxZ: return mCorners_cache[7][2];
		}
		// make compiler happy
		return 0.0f;
	}
	void GeomAxisAlignedBox::updateCorners() const{
		float minX = mPosition[0]-mHalfSize[0];
		float maxX = mPosition[0]+mHalfSize[0];
		float minY = mPosition[1]-mHalfSize[1];
		float maxY = mPosition[1]+mHalfSize[1];
		float minZ = mPosition[2]-mHalfSize[2];
		float maxZ = mPosition[2]+mHalfSize[2];
		// 0 : Corner_mXmYmZ
		mCorners_cache[0] = Vector3(minX,minY,minZ);
		// 1 : Corner_mXmYMZ
		mCorners_cache[1] = Vector3(minX,minY,maxZ);
		// 2 : Corner_mXMYmZ
		mCorners_cache[2] = Vector3(minX,maxY,minZ);
		// 3 : Corner_mXMYMZ
		mCorners_cache[3] = Vector3(minX,maxY,maxZ);
		// 4 : Corner_MXmYmZ
		mCorners_cache[4] = Vector3(maxX,minY,minZ);
		// 5 : Corner_MXmYMZ
		mCorners_cache[5] = Vector3(maxX,minY,maxZ);
		// 6 : Corner_MXMYmZ
		mCorners_cache[6] = Vector3(maxX,maxY,minZ);
		// 7 : Corner_MXMYMZ
		mCorners_cache[7] = Vector3(maxX,maxY,maxZ);
		mCornersDirty = false;
	}
	void GeomAxisAlignedBox::setGeom(const Vector3& v1, const Vector3& v2, SetFunc funcType){
		if(funcType == Set_CenterHSize){
			mPosition = v1;
			mHalfSize = v2;
		} else {
			mPosition = (v1+v2)/2.0f;
			mHalfSize = v2 - mPosition; // v2 is the maximum-corner, so half-size is all-positive.
		}
		mCornersDirty=true;
	}
	void GeomAxisAlignedBox::set(BoundTypeAAB b, float val){
		switch(b){
			case BoundAABMinX:
				mPosition[0] = (val+get(BoundAABMaxX))/2.0f;
				mHalfSize[0] = mPosition[0] - val;
				break;
			case BoundAABMaxX: 
				mPosition[0] = (val+get(BoundAABMinX))/2.0f;
				mHalfSize[0] = val - mPosition[0];
				break;
			case BoundAABMinY: 
				mPosition[1] = (val+get(BoundAABMaxY))/2.0f;
				mHalfSize[1] = mPosition[1] - val;
				break;
			case BoundAABMaxY: 
				mPosition[1] = (val+get(BoundAABMinY))/2.0f;
				mHalfSize[1] = val - mPosition[1];
				break;
			case BoundAABMinZ: 
				mPosition[2] = (val+get(BoundAABMaxZ))/2.0f;
				mHalfSize[2] = mPosition[2] - val;
				break;
			case BoundAABMaxZ: 
				mPosition[2] = (val+get(BoundAABMinZ))/2.0f;
				mHalfSize[2] = val - mPosition[2];
				break;
		}
		mCornersDirty=true;
	}
	void GeomAxisAlignedBox::translate_World(const Vector3& vec){
		mPosition += vec;
		mCornersDirty = true;
	}
	void GeomAxisAlignedBox::rotate_World(const Quaternion& qua){
		Matrix4 transformM;
		cml::matrix_rotation_quaternion(transformM,qua);

		Vector3 boundPoints[8];
		boundPoints[0].set( -mHalfSize[0],-mHalfSize[1],+mHalfSize[2] );
		boundPoints[1].set( -mHalfSize[0],-mHalfSize[1],-mHalfSize[2] );
		boundPoints[2].set( -mHalfSize[0],+mHalfSize[1],+mHalfSize[2] );
		boundPoints[3].set( -mHalfSize[0],+mHalfSize[1],-mHalfSize[2] );
		boundPoints[4].set( +mHalfSize[0],-mHalfSize[1],+mHalfSize[2] );
		boundPoints[5].set( +mHalfSize[0],-mHalfSize[1],-mHalfSize[2] );
		boundPoints[6].set( +mHalfSize[0],+mHalfSize[1],+mHalfSize[2] );
		boundPoints[7].set( +mHalfSize[0],+mHalfSize[1],-mHalfSize[2] );

		mHalfSize = cml::transform_point(transformM,boundPoints[0]);
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[1]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[2]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[3]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[4]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[5]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[6]));
		mHalfSize.maximize(cml::transform_point(transformM,boundPoints[7]));
		mCornersDirty = true;
	}
	void GeomAxisAlignedBox::scale(const Vector3& vec){
		mHalfSize = cml::comp_product(vec, mHalfSize);
		mCornersDirty = true;
	}
	void GeomAxisAlignedBox::scale(float s){
		mHalfSize *= s;
		mCornersDirty = true;
	}

}
