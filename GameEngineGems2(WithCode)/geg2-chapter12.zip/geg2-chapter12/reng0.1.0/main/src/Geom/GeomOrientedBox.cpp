/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomOrientedBox.h"

/************************************************************************/
/* GEOM ORIENTED BOX                                                    */
/************************************************************************/

namespace REng{
	GeomOrientedBox::GeomOrientedBox() {
		mWorldOrientation.identity();
	}
	GeomOrientedBox::GeomOrientedBox(const Vector3& v1, const Vector3& v2, const Quaternion& orient) {
		setGeom(v1,v2,orient);
	}
	const Quaternion& GeomOrientedBox::getWorldOrientation() const{
		return mWorldOrientation;
	}
	GeomType GeomOrientedBox::getType() const{
		return GeomTypeOBox;
	}
	bool GeomOrientedBox::canRotate() {
		return true;
	};
	bool GeomOrientedBox::canScale() {
		return true;
	};
	bool GeomOrientedBox::canTranslate() {
		return true;
	};


	void GeomOrientedBox::setGeom(const Vector3& v1, const Vector3& v2, const Quaternion& orient){
		mPosition = v1;
		mHalfSize = v2;
		mWorldOrientation = orient;
		mCornersDirty = true;
	}
    //! @todo implement updateCorners.
	void GeomOrientedBox::updateCorners() const{
		mCornersDirty = false;
	}
	void GeomOrientedBox::translate_World(const Vector3& vec){
			mPosition += vec;
/*		} else { // ts == GeomTS_Local
			// translate_World wrt current orientation
			Matrix4 matRot;
			cml::matrix_rotation_quaternion(matRot,mWorldOrientation);
			mPosition += cml::transform_vector(matRot, vec);
		}*/
		mCornersDirty = true;
	}
	void GeomOrientedBox::rotate_World(const Quaternion& qua){
		mWorldOrientation = mWorldOrientation * qua;
		mCornersDirty = true;
	}
	void GeomOrientedBox::scale(const Vector3& vec){
		mHalfSize = cml::comp_product(vec, mHalfSize);
		mCornersDirty = true;
	}
}
