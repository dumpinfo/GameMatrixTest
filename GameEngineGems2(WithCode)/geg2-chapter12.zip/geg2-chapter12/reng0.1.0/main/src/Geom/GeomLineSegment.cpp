/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomLineSegment.h"

namespace REng{

	GeomLineSegment::GeomLineSegment(): mPoint2(Vector3(1,0,0)){};
	GeomLineSegment::GeomLineSegment(const Vector3 &p1, const Vector3 &p2){
		setGeom(p1,p2);
	}

	bool GeomLineSegment::canRotate() {
		return true;
	};
	bool GeomLineSegment::canScale() {
		return false;
	};
	bool GeomLineSegment::canTranslate() {
		return true;
	};
	GeomType GeomLineSegment::getType() const {
		return GeomTypeLineSegment;
	};
	GeomPoint GeomLineSegment::getPoint(float u) const{
		return GeomPoint(mPosition + u*(mPoint2-mPosition));
	}


	Vector3 GeomLineSegment::getDirection() const {
		return mPoint2-mPosition;
	};

	void GeomLineSegment::setPosition(const Vector3& pos){
		mPosition = pos;
	}
	void GeomLineSegment::setGeom(const Vector3& p1, const Vector3& p2){
		mPosition=p1;
		mPoint2=p2;
	}

	void GeomLineSegment::rotate_World(const Quaternion& qua){
		Matrix4 matRot;
		matrix_rotation_quaternion(matRot,qua);
		Vector3 direction = mPoint2 - mPosition;
		direction = transform_vector(matRot, direction);
		mPoint2 = mPosition + direction;
	}
}
