/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomPlaneBoundedVolume.h"

using namespace cml;
using namespace std;

namespace REng{

	GeomPlaneBoundedVolume::GeomPlaneBoundedVolume(){
		mPlaneList.push_back(GeomPlane(Vector3(0.5,0,0),Vector3(-1,0,0)));
		mPlaneList.push_back(GeomPlane(Vector3(-0.5,0,0),Vector3(1,0,0)));
		mPlaneList.push_back(GeomPlane(Vector3(0,0.5,0),Vector3(0,-1,0)));
		mPlaneList.push_back(GeomPlane(Vector3(0,-0.5,0),Vector3(0,1,0)));
		mPlaneList.push_back(GeomPlane(Vector3(0,0,-0.5),Vector3(0,0,1)));
		mPlaneList.push_back(GeomPlane(Vector3(0,0,0.5),Vector3(0,0,-1)));
		mPosition.set(0,0,0);
	}

	GeomPlaneBoundedVolume::GeomPlaneBoundedVolume(const GeomPlaneList& _planeList):mPlaneList(_planeList){
		recalcPosition();
	}

	GeomType GeomPlaneBoundedVolume::getType() const { 
		return GeomTypePBV;
	}

	const GeomPlaneList& GeomPlaneBoundedVolume::getPlaneList() const {
		return mPlaneList;
	}

	float GeomPlaneBoundedVolume::getVolume() const {
		return 0;
	}

	const Vector3& GeomPlaneBoundedVolume::getPosition() const{
		return mPosition;
	}

	void GeomPlaneBoundedVolume::clearPlaneList(){
		mPlaneList.clear();
		recalcPosition();
	}
	void GeomPlaneBoundedVolume::addPlane(const GeomPlane& plane){
		mPlaneList.push_back(plane);
		recalcPosition();
	}

	void GeomPlaneBoundedVolume::translate_World(const Vector3& vec) {
		mPosition.set(0,0,0);
		for(unsigned int i=0;i<mPlaneList.size();i++) {
			mPlaneList[i].translate_World(vec);
			mPosition+=mPlaneList[i].getPosition();
		}
		mPosition/=mPlaneList.size();
	}

	void GeomPlaneBoundedVolume::rotate_World(const Quaternion& qua) {
		//Clear PBV Position
		mPosition.set(0,0,0);
		for(unsigned int i=0;i<mPlaneList.size();i++) {
			//Apply World Rotation to Plane
			mPlaneList[i].rotate_World(qua);

			//Add Plane's Position to PBV Position
			mPosition+=mPlaneList[i].getPosition();
		}
		//Normalize PBV Position
		mPosition/=mPlaneList.size();
	}

	//! @todo Scale should be implemented
	void GeomPlaneBoundedVolume::scale(const Vector3& vec) {
	}

	void GeomPlaneBoundedVolume::recalcPosition(){
		mPosition.set(0,0,0);
		if(mPlaneList.size()==0) return;
		for(unsigned int i=0;i<mPlaneList.size();i++) {
			mPosition+=mPlaneList[i].getPosition();
		}
		mPosition/=mPlaneList.size();
	}

}
