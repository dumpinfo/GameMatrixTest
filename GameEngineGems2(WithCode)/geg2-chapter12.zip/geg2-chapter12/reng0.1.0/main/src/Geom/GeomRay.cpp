/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/Geom/GeomRay.h"

namespace REng{

	GeomRay::GeomRay(): mDirection(Vector3(1,0,0)){};
	GeomRay::GeomRay(const Vector3 &p1, const Vector3 &p2, bool funcType){
		setGeom(p1,p2,funcType);
	}

	bool GeomRay::canRotate() {
		return true;
	};
	bool GeomRay::canScale() {
		return false;
	};
	bool GeomRay::canTranslate() {
		return true;
	};
	GeomType GeomRay::getType() const {
		return GeomTypeLine;
	};

	void GeomRay::normalize(){
		mDirection.normalize();
	}
	void GeomRay::reverse(){
		mDirection *= -1;
	}


	GeomPoint GeomRay::getPoint(float u) const{
		return GeomPoint(mPosition + u*mDirection);
	}

	const Vector3& GeomRay::getDirection() const {
		return mDirection;
	};
	const GeomPoint& GeomRay::getOrigin() const {
		return mPosition;
	}


	void GeomRay::setPosition(const Vector3& pos){
		mPosition = pos;
	}
	void GeomRay::setDirection(const Vector3& p1, bool funcType){
		if(funcType) {
			mDirection=p1-mPosition;
		} else {
			mDirection=p1;
		}
	}
	void GeomRay::setGeom(const Vector3& p1, const Vector3& p2, bool funcType){
		mPosition=p1;
		setDirection(p2,funcType);
	}

	void GeomRay::rotate_World(const Quaternion& qua){
		Matrix4 matRot;
		matrix_rotation_quaternion(matRot,qua);
		mDirection = transform_vector(matRot, mDirection);
		normalize();
	}
}
