/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Viewport.h"

#include "REng/GPU/RenderTarget.h"
#include "REng/Camera.h"

#include "REng/RenderSystem.h"
// Camera to render matrix manager
#include "REng/RenderMatrixManager.h"

#include "REng/GPU/GPUFrameBuffer.h"

#include "REng/Math.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	Viewport::Viewport()
		:mRenderTarget(NULL)
		,mCamera(NULL)
		,mListener(NULL)
		,mDisableRendering(false)
		,mClearColor(0.0f,0.0f,0.0f)
		,mClearDepth(1.0f)
		,mClearStencil(0)
		,mDisabledQueuesLessThan(0)
		,mDisableMultiView(false)
		,mSingleViewPref(0)
		,mViewFirstRendering(true)
		,mMVCompositor(NULL)
		,mMVBuffer(NULL)
		,mActiveViewNo(0)
	{
		mClearFrameBuffers = FrameBufferComponent_Depth;
	}

	const RectF& Viewport::getRelRect() const{
		return mRelRect;
	}
	const RectI& Viewport::getAbsRect() const{
		return mAbsRect;
	}
	void Viewport::setAbsRect(RectI rect){
		mAbsRect = rect;
		updateFromAbsToRel();
//		updateCameraAspectRatio();
	}
	void Viewport::setRelRect(RectF rect){
		mRelRect = rect;
		updateFromRelToAbs();
		updateCameraAspectRatio();
	}
	float Viewport::getAspectRatio() const {
		return mRelRect.getWidth()/mRelRect.getHeight();
	}
	void Viewport::updateFromRelToAbs(){
		if(mRenderTarget==NULL) return;
		ushort width  = mRenderTarget->getWidth();
		ushort height = mRenderTarget->getHeight();
		mAbsRect.setLimits(
			mRelRect.getLeft()   * width,
			mRelRect.getRight()  * width,
			mRelRect.getTop()    * height,
			mRelRect.getBottom() * height
			);
	}
	void Viewport::updateFromAbsToRel(){
		if(mRenderTarget==NULL) return;
		float invwidth  = 1.0f/mRenderTarget->getWidth();
		float invheight = 1.0f/mRenderTarget->getHeight();
		mRelRect.setLimits(
			mAbsRect.getLeft()   * invwidth,
			mAbsRect.getRight()  * invwidth,
			mAbsRect.getTop()    * invheight,
			mAbsRect.getBottom() * invheight
			);
	}
	void Viewport::updateCameraAspectRatio(){
		if(mCamera==0) return;
		if(mCamera->mSynchAspectRatioFromViewport){
			mCamera->setAspectRatio(getAspectRatio());
		}
	}

	/************************************************************************/
	/* ViewPort Listener                                                    */
	/************************************************************************/
	bool Viewport::attachListener(std::auto_ptr<ViewportListener> vpListener){
		if(isListenerActive()) return false;
		if(vpListener->init(*this) == false) return false;
		mListener = vpListener;
		return true;
	}
	void Viewport::detachListener(){
		if(isListenerActive()) mListener->clear();
		mListener.reset();
	}
	bool Viewport::isListenerActive() const{
		return ((mListener.get()!=NULL)==true);
	}

	/************************************************************************/
	/* Multi-View Stuff                                                     */
	/************************************************************************/

	bool Viewport::isMVActive() const{
		if(mCamera==NULL) return false;
//		if(mRenderTarget==NULL) return false; // TODO
		if(mDisableMultiView) return false;
		if(mMVBuffer==NULL) return false;
		if(mCamera->getViewCount() != mMVBuffer->getViewCount()) return false;
		if(mMVBuffer->getType() == MVBufferType_Offtarget){
			if(mMVCompositor==NULL) return false;
			if(mCamera->getViewCount() != mMVCompositor->getViewCount()) return false;
		}
		return true;
	}
	bool Viewport::attachMVCompositor(MultiViewCompositor* mvc){
		if(mMVCompositor!=NULL) detachMVCompositor();
		mMVCompositor = mvc;
		if(mMVCompositor->init(*this) == false) {
			detachMVCompositor();
			return false;
		}
		return true;
	}
	bool Viewport::attachMVBuffer(MultiViewBuffer* mvb,MVBuffer_Cfg params){
		// detaching clears GPU resources, yet some drivers may not like that and produce impossible error codes!
		if(mMVBuffer!=NULL) { ; } // detachMVBuffer(); 
		mMVBuffer = mvb;
		if(mMVBuffer->init(*this, params) == false) {
			detachMVBuffer();
			return false;
		}
		return true;
	}
	MultiViewCompositor* Viewport::getMVCompositor(){
		return mMVCompositor;
	}
	MultiViewBuffer* Viewport::getMVBuffer(){
		return mMVBuffer;
	}
	void Viewport::detachMVCompositor(){
		if(mMVCompositor!=NULL) mMVCompositor->clear();
		mMVCompositor=NULL;
	}
	void Viewport::detachMVBuffer(){
		if((mMVBuffer!=NULL)) mMVBuffer->clear();
		mMVBuffer=NULL;
	}
	uchar Viewport::getViewCount() const{
		if(mMVBuffer==0) return 1;
		return mMVBuffer->getViewCount();
	}

	uchar Viewport::getActiveViewNo() const{
		return mActiveViewNo;
	}

	/************************************************************************/
	/* Rendering                                                            */
	/************************************************************************/

	bool Viewport::isRenderQueueEnabled(uchar id){
		if(id<mDisabledQueuesLessThan) return false;
		size_t s = mDisabledQueueIDs.size();
		for(size_t i=0; i<s ; ++i) if(mDisabledQueueIDs[i] == id) return false;
		return true;
	}

	void Viewport::disableRenderQueue(uchar id){
		mDisabledQueueIDs.push_back(id);
	}

	void Viewport::disableRenderQueues_LessThan(uchar id){
		mDisabledQueuesLessThan = id;
	}

	bool Viewport::isRenderReady(){
		if(mDisableRendering) return false;
//		if(mRenderTarget==0) return; // TODO
		if(mCamera==0) return true;
		if(mCamera->getViewCount()==1) return true; // can always render with a single-view camera
		if(!mDisableMultiView){
			if(mMVCompositor!=0) {
				if(mCamera->getViewCount() != mMVCompositor->getViewCount()) return false;
			}
			if(mMVBuffer!=0){
			// check is camera view count a multi-view compositor view count matches
			if(mMVBuffer->getType() == MVBufferType_Offtarget){
				if(mMVCompositor == NULL) return false;
				if(mMVCompositor->getViewCount() != mMVBuffer->getViewCount()) return false;
			}
			}
		}
		return true;
	}

	void Viewport::autoClearBuffer(FrameBufferComponent bt, bool isEnabled){
		if(isEnabled){
			mClearFrameBuffers = mClearFrameBuffers | bt;
		} else {
			mClearFrameBuffers = mClearFrameBuffers & ~bt;
		}
	}
	void Viewport::autoClearColor(Color_Real color){
		mClearColor = color;
	}
	void Viewport::autoClearDepth(float depthVal){
		depthVal = Math::clamp(depthVal,0.0f,1.0f);
		mClearDepth = depthVal;
	}
	void Viewport::autoClearStencil(uint stencilVal){
		mClearStencil = stencilVal;
	}
	void Viewport::clearBuffers(){
		if(mClearFrameBuffers & uint(FrameBufferComponent_Color)){
			glClearColor(mClearColor.r, mClearColor.g, mClearColor.b, mClearColor.a);
		}
		if(mClearFrameBuffers & uint(FrameBufferComponent_Depth)){
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			glClearDepthf(mClearDepth);
			#else
			glClearDepth(mClearDepth);
			#endif
		}
		if(mClearFrameBuffers & uint(FrameBufferComponent_Stencil)){
			glClearStencil(mClearStencil);
		}
		glClear(mClearFrameBuffers);
	}

	bool Viewport::renderToTarget(){
		if(!isRenderReady()) return false;
		if(isListenerActive()) mListener->preRenderAll(); 

		RenderQueueMap::getSingleton().resetQueues();

		if(mCamera!=0) {
			RenderSystem& RSys(RenderSystem::getSingleton());
			RSys.setActiveCamera(*mCamera);
			RSys.queueBackground(true);
			RSys.queueSG();
		}

		if(isMVActive()) renderMultiView(); else renderSingleView();

		if(isListenerActive()) mListener->postRenderAll(); 
		return true;
	}

	void Viewport::renderSingleView(){
		RenderSystem& RSys(RenderSystem::getSingleton());

		if(mCamera!=0) {
			if(mDisableMultiView==true && mCamera->getViewCount()>1){
				mCamera->setActiveView(mSingleViewPref);
				mActiveViewNo = mSingleViewPref;
			}
			RenderMatrixManager::getSingleton().setViewProjection(*mCamera);
		}

		// TODO: bind the render target
		GPUFrameBuffer::setBindTarget(FrameBufferBindTarget_Default);
		GPUFrameBuffer::unbindResource();
		RSys.setViewportTrans(mAbsRect);

		clearBuffers();
		if(!RSys.mDisableInternalSGRenderer) RSys.processRenderQueues();
	}

	void Viewport::renderMultiView(){
		if(mCamera==0) return; // cannot render multi-view with no camera attached

		RenderSystem& RSys(RenderSystem::getSingleton());
		uchar maxViewID = mMVBuffer->getViewCount();

		// If no compositor is attached, mv buffer is on-target and we render to same region on the viewport
		// => Apply wiggle stereo
		if(mMVBuffer->getType()==MVBufferType_Ontarget && !mMVBuffer->hasOwnViewRects() && mMVCompositor==0){
			clearBuffers();
			renderActiveMultiView();
			++mActiveViewNo;
			if(mActiveViewNo>=maxViewID) mActiveViewNo -= maxViewID;
			// no merge required
			return;
		}

		if(mViewFirstRendering){
			if(mMVCompositor) {
				RenderSystem::getSingleton().setViewportTrans(mAbsRect);
				mMVCompositor->beginFrame();
			}
			if(mMVBuffer->getType()==MVBufferType_Ontarget){
				clearBuffers();
			}
			// For each view, processes the multi-view buffer
			for(mActiveViewNo=0; mActiveViewNo<maxViewID ; ++mActiveViewNo) {
				// clear depth and stencil buffers between different views
				if(mClearFrameBuffers & uint(FrameBufferComponent_Depth)){
					glClear(GL_DEPTH_BUFFER_BIT);
				}
				if(mClearFrameBuffers & uint(FrameBufferComponent_Stencil)){
					glClear(GL_STENCIL_BUFFER_BIT);
				}
				renderActiveMultiView();
			}
		} else {
			// NOTE: Currently an invalid path.
			assert(0);
			for(uchar v=0; v<maxViewID ; ++v) {
				mMVBuffer->setActiveView(v);
				clearBuffers();
			}
			if(!RSys.mDisableInternalSGRenderer) RSys.processRenderQueues();
		}

		if(mMVCompositor) mMVCompositor->endFrame();
		mergeViews();
	}

	void Viewport::mergeViews(){
		if(mMVBuffer->getType() == MVBufferType_Offtarget){
			GPUFrameBuffer::setBindTarget(FrameBufferBindTarget_Default);
			GPUFrameBuffer::unbindResource();
			RenderSystem::getSingleton().setViewportTrans(mAbsRect);
			mMVCompositor->mergeViews(*mMVBuffer);
		}
	}

	void Viewport::activateView(uchar viewID){
		mMVBuffer->setActiveView(viewID);
		mCamera->setActiveView(viewID);
		if(mMVCompositor) mMVCompositor->setActiveView(viewID);
		RenderMatrixManager::getSingleton().setViewProjection(*mCamera);
	}

	void Viewport::renderActiveMultiView(){
		RenderSystem& RSys(RenderSystem::getSingleton());

		activateView(mActiveViewNo);

		if(isListenerActive()) mListener->preRenderView(mActiveViewNo); 
		if(mMVBuffer->getType()==MVBufferType_Offtarget)clearBuffers();
		if(!RSys.mDisableInternalSGRenderer) RSys.processRenderQueues();
		if(isListenerActive()) mListener->postRenderView(mActiveViewNo); 
	}


} // namespace REng
