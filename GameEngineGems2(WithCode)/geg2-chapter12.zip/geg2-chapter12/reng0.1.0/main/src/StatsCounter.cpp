/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/StatsCounter.h"

// render system has its own logger
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	// SINGLETON
	template<> StatsCounter* Singleton<StatsCounter>::ms_Singleton = 0;
	StatsCounter* StatsCounter::getSingletonPtr(void) {
		return ms_Singleton;
	}
	StatsCounter& StatsCounter::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	StatsCounter::StatsCounter(){ 
		// you need to set accum's to zero before calling regular clearStats()
		mVertexCountStat.accum=0;
		mFaceCountStat.accum=0;
		mFrame_Cur.accum=0;
		mDrawCall.accum=0;
		clearStats(); 
	}
	StatsCounter::~StatsCounter(){ ; }
	size_t StatsCounter::getFrameRate() const{
		return mFrame_Cur.perSec;
	}
	size_t StatsCounter::getFaceCount() const{
		return mFaceCountStat.perSec;
	}
	size_t StatsCounter::getVertexCount() const{
		return mVertexCountStat.perSec;
	}
	size_t StatsCounter::getDrawCallCount() const{
		return mDrawCall.perSec;
	}
	void StatsCounter::clearStats(){
		// store old values for display
		mVertexCountStat.perSec = mVertexCountStat.accum;
		mFaceCountStat.perSec = mFaceCountStat.accum;
		mDrawCall.perSec = mDrawCall.accum;
		mFrame_Cur.perSec = mFrame_Cur.accum;
		// clear accumulators
		mVertexCountStat.accum = 0;
		mFaceCountStat.accum = 0;
		mFrame_Cur.accum = 0;
		mDrawCall.accum = 0;
		// log frame rate 
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),"FPS:" << mFrame_Cur.perSec);
	}
	void StatsCounter::incFrameRate(){
		mFrame_Cur.accum++;
	}
	void StatsCounter::incDrawCall(){
		mDrawCall.accum++;
	}
	void StatsCounter::addFaceCount(size_t count){
		mFaceCountStat.accum += count;
	}
	void StatsCounter::addVertexCount(size_t count){
		mVertexCountStat.accum += count;
	}

} // namespace REng
