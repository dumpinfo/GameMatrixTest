/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Angle.h"

#include "REng/Math.h"

#include <cmath>

namespace REng {

	Angle::Angle(float val) : mValue(val) { }
	float Angle::degree2radian(float val){
		return val * Math::PI / (180.0f);
	}
	float Angle::radian2degree(float val){
		return val * (180.0f) / Math::PI;
	}
	float Angle::sin(){
		return std::sin(getRadian());
	}
	float Angle::cos(){
		return std::cos(getRadian());
	}
	float Angle::tan(){
		return std::tan(getRadian());
	}

	/************************************************************************/
	/* Angle Degree                                                         */
	/************************************************************************/

	AngleDegree::AngleDegree( float val) : Angle(val) { }
	AngleDegree::AngleDegree( const Angle& _a) : Angle(_a.getDegree()) { }

	AngleDegree& AngleDegree::operator=( const Angle& _a ){
		mValue = _a.getDegree();
		return *this;
	}

	float AngleDegree::getDegree() const{
		return mValue;
	}
	float AngleDegree::getRadian() const{
		return degree2radian(mValue);
	}

	AngleDegree AngleDegree::operator+( const Angle& d ) const{
		return AngleDegree(mValue+d.getDegree());
	}
	AngleDegree AngleDegree::operator-( const Angle& d ) const{
		return AngleDegree(mValue-d.getDegree());
	}
	AngleDegree AngleDegree::operator*( float f ) const{
		return AngleDegree(mValue*f);
	}
	AngleDegree AngleDegree::operator/( float f ) const{
		return AngleDegree(mValue/f);
	}
	AngleDegree AngleDegree::operator*( const Angle& d ) const{
		return AngleDegree(mValue*d.getDegree());
	}
	AngleDegree AngleDegree::operator/( const Angle& d ) const{
		return AngleDegree(mValue/d.getDegree());
	}


	AngleDegree& AngleDegree::operator+=( const Angle& r ){
		mValue += r.getDegree();
		return *this;
	}
	AngleDegree& AngleDegree::operator-=( const Angle& r ){
		mValue -= r.getDegree();
		return *this;
	}
	AngleDegree& AngleDegree::operator*=( const Angle& d ){
		mValue *= d.getDegree();
		return *this;
	}
	AngleDegree& AngleDegree::operator/=( const Angle& d ){
		mValue /= d.getDegree();
		return *this;
	}
	AngleDegree& AngleDegree::operator*=( float f ){
		mValue *= f;
		return *this;
	}
	AngleDegree& AngleDegree::operator/=( float f ){
		mValue /= f;
		return *this;
	}

	bool AngleDegree::operator< ( const Angle& r ) const{
		return (mValue < r.getDegree());
	}
	bool AngleDegree::operator<=( const Angle& r ) const{
		return (mValue <= r.getDegree());
	}
	bool AngleDegree::operator==( const Angle& r ) const{
		return (mValue == r.getDegree());
	}
	bool AngleDegree::operator!=( const Angle& r ) const{
		return (mValue != r.getDegree());
	}
	bool AngleDegree::operator>=( const Angle& r ) const{
		return (mValue >= r.getDegree());
	}
	bool AngleDegree::operator> ( const Angle& r ) const{
		return (mValue > r.getDegree());
	}

	/************************************************************************/
	/* Angle Radian                                                         */
	/************************************************************************/

	AngleRadian::AngleRadian( float val) : Angle(val) { }
	AngleRadian::AngleRadian( const Angle& _a) : Angle(_a.getRadian()) { }

	AngleRadian& AngleRadian::operator=( const Angle& _a ){
		mValue = _a.getRadian();
		return *this;
	}

	float AngleRadian::getDegree() const{
		return radian2degree(mValue);
	}
	float AngleRadian::getRadian() const{
		return mValue;
	}

	AngleRadian AngleRadian::operator+( const Angle& d ) const{
		return AngleRadian(mValue+d.getRadian());
	}
	AngleRadian AngleRadian::operator-( const Angle& d ) const{
		return AngleRadian(mValue-d.getRadian());
	}
	AngleRadian AngleRadian::operator*( float f ) const{
		return AngleRadian(mValue*f);
	}
	AngleRadian AngleRadian::operator/( float f ) const{
		return AngleRadian(mValue/f);
	}

	AngleRadian& AngleRadian::operator+=( const Angle& r ){
		mValue += r.getRadian();
		return *this;
	}
	AngleRadian& AngleRadian::operator-=( const Angle& r ){
		mValue -= r.getRadian();
		return *this;
	}
	AngleRadian& AngleRadian::operator*=( float f ){
		mValue *= f;
		return *this;
	}
	AngleRadian& AngleRadian::operator/=( float f ){
		mValue /= f;
		return *this;
	}

	bool AngleRadian::operator< ( const Angle& r ) const{
		return (mValue < r.getRadian());
	}
	bool AngleRadian::operator<=( const Angle& r ) const{
		return (mValue <= r.getRadian());
	}
	bool AngleRadian::operator==( const Angle& r ) const{
		return (mValue == r.getRadian());
	}
	bool AngleRadian::operator!=( const Angle& r ) const{
		return (mValue != r.getRadian());
	}
	bool AngleRadian::operator>=( const Angle& r ) const{
		return (mValue >= r.getRadian());
	}
	bool AngleRadian::operator> ( const Angle& r ) const{
		return (mValue > r.getRadian());
	}
}
