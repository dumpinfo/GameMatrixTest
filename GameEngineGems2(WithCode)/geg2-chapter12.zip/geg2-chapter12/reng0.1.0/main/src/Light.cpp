/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Light.h"

#include "REng/LightingManager.h"

// light structs register to the material shader
#include "REng/Material/MaterialShader.h"

// GPUConfig can produce logs
#include <log4cplus/logger.h>
using namespace log4cplus;

#include <cmath>

#include "REng/Geom/GeomVolume.h"

namespace REng {

	/************************************************************************/
	/* LIGHT REGISTRY                                                       */
	/************************************************************************/
	// singleton stuff
	template<> LightRegistry* Singleton<LightRegistry>::ms_Singleton = 0;
	LightRegistry& LightRegistry::getSingleton(void) {
		static LightRegistry reg;
		return reg;
	}
	void LightRegistry::add(LightRegFunc creator) {
		mRegFuncs.push_back(creator);
	}
	uint LightRegistry::getLightTypeCount() const{
		return mRegFuncs.size();
	}
	LightRegFuncList::iterator LightRegistry::begin() {
		return mRegFuncs.begin();
	}
	LightRegFuncList::iterator LightRegistry::end() { 
		return mRegFuncs.end();
	}

	LightRegistrer::LightRegistrer(LightRegFunc structFunc) {
		LightRegistry::getSingleton().add(structFunc);
	}

	REGISTER_LIGHT(Light_Sun);
	REGISTER_LIGHT(Light_Point);
	REGISTER_LIGHT(Light_Spot);

	/************************************************************************/
	/* Light Base                                                           */
	/************************************************************************/
	Light_Base::Light_Base(LightNode& node) 
		:mDirtyFlags(-1)
		,mNode(node)
		,mEnabled(true)
	{ 
		mNode.mLight = this;
	}
	Light_Base::~Light_Base(){ 
		mNode.mLight = 0;
	}
	void Light_Base::setNode(LightNode& node){
		if(&node == &mNode) return;
		mNode.mLight = 0;
		mNode = node;
		mNode.mLight = this;
	}
	LightNode& Light_Base::getNode(){
		return mNode;
	}
	const LightNode& Light_Base::getNode() const{
		return mNode;
	}
	void Light_Base::setLit(bool val){
		mEnabled = val;
	}
	bool Light_Base::isLit() const{
		return mEnabled;
	}
	const Vector3& Light_Base::getPosition() const{
		return mNode.getTranslation_World();
	}
	const Vector3 Light_Base::getDirection() const{
		return mNode.getDirection();
	}
	void Light_Base::setAllDirty(bool _isDirty){
		if(_isDirty){
			mDirtyFlags = -1;
		} else {
			mDirtyFlags = 0;
		}
	}
	void Light_Base::setNodeDirty(){
		mDirtyFlags = mDirtyFlags | Dirty_Dir | Dirty_Pos ;
	}


	/************************************************************************/
	/* SUN LIGHT                                                            */
	/************************************************************************/
	Light_Sun::Light_Sun(LightNode& node)
		:Light_Base(node),
		mColor(Color_Real(1.0,0.0f,0.0f,1.0f))
	{
		; // TODO
	}
	Light_Sun& Light_Sun::create(LightNode& node){
		Light_Sun* l = new Light_Sun(node);
		LightingManager::getSingleton().registerLightToScene(*l);
		return *l;
	}
	bool Light_Sun::isPositional() const { 
		return false; 
	}
	bool Light_Sun::isDirectional() const { 
		return true;
	}
	uint Light_Sun::getTypeID() const { 
		return LightType_Sun; 
	}
	void Light_Sun::setColor(Color_Real color){
		mColor = color;
		mDirtyFlags = mDirtyFlags | Dirty_Color;
	}
	Color_Real Light_Sun::getColor() const{
		return mColor;
	}

	const char* Light_Sun::mShaderStructCode = 
				"struct re_SunLightParams{ "
				" vec4 color; "
				" vec3 direction; "
				"}; ";
	const char* Light_Sun::mShaderStructCode_ES = 
				"struct re_SunLightParams{ "
				" mediump vec4 color; "
				" mediump vec3 direction; "
				"}; ";
	const char* Light_Sun::mUniformArrayName = "re_SunLights";
	const char* Light_Sun::getShaderStructCode(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			return mShaderStructCode_ES;
		#else
			return mShaderStructCode;
		#endif
	}
	bool Light_Sun::synchWithPass(RenderPass& pass){
		#ifdef RENG_DEBUG_BUILD
			if(mSynchLightIndex >= LightingManager::MaxNumOfLights_PerType){
				// TODO: log warning to a file...
				return false;
			}
		#endif
		sprintf(_uniformName, "%s[%u]", mUniformArrayName, mSynchLightIndex);
		bool toRet1 = synchColor(pass);
		bool toRet2 = synchDirection(pass);
		return toRet1 || toRet2;
	}
	bool Light_Sun::synchColor(RenderPass& pass){
		sprintf(_uniformName_Param,"%s.color", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		unif->setDataAtIndex(0,mColor.r);
		unif->setDataAtIndex(1,mColor.g);
		unif->setDataAtIndex(2,mColor.b);
		unif->setDataAtIndex(3,mColor.a);
		return true;
	}
	bool Light_Sun::synchDirection(RenderPass& pass){
		// TODO: if not dirty, do not synch
		sprintf(_uniformName_Param,"%s.direction", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		const Vector3& dir(getDirection());
		unif->setDataAtIndex(0,dir[0]);
		unif->setDataAtIndex(1,dir[1]);
		unif->setDataAtIndex(2,dir[2]);
		return true;
	}
	bool Light_Sun::registerFunc(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			MaterialShader::addPreText(mShaderStructCode_ES);
		#else
			MaterialShader::addPreText(mShaderStructCode);
		#endif
		char varName[64];
		sprintf(varName,"uniform re_SunLightParams re_SunLights[%d]; ",LightingManager::MaxNumOfLights_PerType);
		MaterialShader::addPreText(varName);
		return true;
	}

	/************************************************************************/
	/* POINT LIGHT                                                          */
	/************************************************************************/
	Light_Point::Light_Point(LightNode& node)
		:Light_Base(node) , 
		mColor(Color_Real(1.0,0.0f,0.0f,1.0f)),
		mAttenPos_Constant(1),
		mAttenPos_Linear(0),
		mAttenPos_Quadric(0)
	{
		// TODO
	}
	Light_Point& Light_Point::create(LightNode& node){
		Light_Point* l = new Light_Point(node);
		LightingManager::getSingleton().registerLightToScene(*l);
		return *l;
	}
	bool Light_Point::isPositional() const { 
		return true; 
	}
	bool Light_Point::isDirectional() const { 
		return false;
	}
	uint Light_Point::getTypeID() const { 
		return LightType_Point;
	}
	void Light_Point::setColor(Color_Real color){
		mColor = color;
		mDirtyFlags = mDirtyFlags | Dirty_Color;
	}
	Color_Real Light_Point::getColor() const{
		return mColor;
	}
	void Light_Point::setAttenPosFactors(float _cons, float _linear, float _quadric){
		mAttenPos_Constant = _cons;
		mAttenPos_Linear   = _linear;
		mAttenPos_Quadric  = _quadric;
		mDirtyFlags = mDirtyFlags | Dirty_AttenPos;
	}
	void Light_Point::getAttenPosFactors(float& _cons, float& _linear, float& _quadric){
		_cons    = mAttenPos_Constant;
		_linear  = mAttenPos_Linear;
		_quadric = mAttenPos_Quadric;
	}
	const char* Light_Point::mShaderStructCode =
		"struct re_PointLightParams{ "
		" vec4 color; "
		" vec3 position; "
		" vec3 attenPos;" // (constant, linear, quadric)
		"}; ";
	const char* Light_Point::mShaderStructCode_ES =
		"struct re_PointLightParams{ "
		" mediump vec4 color; "
		" mediump vec3 position; "
		" mediump vec3 attenPos;" // (constant, linear, quadric)
		"}; ";
	const char* Light_Point::mUniformArrayName = "re_PointLights";
	const char* Light_Point::getShaderStructCode(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			return mShaderStructCode_ES;
		#else
			return mShaderStructCode;
		#endif
	}
	bool Light_Point::synchWithPass(RenderPass& pass){
		#ifdef RENG_DEBUG_BUILD
		if(mSynchLightIndex >= LightingManager::MaxNumOfLights_PerType){
			// TODO: log to a file...
			return false;
		}
		#endif
		sprintf(_uniformName, "%s[%u]", mUniformArrayName, mSynchLightIndex);
		bool toRet1 = synchColor(pass);
		bool toRet2 = synchPosition(pass);
		bool toRet3 = synchAttenuation(pass);
		return toRet1 || toRet2 || toRet3;
	}
	bool Light_Point::synchColor(RenderPass& pass){
		sprintf(_uniformName_Param,"%s.color", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		unif->setDataAtIndex(0,mColor.r);
		unif->setDataAtIndex(1,mColor.g);
		unif->setDataAtIndex(2,mColor.b);
		unif->setDataAtIndex(3,mColor.a);
		return true;
	}
	bool Light_Point::synchPosition(RenderPass& pass){
		// TODO: if not dirty, do not synch
		sprintf(_uniformName_Param,"%s.position", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		const Vector3& pos(getPosition());
		unif->setDataAtIndex(0,pos[0]);
		unif->setDataAtIndex(1,pos[1]);
		unif->setDataAtIndex(2,pos[2]);
		return true;
	}
	bool Light_Point::synchAttenuation(RenderPass& pass){
//		if( (mDirtyFlags&Dirty_AttenPos) == 0) return;
		sprintf(_uniformName_Param,"%s.attenPos", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		unif->setDataAtIndex(0,mAttenPos_Constant);
		unif->setDataAtIndex(1,mAttenPos_Linear);
		unif->setDataAtIndex(2,mAttenPos_Quadric);
		return true;
	}
	bool Light_Point::registerFunc(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			MaterialShader::addPreText(mShaderStructCode_ES);
		#else
			MaterialShader::addPreText(mShaderStructCode);
		#endif
		char varName[64];
		sprintf(varName,"uniform re_PointLightParams re_PointLights[%d]; ",LightingManager::MaxNumOfLights_PerType);
		MaterialShader::addPreText(varName);
		return true;
	}

	/************************************************************************/
	/* SPOT LIGHT                                                           */
	/************************************************************************/
	Light_Spot::Light_Spot(LightNode& node)
		:Light_Base(node) , 
		mColor(Color_Real(1.0,0.0f,0.0f,1.0f)),
		mAttenPos_Constant(1),
		mAttenPos_Linear(0),
		mAttenPos_Quadric(0),
		mFalloffExponent(0),
		mCutoffAngle(AngleDegree(45))
	{
		// TODO
	}
	Light_Spot& Light_Spot::create(LightNode& node){
		Light_Spot* l = new Light_Spot(node);
		LightingManager::getSingleton().registerLightToScene(*l);
		return *l;
	}
	bool Light_Spot::isPositional() const { 
		return true; 
	}
	bool Light_Spot::isDirectional() const { 
		return true;
	}
	uint Light_Spot::getTypeID() const { 
		return LightType_Spot;
	}
	void Light_Spot::setColor(Color_Real color){
		mColor = color;
		mDirtyFlags = mDirtyFlags | Dirty_Color;
	}
	Color_Real Light_Spot::getColor() const{
		return mColor;
	}
	void Light_Spot::setAttenPosFactors(float _cons, float _linear, float _quadric){
		mAttenPos_Constant = _cons;
		mAttenPos_Linear   = _linear;
		mAttenPos_Quadric  = _quadric;
		mDirtyFlags = mDirtyFlags | Dirty_AttenPos;
	}
	void Light_Spot::getAttenPosFactors(float& _cons, float& _linear, float& _quadric){
		_cons    = mAttenPos_Constant;
		_linear  = mAttenPos_Linear;
		_quadric = mAttenPos_Quadric;
	}
	void Light_Spot::setAttenDirFactors(float falloffExp, const Angle& cutoffAngle){
		mFalloffExponent = falloffExp;
		mCutoffAngle = cutoffAngle;
		mDirtyFlags = mDirtyFlags | Dirty_AttenDir;
	}
	void Light_Spot::getAttenDirFactors(float& falloffExp, Angle& cutoffAngle){
		falloffExp = mFalloffExponent;
		cutoffAngle = mCutoffAngle;
	}
	const char* Light_Spot::mShaderStructCode =
		"struct re_SpotLightParams{ "
		" vec4 color; "
		" vec3 position; "
		" vec3 direction; "
		" vec3 attenPos; "// (constant, linear, quadric) 
		" vec2 attenDir; "// (angle, falloff)
		"}; ";
	const char* Light_Spot::mShaderStructCode_ES =
		"struct re_SpotLightParams{ "
		" mediump vec4 color; "
		" mediump vec3 position; "
		" mediump vec3 direction; "
		" mediump vec3 attenPos; "// (constant, linear, quadric) 
		" mediump vec2 attenDir; "// (angle, falloff)
		"}; ";
	const char* Light_Spot::mUniformArrayName = "re_SpotLights";
	const char* Light_Spot::getShaderStructCode(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			return mShaderStructCode_ES;
		#else
			return mShaderStructCode;
		#endif
	}
	bool Light_Spot::synchWithPass(RenderPass& pass){
		#ifdef RENG_DEBUG_BUILD
		if(mSynchLightIndex>= LightingManager::MaxNumOfLights_PerType){
			// TODO: log to a file...
			return false;
		}
		#endif
		sprintf(_uniformName, "%s[%u]", mUniformArrayName, mSynchLightIndex);
		bool toRet1 = synchColor(pass);
		bool toRet2 = synchPosition(pass) ;
		bool toRet3 = synchDirection(pass) ;
		bool toRet4 = synchAttenuation(pass);
		return toRet1 || toRet2 || toRet3 || toRet4;
	}
	bool Light_Spot::synchColor(RenderPass& pass){
		sprintf(_uniformName_Param,"%s.color", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		unif->setDataAtIndex(0,mColor.r);
		unif->setDataAtIndex(1,mColor.g);
		unif->setDataAtIndex(2,mColor.b);
		unif->setDataAtIndex(3,mColor.a);
		return true;
	}
	bool Light_Spot::synchPosition(RenderPass& pass){
		// TODO: if not dirty, do not synch
		sprintf(_uniformName_Param,"%s.position", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		const Vector3& pos(getPosition());
		unif->setDataAtIndex(0,pos[0]);
		unif->setDataAtIndex(1,pos[1]);
		unif->setDataAtIndex(2,pos[2]);
		return true;
	}
	bool Light_Spot::synchDirection(RenderPass& pass){
		// TODO: if not dirty, do not synch
		sprintf(_uniformName_Param,"%s.direction", _uniformName);
		RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
		if(unif==0) return false;
		const Vector3& dir(getDirection());
		unif->setDataAtIndex(0,dir[0]);
		unif->setDataAtIndex(1,dir[1]);
		unif->setDataAtIndex(2,dir[2]);
		return true;
	}
	bool Light_Spot::synchAttenuation(RenderPass& pass){
		bool toRet = false;
		if( (mDirtyFlags&Dirty_AttenPos) != 0) {
			sprintf(_uniformName_Param,"%s.attenPos", _uniformName);
			RenderProp_Uniform* unif(pass.getUniformProperty(_uniformName_Param));
			if(unif!=0) {
				unif->setDataAtIndex(0,mAttenPos_Constant);
				unif->setDataAtIndex(1,mAttenPos_Linear);
				unif->setDataAtIndex(2,mAttenPos_Quadric);
				toRet = true;
			}
		}
		if( (mDirtyFlags&Dirty_AttenDir) != 0) {
			sprintf(_uniformName_Param,"%s.attenDir", _uniformName);
			RenderProp_Uniform* unif = pass.getUniformProperty(_uniformName_Param);
			if(unif!=0) {
				unif->setDataAtIndex(0,(float)cos(mCutoffAngle.getRadian()));
				unif->setDataAtIndex(1,mFalloffExponent);
				toRet = true;
			}
		}
		return toRet;
	}
	bool Light_Spot::registerFunc(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			MaterialShader::addPreText(mShaderStructCode_ES);
		#else
			MaterialShader::addPreText(mShaderStructCode);
		#endif
		char varName[64];
		sprintf(varName,"uniform re_SpotLightParams re_SpotLights[%d]; ",LightingManager::MaxNumOfLights_PerType);
		MaterialShader::addPreText(varName);
		return true;
	}


}
