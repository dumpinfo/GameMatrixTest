/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/MeshManager.h"

// support for loading 3ds files
#include <lib3ds.h>
// support for loading obj files
#include "REng/OBJLoader.h"

// logging
#include <log4cplus/logger.h>

// accessing loaded materials
#include "REng/Material/MaterialManager.h"

// for mesh bounding volumes
#include "REng/Geom/Geom.h"

using namespace log4cplus;
using namespace std;

namespace REng{

	template<> MeshManager* Singleton<MeshManager>::ms_Singleton = 0;
	MeshManager* MeshManager::getSingletonPtr(void) {
		return ms_Singleton;
	}
	MeshManager& MeshManager::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	MeshManager::MeshManager(void){ 
		mGenerateNormals = true;
		mGenerateTangent = false;
		mGenerateBitangent = false;
		mSwapTexCoordS_T = false;
		mMeshOrient = MeshOrientRHS;
		mTmpBoundBoxType = GeomTypeOBox;
		mScaleOnLoad = 1.0;
	}

	MeshManager::~MeshManager(void){ ; }

	bool MeshManager::isSpecialName(const std::string& meshName){
		if(meshName.length() < 3) return false;
		if(meshName[0] != 'r') return false;
		if(meshName[1] != 'e') return false;
		if(meshName[2] != '_') return false;
		return true;
	}

	string MeshManager::getExtension(const string& filename){
		size_t dotPos = filename.rfind(".");
		if(dotPos == string::npos) return string("");
		return filename.substr(dotPos+1);
	}
	string MeshManager::getBaseName(const string& filename){
		size_t dotPos = filename.rfind(".");
		size_t pathPos = filename.find_last_of('\\');
		if (pathPos == std::string::npos) {
			pathPos = filename.find_last_of('/');
		}
		++pathPos;
		return filename.substr(pathPos,dotPos-pathPos);
	}
	string MeshManager::getPath(const string& filename){
		std::string::size_type offset = filename.find_last_of('\\');
		if (offset != std::string::npos) {
			return filename.substr(0, ++offset);
		} else {
			offset = filename.find_last_of('/');
			if (offset != std::string::npos)
				return filename.substr(0, ++offset);
		}
		return "";
	}


	bool MeshManager::loadFromFile(const string& fileName){
		Logger logger = Logger::getInstance("MeshLoad");
		string fileExtension(getExtension(fileName));
		if(fileExtension==""){
			LOG4CPLUS_ERROR(logger,"loadFromFile: File extension is not found. Filename: " << fileName);
			return false;
		}

		if(fileExtension == "3ds") return loadFrom3DS(fileName);
		if(fileExtension == "3DS") return loadFrom3DS(fileName);
		if(fileExtension == "obj") return loadFromOBJ(fileName);
		// TODO add support for other extensions ?

		LOG4CPLUS_ERROR(logger,"loadFromFile: File extension is unknown. Filename: " << fileName);
		return false;
	}

	bool MeshManager::loadFromOBJ(const std::string& fileName){
		Logger logger = Logger::getInstance("MeshLoad");
		LOG4CPLUS_INFO(logger,"Loading obj file : " << fileName);

		OBJModel model;
		if(!model.import(fileName.c_str(),false)){
			LOG4CPLUS_ERROR(logger," OBJ file could not be parsed.");
			return false;
		}
		LOG4CPLUS_INFO(logger," OBJ Model is loaded from external file");

		float offset[3] = {0.0f,0.0f,0.0f};
		model.scale(mScaleOnLoad,offset); // temp

		const OBJModel::Mesh *pMesh = 0;
		const OBJModel::Material *pMaterial = 0;

		size_t numberOfVertices  = model.getNumberOfVertices();
		size_t numberOfTriangles = model.getNumberOfTriangles();
		size_t numberOfIndices   = model.getNumberOfIndices();
		size_t numberOfMeshes    = model.getNumberOfMeshes();
		size_t numberOfMaterials = model.getNumberOfMaterials();

		LOG4CPLUS_INFO(logger,"\t\tNumber of vertices:  " << numberOfVertices  );
		LOG4CPLUS_INFO(logger,"\t\tNumber of triangles: " << numberOfTriangles );
		LOG4CPLUS_INFO(logger,"\t\tNumber of indices:   " << numberOfIndices   );
		LOG4CPLUS_INFO(logger,"\t\tNumber of meshes:    " << numberOfMeshes    );
		LOG4CPLUS_INFO(logger,"\t\tNumber of materials: " << numberOfMaterials );

		// 1. Create index buffer to be used by the meshes in this OBJ file
		// Note: CPU index buffer is already set by the OBJ loader
		IndexBufferPtr indexBufPtr;
		{
			GPUIndexBuffer* indexBufGPU;
			const unsigned int* indexBuffer32 = model.getIndexBuffer();

			if(numberOfVertices>65535/*max 16bit number*/){
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				LOG4CPLUS_ERROR(logger,"Cannot use mesh: OpenGL ES cannot index more than 65535 in the same buffer.");
				return false;
#endif
				indexBufGPU = ( new GPUIndexBuffer(
					IndexDataType_32BIT,numberOfIndices,BufferUsageFreq_Static,BufferUsageNature_Draw,false));
				indexBufGPU->writeData(indexBuffer32);
				LOG4CPLUS_INFO(logger," - Index buffer created (using 32bit data). ");
			} else {
				// convert index data to 16 bit
				unsigned short* indexBuffer16 = (unsigned short*) malloc(numberOfIndices*sizeof(unsigned short));
				for(size_t i=0 ; i<numberOfIndices; ++i) indexBuffer16[i] = (unsigned short)indexBuffer32[i];

				indexBufGPU = ( new GPUIndexBuffer(
					IndexDataType_16BIT,numberOfIndices,BufferUsageFreq_Static,BufferUsageNature_Draw,false));
				indexBufGPU->writeData(indexBuffer16);
				free(indexBuffer16);
				LOG4CPLUS_INFO(logger," - Index buffer created (using 16bit data). ");
			}
			indexBufPtr.reset(indexBufGPU);
		}
		
		if(mGenerateTangent){ model.generateTangents(); }
		if(!model.hasNormals()){ model.generateNormals(); }

		// 2. Create vertex buffer to be used by the meshes in this OBJ file
		// Note: CPU vertex buffer is already set by the OBJ loader
		VertexBufferPtr vertexBufPtr;
		{
			GPUVertexBuffer* vertexBufGPU( new GPUVertexBuffer(
				model.getVertexSize(),numberOfVertices,BufferUsageFreq_Static, BufferUsageNature_Draw,false));
			vertexBufGPU->writeData(model.getVertexBuffer());
			vertexBufPtr.reset(vertexBufGPU);
			LOG4CPLUS_INFO(logger," - Vertex buffer created with following data types : ["
				"position:" << (model.hasPositions()?"+":"-") << " "
				"texcoord:" << (model.hasTextureCoords()?"+":"-") << " "
				"normal:" << (model.hasNormals()?"+":"-") << " "
				"tangent:" << (model.hasTangents()?"+":"-") << " "
				"bitangent:" << (model.hasTangents()?"+":"-") << "]");
		}

		for (int i=0; i<model.getNumberOfMeshes(); ++i) {
			// obj stores no names per object, generate the name using the file name
			char meshName[128];
			sprintf(meshName,"%s_%d",getBaseName(fileName).c_str(),i);
			LOG4CPLUS_INFO(logger," Creating mesh with name ["<<meshName<<"] ");
			if(getMeshByName(meshName)){
				LOG4CPLUS_WARN(logger," The mesh["<<meshName<<"] was already defined. Skipping...");
				continue;
			}

			pMesh = &model.getMesh(i);
			pMaterial = pMesh->pMaterial;

			// create and insert new mesh into the loaded mesh list
			MeshPtr newMesh = MeshPtr( new Mesh(meshName) );
			mMeshList.insert( std::pair<std::string, boost::shared_ptr<Mesh> >(meshName, newMesh) );

			MeshGeom* meshGeom = newMesh->createLoDGeom();
			
			///////////////////////////////
			///// MESH INDEX DATA
			{
				IndexDataPtr indexData(meshGeom->mIndexDataPtr);
				indexData->setBufferPtr(indexBufPtr);
				indexData->mRange.set(pMesh->startIndex,pMesh->triangleCount*3);
				indexData->primType = PrimitiveType_Triangles;
				LOG4CPLUS_INFO(logger," - Mesh index data set. ["
					"Start Index:" << indexData->mRange.getStart() <<
					"Size:" << indexData->mRange.getSize() << "]" );
			}
			///////////////////////////////
			///// MESH VERTEX DATA
			{
				VertexDataPtr vertexData =(meshGeom->mVertexDataPtr);
				vertexData->linkBufferToIndex(0,vertexBufPtr);

				// position attribute
				if(model.hasPositions()) {
					vertexData->insertAttribute( VertexAttribute(
						0, 0*sizeof(float), VertexAttribDataType_Float, 
						VertexAttribDataCount3, VertexAttribSem_Position));
				}
				// texture coordinate attribute
				if(model.hasTextureCoords()) {
					vertexData->insertAttribute( VertexAttribute(
						0, 3*sizeof(float), VertexAttribDataType_Float, 
						VertexAttribDataCount2, VertexAttribSem_TexCoord0));
				}
				// normal attribute
				if(model.hasNormals()) {
					vertexData->insertAttribute( VertexAttribute(
						0, 5*sizeof(float), VertexAttribDataType_Float, 
						VertexAttribDataCount3, VertexAttribSem_Normal));
				}
				// tangent attribute
				if(model.hasTangents()) {
					vertexData->insertAttribute( VertexAttribute(
						0, 8*sizeof(float), VertexAttribDataType_Float, 
						VertexAttribDataCount4, VertexAttribSem_Tangent));
//				}
//				// bitangent attribute
//				if(model.hasBitangents()) {
					vertexData->insertAttribute( VertexAttribute(
						0,12*sizeof(float), VertexAttribDataType_Float, 
						VertexAttribDataCount3, VertexAttribSem_Bitangent));
				}

				//////////////////////////////////////////////////////////////////////////
				// set bounding box
				assert(model.hasPositions());

				// center: (0,0,0), half-size: (0,0,0)
				GeomAxisAlignedBox *aabb = new GeomAxisAlignedBox(
					cml::vector3f(0.0f,0.0f,0.0f),cml::vector3f(0.0f,0.0f,0.0f),
					GeomAxisAlignedBox::Set_CenterHSize);
				// center: (0,0,0), half-size: (0,0,0)
				GeomSphere *sphere = new GeomSphere();
				
				// we need to "index" the vertex coordinates...
				size_t i_start = pMesh->startIndex;
				size_t i_end   = i_start + pMesh->triangleCount*3;
				const uint *iBuf = model.getIndexBuffer();
				for(size_t i=i_start; i<i_end ; ++i){
					uint vi = iBuf[i];
					const OBJModel::Vertex &v(model.getVertex(vi));
					GeomPoint p = Vector3(v.position[0], v.position[1], v.position[2]);
					GeomHelper::mergeBounding(*aabb,p);
				}
				GeomHelper::mergeBounding(*sphere,*aabb);

				bool checker = true;
				if(mTmpBoundBoxType == GeomTypeAABox){
					meshGeom->setBoundingVolume(aabb);
				} else if(mTmpBoundBoxType == GeomTypeSphere){
					meshGeom->setBoundingVolume(sphere);
				} else if(mTmpBoundBoxType == GeomTypeOBox){
					cml::quaternionf_n quatid;
					quatid.identity();
					GeomOrientedBox *obb = new GeomOrientedBox(aabb->getPosition(), aabb->getHalfSize(), 
					quatid);
					delete aabb;
					meshGeom->setBoundingVolume(obb);
				} else {
					checker = false;
				}
				if(checker) LOG4CPLUS_INFO(logger," - Bounding box is updated. ");
			}
		}
		model.destroy();

		return true;
	}


	bool MeshManager::loadFrom3DS(const std::string& fileName){
		Logger logger = Logger::getInstance("MeshLoad");
		LOG4CPLUS_INFO(logger,"MeshManager : Loading 3ds file : " << fileName);

		Lib3dsFile *f = lib3ds_file_open(fileName.c_str());
		if(!f) {
			LOG4CPLUS_ERROR(logger," 3DS file could not be parsed.");
			return false;
		}

		// the 3ds file is parsed, now you will use Lib3dsFile abstraction to create your mesh data

		// Create nodes for meshes if no node exists in file(?)
		if (!f->nodes) lib3ds_file_create_nodes_for_meshes(f);

		// evaluate nodes (model matrix handling, etc)
		lib3ds_file_eval(f, 0);

		// for each model/object loaded, add a new mesh to the stored list
		for (Lib3dsNode *nodePtr = f->nodes; nodePtr!=0; nodePtr = nodePtr->next) {
			if (nodePtr->type != LIB3DS_NODE_MESH_INSTANCE) continue;

			Lib3dsMesh *meshPtr3ds = lib3ds_file_mesh_for_node(f, nodePtr);
			const char* meshName = meshPtr3ds->name;

			if(meshPtr3ds->name == 0) meshName = fileName.c_str();
			LOG4CPLUS_INFO(logger," - Creating mesh with name ["<<meshName<<"] ");
			if(getMeshByName(meshName)){
				LOG4CPLUS_WARN(logger," The mesh ["<<meshName<<"] was already defined. Skipping...");
				continue;
			}

			// create and insert new mesh into the loaded mesh list
			MeshPtr newMesh = MeshPtr( new Mesh(meshName) );
			mMeshList.insert( std::pair<std::string, boost::shared_ptr<Mesh> >(meshName, newMesh) );

			// NOTE: Although each face can reference to a different material, we assume that all indexes
			//       Share the same material.
			// TODO: You can sort the faces using materials and sub-divide them into material-based lists.

			size_t numFaces = meshPtr3ds->nfaces;
			size_t numIndices = numFaces*3;
			size_t numVertices = meshPtr3ds->nvertices;

			LOG4CPLUS_INFO(logger,"\t\tNumber of vertices:  " << numVertices  );
			LOG4CPLUS_INFO(logger,"\t\tNumber of triangles: " << numFaces );
			LOG4CPLUS_INFO(logger,"\t\tNumber of indices:   " << numIndices   );

			MeshGeom* meshGeom = newMesh->createLoDGeom();

			if(mMeshOrient==MeshOrientLHS){
				for(size_t i=0; i<numVertices ; i++) {
					// swap x and y coordinates
//					float x = meshPtr3ds->vertices[i][0];
//					meshPtr3ds->vertices[i][0] = meshPtr3ds->vertices[i][1];
//					meshPtr3ds->vertices[i][1] = x;
					meshPtr3ds->vertices[i][2] *= -1;
				}
				for(size_t i=0; i<numFaces ; i++){
					size_t ind1 = meshPtr3ds->faces[i].index[0];
					meshPtr3ds->faces[i].index[0] = meshPtr3ds->faces[i].index[1];
					meshPtr3ds->faces[i].index[1] = ind1;
				}
			}

			// buffers which will be send to GPU later...
			ushort *indexBufCPU = 0;
			float *posBufCPU = 0;
			float *normalBufCPU = 0;
			float *texBufCPU = 0;
			float *tangentBufCPU = 0;
			float *bitangentBufCPU = 0;

			///////////////////////////////
			///// INDEX BUFFER
			{
				IndexDataPtr indexData(meshGeom->mIndexDataPtr);

				// create a temporary index CPU buffer and fill it in 
				indexBufCPU = (ushort*) malloc(numIndices*sizeof(ushort));
				size_t bufInd = 0;
				for(size_t i=0; i<numFaces ; i++){
					indexBufCPU[bufInd++] = meshPtr3ds->faces[i].index[0];
					indexBufCPU[bufInd++] = meshPtr3ds->faces[i].index[1];
					indexBufCPU[bufInd++] = meshPtr3ds->faces[i].index[2];
				}

				// copy the CPU buffer to GPU buffer
				GPUIndexBuffer *indexBufGPU = new GPUIndexBuffer( IndexDataType_16BIT, numIndices,
					BufferUsageFreq_Static, BufferUsageNature_Draw);
				indexBufGPU->writeData(indexBufCPU);
				// Note: you need to set hw buffer pointer first
				indexData->setBufferPtr(boost::shared_ptr<GPUIndexBuffer>(indexBufGPU));
				indexData->mRange.set(0,numIndices);
				indexData->primType = PrimitiveType_Triangles;

				LOG4CPLUS_INFO(logger," - Index buffer created. ");
			}

			VertexDataPtr vertexData =(meshGeom->mVertexDataPtr);

			// center: (0,0,0), half-size: (0,0,0)
			GeomAxisAlignedBox *aabb = new GeomAxisAlignedBox(
				cml::vector3f(0.0f,0.0f,0.0f),cml::vector3f(0.0f,0.0f,0.0f),
				GeomAxisAlignedBox::Set_CenterHSize);
			// center: (0,0,0), half-size: (0,0,0)
			GeomSphere *sphere = new GeomSphere();

			///////////////////////////////
			///// POSITION BUFFER
			{
				posBufCPU = (float*) malloc(3*numVertices*sizeof(float));
				size_t bufInd = 0;
				for(size_t i=0; i<numVertices ; i++){
					GeomPoint p = Vector3(meshPtr3ds->vertices[i][0], meshPtr3ds->vertices[i][1], meshPtr3ds->vertices[i][2]);
					GeomHelper::mergeBounding(*aabb,p);
					posBufCPU[bufInd++] = meshPtr3ds->vertices[i][0];
					posBufCPU[bufInd++] = meshPtr3ds->vertices[i][1];
					posBufCPU[bufInd++] = meshPtr3ds->vertices[i][2];
				}
				GeomHelper::mergeBounding(*sphere,*aabb);

				VertexAttribute posAttrib(0,0,VertexAttribDataType_Float, VertexAttribDataCount3, VertexAttribSem_Position);
				GPUVertexBuffer *posBufGPU = new GPUVertexBuffer(posAttrib.getSizeInBytes(), numVertices,
					BufferUsageFreq_Static, BufferUsageNature_Draw);
				posBufGPU->writeData(posBufCPU);

				vertexData->insertAttribute(posAttrib);
				vertexData->linkBufferToIndex(0,boost::shared_ptr<GPUVertexBuffer>(posBufGPU));

				LOG4CPLUS_INFO(logger," - Position buffer created. ");
				
				// set bounding volume
				// convert AAB to OB
				// choose one
				bool checker = true;
				if(mTmpBoundBoxType == GeomTypeAABox){
					meshGeom->setBoundingVolume(aabb);
				} else if(mTmpBoundBoxType == GeomTypeSphere){
					meshGeom->setBoundingVolume(sphere);
				} else if(mTmpBoundBoxType == GeomTypeOBox){
					cml::quaternionf_n quatid;
					quatid.identity();
					GeomOrientedBox *obb = new GeomOrientedBox(aabb->getPosition(), aabb->getHalfSize(), 
					quatid);
					delete aabb;
					meshGeom->setBoundingVolume(obb);
				} else {
					checker = false;
				}
				if(checker) LOG4CPLUS_INFO(logger," - Bounding box is updated. ");
			}

			///////////////////////////////
			///// NORMAL BUFFER
			if(mGenerateNormals){
				// To access the normal of the i-th vertex of the j-th face: normals[3*j+i]
/*				float (*vertexNormals)[3] = (float(*)[3]) malloc(3*3*sizeof(float)*numFaces);
				lib3ds_mesh_calculate_vertex_normals(meshPtr3ds, vertexNormals);
				float *normalBufCPU = (float*)malloc(3*sizeof(float)*numVertices);
				size_t normBufIndex = 0;
				for(int i=0 ; i<numFaces ; i++){
					for(int j=0 ; j<2 ; j++, normBufIndex++){
						unsigned short vertexIndex = meshPtr3ds->faces[i].index[j];
						size_t hwIndex = vertexIndex*3;
						normalBufCPU[hwIndex+0] = vertexNormals[normBufIndex][0];
						normalBufCPU[hwIndex+1] = vertexNormals[normBufIndex][1];
						normalBufCPU[hwIndex+2] = vertexNormals[normBufIndex][2];
					}
				}
*/
				normalBufCPU = (float*)malloc(3*sizeof(float)*numVertices);

				// set all values to 0
				size_t limit = numVertices * 3;
				for(size_t i=0 ; i<limit ; i++) normalBufCPU[i] = 0.0f;

				// accumulate normals
				for(size_t i=0 ; i<numFaces ; i++){
					Lib3dsFace *curFace = meshPtr3ds->faces + i;

					Vector3 v1(meshPtr3ds->vertices[curFace->index[0]]);
					Vector3 v2(meshPtr3ds->vertices[curFace->index[1]]);
					Vector3 v3(meshPtr3ds->vertices[curFace->index[2]]);

					Vector3 nv(cml::unit_cross(v2-v3, v2-v1));

					size_t normBufIndex;
					for(int j=0 ; j<3 ; j++){
						normBufIndex = curFace->index[j]*3;
						normalBufCPU[normBufIndex+0] += nv[0]; 
						normalBufCPU[normBufIndex+1] += nv[1]; 
						normalBufCPU[normBufIndex+2] += nv[2];
					}					
				}

				// normalize the normal accumulations
				limit = numVertices * 3;
				for(size_t i=0 ; i<limit; ) {
					float mult = 1.0f / (float)sqrt( normalBufCPU[i+0]*normalBufCPU[i+0] + normalBufCPU[i+1]*normalBufCPU[i+1] + 
					                                 normalBufCPU[i+2]*normalBufCPU[i+2]);
					normalBufCPU[i++] *= mult;
					normalBufCPU[i++] *= mult;
					normalBufCPU[i++] *= mult;
				}

				VertexAttribute normAttrib(1,0,VertexAttribDataType_Float, VertexAttribDataCount3, VertexAttribSem_Normal);
				GPUVertexBuffer *normalBufGPU = new GPUVertexBuffer(normAttrib.getSizeInBytes(), numVertices,
					BufferUsageFreq_Static, BufferUsageNature_Draw);
				normalBufGPU->writeData(normalBufCPU);

				vertexData->insertAttribute(normAttrib);
				vertexData->linkBufferToIndex(1,boost::shared_ptr<GPUVertexBuffer>(normalBufGPU));

				LOG4CPLUS_INFO(logger," - Normal buffer created. ");
			}

			///////////////////////////////
			///// TEXTURE COORDINATE BUFFER
			if(meshPtr3ds->texcos){
				texBufCPU = (float*) malloc(2*numVertices*sizeof(float));
				size_t bufInd = 0;
				if(mSwapTexCoordS_T==false){
					for(size_t i=0; i<numVertices ; i++){
						texBufCPU[bufInd++] = meshPtr3ds->texcos[i][0];
						texBufCPU[bufInd++] = meshPtr3ds->texcos[i][1];
					}
				} else {
					for(size_t i=0; i<numVertices ; i++){
						texBufCPU[bufInd++] = meshPtr3ds->texcos[i][1];
						texBufCPU[bufInd++] = meshPtr3ds->texcos[i][0];
					}
				}
				// retrieve the vertex attributes defined
				VertexAttribute texAttrib(2,0,VertexAttribDataType_Float, VertexAttribDataCount2, VertexAttribSem_TexCoord0);
				GPUVertexBuffer *texBufGPU = new GPUVertexBuffer( texAttrib.getSizeInBytes(), numVertices,
					BufferUsageFreq_Static, BufferUsageNature_Draw );
				texBufGPU->writeData(texBufCPU);

				vertexData->insertAttribute(texAttrib);
				vertexData->linkBufferToIndex(2,boost::shared_ptr<GPUVertexBuffer>(texBufGPU));

				LOG4CPLUS_INFO(logger," - Texture buffer created. ");

				if(mGenerateTangent || mGenerateBitangent){
					// Sinan
					// Adil (extensions)
					// Using code snippets from:
						// Lengyel, Eric. 
						// �Computing Tangent Space Basis Vectors for an Arbitrary Mesh�. 
						// Terathon Software 3D Graphics Library, 2001. http://www.terathon.com/code/tangent.html

					{
						size_t bufSize = 4*sizeof(float)*numVertices;
						tangentBufCPU = (float*)malloc(bufSize);
						memset(tangentBufCPU,0,bufSize);
					} {
						size_t bufSize = 3*sizeof(float)*numVertices;
						bitangentBufCPU = (float*)malloc(bufSize);
						memset(bitangentBufCPU,0,bufSize);
					}

					// for each face in the mesh
					for(size_t i=0 ; i<numFaces ; i++){
						Lib3dsFace *curFace = meshPtr3ds->faces + i;

						Vector3 v1(meshPtr3ds->vertices[curFace->index[0]]);
						Vector3 v2(meshPtr3ds->vertices[curFace->index[1]]);
						Vector3 v3(meshPtr3ds->vertices[curFace->index[2]]);
						Vector2 t1(meshPtr3ds->texcos[curFace->index[0]]);
						Vector2 t2(meshPtr3ds->texcos[curFace->index[1]]);
						Vector2 t3(meshPtr3ds->texcos[curFace->index[2]]);

						Vector3 v21 = v2 - v1;
						Vector3 v31 = v3 - v1;

						Vector2 t21 = t2 - t1;
						Vector2 t31 = t3 - t1;
						float coef = 1/ (t21[0] * t31[1] - t31[0] * t21[1]);
						Vector3 tangent  = (v21*t31[1] - v31*t21[1])*coef;
						Vector3 binormal = (v21*t31[0] - v31*t21[0])*coef;

						// insert the tangent/binormal we have found to buffers
						for(int j=0 ; j<3 ; j++){
							{
								size_t normBufIndex = curFace->index[j]*4;
								tangentBufCPU[normBufIndex+0] += tangent[0]; 
								tangentBufCPU[normBufIndex+1] += tangent[1]; 
								tangentBufCPU[normBufIndex+2] += tangent[2];
							} {
								size_t normBufIndex = curFace->index[j]*3;
								bitangentBufCPU[normBufIndex+0] += binormal[0]; 
								bitangentBufCPU[normBufIndex+1] += binormal[1]; 
								bitangentBufCPU[normBufIndex+2] += binormal[2];
							}
						}
					}

					size_t vertDataLim = numVertices*4;
					for(size_t i=0,j=0 ; i<vertDataLim ; ){
						// Gram-Schmidt orthogonalize
						Vector3 curNormal( normalBufCPU +j);
						Vector3 curTangent(tangentBufCPU+i);
						Vector3 curBitangent( bitangentBufCPU +j);
						Vector3 tangent = (curTangent - curNormal*cml::dot(curNormal,curTangent)).normalize();
						Vector3 bitangent = cml::cross(curTangent, curNormal);
						bool isLHS = (cml::dot(bitangent,curBitangent) < 0.f);
						tangentBufCPU[i++] = tangent[0];
						tangentBufCPU[i++] = tangent[1];
						tangentBufCPU[i++] = tangent[2];
						tangentBufCPU[i++] = (isLHS)?-1.f:1.f;
						if(mGenerateBitangent){
							if(isLHS) bitangent *= -1;
							bitangent.normalize();
							bitangentBufCPU[j++] = bitangent[0];
							bitangentBufCPU[j++] = bitangent[1];
							bitangentBufCPU[j++] = bitangent[2];
						}
					}
					if(mGenerateTangent){
						VertexAttribute tangentAttrib(3,0,VertexAttribDataType_Float, VertexAttribDataCount4, VertexAttribSem_Tangent);
						GPUVertexBuffer *tangentBufGPU = new GPUVertexBuffer(tangentAttrib.getSizeInBytes(), numVertices,
							BufferUsageFreq_Static, BufferUsageNature_Draw);
						tangentBufGPU->writeData(tangentBufCPU);

						vertexData->insertAttribute(tangentAttrib);
						vertexData->linkBufferToIndex(3,boost::shared_ptr<GPUVertexBuffer>(tangentBufGPU));
						LOG4CPLUS_INFO(logger," - Tangent buffer created.");
					}
					if(mGenerateBitangent){
						VertexAttribute bitangentAttrib(4,0,VertexAttribDataType_Float, VertexAttribDataCount3, VertexAttribSem_Bitangent);
						GPUVertexBuffer *bitangentBufGPU = new GPUVertexBuffer(bitangentAttrib.getSizeInBytes(), numVertices,
							BufferUsageFreq_Static, BufferUsageNature_Draw);
						bitangentBufGPU->writeData(bitangentBufCPU);

						vertexData->insertAttribute(bitangentAttrib);
						vertexData->linkBufferToIndex(4,boost::shared_ptr<GPUVertexBuffer>(bitangentBufGPU));
						LOG4CPLUS_INFO(logger," - Bitangent buffer created.");
					}
				}
			}

			// delete CPU buffers
			free(indexBufCPU);
			free(posBufCPU);
			free(normalBufCPU);
			free(texBufCPU);
			free(tangentBufCPU);
			free(bitangentBufCPU);

			// get the material name
			int matId = meshPtr3ds->faces[0].material;
			char *materialName = f->materials[matId]->name;
			// set the first space, if any, to string terminator
			size_t len=strlen(materialName);
			for(size_t m=0 ; m<len ; m++) if(materialName[m]==' ') { materialName[m]=0; break; }
			MaterialPtr matFound = MaterialManager::getSingleton().getMaterial(materialName);
			if(matFound == MaterialPtr()){
				LOG4CPLUS_ERROR(logger," The required material["<<materialName<<"] is not defined.");
			} else {
				LOG4CPLUS_INFO(logger," Material["<<materialName<<"] is linked to mesh[" << meshName << "]");
			}
			newMesh->mMaterial = matFound;
		}

		return true;
	}

	MeshPtr MeshManager::createMesh(const std::string& meshName){
		MeshPtr meshPtr;
		if(meshName == "") {
			Logger logger = Logger::getInstance("MeshLoad");
			LOG4CPLUS_WARN(logger, "Given mesh file name for creation is empty: " << meshName);
			return meshPtr;
		}

		MeshList::iterator it;
		it = mMeshList.find(meshName);
		if(it == mMeshList.end() ){
			// mesh name not found, create a new mesh
			// create and insert new mesh into the loaded mesh list
			MeshPtr newMesh = MeshPtr( new Mesh(meshName) );
			mMeshList.insert( std::pair<std::string, MeshPtr>(meshName, newMesh) );
			return newMesh;
		} else {
			return meshPtr;
		}
	}

	MeshPtr MeshManager::_getMeshByName(const std::string& meshName){
		if(!isSpecialName(meshName)){
			Logger logger = Logger::getInstance("MeshLoad");
			LOG4CPLUS_WARN(logger, "Given special mesh file name for creation does not start with re_ prefix: " << meshName);
			return MeshPtr();
		}
		MeshList::iterator it;
		it = mMeshList.find(meshName);
		if(it == mMeshList.end() ){
			MeshPtr newMesh = MeshPtr( new Mesh(meshName) );
			mMeshList.insert( std::pair<std::string, MeshPtr>(meshName, newMesh) );
			return newMesh;
		} else {
			return it->second;
		}
	}

	MeshPtr MeshManager::getMeshByName(const std::string& meshName) const{
		MeshList::const_iterator it;
		it = mMeshList.find(meshName);
		if(it == mMeshList.end() ){
			// mesh name not found
			return MeshPtr();
		} else {
			return it->second;
		}
	}
		
	MeshPtr MeshManager::getSkyMesh(){
		std::string meshName("re_CubeMap");
		MeshList::iterator it;
		it = mMeshList.find(meshName);
		if(it != mMeshList.end() ) return it->second;
		
		MeshPtr skyMesh = MeshPtr( new Mesh(meshName) );
		mMeshList.insert( std::pair<std::string, MeshPtr>(meshName, skyMesh) );

		// SET MATERIAL ONLY
		skyMesh->mMaterial = MaterialManager::getSingleton().getMaterial("re_Sky");
		return skyMesh;
	}

}

