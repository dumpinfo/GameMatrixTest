/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Camera.h"

#include <math.h>

namespace REng {

	Camera::Camera(CameraNode& node) 
		:mSwapXY(false)
		,mSynchAspectRatioFromViewport(true)
		,mNode(node)
		,mAspectRatio(1.33f)
		,mNearDistance(0.1f)
		,mFarDistance(300.0f)
		,mFoV_y(45.0f)
		,mProjectionMatrix_Dirty(true)
		,mFrustum_Dirty(true)
	{ 
		// inform parent
		node.mCamera = this;
		node.mBoundingVolume_WS = &mFrustum_Cache;
	}
	Camera::~Camera() { ; }

	void Camera::swapXY(Matrix4& proj){
		// swap 1st and second row
		float row0[4], row1[4];
		row0[0] = proj(0,0);
		row0[1] = proj(0,1);
		row0[2] = proj(0,2);
		row0[3] = proj(0,3);
		row1[0] = proj(1,0);
		row1[1] = proj(1,1);
		row1[2] = proj(1,2);
		row1[3] = proj(1,3);
		proj(0,0) = row1[0];
		proj(0,1) = row1[1];
		proj(0,2) = row1[2];
		proj(0,3) = row1[3];
		proj(1,0) = -row0[0];
		proj(1,1) = -row0[1];
		proj(1,2) = -row0[2];
		proj(1,3) = -row0[3]+1;
	}

	/************************************************************************/
	/* Perspective Camera                                                   */
	/************************************************************************/

	CameraPerspective::CameraPerspective(CameraNode& node) 
		: Camera(node) { ; }
	CameraPerspective& CameraPerspective::create(CameraNode& node){
		return *(new CameraPerspective(node));
	}
	void CameraPerspective::updateProjectionMatrix() const {
		cml::matrix_perspective_yfov_RH( mProjectionMatrix_Cache,
			mFoV_y.getRadian(),
			mAspectRatio,
			mNearDistance,
			mFarDistance,
			cml::z_clip_zero);
		if(mSwapXY) swapXY(mProjectionMatrix_Cache);
		mProjectionMatrix_Dirty = false;
	}
	void CameraPerspective::generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay){
		Vector3 camDirection(0.0,0.0,0.0);
		// nearPlane : half of dimensions
		float nearPlaneHeight_half = mNearDistance * std::tan(mFoV_y.getRadian()/2.0f);
		float nearPlaneWidth_half = nearPlaneHeight_half * mAspectRatio;
		camDirection += Vector3(0.0,1.0,0.0) * nearPlaneHeight_half * -((heightRatio - 0.5)*2.0 );
		camDirection += Vector3(1.0,0.0,0.0) * nearPlaneWidth_half	* ((widthRatio - 0.5)*2.0 );
		camDirection += Vector3(0.0,0.0,-1.0) * mNearDistance;

		Matrix4 matRot;
		cml::matrix_rotation_quaternion(matRot,mNode.getRotation_World());
		camDirection = cml::transform_vector(matRot, camDirection);
	
		pickRay.setPosition(mNode.getTranslation_World());
		pickRay.setDirection(camDirection);
		
		return;
	}
	void CameraPerspective::updateFrustum() const{
		// see www.lighthouse3d.com/opengl/viewfrustum/index.php
		float nWHalf, nHHalf, fWHalf, fHHalf;

		nHHalf = getNearDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		nWHalf = nHHalf * getAspectRatio();
		fHHalf = getFarDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		fWHalf = fHHalf * getAspectRatio();

		const Vector3& position(getPosition());
		const Vector3& dirVec(mNode.getDirection());
		const Vector3& rightVec(mNode.getRight());
		const Vector3& upVec(mNode.getUp());

		Vector3 dirNear(dirVec*getNearDistance());
		Vector3 dirFar(dirVec*getFarDistance());

		Vector3 nc(position + dirNear);   // center point on the near plane
		Vector3 fc(position + dirFar);    // center point on the far plane
		Vector3 rNear(rightVec * nWHalf); // the right-vector to the corner on near plane 
		Vector3 uNear(upVec    * nHHalf); // the up-vector    to the corner on near plane 
		Vector3 rFar(rightVec  * fWHalf); // the right-vector to the corner on near plane 
		Vector3 uFar(upVec     * fHHalf); // the up-vector    to the corner on near plane 

		// near plane can be defined with dirVec as a normal and nc as a point on the plane.
		GeomPlane nearPlane(nc,dirVec);
		// far plane can be defined with -dirVec as a normal and fc as a point on the plane.
		GeomPlane farPlane(fc,-dirVec);

		Vector3 a;
		a = dirFar + rFar;
		GeomPlane rightPlane(position,cml::cross(upVec,a.normalize()));
		a = dirFar - rFar;
		GeomPlane leftPlane(position,cml::cross(a.normalize(),upVec));

		a = dirFar + uFar;
		GeomPlane upPlane(position,cml::cross(a.normalize(),rightVec));
		a = dirFar - uFar;
		GeomPlane downPlane(position,cml::cross(rightVec,a.normalize()));

		mFrustum_Cache.clearPlaneList();
		mFrustum_Cache.addPlane(rightPlane);
		mFrustum_Cache.addPlane(leftPlane);
		mFrustum_Cache.addPlane(upPlane);
		mFrustum_Cache.addPlane(downPlane);
		mFrustum_Cache.addPlane(nearPlane);
		mFrustum_Cache.addPlane(farPlane);

		mFrustum_Dirty = false;
	}
	void CameraPerspective::getFrustumCorners(Vector3* cornerData) const{
		assert(cornerData&&"Invalid pointer");

		float nWHalf, nHHalf, fWHalf, fHHalf;

		nHHalf = getNearDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		nWHalf = nHHalf * getAspectRatio();
		fHHalf = getFarDistance() * std::tan(getFieldOfView_y().getRadian() / 2.0f );
		fWHalf = fHHalf * getAspectRatio();

		const Vector3& position(getPosition());
		const Vector3& dirVec(mNode.getDirection());
		const Vector3& rightVec(mNode.getRight());
		const Vector3& upVec(mNode.getUp());

		Vector3 dirNear(dirVec*getNearDistance());
		Vector3 dirFar(dirVec*getFarDistance());

		Vector3 nc(position + dirNear);   // center point on the near plane
		Vector3 fc(position + dirFar);    // center point on the far plane
		Vector3 rNear(rightVec * nWHalf); // the right-vector to the corner on near plane 
		Vector3 uNear(upVec    * nHHalf); // the up-vector    to the corner on near plane 
		Vector3 rFar(rightVec  * fWHalf); // the right-vector to the corner on near plane 
		Vector3 uFar(upVec     * fHHalf); // the up-vector    to the corner on near plane 

		cornerData[0] = nc + uNear + rNear;
		cornerData[1] = nc + uNear - rNear;
		cornerData[2] = nc - uNear + rNear;
		cornerData[3] = nc - uNear - rNear;
		cornerData[4] = fc + uFar + rFar;
		cornerData[5] = fc + uFar - rFar;
		cornerData[6] = fc - uFar + rFar;
		cornerData[7] = fc - uFar - rFar;
	}



	/************************************************************************/
	/* Orthogonal Camera                                                    */
	/************************************************************************/

	CameraOrthogonal::CameraOrthogonal(CameraNode& node) 
		: Camera(node) { ; }
	CameraOrthogonal& CameraOrthogonal::create(CameraNode& node){
		return *(new CameraOrthogonal(node));
	}
	void CameraOrthogonal::updateProjectionMatrix() const {
		float tangent = tan(mFoV_y.getRadian()/2.0f);
		float width = tangent*mNearDistance*2;
		float height = width/mAspectRatio;
		cml::matrix_orthographic_RH(mProjectionMatrix_Cache,
			width,
			height,
			mNearDistance,
			mFarDistance,
			cml::z_clip_neg_one);
		mProjectionMatrix_Dirty = false;
	}
	void CameraOrthogonal::generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay){
		// TODO
		return;
	}
	void CameraOrthogonal::updateFrustum() const{
		// TODO
		mFrustum_Dirty = false;
	}
	void CameraOrthogonal::getFrustumCorners(Vector3* cornerData) const {
		// TODO
		(void) cornerData;
	}

}
