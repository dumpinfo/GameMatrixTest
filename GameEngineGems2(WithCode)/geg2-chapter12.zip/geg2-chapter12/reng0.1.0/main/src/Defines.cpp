/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Defines.h"

#include "REng/GPU/GPUConfig.h"

#include "log4cplus/logger.h"
using namespace log4cplus;

namespace REng{

	const char * gVertexAttribSemanticStr[] = {
		"re_Position",
		"re_Normal",
		"re_Tangent",
		"re_Bitangent",
		"re_PSize",
		"re_ColorDiffuse",
		"re_ColorSpecular",
		"re_TexCoord0",
		"re_TexCoord1",
		"re_TexCoord2",
		"re_TexCoord3",
		"re_TexCoord4",
		"re_TexCoord5",
		"re_TexCoord6",
		"re_TexCoord7",
		"",
	};


	const char* getGLErrorStr(GLenum errCode){
		switch(errCode){
			case GL_NO_ERROR:
				return "No OpenGL error";
			case GL_OUT_OF_MEMORY:
				return "OUT OF MEMORY: Not enough memory left to execute command.";
			case GL_INVALID_ENUM:
				return "INVALID ENUM: An enumerated argument was out of range.";
			case GL_INVALID_VALUE:
				return "INVALID VALUE: A numeric argument was out of range.";
			case GL_INVALID_OPERATION:
				return "INVALID OPERATION: Operation was invalid in current state.";
			case GL_INVALID_FRAMEBUFFER_OPERATION:
				return "INVALID FRAMEBUFFER OPERATION: Framebuffer object is not complete for the operation to complete.";
		}
		return "OpenGL Error code is not recognized.";
	}

	void checkGLError_Term(const char * logstr, int logint){
		GLenum errCode;
		static Logger logger = Logger::getInstance("RSys");
		if( (errCode = glGetError()) != GL_NO_ERROR) {
			const char *errStr = getGLErrorStr(errCode);
			LOG4CPLUS_FATAL(logger, "["<<logstr<<":"<<logint<<"] OpenGL Error detected: " << errStr);
			exit(1);
		} else {
			//LOG4CPLUS_INFO(logger, "["<<logstr<<":"<<logint<<"] No OpenGL Error is detected.");
		}
	}

	void checkGLError(const char * logstr, int logint){
		GLenum errCode;
		static Logger logger = Logger::getInstance("RSys");
		if( (errCode = glGetError()) != GL_NO_ERROR) {
			const char *errStr = getGLErrorStr(errCode);
			LOG4CPLUS_FATAL(logger, "["<<logstr<<":"<<logint<<"] OpenGL Error detected: " << errStr);
		} else {
			//LOG4CPLUS_INFO(logger, "["<<logstr<<":"<<logint<<"] No OpenGL Error is detected.");
		}
	}

	//! requires GPUConfig info
	bool isSupported(ShaderVersion _version){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(_version){
			case ShaderVersion_100ES:   return true;
			case ShaderVersion_Default: return true;
			default:                    return false;
		}
		#endif
		// TODO: Check OpenGL context version
		GPUConfig& cfg(GPUConfig::getSingleton());
		size_t GLSLversion = 100*cfg.getGLSLVersionMajor()+cfg.getGLSLVersionMinor();
		switch(_version){
			case ShaderVersion_100ES: 
				return false;
			case ShaderVersion_130:
				if(GLSLversion<130) {
					LOG4CPLUS_INFO(Logger::getInstance("RSys"),
						"The requested shader version (130) is not supported. "
						"Current version is " << GLSLversion);
					return false;
				}
				break;
			case ShaderVersion_140:
				if(GLSLversion<140) {
					LOG4CPLUS_INFO(Logger::getInstance("RSys"),
						"The requested shader version (140) is not supported. "
						"Current version is " << GLSLversion);
					return false;
				}
				break;
			case ShaderVersion_150:
				if(GLSLversion<150) {
					LOG4CPLUS_INFO(Logger::getInstance("RSys"),
						"The requested shader version (150) is not supported. "
						"Current version is " << GLSLversion);
					return false;
				}
				break;
			case ShaderVersion_330:
				if(GLSLversion<330) {
					LOG4CPLUS_INFO(Logger::getInstance("RSys"),
						"The requested shader version (330) is not supported. "
						"Current version is " << GLSLversion);
					return false;
				}
				break;
			default:  break;
		}
		return true;
	}



}
