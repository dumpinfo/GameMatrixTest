/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/MultiViewBuffer.h"

#include "REng/Viewport.h"
#include "REng/GPU/GPUFrameBuffer.h"
#include "REng/GPU/GPUTexture.h"
#include "REng/GPU/GPURenderBuffer.h"
#include "REng/RenderSystem.h"
#include "REng/GPU/GPUConfig.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	MVBuffer_Cfg_Offtarget::MVBuffer_Cfg_Offtarget()
		:colorFormat(ImageFormat_RGBA)
		,depthFormat(ImageFormat_D)
		,stencilFormat(ImageFormat_S)
		,sharedDepthStencilTargets(true)
		,sharedFrameBuffer(true)
		,halfResHeight(false)
		,halfResWidth(false)
	{
		lod.halfResBuffer = false;
	}
	MVBuffer_Cfg::MVBuffer_Cfg()
		:viewCount(2)
		,type(MVBufferType_Offtarget)
		{ }
	bool MVBuffer_Cfg::isValid() const{
		if(viewCount<2) return false;
		switch(type){
			case MVBufferType_Offtarget:
				if(!isDepthFormat(offtarget.depthFormat)) 
					return (offtarget.depthFormat==ImageFormat_None);
				if(!isStencilFormat(offtarget.stencilFormat)) 
					return (offtarget.stencilFormat==ImageFormat_None);
				if(!isColorFormat(offtarget.colorFormat)) 
					return false;
				break;
			case MVBufferType_Ontarget:
				if(ontarget.viewRects.size()==0) return true;
				if(ontarget.viewRects.size()==viewCount) return true;
				return false;
			default: break;
		}
		return true;
	}


	MultiViewBuffer::MultiViewBuffer()
		:mViewCount(0)
		,mActiveView(0)
		,mIsInitialized(false)
		,mTargetViewport(0)
		{ }

	MultiViewBuffer::~MultiViewBuffer(){
		clear();
	}

	void MultiViewBuffer::clear(){
		for(size_t i=0 ; i<mStencilTargets.size() ; ++i){
			delete mStencilTargets[i];
		}
		mStencilTargets.clear();
		for(size_t i=0 ; i<mDepthTargets.size() ; ++i){
			delete mDepthTargets[i];
		}
		mDepthTargets.clear();
		for(size_t i=0 ; i<mDepthStencilTargets.size() ; ++i){
			delete mDepthStencilTargets[i];
		}
		mDepthStencilTargets.clear();
		for(size_t i=0 ; i<mColorTargets.size() ; ++i){
			delete mColorTargets[i];
		}
		mColorTargets.clear();
		for(size_t i=0 ; i<mFrameBufferList.size() ; ++i){
			delete mFrameBufferList[i];
		}
		mFrameBufferList.clear();

		mIsInitialized=false;
	}

	bool MultiViewBuffer::isInitialized() const{
		return mIsInitialized;
	}
	uchar MultiViewBuffer::getViewCount() const {
		return mViewCount;
	}
	MVBufferType MultiViewBuffer::getType() const{
		return mType;
	}

	bool MultiViewBuffer::setActiveView(size_t viewIndex) {
		if(!mIsInitialized) return false;
		if(viewIndex>=mViewCount) return false;
		mActiveView = viewIndex;
		switch(mType){
			case MVBufferType_Ontarget:  if(!setView_Ontarget() ) return false; break;
			case MVBufferType_Offtarget: if(!setView_Offtarget()) return false; break;
			default:                     break;
		}
		return true;
	}

	bool MultiViewBuffer::setView_Ontarget(){
		if(mTargetViewport->mRenderTarget==0){
			GPUFrameBuffer::unbindResource();
			// Automated OpenGL Quad Buffering support (TODO)
			if(false/*mTargetViewport->mRelRect->isQuadBuffer()*/) {
				#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
				if(mActiveView == 0){
					glDrawBuffer(GL_BACK_LEFT);
				} else {
					glDrawBuffer(GL_BACK_RIGHT);
				}
				#endif
			}
		} else {
			mTargetViewport->mRenderTarget->bindResource();
		}

		if(mViewRects.size()>0){
			RectI targetRect = mTargetViewport->getAbsRect();
			RectF subRect = mViewRects[mActiveView];
			RectI finalRect;
			int left, bottom;
			targetRect.getOrigin(left,bottom);
			finalRect.setOrigin(
				left+subRect.getLeft()*targetRect.getWidth(),
				bottom+subRect.getBottom()*targetRect.getHeight());
			finalRect.setSize(
				targetRect.getWidth()*subRect.getWidth(),
				targetRect.getHeight()*subRect.getHeight());
			RenderSystem::getSingleton().setViewportTrans(finalRect);
		} else {
			RenderSystem::getSingleton().setViewportTrans(mTargetViewport->getAbsRect());
		}
		return true;
	}
	bool MultiViewBuffer::setView_Offtarget(){
		Logger logger = Logger::getInstance("RSys");
		// bind frame buffer
		getFrameBuffer(mActiveView)->bindResource();
		// attach view-specific depth-stencil buffer target
		if(isDepthStencilDynamic()){
			GPURenderBuffer* depthTarget   = getDepthTarget(mActiveView);
			GPURenderBuffer* stencilTarget = getStencilTarget(mActiveView);
			if(depthTarget) {
				if(!depthTarget->attachToActiveFBODepth())
					LOG4CPLUS_INFO(logger, "Cannot attach depth target");
			}
			if(stencilTarget) {
				if(!stencilTarget->attachToActiveFBOStencil())
					LOG4CPLUS_INFO(logger, "Cannot attach stencil target");
			}
		}
		// attach view-specific color buffer targets
		if(isColorDynamic()){
			if(!attachColorTargets(mActiveView))
				LOG4CPLUS_INFO(logger, "Cannot attach color target");
		}
#ifdef RENG_DEBUG_BUILD
		if(isColorDynamic()||isDepthStencilDynamic()){
			GLenum status;
			getFrameBuffer(mActiveView)->isComplete(status);
		}
#endif
		// update viewport to match the buffer size
		ushort width,height;
		getBufferSize(mActiveView, width, height);
		RenderSystem::getSingleton().setViewportTrans(RectI(0,width,0,height));
		return true;
	}




	bool MultiViewBuffer::init(Viewport& vp, const MVBuffer_Cfg& cfg){
		if(mIsInitialized) return false;
		
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "MultiViewBuffer initializing...");

		if(!cfg.isValid()) {
			LOG4CPLUS_WARN(logger, "Multi view buffer configuration is not valid.");
			return false;
		}

		mTargetViewport = &vp;
		mViewCount = cfg.viewCount;
		mType = cfg.type;

		switch(mType){
			case MVBufferType_Ontarget:   if(!init_Ontarget(cfg.ontarget)) return false; break;
			case MVBufferType_Offtarget:  if(!init_Offtarget(cfg.offtarget)) return false; break;
			default: return false;
		}
		LOG4CPLUS_INFO(logger, "MultiViewBuffer initialization completed...");
		mIsInitialized = true;
		return true;
	}

	bool MultiViewBuffer::init_Ontarget(const MVBuffer_Cfg_Ontarget& cfg){
		if(mTargetViewport->mRenderTarget==0){
			// check if the render targets support OpenGL Quad Buffering
			if(false/*mTargetViewport->mRelRect->isQuadBuffer()*/) {
				// TODO: check if viewport renders to a default framebuffer, 
				//       with a stereo buffer support.
				mIsInitialized = false;
				return false;			
			}
		}
		mViewRects = cfg.viewRects;
		return true;
	}
	void MultiViewBuffer::updateBufferSizeUsingCfg(int& width, int& height, uchar viewId, 
		                                    const MVBuffer_Cfg_Offtarget_LoD& cfg)
	{
		if(cfg.halfResBuffer){
			if(viewId%2){
				width  = width/2;
				height = height/2;
			}
		}
	}

	bool MultiViewBuffer::init_Offtarget(const MVBuffer_Cfg_Offtarget& cfg){
		Logger logger = Logger::getInstance("RSys");

		CHECKGLERROR_TERM();

		// buffer width-height setting
		int bufWidth = mTargetViewport->getAbsRect().getWidth();
		int bufHeight= mTargetViewport->getAbsRect().getHeight();
		if(cfg.halfResWidth)  bufWidth  = bufWidth  / 2;
		if(cfg.halfResHeight) bufHeight = bufHeight / 2;

		LOG4CPLUS_INFO(logger, "  Buffer Width : " << bufWidth);
		LOG4CPLUS_INFO(logger, "  Buffer Height : " << bufHeight);

		// If using LoD, we need to have not-shared buffers
		// TODO: If only two buffer sizes are used, and there are more than one view using
		// a size, they may instead share the  buffers. 
		if(cfg.lod.halfResBuffer){
			mSharedDepthStencilTargets = false;
			LOG4CPLUS_INFO(logger, "  HalfResLoD : No buffers will be shared between views...");
		} else {
			mSharedDepthStencilTargets = cfg.sharedDepthStencilTargets;
		}

		//////////////////////////////////////
		// frame buffers
		uchar frameBufferCount = 1;
		if(!cfg.sharedFrameBuffer) frameBufferCount = mViewCount;
		LOG4CPLUS_INFO(logger, "  Frame Buffer Count : " << int(frameBufferCount));
		GPUFrameBuffer::setBindTarget(FrameBufferBindTarget_Default);
		for(uchar i=0;i<frameBufferCount; ++i){
			mFrameBufferList.push_back(new GPUFrameBuffer());
		}

		CHECKGLERROR_TERM();

		//////////////////////////////////////
		// create depth-stencil targets
		//////////////////////////////////////
		uchar depthStencilTargetCount = 1;
		if(!mSharedDepthStencilTargets) depthStencilTargetCount = mViewCount;
		for(uchar i=0;i<depthStencilTargetCount ; ++i){
			GPURenderBuffer *rbuf;
			int viewBufWidth  = bufWidth;
			int viewBufHeight = bufHeight;
			updateBufferSizeUsingCfg(viewBufWidth,viewBufHeight,i,cfg.lod);

			// stencil-depth target (both are valid targets for their type)
			if(cfg.depthFormat==cfg.stencilFormat && cfg.depthFormat!=ImageFormat_None){
				rbuf = new GPURenderBuffer();
				if(rbuf->storage(cfg.depthFormat,viewBufWidth,viewBufHeight)==false){
					LOG4CPLUS_ERROR(logger, "  Cannot init depth-stencil buffer target with the given format.");
					clear(); return false;
				}
				mDepthStencilTargets.push_back(rbuf);
				continue;
			}

			// depth target
			if(cfg.depthFormat!=ImageFormat_None){
				rbuf = new GPURenderBuffer();
				if(rbuf->storage(cfg.depthFormat,viewBufWidth,viewBufHeight)==false){
					LOG4CPLUS_ERROR(logger, "  Cannot init depth buffer target with the given format.");
					clear(); return false;
				} else {
					LOG4CPLUS_INFO(logger, "  Depth buffer target with the given format is created.");
				}
				mDepthTargets.push_back(rbuf);
			}

			// stencil target
			if(cfg.stencilFormat!=ImageFormat_None){
				rbuf = new GPURenderBuffer();
				if(rbuf->storage(cfg.stencilFormat,viewBufWidth,viewBufHeight)==false){
					LOG4CPLUS_ERROR(logger, "  Cannot init stencil buffer target with the given format.");
					clear(); return false;
				} else {
					LOG4CPLUS_INFO(logger, "  Stencil buffer target with the given format is created.");
				}
				mStencilTargets.push_back(rbuf);
			}
		}
		LOG4CPLUS_INFO(logger, "  Depth/stencil buffers are set-up.");

		CHECKGLERROR_TERM();

		uchar colorTargetCount = mViewCount;
		for(uchar i=0;i<colorTargetCount ; ++i){
			int viewBufWidth  = bufWidth;
			int viewBufHeight = bufHeight;
			updateBufferSizeUsingCfg(viewBufWidth,viewBufHeight,i,cfg.lod);
			GPUTexture* tex = new GPUTexture(TextureType_2D);
			tex->setInternalFormat(cfg.colorFormat);
			if(cfg.lod.halfResBuffer==true && i%2){
				// alternate between nearest and bilinear filtering
				tex->setMagFilter(MagFilter_Linear);
				tex->setMinFilter(MinFilter_Linear);
			} else {
				tex->setMagFilter(MagFilter_Nearest);
				tex->setMinFilter(MinFilter_Nearest);
			}
			tex->setWrap(WrapAxis_S,WrapMode_Repeat);
			tex->setWrap(WrapAxis_T,WrapMode_Repeat);
			tex->setGenMipmaps(false);
			tex->updateSamplerState();
			if(tex->loadFromMemToResource(viewBufWidth,viewBufHeight,PixelDataType_UByte,PixelDataFormat_RGBA,0)==false){
				LOG4CPLUS_ERROR(logger, "  Cannot create color buffer target with the given format.");
				clear(); return false;
			} else {
				LOG4CPLUS_INFO(logger, " Color buffer target with the given format is created.");
			}
			mColorTargets.push_back(tex);
		}
		LOG4CPLUS_INFO(logger, "  Color buffers are set-up.");

		CHECKGLERROR_TERM();

		//////////////////////////////////////
		// attach targets
		//////////////////////////////////////
		for(uchar i=0; i<frameBufferCount ; ++i){
			mFrameBufferList[i]->bindResource();
				if(!isColorDynamic()){
					if(!attachColorTargets(i))  LOG4CPLUS_ERROR(logger, " Cannot attach color target to frame buffer " << int(i));
				}
				if(!isDepthStencilDynamic()){
					if(!attachDepthTarget(i))   LOG4CPLUS_ERROR(logger, " Cannot attach depth target to frame buffer " << int(i));
					if(cfg.stencilFormat==ImageFormat_None) continue;
					if(!attachStencilTarget(i)) LOG4CPLUS_ERROR(logger, " Cannot attach stencil target to frame buffer " << int(i));
				}
		}
		LOG4CPLUS_INFO(logger, "  Color-Depth-Stencil buffers are attached.");

		CHECKGLERROR_TERM();

#ifdef RENG_DEBUG_BUILD
		if(!isColorDynamic() && !isDepthStencilDynamic()){
			// buffer binding may be dynamic, the buffer may not be complete yet, but be complete later on when used.
			LOG4CPLUS_INFO(logger, "  Checking completeness...");
			for(uchar i=0; i<frameBufferCount ; ++i){
				GLenum status;
				if(mFrameBufferList[i]->isComplete(status)==false){
					LOG4CPLUS_ERROR(logger, "  Frame buffer is not complete although all targets are static.");
					clear(); return false;
				} else {
					LOG4CPLUS_INFO(logger, "  Frame buffer is complete with static targets.");
				}
			}
		}
#endif // RENG_DEBUG_BUILD
		GPUFrameBuffer::unbindResource();

		return true;
	}


	GPUFrameBuffer* MultiViewBuffer::getFrameBuffer(uchar viewIndex){
		assert(viewIndex<mViewCount);
		size_t frameBufferCount = mFrameBufferList.size();
		if(frameBufferCount==1) return mFrameBufferList[0];
		return mFrameBufferList[viewIndex];
	}
	GPUTexture* MultiViewBuffer::getColorTarget(uchar viewIndex){
		assert(viewIndex<mViewCount);
		size_t colorTargetCounr = mColorTargets.size();
		if(colorTargetCounr==1) return mColorTargets[0];
		return mColorTargets[viewIndex];
	}
	GPURenderBuffer* MultiViewBuffer::getDepthTarget(uchar viewIndex){
		assert(viewIndex<mViewCount);
		size_t depthStencilTargetCount = mDepthStencilTargets.size();
		if(depthStencilTargetCount>0){
			if(depthStencilTargetCount==1) return mDepthStencilTargets[0];
			return mDepthStencilTargets[viewIndex];
		}
		size_t depthTargetCount = mDepthTargets.size();
		if(depthTargetCount==1) return mDepthTargets[0];
		return mDepthTargets[viewIndex];
	}
	GPURenderBuffer* MultiViewBuffer::getStencilTarget(uchar viewIndex){
		assert(viewIndex<mViewCount);
		size_t depthStencilTargetCount = mDepthStencilTargets.size();
		if(depthStencilTargetCount>0){
			if(depthStencilTargetCount==1) return mDepthStencilTargets[0];
			return mDepthStencilTargets[viewIndex];
		}
		size_t stencilTargetCount = mStencilTargets.size();
		if(stencilTargetCount==0) return 0;
		if(stencilTargetCount==1) return mStencilTargets[0];
		return mStencilTargets[viewIndex];
	}
	bool MultiViewBuffer::attachDepthTarget(uchar viewIndex){
		GPURenderBuffer* depthTarget = getDepthTarget(mActiveView);
		if(!depthTarget) return false;
		return depthTarget->attachToActiveFBODepth();
	}
	bool MultiViewBuffer::attachStencilTarget(uchar viewIndex){
		GPURenderBuffer* stencilTarget = getStencilTarget(mActiveView);
		if(!stencilTarget) return false;
		return stencilTarget->attachToActiveFBOStencil();
	}
	bool MultiViewBuffer::attachColorTargets(uchar viewIndex){
		getColorTarget(viewIndex)->attachToActiveFBO(FrameBufferAttachType_Color0);
		return true;
	}

	bool MultiViewBuffer::isDepthStencilDynamic() const {
		// A single frame buffer, not-shared targets
		return mFrameBufferList.size()==1 && !mSharedDepthStencilTargets;
	}
	bool MultiViewBuffer::isColorDynamic() const{
		// color is alyaws dynamic
		return true;
	}

	void MultiViewBuffer::getBufferSize(uchar viewIndex, ushort& width, ushort& height){
		GPUTexture* clrTarget = getColorTarget(viewIndex);
		width = clrTarget->getWidth();
		height = clrTarget->getHeight();
	}

	void MultiViewBuffer::_loadDebugTextureData(){
		for(size_t i=0 ; i<mColorTargets.size() ; ++i){
			ushort width = mColorTargets[i]->getWidth();
			ushort height = mColorTargets[i]->getHeight();
			size_t image_size = width*height*4;
			GLubyte *texture = (GLubyte*) malloc(image_size*sizeof(GLubyte));
			if(i%3==0) {
				for(size_t j=0 ; j<image_size ; j+=4) {
					texture[j+0] = 255; texture[j+1] = 0; texture[j+2] = 0; texture[j+3] = 0;
				}
				mColorTargets[i]->loadFromMemToResource( width,height,PixelDataType_UByte,PixelDataFormat_RGBA,texture);
			}
			if(i%3==1) {
				for(size_t j=0 ; j<image_size ; j+=4) {
					texture[j+0] = 0; texture[j+1] = 255; texture[j+2] = 0; texture[j+3] = 0;
				}
				mColorTargets[i]->loadFromMemToResource( width,height,PixelDataType_UByte,PixelDataFormat_RGBA,texture);
			}
			if(i%3==2) {
				for(size_t j=0 ; j<image_size ; j+=4) {
					texture[j+0] = 0; texture[j+1] = 0; texture[j+2] = 255; texture[j+3] = 0;
				}
				mColorTargets[i]->loadFromMemToResource( width,height,PixelDataType_UByte,PixelDataFormat_RGBA,texture);
			}
			free(texture);
		}
	}



} // namespace REng
