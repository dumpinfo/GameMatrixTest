/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GeomRenderer.h"

#include "REng/MeshGeomGenerator.h"

namespace REng{

	/************************************************************************/
	/* SINGLETON STUFF                                                      */
	/************************************************************************/
	template<> GeomRenderer* Singleton<GeomRenderer>::ms_Singleton = 0;
	GeomRenderer* GeomRenderer::getSingletonPtr(void) {
		return ms_Singleton;
	}
	GeomRenderer& GeomRenderer::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	GeomRenderer::GeomRenderer(){
		;
	}
	GeomRenderer::~GeomRenderer(){
		;
	}

	/************************************************************************/
	/* MODEL MATRIX UPDATER                                                 */
	/************************************************************************/

	void GeomRenderer::getModelMatrix(
		const cml::vector3f& translation, const cml::vector3f& scale, Matrix4& toRet){
		;
		static float matVal[4][4];
		EXEC_ONCE_BEGIN();
			matVal[3][3] = 1.0f;
			matVal[0][1] = 0.0f;
			matVal[0][2] = 0.0f;
			matVal[1][0] = 0.0f;
			matVal[1][2] = 0.0f;
			matVal[2][0] = 0.0f;
			matVal[2][1] = 0.0f;
			matVal[3][0] = 0.0f;
			matVal[3][1] = 0.0f;
			matVal[3][2] = 0.0f;
		EXEC_ONCE_END();
		// diagonals: scale
		matVal[0][0] = scale[0];
		matVal[1][1] = scale[1];
		matVal[2][2] = scale[2];
		// translation
		matVal[0][3] = translation[0];
		matVal[1][3] = translation[1];
		matVal[2][3] = translation[2];
		toRet = matVal;
	}

	void GeomRenderer::getModelMatrix(const GeomOrientedBox& box, Matrix4& toRet){
		toRet.identity();
		Matrix4 matMult;
		// 3. translation
		cml::matrix_translation(matMult,box.getPosition());
		toRet *= matMult;
		// 2. rotation
		cml::matrix_rotation_quaternion(matMult,box.getWorldOrientation());
		toRet *= matMult;
		// 1. scale
		cml::matrix_scale(matMult,box.getHalfSize());
		toRet *= matMult;
	}

	void GeomRenderer::getModelMatrix(const GeomCylinder& cyl, Matrix4& toRet){
		toRet.identity();
		Matrix4 matMult;
		// 3. translation
		cml::matrix_translation(matMult,cyl.getPosition());
		toRet *= matMult;
		// 1. scale
		cml::matrix_scale(matMult,Vector3(cyl.getRadius(),cyl.getRadius(),cyl.getHeight()));
		toRet *= matMult;
	}

	void GeomRenderer::getModelMatrix(const GeomSphere& sphere, Matrix4& toRet){
		toRet.identity();
		Matrix4 matMult;
		// 3. translation
		cml::matrix_translation(matMult,sphere.getPosition());
		toRet *= matMult;
		// 1. scale
		cml::matrix_uniform_scale(matMult,sphere.getRadius());
		toRet *= matMult;
	}

	void GeomRenderer::getModelMatrix(const GeomRay& ray, Matrix4& toRet){
		toRet.identity();
		Matrix4 matMult;
		// 3. translation
		cml::matrix_translation(matMult,ray.getPosition());
		toRet *= matMult;
		// 2. rotation
		Quaternion rotator;
		cml::quaternion_rotation_vec_to_vec(rotator,Vector3(0,0,-1),ray.getDirection());
		cml::matrix_rotation_quaternion(matMult,rotator);
		toRet *= matMult;
		// 1. scale
		cml::matrix_uniform_scale(matMult,500.f);
		toRet *= matMult;
	}

	/************************************************************************/
	/* RENDERERS                                                            */
	/************************************************************************/
	Renderable GeomRenderer::getRenderable(const Geom& g, GeomRenderMode mode){
		// other methods should have been invoked, you need to call the related method yourself then...
		switch(g.getType()){
			case GeomTypePoint:
				break;
			case GeomTypeLine:
				break;
			case GeomTypePlane:
				break;			
			case GeomTypeAABox:
				return ms_Singleton->getRenderable(static_cast<const GeomAxisAlignedBox&>(g),mode);
			case GeomTypeOBox:
				return ms_Singleton->getRenderable(static_cast<const GeomOrientedBox&>(g),mode);
			case GeomTypeSphere:
				return ms_Singleton->getRenderable(static_cast<const GeomSphere&>(g),mode);
			case GeomTypeCyclinder:
				return ms_Singleton->getRenderable(static_cast<const GeomCylinder&>(g),mode);
			case GeomTypePBV:
				break;
			case GeomTypeRay:
				return ms_Singleton->getRenderable(static_cast<const GeomRay&>(g));
			default:
				break;
		}
		assert(0&&"Given Geom type cannot be converted to a renderable");
		// Return a sphere geometry if all fails
		GeomSphere s(Vector3(0,0,0),1);
		return ms_Singleton->getRenderable(s,mode);
	}

	Renderable GeomRenderer::getRenderable(const GeomVolume& gv, GeomRenderMode mode){
		// other methods should have been invoked, you need to call the related method yourself then...
		switch(gv.getType()){
			case GeomTypeAABox:
				return ms_Singleton->getRenderable(static_cast<const GeomAxisAlignedBox&>(gv),mode);
			case GeomTypeOBox:
				return ms_Singleton->getRenderable(static_cast<const GeomOrientedBox&>(gv),mode);
			case GeomTypeSphere:
				return ms_Singleton->getRenderable(static_cast<const GeomSphere&>(gv),mode);
			case GeomTypeCyclinder:
				return ms_Singleton->getRenderable(static_cast<const GeomCylinder&>(gv),mode);
			case GeomTypePBV:
				break;
			// non-volumetric types
			default:
				break;
		}
		// TODO: What to return otherwise??
		assert(0&&"Given Geom type cannot be converted to a renderable");
		// Return a sphere geometry if all fails
		GeomSphere s(Vector3(0,0,0),1);
		return ms_Singleton->getRenderable(s,mode);
	}

	Renderable GeomRenderer::getRenderable(const GeomRay& ray){
		Matrix4* modelMatrix = new Matrix4;
		getModelMatrix(ray,*modelMatrix);
		return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getUnitRay());
	}

	Renderable GeomRenderer::getRenderable(const GeomAxisAlignedBox& aabb, GeomRenderMode mode){
		Matrix4* modelMatrix = new Matrix4;
		getModelMatrix(aabb.getPosition(), aabb.getHalfSize(),*modelMatrix);
		if(mode == GeomRender_Wire){
			return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getUnitAAB(false));
		} else {
			return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getUnitAAB(true));
		}
	}

	Renderable GeomRenderer::getRenderable(const GeomOrientedBox& obb, GeomRenderMode mode){
		Matrix4* modelMatrix = new Matrix4;
		getModelMatrix(obb,*modelMatrix);
		if(mode == GeomRender_Wire){
			return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getUnitAAB(false));
		} else {
			return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getUnitAAB(true));
		}
	}

	Renderable GeomRenderer::getRenderable(const GeomSphere& obb, GeomRenderMode mode){
		Matrix4* modelMatrix = new Matrix4;
		getModelMatrix(obb,*modelMatrix);
		MeshGeom mg(MeshGeomGenerator::getSingleton().getUnitSphere(2));
		mg.mIndexDataPtr->primType = PrimitiveType_Lines;
		return Renderable(modelMatrix,mg);
	}

	Renderable GeomRenderer::getRenderable(const GeomCylinder& obb, GeomRenderMode mode){
		Matrix4* modelMatrix = new Matrix4;
		getModelMatrix(obb,*modelMatrix);
		return Renderable(modelMatrix,MeshGeomGenerator::getSingleton().getCyclinder(3,1,false));
	}
}
