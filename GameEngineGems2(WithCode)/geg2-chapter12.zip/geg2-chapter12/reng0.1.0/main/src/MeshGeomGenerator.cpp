/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#include "REng/MeshGeomGenerator.h"

#include "REng/Geom/GeomOrientedBox.h"
#include "REng/Geom/GeomSphere.h"
#include "REng/Geom/GeomAxisAlignedBox.h"

#include "REng/Node.h"
#include "REng/Angle.h"
#include "REng/Math.h"

#include "REng/MeshManager.h"
#include "REng/Material/MaterialManager.h"

//! Can convert camera planes into a meshgeom object
#include "REng/Camera.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#include <assert.h>

namespace REng{

	template<> MeshGeomGenerator* Singleton<MeshGeomGenerator>::ms_Singleton = 0;
	MeshGeomGenerator* MeshGeomGenerator::getSingletonPtr(void) {
		return ms_Singleton;
	}
	MeshGeomGenerator& MeshGeomGenerator::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	MeshGeomGenerator::MeshGeomGenerator()
		:mNodeTriadArrow(0)
		,mNodeTriadSphere(0)
	{ ;}
	MeshGeomGenerator::~MeshGeomGenerator(){ ; }

	MeshGeom& MeshGeomGenerator::getUnitAAB(bool isSolid){
		if(!isSolid){
			generate_Unit_AAB_Wire();
			return mMesh_Unit_AAB_Wire;
		} else {
			generate_Unit_AAB_Solid();
			return mMesh_Unit_AAB_Solid;
		}
	}
	MeshGeom& MeshGeomGenerator::getUnitPlane(){
		// If the vertex data ptr is set, return the geom mesh
		if(mMesh_Unit_Plane.mVertexDataPtr.get() != 0) return mMesh_Unit_Plane;

		size_t vertexCount = 4;
		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		mMesh_Unit_Plane.mIndexDataPtr.reset(new IndexData());
		mMesh_Unit_Plane.mIndexDataPtr->setBufferPtr(IndexBufferPtr());
		mMesh_Unit_Plane.mIndexDataPtr->primType = PrimitiveType_TriangleStrip;
		mMesh_Unit_Plane.mIndexDataPtr->mRange.set(0,vertexCount);
		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr = VertexDataPtr(new VertexData());
		mMesh_Unit_Plane.mVertexDataPtr = vertDatPtr;
		vertDatPtr->mRange.set(0,vertexCount);
		// attributes
		VertexAttribute posAttrib(0, vertDatPtr->getVertexSize(0), VertexAttribDataType_Byte, VertexAttribDataCount2, VertexAttribSem_Position );
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(posAttrib);
		VertexAttribute norAttrib(0, vertDatPtr->getVertexSize(0), VertexAttribDataType_Byte, VertexAttribDataCount3, VertexAttribSem_Normal );
		norAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(norAttrib);
		VertexAttribute texAttrib(0, vertDatPtr->getVertexSize(0), VertexAttribDataType_Byte, VertexAttribDataCount2, VertexAttribSem_TexCoord0 );
		texAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(texAttrib);
		// vertex buffer setup
		GPUVertexBufferPtr vbuf(
			new GPUVertexBuffer(
				vertDatPtr->getVertexSize(0), vertexCount,
				BufferUsageFreq_Static, BufferUsageNature_Draw, false)
			);
		vertDatPtr->linkBufferToIndex(0,vbuf);
		// fill in vertex data
		char *vd = (char*) malloc(vertexCount*vertDatPtr->getVertexSize(0));
		{
			size_t i=0;
			// 2 component position.    //3 component normal                   // 2 component tex
			vd[i++] = +1; vd[i++] = +1; vd[i++] = 0; vd[i++] = 0; vd[i++] = 1; vd[i++] = 1; vd[i++] = 1;
			vd[i++] = -1; vd[i++] = +1; vd[i++] = 0; vd[i++] = 0; vd[i++] = 1; vd[i++] = 0; vd[i++] = 1;
			vd[i++] = +1; vd[i++] = -1; vd[i++] = 0; vd[i++] = 0; vd[i++] = 1; vd[i++] = 1; vd[i++] = 0;
			vd[i++] = -1; vd[i++] = -1; vd[i++] = 0; vd[i++] = 0; vd[i++] = 1; vd[i++] = 0; vd[i++] = 0;
		}
		vbuf->writeData(vd);

		free(vd);
		return mMesh_Unit_Plane;
	}

	void hiddenHelperNorm(float* buf){
		buf[0]=0; buf[1]=0; buf[2]=1;
	}
	MeshGeom MeshGeomGenerator::getUnitCircle(uchar subdivision, bool filled){
		if(subdivision==0) subdivision = 1; // parameter fix
		ushort vertexCount = subdivision*4;
		if(filled) vertexCount += 2;
		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr( new IndexData() );
		if(filled)
			indDatPtr->primType = PrimitiveType_TriangleFan;
		else
			indDatPtr->primType = PrimitiveType_LineLoop;
		indDatPtr->mRange.set(0,vertexCount);
		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr( new VertexData() );
		vertDatPtr->mRange.set(0,vertexCount);
		// attributes
		VertexAttribute posAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float,VertexAttribDataCount2,VertexAttribSem_Position);
		vertDatPtr->insertAttribute(posAttrib);
			// TODO: the normals can be stored in byte components
		VertexAttribute norAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float,VertexAttribDataCount3,VertexAttribSem_Normal);
		vertDatPtr->insertAttribute(norAttrib);
		GPUVertexBufferPtr vbuf( new GPUVertexBuffer(
			vertDatPtr->getVertexSize(0), vertexCount, BufferUsageFreq_Static, BufferUsageNature_Draw)
		);
		vertDatPtr->linkBufferToIndex(0,vbuf);

		// create and load vertex data to vertex data buffer
		float *vd = (float*) malloc(vertexCount*vertDatPtr->getVertexSize(0));
		ushort pInd = 0;
		if(filled){
			// center point for triangle fan
			vd[pInd++] = 0; vd[pInd++] = 0;
			hiddenHelperNorm(vd+pInd);
			pInd += 3;
		}
		float increment = (Math::PI/2.0) / subdivision;
		ushort quarter=subdivision*5;
		float _angle=0;
		int i=0;
		for(; i<subdivision ; i++ ) {
			float _sin(sin(_angle));
			float _cos(cos(_angle));
			vd[pInd+0+0*quarter] = +_cos; vd[pInd+1+0*quarter] = +_sin;
			hiddenHelperNorm(vd+pInd+2);
			vd[pInd+0+1*quarter] = -_sin; vd[pInd+1+1*quarter] = +_cos;
			hiddenHelperNorm(vd+pInd+2+1*quarter);
			vd[pInd+0+2*quarter] = -_cos; vd[pInd+1+2*quarter] = -_sin;
			hiddenHelperNorm(vd+pInd+2+2*quarter);
			vd[pInd+0+3*quarter] = +_sin; vd[pInd+1+3*quarter] = -_cos;
			hiddenHelperNorm(vd+pInd+2+3*quarter);
			pInd += 5;
			_angle += increment;
		}
		if(filled){
			// add the 0-degree vertex again
			vd[vertexCount*5-5] = 1.0f; vd[vertexCount*5-4] = 0.0f;
			hiddenHelperNorm(vd + vertexCount*5-3);
		} else {

		}
		vbuf->writeData(vd);
		free(vd);

		MeshGeom toRet;
		toRet.mIndexDataPtr = indDatPtr;
		toRet.mVertexDataPtr = vertDatPtr;
		return toRet;
	}

	MeshGeom MeshGeomGenerator::getCone(uchar subdivision){
		if(subdivision==0) subdivision = 1; // fix parameter
		ushort vertexCount = subdivision*4+2;

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr(new IndexData());
		indDatPtr->primType = PrimitiveType_TriangleFan;
		indDatPtr->mRange.set(0,vertexCount);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr(new VertexData());
		VertexAttribute posAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Position);
		vertDatPtr->insertAttribute(posAttrib);
		VertexAttribute norAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Normal);
		vertDatPtr->insertAttribute(norAttrib);
		vertDatPtr->mRange.set(0,vertexCount);
		GPUVertexBufferPtr vertBufPtr( new GPUVertexBuffer(
			vertDatPtr->getVertexSize(0), vertexCount, BufferUsageFreq_Static, BufferUsageNature_Draw ));
		vertDatPtr->linkBufferToIndex(0,vertBufPtr);

		// create and load vertex data to vertex data buffer
		float *vd = (float*) malloc(vertexCount*vertDatPtr->getVertexSize(0));
		ushort pInd = 0;
		// center point for triangle fan
		vd[pInd++] = 0; vd[pInd++] = 1; vd[pInd++] = 0;
		vd[pInd++] = 0; vd[pInd++] = 1; vd[pInd++] = 0;
		float increment = (Math::PI/ 2.0) / subdivision;
		ushort quarter=subdivision*6;
		float _angle=0;
		int i=0;
		for(; i<subdivision ; i++ ) {
			float _sin(sin(_angle));
			float _cos(cos(_angle));
			vd[pInd+0+0*quarter] = +_cos; vd[pInd+1+0*quarter] = 0; vd[pInd+2+0*quarter] = +_sin;
			vd[pInd+3+0*quarter] = +_cos; vd[pInd+4+0*quarter] = 0; vd[pInd+5+0*quarter] = +_sin;
			vd[pInd+0+1*quarter] = +_sin; vd[pInd+1+1*quarter] = 0; vd[pInd+2+1*quarter] = -_cos;
			vd[pInd+3+1*quarter] = +_sin; vd[pInd+4+1*quarter] = 0; vd[pInd+5+1*quarter] = -_cos;
			vd[pInd+0+2*quarter] = -_cos; vd[pInd+1+2*quarter] = 0; vd[pInd+2+2*quarter] = -_sin;
			vd[pInd+3+2*quarter] = -_cos; vd[pInd+4+2*quarter] = 0; vd[pInd+5+2*quarter] = -_sin;
			vd[pInd+0+3*quarter] = -_sin; vd[pInd+1+3*quarter] = 0; vd[pInd+2+3*quarter] = +_cos;
			vd[pInd+3+3*quarter] = -_sin; vd[pInd+4+3*quarter] = 0; vd[pInd+5+3*quarter] = +_cos;
			pInd += 6;
			_angle -= increment;
		}
		size_t lastId = (vertexCount-1)*6;
		vd[lastId+0] = 1; vd[lastId+1] = 0; vd[lastId+2] = 0;
		vd[lastId+3] = 1; vd[lastId+4] = 0; vd[lastId+5] = 0;
		vertBufPtr->writeData(vd);
		free(vd);

		MeshGeom toRet;
		toRet.mIndexDataPtr = indDatPtr;
		toRet.mVertexDataPtr = vertDatPtr;

		GeomOrientedBox *ob=new GeomOrientedBox();
		ob->translate_World(Vector3(0,0.5,0));
		ob->scale(Vector3(2,1,2));
		toRet.setBoundingVolume(ob);
		return toRet;
	}
	
	MeshGeom MeshGeomGenerator::getTorus(float majorRadius, uchar majorSegments, 
		float minorRadius, uchar minorSegments)
	{
		if(minorRadius>majorRadius){
			float tmp = majorRadius;
			majorRadius = minorRadius;
			minorRadius = tmp;
		}
		majorSegments = Math::max(uchar(6),majorSegments);
		minorSegments = Math::max(uchar(6),minorSegments);

		ushort vertexCount = majorSegments*(2*(minorSegments+1));

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr(new IndexData());
		indDatPtr->primType = PrimitiveType_TriangleStrip;
		indDatPtr->mRange.set(0,vertexCount);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr(new VertexData());
		VertexAttribute posAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Position);
		vertDatPtr->insertAttribute(posAttrib);
		VertexAttribute norAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Normal);
		vertDatPtr->insertAttribute(norAttrib);
		VertexAttribute texAttrib(0,vertDatPtr->getVertexSize(0),VertexAttribDataType_Float, VertexAttribDataCount2,VertexAttribSem_TexCoord0);
		vertDatPtr->insertAttribute(texAttrib);
		vertDatPtr->mRange.set(0,vertexCount);
		GPUVertexBufferPtr vertBufPtr( new GPUVertexBuffer(
			vertDatPtr->getVertexSize(0), vertexCount, BufferUsageFreq_Static, BufferUsageNature_Draw ));
		vertDatPtr->linkBufferToIndex(0,vertBufPtr);

		// create and load vertex data to vertex data buffer
		size_t mallocSize = vertexCount*vertDatPtr->getVertexSize(0);
		float *vd = (float*) malloc(mallocSize);
		ushort pInd = 0;
		AngleDegree majSliceAngle(360./majorSegments);
		AngleDegree minSliceAngle(360./minorSegments);
		Vector3 xyz;
		Vector3 xyz_n;
		Vector2 st;
		for(uchar majSlice=0; majSlice<majorSegments; ++majSlice){
			AngleDegree majAngle    (majSliceAngle*majSlice);
			AngleDegree majAngleNext(majAngle+majSliceAngle);
			Vector2 majSliceCenter    (majAngle.sin(),majAngle.cos());
			Vector2 majSliceCenterNext(majAngleNext.sin(),majAngleNext.cos());
			majSliceCenter     *= majorRadius;
			majSliceCenterNext *= majorRadius;
			for(uchar minSlice=0; minSlice<=minorSegments; ++minSlice){
				AngleDegree minAngle(minSliceAngle*minSlice);
				Vector2 minSliceCenter(minAngle.sin(),minAngle.cos());
				minSliceCenter *= minorRadius;
				float m;
				// add two new vertices
				m = 1.-minSliceCenter[1]/majorRadius;
				// pos
				xyz[0] = majSliceCenterNext[0]*m;
				xyz[1] = minSliceCenter[0]; // 0 stores height, no change there
				xyz[2] = majSliceCenterNext[1]*m;
				vd[pInd++] = xyz[0]; vd[pInd++] = xyz[1]; vd[pInd++] = xyz[2];
				// normal
				xyz_n[2] = -minAngle.cos();
				xyz_n[1] = minAngle.sin();
				xyz_n[0] = 0;
				xyz_n = cml::rotate_vector(xyz_n,Vector3(0,1,0),majAngleNext.getRadian());
				vd[pInd++] = xyz_n[0]; vd[pInd++] = xyz_n[1]; vd[pInd++] = xyz_n[2];
				// texcoord
				st[0] = minAngle.getDegree()/360.f;
				st[1] = majAngleNext.getDegree()/360.f;
				vd[pInd++] = st[0]; vd[pInd++] = st[1];
				// pos
				xyz[0] = majSliceCenter[0]*m;
				xyz[2] = majSliceCenter[1]*m;
				vd[pInd++] = xyz[0]; vd[pInd++] = xyz[1]; vd[pInd++] = xyz[2];
				// normal
				xyz_n[2] = -minAngle.cos();
				xyz_n[1] = minAngle.sin();
				xyz_n[0] = 0;
				xyz_n = cml::rotate_vector(xyz_n,Vector3(0,1,0),majAngle.getRadian());
				vd[pInd++] = xyz_n[0]; vd[pInd++] = xyz_n[1]; vd[pInd++] = xyz_n[2];
				// texcoord
				st[0] = minAngle.getDegree()/360.f;
				st[1] = majAngle.getDegree()/360.f;
				vd[pInd++] = st[0]; vd[pInd++] = st[1];
			}
		}

		vertBufPtr->writeData(vd);
		free(vd);

		MeshGeom toRet;
		toRet.mIndexDataPtr = indDatPtr;
		toRet.mVertexDataPtr = vertDatPtr;

		GeomOrientedBox *ob=new GeomOrientedBox(); // size is (1x1x1)
		float scaleFac1 = (majorRadius+minorRadius)*2.;
		float scaleFac2 = minorRadius*2.;
		ob->scale(Vector3(scaleFac1,scaleFac2,scaleFac1));
		toRet.setBoundingVolume(ob);
		return toRet;
	}

	MeshGeom MeshGeomGenerator::getUnitSphere(uchar subdivision) {
		// TODO: Use indexing (each vertex is repeated 5 or 6 times,
		// but recursively defining both index and vertex data is nearly impossible!

		size_t subPow4 = 1; // subPow4 = 4^subdivision; // when subdivision = 0, subPow4 = 1
		for(uchar tmp=subdivision ; tmp!=0 ; tmp--) subPow4 *= 4;

		// CALCULATE FACE COUNT
		size_t faceCount = 20;
		faceCount *= subPow4;

		// CALCULATE VERTEX COUNT (Distinct)
		size_t vertexCount;
		if(subdivision == 0 )
			vertexCount = 12; // original icosahedron
		else
			vertexCount = 12 + 10*(subPow4-1); // finally formulated :)

		// CALCULATE INDEX COUNT
		size_t indexCount;
		indexCount = 12*5 + (vertexCount-12)*6; // 5 face per original vertices, 6 for every other vertex

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr(new IndexData());
		indDatPtr->primType = PrimitiveType_Triangles;
		indDatPtr->mRange.set(0,indexCount);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr(new VertexData());
		// The normals and vertex positions are the same for each vertex!
		VertexAttribute posAttrib(0,0,VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Position);
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		VertexAttribute norAttrib(0,0,VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Normal);
		norAttrib.mBatchMode = REng::VertexAttribBatch_All;
		// Texture coordinate is specified separately
		VertexAttribute texAttrib(0,posAttrib.getSizeInBytes(),VertexAttribDataType_Float, VertexAttribDataCount2,VertexAttribSem_TexCoord0);
		texAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(posAttrib);
		vertDatPtr->insertAttribute(norAttrib);
		vertDatPtr->insertAttribute(texAttrib);
		size_t vertexSize = posAttrib.getSizeInBytes()+texAttrib.getSizeInBytes();
		GPUVertexBufferPtr vertBufPtr( new GPUVertexBuffer(
			vertexSize,indexCount,BufferUsageFreq_Static,BufferUsageNature_Draw) );
		vertDatPtr->mRange.set(0,indexCount);
		vertDatPtr->linkBufferToIndex(0,vertBufPtr);

		float *vertData = (float*) malloc( indexCount*vertexSize );
		assert(vertData);

		// X and Z is chosen so that they their normalized length is 1
		#define X .525731112119133606
		#define Z .850650808352039932
		// basic icosahedron vertex data
		static float icosaVert[36] = {
			-X, 0.0, Z  /*V1*/,  X, 0.0, Z /*V2*/ , -X, 0.0, -Z  /*V3*/ ,  X, 0.0, -Z /*V4*/,
			 0.0, Z, X  /*V5*/, 0.0, Z, -X /*V6*/ ,  0.0, -Z, X  /*V7*/ , 0.0, -Z, -X /*V8*/,
			 Z, X, 0.0  /*V9*/, -Z, X, 0.0 /*V10*/,  Z, -X, 0.0  /*V11*/, -Z, -X, 0.0 /*V12*/
		};
		// basic icosahedron index data (3 vertices for 20 faces)
		static uint icosaInd[60] = {
			0,4,1,   0,9,4,   9,5,4,   4,5,8,   4,8,1,
			8,10,1,  8,3,10,  5,3,8,   5,2,3,   2,7,3,
			7,10,3,  7,6,10,  7,11,6,  11,0,6,  0,1,6,
			6,1,10,  9,0,11,  9,11,2,  9,2,5,   7,2,11
		};

		size_t vdInd = 0;
		for(char i = 0; i<20; i++) {
			subdivide(
				vertData,
				&(icosaVert[icosaInd[i*3+0]*3]),
				&(icosaVert[icosaInd[i*3+1]*3]),
				&(icosaVert[icosaInd[i*3+2]*3]),
				subdivision,vdInd
				);
		}
		// copy the vertex data to hw vertex buffer
		vertBufPtr->writeData(vertData);
		free(vertData);

		MeshGeom toRet;
		toRet.mIndexDataPtr = indDatPtr;
		toRet.mVertexDataPtr = vertDatPtr;

		toRet.setBoundingVolume(new GeomSphere());
		return toRet;
	}


	MeshGeom MeshGeomGenerator::getUnitPoint() {
		MeshGeom toRet = getUnitSphere(0);
		delete toRet.mBoundingVolume;
		toRet.mBoundingVolume = 0;
		return toRet;
	}

	// hidden simple helper
	void normalize(float v[3]) {
		float d = sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
		if (d == 0.0) return;
		v[0] /= d; v[1] /= d; v[2] /= d;
	}
	void MeshGeomGenerator::subdivide(
		float* vertData, // the array holding vertex data
		float* vert1, float* vert2, float* vert3, // the vertices for the triangle to be subdivided
		uchar depth, //if 0, create triangles from ind1, ind2 and ind3
		size_t& vdID // the first free index in vertData
	){
		if(depth==0){
			// ADIL: The original algorithm produces clock-wise triangles, so reverse them!
			// Vertex 1
			vertData[vdID++] = vert1[0]; vertData[vdID++] = vert1[1]; vertData[vdID++] = vert1[2];
			vertData[vdID++] = asin(vert1[0])/Math::PI+ 0.5;// texture U
			vertData[vdID++] = asin(vert1[1])/Math::PI+ 0.5;// texture V
			// Vertex 2
			vertData[vdID++] = vert3[0]; vertData[vdID++] = vert3[1]; vertData[vdID++] = vert3[2];
			vertData[vdID++] = asin(vert3[0])/Math::PI+ 0.5;// texture U
			vertData[vdID++] = asin(vert3[1])/Math::PI+ 0.5;// texture V
			// Vertex 3
			vertData[vdID++] = vert2[0]; vertData[vdID++] = vert2[1]; vertData[vdID++] = vert2[2];
			vertData[vdID++] = asin(vert2[0])/Math::PI+ 0.5;// texture U
			vertData[vdID++] = asin(vert2[1])/Math::PI+ 0.5;// texture V
			return;
		}

		float vert12[3], vert23[3], vert31[3];
		// generate new vertex using vert1 and vert2
		vert12[0] = vert1[0] + vert2[0];
		vert12[1] = vert1[1] + vert2[1];
		vert12[2] = vert1[2] + vert2[2];
		normalize(vert12);
		// generate new vertex using vert2 and vert3
		vert23[0] = vert2[0] + vert3[0];
		vert23[1] = vert2[1] + vert3[1];
		vert23[2] = vert2[2] + vert3[2];
		normalize(vert23);
		// generate new vertex using vert3 and vert1
		vert31[0] = vert3[0] + vert1[0];
		vert31[1] = vert3[1] + vert1[1];
		vert31[2] = vert3[2] + vert1[2];
		normalize(vert31);
		uchar nextDepth(depth-1);
		subdivide(vertData,vert1,vert12,vert31,nextDepth,vdID);
		subdivide(vertData,vert12,vert2,vert23,nextDepth,vdID);
		subdivide(vertData,vert31,vert23,vert3,nextDepth,vdID);
		subdivide(vertData,vert12,vert23,vert31,nextDepth,vdID);
	}

	void MeshGeomGenerator::generate_Unit_AAB_Wire(){
		// If the vertex data ptr is set, return
		if(mMesh_Unit_AAB_Wire.mVertexDataPtr.get() != 0) return;

		genPos_Unit_AAB();

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr = IndexDataPtr(new IndexData());
		size_t indexCount = 16;
		GPUIndexBuffer *indHwBuf = new GPUIndexBuffer(
			IndexDataType_8BIT,
			indexCount,
			BufferUsageFreq_Static,
			BufferUsageNature_Draw
			);
		char *indices = (char*)malloc(indexCount*sizeof(char));
		{
			size_t i=0;
			indices[i++] = 0;	indices[i++] = 1;	indices[i++] = 3;	indices[i++] = 2;
			indices[i++] = 6;	indices[i++] = 4;	indices[i++] = 5;	indices[i++] = 7;
			indices[i++] = 3; indices[i++] = 2; indices[i++] = 0; indices[i++] = 4;
			indices[i++] = 6; indices[i++] = 7; indices[i++] = 5; indices[i++] = 1;
		}
		indHwBuf->writeData(indices);
		indDatPtr->setBufferPtr(IndexBufferPtr(indHwBuf));
		indDatPtr->primType = PrimitiveType_LineStrip; // line-strip primitives
		indDatPtr->mRange.set(0,indexCount);
		mMesh_Unit_AAB_Wire.mIndexDataPtr = indDatPtr;
		free(indices);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr = VertexDataPtr(new VertexData());
		VertexAttribute positionAttrib(0,0,VertexAttribDataType_Byte, VertexAttribDataCount3,VertexAttribSem_Position);
		positionAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(positionAttrib);
		size_t vertexCount = 8;
		vertDatPtr->linkBufferToIndex(0,mPos_Unit_AAB);
		vertDatPtr->mRange.set(0,vertexCount);
		mMesh_Unit_AAB_Wire.mVertexDataPtr = vertDatPtr;

        GeomOrientedBox* ob = new GeomOrientedBox();
        ob->scale(Vector3(2,2,2));
		mMesh_Unit_AAB_Wire.setBoundingVolume(ob);
	}

	void MeshGeomGenerator::generate_Unit_AAB_Solid(){
		// If the vertex data ptr is set, return
		if(mMesh_Unit_AAB_Solid.mVertexDataPtr.get() != 0) return;

		genPos_Unit_AAB();

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr = IndexDataPtr(new IndexData());
		size_t indexCount = 36;
		GPUIndexBuffer *indHwBuf = new GPUIndexBuffer(
			IndexDataType_8BIT,
			indexCount,
			BufferUsageFreq_Static,
			BufferUsageNature_Draw
			);
		char *indices = (char*)malloc(indexCount*sizeof(char));
		{
			memset(indices,0,indexCount);
			size_t i=0;
			indices[i++] = 0;  indices[i++] = 2 ; indices[i++] = 3 ;
			indices[i++] = 0;  indices[i++] = 3 ; indices[i++] = 1 ;
			indices[i++] = 4;  indices[i++] = 5 ; indices[i++] = 7 ;
			indices[i++] = 4;  indices[i++] = 7 ; indices[i++] = 6 ;
			indices[i++] = 13; indices[i++] = 12; indices[i++] = 8 ;
			indices[i++] = 13; indices[i++] = 8 ; indices[i++] = 9 ;
			indices[i++] = 10; indices[i++] = 14; indices[i++] = 15;
			indices[i++] = 10; indices[i++] = 15; indices[i++] = 11;
			indices[i++] = 16; indices[i++] = 20; indices[i++] = 22;
			indices[i++] = 16; indices[i++] = 22; indices[i++] = 18;
			indices[i++] = 23; indices[i++] = 17; indices[i++] = 19;
			indices[i++] = 23; indices[i++] = 21; indices[i++] = 17;
		}
		indHwBuf->writeData(indices);
		indDatPtr->setBufferPtr(IndexBufferPtr(indHwBuf));
		indDatPtr->primType = PrimitiveType_Triangles; // triangle primitives
		indDatPtr->mRange.set(0,indexCount);
		mMesh_Unit_AAB_Solid.mIndexDataPtr = indDatPtr;
		free(indices);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr = VertexDataPtr(new VertexData());

		VertexAttribute posAttrib(0,0,VertexAttribDataType_Byte, VertexAttribDataCount3,VertexAttribSem_Position);
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(posAttrib);
		VertexAttribute texAttrib(0,0,VertexAttribDataType_Byte, VertexAttribDataCount3,VertexAttribSem_TexCoord0);
		texAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(texAttrib);
		VertexAttribute norAttrib(0,posAttrib.getSizeInBytes(),VertexAttribDataType_Byte, VertexAttribDataCount3,VertexAttribSem_Normal);
		norAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(norAttrib);

		size_t vertexCount = 24;
		vertDatPtr->linkBufferToIndex(0,mPos_Unit_AAB);
		vertDatPtr->mRange.set(0,vertexCount);
		mMesh_Unit_AAB_Solid.mVertexDataPtr = vertDatPtr;

        GeomOrientedBox* ob = new GeomOrientedBox();
        ob->scale(Vector3(2,2,2));
		mMesh_Unit_AAB_Solid.setBoundingVolume(ob);
	}

	MeshGeom MeshGeomGenerator::getCyclinder(uchar subdivision, float topRadius, bool lineRender){
		if(subdivision==0) subdivision = 1; // fix parameter
		if(topRadius<0) topRadius = 0;
//		if(topRadius==0){
//			return getCone(subdivision);
//		}

		ushort vertexCount = subdivision*4*2; // 2: we have two circles
		size_t indexCount = vertexCount*3; // each vertex is indexed 3 times

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		IndexDataPtr indDatPtr(new IndexData());
		if(!lineRender)
		indDatPtr->primType = PrimitiveType_Triangles;
		else
			indDatPtr->primType = PrimitiveType_LineStrip;
		indDatPtr->mRange.set(0,indexCount);
		GPUIndexBufferPtr indBufPtr( new GPUIndexBuffer(
			IndexDataType_16BIT, indexCount, BufferUsageFreq_Static, BufferUsageNature_Draw ));
		indDatPtr->setBufferPtr(indBufPtr);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		VertexDataPtr vertDatPtr(new VertexData());
		VertexAttribute posAttrib(0,0,VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Position);
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(posAttrib);
		VertexAttribute norAttrib(0,0,VertexAttribDataType_Float, VertexAttribDataCount3,VertexAttribSem_Normal);
		norAttrib.mBatchMode = REng::VertexAttribBatch_All;
		vertDatPtr->insertAttribute(norAttrib);
		vertDatPtr->mRange.set(0,vertexCount);
		GPUVertexBufferPtr vertBufPtr( new GPUVertexBuffer(
			vertDatPtr->getVertexSize(0), vertexCount, BufferUsageFreq_Static, BufferUsageNature_Draw ));
		vertDatPtr->linkBufferToIndex(0,vertBufPtr);

		// create and load vertex data to vertex data buffer
		float *vd = (float*) malloc(vertexCount*vertDatPtr->getVertexSize(0));
		ushort pInd = 0;
		float increment = (Math::PI/ 2.0) / subdivision;
		ushort quarter=subdivision*6*2;
		float _angle=0;
		int i=0;
		for(; i<subdivision ; i++ ) {
			float _sin(sin(_angle));
			float _cos(cos(_angle));
			float _sinTop = _sin * topRadius;
			float _cosTop = _cos * topRadius;
			// Pos-X                         Pos-Y                     Pos-Z
			// quarter 1
			vd[pInd+0+0*quarter] = +_cos;    vd[pInd+1+0*quarter] = 0; vd[pInd+2+0*quarter] = +_sin;
			hiddenHelperNorm(vd+pInd+3+0*quarter);
			vd[pInd+6+0*quarter] = +_cosTop; vd[pInd+7+0*quarter] = 1; vd[pInd+8+0*quarter] = +_sinTop;
			hiddenHelperNorm(vd+pInd+9+0*quarter);
			// quarter 2
			vd[pInd+0+1*quarter] = -_sin;    vd[pInd+1+1*quarter] = 0; vd[pInd+2+1*quarter] = +_cos;
			hiddenHelperNorm(vd+pInd+3+1*quarter);
			vd[pInd+6+1*quarter] = -_sinTop; vd[pInd+7+1*quarter] = 1; vd[pInd+8+1*quarter] = +_cosTop;
			hiddenHelperNorm(vd+pInd+9+1*quarter);
			// quarter 3
			vd[pInd+0+2*quarter] = -_cos;    vd[pInd+1+2*quarter] = 0; vd[pInd+2+2*quarter] = -_sin;
			hiddenHelperNorm(vd+pInd+3+2*quarter);
			vd[pInd+6+2*quarter] = -_cosTop; vd[pInd+7+2*quarter] = 1; vd[pInd+8+2*quarter] = -_sinTop;
			hiddenHelperNorm(vd+pInd+9+2*quarter);
			// quarter 4
			vd[pInd+0+3*quarter] = +_sin;    vd[pInd+1+3*quarter] = 0; vd[pInd+2+3*quarter] = -_cos;
			hiddenHelperNorm(vd+pInd+3+3*quarter);
			vd[pInd+6+3*quarter] = +_sinTop; vd[pInd+7+3*quarter] = 1; vd[pInd+8+3*quarter] = -_cosTop;
			hiddenHelperNorm(vd+pInd+9+3*quarter);
			pInd += 6*2;
			_angle += increment;
		}
		vertBufPtr->writeData(vd);
		free(vd);

		ushort *id = (ushort*) malloc( indexCount * sizeof(ushort) );
		ushort iInd = 0;
		int k;
		for(k=0 ; k<vertexCount-2 ; k+=2){
			id[iInd++] = k;   id[iInd++] = k+1; id[iInd++] = k+2;
			id[iInd++] = k+2; id[iInd++] = k+1; id[iInd++] = k+3;
		}
		id[iInd++] = k;   id[iInd++] = k+1; id[iInd++] = 0;
		id[iInd++] = 0; id[iInd++] = k+1; id[iInd++] = 1;
		indBufPtr->writeData(id);
		free(id);

		MeshGeom toRet;
		toRet.mIndexDataPtr = indDatPtr;
		toRet.mVertexDataPtr = vertDatPtr;

		GeomOrientedBox *ob=new GeomOrientedBox();
		ob->translate_World(Vector3(0,0.5,0));
		ob->scale(Vector3(2,1,2));
		toRet.setBoundingVolume(ob);
		return toRet;
	}

	MeshGeom MeshGeomGenerator::getUnitRay(){
		MeshGeom mesh_Ray;

		size_t vertexCount = 2;
		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		mesh_Ray.mIndexDataPtr.reset(new IndexData());
		mesh_Ray.mIndexDataPtr->setBufferPtr(IndexBufferPtr());
		mesh_Ray.mIndexDataPtr->primType = PrimitiveType_LineStrip;
		mesh_Ray.mIndexDataPtr->mRange.set(0,vertexCount);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		mesh_Ray.mVertexDataPtr = VertexDataPtr(new VertexData());
		mesh_Ray.mVertexDataPtr->mRange.set(0,vertexCount);
		VertexAttribute posAttrib(0, 0, VertexAttribDataType_Byte, VertexAttribDataCount3, VertexAttribSem_Position );
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		mesh_Ray.mVertexDataPtr->insertAttribute(posAttrib);
		// vertex buffer setup
		GPUVertexBufferPtr vbuf(
			new GPUVertexBuffer(
				mesh_Ray.mVertexDataPtr->getVertexSize(0), vertexCount,
				BufferUsageFreq_Static, BufferUsageNature_Draw, false)
			);
		mesh_Ray.mVertexDataPtr->linkBufferToIndex(0,vbuf);
		// fill in vertex data
		char *vd = (char*) malloc(vertexCount*mesh_Ray.mVertexDataPtr->getVertexSize(0));
		{
			vd[0] = 0; vd[1] = 0;  vd[2] = 0;
			vd[3] = 0; vd[4] = 0;  vd[5] = -1;
		}
		vbuf->writeData(vd);

		free(vd);
		return mesh_Ray;
	}

	void MeshGeomGenerator::genPos_Unit_AAB(){
		if(mPos_Unit_AAB.get() != 0) return;

		// define the position attribute
		VertexAttribute posAttrib(   0,0,VertexAttribDataType_Byte,VertexAttribDataCount3,VertexAttribSem_Position );
		VertexAttribute normalAttrib(0,0,VertexAttribDataType_Byte,VertexAttribDataCount3,VertexAttribSem_Normal   );
		// Note: texture attribute is same as position attribute
		size_t vertexCount = 24;
		mPos_Unit_AAB.reset(
			new GPUVertexBuffer(
				posAttrib.getSizeInBytes()+normalAttrib.getSizeInBytes(),
				vertexCount,
				BufferUsageFreq_Static,
				BufferUsageNature_Draw
				)
			);

		char boxPos[24*6]; // vertexCount*data

		size_t cv = 0;
		// normals are facing right-left
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = +1; //0
		boxPos[cv++] = +1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = -1; //1
		boxPos[cv++] = +1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = +1; //2
		boxPos[cv++] = +1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = -1; //3
		boxPos[cv++] = +1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = +1; //4
		boxPos[cv++] = -1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = -1; //5
		boxPos[cv++] = -1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = +1; //6
		boxPos[cv++] = -1; boxPos[cv++] =  0; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = -1; //7
		boxPos[cv++] = -1; boxPos[cv++] =  0; boxPos[cv++] =  0;

		// repeat above two more times (each vertex has 3 copies with different normal)
		// normals are facing up-down
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = +1; //8
		boxPos[cv++] =  0; boxPos[cv++] = +1; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = -1; //9
		boxPos[cv++] =  0; boxPos[cv++] = +1; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = +1; //10
		boxPos[cv++] =  0; boxPos[cv++] = -1; boxPos[cv++] =  0;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = -1; //11
		boxPos[cv++] =  0; boxPos[cv++] = -1; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = +1; //12
		boxPos[cv++] =  0; boxPos[cv++] = +1; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = -1; //13
		boxPos[cv++] =  0; boxPos[cv++] = +1; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = +1; //14
		boxPos[cv++] =  0; boxPos[cv++] = -1; boxPos[cv++] =  0;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = -1; //15
		boxPos[cv++] =  0; boxPos[cv++] = -1; boxPos[cv++] =  0;

		// normals are facing front-back
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = +1; //16
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = +1;
		boxPos[cv++] = +1; boxPos[cv++] = +1; boxPos[cv++] = -1; //17
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = -1;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = +1; //18
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = +1;
		boxPos[cv++] = +1; boxPos[cv++] = -1; boxPos[cv++] = -1; //19
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = -1;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = +1; //20
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = +1;
		boxPos[cv++] = -1; boxPos[cv++] = +1; boxPos[cv++] = -1; //21
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = -1;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = +1; //22
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = +1;
		boxPos[cv++] = -1; boxPos[cv++] = -1; boxPos[cv++] = -1; //23
		boxPos[cv++] =  0; boxPos[cv++] =  0; boxPos[cv++] = -1;

		mPos_Unit_AAB->writeData(boxPos);
	}

	void _copyTriBuf(const Vector3* cornerList, size_t i1, size_t i2, size_t i3, float* buf){
		buf[0]=cornerList[i1][0]; buf[1]=cornerList[i1][1]; buf[2]=cornerList[i1][2];
		buf[3]=cornerList[i2][0]; buf[4]=cornerList[i2][1]; buf[5]=cornerList[i2][2];
		buf[6]=cornerList[i3][0]; buf[7]=cornerList[i3][1]; buf[8]=cornerList[i3][2];
	}

	MeshGeom MeshGeomGenerator::getFrustum_WS(const REng::Camera& camera){
		REng::Vector3 corners[8];
		camera.getFrustumCorners(corners);


		MeshGeom frustumMG;
		
		size_t faceCount = 6;
		size_t triCount = faceCount*2;
		size_t vertexCount = triCount*3;

		//////////////////////////////////////////////////////////////////////////
		// INDEX DATA
		frustumMG.mIndexDataPtr.reset(new IndexData());
		frustumMG.mIndexDataPtr->setBufferPtr(IndexBufferPtr());
		frustumMG.mIndexDataPtr->primType = PrimitiveType_Triangles;
		frustumMG.mIndexDataPtr->mRange.set(0,vertexCount);

		//////////////////////////////////////////////////////////////////////////
		// VERTEX DATA
		frustumMG.mVertexDataPtr = VertexDataPtr(new VertexData());
		frustumMG.mVertexDataPtr->mRange.set(0,vertexCount);
		VertexAttribute posAttrib(0, 0, VertexAttribDataType_Float, VertexAttribDataCount3, VertexAttribSem_Position);
		posAttrib.mBatchMode = REng::VertexAttribBatch_All;
		frustumMG.mVertexDataPtr->insertAttribute(posAttrib);
		// vertex buffer setup
		SWVertexBufferPtr vbuf(new SWVertexBuffer(frustumMG.mVertexDataPtr->getVertexSize(0), vertexCount));
		frustumMG.mVertexDataPtr->linkBufferToIndex(0,vbuf);
		// fill in vertex data
		float *vd = (float*) vbuf->getBuffer();
		{
			// front
			_copyTriBuf(corners,0,1,2,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,1,3,2,vd); vd+=9; // advance 9 float space
			// left
			_copyTriBuf(corners,1,5,7,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,3,1,7,vd); vd+=9; // advance 9 float space
			// back
			_copyTriBuf(corners,5,4,6,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,7,5,6,vd); vd+=9; // advance 9 float space
			// right
			_copyTriBuf(corners,4,0,6,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,0,2,6,vd); vd+=9; // advance 9 float space
			// top
			_copyTriBuf(corners,1,0,5,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,0,4,5,vd); vd+=9; // advance 9 float space
			// bottom
			_copyTriBuf(corners,3,7,6,vd); vd+=9; // advance 9 float space
			_copyTriBuf(corners,2,3,6,vd); vd+=9; // advance 9 float space
		}
		return frustumMG;
	}


	GroupNode& MeshGeomGenerator::createTriad_Sphere(GroupNode& parent){
		if(!mNodeTriadSphere) initNodeTriadSphere();
		return mNodeTriadSphere->cloneMeshStruct(parent);
	}

	GroupNode& MeshGeomGenerator::createTriad_Arrow(GroupNode& parent){
		if(!mNodeTriadArrow) initNodeTriadArrow();
		return mNodeTriadArrow->cloneMeshStruct(parent);
	}

	void MeshGeomGenerator::initNodeTriadSphere(){
		mNodeTriadSphere = &(GroupNode::create(RootNode::getSingleton()));
//		mNodeTriadSphere->translate_World(Vector3(0,60,0));
//		mNodeTriadSphere->scale_Parent(0.03f);
		mNodeTriadSphere->mCullingMode = SceneNode::CULL_ALWAYS;

		MeshNode* mTriadNode_Circle_R = &(MeshNode::create(*mNodeTriadSphere));
		MeshNode* mTriadNode_Circle_G = &(MeshNode::create(*mNodeTriadSphere));
		MeshNode* mTriadNode_Circle_B = &(MeshNode::create(*mNodeTriadSphere));

		// spatial relation between nodes
		Quaternion y2x;
		Quaternion y2z;
		Quaternion y2y;
		cml::quaternion_rotation_world_y(y2x,Angle::degree2radian(-90));
		cml::quaternion_rotation_world_x(y2z,Angle::degree2radian(+90));
		y2y.identity();
		mTriadNode_Circle_R->rotate_Parent(y2x);
		mTriadNode_Circle_G->rotate_Parent(y2y);
		mTriadNode_Circle_B->rotate_Parent(y2z);

		// prepare geometries
		MeshGeom circleGeom = getUnitCircle(5,false);

		// create meshes
		MeshPtr crcMesh_R = MeshManager::getSingleton().createMesh("re/mgg/triad_crc_r");
		MeshPtr crcMesh_G = MeshManager::getSingleton().createMesh("re/mgg/triad_crc_g");
		MeshPtr crcMesh_B = MeshManager::getSingleton().createMesh("re/mgg/triad_crc_b");

		// set mesh material and geometries
		crcMesh_R->mMaterial = MaterialManager::getSingleton().getMaterial("re_Red");
		crcMesh_G->mMaterial = MaterialManager::getSingleton().getMaterial("re_Green");
		crcMesh_B->mMaterial = MaterialManager::getSingleton().getMaterial("re_Blue");
		crcMesh_R->createLoDGeom(circleGeom);
		crcMesh_G->createLoDGeom(circleGeom);
		crcMesh_B->createLoDGeom(circleGeom);

		// assign meshes to mesh nodes
		mTriadNode_Circle_R->setMesh(crcMesh_R);
		mTriadNode_Circle_G->setMesh(crcMesh_G);
		mTriadNode_Circle_B->setMesh(crcMesh_B);
	}

	void MeshGeomGenerator::initNodeTriadArrow(){
		mNodeTriadArrow = &(GroupNode::create(RootNode::getSingleton()));
//		mNodeTriadArrow->translate_World(Vector3(0,60,0));
//		mNodeTriadArrow->scale_Parent(0.03f);
		mNodeTriadArrow->mCullingMode = SceneNode::CULL_ALWAYS;

		MeshNode* mTriadNode_Cylinder_R = &(MeshNode::create(*mNodeTriadArrow));
		MeshNode* mTriadNode_Cylinder_G = &(MeshNode::create(*mNodeTriadArrow));
		MeshNode* mTriadNode_Cylinder_B = &(MeshNode::create(*mNodeTriadArrow));
		MeshNode* mTriadNode_Cone_R     = &(MeshNode::create(*mNodeTriadArrow));
		MeshNode* mTriadNode_Cone_G     = &(MeshNode::create(*mNodeTriadArrow));
		MeshNode* mTriadNode_Cone_B     = &(MeshNode::create(*mNodeTriadArrow));

		// spatial relation between nodes
		Quaternion y2x;
		Quaternion y2z;
		Quaternion y2y;
		cml::quaternion_rotation_world_z(y2x,Angle::degree2radian(-90));
		cml::quaternion_rotation_world_x(y2z,Angle::degree2radian(+90));
		y2y.identity();
		mTriadNode_Cone_R->rotate_Parent(y2x);
		mTriadNode_Cone_R->translate_Local(Vector3(0.0f,1.0f,0.0f));
		mTriadNode_Cone_R->scale_Parent(Vector3(0.25,0.5,0.25));
		mTriadNode_Cone_G->rotate_Parent(y2y);
		mTriadNode_Cone_G->translate_Local(Vector3(0.0f,1.0f,0.0f));
		mTriadNode_Cone_G->scale_Parent(Vector3(0.25,0.5,0.25));
		mTriadNode_Cone_B->rotate_Parent(y2z);
		mTriadNode_Cone_B->translate_Local(Vector3(0.0f,1.0f,0.0f));
		mTriadNode_Cone_B->scale_Parent(Vector3(0.25,0.5,0.25));
		mTriadNode_Cylinder_R->rotate_Parent(y2x);
		mTriadNode_Cylinder_R->scale_Parent(Vector3(0.1,1,0.1));
		mTriadNode_Cylinder_G->rotate_Parent(y2y);
		mTriadNode_Cylinder_G->scale_Parent(Vector3(0.1,1,0.1));
		mTriadNode_Cylinder_B->rotate_Parent(y2z);
		mTriadNode_Cylinder_B->scale_Parent(Vector3(0.1,1,0.1));

		// prepare geometries
		MeshGeom cyclinderGeom = getCyclinder(3,1); // 0.25 radius, along y
		MeshGeom coneGeom      = getCone(3); // 1 radius, along y

		// prepare materials
		MaterialPtr material_R = MaterialManager::getSingleton().getMaterial("re_Red");
		MaterialPtr material_G = MaterialManager::getSingleton().getMaterial("re_Green");
		MaterialPtr material_B = MaterialManager::getSingleton().getMaterial("re_Blue");

		// create meshes
		MeshPtr cylMesh_R = MeshManager::getSingleton().createMesh("cylMesh_R");
		MeshPtr cylMesh_G = MeshManager::getSingleton().createMesh("cylMesh_G");
		MeshPtr cylMesh_B = MeshManager::getSingleton().createMesh("cylMesh_B");
		MeshPtr coneMesh_R = MeshManager::getSingleton().createMesh("coneMesh_R");
		MeshPtr coneMesh_G = MeshManager::getSingleton().createMesh("coneMesh_G");
		MeshPtr coneMesh_B = MeshManager::getSingleton().createMesh("coneMesh_B");

		// set mesh material and geometries
		cylMesh_R->mMaterial = material_R;
		cylMesh_G->mMaterial = material_G;
		cylMesh_B->mMaterial = material_B;
		cylMesh_R->createLoDGeom(cyclinderGeom);
		cylMesh_G->createLoDGeom(cyclinderGeom);
		cylMesh_B->createLoDGeom(cyclinderGeom);

		coneMesh_R->mMaterial = material_R;
		coneMesh_G->mMaterial = material_G;
		coneMesh_B->mMaterial = material_B;
		coneMesh_R->createLoDGeom(coneGeom);
		coneMesh_G->createLoDGeom(coneGeom);
		coneMesh_B->createLoDGeom(coneGeom);

		// assign meshes to mesh nodes
		mTriadNode_Cylinder_R->setMesh(cylMesh_R);
		mTriadNode_Cylinder_G->setMesh(cylMesh_G);
		mTriadNode_Cylinder_B->setMesh(cylMesh_B);
		mTriadNode_Cone_R    ->setMesh(coneMesh_R);
		mTriadNode_Cone_G    ->setMesh(coneMesh_G);
		mTriadNode_Cone_B    ->setMesh(coneMesh_B);
	}

} // namespace REng
