/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/Mesh.h"

// accessing loaded materials
#include "REng/Material/MaterialManager.h"

using namespace boost;
using namespace std;

namespace REng{
	
	/************************************************************************/
	/* Mesh LoD Geom                                                        */
	/************************************************************************/

	MeshGeom::MeshGeom() 
		: mBoundingVolume(0)
	{ ; }
	MeshGeom::~MeshGeom(){
		; // ahanda
	}

	size_t MeshGeom::getVertexCount() const{
		if(mIndexDataPtr.get() == 0)
			return mVertexDataPtr->mRange.getSize();
		return mIndexDataPtr->mRange.getSize();
	}
	const GeomVolume* MeshGeom::getBoundingVolume() const{
		return mBoundingVolume;
	}
	void MeshGeom::setBoundingVolume(GeomVolume* volume){
		if(volume==0 && mBoundingVolume != 0) delete mBoundingVolume;
		mBoundingVolume = volume;
	}

	/************************************************************************/
	/* Mesh                                                                 */
	/************************************************************************/

	Mesh::Mesh(const std::string& name) : mName(name){ 
		mMaterial.reset();
//		createLoDGeom(0,0);
	}
	Mesh::~Mesh(){ ; }

	const std::string& Mesh::getName() const{
		return mName;
	}
	VertexDataPtr Mesh::createVertexData(){
		return VertexDataPtr(new VertexData());
	}
	IndexDataPtr Mesh::createIndexData(){
		return IndexDataPtr(new IndexData());
	}

	MeshGeom* Mesh::createLoDGeom(uchar viewIndex, uchar distanceIndex){
		MeshGeom* toRet = createLoDedData(viewIndex, distanceIndex);
		if(toRet==0) return 0;
		toRet->mIndexDataPtr.reset( new IndexData() );
		toRet->mVertexDataPtr.reset(new VertexData());
		return toRet;
	}
	MeshGeom* Mesh::createLoDGeom(VertexDataPtr vertexData, uchar viewIndex, uchar distanceIndex){
		MeshGeom* toRet = createLoDedData(viewIndex, distanceIndex);
		if(toRet==0) return 0;
		toRet->mVertexDataPtr = vertexData;
		toRet->mIndexDataPtr.reset( new IndexData() );
		return toRet;
	}
	MeshGeom* Mesh::createLoDGeom(MeshGeom meshGeom, uchar viewIndex, uchar distanceIndex){
		MeshGeom* toRet = createLoDedData(viewIndex, distanceIndex);
		if(toRet==0) return 0;
		toRet->mVertexDataPtr = meshGeom.mVertexDataPtr;
		toRet->mIndexDataPtr = meshGeom.mIndexDataPtr;
		toRet->setBoundingVolume(meshGeom.mBoundingVolume);
		return toRet;
	}

}

