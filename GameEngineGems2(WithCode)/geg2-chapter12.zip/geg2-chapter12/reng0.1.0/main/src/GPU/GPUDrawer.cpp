/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUDrawer.h"

// accesses GPUProgram information
#include "REng/GPU/GPUProgram.h"

// updates the StatsCounter
#include "REng/StatsCounter.h"

// render system has its own logger
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng {

	// SINGLETON
	template<> GPUDrawer* Singleton<GPUDrawer>::ms_Singleton = 0;
	GPUDrawer* GPUDrawer::getSingletonPtr(void) {
		return ms_Singleton;
	}
	GPUDrawer& GPUDrawer::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	GPUDrawer::GPUDrawer(){
		mAttribBatchMode = false;
		mBatchAttribsBound.clear();
		setAttribBatchOff();
		setMultiDrawBatchOff();
	}

	// Batching Modes

	void GPUDrawer::setAttribBatchOn(){
		mAttribBatchMode = true;
		mBatchInitialized = false;
	}
	void GPUDrawer::setAttribBatchOff(){
		mAttribBatchMode = false;
		unbindBatchAttribs();
	}

	void GPUDrawer::setMultiDrawBatchOn(){
		mMultiDrawBatchMode = true;
		mBatchInitialized = false;
	}
	void GPUDrawer::setMultiDrawBatchOff(){
		mMultiDrawBatchMode = false;
		// TODO
		if(true/*using index buffers*/){
//			glMultiDrawArrays{};
		} else {
//			glMultiDrawElements{};
		}
		unbindBatchAttribs();
	}

	void GPUDrawer::drawMeshGeom(const MeshGeom& index_vertex_data){
		const IndexData& indexData(*(index_vertex_data.mIndexDataPtr));
		const VertexData& vertexData(*(index_vertex_data.mVertexDataPtr));
		void* pBufferData;
		static Logger logger = Logger::getInstance("RSys");
		
		IndexBuffer* indexBufPtr(indexData.getBufferPtr().get());

		// ***********************************
		// validate render data (in debug mode only, release mode should be fast.)
		// ***********************************
		#ifdef RENG_DEBUG_BUILD
			// OpenGL ES 2.0 does not support 32 bit index data, check it!
			if(indexBufPtr != 0) {
				if(isSupported(indexBufPtr->getIndexType())==false){
					LOG4CPLUS_WARN(logger,"GPUDrawer | The render data is not supported: Unsupported index data type.");
					return;
				}
			}
			// a shader must be active
			if(GPUProgram::getActiveProgram()==0) return;
		#endif

		// ***********************************
		// update statistics
		// ***********************************
		size_t vertexCount(indexData.mRange.getSize());
		{
			// account for a pass having multiple iterations
			// if (mCurrentPassIterationCount > 1) vertexCount *= mCurrentPassIterationCount;
			StatsCounter::getSingleton().addVertexCount(vertexCount);

			switch(indexData.primType) {
			case PrimitiveType_Triangles:
				StatsCounter::getSingleton().addFaceCount(vertexCount/3);
				break;
			case PrimitiveType_TriangleStrip:
			case PrimitiveType_TriangleFan:
				StatsCounter::getSingleton().addFaceCount(vertexCount-2);
				break;
			case PrimitiveType_Points:
			case PrimitiveType_Lines:
			case PrimitiveType_LineStrip:
			case PrimitiveType_LineLoop:
				break; // no face
			}
		}

		// **********************************************************************
		// set vertex attributes sources (batching can be applied here)
		// **********************************************************************

		const REng::VertexAttributeList& decl = vertexData.getAttributeElementsAll();
		VertexAttributeList::const_iterator elem = decl.begin(), elemEnd = decl.end();
		std::vector<GLuint> localAttribsBound; // empty

		for( ; elem != elemEnd ; ++elem) {
			// ESCAPE: Multi-draw batching is active
			if(mBatchInitialized && mMultiDrawBatchMode) {
				continue;
			}

			// ESCAPE - Attrib Batch Mode - All
			if(mAttribBatchMode && mBatchInitialized && elem->mBatchMode == VertexAttribBatch_All) {
				continue;
			}

			GLuint genericIndex;
			// **** check inconsistencies
			{
				if(!vertexData.isBufferIndexed(elem->getSourceBufferIndex())){
					LOG4CPLUS_WARN(logger, "GPUDrawe | Render data inconsistency : "
					                       "An indexed buffer is not set, skipping an attribute.");
					continue;
				}
				if(elem->getSemantic()!= VertexAttribSem_None){
					if(GPUProgram::getActiveProgram()->
						getGenericIndex(elem->getSemantic(), genericIndex) == false) {
						continue;
					}
				} else {
					if(GPUProgram::getActiveProgram()->
						getGenericIndex(elem->getName().c_str(), genericIndex) == false) {
						continue;
					}
				}
			}
			
			// **** bind/unbind buffer for this attribute
			VertexBufferPtr vertexBuffer(vertexData.getBuffer(elem->getSourceBufferIndex()));
			{
				if(vertexBuffer->getType() == BufferType_GPU){
					((GPUVertexBuffer*)(vertexBuffer.get()))->bindResource();
				} else {
					GPUVertexBuffer::unbind();
				}
			}
			
			// **** set buffer pointer
			{
				pBufferData = BUFFER_OFFSET(elem->getStartOffset());
				if(vertexBuffer->getType() != BufferType_GPU){
					pBufferData = static_cast<char*>(pBufferData) + (size_t)((SWVertexBuffer*)(vertexBuffer.get()))->getBuffer();
				}
				if(vertexData.mRange.getStart()){
					pBufferData = static_cast<char*>(pBufferData) + vertexData.mRange.getStart() * vertexBuffer->getVertexSize();
				}
			}

			// **** set vertex attribute pointer
			glVertexAttribPointer(
				genericIndex,
				elem->getDataCount(),
				elem->getDataType(),
				elem->mNormalize,
				static_cast<GLsizei>(vertexBuffer->getVertexSize()), 
				pBufferData);

			// ESCAPE - BATCH MODE ACTIVE
			if(mAttribBatchMode && mBatchInitialized && elem->mBatchMode == VertexAttribBatch_Active) {
				continue;
			}

			// **** activate vertex attribute
			glEnableVertexAttribArray(genericIndex);
			if(mAttribBatchMode && !mBatchInitialized && elem->mBatchMode != VertexAttribBatch_None) {
				mBatchAttribsBound.push_back(genericIndex);
			} else if(mMultiDrawBatchMode) {
				// multi-draw batch mode stores the activated attributes
				mBatchAttribsBound.push_back(genericIndex);
			} else {
				localAttribsBound.push_back(genericIndex);
			}
		}

		if(mMultiDrawBatchMode){ //TODO
			if(!mBatchInitialized){
				// bind/unbind vertex buffer
				// store pBufferData
			} else {
				//skip
			}
		}

		// *************************************
		// send draw call ( using index data )
		// *************************************
		if(indexBufPtr != 0){
			pBufferData = BUFFER_OFFSET( indexData.mRange.getStart() * indexBufPtr->getIndexSize());
			if(indexBufPtr->getType() == BufferType_GPU){
				((GPUIndexBuffer*)(indexBufPtr))->bindResource();
			} else {
				GPUIndexBuffer::unbind();
				pBufferData = static_cast<char*>(pBufferData) + (size_t)((SWIndexBuffer*)(indexBufPtr))->getBuffer();
			}
			glDrawElements(
				indexData.primType, 
				(GLsizei)(indexData.mRange.getSize()), 
				indexBufPtr->getIndexType(),
				pBufferData
				);
		} else {
			glDrawArrays(
				indexData.primType, 
				(GLint)indexData.mRange.getStart(),
				(GLsizei)indexData.mRange.getSize()
				);	
		}
		StatsCounter::getSingleton().incDrawCall();

		// *************************************
		// unbind locally activated vertex attributes
		// *************************************
		{
			for (std::vector<GLuint>::iterator ai = localAttribsBound.begin(); ai != localAttribsBound.end(); ++ai) {
				glDisableVertexAttribArray(*ai);
			}
		}
		mBatchInitialized=true;
	}

	void GPUDrawer::unbindBatchAttribs(){
		for (std::vector<GLuint>::iterator ai = mBatchAttribsBound.begin(); ai != mBatchAttribsBound.end(); ++ai) {
			glDisableVertexAttribArray(*ai);
		}
		mBatchAttribsBound.clear();
	}

} // namespace REng 
