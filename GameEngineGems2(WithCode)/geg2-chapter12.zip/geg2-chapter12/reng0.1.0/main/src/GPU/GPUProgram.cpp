/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUProgram.h"

// some operations depend on GPU configuration
#include "REng/GPU/GPUConfig.h"

// need to reset linked uniforms if no program is bound
#include "REng/RenderMatrixManager.h"

// logging
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng
{
	const GPUProgram* GPUProgram::mActiveProgram = 0;

	GPUProgram::GPUProgram() 
		: mIsLinked(false), 
		mActiveUniformCount(0), 
		mActiveUniformMaxLength(0)
	{
		createResource();
	}
	GPUProgram::~GPUProgram() {
		destroyResource();
	}
	GPUProgram::GPUProgram(GPUProgram&){}

	GPUProgram& GPUProgram::operator=(GPUProgram&){ return *this;}

	void GPUProgram::createResource(){
		if(mResourceID!=0) return;
		mResourceID = glCreateProgram();
		assert(mResourceID!=0);
	}
	void GPUProgram::destroyResource(){
		if(mResourceID!=0) glDeleteProgram(mResourceID);
	}
	size_t GPUProgram::getActiveUniformCount() const{
		return mActiveUniformCount;
	}
	size_t GPUProgram::getActiveUniformMaxLength() const{
		return mActiveUniformMaxLength;
	}
	void GPUProgram::bindResource() const {
		assert(isLinked());
		if(this == mActiveProgram) return;
		glUseProgram(mResourceID);
		mActiveProgram = this;
		RenderMatrixManager::getSingleton().resetUniformLinks();
	}
	void GPUProgram::unbindResource() {
		if(mActiveProgram==0) return;
		glUseProgram(0);
		mActiveProgram=0;
		RenderMatrixManager::getSingleton().resetUniformLinks();
	}
	const GPUProgram* GPUProgram::getActiveProgram(){
		return mActiveProgram;
	}
	bool GPUProgram::detachShader(const GPUShader& shader) {
		// check if given shader is attached ... TODO
		glDetachShader(mResourceID,shader.mResourceID);
		// TODO: remove shader object from this programs attached shader list.
		mIsLinked = false;
		return true;
	}
	bool GPUProgram::attachShader(const GPUShader& shader) {
		ShaderType type(shader.getType());
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(type==ShaderType_Fragment && mAttachedFragmentShaders.size()!= 0) return false;
		if(type==ShaderType_Vertex   && mAttachedVertexShaders.size()  != 0) return false;
		if(type==ShaderType_Geometry) return false;
		#endif
		glAttachShader(mResourceID,shader.mResourceID);
		// check gl error (re-binding of a previously bound shader)
		if(type == ShaderType_Fragment) 
			mAttachedFragmentShaders.push_back(&shader);
		if(type == ShaderType_Vertex)
			mAttachedVertexShaders.push_back(&shader);
		if(type == ShaderType_Geometry)
			mAttachedGeometryShaders.push_back(&shader);
		mIsLinked = false;
		return true;
	}
	bool GPUProgram::link() {
		if(mIsLinked) return true;
		glLinkProgram(mResourceID);
		int infoLogLength = 0;
		glGetProgramiv(mResourceID,GL_INFO_LOG_LENGTH,&infoLogLength);
		char* infoLog = 0;
		if(infoLogLength > 0) {
			int actualLogLength = 0;
			infoLog = new char[infoLogLength];
			glGetProgramInfoLog(mResourceID,infoLogLength,&actualLogLength,infoLog);
			// trim any new line at the end of the info log received
			if(infoLog[infoLogLength-1]=='\n') infoLog[infoLogLength-1] = 0;
			infoLogLength = actualLogLength;
		}
		GLint linkStatus = 0;
		glGetProgramiv(mResourceID,GL_LINK_STATUS,&linkStatus);
		mIsLinked = (linkStatus==GL_TRUE);
		if(mIsLinked){
			updateActiveAttributeList();
			glGetProgramiv(mResourceID,GL_ACTIVE_UNIFORMS, &mActiveUniformCount);
			glGetProgramiv(mResourceID,GL_ACTIVE_UNIFORM_MAX_LENGTH, &mActiveUniformMaxLength);
#if OPENGL_DRIVER_CHECK
			for(int i=0; i<mActiveUniformCount; i++){
				size_t length;
				int size;
				GLenum type;
				char name[128];
				getActiveUniform(i,&length, &size, &type, name);
			}
#endif
		}
		if(infoLogLength>0) {
			LOG4CPLUS_INFO(Logger::getInstance("mtrl"),"GPUProgram | OpenGL program linkage log:\n"<<infoLog);
		}
		delete [] infoLog;
		return mIsLinked;
	}
	bool GPUProgram::isLinked() const{
		return mIsLinked;
	}
	bool GPUProgram::validate() {
		// validate program
		glValidateProgram(mResourceID);
		// update program information log
		int infoLogLength = 0;
		glGetProgramiv(mResourceID,GL_INFO_LOG_LENGTH,&infoLogLength);
		char* infoLog = 0;
		if(infoLogLength > 0) {
			int actualLogLength = 0;
			infoLog = new char[infoLogLength];
			glGetProgramInfoLog(mResourceID,infoLogLength,&actualLogLength,infoLog);
			// trim any new line at the end of the info log received
			if(infoLog[infoLogLength-1]=='\n') infoLog[infoLogLength-1] = 0;
			infoLogLength = actualLogLength;
		}
		GLint validateStatus = 0;
		glGetProgramiv(mResourceID, GL_VALIDATE_STATUS, &validateStatus);
		if(infoLogLength>0) {
			LOG4CPLUS_INFO(Logger::getInstance("mtrl"),"GPUProgram | OpenGL program validation log:\n"<<infoLog);
		}
		delete [] infoLog;
		return (validateStatus==GL_TRUE);
	}

	void GPUProgram::updateActiveAttributeList(){
		GLint activeAttributes;
		GLint bufSize; 
		glGetProgramiv(mResourceID,GL_ACTIVE_ATTRIBUTES, &activeAttributes);
		glGetProgramiv(mResourceID,GL_ACTIVE_ATTRIBUTE_MAX_LENGTH, &bufSize);
		char* attribName = (char*) malloc(sizeof(char)*bufSize);
		for(GLint attribIndex =0 ; attribIndex<activeAttributes ; attribIndex++){
			GLenum attribType;
			GLint attribSize;
			GLsizei attribLength;
			glGetActiveAttrib(mResourceID,attribIndex,bufSize,&attribLength,&attribSize,&attribType,attribName);
			SShaderAttrib attrib;
			attrib.size = attribSize;
			attrib.type = attribType;
			attrib.name = (char*) malloc((attribLength+1)*sizeof(char));
			memcpy(attrib.name,attribName,attribLength+1);
			attrib.location = glGetAttribLocation(mResourceID,attrib.name);
			attrib.semantic = VertexAttribSem_None;
			if(false) ;
			else if(strcmp(attrib.name,"re_Position")==0)  attrib.semantic = VertexAttribSem_Position;
			else if(strcmp(attrib.name,"re_Normal")==0)    attrib.semantic = VertexAttribSem_Normal;
			else if(strcmp(attrib.name,"re_Tangent")==0)   attrib.semantic = VertexAttribSem_Tangent;
			else if(strcmp(attrib.name,"re_Bitangent")==0) attrib.semantic = VertexAttribSem_Bitangent;
			else if(strcmp(attrib.name,"re_PSize")==0)     attrib.semantic = VertexAttribSem_PSize;
			else if(strcmp(attrib.name,"re_ColorDiffuse")==0)  attrib.semantic = VertexAttribSem_ColorDiffuse;
			else if(strcmp(attrib.name,"re_ColorSpecular")==0) attrib.semantic = VertexAttribSem_ColorSpecular;
			else if(strcmp(attrib.name,"re_TexCoord0")==0) attrib.semantic = VertexAttribSem_TexCoord0;
			else if(strcmp(attrib.name,"re_TexCoord1")==0) attrib.semantic = VertexAttribSem_TexCoord1;
			else if(strcmp(attrib.name,"re_TexCoord2")==0) attrib.semantic = VertexAttribSem_TexCoord2;
			else if(strcmp(attrib.name,"re_TexCoord3")==0) attrib.semantic = VertexAttribSem_TexCoord3;
			else if(strcmp(attrib.name,"re_TexCoord4")==0) attrib.semantic = VertexAttribSem_TexCoord4;
			else if(strcmp(attrib.name,"re_TexCoord5")==0) attrib.semantic = VertexAttribSem_TexCoord5;
			else if(strcmp(attrib.name,"re_TexCoord6")==0) attrib.semantic = VertexAttribSem_TexCoord6;
			else if(strcmp(attrib.name,"re_TexCoord7")==0) attrib.semantic = VertexAttribSem_TexCoord7;
			mActiveAttributeList.push_back(attrib);
		}
		free(attribName);
	}

	bool GPUProgram::getGenericIndex(const char* name, GLuint& index) const{
		if(name == 0) return false;
		size_t loop = mActiveAttributeList.size();
		for(size_t i=0; i<loop ; i++){
			if(mActiveAttributeList[i].semantic != VertexAttribSem_None) continue;
			if( strcmp(mActiveAttributeList[i].name,name) == 0){
				index = mActiveAttributeList[i].location;
				return true;
			}
		}
		return false;
	}
	bool GPUProgram::getGenericIndex(VertexAttribSemantic sem, GLuint& index) const{
		if(sem == VertexAttribSem_None) return false;
		size_t loop = mActiveAttributeList.size();
		for(size_t i=0; i<loop ; i++){
			if( mActiveAttributeList[i].semantic == sem){
				index = mActiveAttributeList[i].location;
				return true;
			}
		}
		return false;
	}


	void GPUProgram::getActiveUniform(size_t index, size_t* length, int* size, GLenum* type, char* name){
		if(mResourceID == 0) return;
		glGetActiveUniform(
			mResourceID,
			(GLuint)index,
			(GLsizei)mActiveUniformMaxLength,
			(GLsizei*)length,
			(GLint*)size, 
			type, name);
#if OPENGL_DRIVER_CHECK
		Logger logger = Logger::getInstance("mtrl");
		LOG4CPLUS_INFO(logger," GPUProgram getActiveUniform index :" << index);
		LOG4CPLUS_INFO(logger," GPUProgram getActiveUniform length:" << (*length) << " size:" << (*size) << " name:" << name);
		LOG4CPLUS_INFO(logger," GPUProgram mActiveUniformCount: " << mActiveUniformCount);
#endif
		CHECKGLERROR_TERM();
	};
		
	void GPUProgram::bindAttribLocation(uint attribIndex, const char* attribName){
		glBindAttribLocation(mResourceID,attribIndex,attribName);
	}

	int GPUProgram::getFragDataLocation(const char* outName){
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		if(!isLinked()) return -1;
		// Note: No opengl error will be produces, because we check link status eariler.
		return glGetFragDataLocation(mResourceID,outName);
#else
		return -1;
#endif
	}

	bool GPUProgram::bindFragDataLocation(uint colorIndex, const char* outName){
#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		if(colorIndex >= (uint)GPUConfig::getSingleton().getGLMaxDrawBuffers()) return false;
		glBindFragDataLocation(mResourceID,colorIndex,outName);
		return true;
#else
		return false;
#endif
	}

}
