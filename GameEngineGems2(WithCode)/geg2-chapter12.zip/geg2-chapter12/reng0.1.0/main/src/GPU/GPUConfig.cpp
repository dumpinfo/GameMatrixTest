/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUConfig.h"

#include "REng/Defines.h"

#include <cstring>

// GPUConfig can produce logs
#include <log4cplus/logger.h>
using namespace log4cplus;

// Logs OpenGL Context Profile, if GL version>=3.2
#include "REng/sys/GLContext.h"

namespace REng {
	
	GPUConfig::GPUConfig() { 
		mExtentionCount = 0;
		mExtentionInfoList = 0;
	}
	GPUConfig::~GPUConfig() { 
		; 
	}
	
	template<> GPUConfig* Singleton<GPUConfig>::ms_Singleton = 0;
	GPUConfig* GPUConfig::getSingletonPtr(void) {
		return ms_Singleton;
	}
	GPUConfig& GPUConfig::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}




	void GPUConfig::update(){
//		Logger logger = Logger::getInstance("RSys");
//		LOG4CPLUS_INFO(logger,"Reading OpenGL Information...");
		const char* glString;
		glString = (const char*) glGetString(GL_VERSION);	
		mGLVersion = (char*)malloc(strlen(glString)+1); strcpy((char*)mGLVersion,glString);
		glString = (const char*) glGetString(GL_SHADING_LANGUAGE_VERSION);	
		mGLSLVersion = (char*)malloc(strlen(glString)+1); strcpy((char*)mGLSLVersion,glString);
		glString = (const char*) glGetString(GL_RENDERER);	
		mRendererName = (char*)malloc(strlen(glString)+1); strcpy((char*)mRendererName,glString);
		glString = (const char*) glGetString(GL_VENDOR);
		mVendorName = (char*)malloc(strlen(glString)+1); strcpy((char*)mVendorName,glString);

		// convert version string to numeric info
#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		sscanf(mGLVersion, "OpenGL ES %d.%d", &mGLVersionMajor, &mGLVersionMinor);
		sscanf(mGLSLVersion, "OpenGL ES GLSL ES %d.%d", &mGLSLVersionMajor, &mGLSLVersionMinor);
#else
		sscanf(mGLVersion, "%d.%d", &mGLVersionMajor, &mGLVersionMinor);
		sscanf(mGLSLVersion, "%d.%d", &mGLSLVersionMajor, &mGLSLVersionMinor);
#endif

		glGetFloatv(GL_ALIASED_LINE_WIDTH_RANGE, mGLAliasedLineWidthRange);
		glGetFloatv(GL_ALIASED_POINT_SIZE_RANGE, mGLAliasedPointSizeRange);
		glGetIntegerv(GL_NUM_COMPRESSED_TEXTURE_FORMATS, &mGLNumCompressedTextureFormats);
		mGLCompressedTextureFormats = new GLint[mGLNumCompressedTextureFormats];
		glGetIntegerv(GL_COMPRESSED_TEXTURE_FORMATS, mGLCompressedTextureFormats);
		glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &mGLMaxCombinedTextureImageUnits);
		glGetIntegerv(GL_MAX_CUBE_MAP_TEXTURE_SIZE, &mGLMaxCubeMapTextureSize);
		glGetIntegerv(GL_MAX_RENDERBUFFER_SIZE, &mGLMaxRenderbufferSize);
		glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &mGLMaxTextureImageUnits);
		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &mGLMaxTextureSize);
		glGetIntegerv(GL_MAX_VERTEX_ATTRIBS, &mGLMaxVertexAttrib);
		glGetIntegerv(GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS, &mGLMaxVertexTextureImageUnits);
		glGetIntegerv(GL_MAX_VIEWPORT_DIMS, mGLMaxViewportDims);
		glGetIntegerv(GL_SUBPIXEL_BITS, &mGLSubpixelBits);

		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			glGetIntegerv(GL_MAX_VARYING_VECTORS, &mGLMaxVaryingVectors);
		#else
			CHECKGLERROR_TERM();
			glGetIntegerv(GL_MAX_VARYING_COMPONENTS, &mGLMaxVaryingVectors);
			if(glGetError()!=GL_NO_ERROR){
				mGLMaxVaryingVectors = 60; // minimum required
			}
		#endif

		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			glGetIntegerv(GL_MAX_FRAGMENT_UNIFORM_VECTORS, &mGLMaxFragmentUniformVectors);
		#else
			glGetIntegerv(GL_MAX_FRAGMENT_UNIFORM_COMPONENTS, &mGLMaxFragmentUniformVectors);
		#endif

		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			glGetIntegerv(GL_MAX_VERTEX_UNIFORM_VECTORS, &mGLMaxVertexUniformVectors);
		#else
			glGetIntegerv(GL_MAX_VERTEX_UNIFORM_COMPONENTS, &mGLMaxVertexUniformVectors);
		#endif

		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			CHECKGLERROR_TERM();
			mGLMaxColorAttachments = 1;
			mGLMaxDrawBuffers = 1;
			mGLMaxSamples = 1;
			mGLMaxDrawBuffers = 1;
			mGLStereo = 0;
			#if RENG_PLATFORM == RENG_PLATFORM_OMAP
				glGetIntegerv(GL_NUM_SHADER_BINARY_FORMATS, &mGLNumShaderBinaryFormats);
				mGLShaderBinaryFormats = new GLint[mGLNumShaderBinaryFormats];
				glGetIntegerv(GL_SHADER_BINARY_FORMATS, mGLShaderBinaryFormats);
				glGetBooleanv(GL_SHADER_COMPILER, &mGLShaderCompiler);
			#else
				mGLNumShaderBinaryFormats = 0;
				mGLShaderBinaryFormats = 0;
				mGLShaderCompiler=true;
			#endif
			CHECKGLERROR_TERM();
		#else
			glGetIntegerv(GL_MAX_COLOR_ATTACHMENTS, &mGLMaxColorAttachments);
			glGetIntegerv(GL_MAX_SAMPLES, &mGLMaxSamples);
			glGetIntegerv(GL_MAX_DRAW_BUFFERS, &mGLMaxDrawBuffers);
			glGetIntegerv(GL_MAX_DRAW_BUFFERS, &mGLMaxDrawBuffers);
			glGetBooleanv(GL_STEREO, &mGLStereo);
			mGLNumShaderBinaryFormats = 1;
			mGLShaderBinaryFormats = new GLint[1]; mGLShaderBinaryFormats[0] = 0;
			mGLShaderCompiler = true;
		#endif

		readExtensions();
	}
	
	void GPUConfig::readExtensions(){
//		Logger logger = Logger::getInstance("RSys");
//		LOG4CPLUS_INFO(logger,"Reading Extentions ...");
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			// ES still uses GL_EXTENTIONS 
			const char* glStr = (const char*)glGetString(GL_EXTENSIONS);
			
			// we need a non-const string
			size_t glStrLen = strlen(glStr);
			char* cExt = (char*) malloc((glStrLen+1) * sizeof(char));
			strcpy(cExt,glStr);

			// learn number of tokens(extensions) in the string
			const char* delim = " ";
			char* c = strtok(cExt,delim);
			for(mExtentionCount=0 ; c!=NULL ; ++mExtentionCount) c=strtok(NULL,delim);
			mExtentionInfoList = (char**) malloc(mExtentionCount * sizeof(char*));
//			LOG4CPLUS_INFO(logger,"  Number of extensions supported:" << mExtentionCount);

			// re-fill the cExt string
			strcpy(cExt,glStr);

			// copy the extension strings to mExtentionInfoList
			c = strtok(cExt,delim);
			for(size_t i=0 ; c!=NULL; ++i) {
				size_t sLen = strlen(c);
				mExtentionInfoList[i] = (char*) malloc((sLen+1) * sizeof(char));
				strcpy(mExtentionInfoList[i],c);
				c = strtok(NULL,delim);
			}
//			LOG4CPLUS_INFO(logger,"  All extension strings are copied to mExtentionInfoList.");
			free(cExt);
		#else
			GLint n;
			glGetIntegerv(GL_NUM_EXTENSIONS, &n);
			mExtentionCount = (size_t) n;
			mExtentionInfoList = (char**) malloc(mExtentionCount * sizeof(char*));
			for(size_t i=0; i<mExtentionCount; i++) {
				const char* c = (const char*) glGetStringi(GL_EXTENSIONS, (GLint)i);
				size_t sLen = strlen(c);
				mExtentionInfoList[i] = (char*) malloc((sLen+1) * sizeof(char));
				strcpy(mExtentionInfoList[i],c);
				mExtentionInfoList[i][sLen] = 0;
			}
		#endif
	}
	void GPUConfig::logExtensions(){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"Available Extensions: ");
		for(size_t i=0 ; i<mExtentionCount ; i++){
			LOG4CPLUS_INFO(logger,"\t" << i << " " << mExtentionInfoList[i]);
		}
	}

	void GPUConfig::log(){
		Logger logger = Logger::getInstance("RSys");
		
		LOG4CPLUS_INFO(logger,"OpenGL Version   :" << mGLVersion << 
			"  (Major:"<<mGLVersionMajor<<" Minor:"<<mGLVersionMinor<<")");
		LOG4CPLUS_INFO(logger,"OpenGL SL Version:" << mGLSLVersion << 
			"  (Major:"<<mGLSLVersionMajor<<" Minor:"<<mGLSLVersionMinor<<")");
		LOG4CPLUS_INFO(logger,"OpenGL Renderer  :" << mRendererName);
		LOG4CPLUS_INFO(logger,"OpenGL Vendor    :" << mVendorName);

#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		if((mGLVersionMajor>3) || ((mGLVersionMajor==3)&&(mGLVersionMinor>=2))){
			GLint contextProfile(10);
			glGetIntegerv(GL_CONTEXT_PROFILE_MASK,&contextProfile);
			switch(contextProfile){
				case GL_CONTEXT_CORE_PROFILE_BIT:
					LOG4CPLUS_INFO(logger,"OpenGL Profile   :Core"); break;
				case GL_CONTEXT_COMPATIBILITY_PROFILE_BIT:
					LOG4CPLUS_INFO(logger,"OpenGL Profile   :Compability"); break;
				case WGL_CONTEXT_ES2_PROFILE_BIT_EXT:
					LOG4CPLUS_INFO(logger,"OpenGL Profile   :ES2"); break;
				default:
					LOG4CPLUS_INFO(logger,"OpenGL Profile   :Unset"); break;
			}
		}
		// All modern OpenGL specs support GL_CONTEXT_FLAGS query
		GLint contextFlags(10);
		glGetIntegerv(GL_CONTEXT_FLAGS,&contextFlags);
		if(contextFlags&GL_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT){
			LOG4CPLUS_INFO(logger,"OpenGL Context Flag:Forward-Compatible");
		} else {
			LOG4CPLUS_INFO(logger,"OpenGL Context Flag:Backward-Compatible");
		}
#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		LOG4CPLUS_INFO(logger,"OpenGL Profile    : ES2");
#endif

		LOG4CPLUS_INFO(logger,"GLAliasedLineWidthRange       :" << mGLAliasedLineWidthRange[0] << " " << mGLAliasedLineWidthRange[1]);
		LOG4CPLUS_INFO(logger,"GLAliasedPointSizeRange       :" << mGLAliasedPointSizeRange[0] << " " << mGLAliasedPointSizeRange[1]);
		LOG4CPLUS_INFO(logger,"GLMaxCombinedTextureImageUnit :" << mGLMaxCombinedTextureImageUnits);
		LOG4CPLUS_INFO(logger,"GLMaxCubeMapTextureSize       :" << mGLMaxCubeMapTextureSize);
		LOG4CPLUS_INFO(logger,"GLMaxDrawBuffers              :" << mGLMaxDrawBuffers);
		LOG4CPLUS_INFO(logger,"GLMaxFragmentUniformVectors   :" << mGLMaxFragmentUniformVectors);
		LOG4CPLUS_INFO(logger,"GLMaxRenderbufferSize         :" << mGLMaxRenderbufferSize);
		LOG4CPLUS_INFO(logger,"GLMaxTextureImageUnits        :" << mGLMaxTextureImageUnits);
		LOG4CPLUS_INFO(logger,"GLMaxTextureSize              :" << mGLMaxTextureSize);
		LOG4CPLUS_INFO(logger,"GLMaxVaryingVectors           :" << mGLMaxVaryingVectors);
		LOG4CPLUS_INFO(logger,"GLMaxVertexAttrib             :" << mGLMaxVertexAttrib);
		LOG4CPLUS_INFO(logger,"GLMaxVertexTextureImageUnits  :" << mGLMaxVertexTextureImageUnits);
		LOG4CPLUS_INFO(logger,"GLMaxVertexUniformVectors     :" << mGLMaxVertexUniformVectors);
		LOG4CPLUS_INFO(logger,"GLMaxViewportDims             :" << mGLMaxViewportDims[0] << " " << mGLMaxViewportDims[1]);
		LOG4CPLUS_INFO(logger,"GLShaderCompiler              :" << (mGLShaderCompiler?"yes":"no"));
		LOG4CPLUS_INFO(logger,"GLStereo                      :" << (mGLStereo?"yes":"no"));
		LOG4CPLUS_INFO(logger,"GLSubpixelBits                :" << mGLSubpixelBits);

		LOG4CPLUS_INFO(logger,"GLMaxColorAttachments         :" << mGLMaxColorAttachments);

		LOG4CPLUS_INFO(logger,"GLNumShaderBinaryFormats      :" << mGLNumShaderBinaryFormats);
		LOG4CPLUS_INFO(logger,"GLNumCompressedTextureFormats :" << mGLNumCompressedTextureFormats);
		for(GLint i=0;i<mGLNumCompressedTextureFormats;++i){
			if(i==0)LOG4CPLUS_INFO(logger,"GLCompressedTextureFormats (Supported by OpenREng):");
			const char* _str=0;
			switch(mGLCompressedTextureFormats[i]){
				case ImageFormat_Compr_R_RGTC:	      _str = "R_RGTC";         break;
				case ImageFormat_Compr_R_Signed_RGTC:  _str = "R_SIGNED_RGTC";  break;
				case ImageFormat_Compr_RG_RGTC:        _str = "RG_RGTC";        break;
				case ImageFormat_Compr_RG_SIGNED_RGTC: _str = "RG_SIGNED_RGTC"; break;
				case ImageFormat_Compr_RGB_S3TC_DXT1:  _str = "RGB_S3TC_DXT1";  break;
				case ImageFormat_Compr_RGBA_S3TC_DXT1: _str = "RGBA_S3TC_DXT1"; break;
				case ImageFormat_Compr_RGBA_S3TC_DXT3: _str = "RGBA_S3TC_DXT3"; break;
				case ImageFormat_Compr_RGBA_S3TC_DXT5: _str = "RGBA_S3TC_DXT5"; break;
				case ImageFormat_Compr_RGB_PVRTC_4:    _str = "RGB_PVRTC_4";    break;
				case ImageFormat_Compr_RGB_PVRTC_2:    _str = "RGB_PVRTC_2";    break;
				case ImageFormat_Compr_RGBA_PVRTC_4:   _str = "RGBA_PVRTC_4";   break;
				case ImageFormat_Compr_RGBA_PVRTC_2:   _str = "RGBA_PVRTC_2";   break;
				case ImageFormat_Compr_RGB_ETC1:       _str = "RGB_ETC1";       break;
				default: break;
			}
			LOG4CPLUS_INFO(logger,"\t"<<i<<" "<<_str);
		}
		logExtensions();
	}

	// **************************
	// GETTERS
	// **************************


	const char *GPUConfig::getGLVersion() const{ return mGLVersion; }
	const char *GPUConfig::getGLSLVersion() const{ return mGLSLVersion; }
	const char *GPUConfig::getRendererName() const{ return mRendererName; }
	const char *GPUConfig::getVendorName() const{ return mVendorName; }
	int GPUConfig::getGLVersionMajor() const{ return mGLVersionMajor; }
	int GPUConfig::getGLVersionMinor() const{ return mGLVersionMinor; }
	int GPUConfig::getGLSLVersionMajor() const{ return mGLSLVersionMajor; }
	int GPUConfig::getGLSLVersionMinor() const{ return mGLSLVersionMinor; }
	const GLfloat* GPUConfig::getGLAliasedLineWidthRange() const{ return mGLAliasedLineWidthRange; }
	const GLfloat* GPUConfig::getGLAliasedPointSizeRange() const{ return mGLAliasedPointSizeRange; }
	GLint   GPUConfig::getGLNumCompressedTextureFormats() const{ return mGLNumCompressedTextureFormats; }
	const GLint*  GPUConfig::getGLCompressedTextureFormats() const{ return mGLCompressedTextureFormats; }
	GLint   GPUConfig::getGLMaxCombinedTextureImageUnits() const{ return mGLMaxCombinedTextureImageUnits; }
	GLint   GPUConfig::getGLMaxCubeMapTextureSize() const{ return mGLMaxCubeMapTextureSize; }
	GLint   GPUConfig::getGLMaxFragmentUniformVectors() const{ return mGLMaxFragmentUniformVectors; }
	GLint   GPUConfig::getGLMaxRenderbufferSize() const{ return mGLMaxRenderbufferSize; }
	GLint   GPUConfig::getGLMaxTextureImageUnits() const{ return mGLMaxTextureImageUnits; }
	GLint   GPUConfig::getGLMaxTextureSize() const{ return mGLMaxTextureSize; }
	GLint   GPUConfig::getGLMaxVaryingVectors() const{ return mGLMaxVaryingVectors; }
	GLint   GPUConfig::getGLMaxVertexAttrib() const{ return mGLMaxVertexAttrib; }
	GLint   GPUConfig::getGLMaxVertexTextureImageUnits() const{ return mGLMaxVertexTextureImageUnits; }
	GLint   GPUConfig::getGLMaxVertexUniformVectors() const{ return mGLMaxVertexUniformVectors; }
	const GLint*  GPUConfig::getGLMaxViewportDims() const{ return mGLMaxViewportDims; }
	GLint   GPUConfig::getGLNumShaderBinaryFormats() const{ return mGLNumShaderBinaryFormats; }
	const GLint*  GPUConfig::getGLShaderBinaryFormats() const{ return mGLShaderBinaryFormats; }
	GLboolean GPUConfig::getGLShaderCompiler() const{ return mGLShaderCompiler; }
	GLboolean GPUConfig::getGLStereo() const{ return mGLStereo; }
	GLint   GPUConfig::getGLSubpixelBits() const{ return mGLSubpixelBits; }
	GLint   GPUConfig::getGLMaxColorAttachments() const{ return mGLMaxColorAttachments; }
	GLint   GPUConfig::getGLMaxSamples() const{ return mGLMaxSamples; }
	GLint   GPUConfig::getGLMaxDrawBuffers() const{ return mGLMaxDrawBuffers; }

	bool GPUConfig::isCompressedImageFormatSupported(ImageFormat format) const{
		for(GLint i=0;i<mGLNumCompressedTextureFormats;++i){
			if(mGLCompressedTextureFormats[i]==format) return true;
		}
		return false;
	}


	GLint GPUConfig::getSynchTime() const{
		bool isSupported = false;
		if(getGLVersionMajor()>3) {
			isSupported = true;
		} else if(getGLVersionMajor()==3&&getGLVersionMinor()>=3) {
			isSupported = true;
		} else {
			// check if extension ARB_timer_query is available
			// TODO
		}
		if(!isSupported) return 0;
		GLint toRet;
		glGetIntegerv(GL_TIMESTAMP,&toRet);
		return toRet;
	}
}
