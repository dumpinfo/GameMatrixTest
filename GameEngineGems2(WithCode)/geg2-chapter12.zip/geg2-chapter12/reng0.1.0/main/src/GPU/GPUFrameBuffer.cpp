/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUFrameBuffer.h"

#include "REng/GPU/GPUConfig.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	FrameBufferBindTarget GPUFrameBuffer::FBBindTarget =  FrameBufferBindTarget_Default;
	GPUFrameBuffer* GPUFrameBuffer::ActiveFBO = 0;

	GPUFrameBuffer::GPUFrameBuffer() 
	: mDepthAttachment(0), mStencilAttachment(0)
	{
		mCompletenessStatus = false;
		mUpdated = true;

		// initialize the color attachments array
		GLint colorAttachLimit = GPUConfig::getSingleton().getGLMaxColorAttachments();
		size_t memSize = colorAttachLimit*sizeof(RenderTarget*);
		mColorAttachments = (const RenderTarget**) malloc(memSize);
		memset(mColorAttachments, 0, memSize);
		createResource();
	}

	GPUFrameBuffer::~GPUFrameBuffer() {
		free(mColorAttachments);
		destroyResource();
	}

	void GPUFrameBuffer::createResource(){
		if(mResourceID!=0) return;
		glGenFramebuffers(1,&mResourceID);
		assert(mResourceID!=0);
	}

	void GPUFrameBuffer::destroyResource(){
		if(mResourceID!=0) glDeleteFramebuffers(1,&mResourceID);
	}
	
	bool GPUFrameBuffer::setBindTarget(FrameBufferBindTarget target){
		if(!isSupported(target))	return false;
		FBBindTarget = target;
		return true;
	}

	FrameBufferBindTarget GPUFrameBuffer::getBindTarget(){
		return FBBindTarget;
	}

	GPUFrameBuffer* GPUFrameBuffer::getActiveFBO(){
		return ActiveFBO;
	}

	void GPUFrameBuffer::bindResource() const{
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES // target cannot be none
		if(FBBindTarget == GL_NONE) return;
		#endif
		// prevent re-binding of currently attaced FBO
		if(ActiveFBO){
			if(ActiveFBO->mResourceID == this->mResourceID) return;
		}
		glBindFramebuffer(FBBindTarget,mResourceID);
		ActiveFBO = const_cast<GPUFrameBuffer*>(this);
	}

	void GPUFrameBuffer::unbindResource(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(FBBindTarget == GL_NONE) return;
		#endif
		glBindFramebuffer(FBBindTarget,0);
		ActiveFBO = 0;
	}

	ushort GPUFrameBuffer::getWidth() const{
		ushort toRet = 0;
		if(mDepthAttachment) 
			if(mDepthAttachment->getWidth()>toRet) toRet = mDepthAttachment->getWidth();
		if(mStencilAttachment) 
			if(mStencilAttachment->getWidth()>toRet) toRet = mStencilAttachment->getWidth();
		GLint colorAttachLimit = GPUConfig::getSingleton().getGLMaxColorAttachments();
		for(GLint i=0;i<colorAttachLimit;++i){
			if(mColorAttachments[i]) {
				ushort w = mColorAttachments[i]->getWidth();
				if(w>toRet) toRet = w;
			}
		}
		return toRet;
	}
	ushort GPUFrameBuffer::getHeight() const{
		ushort toRet = 0;
		if(mDepthAttachment) 
			if(mDepthAttachment->getHeight()>toRet) toRet = mDepthAttachment->getHeight();
		if(mStencilAttachment) 
			if(mStencilAttachment->getHeight()>toRet) toRet = mStencilAttachment->getHeight();
		GLint colorAttachLimit = GPUConfig::getSingleton().getGLMaxColorAttachments();
		for(GLint i=0;i<colorAttachLimit;++i){
			if(mColorAttachments[i]) {
				ushort w = mColorAttachments[i]->getWidth();
				if(w>toRet) toRet = w;
			}
		}
		return toRet;
	}

	uchar GPUFrameBuffer::getColorAttachmentCount() const{
		uchar toRet(0);
		GLint colorAttachLimit = GPUConfig::getSingleton().getGLMaxColorAttachments();
		for(GLint i=0;i<colorAttachLimit;++i) if(mColorAttachments[i]) ++toRet;
		return toRet;
	}

	bool GPUFrameBuffer::isMultiRenderTarget(){
		return getColorAttachmentCount()==1;
	}
	const RenderTarget* GPUFrameBuffer::getDepthAttachment() const{
		return mDepthAttachment;
	}
	const RenderTarget* GPUFrameBuffer::getStencilAttachment() const{
		return mStencilAttachment;
	}
	const RenderTarget* GPUFrameBuffer::getColorAttachment(FrameBufferAttachType colorType) const{
		int offset = (int)colorType - FrameBufferAttachType_Color0;
		if(offset<0 || offset > GPUConfig::getSingleton().getGLMaxColorAttachments())
			return 0;
		return mColorAttachments[offset];
	}

	bool GPUFrameBuffer::isComplete(GLenum &status){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(FBBindTarget == GL_NONE) return false;
		#endif

		bindResource();

		mCompletenessStatus = glCheckFramebufferStatus(FBBindTarget);
		const char* statusStr = 0;
		switch( mCompletenessStatus ){
			// Note: Using official 3.1 spec error definitions
			case GL_FRAMEBUFFER_COMPLETE:
				break;
			case GL_FRAMEBUFFER_UNDEFINED:
				statusStr = "The target is the default frame buffer and default framebuffer does not exist.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
				statusStr = "All framebuffer attachment points are not framebuffer attachment complete.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
				statusStr = "There is no image attached to the framebuffer.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER:
				statusStr = "A null attachment is done to some color attachment point named by DRAW_BUFFERi.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER:
				statusStr = "Read buffer is set, but the attachment is to READ_BUFFER is null.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE:
				statusStr = "The value of RENDERBUFFER SAMPLES is not the same for all attached renderbuffers;"
					         " and, if the attached images are a mix of renderbuffers and textures,"
					         "the value of RENDERBUFFER SAMPLES is zero for all attached renderbuffers.";
				break;
			case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS:
				statusStr = "Mismatched image/buffer dimensions.";
				break;
			case GL_FRAMEBUFFER_UNSUPPORTED:
				statusStr = "Attachment configuration is not supported by current graphics card/driver.";
				break;
			default: // NOT EXPECTED
				assert(0);
				break;
		}
		if(mCompletenessStatus!=GL_FRAMEBUFFER_COMPLETE) {
			Logger logger = Logger::getInstance("RSys");
			LOG4CPLUS_ERROR(logger, "GPUFrameBuffer | Framebuffer is not complete : " << statusStr);
		}
		status = mCompletenessStatus;
		return (mCompletenessStatus==GL_FRAMEBUFFER_COMPLETE);
	}

}
