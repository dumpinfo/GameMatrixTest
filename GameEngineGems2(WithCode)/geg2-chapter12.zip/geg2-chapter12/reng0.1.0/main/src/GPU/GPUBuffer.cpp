/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUBuffer.h"

namespace REng{

	/************************************************************************/
	/* SW BUFFER                                                            */
	/************************************************************************/

	SWBuffer::SWBuffer(size_t sizeInBytes){
		mSizeInBytes = sizeInBytes;
		mBuffer = 0;
		allocMem();
	}
	SWBuffer::SWBuffer(){
		mSizeInBytes = 0;
		mBuffer = 0;
	}
	SWBuffer::~SWBuffer() { 
		if(mBuffer) free(mBuffer);
	}
	size_t SWBuffer::getSizeInBytes(void) const{
		return mSizeInBytes;
	}
	void* SWBuffer::getBuffer(){
		return mBuffer;
	}
	void SWBuffer::writeData(const void* data){
		memcpy(mBuffer,data,mSizeInBytes);
	}
	void SWBuffer::allocMem(){
		if(mBuffer) { free(mBuffer); mBuffer=0;}
		mBuffer = malloc(mSizeInBytes);
		assert(mBuffer);
	}

	/************************************************************************/
	/* HW BUFFER                                                            */
	/************************************************************************/

	GPUBuffer::GPUBuffer(BufferBindTarget type, BufferUsageFreq usageFreq, BufferUsageNature usageNature, bool useLocalBuffer)
	:	mTarget(type),
		mUsageFreq(usageFreq),
		mUsageNature(usageNature),
		mIsResourceMapped(false),
		mUseLocalBuffer(useLocalBuffer),
		mLocalBuffer(0)
	{	mSizeInBytes = 0;
		createResource();
	}

	GPUBuffer::~GPUBuffer() {
		destroyResource();
		if(mUseLocalBuffer){
			free(mLocalBuffer);
			mLocalBuffer = 0;
		}
	}
	size_t GPUBuffer::getSizeInBytes(void) const{
		return mSizeInBytes;
	}
	bool GPUBuffer::getUseLocalBuffer(void) const{
		return mUseLocalBuffer;
	}
	void GPUBuffer::createResource(){
		if(mResourceID!=0) return;
		glGenBuffers(1,&mResourceID);
		assert(mResourceID != 0);
	}

	void GPUBuffer::destroyResource(){
		if(mResourceID==0) return;
		glDeleteBuffers(1,&mResourceID);
		mResourceID = 0;
	}

	void GPUBuffer::bindResource() const{
		if(mResourceID == 0) return;
		if(!isSupported(mTarget)) return;
		bindResource(mTarget,mResourceID);
	}

	void GPUBuffer::unbindResource(BufferBindTarget target) {
		if(target == BufferBindTarget_None) return;
		bindResource(target,0);
	}

	void GPUBuffer::unbindResource() const{
		bindResource(mTarget,0);
	}

	void GPUBuffer::bindResource(BufferBindTarget target, GLuint resID){
		static GLuint activeBindTargets[BufferBindTarget_None];
		EXEC_ONCE_BEGIN();
		memset(activeBindTargets,0,sizeof(activeBindTargets));
		EXEC_ONCE_END();
		switch(target){
			case BufferBindTarget_Vertex: 
				if(activeBindTargets[0]==resID) return;
				activeBindTargets[0] = resID;
				break;
			case BufferBindTarget_Index:
				if(activeBindTargets[1]==resID) return;
				activeBindTargets[1] = resID;
				break;
			default: break; // TODO: support other buffer types also!
		}
		glBindBuffer(target,resID);
	}

	void GPUBuffer::initStorage(size_t bufSize){
//		if(mSizeInBytes==0) {
			mSizeInBytes = bufSize;
			if(mSizeInBytes==0) return;
//		}

		// create storage for the shadow buffer if requested
		if(mUseLocalBuffer){
			free(mLocalBuffer);
			mLocalBuffer = malloc(mSizeInBytes);
		}

		writeData(0);
	}

	void GPUBuffer::writeData(const void* data){
		bindResource();
		glBufferData(mTarget, mSizeInBytes, data, getGLBufUsage());
		if(mUseLocalBuffer){
			memcpy(mLocalBuffer,data,mSizeInBytes);
		}
	}

	void GPUBuffer::writeData(const void* data, size_t dataSize, size_t rangeOffset, bool discardWholeBuffer){
		if(discardWholeBuffer) writeData(0);
		bindResource();
		glBufferSubData(mTarget, rangeOffset, dataSize, data);
		if(mUseLocalBuffer){
			memcpy((char*)mLocalBuffer+rangeOffset,data,dataSize);
		}
	}

	void* GPUBuffer::mapResource(size_t dataSize, size_t rangeOffset, BufferAccessOp access, int accessDetails){
		if(mSizeInBytes == 0) {
			// buffer storage not created TODO log error?
			return 0;
		}
		if(rangeOffset+dataSize>mSizeInBytes){
			// TODO : log error?
			return 0;
		}
		// return shadow buffer copy
		if(mUseLocalBuffer){
			return (char*)mLocalBuffer+rangeOffset;
		}
		void* toRet = 0;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			// It does not support mapping buffers
			return toRet;
		#else
		if(rangeOffset==0 && dataSize==mSizeInBytes){
			bindResource();
			toRet = glMapBuffer(mTarget,access);
			mIsResourceMapped = true;
			mAccessOp = access;
		} else {
			// create the detailed access info
			GLbitfield accessInfo = accessDetails;
			switch(access){
				case BufferAccessOp_Read:
					accessInfo = accessInfo & GL_MAP_READ_BIT;
					break;
				case BufferAccessOp_Write:
					accessInfo = accessInfo & GL_MAP_WRITE_BIT;
					break;
				case BufferAccessOp_ReadWrite:
					accessInfo = accessInfo & GL_MAP_READ_BIT | GL_MAP_WRITE_BIT;
					break;
			}

			bindResource();
			// TODO: there is a bug (?) in GLee, mapbuffer range returns void (not void ptr)
			glMapBufferRange(mTarget, rangeOffset, dataSize, accessInfo);
			mIsResourceMapped = true;
			mAccessOp = access;
		}
		return toRet;
		#endif
	}


	void GPUBuffer::unmapResource(){
		#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		if(mIsResourceMapped){
			glUnmapBuffer(mTarget);
		} else {
		#endif
			// you may have modified the local copy
			if (mAccessOp == BufferAccessOp_ReadWrite || mAccessOp == BufferAccessOp_Write) {
				bindResource();
				glBufferData(mTarget, mSizeInBytes, mLocalBuffer, getGLBufUsage());
			}
		#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		}
		#endif
	}

	GLenum GPUBuffer::getGLBufUsage(){
		switch(mUsageFreq){
		case BufferUsageFreq_Stream:
			if( mUsageNature==BufferUsageNature_Draw) return GL_STREAM_DRAW;
			if( mUsageNature==BufferUsageNature_Read) return GL_STREAM_READ;
			if( mUsageNature==BufferUsageNature_Copy) return GL_STREAM_COPY;

		case BufferUsageFreq_Static:
			if( mUsageNature==BufferUsageNature_Draw) return GL_STATIC_DRAW;
			if( mUsageNature==BufferUsageNature_Read) return GL_STATIC_READ;
			if( mUsageNature==BufferUsageNature_Copy) return GL_STATIC_COPY;

		case BufferUsageFreq_Dynamic:
			if( mUsageNature==BufferUsageNature_Draw) return GL_DYNAMIC_DRAW;
			if( mUsageNature==BufferUsageNature_Read) return GL_DYNAMIC_READ;
			if( mUsageNature==BufferUsageNature_Copy) return GL_DYNAMIC_COPY;

		}
		return 0;
	}
	
	/************************************************************************/
	/* BASIC VERTEX-INDEX BUFFERS                                           */
	/************************************************************************/

	VertexBuffer::VertexBuffer(size_t vertexSize, size_t numVertices)
		:mVertexCount(numVertices), mVertexSize(vertexSize) { ; }
	size_t VertexBuffer::getVertexSize() const{
		return mVertexSize;
	}
	size_t VertexBuffer::getVertexCount(void) const{
		return mVertexCount;
	}

	IndexBuffer::IndexBuffer(IndexDataType type, size_t numIndexes)
		: mType(type), mIndexCount(numIndexes){ ; }
	IndexDataType IndexBuffer::getIndexType(void) const{
		return mType;
	}
	size_t IndexBuffer::getIndexSize() const{
		return getIndexDataByteSize(mType);
	}
	size_t IndexBuffer::getIndexCount(void) const{
		return mIndexCount;
	}

	/************************************************************************/
	/* SOFTWARE INDEX-VERTEX BUFFERS                                        */
	/************************************************************************/

	SWVertexBuffer::SWVertexBuffer(size_t vertexSize, size_t numVertices)
		: VertexBuffer(vertexSize, numVertices) { 
		mSizeInBytes = mVertexSize * mVertexCount;
		allocMem();
	}
	SWVertexBuffer::~SWVertexBuffer() { ; }
	BufferType SWVertexBuffer::getType() const{ return BufferType_CPU;}

	SWIndexBuffer::SWIndexBuffer(IndexDataType type, size_t numIndexes)
		: IndexBuffer(type, numIndexes) {
		mSizeInBytes = getIndexSize() * mIndexCount;
		allocMem();
	}
	SWIndexBuffer::~SWIndexBuffer() { ; }
	BufferType SWIndexBuffer::getType() const{ return BufferType_CPU;}

	/************************************************************************/
	/* HARDWARE INDEX-VERTEX BUFFERS                                        */
	/************************************************************************/

	GPUVertexBuffer::GPUVertexBuffer(size_t vertexSize, size_t numVertices, BufferUsageFreq freq, BufferUsageNature nature, bool useLocalBuffer)
		:
		GPUBuffer(BufferBindTarget_Vertex,freq,nature,useLocalBuffer), 
		VertexBuffer(vertexSize,numVertices)
	{
		initStorage( mVertexSize * mVertexCount );
	}
	GPUVertexBuffer::~GPUVertexBuffer() { ; }
	BufferType GPUVertexBuffer::getType() const{ return BufferType_GPU;}
	void GPUVertexBuffer::unbind(){
		unbindResource(BufferBindTarget_Vertex);
	}

	GPUIndexBuffer::GPUIndexBuffer(IndexDataType type, size_t numIndexes, BufferUsageFreq freq, BufferUsageNature nature, bool useLocalBuffer)
		:
		GPUBuffer(BufferBindTarget_Index,freq,nature,useLocalBuffer), 
		IndexBuffer(type, numIndexes)
	{
		if(!isSupported(type)) return;
		initStorage( getIndexSize() * mIndexCount );
	}
	GPUIndexBuffer::~GPUIndexBuffer() { };
	BufferType GPUIndexBuffer::getType() const{ return BufferType_GPU;}
	void GPUIndexBuffer::unbind(){
		unbindResource(BufferBindTarget_Index);
	}

}

