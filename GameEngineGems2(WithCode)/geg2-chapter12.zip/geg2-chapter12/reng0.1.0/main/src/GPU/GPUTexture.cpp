/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUTexture.h"

// binding to FBO
#include "REng/GPU/GPUFrameBuffer.h"
#include "REng/GPU/GPUConfig.h"

#include <assert.h>

// logging support
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	const char* _gputextureLogIn = "GPUTexture | ";

	GPUTexture::GPUTexture(TextureType type) 
	:	mType(type), 
		mIsComplete(false),
		mGenMipmaps(false){

		if(!isSupported()) {
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"), _gputextureLogIn<<"An unsupported texture type is specified.");
			return;
		}

		mSampler.setTarget(type);

		mSampler.setWrapMode(WrapAxis_S,WrapMode_Repeat);
		mSampler.setWrapMode(WrapAxis_T,WrapMode_Repeat);
		mSampler.setWrapMode(WrapAxis_R,WrapMode_Repeat);
		mSampler.setMinFilter(MinFilter_Nearest);
		mSampler.setMagFilter(MagFilter_Nearest);

		mInternalFormat = ImageFormat_RGB;

		createResource();
	}

	GPUTexture::~GPUTexture(){
		destroyResource();
	}

	//******************************
	// GPU resource creation/deletion
	void GPUTexture::createResource(){
		if(mResourceID != 0) return;
		glGenTextures(1,&mResourceID);
		assert(mResourceID != 0);
	}
	void GPUTexture::destroyResource(){
		if(mResourceID == 0) return;
		glDeleteTextures(1,&mResourceID);
	}

	void GPUTexture::setActiveTextureUnit(uchar unitID){
#ifdef RENG_DEBUG_BUILD
		if(unitID>=GPUConfig::getSingleton().getGLMaxCombinedTextureImageUnits())
			return;
#endif
		static uchar activeUnitID = 0;
		if(unitID!=activeUnitID){
			glActiveTexture(GL_TEXTURE0+unitID);
			activeUnitID = unitID;
		}
	}
	//************************************
	// getters
	TextureType GPUTexture::getType()      const{ return mType; }
	MagFilter   GPUTexture::getMagFilter() const{ return mSampler.getMagFilter(); }
	MinFilter   GPUTexture::getMinFilter() const{ return mSampler.getMinFilter(); }
	WrapMode    GPUTexture::getWrapModeS() const{ return mSampler.getWrapMode(WrapAxis_S); }
	WrapMode    GPUTexture::getWrapModeT() const{ return mSampler.getWrapMode(WrapAxis_T); }
	WrapMode    GPUTexture::getWrapModeR() const{ return mSampler.getWrapMode(WrapAxis_R); }
	bool        GPUTexture::getGenMipmaps()const{ return mGenMipmaps; }
	//************************************
	// setters
	void GPUTexture::setInternalFormat(ImageFormat format){
		if(!REng::isSupportedTextureFormat(format)){
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"), _gputextureLogIn<<"setInternalFormat | Not supported format. ID:"<<format);
			return;
		}
		mInternalFormat = format;
	}
	void GPUTexture::setMinFilter(MinFilter filter){
		mSampler.setMinFilter(filter);
	}
	void GPUTexture::setMagFilter(MagFilter filter){
		mSampler.setMagFilter(filter);
	}
	void GPUTexture::setWrap(WrapAxis axis, WrapMode mode ){
		mSampler.setWrapMode(axis,mode);
	}
	void GPUTexture::setGenMipmaps(bool flag){
		mGenMipmaps = flag;
	}
	//******************************
	// simple queries
	bool GPUTexture::isSupported()  const{ return REng::isSupported(mType); }
	bool GPUTexture::isComplete()   const{ return mIsComplete; }
	bool GPUTexture::isCompressed() const{ return isCompressedFormat(mInternalFormat); }
	//******************************
	// bind/unbind
	void GPUTexture::bindResource() const {
		if(!isSupported()) return;
		if(mResourceID == 0) return;
		glBindTexture(mType,mResourceID);
	}
	void GPUTexture::unbindResource() {
		glBindTexture(mType,0);
	}

	void GPUTexture::generateMipmaps(){
		if(isSupported()==false) return;
		if(hasComponent(RTC_Depth)==true) return;
		if(hasComponent(RTC_Stencil)==true) return;
		// ADIL: Note: Most of the Desktop OpenGL drivers want non-mipmapped filtering active 
		//             when glGenerateMipmap is called...
		MinFilter realMode = mSampler.getMinFilter();
		mSampler.setMinFilter(MinFilter_Linear);
		mSampler.updateState();
		glGenerateMipmap(mType);
		mSampler.setMinFilter(realMode);
		mSampler.updateState();
	}

	void GPUTexture::setSamplerProperties(const GPUSampler& sampler){
		mSampler.copyState(sampler);
	}
	void GPUTexture::setSamplerProperty(const SamplerProp& prop){
		switch(prop.getType()){
			case RPT_mag_filter:
				setMagFilter(static_cast<const SamplerProp_MagFilter&>(prop).getMode()); break;
			case RPT_min_filter:
				setMinFilter(static_cast<const SamplerProp_MinFilter&>(prop).getMode()); break;
			case RPT_wrap_mode:
				setWrap(static_cast<const SamplerProp_WrapMode&>(prop).getAxis(), 
				        static_cast<const SamplerProp_WrapMode&>(prop).getWrapMode()); break;
			default: break;
		}
	}
	void GPUTexture::updateSamplerState(){
		if(!isSupported()) return;
		bindResource();
		mSampler.updateState();
	}
	void GPUTexture::invalidateSamplerState(){
		mSampler.invalidateState();
	}
	//******************************
	// helpers for loader routines
	bool GPUTexture::checkLoadParameters(PixelDataFormat format, PixelDataType type){
		Logger logger = Logger::getInstance("mtrl");
		if(!REng::isSupported(format)) {
			LOG4CPLUS_ERROR(logger, _gputextureLogIn<<"Pixel data format is not supported : "<<format);
			return false;
		}
		if(type == PixelDataType_UShort_5_6_5 && format != PixelDataFormat_RGB){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Type ushort_5_6_5 is incompatible with given format["<<format<<"].");
			return false;
		}
		if(type == PixelDataType_UShort_5_5_5_1 && format != PixelDataFormat_RGBA){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Type ushort_5_5_5_1 is incompatible with given format["<<format<<"].");
			return false;
		}
		if(type == PixelDataType_UShort_4_4_4_4 && format != PixelDataFormat_RGBA){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Type ushort_4_4_4_4 is incompatible with given format["<<format<<"].");
			return false;
		}
		return true;
	}
	bool GPUTexture::checkTextureSize(uint width, uint height) const{
		uint maxTexSize = (uint)GPUConfig::getSingleton().getGLMaxTextureSize();
		if(width>maxTexSize || height>maxTexSize){
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"), _gputextureLogIn<<"Texture size["<<width<<","<<height<<"] exceeds HW limits["<<maxTexSize<<","<<maxTexSize<<"]");
			return false;
		}
		return true;
	}
	bool GPUTexture::checkSubImgSize(uint xoffset, uint yoffset, uint zoffset, 
		uint width, uint height, uint depth) const
	{
		if(xoffset+width >mWidth ) return false;
		if(yoffset+height>mHeight) return false;
		if(zoffset+depth >mDepth ) return false;
		return true;
	}

	bool GPUTexture::loadFromMemToResource(uint width, uint height, 
			PixelDataType dataType, PixelDataFormat dataFormat, const GLvoid * data, 
			uint lod, CubeMapFace face, uint depth)
	{
		Logger logger = Logger::getInstance("mtrl");
		GLenum errCode;
		if(isCompressed()){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | You must use the compressed data loader.");
			return false;
		}
		if(!checkTextureSize(width,height) || !checkLoadParameters(dataFormat,dataType)) return false;
#ifdef RENG_DEBUG_BUILD
		if((errCode = glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | Unexpected GL error : "<<getGLErrorStr(errCode));
			return false;
		}
#endif
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		bindResource();

		switch(mType){
		case TextureType_2D:
			glTexImage2D(mType,lod,mInternalFormat,width,height,0,dataFormat,dataType,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		case TextureType_1D:
			#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
			glTexImage1D(mType, lod, mInternalFormat, width, 0, dataFormat, dataType, data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			#else
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | GL ES does not support 1D textures.");
			return false;
			#endif
			break;
		case TextureType_Cube:
			glTexImage2D(face,lod,mInternalFormat,width,height,0,dataFormat,dataType,data);
			// does not generate mipmaps automatically
			break;
		case TextureType_3D:
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			// TODO : Extend glew support
//				#ifdef GL_TEXTURE_3D_OES_OK
//				glTexImage3DOES(mType,lod,mInternalFormat,width,height,depth,0,dataFormat,dataType,data);
//				#endif
			#else
				glTexImage3D(mType,lod,mInternalFormat,width,height,depth,0,dataFormat,dataType,data);
			#endif
			break;
		default: break;
		}
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
		mIsComplete = true;
		mWidth = width;
		mHeight = height;
		mDepth = depth;
		updateResolutions();
		return true;
	}
	bool GPUTexture::loadSubImgFromMem(uint xoffset, uint yoffset, uint width, uint height, 
			PixelDataType dataType, PixelDataFormat dataFormat, const GLvoid * data, 
			uint lod, CubeMapFace face, uint zoffset, uint depth)
	{
		Logger logger = Logger::getInstance("mtrl");
		GLenum errCode;
		if(isCompressed()){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | You must use the compressed data loader.");
			return false;
		}
		if(!isComplete()) {
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | Sub-Images can only be loaded to previously well-defined/complete textures.");
			return false;
		}
		if(!checkSubImgSize(xoffset,yoffset,zoffset,width,height,depth) || 
			!checkLoadParameters(dataFormat,dataType)) return false;
#ifdef RENG_DEBUG_BUILD
		if((errCode = glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | Unexpected GL error : "<<getGLErrorStr(errCode));
			return false;
		}
#endif
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		bindResource();

		switch(mType){
		case TextureType_2D:
			glTexSubImage2D(mType,lod,xoffset,yoffset,width,height,dataFormat,dataType,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		case TextureType_1D:
			#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
			glTexSubImage1D(mType,lod,xoffset,width,dataFormat,dataType,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			#else
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | GL ES does not support 1D textures.");
			return false;
			#endif
			break;
		case TextureType_Cube:
			glTexSubImage2D(face,lod,xoffset,yoffset,width,height,dataFormat,dataType,data);
			// does not generate mipmaps automatically
			break;
		case TextureType_3D:
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			// TODO : Extend glew support
//				#ifdef GL_TEXTURE_3D_OES_OK
//				glTexSubImage3DOES(mType, lod, mInternalFormat, width, height, depth, 0, dataFormat, dataType, data);
//				#endif
			#else
				glTexSubImage3D(mType,lod,xoffset,yoffset,zoffset,width,height,depth,dataFormat,dataType,data);
			#endif
			break;
		default: break;
		}
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
		return true;
	}
	bool GPUTexture::loadComprFromMemToResource(uint width, uint height, 
		uint dataSize, const GLvoid * data, uint lod, CubeMapFace face, uint depth)
	{
		Logger logger = Logger::getInstance("mtrl");
		GLenum errCode;
		if(!isCompressed()){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | You must use the uncompressed data loader.");
			return false;
		}
		if(!checkTextureSize(width,height)) return false;
#ifdef RENG_DEBUG_BUILD
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | Unexpected GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
#endif
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		bindResource();

		switch(mType){
		case TextureType_2D:
			glCompressedTexImage2D(mType,lod,mInternalFormat,width,height,0,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		case TextureType_1D:
		case TextureType_3D:
			LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Load | ES | Compressed data cannot be loaded to 1D/3D textures.");
			break;
		#else
		case TextureType_1D:
			glCompressedTexImage1D(mType,lod,mInternalFormat,width,0,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		case TextureType_3D:
			glCompressedTexImage3D(mType,lod,mInternalFormat,width,height,depth,0,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		#endif
		case TextureType_Cube:
			glCompressedTexImage2D(face,lod,mInternalFormat,width, height, 0, dataSize, data);
			// Does not generate mipmaps automatically
			break;
		default: break;
		}
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
		mIsComplete = true;
		mWidth = width;
		mHeight = height;
		mDepth = depth;
		updateResolutions();
		return true;
	}
	bool GPUTexture::loadComprSubImgFromMem(uint xoffset, uint yoffset, uint width, uint height, 
		uint dataSize, const GLvoid * data, uint lod, CubeMapFace face, uint zoffset, uint depth)
	{
		Logger logger = Logger::getInstance("mtrl");
		GLenum errCode;
		if(!isCompressed()){
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | You must use the uncompressed data loader.");
			return false;
		}
		if(!isComplete()) {
			LOG4CPLUS_WARN(logger, _gputextureLogIn<<"Load | Sub-Images can only be loaded to previously well-defined/complete textures.");
			return false;
		}
		if(!checkSubImgSize(xoffset,yoffset,zoffset,width,height,depth)) return false;
#ifdef RENG_DEBUG_BUILD
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | Unexpected GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
#endif
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		bindResource();

		switch(mType){
		case TextureType_2D:
			glCompressedTexSubImage2D(mType,lod,xoffset,yoffset,width,height,mInternalFormat,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		case TextureType_1D:
		case TextureType_3D:
			LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Load | ES | Compressed data cannot be loaded to 1D/3D textures.");
			break;
		#else
		case TextureType_1D:
			glCompressedTexSubImage1D(mType,lod,xoffset,width,mInternalFormat,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		case TextureType_3D:
			glCompressedTexSubImage3D(mType,lod,xoffset,yoffset,zoffset,width,height,depth,mInternalFormat,dataSize,data);
			if(lod==0 && mGenMipmaps) generateMipmaps();
			break;
		#endif
		case TextureType_Cube:
			glCompressedTexSubImage2D(face,lod,xoffset,yoffset,width,height,mInternalFormat,dataSize,data);
			// Does not generate mipmaps automatically
			break;
		default: break;
		}
		if((errCode=glGetError()) != GL_NO_ERROR){
			LOG4CPLUS_FATAL(logger, _gputextureLogIn<<"Load | GL error : "<<getGLErrorStr(errCode));
			mIsComplete = false;
			return false;
		}
		return true;
	}
	bool GPUTexture::readFromResourceToMem(PixelDataType dataType, PixelDataFormat dataFormat, GLvoid * data, 
		uint lod, CubeMapFace face)
	{
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		Logger logger = Logger::getInstance("mtrl");
		if(REng::isDepthStencilFormat(dataFormat)){
			if(!hasComponent(RTC_Depth) && !hasComponent(RTC_Stencil)) {
				LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Read | Requested Depth-Stencil read, but the texture does not have both components.");
				return false;
			}
		} else if(REng::isDepthFormat(dataFormat)){
			if(!hasComponent(RTC_Depth)) {
				LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Read | Requested Depth read, but the texture does not have depth component.");
				return false;
			}
		} else if(REng::isColorFormat(dataFormat)){
			if(!hasComponent(RTC_Alpha)&&!hasComponent(RTC_Red)&&hasComponent(RTC_Green)&&hasComponent(RTC_Blue)) {
				LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Read | Requested Color read, but the texture does not have color component.");
				return false;
			}
		} else {
			LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Read | Stencil-only formats cannot be read back.");
			return false;
		}
		bindResource();
		switch(mType){
			case TextureType_1D:
			case TextureType_2D:
			case TextureType_3D:
				glGetTexImage(mType,lod,dataFormat,dataType,data);
				break;
			case TextureType_Cube:
				glGetTexImage(face,lod,dataFormat,dataType,data);
				break;
			default: break;
		}
		return true;
		#endif
		return false; // ES does not support reading back texture data
	}
	bool GPUTexture::readComprFromResourceToMem(GLvoid * data,uint lod, CubeMapFace face){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		bindResource();
		switch(mType){
			case TextureType_1D:
			case TextureType_2D:
			case TextureType_3D:
				glGetCompressedTexImage(mType, lod, data);
				break;
			case TextureType_Cube:
				glGetCompressedTexImage(face, lod, data);
				break;
			default: break;
		}
		return true;
		#endif
		return false; // ES does not support reading back texture data
	}

	// ****************************************************************
	// Frame buffer attachment routines
	// ****************************************************************
	bool GPUTexture::attachToActiveFBO(uint level,CubeMapFace face) const{
		if(attachToActiveFBODepth(level,face)==true) return true;
		if(attachToActiveFBOStencil(level,face)==true) return true;
		return attachToActiveFBO(FrameBufferAttachType_Color0,level,face);
	}
	bool GPUTexture::attachToActiveFBODepth(uint level, CubeMapFace face) const{
		if(!hasComponent(RTC_Depth)) return false;
		return attachToActiveFBO(FrameBufferAttachType_Depth,level, face);
	}
	bool GPUTexture::attachToActiveFBOStencil(uint level, CubeMapFace face) const{
		if(!hasComponent(RTC_Stencil)) return false;
		return attachToActiveFBO(FrameBufferAttachType_Stencil,level, face);
	}
	bool GPUTexture::attachToActiveFBO(FrameBufferAttachType attachType, uint level, CubeMapFace face) const{
		if(checkAttachmentLevel(level)==false) return false;
		Logger logger = Logger::getInstance("mtrl");

		// TODO: add 3d layer support!!
		int layer3d = 0;
		(void) layer3d;

		switch(mType){
		case TextureType_1D:
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"ES | Attach | 1D textures not supported.");
				return false;
			#else
				glFramebufferTexture1D(GPUFrameBuffer::getBindTarget(),attachType,GL_TEXTURE_1D,mResourceID,level);
			#endif
			break;
		case TextureType_2D:
			glFramebufferTexture2D(GPUFrameBuffer::getBindTarget(),attachType,GL_TEXTURE_2D,mResourceID,level);
			break;
		case TextureType_3D:
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"ES | Attach | 3D textures not supported.");
				return false;
			#else
				glFramebufferTexture3D(GPUFrameBuffer::getBindTarget(),attachType,GL_TEXTURE_3D,mResourceID,level,layer3d);
			#endif
			break;
		case TextureType_Cube:
			glFramebufferTexture2D(GPUFrameBuffer::getBindTarget(),attachType,face,mResourceID,level);
			break;
		}
		#ifdef RENG_DEBUG_BUILD
		GLenum glerr;
		// check OpenGL Error
		glerr = glGetError();
		if(glerr != GL_NO_ERROR){
			LOG4CPLUS_ERROR(logger,_gputextureLogIn<<"Attach | GL error: " << getGLErrorStr(glerr));
			return false;
		}
		#endif

		// active FBO is not zero, so attachment succeeded
		switch(attachType){
			case FrameBufferAttachType_Depth: 
				GPUFrameBuffer::ActiveFBO->mDepthAttachment = this;
				break;
			case FrameBufferAttachType_Stencil: 
				GPUFrameBuffer::ActiveFBO->mStencilAttachment = this;
				break;
			default: {
					int offset = attachType - FrameBufferAttachType_Color0;
					GPUFrameBuffer::ActiveFBO->mColorAttachments[offset] = this;
				}
		}
		return true;
	}

	bool GPUTexture::checkAttachmentLevel(uint level) const{
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		// ES 2 requires that level is always 0
		if(level != 0 ){
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"),
				_gputextureLogIn<<"ES | No support for attaching mipmap levels != 0. Requested level:"<<level);
			return false;
		}
		#endif
		return true;
	}

	void GPUTexture::updateResolutions(){
		// Note: GPUTexture is already bound
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES

		// Note: OpenGL ES 2.0 does not support querying component bit counts!
		// Note: Initially all components are 0.

		// a texture is a depth texture if its internal type has a depth component
		if(mInternalFormat == ImageFormat_D16) mBitSize_Comp[RTC_Depth] = 16;
		if(mInternalFormat == ImageFormat_D24) mBitSize_Comp[RTC_Depth] = 24;
		if(mInternalFormat == ImageFormat_D32) mBitSize_Comp[RTC_Depth] = 32;
		// a texture is a stencil texture if its internal type has a stencil component
		if(mInternalFormat == ImageFormat_S)   mBitSize_Comp[RTC_Stencil] = 1;
		if(mInternalFormat == ImageFormat_S1)  mBitSize_Comp[RTC_Stencil] = 1;
		if(mInternalFormat == ImageFormat_S4)  mBitSize_Comp[RTC_Stencil] = 4;
		if(mInternalFormat == ImageFormat_S8)  mBitSize_Comp[RTC_Stencil] = 8;
		if(mInternalFormat == ImageFormat_S16) mBitSize_Comp[RTC_Stencil] = 16;
		// TODO: Assuming that all color channels are 8-bit if used
		uchar defaultBitSize = 8;
		switch(mInternalFormat){
			case ImageFormat_A    : 
				mBitSize_Comp[RTC_Alpha] = defaultBitSize; break;
			case ImageFormat_LA   :
			case ImageFormat_RGBA : 
				mBitSize_Comp[RTC_Alpha] = defaultBitSize; // no break!
			case ImageFormat_L    :
			case ImageFormat_RGB  :
				mBitSize_Comp[RTC_Red]   = defaultBitSize; 
				mBitSize_Comp[RTC_Green] = defaultBitSize; 
				mBitSize_Comp[RTC_Blue]  = defaultBitSize; 
				break;
			default: break; // not supported
		}
		#else
		GLenum errCode;
		errCode = glGetError();
		if(errCode != GL_NO_ERROR){
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"),
				_gputextureLogIn<<"updateResolution | Unexpected GL error:"<<getGLErrorStr(errCode));
			return;
		}
		// TODO : You would expect below to work in OpenGL 3.0, but it may (will) not. !
		GLint tmp;
		// if texture is cube-map, query one of the faces (pos-x)
		GLenum texType = mType;
		if(texType==TextureType_Cube) texType = CubeMapFace_Positive_X;
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_RED_SIZE  , &tmp);
		mBitSize_Comp[RTC_Red]   = (uchar)tmp;
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_GREEN_SIZE, &tmp);
		errCode = glGetError();
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_BLUE_SIZE , &tmp);
		errCode = glGetError();
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_ALPHA_SIZE, &tmp);
		mBitSize_Comp[RTC_Alpha] = (uchar)tmp;
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_DEPTH_SIZE, &tmp);
		mBitSize_Comp[RTC_Depth] = (uchar)tmp;
		glGetTexLevelParameteriv(texType,0,GL_TEXTURE_STENCIL_SIZE, &tmp);
		errCode = glGetError();
		if(errCode != GL_NO_ERROR){
			LOG4CPLUS_ERROR(Logger::getInstance("mtrl"),
				_gputextureLogIn<<"updateResolution | GL error:"<<getGLErrorStr(errCode));
			return;
		}
		#endif
		// logResourceParameters();
	}

}

