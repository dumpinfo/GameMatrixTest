/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/RenderTarget.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	RenderTarget::RenderTarget() 
		:mWidth(0)
		,mHeight(0)
		,mDepth(1)
		,mSamples(0)
		,mInternalFormat(ImageFormat_RGBA)
	{
		mBitSize_Comp[0] = 0;
		mBitSize_Comp[1] = 0;
		mBitSize_Comp[2] = 0;
		mBitSize_Comp[3] = 0;
		mBitSize_Comp[4] = 0;
		mBitSize_Comp[5] = 0;
	}
	ushort RenderTarget::getWidth() const {
		return mWidth;
	}
	ushort RenderTarget::getHeight() const {
		return mHeight;
	}
	ushort RenderTarget::getDepth() const {
		return mDepth;
	}
	bool RenderTarget::hasComponent(RenderTargetComp c) const{
		return (mBitSize_Comp[c]>0);
	}
	uchar RenderTarget::getResolution(RenderTargetComp c) const{
		return mBitSize_Comp[c];
	}
	ImageFormat RenderTarget::getInternalFormat() const{
		return mInternalFormat;
	}
	uchar RenderTarget::getSamples() const{
		return mSamples;
	}
	void RenderTarget::logResourceParameters() const{
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"RenderTarget Info:"
			"\n\tWidth : " << mWidth << " Height : " << mHeight <<
			"\n\tResourceSize_Red     : " << (int)mBitSize_Comp[RTC_Red] << 
			"\n\tResourceSize_Green   : " << (int)mBitSize_Comp[RTC_Green] << 
			"\n\tResourceSize_Blue    : " << (int)mBitSize_Comp[RTC_Blue] << 
			"\n\tResourceSize_Alpha   : " << (int)mBitSize_Comp[RTC_Alpha] << 
			"\n\tResourceSize_Depth   : " << (int)mBitSize_Comp[RTC_Depth] << 
			"\n\tResourceSize_Stencil : " << (int)mBitSize_Comp[RTC_Stencil] /*<< 
			"\n\tmResourceSampleCount : " << mResourceSampleCount */
			);
	}

	RenderTarget_Window::~RenderTarget_Window(){}
	RenderTarget_Window::RenderTarget_Window(){
	}
	void RenderTarget_Window::updateResolutions(){
		// empty, Render System automatically fills in values
	}
}
