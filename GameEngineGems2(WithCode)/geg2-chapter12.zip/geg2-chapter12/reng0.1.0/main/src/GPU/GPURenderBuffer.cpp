/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPURenderBuffer.h"

// binding to FBO
#include "REng/GPU/GPUFrameBuffer.h"
// need hw config
#include "REng/GPU/GPUConfig.h"

#include <assert.h>

// logging support
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng
{
	GLuint GPURenderBuffer::ActiveRenderBufferID = 0;

	const char* _gpurenderbufLogIn = "GPURenderBuffer | ";

	GPURenderBuffer::GPURenderBuffer() {
		createResource();
	}
	GPURenderBuffer::~GPURenderBuffer() {
		destroyResource();
	}

	void GPURenderBuffer::createResource(){
		if(mResourceID != 0) return;
		glGenRenderbuffers(1,&mResourceID);
		assert(mResourceID != 0);
	}

	void GPURenderBuffer::destroyResource(){
		if(mResourceID == 0) return;
		glDeleteRenderbuffers(1,&mResourceID);
	}

	void GPURenderBuffer::bindResource() const{
		// optimize
		if(mResourceID==ActiveRenderBufferID) return;
		glBindRenderbuffer(GL_RENDERBUFFER,mResourceID);
		ActiveRenderBufferID = mResourceID;
	}

	void GPURenderBuffer::unbindResource() {
		glBindRenderbuffer(GL_RENDERBUFFER,0);
		ActiveRenderBufferID = 0;
	}

	bool GPURenderBuffer::isBound(){
		return (ActiveRenderBufferID == mResourceID);
	}

	bool GPURenderBuffer::isHWBindingNull(){
		return (ActiveRenderBufferID == 0);
	}

	GLuint GPURenderBuffer::getResourceID() const{
		return mResourceID;
	}
	
	bool GPURenderBuffer::storage(ImageFormat internalFormat,unsigned short width,unsigned short height, unsigned char samples) {
		if(mResourceID==0) return false;
		Logger logger = Logger::getInstance("RSys");
		GLenum erCode;
		
		// 1. check width and height parameters
		int hwSizeLimit = GPUConfig::getSingleton().getGLMaxRenderbufferSize();
		if(width > hwSizeLimit|| height > hwSizeLimit){
			LOG4CPLUS_ERROR(logger,_gpurenderbufLogIn<<"Storage | Width["<<width<<"] or height["<<height<<"] parameter "
			                       "exceeds HW limit["<<hwSizeLimit<<"]");
			return false;
		}
		
		// 2. check samples parameter
	#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(samples>0){
			LOG4CPLUS_WARN(logger,_gpurenderbufLogIn<<"Storage | OpenGL ES does not support multisampling renderbuffers.");
			samples = 0;
		}
	#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		int hwSampleLimit = GPUConfig::getSingleton().getGLMaxSamples();
		if(samples>hwSampleLimit){
			LOG4CPLUS_WARN(logger,_gpurenderbufLogIn<<"Storage | Sample count["<<samples<<"] "
				"is clamped to the HW limits["<<hwSampleLimit<<"]");
			samples = hwSampleLimit;
		}
	#endif

		// 3. check internal format
		if(!isSupportedRenderBufferFormat(internalFormat)){
			LOG4CPLUS_ERROR(logger,_gpurenderbufLogIn<<"Storage | Unsupported internal image formet specified. ID:"<<internalFormat);
			return false;
		}

		// create the storage
		bindResource();
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			glRenderbufferStorage(GL_RENDERBUFFER,internalFormat,width,height);
		#else
			// if samples = 0, is equivalent to regular RenderbufferStorage call.
			glRenderbufferStorageMultisample(GL_RENDERBUFFER,samples,internalFormat,width,height);
		#endif

		// check OpenGL errors
		erCode = glGetError();
		if(erCode != GL_NO_ERROR){
			LOG4CPLUS_ERROR(logger,_gpurenderbufLogIn<<"Storage | GL error : " << getGLErrorStr(erCode));
			return false;
		}

		// storage is successfully updated
		mInternalFormat = internalFormat;
		mWidth = width;
		mHeight = height;

		// update hardware resource related data
		updateResolutions();

		return true;
	}

	bool GPURenderBuffer::attachToActiveFBO(FrameBufferAttachType attachType) {
		glFramebufferRenderbuffer(GPUFrameBuffer::getBindTarget(),(GLenum)attachType,GL_RENDERBUFFER,mResourceID);
#ifdef RENG_DEBUG_BUILD
		// check OpenGL Error
		GLenum glerr = glGetError();
		if(glerr != GL_NO_ERROR){
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"), 
				_gpurenderbufLogIn<<"Attaching a renderbuffer to framebuffer failed. Error: " << getGLErrorStr(glerr));
			return false;
		}
#endif

		// active FBO is not zero, so attachment succeeded
		switch(attachType){
			case FrameBufferAttachType_Depth: 
				GPUFrameBuffer::ActiveFBO->mDepthAttachment = this;
				break;
			case FrameBufferAttachType_Stencil: 
				GPUFrameBuffer::ActiveFBO->mStencilAttachment = this;
				break;
			default: {
				int offset = attachType - FrameBufferAttachType_Color0;
				GPUFrameBuffer::ActiveFBO->mColorAttachments[offset] = this;
				break;
			}
		}

		return true;
	}

	bool GPURenderBuffer::attachToActiveFBO(){
		// try to attach to depth target
		if(attachToActiveFBODepth()==true) return true;
		// try to attach to stencil target
		if(attachToActiveFBOStencil()==true) return true;
		// try to attach to color target 0
		return attachToActiveFBO(FrameBufferAttachType_Color0);
	}

	bool GPURenderBuffer::attachToActiveFBODepth(){
		if(hasComponent(RTC_Depth)==false) return false;
		return attachToActiveFBO(FrameBufferAttachType_Depth);
	}

	bool GPURenderBuffer::attachToActiveFBOStencil(){
		if(hasComponent(RTC_Stencil)==false) return false;
		return attachToActiveFBO(FrameBufferAttachType_Stencil);
	}

	void GPURenderBuffer::updateResolutions(){
		// Note: GPURenderBuffer is already bound
		GLint tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_RED_SIZE, &tmp);
		mBitSize_Comp[RTC_Red] = (uchar)tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_GREEN_SIZE, &tmp);
		mBitSize_Comp[RTC_Green] = (uchar)tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_BLUE_SIZE, &tmp);
		mBitSize_Comp[RTC_Blue] = (uchar)tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_ALPHA_SIZE, &tmp);
		mBitSize_Comp[RTC_Alpha] = (uchar)tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_DEPTH_SIZE, &tmp);
		mBitSize_Comp[RTC_Depth] = (uchar)tmp;
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_STENCIL_SIZE, &tmp);
		mBitSize_Comp[RTC_Stencil] = (uchar)tmp;
		#if RENG_GL_PLATFORM != RENG_GL_PLATFORM_ES
		glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_SAMPLES, &tmp);
		mSamples = tmp;
		#endif
//		logResourceParameters();
	}

}
