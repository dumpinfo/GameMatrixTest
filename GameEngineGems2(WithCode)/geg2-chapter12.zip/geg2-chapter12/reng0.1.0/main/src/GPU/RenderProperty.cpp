/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/RenderProperty.h"

// for accessing script parsing helpers (parse)
#include "REng/Material/MaterialScriptParser.h"

#include <assert.h>

// logging
#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	/************************************************************************/
	/* RENDER PROPERTY COMMON                                               */
	/************************************************************************/
	RenderProp::RenderProp(RenderPropertyType type) : mType(type) { ; }
	
	RenderProp* RenderProp::clone() const{ 
		assert( false ); 
		return 0; 
	}

	RenderPropertyType RenderProp::getType() const { 
		return mType; 
	}

	/************************************************************************/
	/* RENDER PROPERTY GENERIC & TEXTURE                                    */
	/************************************************************************/
	RenderProp_Generic::RenderProp_Generic(RenderPropertyType t) : RenderProp(t){ ; }

	bool RenderProp_Generic::isTracked() const{ return false; }

	void RenderProp_Generic::setTracked(bool flag) { return; }

	SamplerProp::SamplerProp(RenderPropertyType t) 
		: RenderProp(t), 
		mRequiresSycnh(false){ ; }

	bool SamplerProp::isSynchRequired() const{
		return mRequiresSycnh;
	}
	void SamplerProp::invalidate(){
		mRequiresSycnh = true;
	}
	void SamplerProp::activate(){
		mRequiresSycnh = false;
	}

	unsigned char getComponentCount(UniformType utype){
		switch(utype){
		case UniformType_Float_1:
		case UniformType_Int_1:
			return 1;
		case UniformType_Float_2:
		case UniformType_Int_2:
			return 2;
		case UniformType_Float_3:
		case UniformType_Int_3:
			return 3;
		case UniformType_Float_4:
		case UniformType_Int_4:
		case UniformType_Matrix_22:
			return 4;
		case UniformType_Matrix_33:
			return 9;
		case UniformType_Matrix_44:
			return 16;
		default:
			break;
		}
		// should not reach here
		assert(0);
		return 0;
	}

	UniformType getUniTypeFromUniAutoName(UniformAutoName name){
		if(name <UAN_Max_Matrix_44_Type) return UniformType_Matrix_44;
		if(name==UAN_Max_Matrix_44_Type) return UniformType_None;
		if(name <UAN_Max_Matrix_33_Type) return UniformType_Matrix_33;
		if(name==UAN_Max_Matrix_33_Type) return UniformType_None;
		if(name <UAN_Max_Int_1_Type)     return UniformType_Int_1;
		if(name==UAN_Max_Int_1_Type)     return UniformType_None;
		if(name <UAN_Max_Float_1_Type)   return UniformType_Float_1;
		if(name==UAN_Max_Float_1_Type)   return UniformType_None;
		if(name <UAN_Max_Float_3_Type)   return UniformType_Float_3;

		return UniformType_None;
	}

	bool convertStrToUAN(const char* str, UniformAutoName &uan){
		if(strlen(str)<5) return false;
		if(str[0]!='r')   return false;
		if(str[1]!='e')   return false;
		if(str[2]!='_')   return false;
		str+=3;
		if(!strcmp(str,"ModelMatrix")) { 
			uan = UAN_ModelMatrix; return true;
		}
		if(!strcmp(str,"ModelMatrixInverse")) { 
			uan = UAN_ModelMatrixInverse; return true; 
		}
		if(!strcmp(str,"ModelMatrixTranspose")) { 
			uan = UAN_ModelMatrixTranspose; return true; 
		}
		if(!strcmp(str,"ModelMatrixInverseTranspose")) { 
			uan = UAN_ModelMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"ViewMatrix")) { 
			uan = UAN_ViewMatrix; return true; 
		}
		if(!strcmp(str,"ViewMatrixInverse")) {
			uan = UAN_ViewMatrixInverse; return true;
		}
		if(!strcmp(str,"ViewMatrixTranspose")) { 
			uan = UAN_ViewMatrixTranspose; return true; 
		}
		if(!strcmp(str,"ViewMatrixInverseTranspose")) { 
			uan = UAN_ViewMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"ProjectionMatrix")) { 
			uan = UAN_ProjectionMatrix; return true; 
		}
		if(!strcmp(str,"ProjectionMatrixInverse")) { 
			uan = UAN_ProjectionMatrixInverse; return true; 
		}
		if(!strcmp(str,"ProjectionMatrixTranspose")) { 
			uan = UAN_ProjectionMatrixTranspose; return true; 
		}
		if(!strcmp(str,"ProjectionMatrixInverseTranspose")) { 
			uan = UAN_ProjectionMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"ModelViewMatrix")) { 
			uan = UAN_ModelViewMatrix; return true; 
		}
		if(!strcmp(str,"ModelViewMatrixInverse")) { 
			uan = UAN_ModelViewMatrixInverse; return true; 
		}
		if(!strcmp(str,"ModelViewMatrixTranspose")) { 
			uan = UAN_ModelViewMatrixTranspose; return true; 
		}
		if(!strcmp(str,"ModelViewMatrixInverseTranspose")) {
			uan = UAN_ModelViewMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"ViewProjectionMatrix")) { 
			uan = UAN_ViewProjectionMatrix; return true; 
		}
		if(!strcmp(str,"ViewProjectionMatrixInverse")) { 
			uan = UAN_ViewProjectionMatrixInverse; return true; 
		}
		if(!strcmp(str,"ViewProjectionMatrixTranspose")) {
			uan = UAN_ViewProjectionMatrixTranspose; return true; 
		}
		if(!strcmp(str,"ViewProjectionMatrixInverseTranspose")) { 
			uan = UAN_ViewProjectionMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"ModelViewProjectionMatrix")) { 
			uan = UAN_ModelViewProjectionMatrix; return true; 
		}
		if(!strcmp(str,"ModelViewProjectionMatrixInverse")) { 
			uan = UAN_ModelViewProjectionMatrixInverse; return true; 
		}
		if(!strcmp(str,"ModelViewProjectionMatrixTranspose")) { 
			uan = UAN_ModelViewProjectionMatrixTranspose; return true; 
		}
		if(!strcmp(str,"NormalMatrix")) { 
			uan = UAN_NormalMatrix; return true; 
		}
		if(!strcmp(str,"ModelViewProjectionMatrixInverseTranspose")) { 
			uan = UAN_ModelViewProjectionMatrixInverseTranspose; return true; 
		}
		if(!strcmp(str,"FPS")) { 
			uan = UAN_FPS; return true; 
		}
		if(!strcmp(str,"ViewportWidth")) { 
			uan = UAN_ViewportWidth; return true; 
		}
		if(!strcmp(str,"ViewportHeight")) { 
			uan = UAN_ViewportHeight; return true;
		}
		if(!strcmp(str,"ViewportDimentions")) { 
			uan = UAN_ViewportDimensions; return true;
		}
		if(!strcmp(str,"InvViewportWidth")) { 
			uan = UAN_InvViewportWidth; return true; 
		}
		if(!strcmp(str,"InvViewportHeight")) { 
			uan = UAN_InvViewportHeight; return true;
		}
		if(!strcmp(str,"InvViewportDimentions")) { 
			uan = UAN_InvViewportDimensions; return true;
		}
		if(!strcmp(str,"MultiViewNo")) { 
			uan = UAN_MultiViewNo; return true;
		}
		if(!strcmp(str,"RenderPassIndex")) { 
			uan = UAN_RenderPassIndex; return true;
		}
		if(!strcmp(str,"ViewPosition")) { 
			uan = UAN_ViewPosition; return true;
		}
		if(!strcmp(str,"ViewDirection")) { 
			uan = UAN_ViewDirection; return true;
		}
		if(!strcmp(str,"ViewRight")) { 
			uan = UAN_ViewRight; return true;
		}
		if(!strcmp(str,"ViewUp")) { 
			uan = UAN_ViewUp; return true;
		}
		return false;
	}

	/************************************************************************/
	/* BLEND EQUATION RENDER PROPERTY                                       */
	/************************************************************************/
	RenderProp_BlendEq::RenderProp_BlendEq(BlendEqMode rgbMode, BlendEqMode alphaMode) :
		RenderProp_Generic(RPT_blend_equation),
		mRGBMode(rgbMode),
		mAlphaMode(alphaMode)
		{ ; }

	RenderProp_BlendEq::~RenderProp_BlendEq() { ; } 

	RenderProp * RenderProp_BlendEq::clone() const {
		RenderProp_BlendEq *toRet = new RenderProp_BlendEq();
		toRet->mRGBMode   = this->mRGBMode;
		toRet->mAlphaMode = this->mAlphaMode;
		return toRet;
	}

	void RenderProp_BlendEq::activate(){
		glBlendEquationSeparate(mRGBMode, mAlphaMode);
	}
	bool RenderProp_BlendEq::parseFromFile(){
		BlendEqMode rgbMode=BlendEqMode_Func_Add, alphaMode=BlendEqMode_Func_Add;
		for(int i=0 ; i<2 ; i++){
			GLenum e;
			const char* str = MaterialScriptParser::getSingleton().readString();
			if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
				MaterialScriptParser::getSingleton().logGLConverstionError(str);
				return false;
			}
			BlendEqMode mode;
			switch(e){
			case GL_FUNC_ADD:
				mode = BlendEqMode_Func_Add;
				break;
			case GL_FUNC_SUBTRACT:
				mode = BlendEqMode_Func_Subtract;
				break;
			case GL_FUNC_REVERSE_SUBTRACT:
				mode = BlendEqMode_Func_Reverse_Subtract;
				break;
			default:
				MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"blend_equation");
				return false;
			}
			if(i==0) rgbMode = mode;
			if(i==1) alphaMode = mode;
		}
		setModes(rgbMode, alphaMode);
		return true;
	}
	void RenderProp_BlendEq::setModes(BlendEqMode  rgbMode, BlendEqMode  alphaMode){
		mRGBMode = rgbMode;
		mAlphaMode = alphaMode;
	}

	void RenderProp_BlendEq::getModes(BlendEqMode& rgbMode, BlendEqMode& alphaMode) const{
		rgbMode   = mRGBMode;
		alphaMode = mAlphaMode;
	}

	/************************************************************************/
	/* BLEND FUNCTION RENDER PROPERTY                                       */
	/************************************************************************/
	RenderProp_BlendFunc::RenderProp_BlendFunc(BlendFuncMode srcRGB, BlendFuncMode dstRGB, 
		                                        BlendFuncMode srcAlpha, BlendFuncMode dstAlpha):
		RenderProp_Generic(RPT_blend_function),
		mSrcRGB(srcRGB),
		mDstRGB(dstRGB),
		mSrcAlpha(srcAlpha),
		mDstAlpha(dstAlpha)
		{ ; }

	RenderProp_BlendFunc::~RenderProp_BlendFunc() { ; }

	void RenderProp_BlendFunc::activate(){
		glBlendFuncSeparate(mSrcRGB, mDstRGB, mSrcAlpha, mDstAlpha);
	}

	RenderProp * RenderProp_BlendFunc::clone() const{
		RenderProp_BlendFunc *toRet = new RenderProp_BlendFunc();
		toRet->mDstAlpha = this->mDstAlpha;
		toRet->mDstRGB   = this->mDstRGB;
		toRet->mSrcAlpha = this->mSrcAlpha;
		toRet->mSrcRGB = this->mSrcRGB;
		return toRet;
	}

	bool RenderProp_BlendFunc::parseFromFile(){
		BlendFuncMode srcRGB=BlendFuncMode_Zero,
						  dstRGB=BlendFuncMode_Zero,
						  srcAlpha=BlendFuncMode_Zero,
						  dstAlpha=BlendFuncMode_Zero;
		for(int i=0 ; i<4 ; i++){
			GLenum e;
			const char* str = MaterialScriptParser::getSingleton().readString();
			if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
				MaterialScriptParser::getSingleton().logGLConverstionError(str);
				return false;
			}
			BlendFuncMode func;
			switch(e){
			case GL_ZERO:
				func = BlendFuncMode_Zero;
				break;
			case GL_ONE:
				func = BlendFuncMode_One;
				break;
			case GL_SRC_COLOR:
				func = BlendFuncMode_SrcColor;
				break;
			case GL_ONE_MINUS_SRC_COLOR:
				func = BlendFuncMode_OneMinusSrcColor;
				break;
			case GL_DST_COLOR:
				func = BlendFuncMode_DstColor;
				break;
			case GL_ONE_MINUS_DST_COLOR:
				func = BlendFuncMode_OneMinusDstColor;
				break;
			case GL_SRC_ALPHA:
				func = BlendFuncMode_SrcAlpha;
				break;
			case GL_ONE_MINUS_SRC_ALPHA:
				func = BlendFuncMode_OneMinusSrcAlpha;
				break;
			case GL_DST_ALPHA:
				func = BlendFuncMode_DstAlpha;
				break;
			case GL_ONE_MINUS_DST_ALPHA:
				func = BlendFuncMode_OneMinusDstAlpha;
				break;
			case GL_CONSTANT_COLOR:
				func = BlendFuncMode_ConstantColor;
				break;
			case GL_ONE_MINUS_CONSTANT_COLOR:
				func = BlendFuncMode_OneMinusConstantColor;
				break;
			case GL_CONSTANT_ALPHA:
				func = BlendFuncMode_ConstantAlpha;
				break;
			case GL_ONE_MINUS_CONSTANT_ALPHA:
				func = BlendFuncMode_OneMinusConstantAlpha;
				break;
			case GL_SRC_ALPHA_SATURATE:
				func = BlendFuncMode_SrcAlphaSaturate;
				break;
			default:
				MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"blend_function");
				return false;
			}
			if(i==0) srcRGB   = func; 
			if(i==1) dstRGB   = func; 
			if(i==2) srcAlpha = func; 
			if(i==3) dstAlpha = func; 
		}
		setModes(srcRGB, dstRGB, srcAlpha, dstAlpha);
		return true;
	}

	void RenderProp_BlendFunc::setModes(BlendFuncMode srcRGB, BlendFuncMode dstRGB, 
										 BlendFuncMode srcAlpha, BlendFuncMode dstAlpha){
		mSrcRGB   = srcRGB;
		mDstRGB   = dstRGB;
		mSrcAlpha = srcAlpha;
		mDstAlpha = dstAlpha;
	}

	void RenderProp_BlendFunc::getModes(BlendFuncMode &srcRGB, BlendFuncMode &dstRGB, 
										 BlendFuncMode &srcAlpha, BlendFuncMode &dstAlpha) const{
		srcRGB   = mSrcRGB;
		dstRGB   = mDstRGB;
		srcAlpha = mSrcAlpha;
		dstAlpha = mDstAlpha;
	}

	/************************************************************************/
	/* STENCIL FUNCTION RENDER PROPERTY                                     */
	/************************************************************************/
	RenderProp_StencilFunc::RenderProp_StencilFunc(FaceType face, CompareFunc func, GLint reference, GLuint mask):
		RenderProp_Generic(RPT_stencil_function),
		mFace(face),
		mFunction(func),
		mReference(reference),
		mMask(mask)
		{ ; }

	RenderProp_StencilFunc::~RenderProp_StencilFunc() { ; }

	RenderProp* RenderProp_StencilFunc::clone() const {
		RenderProp_StencilFunc *toRet = new RenderProp_StencilFunc();
		toRet->mFace      = this->mFace;
		toRet->mFunction  = this->mFunction;
		toRet->mMask      = this->mMask;
		toRet->mReference = this->mReference;
		return toRet;
	}

	void RenderProp_StencilFunc::activate(){
		glStencilFuncSeparate(mFace, mFunction, mReference, mMask);
	}
	bool RenderProp_StencilFunc::parseFromFile(){
		GLenum e1, e2;
		unsigned int i1, i2;
		FaceType face;
		CompareFunc func;

		const char* str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e1)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e1){
		case GL_FRONT:          face = FaceType_Front;        break;
		case GL_BACK:           face = FaceType_Back;         break;
		case GL_FRONT_AND_BACK: face = FaceType_FrontAndBack; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"stencil_function - face");
			return false;
		}

		str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e2)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e2){
		case GL_ALWAYS:   func = CompareFunc_Always;   break;
		case GL_NEVER:    func = CompareFunc_Never;    break;
		case GL_LESS:     func = CompareFunc_Less;     break;
		case GL_LEQUAL:   func = CompareFunc_LEqual;   break;
		case GL_GREATER:  func = CompareFunc_Greater;  break;
		case GL_GEQUAL:   func = CompareFunc_GEqual;   break;
		case GL_EQUAL:    func = CompareFunc_Equal;    break;
		case GL_NOTEQUAL: func = CompareFunc_NotEqual; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"stencil_function - function");
			return false;
		}

		if(MaterialScriptParser::getSingleton().readUnsignedInt(i1)==false) {
			MaterialScriptParser::getSingleton().logUnsignedIntError();
			return false;
		}

		if(MaterialScriptParser::getSingleton().readUnsignedInt(i2)==false) {
			MaterialScriptParser::getSingleton().logUnsignedIntError();
			return false;
		}

		setProperty(face, func, i1, i2);
		return true;
	}

	void RenderProp_StencilFunc::setProperty(FaceType  face, CompareFunc  func, GLint  reference, GLuint  mask){
		mFunction = func;
		mFace = face;
		mReference = reference;
		mMask = mask;
	}
	void RenderProp_StencilFunc::getProperty(FaceType& face, CompareFunc& func, GLint& reference, GLuint& mask) const{
		face = mFace;
		func = mFunction;
		reference = mReference;
		mask = mMask;
	}
	FaceType RenderProp_StencilFunc::getFace() const{
		return mFace;
	}
	CompareFunc RenderProp_StencilFunc::getFunction() const{
		return mFunction;
	}
	GLint  RenderProp_StencilFunc::getReference() const{
		return mReference;
	}
	GLuint RenderProp_StencilFunc::getMask() const{
		return mMask;
	}

	/************************************************************************/
	/* STENCIL MASK RENDER PROPERTY                                         */
	/************************************************************************/
	RenderProp_StencilMask::RenderProp_StencilMask(FaceType face, GLuint mask):
		RenderProp_Generic(RPT_stencil_mask), 
		mFace(face),
		mMask(mask)
		{ ; }

	RenderProp_StencilMask::~RenderProp_StencilMask() { ; }

	RenderProp* RenderProp_StencilMask::clone() const {
		RenderProp_StencilMask* toRet = new RenderProp_StencilMask();
		toRet->mMask = this->mMask;
		toRet->mFace = this->mFace;
		return toRet;
	}

	void RenderProp_StencilMask::activate(){
		glStencilMaskSeparate(mFace, mMask);
	}
	bool RenderProp_StencilMask::parseFromFile(){
		GLenum e;
		unsigned int i;
		FaceType face;

		const char *str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_FRONT:          face = FaceType_Front;        break;
		case GL_BACK:           face = FaceType_Back;         break;
		case GL_FRONT_AND_BACK: face = FaceType_FrontAndBack; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"depth_function");
			return false;
		}

		if(MaterialScriptParser::getSingleton().readUnsignedInt(i)==0) {
			MaterialScriptParser::getSingleton().logUnsignedIntError();
			return false;
		}

		setFace(face);
		setMask(i);
		return true;
	}

	void RenderProp_StencilMask::setProperty(FaceType  face, GLuint  mask){
		setFace(face);
		setMask(mask);
	}
	void RenderProp_StencilMask::getProperty(FaceType& face, GLuint& mask) const{
		face = mFace;
		mask = mMask;
	}
	FaceType RenderProp_StencilMask::getFace() const{
		return mFace;
	}
	GLuint RenderProp_StencilMask::getMask() const{
		return mMask;
	}
	void RenderProp_StencilMask::setFace(FaceType face){ 
		mFace = face;
	}
	void RenderProp_StencilMask::setMask(GLuint mask){ 
		mMask = mask; 
	}

	/************************************************************************/
	/* STENCIL OPERATION RENDER PROPERTY                                    */
	/************************************************************************/
	RenderProp_StencilOp::RenderProp_StencilOp(FaceType face, OperationMode stencilFail, 
		OperationMode depthFail, OperationMode depthPass):
		RenderProp_Generic(RPT_stencil_operation), 
		mFace(face),
		mStencilFail(stencilFail),
		mDepthFail(depthFail),
		mDepthPass(depthPass)
		{ ; }
	RenderProp_StencilOp::~RenderProp_StencilOp() { ; }

	RenderProp* RenderProp_StencilOp::clone() const {
		RenderProp_StencilOp* toRet = new RenderProp_StencilOp();
		toRet->mDepthFail   = this->mDepthFail;
		toRet->mDepthPass   = this->mDepthPass;
		toRet->mFace        = this->mFace;
		toRet->mStencilFail = this->mStencilFail;
		return toRet;
	}

	void RenderProp_StencilOp::activate(){
		glStencilOpSeparate(mFace, mStencilFail, mDepthFail, mDepthPass);
	}
	void RenderProp_StencilOp::deactivate(){
		glStencilOpSeparate(mFace, GL_KEEP, GL_KEEP, GL_KEEP);
	}

	bool RenderProp_StencilOp::parseFromFile(){
		GLenum e;
		const char* str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}

		FaceType face;
		switch(e){
		case GL_FRONT:          face = FaceType_Front;        break;
		case GL_BACK:           face = FaceType_Back;         break;
		case GL_FRONT_AND_BACK: face = FaceType_FrontAndBack; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"stencil_operation");
			return false;
		}

		OperationMode op[3];

		for(int i=0 ; i<3 ; i++){
			str = MaterialScriptParser::getSingleton().readString();
			if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
				MaterialScriptParser::getSingleton().logGLConverstionError(str);
				return false;
			}
			switch(e){
			case GL_KEEP:      op[i] = OperationMode_Keep;      break;
			case GL_ZERO:      op[i] = OperationMode_Zero;      break;
			case GL_REPLACE:   op[i] = OperationMode_Replace;   break;
			case GL_INCR:      op[i] = OperationMode_Incr;      break;
			case GL_INCR_WRAP: op[i] = OperationMode_Inc_Wrap;  break;
			case GL_DECR:      op[i] = OperationMode_Decr;      break;
			case GL_DECR_WRAP: op[i] = OperationMode_Decr_Wrap; break;
			case GL_INVERT:    op[i] = OperationMode_Invert;    break;
				break;
			default:
				MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"stencil_operation");
				return false;
			}
		}

		setProperty(face, op[0], op[1], op[2]);
		return true;
	}

	void RenderProp_StencilOp::setProperty(FaceType  face, OperationMode  stencilFail, 
		OperationMode  depthFail, OperationMode  depthPass){
			mFace = face;
			mStencilFail = stencilFail;
			mDepthPass = depthPass;
			mDepthFail = depthFail;
	}
	void RenderProp_StencilOp::getProperty(FaceType& face, OperationMode& stencilFail, 
		OperationMode& depthFail, OperationMode& depthPass) const{
			face = mFace;
			stencilFail = mStencilFail;
			depthPass = mDepthPass;
			depthFail = mDepthFail;
	}
	FaceType RenderProp_StencilOp::getFace() const{
		return mFace;
	}
	OperationMode RenderProp_StencilOp::getStencilFail() const{
		return mStencilFail;
	}
	OperationMode RenderProp_StencilOp::getDepthFail() const{
		return mDepthFail;
	}
	OperationMode RenderProp_StencilOp::getDepthPass() const{
		return mDepthPass;
	}

	/************************************************************************/
	/* DEPTH FUNCTION RENDER PROPERTY                                       */
	/************************************************************************/
	RenderProp_DepthFunc::RenderProp_DepthFunc(CompareFunc func):
		RenderProp_Generic(RPT_depth_function),
		mFunction(func)
		{ ; }

	RenderProp_DepthFunc::~RenderProp_DepthFunc() { ; }

	RenderProp* RenderProp_DepthFunc::clone() const {
		RenderProp_DepthFunc* toRet = new RenderProp_DepthFunc();
		toRet->mFunction = this->mFunction;
		return toRet;
	}

	void RenderProp_DepthFunc::setDefault(){
		glDepthFunc(GL_LEQUAL);
	}
	void RenderProp_DepthFunc::activate(){
		#ifndef _DO_NOT_TRACK_DEPTHFUNC
		if(mFunction == GL_LEQUAL) return;
		#endif
		glDepthFunc(mFunction);
	}
	void RenderProp_DepthFunc::deactivate(){ 
		#ifndef _DO_NOT_TRACK_DEPTHFUNC
		if(mFunction == GL_LEQUAL) return;
		#endif
		glDepthFunc(GL_LEQUAL); 
	}

	bool RenderProp_DepthFunc::parseFromFile(){
		GLenum e;
		const char *str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		CompareFunc func;
		switch(e){
		case GL_ALWAYS:   func = CompareFunc_Always;   break;
		case GL_NEVER:    func = CompareFunc_Never;    break;
		case GL_LESS:     func = CompareFunc_Less;     break;
		case GL_LEQUAL:   func = CompareFunc_LEqual;   break;
		case GL_GREATER:  func = CompareFunc_Greater;  break;
		case GL_GEQUAL:   func = CompareFunc_GEqual;   break;
		case GL_EQUAL:    func = CompareFunc_Equal;    break;
		case GL_NOTEQUAL: func = CompareFunc_NotEqual; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"depth_function");
			return false;
		}

		setFunction(func);
		return true;
	}

	void RenderProp_DepthFunc::setFunction(CompareFunc func){
		mFunction = func;
	}
	CompareFunc RenderProp_DepthFunc::getFunction(void) const{ return mFunction; }

	#ifndef _DO_NOT_TRACK_DEPTHFUNC
	bool RenderProp_DepthFunc::mIsTracked = true;
	bool RenderProp_DepthFunc::isTracked() const{ return mIsTracked; }
	void RenderProp_DepthFunc::setTracked(bool flag){ mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* DEPTH MASK RENDER PROPERTY                                           */
	/************************************************************************/
	RenderProp_DepthMask::RenderProp_DepthMask(bool flag):
		RenderProp_Generic(RPT_depth_mask) 
	{ 
		mFlag = (flag ? GL_TRUE : GL_FALSE);
	}
	RenderProp_DepthMask::~RenderProp_DepthMask() { ; }

	RenderProp* RenderProp_DepthMask::clone() const {
		RenderProp_DepthMask *toRet = new RenderProp_DepthMask();
		toRet->mFlag = this->mFlag;
		return toRet;
	}

	void RenderProp_DepthMask::setDefault(){
		glDepthMask(GL_TRUE);
	}
	void RenderProp_DepthMask::activate() {
		#ifndef _DO_NOT_TRACK_DEPTHMASK
		if(mIsTracked){ if(mFlag == GL_TRUE) return; }
		#endif
		glDepthMask(mFlag); 
	}
	void RenderProp_DepthMask::deactivate(){ 
		#ifndef _DO_NOT_TRACK_DEPTHMASK
		if(mIsTracked){ if(mFlag == GL_TRUE) return; }
		#endif
		glDepthMask(GL_TRUE);
	}

	bool RenderProp_DepthMask::parseFromFile(){
		bool enabled;
		if(MaterialScriptParser::getSingleton().readOnOff(enabled)==false) {
			return false;
		}
		if(enabled) mFlag = GL_TRUE; else mFlag = GL_FALSE;
		return true;
	}
	void RenderProp_DepthMask::setFlag(bool flag){
		mFlag = (flag ? GL_TRUE : GL_FALSE);
	}
	bool RenderProp_DepthMask::getFlag(void) const{ 
		return (mFlag==GL_TRUE); 
	}

	#ifndef _DO_NOT_TRACK_DEPTHMASK
	bool RenderProp_DepthMask::mIsTracked = true;
	bool RenderProp_DepthMask::isTracked() const{ return mIsTracked; }
	void RenderProp_DepthMask::setTracked(bool flag){ mIsTracked = flag; } 
	#endif

	/************************************************************************/
	/* COLOR MASK RENDER PROPERTY                                           */
	/************************************************************************/
	RenderProp_ColorMask::RenderProp_ColorMask(bool red, bool green, bool blue, bool alpha):
		RenderProp_Generic(RPT_color_mask)
	{
		setFlags(red,green,blue,alpha);
	}
	RenderProp_ColorMask::~RenderProp_ColorMask() { ; }

	RenderProp* RenderProp_ColorMask::clone() const {
		RenderProp_ColorMask* toRet = new RenderProp_ColorMask();
		toRet->mFlags = this->mFlags;
		return toRet;
	}

	void RenderProp_ColorMask::setDefault(){
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	}
	void RenderProp_ColorMask::activate() {
		#ifndef _DO_NOT_TRACK_COLORMASK
		if(mIsTracked){
			if(mFlags == (ColorFlagRed | ColorFlagGreen | ColorFlagBlue | ColorFlagAlpha)) return;
		}
		#endif
		glColorMask( mFlags&ColorFlagRed, mFlags&ColorFlagGreen, mFlags&ColorFlagBlue, mFlags&ColorFlagAlpha);
	}
	void RenderProp_ColorMask::deactivate(){ 
		#ifndef _DO_NOT_TRACK_COLORMASK
		if(mIsTracked){
			if(mFlags == (ColorFlagRed | ColorFlagGreen | ColorFlagBlue | ColorFlagAlpha)) return;
		}
		#endif
		glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	}

	bool RenderProp_ColorMask::parseFromFile(){
		bool r=0,g=0,b=0,a=0;
		for(int i=0 ; i<4 ; i++){
			bool tmp;
			if(MaterialScriptParser::getSingleton().readOnOff(tmp)==false) {
				return false;
			}
			if(i==0) r = (tmp!=0);
			if(i==1) g = (tmp!=0);
			if(i==2) b = (tmp!=0);
			if(i==3) a = (tmp!=0);
		}
		setFlags(r,g,b,a);
		return true;
	}
	void RenderProp_ColorMask::setFlags(bool red, bool green, bool blue, bool alpha){
		mFlags = 0;
		if(red)   mFlags = mFlags | ColorFlagRed;
		if(green) mFlags = mFlags | ColorFlagGreen;
		if(blue)  mFlags = mFlags | ColorFlagBlue;
		if(alpha) mFlags = mFlags | ColorFlagAlpha;
	}
	void RenderProp_ColorMask::getFlags(bool& red, bool& green, bool& blue, bool& alpha) const{ 
		red   = (mFlags & ColorFlagRed  ) != 0;
		green = (mFlags & ColorFlagGreen) != 0;
		blue  = (mFlags & ColorFlagBlue ) != 0;
		alpha = (mFlags & ColorFlagAlpha) != 0;
	}

	#ifndef _DO_NOT_TRACK_COLORMASK
	bool RenderProp_ColorMask::mIsTracked = true;
	bool RenderProp_ColorMask::isTracked() const{ return mIsTracked; }
	void RenderProp_ColorMask::setTracked(bool flag){ mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* FACE FRONT RENDER PROPERTY                                           */
	/************************************************************************/
	RenderProp_FrontFace::RenderProp_FrontFace(FaceOrientation mode) :
		RenderProp_Generic(RPT_front_face),
		mMode(mode)
		{ ;}
	RenderProp_FrontFace::~RenderProp_FrontFace() { ; }

	RenderProp* RenderProp_FrontFace::clone() const {
		RenderProp_FrontFace *toRet = new RenderProp_FrontFace();
		toRet->mMode = this->mMode;
		return toRet;
	}

	void RenderProp_FrontFace::setDefault(){
		glFrontFace(FaceOrientation_CCW);
	}
	void RenderProp_FrontFace::activate(){ 
		#ifndef _DO_NOT_TRACK_FRONTFACE
		if(mIsTracked){ if(mMode == FaceOrientation_CCW) return; }
		#endif
		glFrontFace(mMode);  
	}
	void RenderProp_FrontFace::deactivate() { 
		#ifndef _DO_NOT_TRACK_FRONTFACE
		if(mIsTracked){ if(mMode == FaceOrientation_CCW) return; }
		#endif
		glFrontFace(FaceOrientation_CCW); 
	}
	bool RenderProp_FrontFace::parseFromFile(){
		GLenum e;
		const char *str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_CW:   setMode(FaceOrientation_CW);  break;
		case GL_CCW:  setMode(FaceOrientation_CCW); break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"front face");
			return false;
		}
		return true;
	}

	void RenderProp_FrontFace::setMode(FaceOrientation mode){
		mMode = mode;
	}
	FaceOrientation RenderProp_FrontFace::getMode(void) const{ 
		return mMode; 
	}

	#ifndef _DO_NOT_TRACK_FRONTFACE
	bool RenderProp_FrontFace::mIsTracked = true;
	bool RenderProp_FrontFace::isTracked() const { return mIsTracked; }
	void RenderProp_FrontFace::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* CULL FACE RENDER PROPERTY                                            */
	/************************************************************************/
	RenderProp_CullFace::RenderProp_CullFace(FaceType mode):
		RenderProp_Generic(RPT_cull_face), 
		mMode(mode)
		{ ; }
	RenderProp_CullFace::~RenderProp_CullFace() { ; }

	RenderProp* RenderProp_CullFace::clone() const {
		RenderProp_CullFace* toRet = new RenderProp_CullFace();
		toRet->mMode = this->mMode;
		return toRet;
	}

	void RenderProp_CullFace::setDefault(){
		glEnable(GL_CULL_FACE);
		glCullFace(GL_BACK);
	}
	void RenderProp_CullFace::activate() { 
		#ifndef _DO_NOT_TRACK_CULLFACE
		if(mIsTracked){ if(mMode == FaceType_Back) return; }
		#endif
		if(mMode == FaceType_None)
			glDisable(GL_CULL_FACE);
		else
			glCullFace(mMode);
	}
	void RenderProp_CullFace::deactivate() { 
		#ifndef _DO_NOT_TRACK_CULLFACE
		if(mIsTracked){ if(mMode == FaceType_Back) return; }
		#endif
		if(mMode == FaceType_None)
			glEnable(GL_CULL_FACE);
		else
			glCullFace(FaceType_Back);
	}
	bool RenderProp_CullFace::parseFromFile(){
		GLenum e;
		const char *str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_FRONT:           setMode(FaceType_Front);        break;
		case GL_BACK:            setMode(FaceType_Back);         break;
		case GL_FRONT_AND_BACK:  setMode(FaceType_FrontAndBack); break;
		case GL_NONE:            setMode(FaceType_None);         break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"cull face");
			return false;
		}

		return true;
	}
	void RenderProp_CullFace::setMode(FaceType mode){
		mMode = mode;
	}
	FaceType RenderProp_CullFace::getMode(void) const{ 
		return mMode; 
	}

	#ifndef _DO_NOT_TRACK_CULLFACE
	bool RenderProp_CullFace::mIsTracked = true;
	bool RenderProp_CullFace::isTracked() const { return mIsTracked; }
	void RenderProp_CullFace::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* LINE WIDTH RENDER PROPERTY                                           */
	/************************************************************************/
	RenderProp_LineWidth::RenderProp_LineWidth(float width):
		RenderProp_Generic(RPT_line_width), 
		mWidth(GLfloat(width)) 
		{ ; }
	RenderProp_LineWidth::~RenderProp_LineWidth() { ; }

	RenderProp* RenderProp_LineWidth::clone() const {
		RenderProp_LineWidth *toRet = new RenderProp_LineWidth();
		toRet->mWidth = this->mWidth;
		return toRet;
	}

	void RenderProp_LineWidth::setDefault(){
		glLineWidth(GLfloat(1.0f));
	}
	void RenderProp_LineWidth::activate() { 
		glLineWidth(mWidth);
	}
	void RenderProp_LineWidth::deactivate() { 
		glLineWidth(1.0f);
	}
	bool RenderProp_LineWidth::parseFromFile(){
		float width;
		if(false==MaterialScriptParser::getSingleton().readFloat(width)){
			MaterialScriptParser::getSingleton().logDefaultError("LineWidth: float expected.");
			return false;
		}
		setWidth(width);
		return true;
	}
	void RenderProp_LineWidth::setWidth(float width){
		mWidth = GLfloat(width);
	}
	float RenderProp_LineWidth::getWidth(void) const{ 
		return mWidth; 
	}

	#ifndef _DO_NOT_TRACK_LINEWIDTH
	bool RenderProp_LineWidth::mIsTracked = true;
	bool RenderProp_LineWidth::isTracked() const { return mIsTracked; }
	void RenderProp_LineWidth::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* POLYGON MODE RENDER PROPERTY                                         */
	/************************************************************************/
	RenderProp_PolyMode::RenderProp_PolyMode() 
	:	RenderProp_Generic(RPT_poly_mode), 
		mFaceMode(FaceType_Front), 
		mPolyMode(PolygonMode_Fill){ ; }
	RenderProp_PolyMode::~RenderProp_PolyMode() { ; }

	RenderProp* RenderProp_PolyMode::clone() const {
		RenderProp_PolyMode* toRet = new RenderProp_PolyMode();
		toRet->mPolyMode = this->mPolyMode;
		toRet->mFaceMode = this->mFaceMode;
		return toRet;
	}

	void RenderProp_PolyMode::setDefault(){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		return;
		#else
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		#endif
	}
	void RenderProp_PolyMode::activate() { 
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		return;
		#else
			#ifndef _DO_NOT_TRACK_POLYMODE
			if(mIsTracked){ if(mPolyMode == PolygonMode_Fill) return; }
			#endif
			glPolygonMode(mFaceMode, mPolyMode);
		#endif
	}
	void RenderProp_PolyMode::deactivate() { 
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		return;
		#else
			#ifndef _DO_NOT_TRACK_POLYMODE
			if(mIsTracked){ if(mPolyMode == PolygonMode_Fill) return; }
			#endif
			glPolygonMode(mFaceMode, PolygonMode_Fill);
		#endif
	}
	bool RenderProp_PolyMode::parseFromFile(){
		GLenum e;
		const char *str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_FRONT:           setFaceMode(FaceType_Front);        break;
		case GL_BACK:            setFaceMode(FaceType_Back);         break;
		case GL_FRONT_AND_BACK:  setFaceMode(FaceType_FrontAndBack); break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"polygon mode");
			return false;
		}

		str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_POINT:   setPolyMode(PolygonMode_Point); break;
		case GL_LINE:    setPolyMode(PolygonMode_Line);  break;
		case GL_FILL:    setPolyMode(PolygonMode_Fill);  break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"polygon mode");
			return false;
		}

		return true;
	}
	void RenderProp_PolyMode::setFaceMode(FaceType mode){
		mFaceMode = mode;
	}
	void RenderProp_PolyMode::setPolyMode(PolygonMode mode){
		mPolyMode = mode;
	}
	FaceType RenderProp_PolyMode::getFaceMode(void) const{ 
		return mFaceMode; 
	}
	PolygonMode RenderProp_PolyMode::getPolyMode(void) const{ 
		return mPolyMode; 
	}

	#ifndef _DO_NOT_TRACK_POLYMODE
	bool RenderProp_PolyMode::mIsTracked = true;
	bool RenderProp_PolyMode::isTracked() const { return mIsTracked; }
	void RenderProp_PolyMode::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* BLEND RENDER PROPERTY                                                */
	/************************************************************************/
	RenderProp_Blending::RenderProp_Blending(bool flag) :
		RenderProp_Generic(RPT_blending), 
		mEnabled(flag)
		{ ; }
	RenderProp_Blending::~RenderProp_Blending() { ; }

	RenderProp* RenderProp_Blending::clone() const {
		RenderProp_Blending* toRet = new RenderProp_Blending();
		toRet->mEnabled = this->mEnabled;
		return toRet;
	}

	void RenderProp_Blending::setDefault(){
		glDisable(GL_BLEND);
	}
	void RenderProp_Blending::activate() {
		#ifndef _DO_NOT_TRACK_BLENDING
		if(mIsTracked){ if(mEnabled == false) return; }
		#endif
		if(mEnabled) glEnable(GL_BLEND);
		else         glDisable(GL_BLEND);
	}
	void RenderProp_Blending::deactivate(){
		#ifndef _DO_NOT_TRACK_BLENDING
		if(mIsTracked){ if(mEnabled == false) return; }
		#endif
		glDisable(GL_BLEND);
	}
	bool RenderProp_Blending::parseFromFile(){
		if(MaterialScriptParser::getSingleton().readOnOff(mEnabled)==false) {
			return false;
		}
		return true;
	}
	void RenderProp_Blending::setEnabled(bool en){ 
		mEnabled = en;
	}
	bool RenderProp_Blending::getEnabled(void) const { 
		return mEnabled; 
	}
	#ifndef _DO_NOT_TRACK_BLENDING
	bool RenderProp_Blending::mIsTracked = true;
	bool RenderProp_Blending::isTracked() const { return mIsTracked; }
	void RenderProp_Blending::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* DEPTH TEST RENDER PROPERTY                                           */
	/************************************************************************/
	RenderProp_DepthTest::RenderProp_DepthTest(bool flag) :
		RenderProp_Generic(RPT_depth_test), 
		mEnabled(flag)
		{ ; }
	RenderProp_DepthTest::~RenderProp_DepthTest() { ; }

	RenderProp* RenderProp_DepthTest::clone() const {
		RenderProp_DepthTest* toRet = new RenderProp_DepthTest();
		toRet->mEnabled = this->mEnabled;
		return toRet;
	}

	void RenderProp_DepthTest::setDefault(){
		glEnable(GL_DEPTH_TEST);
	}

	void RenderProp_DepthTest::activate() {
		#ifndef _DO_NOT_TRACK_DEPTHTEST
		if(mIsTracked){ if(mEnabled == true) return; }
		#endif
		if(mEnabled) glEnable(GL_DEPTH_TEST);
		else         glDisable(GL_DEPTH_TEST);
	}
	void RenderProp_DepthTest::deactivate(){
		#ifndef _DO_NOT_TRACK_DEPTHTEST
		if(mIsTracked){ if(mEnabled == true) return; }
		#endif
		glEnable(GL_DEPTH_TEST);
	}
	bool RenderProp_DepthTest::parseFromFile(){
		if(MaterialScriptParser::getSingleton().readOnOff(mEnabled)==false) {
			return false;
		}
		return true;
	}
	void RenderProp_DepthTest::setEnabled(bool en){ 
		mEnabled = en;
	}
	bool RenderProp_DepthTest::getEnabled(void) const { 
		return mEnabled; 
	}
	#ifndef _DO_NOT_TRACK_DEPTHTEST
	bool RenderProp_DepthTest::mIsTracked = true;
	bool RenderProp_DepthTest::isTracked() const { return mIsTracked; }
	void RenderProp_DepthTest::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* STENCIL TEST RENDER PROPERTY                                         */
	/************************************************************************/
	RenderProp_StencilTest::RenderProp_StencilTest(bool flag) :
		RenderProp_Generic(RPT_stencil_test), 
		mEnabled(flag)
		{ ; }
	RenderProp_StencilTest::~RenderProp_StencilTest() { ; }

	RenderProp* RenderProp_StencilTest::clone() const {
		RenderProp_StencilTest* toRet = new RenderProp_StencilTest();
		toRet->mEnabled = this->mEnabled;
		return toRet;
	}

	void RenderProp_StencilTest::setDefault(){
		glEnable(GL_STENCIL_TEST);
		glDisable(GL_STENCIL_TEST);
	}
	void RenderProp_StencilTest::activate() {
		#ifndef _DO_NOT_TRACK_STENCILTEST
		if(mIsTracked){ if(mEnabled == false) return; }
		#endif
		if(mEnabled) glEnable(GL_STENCIL_TEST);
		else         glDisable(GL_STENCIL_TEST);
	}
	void RenderProp_StencilTest::deactivate(){
		#ifndef _DO_NOT_TRACK_STENCILTEST
		if(mIsTracked){ if(mEnabled == false) return; }
		#endif
		glDisable(GL_STENCIL_TEST);
	}
	bool RenderProp_StencilTest::parseFromFile(){
		if(MaterialScriptParser::getSingleton().readOnOff(mEnabled)==false) {
			return false;
		}
		return true;
	}
	void RenderProp_StencilTest::setEnabled(bool en){ 
		mEnabled = en;
	}
	bool RenderProp_StencilTest::getEnabled(void) const { 
		return mEnabled; 
	}
	#ifndef _DO_NOT_TRACK_STENCILTEST
	bool RenderProp_StencilTest::mIsTracked = true;
	bool RenderProp_StencilTest::isTracked() const { return mIsTracked; }
	void RenderProp_StencilTest::setTracked(bool flag) { mIsTracked = flag; }
	#endif

	/************************************************************************/
	/* UNIFORM RENDER PROPERTY                                              */
	/************************************************************************/
	RenderProp_Uniform::RenderProp_Uniform(const std::string& name, UniformType type, UniformAutoName autoname )
	:	RenderProp(RPT_uniform), 
		mUniformName(name),
		mUniformType(type),
		mUniformData(0),
		mAutoName(autoname),
		mGLUniform(0), 
		mSynchRequired(false) {
			if(autoname != UAN_None)
				mUniformType = getUniTypeFromUniAutoName(autoname);
			// 7.1 create a space for uniform data
			size_t dataSize = getDataSize();
			mUniformData = malloc(dataSize);
	}
	RenderProp_Uniform::~RenderProp_Uniform() { 
		// destroy OpenGL uniform interface
		if(mGLUniform) delete mGLUniform;
		if(mUniformData) free(mUniformData);
		mGLUniform = 0;
	}
	RenderProp* RenderProp_Uniform::clone() const{
		RenderProp_Uniform *toRet = new RenderProp_Uniform(mUniformName, mUniformType, mAutoName);
		this->copyData(*toRet);
		return toRet;
	}

	UniformAutoName RenderProp_Uniform::getAutoName() const{
		return mAutoName;
	}
	GLint RenderProp_Uniform::getLocation() const{
		if (mGLUniform==0) return -1;
		return mGLUniform->getResourceLocation();
	}
	void RenderProp_Uniform::activate() {
		if(mGLUniform == 0 ) return;
		const GLfloat *floatData = (const GLfloat*)mUniformData;
		const GLint   *intData   = (const GLint*)mUniformData;
		switch(mUniformType){
		case UniformType_Float_1:
			mGLUniform->setFloat(floatData[0]);
			break;
		case UniformType_Float_2:
			mGLUniform->setVector2(floatData[0],floatData[1]);
			break;
		case UniformType_Float_3:
			mGLUniform->setVector3(floatData[0],floatData[1], floatData[2]);
			break;
		case UniformType_Float_4:
			mGLUniform->setVector4(floatData[0],floatData[1], floatData[2], floatData[3]);
			break;
		case UniformType_Matrix_22:
			mGLUniform->setMatrix22((const GLfloat*)mUniformData);
			break;
		case UniformType_Matrix_33:
			mGLUniform->setMatrix33((const GLfloat*)mUniformData); 
			break;
		case UniformType_Matrix_44:
			mGLUniform->setMatrix44((const GLfloat*)mUniformData);
			break;
		case UniformType_Int_1:
			mGLUniform->setInteger(intData[0]);
			break;
		case UniformType_Int_2:
			mGLUniform->setVector2i(intData[0],intData[1]);
			break;
		case UniformType_Int_3:
			mGLUniform->setVector3i(intData[0],intData[1],intData[2]);
			break;
		case UniformType_Int_4:
			mGLUniform->setVector4i(intData[0],intData[1],intData[2],intData[3]);
			break;
		default:
			break;
		}
		mSynchRequired = false;
	}

	size_t RenderProp_Uniform::getDataSize() const{
		// 7.1 create a space for uniform data
		size_t dataSize=0;
		switch(mUniformType){
		case UniformType_Float_1:   dataSize =  1*sizeof(GLfloat); break;
		case UniformType_Float_2:   dataSize =  2*sizeof(GLfloat); break;
		case UniformType_Float_3:   dataSize =  3*sizeof(GLfloat); break;
		case UniformType_Float_4:   dataSize =  4*sizeof(GLfloat); break;
		case UniformType_Int_1:     dataSize =  1*sizeof(GLint);   break;
		case UniformType_Int_2:     dataSize =  2*sizeof(GLint);   break;
		case UniformType_Int_3:     dataSize =  3*sizeof(GLint);   break;
		case UniformType_Int_4:     dataSize =  4*sizeof(GLint);   break;
		case UniformType_Matrix_22: dataSize =  4*sizeof(GLfloat); break;
		case UniformType_Matrix_33: dataSize =  9*sizeof(GLfloat); break;
		case UniformType_Matrix_44: dataSize = 16*sizeof(GLfloat); break;
		default: assert(0); break;
		}
		return dataSize;
	}

	bool RenderProp_Uniform::parseFromFile(){
		// 7.2 read list of uniform data
		uchar loopLimit = getComponentCount(mUniformType);

		float dataFloat;
		int dataInt;
		switch(mUniformType){
			// float types
		case UniformType_Float_1:
		case UniformType_Float_2:
		case UniformType_Float_3:
		case UniformType_Float_4:
		case UniformType_Matrix_22:
		case UniformType_Matrix_33:
		case UniformType_Matrix_44:
			for(uchar i=0 ; i<loopLimit;++i){
				if(false==MaterialScriptParser::getSingleton().readFloat(dataFloat)){
					MaterialScriptParser::getSingleton().logUniformDataError();
					return false;
				}
				setDataAtIndex(i,dataFloat);
			}
			break;
			// integer types
		case UniformType_Int_1:
		case UniformType_Int_2:
		case UniformType_Int_3:
		case UniformType_Int_4:
			for(uchar i=0 ; i<loopLimit;++i){
				if(false==MaterialScriptParser::getSingleton().readInt(dataInt)){
					MaterialScriptParser::getSingleton().logUniformDataError();
					return false;
				}
				setDataAtIndex(i,dataInt);
			}
			break;
		default: break;
		}
		return true;
	}

	const std::string& RenderProp_Uniform::getName(void) const { 
		return mUniformName; 
	}
	UniformType RenderProp_Uniform::getType(void) const { 
		return mUniformType; 
	}
	bool RenderProp_Uniform::requiresSynch(void) const  { 
		return mSynchRequired; 
	}
	bool RenderProp_Uniform::isBoundToProgram() const{
		return mGLUniform!=0;
	}

	void RenderProp_Uniform::setDataAtIndex(uchar index, GLfloat data){
		switch(mUniformType){
		case UniformType_Int_1:
		case UniformType_Int_2:
		case UniformType_Int_3:
		case UniformType_Int_4:
			LOG4CPLUS_WARN(Logger::getInstance("mtrl"),"Uniform["<<mUniformName<<"] Cannot update data, expected float type uniform");
			return;
		case UniformType_Float_1:    if(index > 0)  { return; } break;
		case UniformType_Float_2:    if(index > 1)  { return; } break;
		case UniformType_Float_3:    if(index > 2)  { return; } break;
		case UniformType_Float_4:    if(index > 3)  { return; } break;
		case UniformType_Matrix_22:  if(index > 3)  { return; } break;
		case UniformType_Matrix_33:  if(index > 8)  { return; } break;
		case UniformType_Matrix_44:  if(index > 15) { return; } break;
		default: assert(0); break;
		}

		((GLfloat*)mUniformData)[index] = data;
		mSynchRequired = true;
	}

	void RenderProp_Uniform::setDataAtIndex(uchar index, GLint data){
		switch(mUniformType){
		case UniformType_Float_1:
		case UniformType_Float_2:
		case UniformType_Float_3:
		case UniformType_Float_4:
		case UniformType_Matrix_22:
		case UniformType_Matrix_33:
		case UniformType_Matrix_44:
			LOG4CPLUS_WARN(Logger::getInstance("mtrl"),"Uniform["<<mUniformName<<"] Cannot update data, expected integer type uniform");
			return;
		case UniformType_Int_1: if(index > 0) { return; } break;
		case UniformType_Int_2: if(index > 1) { return; } break;
		case UniformType_Int_3: if(index > 2) { return; } break;
		case UniformType_Int_4: if(index > 3) { return; } break;
		default: assert(0); break;
		}

		((GLint*)mUniformData)[index] = data;
		mSynchRequired = true;
	}

	void RenderProp_Uniform::setData(const void* storage, size_t storageSize){
		if(storage==0) return;
		memcpy(mUniformData,storage,storageSize);
		mSynchRequired = true;
	}

	void RenderProp_Uniform::copyData(RenderProp_Uniform& copyTo) const{
		if(this->mUniformType != copyTo.getType()) return;
		copyTo.setData(mUniformData,getDataSize());
	}

	bool RenderProp_Uniform::bindToProgram(const GPUProgram& program){
		mGLUniform = new GPUUniform(program,mUniformName.c_str());
		if(!mGLUniform->isValid()){
			delete mGLUniform;
			mGLUniform = 0;
			return false;
		}
		return true;
	}

	/************************************************************************/
	/* TEXTURE MIN FILTER PROPERTY                                          */
	/************************************************************************/
	SamplerProp_MinFilter::SamplerProp_MinFilter()
	:	SamplerProp(RPT_min_filter), 
		mMode(MinFilter_Nearest) { ; }
	SamplerProp_MinFilter::~SamplerProp_MinFilter() { ; }

	bool SamplerProp_MinFilter::parseFromFile(){
		GLenum e;
		const char* str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		MinFilter filt;
		switch(e){
		case GL_NEAREST: 
			filt = MinFilter_Nearest; break;
		case GL_LINEAR: 
			filt = MinFilter_Linear; break;
		case GL_NEAREST_MIPMAP_NEAREST: 
			filt = MinFilter_NearestMipmapNearest; break;
		case GL_LINEAR_MIPMAP_LINEAR: 
			filt = MinFilter_LinearMipmapLinear; break;
		case GL_NEAREST_MIPMAP_LINEAR: 
			filt = MinFilter_NearestMipmapLinear; break;
		case GL_LINEAR_MIPMAP_NEAREST: 
			filt = MinFilter_LinearMipmapNearest; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"min filter type");
			return false;
		}
		setMode(filt);
		return true;
	}
	void SamplerProp_MinFilter::setMode(MinFilter mode){
		mMode = mode;
		mRequiresSycnh = true;
	}
	MinFilter SamplerProp_MinFilter::getMode() const{
		return mMode;
	}

	/************************************************************************/
	/* TEXTURE MAG FILTER PROPERTY                                          */
	/************************************************************************/
	SamplerProp_MagFilter::SamplerProp_MagFilter()
	:	SamplerProp(RPT_mag_filter), 
		mMode(MagFilter_Nearest) { ; }
	SamplerProp_MagFilter::~SamplerProp_MagFilter() { ; }

	bool SamplerProp_MagFilter::parseFromFile(){
		GLenum e;
		const char* str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		MagFilter filt;
		switch(e){
		case GL_NEAREST:
			filt = MagFilter_Nearest; break;
		case GL_LINEAR:
			filt = MagFilter_Linear; break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"mag filter type");
			return false;
		}
		setMode(filt);
		return true;
	}
	void SamplerProp_MagFilter::setMode(MagFilter mode){
//		if(mode == mMode) return;
		mMode = mode;
		mRequiresSycnh = true;
	}
	MagFilter SamplerProp_MagFilter::getMode() const{
		return mMode;
	}

	/************************************************************************/
	/* TEXTURE WRAP MODE PROPERTY                                           */
	/************************************************************************/
	SamplerProp_WrapMode::SamplerProp_WrapMode()
	:	SamplerProp(RPT_wrap_mode),
		mAxis(WrapAxis_S), 
		mWrapMode(WrapMode_ClampToEdge)
		{ ; }
	SamplerProp_WrapMode::~SamplerProp_WrapMode() { ; }

	bool SamplerProp_WrapMode::parseFromFile(){
		// 1. read axis (s, t or r)
		const char* str = MaterialScriptParser::getSingleton().readString();
		if(!strcmp(str,"AXIS_S")){
			setAxis(WrapAxis_S);
		} else if(!strcmp(str,"AXIS_T")){
			setAxis(WrapAxis_T);
		} else if(!strcmp(str,"AXIS_R")){
			setAxis(WrapAxis_R);
		} else {
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"wrap mode axis");
			return false;
		}

		GLenum e;
		str = MaterialScriptParser::getSingleton().readString();
		if(!MaterialScriptParser::getSingleton().getGLenum(str,e)){
			MaterialScriptParser::getSingleton().logGLConverstionError(str);
			return false;
		}
		switch(e){
		case GL_CLAMP_TO_EDGE:
			setWrapMode(WrapMode_ClampToEdge);
			break;
		case GL_MIRRORED_REPEAT:
			setWrapMode(WrapMode_MirroredRepeat);
			break;
		case GL_REPEAT:
			setWrapMode(WrapMode_Repeat);
			break;
		default:
			MaterialScriptParser::getSingleton().logUnrecogTokenError(str,"wrap mode type");
			return false;
		}
		return true;
	}
	void SamplerProp_WrapMode::setWrapMode(WrapMode mode){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
			if(mWrapMode == GL_CLAMP_TO_BORDER) {
				Logger logger = Logger::getInstance("mtrl");
				LOG4CPLUS_WARN(logger,"GL_CLAMP_TO_BORDER type is not supported in ES 2.0");
				return;
			}
		#endif
//		if(mWrapMode == mode) return;
		mWrapMode = mode;
		mRequiresSycnh = true;
	}
	WrapMode SamplerProp_WrapMode::getWrapMode() const{
		return mWrapMode;
	}
	void SamplerProp_WrapMode::setAxis(WrapAxis axis){
		if(mAxis == axis) return;
		mAxis = axis;
		mRequiresSycnh = true;
	}
	WrapAxis SamplerProp_WrapMode::getAxis() const{
		return mAxis;
	}

}
