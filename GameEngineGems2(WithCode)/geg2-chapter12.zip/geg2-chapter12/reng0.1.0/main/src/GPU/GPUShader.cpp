/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUShader.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng
{
	GPUShader::GPUShader(ShaderType shaderType)
	: mShaderType(shaderType) 
	{
		createResource();
	}

	GPUShader::~GPUShader() {
		destroyResource();
	}
	GPUShader::GPUShader(GPUShader&){}
	GPUShader& GPUShader::operator=(GPUShader&){ return *this;}

	void GPUShader::createResource(){
		if(mResourceID!=0) return;
		if(!REng::isSupported(mShaderType)) {
			LOG4CPLUS_WARN(Logger::getInstance("mtrl"), "GPUShader | Shader type is not supported.");
			return;
		}
		mResourceID = glCreateShader((GLenum)mShaderType);
		assert(mResourceID);
	}

	void GPUShader::destroyResource(){
		if(mResourceID!=0) glDeleteShader(mResourceID);
	}

	ShaderType GPUShader::getType() const {
		return mShaderType;
	}

	bool GPUShader::compileFromText(size_t count, const char** shaderText) {
		if(!REng::isSupported(mShaderType)) { return false; }
		CHECKGLERROR_TERM();
		glShaderSource(mResourceID,(GLsizei)count,shaderText,NULL);
		glGetError(); // ADIL: fixing PowerVR OpenGL ES 2.0 simulator 2_05__25_0804 bug...
		glCompileShader(mResourceID);
		int infoLogLength = 0;
		glGetShaderiv(mResourceID,GL_INFO_LOG_LENGTH,&infoLogLength);
		char* infoLog = 0;
		if(infoLogLength > 0) {
			infoLog = new char[infoLogLength];
			int actualLogLength = 0;
			glGetShaderInfoLog(mResourceID,infoLogLength,&actualLogLength,infoLog);
			// trim any new line at the end of the info log received
			if(infoLog[infoLogLength-1]=='\n') infoLog[infoLogLength-1] = 0;
			if(infoLog[infoLogLength-2]=='\n') infoLog[infoLogLength-2] = 0;
			infoLogLength = actualLogLength;
		}
		GLint compileStatus = 0;
		glGetShaderiv(mResourceID,GL_COMPILE_STATUS,&compileStatus);
		if(infoLogLength>0) {
			if(strcmp(infoLog,"Success.")!=0)
				LOG4CPLUS_INFO(Logger::getInstance("mtrl"),"GPUShader | OpenGL shader compilation log:\n"<<infoLog);
		}

		CHECKGLERROR_TERM();
		delete [] infoLog;
		return (compileStatus==GL_TRUE);
	}

}
