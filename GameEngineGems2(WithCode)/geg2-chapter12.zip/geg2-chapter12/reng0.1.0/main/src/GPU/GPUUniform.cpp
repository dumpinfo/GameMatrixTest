/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/GPU/GPUUniform.h"
#include "REng/GPU/GPUProgram.h"

namespace REng
{
	GPUUniform::GPUUniform(const GPUProgram& glslProgram,const char* uniformName)
	: mOwnerProgram( glslProgram ) {
		mResourceLocation = glGetUniformLocation(glslProgram.mResourceID,uniformName);
		mResourceName = uniformName;
	}

	GPUUniform::~GPUUniform()
	{ ; }

	void GPUUniform::setInteger(GLint textureUnit) {
		glUniform1i(mResourceLocation,textureUnit);
	}

	void GPUUniform::setFloat(GLfloat value) {
		glUniform1f(mResourceLocation,value);
	}

	void GPUUniform::setVector2(GLfloat value0,GLfloat value1) {
		glUniform2f(mResourceLocation,value0,value1);
	}

	void GPUUniform::setVector3(GLfloat value0,GLfloat value1,GLfloat value2) {
		glUniform3f(mResourceLocation,value0,value1,value2);
	}

	void GPUUniform::setVector4(GLfloat value0,GLfloat value1,GLfloat value2,GLfloat value3) {
		glUniform4f(mResourceLocation,value0,value1,value2,value3);
	}

	void GPUUniform::setVector2i(GLint value0,GLint value1) {
		glUniform2i(mResourceLocation,value0,value1);
	}

	void GPUUniform::setVector3i(GLint value0,GLint value1,GLint value2) {
		glUniform3i(mResourceLocation,value0,value1,value2);
	}

	void GPUUniform::setVector4i(GLint value0,GLint value1,GLint value2,GLint value3) {
		glUniform4i(mResourceLocation,value0,value1,value2,value3);
	}

	void GPUUniform::setFloatArray(GLsizei elementCount,const GLfloat* array) {
		glUniform1fv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setIntArray(GLsizei elementCount,const GLint* array) {
		glUniform1iv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector2Array(GLsizei elementCount,const GLfloat* array) {
		glUniform2fv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector3Array(GLsizei elementCount,const GLfloat* array) {
		glUniform3fv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector4Array(GLsizei elementCount,const GLfloat* array) {
		glUniform4fv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector2iArray(GLsizei elementCount,const GLint* array) {
		glUniform2iv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector3iArray(GLsizei elementCount,const GLint* array) {
		glUniform3iv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setVector4iArray(GLsizei elementCount,const GLint* array) {
		glUniform4iv(mResourceLocation,elementCount,array);
	}

	void GPUUniform::setMatrix22(const GLfloat* matrix,GLsizei count,bool transpose) {
		glUniformMatrix2fv(mResourceLocation,count,transpose,matrix);
	}

	void GPUUniform::setMatrix33(const GLfloat* matrix,GLsizei count,bool transpose) {
		glUniformMatrix3fv(mResourceLocation,count,transpose,matrix);
	}

	void GPUUniform::setMatrix44(const GLfloat* matrix,GLsizei count ,bool transpose) {
		glUniformMatrix4fv(mResourceLocation,count,transpose,matrix);
	}

	const std::string& GPUUniform::getName() const {
		return mResourceName;
	}

	GLint GPUUniform::getResourceLocation() const {
		return mResourceLocation;
	}

	const GPUProgram& GPUUniform::getGLSLProgram() const {
		return mOwnerProgram;
	}

	bool GPUUniform::isValid() const  {
		return (mResourceLocation != -1);
	}
}
