/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/RenderMatrixManager.h"

#include "REng/Camera.h"

#define MAT4DATASIZE 16*sizeof(GLfloat)
#define MAT3DATASIZE  9*sizeof(GLfloat)

namespace REng{

	// singleton stuff
	template<> RenderMatrixManager* Singleton<RenderMatrixManager>::ms_Singleton = 0;
	RenderMatrixManager* RenderMatrixManager::getSingletonPtr(void) {
		return ms_Singleton;
	}
	RenderMatrixManager& RenderMatrixManager::getSingleton(void) {
		assert( ms_Singleton );  return ( *ms_Singleton );
	}

	RenderMatrixManager::RenderMatrixManager(){
		resetUniformLinks();
		setModel(cml::identity_4x4());
		setView(cml::identity_4x4());
		setProjection(cml::identity_4x4());
	}
	RenderMatrixManager::~RenderMatrixManager(){ ; }

/*
	// this code block is left for future reference
	void RenderMatrixManager::updateModel_Fixed(){
		Matrix4 tmpMatrix;
		glGetFloatv(GL_MODELVIEW_MATRIX,tmpMatrix.data());
		setModel(tmpMatrix,true);
		setView(cml::identity_4x4(),true);
	}
	void RenderMatrixManager::updateProjection_Fixed(){
		Matrix4 tmpMatrix;
		glGetFloatv(GL_PROJECTION_MATRIX,tmpMatrix.data());
		setProjection(tmpMatrix,true);
	}
*/

	void RenderMatrixManager::setViewProjection(const Camera& cam, bool updCur){
		setView(cam.getViewMatrix(),updCur);
		setProjection(cam.getProjectionMatrix(),updCur);
	}

	void RenderMatrixManager::setModel(const Matrix4& mat, bool updCur){
		mMat_Model = mat;
		if(updCur && mUni_Model) {
			mUni_Model->setData((void*)mMat_Model.data() , MAT4DATASIZE );
			mUni_Model->activate();
		}

		static int flagUpdater = (
			0x0001 | 0x0002 | 0x0004 | 0x0200 | 0x0400 | 0x0800 | 
			0x8000 | 0x10000 | 0x20000 | 0x40000 | 0x100000 | 0x200000 );
		mMat_Dirty = mMat_Dirty | flagUpdater;

		if(mUni_ModelView) updateModelView(updCur);
		if(mUni_ModelViewInv) updateModelViewInv(updCur);
		if(mUni_ModelViewTrans) updateModelViewTrans(updCur);
		if(mUni_ModelViewInvTrans) updateModelViewInvTrans(updCur);
		if(mUni_ModelViewProj) updateModelViewProj(updCur);
		if(mUni_ModelViewProjInv) updateModelViewProjInv(updCur);
		if(mUni_ModelViewProjTrans) updateModelViewProjTrans(updCur);
		if(mUni_ModelViewProjInvTrans) updateModelViewProjInvTrans(updCur);
		if(mUni_Normal) updateNormal(updCur);
	}

	void RenderMatrixManager::setView(const Matrix4& mat, bool updCur){
		mMat_View = mat;
		if(updCur && mUni_View) {
			mUni_View->setData((void*)mMat_View.data() , MAT4DATASIZE );
			mUni_View->activate();
		}

		static int flagUpdater = (
			0x0008 | 0x0010 | 0x0020 | 0x0200 | 0x0400 | 0x0800 | 
			0x1000 | 0x2000 | 0x4000 | 0x8000 | 0x10000 | 0x20000 | 
			0x40000 | 0x80000 | 0x100000 | 0x200000 );
		mMat_Dirty = mMat_Dirty | flagUpdater;

		if(mUni_ModelViewInv) updateModelViewInv(updCur);
		if(mUni_ModelViewTrans) updateModelViewTrans(updCur);
		if(mUni_ModelViewInvTrans) updateModelViewInvTrans(updCur);
		if(mUni_ViewProj) updateViewProj(updCur);
		if(mUni_ViewProjInv) updateViewProjInv(updCur);
		if(mUni_ViewProjTrans) updateViewProjTrans(updCur);
		if(mUni_ViewProjInvTrans) updateViewProjInvTrans(updCur);
		if(mUni_ModelViewProj) updateModelViewProj(updCur);
		if(mUni_ModelViewProjInv) updateModelViewProjInv(updCur);
		if(mUni_ModelViewProjTrans) updateModelViewProjTrans(updCur);
		if(mUni_ModelViewProjInvTrans) updateModelViewProjInvTrans(updCur);
		if(mUni_Normal) updateNormal(updCur);
	}

	void RenderMatrixManager::setProjection(const Matrix4& mat, bool updCur){
		mMat_Proj = mat;
		if(updCur && mUni_Proj) {
			mUni_Proj->setData((void*)mMat_Proj.data() , MAT4DATASIZE );
			mUni_Proj->activate();
		}

		static int flagUpdater = (
			0x0040 | 0x0080 | 0x0100 | 0x1000 | 0x2000 | 0x4000 | 
			0x8000 | 0x10000 | 0x20000 | 0x80000 | 0x100000);
		mMat_Dirty = mMat_Dirty | flagUpdater;

		if(mUni_ViewProj) updateViewProj(updCur);
		if(mUni_ViewProjInv) updateViewProjInv(updCur);
		if(mUni_ViewProjTrans) updateViewProjTrans(updCur);
		if(mUni_ViewProjInvTrans) updateViewProjInvTrans(updCur);
		if(mUni_ModelViewProj) updateModelViewProj(updCur);
		if(mUni_ModelViewProjInv) updateModelViewProjInv(updCur);
		if(mUni_ModelViewProjTrans) updateModelViewProjTrans(updCur);
		if(mUni_ModelViewProjInvTrans) updateModelViewProjInvTrans(updCur);
	}
	
	void RenderMatrixManager::setKernelMatrices(){
		Matrix4 m1;
		Matrix4 m2;
		cml::matrix_orthographic_RH(m1, -1.0f, +1.0f, -1.0f, +1.0f, -1.0f, +1.0f, cml::z_clip_neg_one);
		cml::matrix_look_at_RH(m2,
			0.0f,0.0f,1.0f/*pos*/,
			0.0f,0.0f,0.0f/*target*/,
			0.0f,1.0f,0.0f/*up*/
			);
		setProjection(m1,true);
		setView(m2,true);
		setModel(cml::identity_4x4(),true);
	}

	/************************************************************************/
	/* STACK OPERATIONS                                                     */
	/************************************************************************/

	void RenderMatrixManager::pushModel(){
		mStack_Model.push_back(mMat_Model);
	}
	void RenderMatrixManager::pushView(){
		mStack_View.push_back(mMat_View);
	}
	void RenderMatrixManager::pushProjection(){
		mStack_Proj.push_back(mMat_Proj);
	}
	void RenderMatrixManager::pushAll(){
		pushModel();
		pushView();
		pushProjection();
	}

	bool RenderMatrixManager::popModel(){
		if(mStack_Model.size()==0) return false;
		setModel(mStack_Model.back());
		mStack_Model.pop_back();
		return true;
	}
	bool RenderMatrixManager::popView(){
		if(mStack_View.size()==0) return false;
		setView(mStack_View.back());
		mStack_View.pop_back();
		return true;
	}
	bool RenderMatrixManager::popProjection(){
		if(mStack_Proj.size()==0) return false;
		setProjection(mStack_Proj.back());
		mStack_Proj.pop_back();
		return true;
	}
	bool RenderMatrixManager::popAll(){
		bool toRet = true;
		toRet = toRet && popView();
		toRet = toRet && popModel();
		toRet = toRet && popProjection();
		return toRet;
	}

	/************************************************************************/
	/* GETTERS                                                              */
	/************************************************************************/

	const Matrix4& RenderMatrixManager::getMat_Model() const{
		return mMat_Model;
	}
	const Matrix4& RenderMatrixManager::getMat_View() const{
		return mMat_View;
	}
	const Matrix4& RenderMatrixManager::getMat_Proj() const{
		return mMat_Proj;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelInv() const{
		if(mMat_Dirty & 0x0001) updateModelInv();
		return mMat_ModelInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelTrans() const{
		if(mMat_Dirty & 0x0002) updateModelTrans();
		return mMat_ModelTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelInvTrans() const{
		if(mMat_Dirty & 0x0004) updateModelInvTrans();
		return mMat_ModelTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewInv() const{
		if(mMat_Dirty & 0x0008) updateViewInv();
		return mMat_ViewInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewTrans() const{
		if(mMat_Dirty & 0x0010) updateViewTrans();
		return mMat_ViewTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewInvTrans() const{
		if(mMat_Dirty & 0x0020) updateViewInvTrans();
		return mMat_ViewInvTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ProjInv() const{
		if(mMat_Dirty & 0x0040) updateProjInv();
		return mMat_ProjInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ProjTrans() const{
		if(mMat_Dirty & 0x0080) updateProjTrans();
		return mMat_ProjTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ProjInvTrans() const{
		if(mMat_Dirty & 0x0100) updateProjInvTrans();
		return mMat_ProjInvTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewInv() const{
		if(mMat_Dirty & 0x0200) updateModelViewInv();
		return mMat_ModelViewInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewTrans() const{
		if(mMat_Dirty & 0x0400) updateModelViewTrans();
		return mMat_ModelViewTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewInvTrans() const{
		if(mMat_Dirty & 0x0800) updateModelViewInvTrans();
		return mMat_ModelViewInvTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewProjInv() const{
		if(mMat_Dirty & 0x1000) updateViewProjInv();
		return mMat_ViewProjInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewProjTrans() const{
		if(mMat_Dirty & 0x2000) updateViewProjTrans();
		return mMat_ViewProjTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewProjInvTrans() const{
		if(mMat_Dirty & 0x4000) updateViewProjInvTrans();
		return mMat_ViewProjInvTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewProjInv() const{
		if(mMat_Dirty & 0x8000) updateModelViewProjInv();
		return mMat_ModelViewProjInv;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewProjTrans() const{
		if(mMat_Dirty & 0x10000) updateModelViewProjTrans();
		return mMat_ModelViewProjTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewProjInvTrans() const{
		if(mMat_Dirty & 0x20000) updateModelViewProjInvTrans();
		return mMat_ModelViewProjInvTrans;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelView() const{
		if(mMat_Dirty & 0x40000) updateModelView();
		return mMat_ModelView;
	}
	const Matrix4& RenderMatrixManager::getMat_ViewProj() const{
		if(mMat_Dirty & 0x80000) updateViewProj();
		return mMat_ViewProj;
	}
	const Matrix4& RenderMatrixManager::getMat_ModelViewProj() const{
		if(mMat_Dirty & 0x100000) updateModelViewProj();
		return mMat_ModelViewProj;
	}
	const Matrix3& RenderMatrixManager::getMat_Normal() const{
		if(mMat_Dirty & 0x200000) updateNormal();
		return mMat_Normal;
	}

	void RenderMatrixManager::updateModelInv(bool updCur) const{
		mMat_ModelInv = mMat_Model;
		mMat_ModelInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x0001;
		if(updCur && mUni_ModelInv) {
			mUni_ModelInv->setData((void*)mMat_ModelInv.data() , MAT4DATASIZE );
			mUni_ModelInv->activate();
		}
	}
	void RenderMatrixManager::updateModelTrans(bool updCur) const{
		mMat_ModelTrans = mMat_Model;
		mMat_ModelTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x0002;
		if(updCur && mUni_ModelTrans) {
			mUni_ModelTrans->setData((void*)mMat_ModelTrans.data() , MAT4DATASIZE );
			mUni_ModelTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelInvTrans(bool updCur) const{
		mMat_ModelInvTrans = mMat_Model;
		mMat_ModelInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x0004;
		if(updCur && mUni_ModelInvTrans) {
			mUni_ModelInvTrans->setData((void*)mMat_ModelInvTrans.data() , MAT4DATASIZE );
			mUni_ModelInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateViewInv(bool updCur) const{
		mMat_ViewInv = mMat_View;
		mMat_ViewInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x0008;
		if(updCur && mUni_ViewInv) {
			mUni_ViewInv->setData((void*)mMat_ViewInv.data() , MAT4DATASIZE );
			mUni_ViewInv->activate();
		}
	}
	void RenderMatrixManager::updateViewTrans(bool updCur) const{
		mMat_ViewTrans = mMat_View;
		mMat_ViewTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x0010;
		if(updCur && mUni_ViewTrans) {
			mUni_ViewTrans->setData((void*)mMat_ViewTrans.data() , MAT4DATASIZE );
			mUni_ViewTrans->activate();
		}
	}
	void RenderMatrixManager::updateViewInvTrans(bool updCur) const{
		mMat_ViewInvTrans = mMat_View;
		mMat_ViewInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x0020;
		if(updCur && mUni_ViewInvTrans) {
			mUni_ViewInvTrans->setData((void*)mMat_ViewInvTrans.data() , MAT4DATASIZE );
			mUni_ViewInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateProjInv(bool updCur) const{
		mMat_ProjInv = mMat_Proj;
		mMat_ProjInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x0040;
		if(updCur && mUni_ProjInv) {
			mUni_ProjInv->setData((void*)mMat_ProjInv.data() , MAT4DATASIZE );
			mUni_ProjInv->activate();
		}
	}
	void RenderMatrixManager::updateProjTrans(bool updCur) const{
		mMat_ProjTrans = mMat_Proj;
		mMat_ProjTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x0080;
		if(updCur && mUni_ProjTrans) {
			mUni_ProjTrans->setData((void*)mMat_ProjTrans.data() , MAT4DATASIZE );
			mUni_ProjTrans->activate();
		}
	}
	void RenderMatrixManager::updateProjInvTrans(bool updCur) const{
		mMat_ProjInvTrans = mMat_Proj;
		mMat_ProjInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x0100;
		if(updCur && mUni_ProjInvTrans) {
			mUni_ProjInvTrans->setData((void*)mMat_ProjInvTrans.data() , MAT4DATASIZE );
			mUni_ProjInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelViewInv(bool updCur) const{
		mMat_ModelViewInv = getMat_ModelView();
		mMat_ModelViewInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x0200;
		if(updCur && mUni_ModelViewInv) {
			mUni_ModelViewInv->setData((void*)mMat_ModelViewInv.data() , MAT4DATASIZE );
			mUni_ModelViewInv->activate();
		}
	}
	void RenderMatrixManager::updateModelViewTrans(bool updCur) const{
		mMat_ModelViewTrans = getMat_ModelView();
		mMat_ModelViewTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x0400;
		if(updCur && mUni_ModelViewTrans) {
			mUni_ModelViewTrans->setData((void*)mMat_ModelViewTrans.data() , MAT4DATASIZE );
			mUni_ModelViewTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelViewInvTrans(bool updCur) const{
		mMat_ModelViewInvTrans = getMat_ModelView();
		mMat_ModelViewInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x0800;
		if(updCur && mUni_ModelViewInvTrans) {
			mUni_ModelViewInvTrans->setData((void*)mMat_ModelViewInvTrans.data() , MAT4DATASIZE );
			mUni_ModelViewInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateViewProjInv(bool updCur) const{
		mMat_ViewProjInv = getMat_ViewProj();
		mMat_ViewProjInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x1000;
		if(updCur && mUni_ViewProjInv) {
			mUni_ViewProjInv->setData((void*)mMat_ViewProjInv.data() , MAT4DATASIZE );
			mUni_ViewProjInv->activate();
		}
	}
	void RenderMatrixManager::updateViewProjTrans(bool updCur) const{
		mMat_ViewProjTrans = getMat_ViewProj();
		mMat_ViewProjTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x2000;
		if(updCur && mUni_ViewProjTrans) {
			mUni_ViewProjTrans->setData((void*)mMat_ViewProjTrans.data() , MAT4DATASIZE );
			mUni_ViewProjTrans->activate();
		}
	}
	void RenderMatrixManager::updateViewProjInvTrans(bool updCur) const{
		mMat_ViewProjInvTrans = getMat_ViewProj();
		mMat_ViewProjInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x4000;
		if(updCur && mUni_ViewProjInvTrans) {
			mUni_ViewProjInvTrans->setData((void*)mMat_ViewProjInvTrans.data() , MAT4DATASIZE );
			mUni_ViewProjInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelViewProjInv(bool updCur) const{
		mMat_ModelViewProjInv = getMat_ModelViewProj();
		mMat_ModelViewProjInv.inverse();
		mMat_Dirty = mMat_Dirty & ~0x8000;
		if(updCur && mUni_ModelViewProjInv) {
			mUni_ModelViewProjInv->setData((void*)mMat_ModelViewProjInv.data() , MAT4DATASIZE );
			mUni_ModelViewProjInv->activate();
		}
	}
	void RenderMatrixManager::updateModelViewProjTrans(bool updCur) const{
		mMat_ModelViewProjTrans = getMat_ModelViewProj();
		mMat_ModelViewProjTrans.transpose();
		mMat_Dirty = mMat_Dirty & ~0x10000;
		if(updCur && mUni_ModelViewProjTrans) {
			mUni_ModelViewProjTrans->setData((void*)mMat_ModelViewProjTrans.data() , MAT4DATASIZE );
			mUni_ModelViewProjTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelViewProjInvTrans(bool updCur) const{
		mMat_ModelViewProjInvTrans = getMat_ModelViewProj();
		mMat_ModelViewProjInvTrans.inverse().transpose();
		mMat_Dirty = mMat_Dirty & ~0x20000;
		if(updCur && mUni_ModelViewProjInvTrans) {
			mUni_ModelViewProjInvTrans->setData((void*)mMat_ModelViewProjInvTrans.data() , MAT4DATASIZE );
			mUni_ModelViewProjInvTrans->activate();
		}
	}
	void RenderMatrixManager::updateModelView(bool updCur) const{
		mMat_ModelView = mMat_View * mMat_Model;
		mMat_Dirty = mMat_Dirty & ~0x40000;
		if(updCur && mUni_ModelView) {
			mUni_ModelView->setData((void*)mMat_ModelView.data() , MAT4DATASIZE );
			mUni_ModelView->activate();
		}
	}
	void RenderMatrixManager::updateViewProj(bool updCur) const{
		mMat_ViewProj = mMat_Proj * mMat_View;
		mMat_Dirty = mMat_Dirty & ~0x80000;
		if(updCur && mUni_ViewProj) {
			mUni_ViewProj->setData((void*)mMat_ViewProj.data() , MAT4DATASIZE );
			mUni_ViewProj->activate();
		}
	}
	void RenderMatrixManager::updateModelViewProj(bool updCur) const{
		mMat_ModelViewProj = mMat_Proj * mMat_View * mMat_Model ;
		mMat_Dirty = mMat_Dirty & ~0x100000;
		if(updCur && mUni_ModelViewProj) {
			mUni_ModelViewProj->setData((void*)mMat_ModelViewProj.data() , MAT4DATASIZE );
			mUni_ModelViewProj->activate();
		}
	}
	void RenderMatrixManager::updateNormal(bool updCur) const{
		getMat_ModelViewInvTrans(); // updates mMat_ModelViewInvTrans
		mMat_Normal(0,0) = mMat_ModelViewInvTrans(0,0);
		mMat_Normal(0,1) = mMat_ModelViewInvTrans(0,1);
		mMat_Normal(0,2) = mMat_ModelViewInvTrans(0,2);
		mMat_Normal(1,0) = mMat_ModelViewInvTrans(1,0);
		mMat_Normal(1,1) = mMat_ModelViewInvTrans(1,1);
		mMat_Normal(1,2) = mMat_ModelViewInvTrans(1,2);
		mMat_Normal(2,0) = mMat_ModelViewInvTrans(2,0);
		mMat_Normal(2,1) = mMat_ModelViewInvTrans(2,1);
		mMat_Normal(2,2) = mMat_ModelViewInvTrans(2,2);
		mMat_Dirty = mMat_Dirty & ~0x200000;
		if(updCur && mUni_Normal) {
			mUni_Normal->setData((void*)mMat_Normal.data() , MAT3DATASIZE );
			mUni_Normal->activate();
		}
	}

	bool RenderMatrixManager::updateUniform(RenderProp_Uniform& uniform) const {
		switch(uniform.getAutoName()){
			case UAN_ModelMatrix:
				mUni_Model = &uniform;
				uniform.setData((void*)getMat_Model().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelMatrixInverse:
				mUni_ModelInv = &uniform;
				uniform.setData((void*)getMat_ModelInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelMatrixTranspose:
				mUni_ModelTrans = &uniform;
				uniform.setData((void*)getMat_ModelTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelMatrixInverseTranspose:
				mUni_ModelInvTrans = &uniform;
				uniform.setData((void*)getMat_ModelInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewMatrix:
				mUni_View = &uniform;
				uniform.setData((void*)getMat_View().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewMatrixInverse:
				mUni_ViewInv = &uniform;
				uniform.setData((void*)getMat_ViewInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewMatrixTranspose:
				mUni_ViewTrans = &uniform;
				uniform.setData((void*)getMat_ViewTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewMatrixInverseTranspose:
				mUni_ViewInvTrans = &uniform;
				uniform.setData((void*)getMat_ViewInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ProjectionMatrix:
				mUni_Proj = &uniform;
				uniform.setData((void*)getMat_Proj().data(), MAT4DATASIZE); 
				break;
			case UAN_ProjectionMatrixInverse:
				mUni_ProjInv = &uniform;
				uniform.setData((void*)getMat_ProjInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ProjectionMatrixTranspose:
				mUni_ProjTrans = &uniform;
				uniform.setData((void*)getMat_ProjTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ProjectionMatrixInverseTranspose:
				mUni_ProjInvTrans = &uniform;
				uniform.setData((void*)getMat_ProjInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewMatrix:
				mUni_ModelView = &uniform;
				uniform.setData((void*)getMat_ModelView().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewMatrixInverse:
				mUni_ModelViewInv = &uniform;
				uniform.setData((void*)getMat_ModelViewInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewMatrixTranspose:
				mUni_ModelViewTrans = &uniform;
				uniform.setData((void*)getMat_ModelViewTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewMatrixInverseTranspose:
				mUni_ModelViewInvTrans = &uniform;
				uniform.setData((void*)getMat_ModelViewInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewProjectionMatrix:
				mUni_ViewProj = &uniform;
				uniform.setData((void*)getMat_ViewProj().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewProjectionMatrixInverse:
				mUni_ViewProjInv = &uniform;
				uniform.setData((void*)getMat_ViewProjInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewProjectionMatrixTranspose:
				mUni_ViewProjInvTrans = &uniform;
				uniform.setData((void*)getMat_ViewProjTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ViewProjectionMatrixInverseTranspose:
				mUni_ViewProjTrans = &uniform;
				uniform.setData((void*)getMat_ViewProjInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewProjectionMatrix:
				mUni_ModelViewProj = &uniform;
				uniform.setData((void*)getMat_ModelViewProj().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewProjectionMatrixInverse:
				mUni_ModelViewProjInv = &uniform;
				uniform.setData((void*)getMat_ModelViewProjInv().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewProjectionMatrixTranspose:
				mUni_ModelViewProjTrans = &uniform;
				uniform.setData((void*)getMat_ModelViewProjTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_ModelViewProjectionMatrixInverseTranspose:
				mUni_ModelViewProjInvTrans = &uniform;
				uniform.setData((void*)getMat_ModelViewProjInvTrans().data(), MAT4DATASIZE); 
				break;
			case UAN_NormalMatrix:
				mUni_Normal = &uniform;
				uniform.setData((void*)getMat_Normal().data(), MAT3DATASIZE); 
				break;
			default:
				return false;
		}
		return true;
	}
	void RenderMatrixManager::resetUniformLinks(){
		mUni_Model = 0;
		mUni_ModelInv = 0;
		mUni_ModelTrans = 0;
		mUni_ModelInvTrans = 0;

		mUni_View = 0;
		mUni_ViewInv = 0;
		mUni_ViewTrans = 0;
		mUni_ViewInvTrans = 0;

		mUni_Proj = 0;
		mUni_ProjInv = 0;
		mUni_ProjTrans = 0;
		mUni_ProjInvTrans = 0;

		mUni_ModelView = 0;
		mUni_ModelViewInv = 0;
		mUni_ModelViewTrans = 0;
		mUni_ModelViewInvTrans = 0;

		mUni_ViewProj = 0;
		mUni_ViewProjInv = 0;
		mUni_ViewProjTrans = 0;
		mUni_ViewProjInvTrans = 0;

		mUni_ModelViewProj = 0;
		mUni_ModelViewProjInv = 0;
		mUni_ModelViewProjTrans = 0;
		mUni_ModelViewProjInvTrans = 0;

		mUni_Normal = 0;
	}
}

