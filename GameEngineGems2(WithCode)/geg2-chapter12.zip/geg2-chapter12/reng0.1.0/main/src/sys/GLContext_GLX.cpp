/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/sys/GLContext_GLX.h"

#ifdef USING_GLX

#include "REng/sys/OSWindow_XWin.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#ifndef GLX_MAX_SWAP_INTERVAL_EXT
#define GLX_MAX_SWAP_INTERVAL_EXT 0x20F2
#endif

#define GLX_CONTEXT_CORE_PROFILE_BIT_ARB 0x00000001
#define GLX_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB 0x00000002
#define GLX_CONTEXT_PROFILE_MASK_ARB 0x9126

namespace REng{

	static const char* _GLXstr = "GLX | ";


	GLContext_GLX::GLContext_GLX()
		:mParamsHack(0)
		,mVisInfo(0)
		,glXCreateContextAttribsARB(NULL)
		,mExtentionInfoList(0)
		,mExtentionCount(0)
	{ ; }
	GLContext_GLX::~GLContext_GLX(){
		if(mFrameBufConfigs) XFree(mFrameBufConfigs);
	}

	bool GLContext_GLX::updateVisInfo(OSWindow_X* windowHandle){
		if(mVisInfo) return true;
		Logger logger = Logger::getInstance("RSys");

		mWindowHandle = windowHandle;
		assert(windowHandle->getDisplay());

		int configAttribs[64];
		size_t i=0;
		//////////////////////////////////////////////////////////////////////////
		// PRE-DEFINED VALUES
		configAttribs[i++]=GLX_X_RENDERABLE;  configAttribs[i++]=True;
		configAttribs[i++]=GLX_X_VISUAL_TYPE; configAttribs[i++]=GLX_TRUE_COLOR; // DIRECT/PSEUDO/STATIC/GRAY
		configAttribs[i++]=GLX_DRAWABLE_TYPE; configAttribs[i++]=GLX_WINDOW_BIT; // No pixmap/pbuffers
		configAttribs[i++]=GLX_RENDER_TYPE;   configAttribs[i++]=GLX_RGBA_BIT; // No color-index support
		//////////////////////////////////////////////////////////////////////////
		// CONFIGURABLE VALUES
		if(mParamList[GLCntxtParRedRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_RED_SIZE;     configAttribs[i++]=mParamList[GLCntxtParRedRes];
		if(mParamList[GLCntxtParBlueRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_GREEN_SIZE;   configAttribs[i++]=mParamList[GLCntxtParBlueRes];
		if(mParamList[GLCntxtParGreenRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_BLUE_SIZE;    configAttribs[i++]=mParamList[GLCntxtParGreenRes];
		if(mParamList[GLCntxtParAlphaRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_ALPHA_SIZE;   configAttribs[i++]=mParamList[GLCntxtParAlphaRes];
		if(mParamList[GLCntxtParDepthRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_DEPTH_SIZE;   configAttribs[i++]=mParamList[GLCntxtParDepthRes];
		if(mParamList[GLCntxtParStencilRes]!=GLCntxtParDontCare)
			configAttribs[i++]=GLX_STENCIL_SIZE; configAttribs[i++]=mParamList[GLCntxtParStencilRes];
		if(mParamList[GLCntxtParSampleCount]!=0){
			configAttribs[i++]=GLX_SAMPLE_BUFFERS;
			configAttribs[i++]=1;
			configAttribs[i++]=GLX_SAMPLES;
			configAttribs[i++]=mParamList[GLCntxtParSampleCount];
		}
		configAttribs[i++]=GLX_DOUBLEBUFFER;
		switch(mParamList[GLCntxtParDoubleBuffer]){
			default:
			case GLCntxtParDontCare: configAttribs[i++]=GLX_DONT_CARE; break;
			case GLCntxtParFalse:    configAttribs[i++]=False; break;
			case GLCntxtParTrue:     configAttribs[i++]=True; break;
		}
		configAttribs[i++]=GLX_STEREO;  
		switch(mParamList[GLCntxtParStereoBuffer]){
			default: 
			case GLCntxtParDontCare: configAttribs[i++]=GLX_DONT_CARE; break;
			case GLCntxtParFalse:    configAttribs[i++]=False; break;
			case GLCntxtParTrue:     configAttribs[i++]=True; break;
		}
		configAttribs[i++]=None;

		LOG4CPLUS_INFO(logger,_GLXstr<<"Getting matching framebuffer configs...");
		int fbcount;
		mFrameBufConfigs = glXChooseFBConfig(windowHandle->getDisplay(), windowHandle->getScreen(), 
			configAttribs, &fbcount);
		if(mFrameBufConfigs==0){
			LOG4CPLUS_FATAL(logger,_GLXstr<<"Failed to retrieve a framebuffer config."); return false;
		}
		mSelectedFrameBufConfig = 0; // assume the first returned config is the best

		LOG4CPLUS_INFO(Logger::getInstance("RSys"),_GLXstr<<"FrameBuffer Configs CHOSEN:");
		for(int i=0;i<fbcount;++i) logFBConfigAttribs(mFrameBufConfigs[i]);
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),_GLXstr<<"The config SELECTED:");
		logFBConfigAttribs(mFrameBufConfigs[mSelectedFrameBufConfig]);

		mVisInfo = glXGetVisualFromFBConfig(windowHandle->getDisplay(), mFrameBufConfigs[mSelectedFrameBufConfig]);
		LOG4CPLUS_INFO(logger,_GLXstr<<"XVisual is received.");
		return true;
	}

	bool GLContext_GLX::init(OSWindow* windowHandle){
		(void) windowHandle;
		Logger logger = Logger::getInstance("RSys");
		OSWindow_X* windowHandle_X = (OSWindow_X*)windowHandle;

		assert(windowHandle_X->getDisplay());

		// Create an old-style GLX context first, to get the correct function ptr.
		mContext = glXCreateContext( windowHandle_X->getDisplay(), mVisInfo, 0, True); // direct connection, no shared context

		glXCreateContextAttribsARB = (glXCreateContextAttribsARBProc) glXGetProcAddress((const GLubyte*)"glXCreateContextAttribsARB");
		glXSwapIntervalEXT = (glXSwapIntervalEXTProc) glXGetProcAddress((const GLubyte*)"glXSwapIntervalEXT");
		if(glXSwapIntervalEXT==NULL){
			// try SGI's extension
			glXSwapIntervalSGI =(glXSwapIntervalSGIProc) glXGetProcAddress((const GLubyte*)"glXSwapIntervalSGI");
		}

		if(glXCreateContextAttribsARB==NULL) {
			LOG4CPLUS_ERROR(logger,_GLXstr<<"Cannot get Proc Adress for required function pointers."); return false;
		}

		glXMakeCurrent(windowHandle_X->getDisplay(), 0, 0);
		glXDestroyContext(windowHandle_X->getDisplay(), mContext);
		LOG4CPLUS_INFO(logger,_GLXstr<<"Old GLX context is destroyed.");

		int contextAttribs[16]; setContextAttribs(contextAttribs);

		// direct connection, no shared context
		mContext = glXCreateContextAttribsARB( windowHandle_X->getDisplay(), 
			mFrameBufConfigs[mSelectedFrameBufConfig], 0, True, contextAttribs );
		if(mContext==0){
			LOG4CPLUS_FATAL(logger,_GLXstr<<"Failed to created GL 3.0 context."); return false;
		}

		// Check if the new context has a direct connection to graphics system.
		if(!glXIsDirect(windowHandle_X->getDisplay(), mContext) ) {
			LOG4CPLUS_FATAL(logger,_GLXstr<<"Context is not direct."); return false;
		}

		glXMakeCurrent(windowHandle_X->getDisplay(), windowHandle_X->getWindow(), mContext);

		//////////////////////////////////////////////////////////////////////////
		// READ GLX SETTINGS

		glXQueryVersion(windowHandle_X->getDisplay(),&mVersion_Major,&mVersion_Minor);
		const char* _str;
		_str = glXGetClientString(windowHandle_X->getDisplay(),GLX_EXTENSIONS);
		mExtensions = (char*)malloc(strlen(_str)+1); strcpy((char*)mExtensions,_str);
		_str = glXGetClientString(windowHandle_X->getDisplay(),GLX_VENDOR);
		mVendor     = (char*)malloc(strlen(_str)+1); strcpy((char*)mVendor,    _str);
		_str = glXGetClientString(windowHandle_X->getDisplay(),GLX_VERSION);
		mVersion    = (char*)malloc(strlen(_str)+1); strcpy((char*)mVersion,   _str);
		readExtensions();

		LOG4CPLUS_INFO(logger,_GLXstr<<"OpenGL Context is created.");

//		updateResolutions(); TODO
		switch(mParamList[GLCntxtParVSynch]){
			case GLCntxtParDontCare: break;
			case GLCntxtParFalse: setVSyncEnabled(false); break;
			case GLCntxtParTrue: setVSyncEnabled(true); break;
		}
		switch(mParamList[GLCntxtParDoubleBuffer]){
			case GLCntxtParFalse:    mDoubleBuffered = false;
			case GLCntxtParTrue:     mDoubleBuffered = true;
			case GLCntxtParDontCare: mDoubleBuffered = true; // TODO: Read from GLX
		}
		mIsInited = true;
		return true;
	}

	bool GLContext_GLX::release(){
		if(mContext==0) return true;
		glXMakeCurrent(((OSWindow_X*)mWindowHandle)->getDisplay(), 0, 0 );
		glXDestroyContext(((OSWindow_X*)mWindowHandle)->getDisplay(), mContext);
		mIsInited = false;
		return true;
	}
	bool GLContext_GLX::swapBuffers(){
		if(!mDoubleBuffered) return true;
		glXSwapBuffers( 
			((OSWindow_X*)mWindowHandle)->getDisplay(), 
			(GLXDrawable)(((OSWindow_X*)mWindowHandle))->getWindow()
			);
		return true;
	}

	void GLContext_GLX::setContextAttribs(int* contextAttribs){
		size_t attribIndex = 0;
		if(mParamList[GLCntxtParGLVersionMaj]!=GLCntxtParDontCare){
			contextAttribs[attribIndex++] = GLX_CONTEXT_MAJOR_VERSION_ARB;
			contextAttribs[attribIndex++] = mParamList[GLCntxtParGLVersionMaj];
		}
		if(mParamList[GLCntxtParGLVersionMin]!=GLCntxtParDontCare){
			contextAttribs[attribIndex++] = GLX_CONTEXT_MINOR_VERSION_ARB;
			contextAttribs[attribIndex++] = mParamList[GLCntxtParGLVersionMin];
		}
		switch(mParamList[GLCntxtParProfile]){
			default: break;
			case GLContextProfile_DontCare: break;
			case GLContextProfile_ES:
				if(!isExtensionSupported("WGL_EXT_create_context_es2_profile")){
					LOG4CPLUS_WARN(Logger::getInstance("RSys"),_GLXstr<<"ES contexts are unsupported.");
				} else {
					contextAttribs[attribIndex++] = GLX_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_ES;
				}
				break;
			case GLContextProfile_Core:
				// only valid for OpenGL version > 3.2
				if(mParamList[GLCntxtParGLVersionMaj]!=3||mParamList[GLCntxtParGLVersionMin]>=2){
					contextAttribs[attribIndex++] = GLX_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_Core;
				}
				break;
			case GLContextProfile_Compatibility:
				// only valid for OpenGL version > 3.2
				if(mParamList[GLCntxtParGLVersionMaj]!=3||mParamList[GLCntxtParGLVersionMin]>=2){
					contextAttribs[attribIndex++] = GLX_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_Compatibility;
				}
				break;
		}
		// If requested OpenGL version is less than 3.2, forward-only compatible profiles 
		// is managed by additional bit parameters
		switch(mParamList[GLCntxtParProfile]){
			default: break;
			case GLContextProfile_Core:
				contextAttribs[attribIndex++] = GLX_CONTEXT_FLAGS_ARB;
				contextAttribs[attribIndex++] = GLX_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB;
				break;
		}
		contextAttribs[attribIndex++] = 0;
	}
	void GLContext_GLX::logConfig(){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"GLX Version   :" << mVersion_Major << "-" << mVersion_Minor);
		LOG4CPLUS_INFO(logger,"GLX Version   :" << mVersion);
		LOG4CPLUS_INFO(logger,"GLX Vendor    :" << mVendor);
		LOG4CPLUS_INFO(logger,"GLX Extensions:");
		for(size_t i=0 ; i<mExtentionCount ; ++i) LOG4CPLUS_INFO(logger,"\t"<<i<<" "<<mExtentionInfoList[i]);
	}
	
	void GLContext_GLX::readExtensions(){
		if(mExtentionInfoList) return; // we have already read extensions
		// we need a non-const string
		char* cExt = (char*) malloc((strlen(mExtensions)+1) * sizeof(char));
		strcpy(cExt,mExtensions);
		// learn number of tokens(mExtensions) in the string
		const char* delim = " ";
		char* c = strtok(cExt,delim);
		for(mExtentionCount=0 ; c!=NULL ; ++mExtentionCount) c=strtok(NULL,delim);
		mExtentionInfoList = (char**) malloc(mExtentionCount * sizeof(char*));
		// re-fill the cExt string
		strcpy(cExt,mExtensions);
		// copy the extension strings to mExtentionInfoList
		c = strtok(cExt,delim);
		for(size_t i=0 ; c!=NULL; ++i) {
			size_t sLen = strlen(c);
			mExtentionInfoList[i] = (char*) malloc((sLen+1) * sizeof(char));
			strcpy(mExtentionInfoList[i],c);
			c = strtok(NULL,delim);
		}
		free(cExt);
	}

	bool GLContext_GLX::isExtensionSupported(const char *extension){
		for(size_t i=0; i<mExtentionCount; ++i){
			if(strcmp(mExtentionInfoList[i],extension)==0) return true;
		} return false;
	}

	void GLContext_GLX::logFBConfigAttribs(GLXFBConfig cfg){
		Display* display = ((OSWindow_X*)mWindowHandle)->getDisplay();
		int bufferSize(10),redSize(10),greenSize(10),blueSize(10),alphaSize(10);
		int depthSize(10),stnclSize(10),caveat(10),multiSamp(10),samples(10);
		int maxInterval(10), configID(10);
		glXGetFBConfigAttrib(display,cfg,GLX_FBCONFIG_ID,   &configID  );
		glXGetFBConfigAttrib(display,cfg,GLX_BUFFER_SIZE,   &bufferSize);
		glXGetFBConfigAttrib(display,cfg,GLX_RED_SIZE,      &redSize   );
		glXGetFBConfigAttrib(display,cfg,GLX_GREEN_SIZE,    &greenSize );
		glXGetFBConfigAttrib(display,cfg,GLX_BLUE_SIZE,     &blueSize  );
		glXGetFBConfigAttrib(display,cfg,GLX_ALPHA_SIZE,    &alphaSize );
		glXGetFBConfigAttrib(display,cfg,GLX_DEPTH_SIZE,    &depthSize );
		glXGetFBConfigAttrib(display,cfg,GLX_STENCIL_SIZE,  &stnclSize );
		glXGetFBConfigAttrib(display,cfg,GLX_SAMPLE_BUFFERS,&multiSamp );
		glXGetFBConfigAttrib(display,cfg,GLX_SAMPLES,       &samples   );
		glXGetFBConfigAttrib(display,cfg,GLX_CONFIG_CAVEAT, &caveat    );
		glXGetFBConfigAttrib(display,cfg,GLX_MAX_SWAP_INTERVAL_EXT, &maxInterval );

		LOG4CPLUS_INFO(Logger::getInstance("RSys")," "
			"ID:"<<configID<<" "
			
			"[R:"<<redSize<<" G:"<<greenSize<<" B:"<<blueSize<<" A:"<<alphaSize<<"  Total:"<<bufferSize<<"] "
			
			"[D:"<<depthSize<<((depthSize<10)?" ":"")<<" S:"<<stnclSize<<"] "
			
//			"[MS:"<<(multiSamp?"Y-":"N-")<<(multiSamp?samples:0)<<"] "<<
			"[MS:"<<(multiSamp?samples:0)<<"] "<<
			
			((caveat==GLX_SLOW_CONFIG)?"Slow ":"")<<
			((caveat==GLX_NON_CONFORMANT_CONFIG)?"NonConform. ":"")<<

			"[SwapInt-Max:"<<maxInterval<<"]"
			);
	}

	void GLContext_GLX::setVSyncEnabled(bool flag){
		if(this->glXSwapIntervalEXT!=NULL) {
			this->glXSwapIntervalEXT(
				((OSWindow_X*)mWindowHandle)->getDisplay(),
				((OSWindow_X*)mWindowHandle)->getWindow(),
				flag
				);
		} else {
			if(this->glXSwapIntervalSGI!=NULL){
				this->glXSwapIntervalSGI(flag);
			}

		}
	}
	bool GLContext_GLX::isVSyncEnabled() const{
		// querying this setting is not supported by GLX
		return false;
	}




} // namespace REng

#endif // USING_GLX
