/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/sys/GLContext_EGL.h"

#ifdef USING_EGL

#include "REng/sys/OSWindow_XWin.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#ifndef EGL_OPENGL_BIT
#define EGL_OPENGL_BIT                 0x0008  /* EGL_RENDERABLE_TYPE mask bits */
#endif

namespace REng{

	static const char* _EGLstr = "EGL | ";

	GLContext_EGL::GLContext_EGL() : mDisplay(0), mGLContext(0),mVSynchEnabled(true) { ; }
	GLContext_EGL::~GLContext_EGL(){ ; }

	bool GLContext_EGL::init(OSWindow* windowHandle){
		mWindowHandle = windowHandle;

		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,_EGLstr<<"Initializing...");

		mDisplay = eglGetDisplay(
			#if RENG_PLATFORM == RENG_PLATFORM_OMAP
				(EGLNativeDisplayType) EGL_DEFAULT_DISPLAY
			#elif defined USING_XLIB
				(EGLNativeDisplayType) ((OSWindow_X*)windowHandle)->getDisplay()
			#elif defined USING_WINCLS
				(EGLNativeDisplayType) ((OSWindow_Win*)windowHandle)->getDeviceContext()
			#endif
			);
		if(mDisplay==EGL_NO_DISPLAY){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"No display matching is available."); return false;
		}  LOG4CPLUS_INFO (logger,_EGLstr<<"Display is received.");

		// Initialization must be performed once for each display prior to calling most other EGL or client API functions.
		if(eglInitialize(mDisplay, &mVersion_Major, &mVersion_Minor)==EGL_FALSE) {
			LOG4CPLUS_FATAL(logger,_EGLstr<<"Initialization failed. Error: "<<getErrorStr(eglGetError())); return false;
		}  LOG4CPLUS_INFO (logger,_EGLstr<<"EGL is initialized.");

		if(eglBindAPI(EGL_OPENGL_ES_API)==EGL_FALSE ){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"OpenGL ES API bind failed. Error: "<<getErrorStr(eglGetError()));
			release(); return false;
		}  LOG4CPLUS_INFO (logger,_EGLstr<<"OPENGL ES API is bound.");

		// EGL info
		const char* glString;
		glString    = (const char*) eglQueryString( mDisplay, EGL_CLIENT_APIS );
		mClientAPIs = (char*)malloc(strlen(glString)+1); strcpy((char*)mClientAPIs,glString);
		glString    = (const char*) eglQueryString( mDisplay, EGL_EXTENSIONS  );
		mExtensions = (char*)malloc(strlen(glString)+1); strcpy((char*)mExtensions,glString);
		glString    = (const char*) eglQueryString( mDisplay, EGL_VENDOR      );
		mVendor     = (char*)malloc(strlen(glString)+1); strcpy((char*)mVendor,glString);
		glString    = (const char*) eglQueryString( mDisplay, EGL_VERSION     );
		mVersion    = (char*)malloc(strlen(glString)+1); strcpy((char*)mVersion,glString);

		// get number of total supported EGL configs
		EGLint configCount;
		eglGetConfigs(mDisplay,0,0,&configCount);

		// log all config data
		EGLConfig* configList = (EGLConfig*)malloc(configCount*sizeof(EGLConfig));
		eglGetConfigs(mDisplay,configList,configCount,&configCount);
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),_EGLstr<<"Configs ALL:");
		for(EGLint i=0;i<configCount;++i) logEGLConfigAttribs(configList[i]);

		testEGLError();

		//////////////////////////////////////////////////////////////////////////
		// PRE-DEFINED VALUES
		EGLint configAttribs[32];
		for(int i=0;i>32;++i) configAttribs[i] = EGL_NONE;
		size_t cfgId=0;
		configAttribs[cfgId++] = EGL_SURFACE_TYPE;      configAttribs[cfgId++] = EGL_WINDOW_BIT;
		configAttribs[cfgId++] = EGL_RENDERABLE_TYPE;   configAttribs[cfgId++] = EGL_OPENGL_ES2_BIT;
		configAttribs[cfgId++] = EGL_NATIVE_RENDERABLE; configAttribs[cfgId++] = EGL_FALSE;
		configAttribs[cfgId++] = EGL_COLOR_BUFFER_TYPE; configAttribs[cfgId++] = EGL_RGB_BUFFER;
		//////////////////////////////////////////////////////////////////////////
		// CONFIGURABLE VALUES
		if(mParamList[GLCntxtParRedRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_RED_SIZE;     configAttribs[cfgId++] = mParamList[GLCntxtParRedRes];
		if(mParamList[GLCntxtParGreenRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_GREEN_SIZE;   configAttribs[cfgId++] = mParamList[GLCntxtParGreenRes];
		if(mParamList[GLCntxtParBlueRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_BLUE_SIZE;    configAttribs[cfgId++] = mParamList[GLCntxtParBlueRes];
		if(mParamList[GLCntxtParAlphaRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_ALPHA_SIZE;   configAttribs[cfgId++] = mParamList[GLCntxtParAlphaRes];
		if(mParamList[GLCntxtParDepthRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_DEPTH_SIZE;   configAttribs[cfgId++] = mParamList[GLCntxtParDepthRes];
		if(mParamList[GLCntxtParStencilRes]!=GLCntxtParDontCare)
			configAttribs[cfgId++] = EGL_STENCIL_SIZE; configAttribs[cfgId++] = mParamList[GLCntxtParStencilRes];
		if(mParamList[GLCntxtParSampleCount]!=0){
			configAttribs[cfgId++] = EGL_SAMPLE_BUFFERS;
			configAttribs[cfgId++] = 1;
			configAttribs[cfgId++] = EGL_SAMPLES;
			configAttribs[cfgId++] = mParamList[GLCntxtParSampleCount];
		}
		configAttribs[cfgId++] = EGL_NONE;
		//////////////////////////////////////////////////////////////////////////
		// IGNORED CONTEXT OPTIONS
		if(mParamList[GLCntxtParProfile]!=GLContextProfile_DontCare)
			LOG4CPLUS_WARN(logger,_EGLstr<<"-Core profile- context parameter is not supported.");
		if(mParamList[GLCntxtParStereoBuffer]==GLCntxtParTrue)
			LOG4CPLUS_WARN(logger,_EGLstr<<"-Stereo buffer- context parameter is not supported.");
		if(mParamList[GLCntxtParGLVersionMaj]!=GLCntxtParDontCare || 
			mParamList[GLCntxtParGLVersionMin]!=GLCntxtParDontCare)
			LOG4CPLUS_WARN(logger,_EGLstr<<"-OpenGL version- context parameter is not supported.");

		LOG4CPLUS_INFO(logger,_EGLstr<<"Config attributes REQUESTED: "
			"[R:"<<mParamList[GLCntxtParRedRes]<<" G:"<<mParamList[GLCntxtParGreenRes]<<
			" B:"<<mParamList[GLCntxtParBlueRes]<<" A:"<<mParamList[GLCntxtParAlphaRes]<<"] "
			"[D:"<<mParamList[GLCntxtParDepthRes]<<" S:"<<mParamList[GLCntxtParStencilRes]<<"] "
			"MS:"<<mParamList[GLCntxtParSampleCount]);

		int foundConfig;
		if(eglChooseConfig(mDisplay, configAttribs, configList, configCount, &foundConfig) == EGL_FALSE) {
			LOG4CPLUS_FATAL(logger,_EGLstr<<"ChooseConfig failed. Error info: "<<getErrorStr(eglGetError()));
			release(); free(configList); return false;
		}
		if(foundConfig==0){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"No matching config found using given attributes."); 
			release(); free(configList); return false;
		}
		mSelectedConfig = configList[0]; // The "best" one as ordered by EGL
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),_EGLstr<<"Configs CHOSEN:");
		for(EGLint i=0;i<foundConfig;++i) logEGLConfigAttribs(configList[i]);
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),_EGLstr<<"The config SELECTED:");
		logEGLConfigAttribs(mSelectedConfig);
		free(configList);

		testEGLError();

		// FIX FOR BROKEN DRIVERS
		// Some PowerVR drivers may not accept EGL_RENDER_BUFFER configuration and result in error
		// TODO: Fix later
		mParamList[GLCntxtParDoubleBuffer] = GLCntxtParDontCare;

		EGLint configSurfaceAttribs[3];
		size_t attribId=0;
		switch(mParamList[GLCntxtParDoubleBuffer]){
			default: break;
			case GLCntxtParFalse:
				configSurfaceAttribs[attribId++] = EGL_RENDER_BUFFER;
				configSurfaceAttribs[attribId++] = EGL_SINGLE_BUFFER;
				break;
			case GLCntxtParTrue:
				configSurfaceAttribs[attribId++] = EGL_RENDER_BUFFER;
				configSurfaceAttribs[attribId++] = EGL_BACK_BUFFER;
				break;
		}
		configSurfaceAttribs[attribId] = EGL_NONE;
		mSurface = eglCreateWindowSurface(mDisplay, mSelectedConfig, 
			#if RENG_PLATFORM == RENG_PLATFORM_OMAP
				(EGLNativeWindowType)NULL,
			#elif defined USING_XLIB
				(EGLNativeWindowType)((OSWindow_X*)windowHandle)->getWindow(),
			#elif defined USING_WINCLS
				(EGLNativeWindowType)((OSWindow_Win*)windowHandle)->getWindowHandle(),
			#endif
			configSurfaceAttribs
			);
		if(mSurface == EGL_NO_SURFACE){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"CreateWindowSurface failed. Error info: "<<getErrorStr(eglGetError()));
			release();
			return false;
		}
		LOG4CPLUS_INFO(logger,_EGLstr<<"Window surface is created.");

		// Check if double or single buffered
		EGLint renderBufType;
		if(eglQueryContext(mDisplay,mGLContext,EGL_RENDER_BUFFER,&renderBufType)==EGL_FALSE){
			LOG4CPLUS_WARN(logger,_EGLstr<<"Driver Bug: Does not support context query for RENDER_BUFFER.");
			switch(mParamList[GLCntxtParDoubleBuffer]){
				case GLCntxtParFalse:    mDoubleBuffered = false;
				case GLCntxtParTrue:     mDoubleBuffered = true;
				case GLCntxtParDontCare: mDoubleBuffered = true; // assume double-buffering
			}
		} else {
			mDoubleBuffered = !(renderBufType==EGL_SINGLE_BUFFER);
		}

		EGLint pi32ContextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
		mGLContext = eglCreateContext(mDisplay, mSelectedConfig, EGL_NO_CONTEXT, pi32ContextAttribs);
		if(mGLContext == EGL_NO_CONTEXT){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"CreateContext failed. Error info: "<<getErrorStr(eglGetError()));
			release(); return false;
		}
		LOG4CPLUS_INFO(logger,_EGLstr<<"OpenGL Context is created.");

		if(eglMakeCurrent(mDisplay, mSurface, mSurface, mGLContext) == EGL_FALSE){
			LOG4CPLUS_FATAL(logger,_EGLstr<<"MakeCurrent failed. Error info: "<<getErrorStr(eglGetError()));
			release(); return false;
		}

		// set VSynch
		switch(mParamList[GLCntxtParVSynch]){
			case GLCntxtParDontCare: break;
			case GLCntxtParFalse: setVSyncEnabled(false); break;
			case GLCntxtParTrue: setVSyncEnabled(true); break;
		}

#ifdef USING_WINCLS
		ShowWindow(((OSWindow_Win*)windowHandle)->getWindowHandle(),SW_SHOW);
		SetForegroundWindow(((OSWindow_Win*)windowHandle)->getWindowHandle());	// Slightly Higher Priority
		SetFocus(((OSWindow_Win*)windowHandle)->getWindowHandle());				// Sets Keyboard Focus To The Window
#endif

		updateResolutions();
		mIsInited = true;
		return true;
	}
	bool GLContext_EGL::release(){
		if(mDisplay==0) return true;
		eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT) ;
		eglTerminate(mDisplay);
		mIsInited = false;
		return true;
	}
	bool GLContext_EGL::swapBuffers(){
		if(!mDoubleBuffered) return true;
		return 0 != eglSwapBuffers(mDisplay, mSurface);
	}

	void GLContext_EGL::logConfig(){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"EGL Version     : " << mVersion);
		LOG4CPLUS_INFO(logger,"EGL Vendor      : " << mVendor);
		LOG4CPLUS_INFO(logger,"EGL Extensions  : " << mExtensions);
		LOG4CPLUS_INFO(logger,"EGL Client API's: " << mClientAPIs);
	}

	bool GLContext_EGL::testEGLError() {
		EGLint iErr = eglGetError();
		if (iErr != EGL_SUCCESS) {
			LOG4CPLUS_INFO(Logger::getInstance("RSys"),_EGLstr<<"Error:"<<getErrorStr(iErr));
			return false;
		}
		return true;
	}

	void GLContext_EGL::logEGLConfigAttribs(EGLConfig cfg){
		EGLint bufferSize(10),redSize(10),greenSize(10),blueSize(10),alphaSize(10),lumSize(10);
		EGLint confID(10),depthSize(10),stnclSize(10),multiSamp(10),caveat(10),samples(10);
		EGLint buffType(10),surfType(10),rendType(10);
		EGLint minInterval(10), maxInterval(10);
		eglGetConfigAttrib(mDisplay,cfg,EGL_CONFIG_ID,     &confID    );
		eglGetConfigAttrib(mDisplay,cfg,EGL_BUFFER_SIZE,   &bufferSize);
		eglGetConfigAttrib(mDisplay,cfg,EGL_RED_SIZE,      &redSize   );
		eglGetConfigAttrib(mDisplay,cfg,EGL_GREEN_SIZE,    &greenSize );
		eglGetConfigAttrib(mDisplay,cfg,EGL_BLUE_SIZE,     &blueSize  );
		eglGetConfigAttrib(mDisplay,cfg,EGL_ALPHA_SIZE,    &alphaSize );
		eglGetConfigAttrib(mDisplay,cfg,EGL_LUMINANCE_SIZE,&lumSize   );
		eglGetConfigAttrib(mDisplay,cfg,EGL_DEPTH_SIZE,    &depthSize );
		eglGetConfigAttrib(mDisplay,cfg,EGL_STENCIL_SIZE,  &stnclSize );
		eglGetConfigAttrib(mDisplay,cfg,EGL_SAMPLE_BUFFERS,&multiSamp );
		eglGetConfigAttrib(mDisplay,cfg,EGL_SAMPLES,       &samples   );
		eglGetConfigAttrib(mDisplay,cfg,EGL_CONFIG_CAVEAT, &caveat    );
		eglGetConfigAttrib(mDisplay,cfg,EGL_COLOR_BUFFER_TYPE, &buffType );
		eglGetConfigAttrib(mDisplay,cfg,EGL_SURFACE_TYPE,      &surfType );
		eglGetConfigAttrib(mDisplay,cfg,EGL_MAX_SWAP_INTERVAL, &maxInterval );
		eglGetConfigAttrib(mDisplay,cfg,EGL_MIN_SWAP_INTERVAL, &minInterval );

		LOG4CPLUS_INFO(Logger::getInstance("RSys")," "
			"ID:"<<confID<<" "
			
			"[R:"<<redSize<<" G:"<<greenSize<<" B:"<<blueSize<<" A:"<<alphaSize<<" L:"<<lumSize<<" Total:"<<bufferSize<<"] "
			
			"[D:"<<depthSize<<((depthSize<10)?" ":"")<<" S:"<<stnclSize<<"] "
			
//			"[MS:"<<(multiSamp?"Y-":"N-")<<(multiSamp?samples:0)<<"] "<<
			"[MS:"<<(multiSamp?samples:0)<<"] "<<
			
			((caveat==EGL_SLOW_CONFIG)?"Slow ":"")<<
			((caveat==EGL_NON_CONFORMANT_CONFIG)?"NonConform. ":"")<<

			"[Surface:"<<
			((surfType&EGL_WINDOW_BIT)?"Window ":"")<<
			((surfType&EGL_PIXMAP_BIT)?"Pixmap ":"")<<
			((surfType&EGL_PBUFFER_BIT)?"PBuffer ":"")<<"] "

			"[Renderable:"<<
			((rendType&EGL_OPENGL_BIT)?"ESx ":"")<<
			((rendType&EGL_OPENGL_ES_BIT)?"ES1 ":"")<<
			((rendType&EGL_OPENGL_ES2_BIT)?"ES2 ":"")<<
			((rendType&EGL_OPENVG_BIT)?"VG ":"")<<"] "

			"[SwapInt:"<<minInterval<<"-"<<maxInterval<<"]"
			);
	}
	void GLContext_EGL::updateResolutions(){
		EGLint redSize(10),greenSize(10),blueSize(10),alphaSize(10);
		EGLint depthSize(10),stnclSize(10),multiSamp(10),samples(10);
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_RED_SIZE,      &redSize   );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_GREEN_SIZE,    &greenSize );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_BLUE_SIZE,     &blueSize  );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_ALPHA_SIZE,    &alphaSize );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_DEPTH_SIZE,    &depthSize );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_STENCIL_SIZE,  &stnclSize );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_SAMPLE_BUFFERS,&multiSamp );
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_SAMPLES,       &samples   );
		mSamples                  = samples;
		mBitSize_Comp[RTC_Red]    = redSize;
		mBitSize_Comp[RTC_Green]  = greenSize;
		mBitSize_Comp[RTC_Blue]   = blueSize;
		mBitSize_Comp[RTC_Alpha]  = alphaSize;
		mBitSize_Comp[RTC_Depth]  = depthSize;
		mBitSize_Comp[RTC_Stencil]= stnclSize;
	}

	const char* GLContext_EGL::getErrorStr(EGLint errCode ){
		switch(errCode){
			case EGL_SUCCESS:
				return "Function succeeded.";
			case EGL_NOT_INITIALIZED:
				return "EGL is not initialized, or could not be initialized, for the specified display.";
			case EGL_BAD_ACCESS:
				return "EGL cannot access a requested resource.";
			case EGL_BAD_ALLOC:
				return "EGL failed to allocate resources for the requested operation.";
			case EGL_BAD_ATTRIBUTE:
				return "An unrecognized attribute or attribute value as passed in an attribute list.";
			case EGL_BAD_CONTEXT:
				return "An EGLContext argument does not name a valid EGLContext.";
			case EGL_BAD_CONFIG:
				return "An EGLConfig argument does not name a valid EGLConfig.";
			case EGL_BAD_CURRENT_SURFACE:
				return "The current surface of the calling thread is a window, pbuffer, or pixmap that is no longer valid.";
			case EGL_BAD_DISPLAY:
				return "An EGLDisplay argument does not name a valid EGLDisplay; or, EGL is not initialized on the specified EGLDisplay.";
			case EGL_BAD_SURFACE:
				return "An EGLSurface argument does not name a valid surface (window, pbuffer, or pixmap) configured for rendering.";
			case EGL_BAD_MATCH:
				return "Arguments are inconsistent.";
			case EGL_BAD_PARAMETER:
				return "One or more argument values are invalid.";
			case EGL_BAD_NATIVE_PIXMAP:
				return "An EGLNativePixmapType argument does not refer to a valid native pixmap.";
			case EGL_BAD_NATIVE_WINDOW:
				return "An EGLNativeWindowType argument does not refer to a valid native window.";
			case EGL_CONTEXT_LOST:
				return "A power management event has occurred. The application must destroy all contexts "
				       "and re-initialise client API state and objects to continue rendering, ";
		}
		return "";
	}

	void GLContext_EGL::setVSyncEnabled(bool flag){
		EGLint minInterval(10), maxInterval(10);
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_MIN_SWAP_INTERVAL, &minInterval);
		eglGetConfigAttrib(mDisplay,mSelectedConfig,EGL_MAX_SWAP_INTERVAL, &maxInterval);
		if(minInterval!=0||maxInterval<1) return;
		eglSwapInterval(mDisplay,flag);
		mVSynchEnabled = flag;
	}
	bool GLContext_EGL::isVSyncEnabled() const{
		return mVSynchEnabled;
	}

} // namespace REng

#endif // USING_EGL
