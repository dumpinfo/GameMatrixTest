/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/sys/GLContext_WGL.h"

#ifdef USING_WGL

#include "REng/sys/OSWindow_XWin.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#ifndef ERROR_INVALID_VERSION_ARB
#define ERROR_INVALID_VERSION_ARB 0x2095
#endif
#ifndef ERROR_INVALID_PROFILE_ARB
#define ERROR_INVALID_PROFILE_ARB 0x2096
#endif

namespace REng{

	static const char* _WGLstr = "WGL | ";

	GLContext_WGL::GLContext_WGL()
		:mGLContext(NULL)
		,mExtentionInfoList(0)
		,mExtentionCount(0)
		,wglCreateContextAttribs(NULL)
		,wglGetExtString(NULL)
		,wglGetPixelFormatAttribiv(NULL)
		,wglGetPixelFormatAttribfv(NULL)
		,wglChoosePixelFormat(NULL)
		,wglSwapInterval(NULL)
		,wglGetSwapInterval(NULL)
		{ ; }

	bool GLContext_WGL::init(OSWindow* windowHandle){
		mWindowHandle = windowHandle;

		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,_WGLstr<<"Initializing...");

		testWGLError();

		// set up initial old-fashioned pixel format descriptor data
		PIXELFORMATDESCRIPTOR pfd; setPixelFormatFlags(pfd);
		if(!choosePixelFormat(pfd,mSelectedPixelFormat)) return false;
		if(!setPixelFormat(pfd,mSelectedPixelFormat)) return false;
		testWGLError();

		if(!createGLContext(mGLContext)) return false;
		if(!setGLContextCurrent(mGLContext)) return false;
		testWGLError();

		updateFuncPointers();
		readExtensions();

		wglDeleteContext(mGLContext);
		if(wglCreateContextAttribs==NULL || wglGetExtString==NULL || wglChoosePixelFormat==NULL) {
			LOG4CPLUS_ERROR(logger,_WGLstr<<"Cannot get Proc Adress for required function pointers."); return false;
		}

		LOG4CPLUS_INFO(logger,_WGLstr<<"Releasing old OpenGL context and window "
			"to create a richer&up-to-date render surface.");
		this->release();
		((OSWindow_Win*)mWindowHandle)->destroyWindow_KeepRegistry();
		LOG4CPLUS_INFO(logger,_WGLstr<<"Creating new window...");
		mWindowHandle->createWindow(
			mWindowHandle->getPosition(),
			mWindowHandle->isFullscreen(),
			mWindowHandle->getWindowTitle());

		testWGLError();

		int pfAttribs[64]; memset(pfAttribs,0,sizeof(int)*64);
		int chosenPixelFormats[32];
		uint chosenPixelFormatCount;
		setPixelFormatAttribs(pfAttribs);
		bool success = (0!=wglChoosePixelFormat(
			(((OSWindow_Win*)mWindowHandle)->getDeviceContext()),
//			iAttributes,
			pfAttribs,
			NULL, // no floating point args
			32,
			chosenPixelFormats,
			&chosenPixelFormatCount));
		// TODO: choose the best of the retrieved formats
		if(chosenPixelFormatCount>0) {
			mSelectedPixelFormat = chosenPixelFormats[0];
			LOG4CPLUS_INFO(Logger::getInstance("RSys"),"WGL | Pixel Formats CHOSEN:");
			for(uint i=0; i<chosenPixelFormatCount;++i) logPixelFormat(chosenPixelFormats[i]);
		} else {
			LOG4CPLUS_INFO(Logger::getInstance("RSys"),"WGL | New PixelFormat cannot be chosen with given configs.");
		}
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),"WGL | The PixelFormat SELECTED:");
		logPixelFormat(mSelectedPixelFormat);

		// we can reference our old pfd
		if(!setPixelFormat(pfd,mSelectedPixelFormat)) return false;
		testWGLError();

		int contextAttribs[16];
		setContextAttribs(contextAttribs);

		if(!(mGLContext=wglCreateContextAttribs(((OSWindow_Win*)mWindowHandle)->getDeviceContext(),0, contextAttribs))){
			LOG4CPLUS_FATAL(logger,_WGLstr<<"CreateContext failed. Error: "<<getErrorStr(::GetLastError()));
		}
		if(!setGLContextCurrent(mGLContext)) return false;

		LOG4CPLUS_INFO(logger,_WGLstr<<"Final OpenGL Context is created.");

		ShowWindow(((OSWindow_Win*)mWindowHandle)->getWindowHandle(),SW_SHOW);
		SetForegroundWindow(((OSWindow_Win*)mWindowHandle)->getWindowHandle()); // Slightly Higher Priority
		SetFocus(((OSWindow_Win*)mWindowHandle)->getWindowHandle());				// Sets Keyboard Focus To The Window

		updateResolutions();
		switch(mParamList[GLCntxtParVSynch]){
			case GLCntxtParDontCare: break;
			case GLCntxtParFalse: setVSyncEnabled(false); break;
			case GLCntxtParTrue: setVSyncEnabled(true); break;
		}
		switch(mParamList[GLCntxtParDoubleBuffer]){
			case GLCntxtParFalse:    mDoubleBuffered = false;
			case GLCntxtParTrue:     mDoubleBuffered = true;
			case GLCntxtParDontCare: mDoubleBuffered = true; // TODO: Read from WGL
		}
		mIsInited = true;
		return true;
	}

	bool GLContext_WGL::release(){
		Logger logger = Logger::getInstance("RSys");
		if(!mIsInited) return true;
		if(!mGLContext) return true;

		if(mWindowHandle->isFullscreen()){
			::ChangeDisplaySettings(NULL,0);
			::ShowCursor(TRUE);
		}
		if(!wglMakeCurrent(NULL,NULL)) {
			LOG4CPLUS_ERROR(logger,_WGLstr<<"Releasing Device Context Failed."); return false;
		}
		if(!wglDeleteContext(mGLContext)) {
			LOG4CPLUS_ERROR(logger,_WGLstr<<"Deleting Rendering Context Failed."); return false;
		}
		mGLContext=0;
		mIsInited = false;
		return true;
	}

	bool GLContext_WGL::swapBuffers(){
		if(!mDoubleBuffered) return true;
		return ::SwapBuffers(((OSWindow_Win*)mWindowHandle)->getDeviceContext())!=0;
	}

	const char* GLContext_WGL::getErrorStr(DWORD errCode){
		switch(errCode){
			case ERROR_INVALID_VERSION_ARB:  return "Invalid version";
			case ERROR_INVALID_PROFILE_ARB:  return "Invalid profile";
			case ERROR_INVALID_PARAMETER:    return "Invalid parameter";
			case ERROR_INVALID_OPERATION:    return "Invalid operation";
			case ERROR_DC_NOT_FOUND:         return "Device context not found";
			case ERROR_INVALID_PIXEL_FORMAT: return "Invalid pixel format";
			case ERROR_NO_SYSTEM_RESOURCES:  return "No system resources available";
			case ERROR_INCOMPATIBLE_DEVICE_CONTEXTS_ARB: return "Incompatible device contexts";
			default: break;
		}
		return "?";
	}
	bool GLContext_WGL::testWGLError(){
		DWORD iErr=::GetLastError();
		if(iErr != 0) {
			LOG4CPLUS_INFO(Logger::getInstance("RSys"),"WGL | Error:"<<getErrorStr(iErr)); return false;
		} return true;
	}

	void GLContext_WGL::readExtensions(){
		if(mExtentionInfoList) return; // we have already read extensions
		const char *extensions = ((char*(__stdcall*)(HDC))wglGetExtString)(wglGetCurrentDC());
		// we need a non-const string
		char* cExt = (char*) malloc((strlen(extensions)+1) * sizeof(char));
		strcpy(cExt,extensions);
		// learn number of tokens(extensions) in the string
		const char* delim = " ";
		char* c = strtok(cExt,delim);
		for(mExtentionCount=0 ; c!=NULL ; ++mExtentionCount) c=strtok(NULL,delim);
		mExtentionInfoList = (char**) malloc(mExtentionCount * sizeof(char*));
		// re-fill the cExt string
		strcpy(cExt,extensions);
		// copy the extension strings to mExtentionInfoList
		c = strtok(cExt,delim);
		for(size_t i=0 ; c!=NULL; ++i) {
			size_t sLen = strlen(c);
			mExtentionInfoList[i] = (char*) malloc((sLen+1) * sizeof(char));
			strcpy(mExtentionInfoList[i],c);
			c = strtok(NULL,delim);
		}
		free(cExt);
	}

	bool GLContext_WGL::isExtensionSupported(const char *extension){
		for(size_t i=0; i<mExtentionCount; ++i){
			if(strcmp(mExtentionInfoList[i],extension)==0) return true;
		} return false;
	}

	void GLContext_WGL::logConfig(){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,_WGLstr<<"Supported Extensions:");
		for(size_t i=0 ; i<mExtentionCount ; ++i) LOG4CPLUS_INFO(logger,"\t"<<i<<" "<<mExtentionInfoList[i]);
	}

	void GLContext_WGL::updateFuncPointers(){
		wglCreateContextAttribs = (PFNWGLCREATECONTEXTATTRIBSARBPROC) wglGetProcAddress("wglCreateContextAttribsARB");
		wglGetExtString = (PFNWGLGETEXTENSIONSSTRINGARBPROC) wglGetProcAddress("wglGetExtensionsStringARB");
		wglGetPixelFormatAttribiv = (PFNWGLGETPIXELFORMATATTRIBIVARBPROC) wglGetProcAddress("wglGetPixelFormatAttribivARB");
		wglGetPixelFormatAttribfv = (PFNWGLGETPIXELFORMATATTRIBFVARBPROC) wglGetProcAddress("wglGetPixelFormatAttribfvARB");
		wglChoosePixelFormat = (PFNWGLCHOOSEPIXELFORMATARBPROC) wglGetProcAddress("wglChoosePixelFormatARB");
		wglSwapInterval = (PFNWGLSWAPINTERVALEXTPROC) wglGetProcAddress("wglSwapIntervalEXT");
		wglGetSwapInterval = (PFNWGLGETSWAPINTERVALEXTPROC) wglGetProcAddress("wglGetSwapIntervalEXT");
	}

	bool GLContext_WGL::choosePixelFormat(PIXELFORMATDESCRIPTOR& pfd,int& pixFormatIndex){
		if(!(pixFormatIndex=ChoosePixelFormat(((OSWindow_Win*)mWindowHandle)->getDeviceContext(),&pfd))) {
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),_WGLstr<<"Can't find a suitable PixelFormat"); return false;
		}	LOG4CPLUS_INFO (Logger::getInstance("RSys"),_WGLstr<<"A suitable PixalFormat is found."); return true;
	}
	bool GLContext_WGL::setPixelFormat(PIXELFORMATDESCRIPTOR& pfd, int& pixFormatIndex){
		if(!SetPixelFormat(((OSWindow_Win*)mWindowHandle)->getDeviceContext(),pixFormatIndex,&pfd)) {
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),_WGLstr<<"Can't set the PixelFormat."); return false;
		}	LOG4CPLUS_INFO (Logger::getInstance("RSys"),_WGLstr<<"PixelFormat is set."); return true;
	}
	bool GLContext_WGL::createGLContext(HGLRC& context){
		if(!(context=wglCreateContext(((OSWindow_Win*)mWindowHandle)->getDeviceContext()))) {
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),_WGLstr<<"Can't create openGL context."); return false;
		}	LOG4CPLUS_INFO (Logger::getInstance("RSys"),_WGLstr<<"OpenGL context is created."); return true;
	}
	bool GLContext_WGL::setGLContextCurrent(HGLRC& context){
		if(!wglMakeCurrent(((OSWindow_Win*)mWindowHandle)->getDeviceContext(),context)) {
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),_WGLstr<<"Can't activate GL context."); return false;
		} return true;
	}

	void GLContext_WGL::setPixelFormatFlags(PIXELFORMATDESCRIPTOR& pfd){
		//////////////////////////////////////////////////////////////////////////
		// PRE-DEFINED VALUES
		pfd.nSize      = sizeof(PIXELFORMATDESCRIPTOR);
		pfd.nVersion   = 1;
		pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL; // Format Must Support Window and OpenGL
		pfd.iPixelType = PFD_TYPE_RGBA;
		pfd.iLayerType = PFD_MAIN_PLANE;
		pfd.cRedBits   =0; pfd.cRedShift  = 0; pfd.cGreenBits = 0; pfd.cGreenShift = 0;
		pfd.cBlueBits  =0; pfd.cBlueShift = 0; pfd.cAlphaBits = 0; pfd.cAlphaShift = 0;
		pfd.cAccumBits =0; pfd.cAccumRedBits=0; pfd.cAccumGreenBits=0; pfd.cAccumBlueBits=0; pfd.cAccumAlphaBits=0;
		pfd.cAuxBuffers=0;
		pfd.bReserved=0; pfd.dwLayerMask=0; pfd.dwVisibleMask=0; pfd.dwDamageMask=0; // Ignored fields
		//////////////////////////////////////////////////////////////////////////
		// CONFIGURABLE VALUES
		pfd.cColorBits   = getParamTotalColorRes();
		pfd.cDepthBits = 0;
		if(mParamList[GLCntxtParDepthRes]!=GLCntxtParDontCare)
			pfd.cDepthBits   = mParamList[GLCntxtParDepthRes];
		pfd.cStencilBits = 0;
		if(mParamList[GLCntxtParStencilRes]!=GLCntxtParDontCare)
			pfd.cStencilBits = mParamList[GLCntxtParStencilRes];
		switch(mParamList[GLCntxtParDoubleBuffer]){
			default: break;
			case GLCntxtParTrue:     pfd.dwFlags = pfd.dwFlags|PFD_DOUBLEBUFFER; break;
			case GLCntxtParDontCare: pfd.dwFlags = pfd.dwFlags|PFD_DOUBLEBUFFER_DONTCARE; break;
		}
		switch(mParamList[GLCntxtParStereoBuffer]){
			default: break;
			case GLCntxtParTrue:     pfd.dwFlags = pfd.dwFlags|PFD_STEREO; break;
			case GLCntxtParDontCare: pfd.dwFlags = pfd.dwFlags|PFD_STEREO_DONTCARE; break;
		}
	}

	void GLContext_WGL::setContextAttribs(int* contextAttribs){
		size_t attribIndex = 0;
		if(mParamList[GLCntxtParGLVersionMaj]!=GLCntxtParDontCare){
			contextAttribs[attribIndex++] = WGL_CONTEXT_MAJOR_VERSION_ARB;
			contextAttribs[attribIndex++] = mParamList[GLCntxtParGLVersionMaj];
		}
		if(mParamList[GLCntxtParGLVersionMin]!=GLCntxtParDontCare){
			contextAttribs[attribIndex++] = WGL_CONTEXT_MINOR_VERSION_ARB;
			contextAttribs[attribIndex++] = mParamList[GLCntxtParGLVersionMin];
		}
		switch(mParamList[GLCntxtParProfile]){
			default: break;
			case GLContextProfile_DontCare: break;
			case GLContextProfile_ES:
				if(!isExtensionSupported("WGL_EXT_create_context_es2_profile")){
					LOG4CPLUS_WARN(Logger::getInstance("RSys"),_WGLstr<<"ES contexts are unsupported.");
				} else {
					contextAttribs[attribIndex++] = WGL_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_ES;
				}
				break;
			case GLContextProfile_Core:
				// only valid for OpenGL version > 3.2
				if(mParamList[GLCntxtParGLVersionMaj]!=3||mParamList[GLCntxtParGLVersionMin]>=2){
					contextAttribs[attribIndex++] = WGL_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_Core;
				}
				break;
			case GLContextProfile_Compatibility:
				// only valid for OpenGL version > 3.2
				if(mParamList[GLCntxtParGLVersionMaj]!=3||mParamList[GLCntxtParGLVersionMin]>=2){
					contextAttribs[attribIndex++] = WGL_CONTEXT_PROFILE_MASK_ARB;
					contextAttribs[attribIndex++] = GLContextProfile_Compatibility;
				}
				break;
		}
		// If requested OpenGL version is less than 3.2, forward-only compatible profiles 
		// is managed by additional bit parameters
		switch(mParamList[GLCntxtParProfile]){
			default: break;
			case GLContextProfile_Core:
				contextAttribs[attribIndex++] = WGL_CONTEXT_FLAGS_ARB;
				contextAttribs[attribIndex++] = WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB;
				break;
		}
		contextAttribs[attribIndex++] = 0;
	}
	void GLContext_WGL::setPixelFormatAttribs(int* pfAttrib){
		size_t i = 0;
		//////////////////////////////////////////////////////////////////////////
		// PRE-DEFINED VALUES
		pfAttrib[i++] = WGL_DRAW_TO_WINDOW_ARB; pfAttrib[i++] = GL_TRUE;
		pfAttrib[i++] = WGL_DRAW_TO_BITMAP_ARB; pfAttrib[i++] = GL_FALSE;
		pfAttrib[i++] = WGL_SUPPORT_OPENGL_ARB; pfAttrib[i++] = GL_TRUE;
		pfAttrib[i++] = WGL_SUPPORT_GDI_ARB;    pfAttrib[i++] = GL_FALSE;
		pfAttrib[i++] = WGL_ACCELERATION_ARB;   pfAttrib[i++] = WGL_FULL_ACCELERATION_ARB;
		pfAttrib[i++] = WGL_PIXEL_TYPE_ARB;     pfAttrib[i++] = WGL_TYPE_RGBA_ARB;
		// No configs may match if they are set to 0. Don't know why...
//		pfAttrib[i++] = WGL_ACCUM_BITS_ARB;       pfAttrib[i++] = 0;
//		pfAttrib[i++] = WGL_ACCUM_RED_BITS_ARB;   pfAttrib[i++] = 0;
//		pfAttrib[i++] = WGL_ACCUM_GREEN_BITS_ARB; pfAttrib[i++] = 0;
//		pfAttrib[i++] = WGL_ACCUM_BLUE_BITS_ARB;  pfAttrib[i++] = 0;
//		pfAttrib[i++] = WGL_ACCUM_ALPHA_BITS_ARB; pfAttrib[i++] = 0;
//		pfAttrib[i++] = WGL_AUX_BUFFERS_ARB;      pfAttrib[i++] = 0;
		//////////////////////////////////////////////////////////////////////////
		// CONFIGURABLE VALUES
		pfAttrib[i++] = WGL_COLOR_BITS_ARB;   pfAttrib[i++] = getParamTotalColorRes();
		if(mParamList[GLCntxtParDepthRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_DEPTH_BITS_ARB;   pfAttrib[i++] = mParamList[GLCntxtParDepthRes];
		if(mParamList[GLCntxtParStencilRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_STENCIL_BITS_ARB; pfAttrib[i++] = mParamList[GLCntxtParStencilRes];
		if(mParamList[GLCntxtParRedRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_RED_BITS_ARB;     pfAttrib[i++] = mParamList[GLCntxtParRedRes];
		if(mParamList[GLCntxtParGreenRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_GREEN_BITS_ARB;   pfAttrib[i++] = mParamList[GLCntxtParGreenRes];
		if(mParamList[GLCntxtParBlueRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_BLUE_BITS_ARB;    pfAttrib[i++] = mParamList[GLCntxtParBlueRes];
		if(mParamList[GLCntxtParAlphaRes]!=GLCntxtParDontCare)
			pfAttrib[i++] = WGL_ALPHA_BITS_ARB;   pfAttrib[i++] = mParamList[GLCntxtParAlphaRes];
		if(mParamList[GLCntxtParSampleCount]!=0){
			pfAttrib[i++] = WGL_SAMPLE_BUFFERS_ARB;
			pfAttrib[i++] = GL_TRUE;
			pfAttrib[i++] = WGL_SAMPLES_ARB;
			pfAttrib[i++] = mParamList[GLCntxtParSampleCount];
		} else {
			pfAttrib[i++] = WGL_SAMPLE_BUFFERS_ARB;
			pfAttrib[i++] = GL_FALSE;
			pfAttrib[i++] = WGL_SAMPLES_ARB;
			pfAttrib[i++] = 0;
		}
		switch(mParamList[GLCntxtParDoubleBuffer]){
			case GLCntxtParDontCare: break;
			case GLCntxtParFalse:
				pfAttrib[i++] = WGL_DOUBLE_BUFFER_ARB;  
				pfAttrib[i++] = GL_FALSE;
				break;
			case GLCntxtParTrue:
				pfAttrib[i++] = WGL_DOUBLE_BUFFER_ARB;  
				pfAttrib[i++] = GL_TRUE;
				break;
			default: break;
		}
		switch(mParamList[GLCntxtParStereoBuffer]){
			case GLCntxtParDontCare: break;
			case GLCntxtParFalse:
				pfAttrib[i++] = WGL_STEREO_ARB;  
				pfAttrib[i++] = GL_FALSE;
				break;
			case GLCntxtParTrue:
				pfAttrib[i++] = WGL_STEREO_ARB;  
				pfAttrib[i++] = GL_TRUE;
				break;
			default: break;
		}
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),"WGL | Pixel format attributes REQUESTED: "
			"[R:"<<mParamList[GLCntxtParRedRes]<<" G:"<<mParamList[GLCntxtParGreenRes]<<
			" B:"<<mParamList[GLCntxtParBlueRes]<<" A:"<<mParamList[GLCntxtParAlphaRes]<<"] "
			"[D:"<<mParamList[GLCntxtParDepthRes]<<" S:"<<mParamList[GLCntxtParStencilRes]<<"] "
			"MS:"<<mParamList[GLCntxtParSampleCount]);
	}

	void GLContext_WGL::logAllSupportedPixelFormats(){
		bool success;
		int num_PixForm(0);
		const int attribs[] = {WGL_NUMBER_PIXEL_FORMATS_ARB};
		success = (0!=wglGetPixelFormatAttribiv(
			((OSWindow_Win*)mWindowHandle)->getDeviceContext(),
			0,0,1,attribs,&num_PixForm
			));
		// TOO MANY PIXEL FORMATS (>100), PROBABLY
	}
	void GLContext_WGL::logPixelFormat(int pixelFormat){
		const int attribs[] = {
			WGL_DOUBLE_BUFFER_ARB, //0
			WGL_STEREO_ARB,
			WGL_SAMPLES_ARB,       //2
			WGL_COLOR_BITS_ARB,
			WGL_RED_BITS_ARB,      //4
			WGL_RED_SHIFT_ARB,
			WGL_GREEN_BITS_ARB,    //6
			WGL_GREEN_SHIFT_ARB,
			WGL_BLUE_BITS_ARB,     //8
			WGL_BLUE_SHIFT_ARB,
			WGL_ALPHA_BITS_ARB,    //10
			WGL_ALPHA_SHIFT_ARB,
			WGL_DEPTH_BITS_ARB,    //12
			WGL_STENCIL_BITS_ARB,
			WGL_SAMPLE_BUFFERS_ARB,//14
			WGL_TRANSPARENT_ARB,
			WGL_ACCELERATION_ARB,  //16
			WGL_SWAP_METHOD_ARB,
			WGL_PIXEL_TYPE_ARB,    //18
			WGL_AUX_BUFFERS_ARB,
			WGL_ACCUM_BITS_ARB,    //20
		};
		int vals[32];
		bool success = (0!=wglGetPixelFormatAttribiv(
			((OSWindow_Win*)mWindowHandle)->getDeviceContext(),
			pixelFormat, 0, 21, attribs, vals));
		if(!success){
			return;
		}
		LOG4CPLUS_INFO(Logger::getInstance("RSys"),"  "
			"ID:"<<pixelFormat<<" "<<(pixelFormat<10?" ":"")<<
			"[R:"<<vals[4]<<" G:"<<vals[6]<<" B:"<<vals[8]<<" A:"<<vals[10]<<" Total:"<<vals[3]<<"] "
			"[D:"<<vals[12]<<" S:"<<vals[13]<<"] "
			"[MS:"<<(vals[14]?vals[2]:0)<<"] "<<(vals[2]<10?" ":"")<<
			"Aux:"<<vals[19]<<" "
			"Accum:"<<vals[20]<<" "<<
//			"Shifts:[R:"<<vals[5]<<" G:"<<vals[7]<<" B:"<<vals[8]<<" A:"<<vals[11]<<"] "
			(vals[0]?"DoubleBuf ":"SingleBuf ")<<(vals[1]?"StereoBuf ":"")<<
			(vals[15]?"Transparent ":"")<<
//			(vals[16]==WGL_NO_ACCELERATION_ARB?"NoAccel ":"")<<
//			(vals[16]==WGL_GENERIC_ACCELERATION_ARB?"GenericAccel ":"")<<
//			(vals[16]==WGL_FULL_ACCELERATION_ARB?"FullAccel ":"")<<
			(vals[17]==WGL_SWAP_EXCHANGE_ARB?"SwapExhange ":"")<<
			(vals[17]==WGL_SWAP_COPY_ARB?"SwapCopy ":"")<<
			(vals[17]==WGL_SWAP_UNDEFINED_ARB?"SwapUndef":"")<<
			""
			);
	}
	void GLContext_WGL::updateResolutions(){
		const int attribs[] = {
			WGL_SAMPLE_BUFFERS_ARB, WGL_SAMPLES_ARB, // 2
			WGL_RED_BITS_ARB, WGL_GREEN_BITS_ARB, WGL_BLUE_BITS_ARB, WGL_ALPHA_BITS_ARB, //6
			WGL_DEPTH_BITS_ARB, WGL_STENCIL_BITS_ARB, // 8
		};
		int vals[8];
		wglGetPixelFormatAttribiv(((OSWindow_Win*)mWindowHandle)->getDeviceContext(),mSelectedPixelFormat, 0, 8, attribs, vals);
		mSamples                  = vals[1];
		mBitSize_Comp[RTC_Red]    = vals[2];
		mBitSize_Comp[RTC_Green]  = vals[3];
		mBitSize_Comp[RTC_Blue]   = vals[4];
		mBitSize_Comp[RTC_Alpha]  = vals[5];
		mBitSize_Comp[RTC_Depth]  = vals[6];
		mBitSize_Comp[RTC_Stencil]= vals[7];
	}

	void GLContext_WGL::setVSyncEnabled(bool flag) {
		if(wglSwapInterval)wglSwapInterval(flag); //set interval to 1 -> enable
	}
	bool GLContext_WGL::isVSyncEnabled() const {
		// assume disabled (actually configured by the PC user)
		if(wglGetSwapInterval==NULL) return false;
		return (wglGetSwapInterval() != 0);
	}

} // namespace REng

#endif // USING_XLIB

