/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#include "REng/sys/OSWindow_XWin.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

#if defined USING_WINCLS

#include "REng/RenderSystem.h"

namespace REng {

	OSWindow_Win::OSWindow_Win(){
		hDC=NULL;
		hWnd=NULL;
		mIsClassRegistered = false;
		mClassName = "REngWindow";
	}
	OSWindow_Win::~OSWindow_Win(){;}

	HDC OSWindow_Win::getDeviceContext() const{ return hDC;  }
	HWND OSWindow_Win::getWindowHandle() const{ return hWnd; }

	bool OSWindow_Win::registerClass(){
		if (mIsClassRegistered) return true;

		hInstance      = GetModuleHandle(NULL);              // Grab An Instance For Our Window
		WNDCLASS	wc;
		wc.style       = CS_HREDRAW | CS_VREDRAW | CS_OWNDC; // Redraw On Size, And Own DC For Window.
		wc.lpfnWndProc = (WNDPROC) OSWindow_Win::WndProcHandler; // WndProc Handles Messages
		wc.cbClsExtra  = 0;                                  // No Extra Class Data
		wc.cbWndExtra  = 0;                                  // No Extra Window Data
		wc.hInstance   = hInstance;                          // Set The Instance
		wc.hIcon       = LoadIcon(NULL, IDI_WINLOGO);        // Load The Default Icon
		wc.hCursor     = LoadCursor(NULL, IDC_ARROW);        // Load The Arrow Pointer
		wc.hbrBackground = NULL;                             // No Background Required For GL
		wc.lpszMenuName  = NULL;                             // We Don't Want A Menu
		wc.lpszClassName = mClassName;                       // Class name (you want it, you got it.)

		mIsClassRegistered = ((::RegisterClass(&wc))!=0); // we do not care about atoms, they are way too small!
		return mIsClassRegistered;
	}

	bool OSWindow_Win::unregisterClass(){
		if(mIsClassRegistered == false) return true;
		if(!::UnregisterClass(mClassName,hInstance)) return false;
		hInstance=NULL;
		return true;
	}

	bool OSWindow_Win::createWindow(const RectI& position, bool fullscreen, const char* windowTitle){
		Logger logger = Logger::getInstance("RSys");

		DWORD		dwExStyle;  // Window Extended Style
		DWORD		dwStyle;    // Window Style
		RECT		WindowRect; // Grabs Rectangle Upper Left / Lower Right Values

		mPosition = position;
		if(fullscreen) mPosition.setLimits(0,position.getWidth(),position.getHeight(),0);

		WindowRect.left   = mPosition.getLeft();
		WindowRect.right  = mPosition.getWidth();
		WindowRect.top    = mPosition.getTop();
		WindowRect.bottom = mPosition.getHeight();

		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle   = WS_OVERLAPPEDWINDOW;

		if(registerClass()==false){
			LOG4CPLUS_FATAL(logger, "WinClass | Cannot register the window class."); return false;
		}

		// From Nehe's tutorial
		if(fullscreen){
			logPossibleVideoSettings();

			DEVMODE dmScreenSettings;                              // Device Mode
			memset(&dmScreenSettings,0,sizeof(dmScreenSettings));  // Makes Sure Memory's Cleared
			dmScreenSettings.dmSize=sizeof(dmScreenSettings);      // Size Of The Devmode Structure
			dmScreenSettings.dmPelsWidth	= mPosition.getWidth();  // Selected Screen Width
			dmScreenSettings.dmPelsHeight	= mPosition.getHeight(); // Selected Screen Height
			dmScreenSettings.dmBitsPerPel	= 32;                    // Selected Bits Per Pixel TODO: Fix/extend (?)
			dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

			if(::ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL){
				LOG4CPLUS_FATAL(logger, "WinClass | Cannot change display setting to fullscreen."); return false;
			}
			dwExStyle=WS_EX_APPWINDOW;
			dwStyle=WS_POPUP;
			::ShowCursor(FALSE);
		} else {
			// Adjust Window To True Requested Size, accounting window borders (style)
			::AdjustWindowRectEx(&WindowRect, dwStyle, FALSE/*no-menu*/, dwExStyle);
		}


		// Note: We are using the 'adjusted' window rect
		if(!(hWnd=::CreateWindowEx(	
				dwExStyle,
				mClassName,
				windowTitle,
				dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, // OpenGL window should be created these 2 styles. (from MSDN)
				WindowRect.left, WindowRect.top,	 // Window Position
				WindowRect.right-WindowRect.left, // Calculate Window Width
				WindowRect.bottom-WindowRect.top, // Calculate Window Height
				NULL,                             // No Parent Window
				NULL,                             // No Menu
				hInstance,                        // Instance
				this                              // Don't Pass Anything To WM_CREATE
			)))
		{
			LOG4CPLUS_FATAL(logger, "WinClass | Window Creation Error."); return false;
		}

		if(!(hDC=GetDC(hWnd))) { // Did We Get A Device Context?
			LOG4CPLUS_FATAL(logger, "WinClass | Can't Create A GL Device Context."); return false;
		}

		mFullScreen = fullscreen;
		mIsValid = true;
		free(mWindowTitle);
		if(windowTitle){
			mWindowTitle = (char*) malloc(strlen(windowTitle)+1);
			strcpy(mWindowTitle,windowTitle);
		}
		LOG4CPLUS_INFO(logger, "WinClass | An application window is successfully created.");
		return true;
	}

	bool OSWindow_Win::destroyWindow(){
		if(hDC && !::ReleaseDC(hWnd,hDC)) {
			LOG4CPLUS_WARN(Logger::getInstance("RSys"), "WinClass | Release Device Context Failed.");
		}
		hDC=NULL;
		if(hWnd && !::DestroyWindow(hWnd)) {
			LOG4CPLUS_WARN(Logger::getInstance("RSys"), "WinClass | Could Not Release hWnd.");
		}
		hWnd=NULL;
		if(!unregisterClass()) {
			LOG4CPLUS_WARN(Logger::getInstance("RSys"), "WinClass | Could Not Unregister Class.");
		}
		hInstance = NULL;
		mIsValid = false;
		return true;
	}
	bool OSWindow_Win::destroyWindow_KeepRegistry(){
		if(hDC && !::ReleaseDC(hWnd,hDC)) {
			LOG4CPLUS_WARN(Logger::getInstance("RSys"), "WinClass | Release Device Context Failed.");
		}
		hDC=NULL;
		if(hWnd && !::DestroyWindow(hWnd)) {
			LOG4CPLUS_WARN(Logger::getInstance("RSys"), "WinClass | Could Not Release hWnd.");
		}
		hWnd=NULL;
		hInstance = NULL;
		mIsValid = false;
		return true;

	}

	LRESULT CALLBACK OSWindow_Win::WndProcHandler(
		HWND	hWnd,    // Handle For This Window
		UINT	uMsg,    // Message For This Window
		WPARAM wParam, // Additional Message Information
		LPARAM lParam) // Additional Message Information
	{
		switch (uMsg) {
		case WM_ACTIVATE:
			// LoWord Can Be WA_INACTIVE, WA_ACTIVE, WA_CLICKACTIVE,
			// The High-Order Word Specifies The Minimized State Of The Window Being Activated Or Deactivated.
			// A NonZero Value Indicates The Window Is Minimized.
			if ((LOWORD(wParam) != WA_INACTIVE) && !((BOOL)HIWORD(wParam)))
				; // windowActive=TRUE;
			else
				; // windowActive=FALSE;
			return 0;

		case WM_SYSCOMMAND:
			switch (wParam) {
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;

		case WM_SIZE: {
			// TODO: Add a generic resize-window functionality
			ushort width  = LOWORD(lParam);
			ushort height = HIWORD(lParam);
			return 0;
			}

		case WM_MOVE: {
			ushort x = LOWORD(lParam);
			ushort y = HIWORD(lParam);
			}
			break;

		case WM_CLOSE:
			REng::RenderSystem::getSingleton().shutdownWindowAndGLContext();
			PostQuitMessage(0);
			return 0;
		case WM_DESTROY:
			REng::RenderSystem::getSingleton().shutdownWindowAndGLContext();
		}

		// Pass All Unhandled Messages To DefWindowProc
		return DefWindowProc(hWnd,uMsg,wParam,lParam);
	}

	bool OSWindow_Win::releaseDeviceContext(){
		if(hDC && !ReleaseDC(hWnd,hDC)) {
			LOG4CPLUS_FATAL(Logger::getInstance("RSys"), "WinClass | Releasing Device Context Failed."); return false;
		}
		hDC=0;
		return true;
	}

	void OSWindow_Win::logPossibleVideoSettings(){
		// Log possible screen resolutions
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger, "Listing available video settings...");
		int  nModeExist;
		DEVMODE devMode;
		devMode.dmSize = sizeof(DEVMODE);
		for(int i=0;true;++i){
			nModeExist = EnumDisplaySettings(NULL, i, &devMode);
			if(nModeExist!=1) {
				break;
			} else {
				LOG4CPLUS_INFO(logger, "Video Setting " << i << 
					"  BitsPerPixel:"<<devMode.dmBitsPerPel<<
					"  Width:"       <<devMode.dmPelsWidth <<
					"  Height:"      <<devMode.dmPelsHeight);
			}
		}
	}

} // namespace REng

#elif defined USING_XLIB

#include "REng/sys/GLContext_GLX.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>

// Temporarily disabling fullscreen. This header may nt be found in the system
// #include <X11/extensions/xf86vmode.h>

namespace REng{

	OSWindow_X::OSWindow_X(){
		x11Window = 0;
		x11Display = 0;
	}
	OSWindow_X::~OSWindow_X(){ ; }

	Window   OSWindow_X::getWindow()    { return x11Window;    }
	Display* OSWindow_X::getDisplay()   { return x11Display;   }
	long     OSWindow_X::getScreen()    { return x11Screen;    }
	Colormap OSWindow_X::getColormap()  { return x11Colormap;  }

	bool OSWindow_X::createWindow(const RectI& position, bool fullscreen, const char* windowTitle){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"X: Initing XServer connection.");

		x11Display = XOpenDisplay( 0 );
		if(!x11Display) {
			LOG4CPLUS_FATAL(logger,"X: Cannot connect to XServer."); return false;
		}	LOG4CPLUS_INFO(logger,"X: OpenDisplay succeeded.");

		x11Screen = XDefaultScreen(x11Display);

#if defined(USING_GLX)
		if(mGLX->updateVisInfo(this) == false) return false;
		XVisualInfo *x11VisualInfo = mGLX->getVisInfo();
#elif defined(USING_EGL)
		XVisualInfo *x11VisualInfo = new XVisualInfo;
		xScreenDepth      = DefaultDepth(x11Display, x11Screen);
		if(XMatchVisualInfo( x11Display, x11Screen, xScreenDepth, TrueColor, x11VisualInfo) == 0) {
			LOG4CPLUS_FATAL(logger,"X: A visual that matches the specified depth and class info cannot be found."); return false;
		}
		if(!x11VisualInfo){ LOG4CPLUS_FATAL(logger,"X: Unable to acquire visual."); return false; }
		LOG4CPLUS_INFO(logger,"X: Visual is acquired. depth: "<<xScreenDepth<<", TrueColor");
#else
		LOG4CPLUS_FATAL(logger,"X: OpenGL Context Manager type is not set (GLX/EGL)."); return false;
#endif

		Window rootWindow = RootWindow(x11Display, x11Screen);
		x11Colormap = XCreateColormap(x11Display, rootWindow, x11VisualInfo->visual, AllocNone);


		// create XWindow
		XSetWindowAttributes sWA;
		sWA.colormap   = x11Colormap;
		sWA.event_mask = StructureNotifyMask|ExposureMask|
			              ButtonPressMask|ButtonReleaseMask|
							  KeyPressMask|KeyReleaseMask;
		sWA.background_pixmap = None;
		sWA.border_pixel      = 0;

		// temporarily disabled
		/*
		if(fullscreen){ // switch video mode
			// get window video modes supported
			XF86VidModeModeInfo **vidModes;
			int vidModeCount, vidModeBest;

			int vidModeMajorVersion, vidModeMinorVersion;
			XF86VidModeQueryVersion(x11Display,&vidModeMajorVersion,&vidModeMinorVersion);
			LOG4CPLUS_INFO(logger,"X: XF86VidModeExtension-Version :"<<vidModeMajorVersion<<"."<<vidModeMinorVersion);
			
			XF86VidModeGetAllModeLines(x11Display, x11Screen, &vidModeCount, &vidModes);
			// look for mode with requested resolution, if not found, fatal error
			for(int i=0; true ; ++i) { 
				if(i==vidModeCount) {
					LOG4CPLUS_FATAL(logger,"X: Fullscreen is not supported in [:"<<position.getWidth()<<"x"<<position.getHeightt()<<"]");
					return false;
				}
				if(vidModes[i]->hdisplay != position.getWidth())  continue;
				if(vidModes[i]->vdisplay != position.getHeight()) continue;
				bestMode = i; break; // whoohoo, found it
			}
			LOG4CPLUS_INFO(logger,"X: Setting up fullscreen mode...");
			XF86VidModeSwitchToMode(x11Display, x11Screen, vidModes[vidModeBest]);
			XF86VidModeSetViewPort (x11Display, x11Screen, 0, 0);
			XFree(vidModes);
		}
		*/
		unsigned int ui32Mask = CWBackPixel | CWBorderPixel | CWEventMask | CWColormap;
		x11Window = XCreateWindow( 
			x11Display,                                // display
			rootWindow,                                // parent 
			position.getLeft(),  position.getTop(),    
			position.getWidth(), position.getHeight(),
			0,                                         // border_width
			x11VisualInfo->depth,                      // depth 
			InputOutput,                               // class 
			x11VisualInfo->visual,                     // *visual
			ui32Mask,                                  // valuemask
			&sWA                                       // *attributes
			);
		if(!x11Window) {
			LOG4CPLUS_ERROR(logger,"X: window cannot be created."); return false;
		}  LOG4CPLUS_INFO(logger,"X: window is created.");


		XStoreName(x11Display,x11Window,windowTitle); // set window title
		XMapWindow(x11Display,x11Window);
		XFlush(x11Display);


		mIsValid = true;
		mPosition = position;
		mFullScreen = fullscreen;
		free(mWindowTitle);
		if(windowTitle){
			mWindowTitle = (char*) malloc(strlen(windowTitle)+1);
			strcpy(mWindowTitle,windowTitle);
		}
		return true;
	}

	bool OSWindow_X::destroyWindow(){
		if (x11Window)   XDestroyWindow(x11Display, x11Window  );
		if (x11Colormap) XFreeColormap (x11Display, x11Colormap);
		if (x11Display)  XCloseDisplay (x11Display);
		x11Window = 0;
		x11Colormap = 0;
		x11Display = 0;
		return true;
	}
	void OSWindow_X::testColormapStuff(){
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"X: Colormap:"<<(size_t)x11Colormap);
		LOG4CPLUS_INFO(logger,"X: Display:"<<(size_t)x11Display);
		XColor black, dummy;
		XAllocNamedColor(x11Display,x11Colormap,"black",&black,&dummy);
	}

}

#endif // USING_XLIB
