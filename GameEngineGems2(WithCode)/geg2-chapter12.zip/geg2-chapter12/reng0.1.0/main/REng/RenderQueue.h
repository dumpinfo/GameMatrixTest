/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_RENDERQUEUE_H_
#define _RENG_RENDERQUEUE_H_

#include "REng/Prerequisites.h"

#include "REng/Mesh.h"
#include "REng/Material/RenderPass.h"

// render queue map is a singleton
#include "REng/Singleton.h"
// std::map
#include <map>
// auto_ptr
#include <memory>
// iterators are shared pointers
#include <boost/shared_ptr.hpp>

namespace REng{

	//! For use as a reference in setting your queueID's
	enum RenderQueueID{
		RenderQueueID_Null        = 0,  ///! Denotes no specific ID, may signal the use of a default ID
		RenderQueueID_Background  = 1,  ///! Used by background elements
		RenderQueueID_NodeDefault = 10, ///! Used by the scene graph as a default value
		REnderQueueID_BoundingVol = 15, ///! Used by the bounding volume renderables
		REnderQueueID_GUI         = 100 ///! Reserved for use by the GUI render queues
	};

	/*!
	 * @brief Provides a complete information for a structure to be rendered
	 * @remark It is a thin class, in which copy operation is fast. You can use an instance as 
	 *         pass by value or store them in standard containers.
	 * @author Adil Yalcin
	 */
	class RENGAPI Renderable{
	public:
		//! Creates a renderable which described a complete set of rendering data
		//! @param mt The model Matrix
		//! @param mg The mesh geometry to be rendered
		//! @param rp The pointer to render pass information. If NULL, this renderable will not change the 
		//!           rendering state.
		Renderable(const Matrix4& mt, const MeshGeom& mg, RenderPass* rp=0);

		//! Creates a renderable which described a complete set of rendering data
		//! @param mt The model Matrix
		//! @param mg The mesh geometry to be rendered
		//! @param rp The pointer to render pass information. If NULL, this renderable will not change the 
		//!           rendering state.
		//! @remark mt pointer will be owned by this renderable and will be deleted when this 
		//!         renderable is about to be destructed (with a clear() call)
		Renderable(Matrix4* mt, const MeshGeom& mg, RenderPass* rp=0);
		~Renderable();

		//! Deletes any data that this renderable owns
		void clear();

		Renderable& operator=(const Renderable& rhs);

		//! @return The model transform of the renderable
		const Matrix4& getModelTransform() const;
		//! @return The mesh vertex/pixel geometry of the renderable
		MeshGeom& getMeshGeom();
		//! @return The render pass of the renderable. 0 if not set
		RenderPass* getRenderPass();

		//! temp
		uchar viewNo;

	private:
		//! @note Points to a persistent data
		const Matrix4* modelTransform;
		//! @note If set, deleted on object destruction
		Matrix4* modelTransformPtr;
		MeshGeom meshGeom;
		//! May be null, which means we do not specify any render pass information
		RenderPass* pass;
	};

	/*!
	 * @brief Stores a list of renderables, which may be ordered internally
	 * @notes
	 *  - You need to attach a render queue instance to RenderQueueMap for it to be precessed during
	 *    scene rendering
	 * @author Adil Yalcin
	 */
	class RENGAPI RenderQueue {
	// forward declarations
	protected:
		class IteratorImp;
		typedef boost::shared_ptr<IteratorImp> RIteratorImpPtr;
	public:
		class IteratorGeneric;

	public:
		RenderQueue();

		//! @brief You can prevent a render queue from being processed / rendered by the render system
		//!        if you disable it.
		//! @remark A render queue is enabled by default.
		bool mEnabled;

		//! @return Active renderable count in this render queue
		size_t getRenderableCount() const { return mRenderableCount; }

		//! Initially, is RenderQueueID_Null, which means "not reserved/default"
		uchar getQueueID() const { return mQueueID; }

		//! Adds a renderable to this render queue
		virtual void addRenderable(Renderable& r) = 0;
		//! For use with boost foreach
		virtual IteratorGeneric begin() = 0;
		//! For use with boost foreach
		virtual IteratorGeneric end() = 0;

		//! Resets the renderable list size to 0 (does not delete existing renderables)
		virtual void reset(){ mRenderableCount = 0; }
		//! Deletes all renderable instances within this queue
		virtual void clear(){ mRenderableCount = 0; }
		//! Called before processing (rendering) render queue content
		//! @note You can modify this class to define render queue behavior
		virtual void preRenderQueueProcess(){ }
		//! Called after processing (rendering) render queue content
		//! @note You can modify this class to define render queue behavior
		virtual void postRenderQueueProcess(){ }

	protected:
		//! The active number of renderables
		size_t mRenderableCount;
		//! @remark Cannot be set directly from the public interface, only RenderQueueMap can set it
		uchar mQueueID;

		friend class RenderQueueMap;

	public:
		//! @class IteratorGeneric
		//! @brief Aims to provide basic iteration over generic render queue containers.
		class RENGAPI IteratorGeneric : public std::iterator<std::forward_iterator_tag,Renderable> {
		public:
			//! The constructor, wraps over an internal iterator implementation
			IteratorGeneric(IteratorImp* imp);
			IteratorGeneric(const IteratorGeneric& rhs);
			~IteratorGeneric();
			//! equality operator
			bool operator==(const IteratorGeneric& i) const;
			//! accessing the renderable
			Renderable& operator*();
			//! pre-increments
			IteratorGeneric& operator++();
			//! the inequality operator uses equality operator directly
			bool operator!=(const IteratorGeneric& i) const;
		private:
			//! The pointer to abstract iterator implementation
			RIteratorImpPtr imp;
			// do not support other operators
			IteratorGeneric operator--(int);
			IteratorGeneric& operator--();
			Renderable& operator[](int i) const;
			//! do not support post-increment, since it requires an object instance, not reference
			IteratorGeneric operator++(int);
		};

		// for boost compability
		typedef IteratorGeneric iterator;
		typedef const IteratorGeneric const_iterator;

	protected:

		//! @class IteratorImp
		//! @define A private iterator that can be modified by sub-classes of RenderQueue
		//! 
		//! You need to override the public methods in derived classes from RenderQueue
		//! The class that needs to defined for specific render queue implementations
		class RENGAPI IteratorImp {
		public:
			virtual ~IteratorImp(){}

		protected:
			//! equality operator
			virtual bool operator==(const IteratorImp& i) const = 0;
			//! accessing the renderable
			virtual Renderable& operator*() = 0;
			//! pre-increments
			virtual IteratorImp& operator++() = 0;
			friend class IteratorGeneric;
		};

	};

	//! @class RenderQueue_Vector
	//! @brief A render queue which uses stl vector class and only pushes 
	//!        back the renderables as they are inserted into the queue.
	class RENGAPI RenderQueue_Vector : public RenderQueue {
	public:
		void clear();
		void addRenderable(Renderable& r);

		IteratorGeneric begin();
		IteratorGeneric end();

	protected:
		typedef std::vector<Renderable> RenderableList;

		//! The list of renderables within this render queue
		RenderableList mRenderableList;

		class RENGAPI RIteratorImp_Vector : public RenderQueue::IteratorImp {
		public:
			RIteratorImp_Vector(RenderableList::iterator it);
			~RIteratorImp_Vector();
			//! equality operator
			//! @note Assumes the parameter is of type RIteratorImp_Vector, TODO fix?
			bool operator==(const RenderQueue::IteratorImp& i) const;
			//! accessing the renderable
			Renderable& operator*();
			//! pre-increments
			RenderQueue::IteratorImp& operator++();
		private:
			RenderableList::iterator it;
		};
	};

	//! A render queue with specialized pre/post processing steps
	class RENGAPI RenderQueue_BVs : public RenderQueue_Vector {
	public:
		static const uchar RenderQueue_BVs_ID;
		//! Registers itself to RenderQueue_BVs_ID
		RenderQueue_BVs();
		void preRenderQueueProcess();
		void postRenderQueueProcess();
		bool mEnableSetAttribBatch;
	};

	//! A render queue with specialized pre/post processing steps
	class RENGAPI RenderQueue_Background : public RenderQueue_Vector {
	public:
		static const uchar RenderQueue_Background_ID;
		//! Registers itself to RenderQueue_BVs_ID
		RenderQueue_Background();
		void preRenderQueueProcess();
		void postRenderQueueProcess();
	};

	/**
	 * @class RenderQueueMap
	 * @brief Stores a list of render queue's ordered by their queue ID's.
	 *        The render queues are processed by the render system with increasing queue ID order.
	 *        You can achieve a render order for your scene by registering new queue's to unique ID's
	 * @note Only a single instance of render queue map exists, and it is managed by the render system.
	 * @author Adil Yalcin
	 */
	class RENGAPI RenderQueueMap : public Singleton<RenderQueueMap> {
	public:
		typedef std::map< uchar, RenderQueue* > RenderQueueMapping;
		typedef RenderQueueMapping::iterator iterator;
		typedef const RenderQueueMapping::iterator const_iterator;

	public:
		static RenderQueueMap& getSingleton(void);
		static RenderQueueMap* getSingletonPtr(void);

		//! Clears all the renderables inserted into the queue.
		//! Call in the start of every frame...
		void resetQueues();

		//! Adds the given render queue instance to the mapping
		//! @param queue The queue which will be inserted at the mapping, cannot be 0
		//! @param queueID The requested queueID to put this queue into, cannot be RenderQueueID_Null
		//! @return True if the queue is successfully registered
		bool registerRenderQueue(RenderQueue* queue, uchar queueID);

		//! @param r The renderable that wll be inserted into queue
		//! @param queueID If 0, default group ID is used
		//! @remark If a render queue with the given group ID does not exists, does nothing
		//! @note The queue stores a copy of the given renderable, so you may delete the renderable 
		//!       objects after calling this method
		//! @note Prefer to use RenderQueue::addRenderable() function directly.
		void addRenderable(Renderable& r, uchar queueID=RenderQueueID_Null);

		//! @param queueID The default group ID to be used when no groupID is
		//!        specified in a addRenderable. Value 0 is reserved (will have no affect)
		//! Default value is 1
		void setDefaultQueueID(uchar queueID);

		//! @return The default group ID that is used when no groupID is specified for a renderable.
		uchar getDefaultQueueID() const;

		//! @return The render queue at the given queue ID.
		//!         Null if no render queue exists in the requested queue ID
		RenderQueue* getRenderQueue(uchar queueID);

		//! @note For use with STL iterators
		//! @TODO make this better
		iterator begin();

		//! @note For use with STL iterators
		//! @TODO make this better
		iterator end();

	protected:
		RenderQueueMapping mRenderableListMap;
		uchar mDefaultQueueID;

		//! The object can only be created by the render system
		RenderQueueMap();

		friend class RenderSystem;
	};

} // namespace REng

#endif // _RENG_RENDERQUEUE_H_
