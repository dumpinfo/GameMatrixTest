/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_DEFINES_H_
#define _RENG_DEFINES_H_

#include "REng/Prerequisites.h"

// Use these macros to easyly log opengl errors
#ifdef RENG_DEBUG_BUILD
#define CHECKGLERROR_TERM() { REng::checkGLError_Term(__FILE__,__LINE__); }
#define CHECKGLERROR() { REng::checkGLError(__FILE__,__LINE__); }
#else
#define CHECKGLERROR_TERM() ;
#define CHECKGLERROR() ;
#endif

// you can make sure a code piece is executed only once using these macros
#define EXEC_ONCE_BEGIN() { static bool guard = false; if(!guard) { 
#define EXEC_ONCE_END()   guard = true;} }

/*
the following define's give error on gcc

#define DEFINE_AS_NONE( enumtype )      \
	#ifndef GL_##enumtype##             
		#define GL_##enumtype## GL_NONE 
	#endif

#define DEFINE_FROM_OES( enumtype )                       \
	#ifndef GL_##enumtype##                               \
		#ifdef GL_##enumtype##_OES                        \
			#define GL_##enumtype##  GL_##enumtype##_OES  \
		#else                                             \
			#define GL_##enumtype##  GL_NONE              \
		#endif                                            \
	#endif
*/

namespace REng{

	//! @brief Checks if there exists a GL error. If error is found, error is send as a critical error message
	//!        and program is terminated. 
	void checkGLError_Term(const char * logstr, int logint);
	//! @brief Checks if there exists a GL error. If error is found, error is send as a critical error message only
	void checkGLError(const char * logstr, int logint);
	//! @brief Transforms the error into string representation (is error holds a valid OpenGL error code)
	const char* getGLErrorStr(GLenum error);

	//! Lists all possible hardware shader types.
	//! Used by : glCreateShader, 
	enum ShaderType {
		ShaderType_Vertex   = GL_VERTEX_SHADER,
		ShaderType_Fragment = GL_FRAGMENT_SHADER,
		ShaderType_Geometry = GL_GEOMETRY_SHADER 
	};

	enum ShaderVersion{
		ShaderVersion_100ES, // For OpenGL ES configurations
		ShaderVersion_130,
		ShaderVersion_140,
		ShaderVersion_150,
		ShaderVersion_330,
		ShaderVersion_Default // No specific version is set
	};

	//! Lists all possible texture types.
	//! Used by : glTexImageXYZ, glTexParam, ...
	enum TextureType {
		TextureType_1D   = GL_TEXTURE_1D,
		TextureType_2D   = GL_TEXTURE_2D,
		TextureType_3D   = GL_TEXTURE_3D,
		TextureType_Cube = GL_TEXTURE_CUBE_MAP
	};

	//! Lists possible cube map faces.
	//! Used by : glTexImage2D, glFramebufferTexture2D
	enum CubeMapFace {
		CubeMapFace_Positive_X = GL_TEXTURE_CUBE_MAP_POSITIVE_X,
		CubeMapFace_Negative_X = GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
		CubeMapFace_Positive_Y = GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
		CubeMapFace_Negative_Y = GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
		CubeMapFace_Positive_Z = GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
		CubeMapFace_Negative_Z = GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
	};

	//! Lists possible render target components
	enum RenderTargetComp{
		RTC_Red     = 0,
		RTC_Green   = 1,
		RTC_Blue    = 2,
		RTC_Alpha   = 3,
		RTC_Depth   = 4,
		RTC_Stencil = 5
	};

	//! Lists all possible image formats (used by textures or render targets)
	//! Used by : glTexImageXYZ, glCompressedTexImageXYZ
	enum ImageFormat {

		// ***************************************************************
		// Base Internal Formats
		ImageFormat_R    = GL_RED, // 3.1>= ?
		ImageFormat_RG   = GL_RG,  // 3.1>= ?
		ImageFormat_RGB  = GL_RGB,
		ImageFormat_RGBA = GL_RGBA,
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES // Not defined, but automatically set to default types
		ImageFormat_D    = GL_DEPTH_COMPONENT16,
		ImageFormat_S    = GL_STENCIL_INDEX, // should be GL_STENCIL_INDEX8, but some drivers may accept this instead.
		#else
		ImageFormat_D    = GL_DEPTH_COMPONENT,
		ImageFormat_S    = GL_STENCIL_INDEX, // Can only be used by renderbuffers
		#endif
		ImageFormat_DS   = GL_DEPTH_STENCIL, // ES 2.0 => _OES

		// *********************************************************
		// Legacy Base Formats, included as valid types in ES 2.0 specs
		ImageFormat_A    = GL_ALPHA,
		ImageFormat_L    = GL_LUMINANCE,
		ImageFormat_LA   = GL_LUMINANCE_ALPHA,
		
		// *********************************************************
		// Sized Depth Formats
		ImageFormat_D16  = GL_DEPTH_COMPONENT16,
		ImageFormat_D24  = GL_DEPTH_COMPONENT24,  // ES 2.0 => _OES
		ImageFormat_D32  = GL_DEPTH_COMPONENT32,  // 3.1 => OPT, ES 2.0 => _OES,
		ImageFormat_D32F = GL_DEPTH_COMPONENT32F, // ES 2.0 => NONE

		// *********************************************************
		// Sized Stencil Formats (Only be usable by renderbuffers)
		ImageFormat_S1   = GL_STENCIL_INDEX1,     // ES 2.0 => NONE
		ImageFormat_S4   = GL_STENCIL_INDEX4,     // ES 2.0 => NONE
		ImageFormat_S8   = GL_STENCIL_INDEX8,
		ImageFormat_S16  = GL_STENCIL_INDEX16,    // ES 2.0 => NONE

		// *********************************************************
		// Combined Depth-Stencil Formats (Not defined in ES 2.0)
		ImageFormat_D24S8  = GL_DEPTH24_STENCIL8,
		ImageFormat_D32FS8 = GL_DEPTH32F_STENCIL8,

		// *********************************************************
		// Sized color formats (added as required)
		// *******************
			// For textures and renderbuffers
		ImageFormat_R8       = GL_R8,
		ImageFormat_R8I      = GL_R8I,
		ImageFormat_R8UI     = GL_R8UI,
		ImageFormat_R16      = GL_R16,
		ImageFormat_R16F     = GL_R16F,
		ImageFormat_R16I     = GL_R16I,
		ImageFormat_R16UI    = GL_R16UI,
		ImageFormat_R32F     = GL_R32F,
		ImageFormat_R32I     = GL_R32I,
		ImageFormat_R32UI    = GL_R32UI,
		ImageFormat_RG8      = GL_RG8,
		ImageFormat_RG8I     = GL_RG8I,
		ImageFormat_RG8UI    = GL_RG8UI,
		ImageFormat_RG16     = GL_RG16,
		ImageFormat_RG16F    = GL_RG16F,
		ImageFormat_RG16I    = GL_RG16I,
		ImageFormat_RG16UI   = GL_RG16UI,
		ImageFormat_RG32F    = GL_RG32F,
		ImageFormat_RG32I    = GL_RG32I,
		ImageFormat_RG32UI   = GL_RG32UI,
		ImageFormat_RGBA8    = GL_RGBA8,
		ImageFormat_RGBA8I   = GL_RGBA8I,
		ImageFormat_RGBA8UI  = GL_RGBA8UI,
		ImageFormat_RGBA16   = GL_RGBA16,
		ImageFormat_RGBA16F  = GL_RGBA16F,
		ImageFormat_RGBA16I  = GL_RGBA16I,
		ImageFormat_RGBA16UI = GL_RGBA16UI,
		ImageFormat_RGBA32F  = GL_RGBA32F,
		ImageFormat_RGBA32I  = GL_RGBA32I,
		ImageFormat_RGBA32UI = GL_RGBA32UI,

		ImageFormat_RGB10_A2   = GL_RGB10_A2,
		ImageFormat_RGB10_A2UI = GL_RGB10_A2UI,
		ImageFormat_RG11F_B10F = GL_R11F_G11F_B10F,

			// For textures only
		ImageFormat_RGB8    = GL_RGB8,
		ImageFormat_RGB8I   = GL_RGB8I,
		ImageFormat_RGB8UI  = GL_RGB8UI,
		ImageFormat_RGB9_E5 = GL_RGB9_E5,
		ImageFormat_RGB16   = GL_RGB16,
		ImageFormat_RGB16F  = GL_RGB16F,
		ImageFormat_RGB16I  = GL_RGB16I,
		ImageFormat_RGB16UI = GL_RGB16UI,
		ImageFormat_RGB32F  = GL_RGB32F,
		ImageFormat_RGB32I  = GL_RGB32I,
		ImageFormat_RGB32UI = GL_RGB32UI,

			// For Render Buffers & OpenGL ES 2.0 only
		ImageFormat_RGBA4    = GL_RGBA4,
		ImageFormat_RGB5_A1  = GL_RGB5_A1,
		ImageFormat_RGB565   = GL_RGB565,

		// *****************************************************
		// Compressed image formats

			// Targets supported by desktop GL
		ImageFormat_Compr_R_RGTC         = GL_COMPRESSED_RED_RGTC1,
		ImageFormat_Compr_R_Signed_RGTC  = GL_COMPRESSED_SIGNED_RED_RGTC1,
		ImageFormat_Compr_RG_RGTC        = GL_COMPRESSED_RG_RGTC2,
		ImageFormat_Compr_RG_SIGNED_RGTC = GL_COMPRESSED_SIGNED_RG_RGTC2,
		ImageFormat_Compr_RGB_S3TC_DXT1  = GL_COMPRESSED_RGB_S3TC_DXT1_EXT,
		ImageFormat_Compr_RGBA_S3TC_DXT1 = GL_COMPRESSED_RGBA_S3TC_DXT1_EXT,
		ImageFormat_Compr_RGBA_S3TC_DXT3 = GL_COMPRESSED_RGBA_S3TC_DXT3_EXT,
		ImageFormat_Compr_RGBA_S3TC_DXT5 = GL_COMPRESSED_RGBA_S3TC_DXT5_EXT,
			// Targets supported by ES 2.0 platform
		ImageFormat_Compr_RGB_PVRTC_4    = GL_COMPRESSED_RGB_PVRTC_4BPPV1_IMG,
		ImageFormat_Compr_RGB_PVRTC_2    = GL_COMPRESSED_RGB_PVRTC_2BPPV1_IMG,
		ImageFormat_Compr_RGBA_PVRTC_4   = GL_COMPRESSED_RGBA_PVRTC_4BPPV1_IMG,
		ImageFormat_Compr_RGBA_PVRTC_2   = GL_COMPRESSED_RGBA_PVRTC_2BPPV1_IMG,
		ImageFormat_Compr_RGB_ETC1       = GL_ETC1_RGB8_OES,

		ImageFormat_None                 // An invalid/none image format
	};

	enum PixelDataFormat {
		PixelDataFormat_RGB  = GL_RGB,
		PixelDataFormat_RGBA = GL_RGBA,
		PixelDataFormat_D    = GL_DEPTH_COMPONENT,
			// legacy
		PixelDataFormat_A     = GL_ALPHA,
		PixelDataFormat_L     = GL_LUMINANCE,
		PixelDataFormat_LA    = GL_LUMINANCE_ALPHA,
			// not supported in ES 2.0
		PixelDataFormat_S     = GL_STENCIL_INDEX,
		PixelDataFormat_DS    = GL_DEPTH_STENCIL,
		PixelDataFormat_R     = GL_RED,
		PixelDataFormat_G     = GL_GREEN,
		PixelDataFormat_B     = GL_BLUE,
		PixelDataFormat_RG    = GL_RG,
		PixelDataFormat_BGR   = GL_BGR,
		PixelDataFormat_BGRA  = GL_BGRA,
			// integer formats
		PixelDataFormat_iR    = GL_RED_INTEGER,
		PixelDataFormat_iG    = GL_GREEN_INTEGER,
		PixelDataFormat_iB    = GL_BLUE_INTEGER,
		PixelDataFormat_iRG   = GL_RG_INTEGER,
		PixelDataFormat_iRGB  = GL_RGB_INTEGER,
		PixelDataFormat_iRGBA = GL_RGBA_INTEGER,
		PixelDataFormat_iBGR  = GL_BGR_INTEGER,
		PixelDataFormat_iBGRA = GL_BGRA_INTEGER
	};

	/*! Lists possible texture data types.
	 *  
	 * \note OpenGL ES 2.0 : ushort and uint are added with OES_depth_texture ext.
	 *       OpenGL >= 2.0 : supports many more types, they are not listed (will be added when required)
	 */
	enum PixelDataType {
		PixelDataType_UByte          = GL_UNSIGNED_BYTE,
		PixelDataType_Byte           = GL_BYTE,
		PixelDataType_UShort         = GL_UNSIGNED_SHORT,
		PixelDataType_Short          = GL_SHORT,
		PixelDataType_UInt           = GL_UNSIGNED_INT,
		PixelDataType_Int            = GL_INT,
		PixelDataType_Float_Half     = GL_HALF_FLOAT,
		PixelDataType_Float          = GL_FLOAT, // ES 2.0 => Supported by an extension

		// packed formats
		PixelDataType_UShort_5_6_5   = GL_UNSIGNED_SHORT_5_6_5, 
		PixelDataType_UShort_4_4_4_4 = GL_UNSIGNED_SHORT_4_4_4_4, 
		PixelDataType_UShort_5_5_5_1 = GL_UNSIGNED_SHORT_5_5_5_1,
		// TODO add other supported packed formats...
	};

	//! Lists possible texture wrap modes. @see RenderProp_WrapMode
	//! @note GL_CLAMP is deprecated in OpenGL 3.0, thus it is not included.
	enum WrapMode {
		WrapMode_Repeat         = GL_REPEAT,
		WrapMode_ClampToEdge    = GL_CLAMP_TO_EDGE,
		WrapMode_MirroredRepeat = GL_MIRRORED_REPEAT,
		WrapMode_ClampToBorder  = GL_CLAMP_TO_BORDER // ES 2.0 = not supported.
	};

	//! Lists possible texture wrap axises. @see RenderProp_WrapMode
	enum WrapAxis{
		WrapAxis_S = GL_TEXTURE_WRAP_S, 
		WrapAxis_T = GL_TEXTURE_WRAP_T, 
		WrapAxis_R = GL_TEXTURE_WRAP_R // ES 2.0 => _OES => ( see OS_3D_texture ext)
	};

	//! Lists possible texture minification filters. //! @see RenderProp_MinFilter
	enum MinFilter {
		MinFilter_Nearest              = GL_NEAREST,
		MinFilter_Linear               = GL_LINEAR,
		MinFilter_NearestMipmapNearest = GL_NEAREST_MIPMAP_NEAREST,
		MinFilter_LinearMipmapLinear   = GL_LINEAR_MIPMAP_LINEAR,
		MinFilter_NearestMipmapLinear  = GL_NEAREST_MIPMAP_LINEAR,
		MinFilter_LinearMipmapNearest  = GL_LINEAR_MIPMAP_NEAREST
	};

	//! Lists possible texture magnification filters.  @see RenderProp_MagFilter
	enum MagFilter {
		MagFilter_Nearest = GL_NEAREST,
		MagFilter_Linear  = GL_LINEAR
	};

	//! Lists possible face modes
	//! @see RenderProp_StencilFunc 
	//! @see RenderProp_StencilMask
	//! @see RenderProp_StencilOp
	//! @see RenderProp_PolyMode
	enum FaceType {
		FaceType_Front         = GL_FRONT,
		FaceType_Back          = GL_BACK,
		FaceType_FrontAndBack  = GL_FRONT_AND_BACK,
		FaceType_None          = GL_NONE ///< No face
	};

	//! Lists possible face orientations @see RenderProp_CullFace
	enum FaceOrientation{
		FaceOrientation_CW  = GL_CW,
		FaceOrientation_CCW = GL_CCW,
	};

	//! Lists possible compare functions 
	//! @see RenderProp_DepthFunc
	//! @see RenderProp_StencilFunc
	enum CompareFunc {
		CompareFunc_Never    = GL_NEVER,
		CompareFunc_Less     = GL_LESS,
		CompareFunc_LEqual   = GL_LEQUAL,
		CompareFunc_Greater  = GL_GREATER,
		CompareFunc_GEqual   = GL_GEQUAL,
		CompareFunc_Equal    = GL_EQUAL,
		CompareFunc_NotEqual = GL_NOTEQUAL,
		CompareFunc_Always   = GL_ALWAYS
	};

	//! Lists possible stencil operation modes @see CRenderProp_StencilOp
	enum OperationMode {
		OperationMode_Keep      = GL_KEEP,
		OperationMode_Zero      = GL_ZERO,
		OperationMode_Replace   = GL_REPLACE,
		OperationMode_Incr      = GL_INCR,
		OperationMode_Inc_Wrap  = GL_INCR_WRAP,
		OperationMode_Decr      = GL_DECR,
		OperationMode_Decr_Wrap = GL_DECR_WRAP,
		OperationMode_Invert    = GL_INVERT
	};

	//! @see CRenderProp_BlendEq
	enum BlendEqMode{
		BlendEqMode_Func_Add              = GL_FUNC_ADD, 
		BlendEqMode_Func_Subtract         = GL_FUNC_SUBTRACT, 
		BlendEqMode_Func_Reverse_Subtract = GL_FUNC_REVERSE_SUBTRACT
	};

	//! @see CRenderProp_BlendFunc
	enum BlendFuncMode{
		BlendFuncMode_Zero                  = GL_ZERO,
		BlendFuncMode_One                   = GL_ONE,
		BlendFuncMode_SrcColor              = GL_SRC_COLOR,
		BlendFuncMode_OneMinusSrcColor      = GL_ONE_MINUS_SRC_COLOR,
		BlendFuncMode_DstColor              = GL_DST_COLOR,
		BlendFuncMode_OneMinusDstColor      = GL_ONE_MINUS_DST_COLOR,
		BlendFuncMode_SrcAlpha              = GL_SRC_ALPHA,
		BlendFuncMode_OneMinusSrcAlpha      = GL_ONE_MINUS_SRC_ALPHA,
		BlendFuncMode_DstAlpha              = GL_DST_ALPHA,
		BlendFuncMode_OneMinusDstAlpha      = GL_ONE_MINUS_DST_ALPHA,
		BlendFuncMode_ConstantColor         = GL_CONSTANT_COLOR,
		BlendFuncMode_OneMinusConstantColor = GL_ONE_MINUS_CONSTANT_COLOR,
		BlendFuncMode_ConstantAlpha         = GL_CONSTANT_ALPHA,
		BlendFuncMode_OneMinusConstantAlpha = GL_ONE_MINUS_CONSTANT_ALPHA,
		BlendFuncMode_SrcAlphaSaturate      = GL_SRC_ALPHA_SATURATE
	};

	//! Lists polygon render modes.
	//! @see CRenderProp_PolyMode
	enum PolygonMode{
		PolygonMode_Point = GL_POINT, // ES 2.0 => NONE
		PolygonMode_Line  = GL_LINE,  // ES 2.0 => NONE
		PolygonMode_Fill  = GL_FILL   // ES 2.0 => NONE
	};

	//! Lists possible Draw / Read Buffer arguments when using a window buffer
	enum WindowBufferSource {
		WindowBufferSource_None         = GL_NONE,
		WindowBufferSource_Front_Left   = GL_FRONT_LEFT,
		WindowBufferSource_Front_Right  = GL_FRONT_RIGHT,
		WindowBufferSource_Back_Left    = GL_BACK_LEFT,
		WindowBufferSource_Back_Right   = GL_BACK_RIGHT,
		WindowBufferSource_Front        = GL_FRONT,
		WindowBufferSource_Back         = GL_BACK,
		WindowBufferSource_Left         = GL_LEFT,
		WindowBufferSource_Right        = GL_RIGHT,
		WindowBufferSource_FrontAndBack = GL_FRONT_AND_BACK
	};

	/*! Lists possible frame buffer attachment types
	 *  Used by : glFramebufferTextureXD, glFramebufferRenderbuffer
	 *
	 *  \note OpenGL >= 2.0 : supports many more color attachments, they are not listed (will be added when required)  
	 */
	enum FrameBufferAttachType {
		FrameBufferAttachType_Depth        = GL_DEPTH_ATTACHMENT,
		FrameBufferAttachType_Stencil      = GL_STENCIL_ATTACHMENT,
		FrameBufferAttachType_DepthStencil = GL_DEPTH_STENCIL_ATTACHMENT,   // ES 2.0 => _OES
		FrameBufferAttachType_Color0       = GL_COLOR_ATTACHMENT0,
		FrameBufferAttachType_Color1       = GL_COLOR_ATTACHMENT1,  // ES 2.0 : not supported
		FrameBufferAttachType_Color2       = GL_COLOR_ATTACHMENT2,  // ES 2.0 : not supported
		FrameBufferAttachType_Color3       = GL_COLOR_ATTACHMENT3,  // ES 2.0 : not supported
		FrameBufferAttachType_Color4       = GL_COLOR_ATTACHMENT4,  // ES 2.0 : not supported
		FrameBufferAttachType_Color5       = GL_COLOR_ATTACHMENT5,  // ES 2.0 : not supported
		FrameBufferAttachType_Color6       = GL_COLOR_ATTACHMENT6,  // ES 2.0 : not supported
		FrameBufferAttachType_Color7       = GL_COLOR_ATTACHMENT7,  // ES 2.0 : not supported
		FrameBufferAttachType_Color8       = GL_COLOR_ATTACHMENT8,  // ES 2.0 : not supported
		FrameBufferAttachType_Color9       = GL_COLOR_ATTACHMENT9,  // ES 2.0 : not supported
		FrameBufferAttachType_Color10      = GL_COLOR_ATTACHMENT10, // ES 2.0 : not supported
		FrameBufferAttachType_Color11      = GL_COLOR_ATTACHMENT11, // ES 2.0 : not supported
		FrameBufferAttachType_Color12      = GL_COLOR_ATTACHMENT12, // ES 2.0 : not supported
		FrameBufferAttachType_Color13      = GL_COLOR_ATTACHMENT13, // ES 2.0 : not supported
		FrameBufferAttachType_Color14      = GL_COLOR_ATTACHMENT14, // ES 2.0 : not supported
		FrameBufferAttachType_Color15      = GL_COLOR_ATTACHMENT15  // ES 2.0 : not supported
	};

	//! Lists possible frame buffer color attachment types
	//! Used by glReadBuffer / glDrawBuffer(s)
	enum FrameBufferColorBufferType{
		FrameBufferColorBufferType_None    = GL_NONE,
		FrameBufferColorBufferType_Color0  = GL_COLOR_ATTACHMENT0,
		FrameBufferColorBufferType_Color1  = GL_COLOR_ATTACHMENT1,
		FrameBufferColorBufferType_Color2  = GL_COLOR_ATTACHMENT2,
		FrameBufferColorBufferType_Color3  = GL_COLOR_ATTACHMENT3,
		FrameBufferColorBufferType_Color4  = GL_COLOR_ATTACHMENT4,
		FrameBufferColorBufferType_Color5  = GL_COLOR_ATTACHMENT5,
		FrameBufferColorBufferType_Color6  = GL_COLOR_ATTACHMENT6,
		FrameBufferColorBufferType_Color7  = GL_COLOR_ATTACHMENT7,
		FrameBufferColorBufferType_Color8  = GL_COLOR_ATTACHMENT8,
		FrameBufferColorBufferType_Color9  = GL_COLOR_ATTACHMENT9,
		FrameBufferColorBufferType_Color10 = GL_COLOR_ATTACHMENT10,
		FrameBufferColorBufferType_Color11 = GL_COLOR_ATTACHMENT11,
		FrameBufferColorBufferType_Color12 = GL_COLOR_ATTACHMENT12,
		FrameBufferColorBufferType_Color13 = GL_COLOR_ATTACHMENT13,
		FrameBufferColorBufferType_Color14 = GL_COLOR_ATTACHMENT14,
		FrameBufferColorBufferType_Color15 = GL_COLOR_ATTACHMENT15 
	};

	//! Enum for OpenGL framebuffer bind targets ( draw and read defined by ARB_framebuffer / GL 3.1)
	enum FrameBufferBindTarget{
		FrameBufferBindTarget_Draw    = GL_DRAW_FRAMEBUFFER,  // ES 2.0 : not supported
		FrameBufferBindTarget_Read    = GL_READ_FRAMEBUFFER,  // ES 2.0 : not supported
		FrameBufferBindTarget_Default = GL_FRAMEBUFFER        // 3.1    : draw + read framebuffer
	};

	/*****************************************************
	 * BUFFER RELATED ENUMARATIONS
	 *****************************************************/

	//! Possible buffer usage frequency types
	enum BufferUsageFreq {
		//! @brief The data store contents will be modified once and used at most a few times.
		BufferUsageFreq_Stream,
		//! @brief The data store contents will be modified once and used many times.
		BufferUsageFreq_Static,
		//! @brief The data store contents will be modified repeatedly and used many times.
		BufferUsageFreq_Dynamic
	};

	//! Possible buffer usage nature types
	enum BufferUsageNature {
		//! @brief The data store contents are modified by the application, 
		//!        and used as the source for GL drawing and image specification commands.
		BufferUsageNature_Draw,
		//! @brief The data store contents are modified by reading data from the GL, 
		//!        and used to return that data when queried by the application.
		BufferUsageNature_Read,
		//! @brief The data store contents are modified by reading data from the GL, 
		//!        and used as the source for GL drawing and image specification commands.
		BufferUsageNature_Copy
	};

	enum BufferAccessOp{
		BufferAccessOp_Read      = GL_READ_ONLY,
		BufferAccessOp_Write     = GL_WRITE_ONLY,
		BufferAccessOp_ReadWrite = GL_READ_WRITE
	};
	enum BufferAccessFlag{
		BufferAccessFlag_Invalidate_Range  = GL_MAP_INVALIDATE_RANGE_BIT,
		BufferAccessFlag_Invalidate_Buffer = GL_MAP_INVALIDATE_BUFFER_BIT,
		BufferAccessFlag_Flush_Explicit    = GL_MAP_FLUSH_EXPLICIT_BIT,
		BufferAccessFlag_Unsynchronized    = GL_MAP_UNSYNCHRONIZED_BIT
	};
	enum BufferBindTarget{
		BufferBindTarget_Vertex            = GL_ARRAY_BUFFER,
		BufferBindTarget_Index             = GL_ELEMENT_ARRAY_BUFFER,
		BufferBindTarget_Copy_Read         = GL_COPY_READ_BUFFER,
		BufferBindTarget_Copy_Write        = GL_COPY_WRITE_BUFFER,
		BufferBindTarget_PixelPack         = GL_PIXEL_PACK_BUFFER,
		BufferBindTarget_PixelUnpack       = GL_PIXEL_UNPACK_BUFFER,
		BufferBindTarget_Texture           = GL_TEXTURE_BUFFER,
		BufferBindTarget_TransformFeedback = GL_TRANSFORM_FEEDBACK_BUFFER,
		BufferBindTarget_Uniform           = GL_UNIFORM_BUFFER,
		BufferBindTarget_None
	};

	/*! Enum for index buffer types. 
	 *  Used by : glDrawElements
	 *
	 *  ES 2.0 : OES_element_index_uint extension adds UnsignedInt type support. TODO: check extension
	 */
	enum IndexDataType {
		IndexDataType_32BIT = GL_UNSIGNED_INT,  // ES 2.0 : not supported
		IndexDataType_16BIT = GL_UNSIGNED_SHORT,
		IndexDataType_8BIT = GL_UNSIGNED_BYTE,
	};

	//! Lists possible semantics assignable to vertex attributes @see VertexAttribute
	enum VertexAttribSemantic {
		VertexAttribSem_Position      = 0,
		VertexAttribSem_Normal        = 1,
		VertexAttribSem_Tangent       = 2,
		VertexAttribSem_Bitangent     = 3,
		VertexAttribSem_PSize         = 4,
		VertexAttribSem_ColorDiffuse  = 5,
		VertexAttribSem_ColorSpecular = 6,
		VertexAttribSem_TexCoord0     = 7,
		VertexAttribSem_TexCoord1     = 8,
		VertexAttribSem_TexCoord2     = 9,
		VertexAttribSem_TexCoord3     = 10,
		VertexAttribSem_TexCoord4     = 11,
		VertexAttribSem_TexCoord5     = 12,
		VertexAttribSem_TexCoord6     = 13,
		VertexAttribSem_TexCoord7     = 14,
		VertexAttribSem_None          = 15
	};

	//! Lists possible buffer types
	enum FrameBufferComponent {
		FrameBufferComponent_Color   = GL_COLOR_BUFFER_BIT,
		FrameBufferComponent_Depth   = GL_DEPTH_BUFFER_BIT,
		FrameBufferComponent_Stencil = GL_STENCIL_BUFFER_BIT
	};
	
	//! Stores the string representation of attribute semantics as used in shaders
	extern const char * gVertexAttribSemanticStr[];

	//! Lists possible semantics assignable to vertex attribute data types @see VertexAttribute
	enum VertexAttribDataType {
		VertexAttribDataType_Byte      = GL_BYTE,
		VertexAttribDataType_UByte     = GL_UNSIGNED_BYTE,
		VertexAttribDataType_Short     = GL_SHORT,
		VertexAttribDataType_UShort    = GL_UNSIGNED_SHORT,
		VertexAttribDataType_Float     = GL_FLOAT,
		VertexAttribDataType_Int       = GL_INT,
		VertexAttribDataType_UInt      = GL_UNSIGNED_INT,
		VertexAttribDataType_Fixed     = GL_FIXED,
		VertexAttribDataType_HalfFloat = GL_HALF_FLOAT,
		VertexAttribDataType_Double    = GL_DOUBLE
	};

	//! Enum for vertex attrib sizes (per vertex). @see VertexAttribute
	enum VertexAttribDataCount {
		VertexAttribDataCount1 = 1,
		VertexAttribDataCount2 = 2,
		VertexAttribDataCount3 = 3,
		VertexAttribDataCount4 = 4
	};

	//! Enum for vertex attrib batching
	//! @remark On render-time, the following states are changed per vertex attrib:
	//!         - HW vertex buffer is bound/unbound, depending on where the vertex data is stored.
	//!         - Attribute pointer is set.
	//!         - Attribute is activated.
	enum VertexAttribBatch {
		//! In this mode, all the above steps are performed for each attrib on every draw call
		VertexAttribBatch_None        = 0,
		//! In this mode, attrib is activated only on first draw call
		VertexAttribBatch_Active      = 1,
		//! In this mode, all the above steps are performed only on first draw call
		VertexAttribBatch_All = 2,
	};

	//! Enum for OpenGL primitive types.
	enum PrimitiveType {
		PrimitiveType_Points        = GL_POINTS,
		PrimitiveType_LineStrip     = GL_LINE_STRIP,
		PrimitiveType_LineLoop      = GL_LINE_LOOP,
		PrimitiveType_Lines         = GL_LINES,
		PrimitiveType_TriangleStrip = GL_TRIANGLE_STRIP,
		PrimitiveType_TriangleFan   = GL_TRIANGLE_FAN,
		PrimitiveType_Triangles     = GL_TRIANGLES
	};

	//! Asynchronous query targets
	enum QueryTarget{
		// primitive queries
		QueryTarget_PrimsGenerated  = GL_PRIMITIVES_GENERATED,
		QueryTarget_TransFeedback   = GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN,
		// occlusion queries
		QueryTarget_SamplesPassed    = GL_SAMPLES_PASSED,
		QueryTarget_AnySamplesPassed = GL_ANY_SAMPLES_PASSED, // 3.3 (or check extension)
		// timer queries
		QueryTarget_TimeElapsed = GL_TIME_ELAPSED, // 3.3 (or check extension)
		QueryTarget_Timestamp   = GL_TIMESTAMP // 3.3 (or check extension)
	};

	//////////////////////////////////////////////////////////////////////////
	// BASIC CHECKING USING ENUMARATED TYPES

	bool isSupported(TextureType type);
	bool isSupported(BufferBindTarget target);
	bool isSupported(ShaderType type);
	//! @note Uses GPUConfig to retrieve supported version informations
	bool isSupported(ShaderVersion _version);
	bool isSupported(WrapMode mode);
	bool isSupported(FrameBufferBindTarget target);
	bool isSupported(FrameBufferColorBufferType colorBufType);
	bool isSupported(IndexDataType type);
	bool isSupported(WindowBufferSource source);
	bool isSupported(PixelDataType type);
	bool isSupported(PixelDataFormat type);

	bool isSupportedTextureFormat(ImageFormat imformat);
	bool isSupportedRenderBufferFormat(ImageFormat imformat);
	bool isCompressedFormat(ImageFormat format);
	bool isDepthFormat  (ImageFormat imformat);
	bool isStencilFormat(ImageFormat imformat);
	bool isColorFormat  (ImageFormat imformat);
	bool isDepthFormat       (PixelDataFormat pxformat);
	bool isStencilFormat     (PixelDataFormat pxformat);
	bool isDepthStencilFormat(PixelDataFormat pxformat);
	bool isColorFormat       (PixelDataFormat pxformat);

	//! A global helper to convert index data type to its corresponding data byte size
	size_t getIndexDataByteSize(IndexDataType type);
	const char* getVertexAttribSemanticStr(VertexAttribSemantic sem);
	uchar getPixelDataChannelCount(PixelDataFormat format);

	//////////////////////////////////////////////////////////////////////////
	// INLINE METHODS

	inline bool isSupported(TextureType type){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(type){
			case TextureType_Cube :
			case TextureType_2D   : return true;
			case TextureType_3D   : // TODO: Check extension support on run-time
			default               : return false;
		}
		#endif
		return true;
	}
	inline bool isSupported(BufferBindTarget target){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(target) {
			case GL_COPY_READ_BUFFER:
			case GL_COPY_WRITE_BUFFER:
			case GL_PIXEL_PACK_BUFFER:
			case GL_PIXEL_UNPACK_BUFFER:
			case GL_TEXTURE_BUFFER:
			case GL_TRANSFORM_FEEDBACK_BUFFER:
			case GL_UNIFORM_BUFFER:
				return false;
			default:
				return true;
		}
		#endif
		return true;
	}
	inline bool isSupported(ShaderType type){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(type == ShaderType_Geometry ) return false;
		#endif
		return true;
	}
	inline bool isSupported(WrapMode mode){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(mode == GL_CLAMP_TO_BORDER) return false;
		#endif
		return true;
	}
	inline bool isSupported(FrameBufferBindTarget target){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(target==FrameBufferBindTarget_Default) return true;
		return false;
		#endif
		return true;
	}
	inline bool isSupported(FrameBufferAttachType attachType){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(attachType){
			case FrameBufferAttachType_Color0:       return true;
			case FrameBufferAttachType_Depth:        return true;
			case FrameBufferAttachType_Stencil:      return true;
			case FrameBufferAttachType_DepthStencil: return true; // TODO: Is not in the core, check for support
			default: return false;
		}
		#endif
		return true;
	}
	inline bool isSupported(FrameBufferColorBufferType colorBufType){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(colorBufType){
			case FrameBufferAttachType_Color0: return true;
			default:                           return false;
		}
		return false;
		#endif
		return true;
	}
	inline bool isSupported(WindowBufferSource source){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		return false;
		#endif
		return true;
	}
	inline bool isSupported(IndexDataType type){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(type == IndexDataType_32BIT) return false;
		#endif
		return true;
	}
	inline bool isSupported(PixelDataType type){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		if(type == PixelDataType_UByte ) return true;
		if(type == PixelDataType_UShort_5_6_5 ) return true;
		if(type == PixelDataType_UShort_4_4_4_4 ) return true;
		if(type == PixelDataType_UShort_5_5_5_1 ) return true;
		return false;
		#endif
		return true;
	}
	inline bool isSupported(PixelDataFormat type){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(type){
			case PixelDataFormat_A    :
			case PixelDataFormat_L    :
			case PixelDataFormat_LA   :
			case PixelDataFormat_RGB  :
			case PixelDataFormat_RGBA : return true;
			default                   : return false;
		}
		#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		switch(type){
			case PixelDataFormat_A   :
			case PixelDataFormat_L   :
			case PixelDataFormat_LA  : return false;
			default                  : return true;
		}
		#endif
	};

	inline bool isSupportedTextureFormat(ImageFormat imformat){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(imformat){
			// very few supported formats (in core specs)
			// TODO: extend with run-time extension checks
			case ImageFormat_Compr_RGB_PVRTC_4  : // TODO: check extension
			case ImageFormat_Compr_RGB_PVRTC_2  : // TODO: check extension 
			case ImageFormat_Compr_RGBA_PVRTC_4 : // TODO: check extension
			case ImageFormat_Compr_RGBA_PVRTC_2 : // TODO: check extension
			case ImageFormat_Compr_RGB_ETC1     : // TODO: check extension
			case ImageFormat_A    :
			case ImageFormat_L    :
			case ImageFormat_LA   :
			case ImageFormat_RGB  :
			case ImageFormat_RGBA : return true;
			default               : return false;
		}
		#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		switch(imformat){
				// compressed ES formats
			case ImageFormat_Compr_RGB_PVRTC_4 :
			case ImageFormat_Compr_RGB_PVRTC_2 :
			case ImageFormat_Compr_RGBA_PVRTC_4:
			case ImageFormat_Compr_RGBA_PVRTC_2:
			case ImageFormat_Compr_RGB_ETC1:
				// legacy formats supported by ES 2.0
			case ImageFormat_None:
			case ImageFormat_A :
			case ImageFormat_L :
			case ImageFormat_LA: return false;
			default: return true;
		}
		#endif
	}

	inline bool isSupportedRenderBufferFormat(ImageFormat imformat){
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		switch(imformat){
			// very few formats are supported in core
			// TODO: Check extensions if they allow more types
			case ImageFormat_RGBA4   :
			case ImageFormat_RGB5_A1 :
			case ImageFormat_RGB565  :
			case ImageFormat_D16     :
			case ImageFormat_S       :
			case ImageFormat_S8      : return true;
			default                  : return false;
		}
		#elif RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		switch(imformat){
			case ImageFormat_None :
				// Texture-Only formats
			case ImageFormat_RGB8    :
			case ImageFormat_RGB8I   :
			case ImageFormat_RGB8UI  :
			case ImageFormat_RGB16   :
			case ImageFormat_RGB16F  :
			case ImageFormat_RGB16I  :
			case ImageFormat_RGB16UI :
			case ImageFormat_RGB32F  :
			case ImageFormat_RGB32I  :
			case ImageFormat_RGB32UI :
			case ImageFormat_RGB9_E5 :
				// Legacy formats
			case ImageFormat_A:
			case ImageFormat_L:
			case ImageFormat_LA:
				// OpenGL ES Only formats
			case ImageFormat_RGBA4   :
			case ImageFormat_RGB5_A1 :
			case ImageFormat_RGB565  : return false;
			default                  : break;
		}
		return !isCompressedFormat(imformat);
		#endif
	}

	inline bool isCompressedFormat(ImageFormat format){
		switch(format){
			case ImageFormat_Compr_R_RGTC         :
			case ImageFormat_Compr_R_Signed_RGTC  :
			case ImageFormat_Compr_RG_RGTC        :
			case ImageFormat_Compr_RG_SIGNED_RGTC :
			case ImageFormat_Compr_RGB_S3TC_DXT1  :
			case ImageFormat_Compr_RGBA_S3TC_DXT1 :
			case ImageFormat_Compr_RGBA_S3TC_DXT3 :
			case ImageFormat_Compr_RGBA_S3TC_DXT5 :
			case ImageFormat_Compr_RGB_PVRTC_4    :
			case ImageFormat_Compr_RGB_PVRTC_2    :
			case ImageFormat_Compr_RGBA_PVRTC_4   :
			case ImageFormat_Compr_RGBA_PVRTC_2   :
			case ImageFormat_Compr_RGB_ETC1: return true;
			default: break;
		}
		return false;
	}

	inline bool isDepthFormat(ImageFormat imformat){
		if(imformat==ImageFormat_D) return true;
		switch(imformat){
			case ImageFormat_D16    :
			case ImageFormat_D24    :
			case ImageFormat_D32F   :
			case ImageFormat_D32    :
			case ImageFormat_D24S8  : 
			case ImageFormat_D32FS8 : return true;
			default                 : return false;
		}
	}
	inline bool isStencilFormat(ImageFormat imformat){
		if(imformat==ImageFormat_S) return true;
		switch(imformat){
			case ImageFormat_S1     :
			case ImageFormat_S4     :
			case ImageFormat_S8     :
			case ImageFormat_S16    :
			case ImageFormat_D24S8  : 
			case ImageFormat_D32FS8 : return true;
			default                 : return false;
		}
	}
	inline bool isColorFormat(ImageFormat imformat){
		if(imformat==ImageFormat_None) return false;
		return !isDepthFormat(imformat) && !isStencilFormat(imformat);
	}
	inline bool isDepthFormat(PixelDataFormat pxformat){
		switch(pxformat){
			case PixelDataFormat_D  :
			case PixelDataFormat_DS : return true;
			default                 : return false;
		}
	};
	inline bool isStencilFormat(PixelDataFormat pxformat){
		switch(pxformat){
			case PixelDataFormat_S  :
			case PixelDataFormat_DS : return true;
			default                 : return false;
		}
	};
	inline bool isDepthStencilFormat(PixelDataFormat pxformat){
		switch(pxformat){
			case PixelDataFormat_DS : return true;
			default                 : return false;
		}
	}
	inline bool isColorFormat(PixelDataFormat pxformat){
		switch(pxformat){
			case PixelDataFormat_D  :
			case PixelDataFormat_S  :
			case PixelDataFormat_DS : return false;
			default                 : return true;
		}
	};


	inline size_t getIndexDataByteSize(IndexDataType type){
		if(!isSupported(type))     return 0;
		switch(type){
			case GL_UNSIGNED_INT:   return 4;
			case GL_UNSIGNED_SHORT: return 2;
			case GL_UNSIGNED_BYTE:  return 1;
		}
		return 0;
	}
	inline const char* getVertexAttribSemanticStr(VertexAttribSemantic sem){
		return gVertexAttribSemanticStr[sem];
	}
	inline uchar getPixelDataChannelCount(PixelDataFormat format){
		switch(format){
			case PixelDataFormat_R     :
			case PixelDataFormat_G     :
			case PixelDataFormat_B     :
			case PixelDataFormat_D     :
			case PixelDataFormat_A     :
			case PixelDataFormat_L     :
			case PixelDataFormat_S     :
			case PixelDataFormat_iR    :
			case PixelDataFormat_iG    :
			case PixelDataFormat_iB    :
				return 1;
			case PixelDataFormat_DS    :
			case PixelDataFormat_RG    :
			case PixelDataFormat_LA    :
			case PixelDataFormat_iRG   :
				return 2;
			case PixelDataFormat_RGB   :
			case PixelDataFormat_BGR   :
			case PixelDataFormat_iRGB  :
			case PixelDataFormat_iBGR  :
				return 3;
			case PixelDataFormat_RGBA  :
			case PixelDataFormat_BGRA  :
			case PixelDataFormat_iRGBA :
			case PixelDataFormat_iBGRA :
				return 4;
			default:
				// not possible
				return 0;
		}
	}

}

#endif // _RENG_DEFINES_H_
