/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_RENDERMATRIXMANAGER_H_
#define _RENG_RENDERMATRIXMANAGER_H_

#include <vector>

#include <cml/cml.h>

#include "REng/Defines.h"
#include "REng/Singleton.h"
#include "REng/GPU/RenderProperty.h"

namespace REng{
	
	/*!
	 *  @brief This class is a helper to the render system. 
	 *         It manages model, view, projection and other matrices that may be directly derived from those.
	 *         It offers methods that can replace glLoadMatrix, glFrustum, gluPerspective and gluOrtho.
	 *         It also offers a matrix stack (of non-limited dynamic size) for model, view and 
	 *            projection matrices.
	 *         It stores the uniforms bound to render matrices and auto-updates them
	 *            when the matrices are updated, without a need to call render pass activation
	 *         It is written to only update derived matrices when tehy are required / used by a uniform.
	 *  @author Adil Yalcin
	 *  @version 1.0
	 */
	class RENGAPI RenderMatrixManager : public Singleton<RenderMatrixManager> {
	public:
		//! @brief Initializes all basic matrices to identity
		//! @note Can be constructed any time, does not depend on other initializations
		RenderMatrixManager(void);
		~RenderMatrixManager(void);

		static RenderMatrixManager& getSingleton(void);
		static RenderMatrixManager* getSingletonPtr(void);

		//! @brief Sets the active model matrix
		//! @param mat The matrix storing model transformation
		//! @param updCur Set to true if you want currently attached and related uniforms 
		//!        to be updated with this call
		void setModel(const Matrix4& mat, bool updCur = false);

		//! @brief Sets the active view matrix
		//! @param mat The matrix storing view transformation
		//! @param updCur Set to true if you want currently attached and related uniforms 
		//!        to be updated with this call
		void setView(const Matrix4& mat, bool updCur = false);

		//! @brief Sets the active projection matrix
		//! @param mat The matrix storing projection transformation
		//! @param updCur Set to true if you want currently attached and related uniforms 
		//!        to be updated with this call
		void setProjection(const Matrix4& mat, bool updCur = false);

		//! Reads and sets view-projection matrix information from the camera object
		void setViewProjection(const Camera& ca, bool updCur = false);

		//! Sets the model-view-projection matrices so that when the defult plane mesh is drawn,
		//! the output will be aligned to cover all viewport
		//! @note You have to set the viewport dimentions outside this method
		void setKernelMatrices();

		/************************************************************************/
		/* STACK OPERATIONS                                                     */
		/************************************************************************/

		//! @brief Pushes the current model matrix into model matrix stack
		void pushModel();

		//! @brief Pushes the current view matrix into model matrix stack
		void pushView();

		//! @brief Pushes the current projection matrix into model matrix stack
		void pushProjection();

		//! @brief Pushes the current model,view and projection matrices into internal matrix stacks
		void pushAll();

		//! @brief Pops the topmost model matrix in model matrix stack and replace current model matrix with
		//!        the popped matrix. If model stack has no matrices, has no effect.
		//! @return False if there is no matrix in model stack, true otherwise
		bool popModel();

		//! @brief Pops the topmost view matrix in model matrix stack and replace current view matrix with
		//!        the popped matrix.  If model stack has no matrices, has no effect.
		//! @return False if there is no matrix in view stack, true otherwise
		bool popView();

		//! @brief Pops the topmost projection matrix in model matrix stack and replace current projection matrix with
		//!        the popped matrix.  If model stack has no matrices, has no effect.
		//! @return False if there is no matrix in projection stack, true otherwise
		bool popProjection();

		//! @brief Equivalent to calling popModel, popView and popProjection methods in sequence
		//! @return True iff all the matrices have been successfully popped.
		bool popAll();


		/************************************************************************/
		/* GETTERS                                                              */
		/************************************************************************/

		const Matrix4& getMat_Model() const;
		const Matrix4& getMat_View() const;
		const Matrix4& getMat_Proj() const;


		// *******************************************
		// Matrices directly derived from model matrix
		// *******************************************

		const Matrix4& getMat_ModelInv() const;
		const Matrix4& getMat_ModelTrans() const;
		const Matrix4& getMat_ModelInvTrans() const;

		// ******************************************
		// Matrices directly derived from view matrix
		// ******************************************

		const Matrix4& getMat_ViewInv() const;
		const Matrix4& getMat_ViewTrans() const;
		const Matrix4& getMat_ViewInvTrans() const;

		// ************************************************
		// Matrices directly derived from projection matrix
		// ************************************************

		const Matrix4& getMat_ProjInv() const;
		const Matrix4& getMat_ProjTrans() const;
		const Matrix4& getMat_ProjInvTrans() const;;

		// *********************************************
		// Matrices derived from model and view matrices
		// *********************************************

		const Matrix4& getMat_ModelView() const;
		const Matrix4& getMat_ModelViewInv() const;
		const Matrix4& getMat_ModelViewTrans() const;
		const Matrix4& getMat_ModelViewInvTrans() const;
		const Matrix3& getMat_Normal() const;

		// **************************************************
		// Matrices derived from view and projection matrices
		// **************************************************

		const Matrix4& getMat_ViewProj() const;
		const Matrix4& getMat_ViewProjInv() const;
		const Matrix4& getMat_ViewProjTrans() const;
		const Matrix4& getMat_ViewProjInvTrans() const;

		// *********************************************************
		// Matrices derived from model, view and projection matrices
		// *********************************************************

		const Matrix4& getMat_ModelViewProj() const;
		const Matrix4& getMat_ModelViewProjInv() const;
		const Matrix4& getMat_ModelViewProjTrans() const;
		const Matrix4& getMat_ModelViewProjInvTrans() const;

		//! @brief Updates the uniform data by using the uniform semantic
		//! @param uniform The uniform to be updated. If auto name is None, no update is performed.
		//! @return True if the given uniform has been updated.
		bool updateUniform(RenderProp_Uniform& uniform) const;

		//! @brief Makes all the uniform links null
		//! @note  Public for debugging purposes
		void resetUniformLinks();

	private:

		//! @brief Stores the active model matrix
		Matrix4 mMat_Model;

		//! @brief Stores the active view matrix
		Matrix4 mMat_View;

		//! @brief Stores the active projection matrix
		Matrix4 mMat_Proj;

		//! @brief Model matrix stack (stores pushed matrices)
		std::vector<Matrix4> mStack_Model;

		//! @brief View matrix stack (stores pushed matrices)
		std::vector<Matrix4> mStack_View;

		//! @brief Projection matrix stack (stores pushed matrices)
		std::vector<Matrix4> mStack_Proj;

		//! @brief Used as a bit field, stores dirty info per matrix.
		mutable uint mMat_Dirty;

		mutable Matrix4 mMat_ModelInv;              // 0x0001
		mutable Matrix4 mMat_ModelTrans;            // 0x0002
		mutable Matrix4 mMat_ModelInvTrans;         // 0x0004

		mutable Matrix4 mMat_ViewInv;               // 0x0008
		mutable Matrix4 mMat_ViewTrans;             // 0x0010
		mutable Matrix4 mMat_ViewInvTrans;          // 0x0020

		mutable Matrix4 mMat_ProjInv;               // 0x0040
		mutable Matrix4 mMat_ProjTrans;             // 0x0080
		mutable Matrix4 mMat_ProjInvTrans;          // 0x0100

		mutable Matrix4 mMat_ModelViewInv;          // 0x0200
		mutable Matrix4 mMat_ModelViewTrans;        // 0x0400
		mutable Matrix4 mMat_ModelViewInvTrans;     // 0x0800

		mutable Matrix4 mMat_ViewProjInv;           // 0x1000
		mutable Matrix4 mMat_ViewProjTrans;         // 0x2000
		mutable Matrix4 mMat_ViewProjInvTrans;      // 0x4000

		mutable Matrix4 mMat_ModelViewProjInv;      // 0x8000
		mutable Matrix4 mMat_ModelViewProjTrans;    // 0x10000
		mutable Matrix4 mMat_ModelViewProjInvTrans; // 0x20000

		mutable Matrix4 mMat_ModelView;             // 0x40000
		mutable Matrix4 mMat_ViewProj;              // 0x80000
		mutable Matrix4 mMat_ModelViewProj;         // 0x100000

		mutable Matrix3 mMat_Normal;                // 0x200000

		// methods below generate the matrix data from basic matrices

		void updateModelView(bool updCur=false) const;
		void updateViewProj(bool updCur=false) const;
		void updateModelViewProj(bool updCur=false) const;

		void updateModelInv(bool updCur=false) const;
		void updateModelTrans(bool updCur=false) const;
		void updateModelInvTrans(bool updCur=false) const;
		void updateViewInv(bool updCur=false) const;
		void updateViewTrans(bool updCur=false) const;
		void updateViewInvTrans(bool updCur=false) const;
		void updateProjInv(bool updCur=false) const;
		void updateProjTrans(bool updCur=false) const;
		void updateProjInvTrans(bool updCur=false) const;;
		void updateModelViewInv(bool updCur=false) const;
		void updateModelViewTrans(bool updCur=false) const;
		void updateModelViewInvTrans(bool updCur=false) const;
		void updateViewProjInv(bool updCur=false) const;
		void updateViewProjTrans(bool updCur=false) const;
		void updateViewProjInvTrans(bool updCur=false) const;
		void updateModelViewProjInv(bool updCur=false) const;
		void updateModelViewProjTrans(bool updCur=false) const;
		void updateModelViewProjInvTrans(bool updCur=false) const;
		void updateNormal(bool updCur=false) const;

		// The rest stores the uniform currently bound to matrices

		mutable RenderProp_Uniform* mUni_Model;
		mutable RenderProp_Uniform* mUni_ModelInv;
		mutable RenderProp_Uniform* mUni_ModelTrans;
		mutable RenderProp_Uniform* mUni_ModelInvTrans;

		mutable RenderProp_Uniform* mUni_View;
		mutable RenderProp_Uniform* mUni_ViewInv;
		mutable RenderProp_Uniform* mUni_ViewTrans;
		mutable RenderProp_Uniform* mUni_ViewInvTrans;

		mutable RenderProp_Uniform* mUni_Proj;
		mutable RenderProp_Uniform* mUni_ProjInv;
		mutable RenderProp_Uniform* mUni_ProjTrans;
		mutable RenderProp_Uniform* mUni_ProjInvTrans;

		mutable RenderProp_Uniform* mUni_ModelView;
		mutable RenderProp_Uniform* mUni_ModelViewInv;
		mutable RenderProp_Uniform* mUni_ModelViewTrans;
		mutable RenderProp_Uniform* mUni_ModelViewInvTrans;

		mutable RenderProp_Uniform* mUni_ViewProj;
		mutable RenderProp_Uniform* mUni_ViewProjInv;
		mutable RenderProp_Uniform* mUni_ViewProjTrans;
		mutable RenderProp_Uniform* mUni_ViewProjInvTrans;

		mutable RenderProp_Uniform* mUni_ModelViewProj;
		mutable RenderProp_Uniform* mUni_ModelViewProjInv;
		mutable RenderProp_Uniform* mUni_ModelViewProjTrans;
		mutable RenderProp_Uniform* mUni_ModelViewProjInvTrans;
		
		mutable RenderProp_Uniform* mUni_Normal;
	};

} // namespace REng

#endif // _RENG_RENDERMATRIXMANAGER_H_
