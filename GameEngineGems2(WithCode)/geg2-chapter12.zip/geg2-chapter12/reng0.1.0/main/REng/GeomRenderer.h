/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GEOM_RENDERER_H_
#define _RENG_GEOM_RENDERER_H_

#include "REng/Prerequisites.h"

//! is a singleton
#include "REng/Singleton.h"
//! works with geom objects
#include "REng/Geom/Geom.h"
//! geomrenderer generates renderables from geom's
#include "REng/RenderQueue.h"

namespace REng{

	//! @brief Specifies how a given geometry-volume- should be drawn
	enum GeomRenderMode {
		GeomRender_Wire ,
		GeomRender_Solid
	};

	/*!
	 *  @brief This class provides methods that can render given geometric primitives
	 *         The methods below are separated from basic Geom headers, so that they are not dependent
	 *          on other large REng rendering components.
	 *  @remark
	 *   - Most of the geom are rendered using the same geometry data/buffers.
	 *     So, try to enable batching (from RenderSystem) and render all geoms of same 
	 *       type in one render queue.
	 *  @author Adil Yalcin
	 */
	// Internal Note: ES does not support polygon modes.
	//       - To draw in wire-frame, you need to send Line-based primitives.
	//       - All wire-frame drawing code MUST use line-based primitives.
	// Public Note: The methods below DO NOT SET RENDERING STATES (GENERIC/UNIFORM/TEXTURE ETC)
	//       - you MUST specify your shaders and render states before drawing a primitive
	class GeomRenderer : public Singleton<GeomRenderer> {
	public:
		GeomRenderer(void);
		~GeomRenderer(void);

		// Singleton access methods
		static GeomRenderer& getSingleton(void);
		static GeomRenderer* getSingletonPtr(void);

		//! @brief Fall-back method if a render method is not defined
		//! @param g The geom to be rendered
		//! @param mode The render mode that is requested
		static Renderable getRenderable(const Geom& g, GeomRenderMode mode);

		//! @brief If an unknown object of generic volume type is given
		static Renderable getRenderable(const GeomVolume& g, GeomRenderMode mode);

		//! @brief Renders a given point list
		//! @param g The point list to be rendered
		//! @note  Rendering each point in a separate draw call is not optimal
		//!        You should avoid such cases
		//! @note  You may want to render each point as a volumetric sphere.
		//!        You need to generate spheres from your point and render a sphere then.
		//! @remark The points are rendered in point render mode, you cannot specify wire or solid modes
		//! TODO: Move this functionality elsewhere, store/manage permanent buffers
		//! TODO: Not implemented
		Renderable getRenderable(const GeomPointList& g, GeomRenderMode mode);

		//! @brief Renders a given plane
		//! @remark Costs one draw command to be send in each call
		//! TODO: Not implemented
		Renderable getRenderable(const GeomPlane& plane, GeomRenderMode mode);

		//! @brief Renders a given aab 
		//! @remark Costs one draw command to be send in each call
		Renderable getRenderable(const GeomAxisAlignedBox& aabb, GeomRenderMode mode);

		//! @brief Renders a given ob 
		//! @remark Costs one draw command to be send in each call
		Renderable getRenderable(const GeomOrientedBox& obb, GeomRenderMode mode);

		//! @brief Renders a given sphere 
		//! @remark Costs one draw command to be send in each call
		Renderable getRenderable(const GeomSphere& sphere, GeomRenderMode mode);

		//! @brief Renders a given ray 
		//! @remark Costs one draw command to be send in each call
		Renderable getRenderable(const GeomRay& ray);

		//! @brief Renders a given cylinder 
		//! TODO: Not implemented
		Renderable getRenderable(const GeomCylinder& cylinder, GeomRenderMode mode);

		//! @brief Renders a given plane bounded volume
		//! TODO: Not implemented
		Renderable getRenderable(const GeomPlaneBoundedVolume& pbv, GeomRenderMode mode);

		//! @brief Renders a given line ???
		// static void renderGeom(const GeomLine& line, GeomRenderMode mode);

	private:
		//! @brief Updates model matrix for obb rendering
		void getModelMatrix(const GeomOrientedBox& box, Matrix4& toRet);
		void getModelMatrix(const GeomSphere& sphere, Matrix4& toRet);
		void getModelMatrix(const GeomCylinder& cyl, Matrix4& toRet);
		void getModelMatrix(const GeomRay& ray, Matrix4& toRet);

		//! @brief Sets the model matrix from translation and scale components only
		void getModelMatrix(const cml::vector3f& translation, const cml::vector3f& scale, Matrix4& toRet);
	};

} // namespace REng

#endif // _RENG_GEOM_RENRERER_H_
