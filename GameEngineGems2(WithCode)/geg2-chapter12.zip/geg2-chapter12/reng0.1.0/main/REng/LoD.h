/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_LOD_H_
#define _RENG_LOD_H_

#include <vector>

#include "REng/Defines.h"

namespace REng{

	/*!
	 *  @brief This class provides a basic interface for LoD'able objects (of some type T)
	 *
	 *     - LoDed data is managed using a vector container.
	 *     - The derived class can define how to instantiate an LoD object, 
	 *           to allow customized object constructors on create time.
	 *     - This class does not allow pointer-sharing of LoDed data. It is based on simple pointers.
	 *     - This class is the "owner" of the LoDed objects, and all LoDed objects attached are 
	 *          destroyed on deconstruction.
	 *
	 *  TODO: describe how a "suitable" LoD'ed data is retrieved (use material's documentation as a reference)
	 *
	 *  @author Adil Yalcin
	 */
	template<typename T>
	class RENGAPI LoD{
	public:
		//! @brief LoD data is stored with view and dist indices
		struct LoDMapping{
			T*    mLoDData;
			uchar mViewIndex;
			uchar mDistIndex;
		};

		// TODO: use boost ptr_container class instead
		typedef std::vector<LoDMapping> LoDMappingList;

		typedef typename LoDMappingList::iterator iterator;
		typedef typename LoDMappingList::const_iterator const_iterator;

		virtual ~LoD();

		//! @brief Creates a new LoD'ed data
		//! @param viewIndex      the view index (used for autostereoscobic rendering)
		//! @param distanceIndex  the distance index
		//! @return 0, if an LoD'ed data with given conf exists. Else, the newly created LoD'ed data
		T* createLoDedData(uchar viewIndex = 0, uchar distanceIndex = 0);

		//! @brief Removes the LoD'ed data in the given view and LoD index, if any
		//! @return True if an LoD'ed data was successfully removed, false otherwise
		bool destroyLodedData(uchar viewIndex, uchar lodIndex);

		//! @brief Removes a specific LoD data in the given index
		//! @param index Must be between 0 and techniqueCount.
		void destroyLoDedData(uchar index);

		//! @brief Removes all the LoD'ed data
		void clear(void);

		//! @return The number of LoD specifications this LoD hierarchy holds
		size_t getLoDCount(void) const;

		//! @return The current maximum view technique level.
		uchar getMaxViewIndex(void) const;

		//! @return The current maximum LoD technique level.
		uchar getMaxDistIndex(void) const;

		//! @return The most suitable technique given the parameters.
		/*! TODO */
		T* getSuitableData(uchar viewIndex=0, uchar distIndex=0);

		//! @copydoc getSuitableData(uchar viewIndex=0, uchar distIndex=0)
		//! const variant
		const T* getSuitableData(uchar viewIndex=0, uchar distIndex=0) const;

		//! Use it to iterate over the LoD data list
		typename LoDMappingList::iterator begin(){
			return mLoDList.begin();
		}
		//! Use it to iterate over the LoD data list
		typename LoDMappingList::iterator end(){
			return mLoDList.end();
		}

		//! Use it to iterate over the LoD data list
		typename LoDMappingList::const_iterator begin() const {
			return mLoDList.begin();
		}
		//! Use it to iterate over the LoD data list
		typename LoDMappingList::const_iterator end() const {
			return mLoDList.end();
		}

	protected:

		//! Stores the list of LoD data and their associated view and LoD indexes
		LoDMappingList mLoDList;

		//! The maximum view index in LOD mapping
		unsigned char mMaxViewIndex;  

		//! The maximum distance index in LOD mapping
		unsigned char mMaxDistIndex;

		//! recalculates all cache data using technique mapping
		void _calculateMaxIndexes();

		virtual T* constructLoDData();

	};


	//////////////////////////////////////////////////////////////////////////
	// TODO : move below to an inline file.
	//////////////////////////////////////////////////////////////////////////

	template<class T>
	T* LoD<T>::getSuitableData(uchar viewIndex, uchar distIndex){
		size_t loop = mLoDList.size();
		LoDMapping *selectedMap = 0;
		for(size_t i=0 ; i<loop ; i++){
			if(viewIndex < mLoDList[i].mViewIndex) continue;
			if(distIndex  < mLoDList[i].mDistIndex ) continue;

			if(selectedMap){
				if(selectedMap->mViewIndex > mLoDList[i].mViewIndex) continue;
				if(selectedMap->mDistIndex > mLoDList[i].mDistIndex) continue;
			}
			selectedMap = &(mLoDList[i]);
		}
		if(selectedMap == 0) return 0;
		return selectedMap->mLoDData;
	}

	template<class T>
	const T* LoD<T>::getSuitableData(uchar viewIndex, uchar distIndex) const{
		size_t loop = mLoDList.size();
		if(loop==0) return 0;
		const LoDMapping *selectedMap = 0;
		for(size_t i=0 ; i<loop ; i++){
			if(viewIndex < mLoDList[i].mViewIndex) continue;
			if(distIndex  < mLoDList[i].mDistIndex ) continue;

			if(selectedMap){
				if(selectedMap->mViewIndex > mLoDList[i].mViewIndex) continue;
				if(selectedMap->mDistIndex  > mLoDList[i].mDistIndex ) continue;
			} else {
				selectedMap = &(mLoDList[0]);
			}
		}
		return selectedMap->mLoDData;
	}

	template<class T>
	T* LoD<T>::createLoDedData(uchar viewIndex, uchar lodIndex){
		size_t loop = mLoDList.size();
		for(size_t i=0 ; i<loop ; i++){
			if(lodIndex<mLoDList[i].mDistIndex && viewIndex<mLoDList[i].mViewIndex)
				// view and LoD indices match parameters, cannot create new technique
				return 0;
		}

		LoDMapping newMapping;
		newMapping.mDistIndex = lodIndex;
		newMapping.mViewIndex = viewIndex;
		newMapping.mLoDData = constructLoDData();
		mLoDList.push_back(newMapping);

		_calculateMaxIndexes();
		return newMapping.mLoDData;
	}

	template<class T>
	void LoD<T>::_calculateMaxIndexes(){
		mMaxViewIndex = 0;
		mMaxDistIndex = 0;
		size_t loop = mLoDList.size();
		for(size_t i=0 ; i<loop ; i++){
			if(mMaxDistIndex<mLoDList[i].mDistIndex)
				mMaxDistIndex = mLoDList[i].mDistIndex;
			if(mMaxViewIndex<mLoDList[i].mViewIndex)
				mMaxViewIndex = mLoDList[i].mViewIndex;
		}
	}

	template<class T>
	size_t LoD<T>::getLoDCount(void) const{
		return mLoDList.size();
	}

	template<class T>
	uchar LoD<T>::getMaxViewIndex(void) const{
		return mMaxViewIndex;
	}

	template<class T>
	uchar LoD<T>::getMaxDistIndex(void) const{
		return mMaxDistIndex;
	}

	template<class T>
	T* LoD<T>::constructLoDData(){
		return new T();
	}

	template<class T>
	bool LoD<T>::destroyLodedData(uchar viewIndex, uchar lodIndex) {
		typename LoDMappingList::iterator it = mLoDList.begin();
		typename LoDMappingList::iterator end = mLoDList.end();
		for( ; it != end ; it++) {
			if ( (*it).mDistIndex  != lodIndex ) continue;
			if ( (*it).mViewIndex != viewIndex ) continue;
			// LoD and view indexes match
			mLoDList.erase(it);
			return true;
		}
		return false; 
	}

	template<class T>
	void LoD<T>::clear(void){
		typename LoDMappingList::iterator it  = mLoDList.begin();
		typename LoDMappingList::iterator end = mLoDList.end();
		while(it != end) {
			delete(*it).mLoDData;
			it++;
		}
		mLoDList.clear();
	}

	template<class T>
	LoD<T>::~LoD(){
		clear();
	}

	template<class T>
	void LoD<T>::destroyLoDedData(uchar index){
		assert (index < mLoDList.size() && "Index out of bounds.");
		typename LoDMappingList::iterator it = mLoDList.begin() + index;
		delete (*it).mLoDData;
		mLoDList.erase(it);
	}


}

#endif

