/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_MESHGEOMGEN_H_
#define _RENG_MESHGEOMGEN_H_

#include "REng/Prerequisites.h"

//! stores some mesh geom's internally
#include "REng/Mesh.h"
//! Is a singleton
#include "REng/Singleton.h"

namespace REng{

	/*!
	 *  @brief You can use this class to get some simple renderable mesh geometries.
	 *         Supported types: Axis Aligned Box, Plane, Circle, Sphere, Cylinder
	 *  @todo  Capsule, Rounded Axis Aligned Box (?)
	 *  @author Adil Yalcin
	 */
	class RENGAPI MeshGeomGenerator : public Singleton<MeshGeomGenerator> {
	public:
		MeshGeomGenerator(void);
		~MeshGeomGenerator(void);

		// Singleton access methods
		static MeshGeomGenerator& getSingleton(void);
		static MeshGeomGenerator* getSingletonPtr(void);

		/*! @brief Mesh Info:
		 *  - It is a solid or wire-frame axis-aligned box.
		 *  - Its center is in (0,0,0).
		 *  - Has vertices at positions (+-1,+-1,+-1)
		` *  - Has position and texture coordinate(0) attributes.
		 *  @note An axis-aligned box is assigned as the mesh geom bound.
		 *  @param isSolid Set to false if you want a mesh composed of lines.
		 */
		MeshGeom& getUnitAAB(bool isSolid=true);

		/*! @brief Mesh info:
		 *  - It is a square.
		 *  - Its center is in (0,0,0).
		 *  - It is on the x-y axis.
		 *  - Its size is 2x2 units.
		 *  - Mesh has four vertices at positions (+-1,+-1)
		 *  - Normal of the plane is +z (0,0,1).
		 *  - Vertices have texture coord's (0,0 -> 1,1)
		 */
		MeshGeom& getUnitPlane();

		/*! @brief Mesh info:
		 *  - It is a circle, either filled (such as a disc) or wire-frame only.
		 *  - Its center is in (0,0,0).
		 *  - It is on x-y axis.
		 *  - Its radius is 1 unit.
		 *  - It is a filled render geometry (indexing type is triangle fan).
		 *  @note  Mesh index-vertex data is not cached (dynamic for each request).
		 *         If you want to re-use the mesh, create your own mesh-geom using shared index-vertex data.
		 *  @param filled True if you want the circle to be filled inside
		 *  @param subdivision The number of points on the circle (divided by four). Cannot be zero.
		 */
		MeshGeom getUnitCircle(uchar subdivision, bool filled);

		/*! @brief Mesh info:
		 *  - It is a filled sphere.
		 *  - Its center is in (0,0,0).
		 *  - Its radius is 1 unit.
		 *  - It is UV-mapped (0-1) using latitude-longitude approach.
		 *  - It is a filled render geometry (indexing type is separate triangles).
		 *  @param subdivision The number of sub-division applied to 20-sided icosahedron.
		 *  @note Each subdivision multiplies face count by four.
		 *  @note A subdivision of size "4" would be adequate for smooth results (produces about 2000 points on sphere!).
		 *  @note Mesh is tessellated using icosahedron approach:
		 *    Reference: http://www.glprogramming.com/red/chapter02.html
		 *  @note A sphere is assigned as the mesh geom bound.
		 */
		MeshGeom getUnitSphere(uchar subdivision);

		/*! Mesh info:
		 *  - It is a unit sphere with 0 subdivision.
		 */
		MeshGeom getUnitPoint();


		/*! Mesh info:
		 *  - It is a single line, pointing in -z direction, of length 1.
		 *  - Only position attribute is defined.
		 */
		MeshGeom getUnitRay();

		/*! Mesh Info:
		 *  - It is a cylinder with the sides filled.
		 *  - It is oriented along y-axis.
		 *  - Its base is at y=0 and its top is at y=1.
		 *  - This mesh includes no caps at the ends!
		 *  @param subdivision The number of slices along the side of the cylinder (divided by four). Cannot be zero.
		 *  @param topRadius The radius of top end. If 0, returns a cone
		 *  @todo Adding Texture U-V coordinates
		 */
		MeshGeom getCyclinder(uchar subdivision, float topRadius,bool lineRender=false);

		/*! Mesh Info:
		 *  - It is a cone with the sides filled.
		 *  - It is oriented along y-axis. (the bottom circle is on the x-z axis
		 *  - Its base is at y=0 and its top is at y=1.
		 *  - This mesh includes no cap at the bottom end!
		 *  @param subdivision The number of slices along the base of the cone (divided by four). Cannot be zero.
		 *  @todo Adding Texture U-V coordinates
		 */
		MeshGeom getCone(uchar subdivision);

		/*! Mesh Info:
		 *  - It is a torus with the sides filled.
		 *  - Its major circle is oriented along xz-axis and minor circle is oriented along y axis.
		 *  - Its center is at (0,0,0)
		 *  @param majorRadius The radius of major circle
		 *  @param majorSegments The number of segments perpendicular to major (xz) axes
		 *  @param minorRadius The radius of major circle, must be smaller or equal to majorRadius
		 *  @param minorSegments The number of segments perpendicular to minor (y) axes
		 */
		MeshGeom getTorus(float majorRadius, uchar majorSegments, float minorRadius, uchar minorSegments);

		/*! Allows retrieving renderable frustum planes from a given camera object
		 *  @param camera The camera that we want to get the frustum mesh of.
		 */
		MeshGeom getFrustum_WS(const REng::Camera& camera);

		/*! @brief Creates and returns a group node which holds a triad sphere hierarchy.
		 *  Mesh group info:
		 *  - It holds 3 circle meshes aligned to x-y-z axises, creating a spherical shape.
		 *  - The material of the meshes are set to static R-G-B colors respectively.
		 *  - Its center is in (0,0,0).
		 *  - The radius of circles is 1 unit.
		 *  - The primitives are lines and are not filled
		 *  @note The subdivision of internal circles are set to 4 automatically.
		 *  @param parent The node that the new node will be attached to
		 */
		GroupNode& createTriad_Sphere(GroupNode& parent);

		/*! @brief Creates and returns a group node which holds a triad arrow hierarchy.
		 *  Mesh group info:
		 *  - It holds 3 arrows aligned to x-y-z axises, creating a coordinate-axis like shape.
		 *  - The material of the meshes are set to static R-G-B colors respectively.
		 *  - Its center is in (0,0,0). TODO CHECK
		 *  - The radius of circles is 1 unit. TODO CHECK
		 *  - The primitives are filled primitives.
		 *  @param parent The node that the new node will be attached to
		 */
		GroupNode& createTriad_Arrow(GroupNode& parent);

	private:
		//! @brief The cached triad node arrow
		GroupNode* mNodeTriadArrow;
		void initNodeTriadArrow();
		//! @brief The cached triad node sphere
		GroupNode* mNodeTriadSphere;
		void initNodeTriadSphere();

		//! @remark Since it is not a complete mesh, does not store material information
		MeshGeom mMesh_Unit_AAB_Wire;
		//! @brief If Unit_AAB_Wire is generated, does nothing.
		//!        Else, updates th=e mesh geom to hold correct vertex and index data
		void generate_Unit_AAB_Wire();

		//! @remark Since it is not a complete mesh, does not store material information
		MeshGeom mMesh_Unit_AAB_Solid;
		//! @brief If Unit_AAB_Solid is generated, does nothing.
		//!        Else, updates th=e mesh geom to hold correct vertex and index data
		void generate_Unit_AAB_Solid();

		//! @brief Vertex buffer that stores Unit AAB positions,
		//!        shared between solid/wire-frame modes
		//!        Is a unit axis-aligned box (-1,+1 in every axis)
		GPUVertexBufferPtr mPos_Unit_AAB;
		//! @brief Generates mPos_Unit_AABB data
		void genPos_Unit_AAB();

		MeshGeom mMesh_Unit_Plane;

		//! helper for icosahedron-based sphere tessellation
		void subdivide(
			float* vertData, // the array holding vertex data
			float* vert1, float* vert2, float* vert3, // the vertices for the triangle to be subdivided
			uchar depth, //if 0, create triangles from ind1, ind2 and ind3
			size_t& vdIndNext // the first free index in vertData
		);
	};

} // namespace REng

#endif // _RENG_MESHGEOMGEN_H_
