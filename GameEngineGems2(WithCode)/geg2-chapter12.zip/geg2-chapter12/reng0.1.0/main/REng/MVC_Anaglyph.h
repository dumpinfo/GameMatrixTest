/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MVC_ANAGLYPH_H_
#define _RENG_MVC_ANAGLYPH_H_

#include "REng/MultiViewCompositor.h"

// uses a GPU Program 
#include "REng/GPU/GPUProgram.h"
// uses uniforms directly...
#include "REng/GPU/RenderProperty.h"
// uses its own MeshGeom
#include "REng/Mesh.h"

namespace REng{

	//! Possible anaglyph configurations used by the default anaglyph compositor
	enum AnaglyphType{
		Anaglyh_Mono_R_G, // Monochrome R-G filter
		Anaglyh_Mono_R_B, // Monochrome R-B filter
		Anaglyh_R_GB      // Red-Cyan filter
	};

	/*!
	 * @brief A multi view compositor for anaglyph type displays.
	 * @note Default anaglyph type is Red-Cyan
	 * @author Adil Yalcin
	 */
	class RENGAPI MVC_Anaglyph : public REng::MultiViewCompositor {
	public:
		MVC_Anaglyph();
		~MVC_Anaglyph();

		bool init(Viewport& vp);
		bool clear();
		bool mergeViews(MultiViewBuffer& mvb);

		void setType(AnaglyphType _type) const;
		AnaglyphType getType() const;

		//! If true, the left-right image pairs are reversed
		void setViewsReversed(bool flag) const;
		bool isViewsReversed() const;

	protected:

		mutable AnaglyphType mType;
		mutable bool mViewsReversed;

		mutable REng::GPUProgram *mCompProg;
		mutable REng::GPUShader  *mCompFragS;
		//! The uniform property of mCompProg which is used to set left image sampler
		mutable REng::RenderProp_Uniform *mImageSampler_L;
		//! The uniform property of mCompProg which is used to set right image sampler
		mutable REng::RenderProp_Uniform *mImageSampler_R;

		bool updateCompProg() const;

		//! The geometry drawn in the merge step
		REng::MeshGeom mCompositorGeom;
		void initCompositorGeom();
	};

	/*!
	 * @brief A multi view compositor for anaglyph type displays.
	 * @note Default anaglyph type is Red-Cyan
	 * @note Works with on-target multi0view buffers using color mode enable/disables.
	 * @author Adil Yalcin
	 */
	class RENGAPI MVC_Anaglyph_OnTarget : public REng::MultiViewCompositor {
	public:
		MVC_Anaglyph_OnTarget();
		~MVC_Anaglyph_OnTarget();

		bool init(Viewport& vp);
		bool clear();

		//! Updates color modes (Ex: Only red color channel of fragments passes to render buffer, etc)
		bool setActiveView(size_t viewIndex);
		bool beginFrame();
		bool endFrame();

		//////////////////////////////////////////////////////////////////////////
		// ANAGLYPH OPTIONS

		void setType(AnaglyphType _type) const;
		AnaglyphType getType() const;

	protected:
		mutable AnaglyphType mType;
		mutable RenderProp_ColorMask mLeftColorMask;
		mutable RenderProp_ColorMask mRightColorMask;
	};

} // namespace REng

#endif // _RENG_MVC_ANAGLYPH_H_
