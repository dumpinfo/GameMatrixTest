/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MVC_PARALLAX_H_
#define _RENG_MVC_PARALLAX_H_

#include "REng/MultiViewCompositor.h"

// uses a GPU Program 
#include "REng/GPU/GPUProgram.h"
// uses uniforms directly...
#include "REng/GPU/RenderProperty.h"
// uses its own MeshGeom
#include "REng/Mesh.h"

namespace REng{

	/*!
	 * @brief A multi view compositor for parallax-barrier type displays.
	 * @author Adil Yalcin, Attila Barsi (Holografika)
	 */
	class RENGAPI MVC_Parallax : public REng::MultiViewCompositor {
	public:
		MVC_Parallax();
		~MVC_Parallax();

		bool init(Viewport& vp);
		bool clear();
		bool mergeViews(MultiViewBuffer& mvb);

		//! If set to true, the individual views will be axis-converted on merge time.
		void setViewAxisTransposed(bool val) const;
		bool isViewAxisTransposed() const;

	protected:

		//! The GPU program which will merge two given textures into the frame buffer
		mutable REng::GPUProgram *mCompProg;
		mutable REng::GPUShader  *mCompFragS;
		//! The uniform property of mCompProg which is used to set left image sampler
		mutable REng::RenderProp_Uniform *mImageSampler_L;
		//! The uniform property of mCompProg which is used to set right image sampler
		mutable REng::RenderProp_Uniform *mImageSampler_R;

		mutable bool mTransposeViewAxis;
		bool updateCompProg() const;

		//! The geometry drawn in the merge step
		REng::MeshGeom mCompositorGeom;
		void initCompositorGeom();
		
	};

	/*!
	 * @brief A multi view compositor for parallax-barrier type displays.
	 * @note For on-screen-buffers and stencil-based stipple patterns. 
	 *       Use this one if you don't use your custom stencil operations inside the viewport
	 * @author Adil Yalcin
	 */
	class RENGAPI MVC_Parallax_Stencil : public REng::MultiViewCompositor {
	public:
		MVC_Parallax_Stencil();
		~MVC_Parallax_Stencil();

		bool init(Viewport& vp);
		bool clear();

		//! Updates stencil testing logic
		bool setActiveView(size_t viewIndex);
		bool beginFrame();
		bool endFrame();

		//! If you need your stencil-buffer to be reset in each frame, you should enable this flag
		bool mResetStencilEveryFrame;

		//! If set to true, the individual views will be axis-converted on merge time.
		void setViewAxisTransposed(bool val) const;
		bool isViewAxisTransposed() const;

	private:
		//! The GPU program which generates the stencil pattern
		mutable REng::MaterialPtr mStencilGenMat;

		mutable bool mTransposeViewAxis;
		bool updateStencilPattern() const;

		void updateStencilGenProg() const;

		//! The geometry drawn in the merge step
		REng::MeshGeom mFillerGeom;
		void initFillerGeom();
	};


} // namespace REng

#endif // _RENG_MVC_PARALLAX_H_
