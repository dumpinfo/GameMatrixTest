/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_NODE_H_
#define _RENG_NODE_H_

#include "REng/Prerequisites.h"
#include "REng/Singleton.h"

// nodes store mesh
#include "REng/Mesh.h"

#include <vector>
#include <boost/shared_ptr.hpp>

// Ray intersection queries with nodes
#include "REng/Geom/GeomRay.h"

namespace REng {
	
	typedef std::vector<SceneNode*> SceneNodeList;

	//! @brief Can be used to get RTTI of a scene node type
	enum SceneNodeType{
		SceneNode_Group,
		SceneNode_Switch,
		SceneNode_LOD,
		SceneNode_Light,
		SceneNode_Root,
		SceneNode_Camera,
		SceneNode_Mesh
	};

	///! The scene-graph node inheritance relations 
	enum NodeInheritanceFlag {
		///! The node will inherit position (translation) information from the parent
		NodeInheritance_Translation  = 0x01,
		///! The node will inherit orientation (rotation) information from the parent
		NodeInheritance_Rotation  = 0x02,
		///! The node will inherit scale information from the parent
		NodeInheritance_Scale     = 0x04,
		///! The node will inherit the billboard information from the parent
		NodeInheritance_Billboard = 0x08
	};

	/** The type of billboard (NOT USED CURRENTLY, ONLY FOR REFERENCE, FROM OGRE */
	enum BillboardType {
		/// Standard point billboard (default), always faces the camera completely and is always upright
		BBT_POINT,
		/// Billboards are oriented around a shared direction vector (used as Y axis) and only rotate around this to face the camera
		BBT_ORIENTED_COMMON,
		/// Billboards are oriented around their own direction vector (their own Y axis) and only rotate around this to face the camera
		BBT_ORIENTED_SELF,
		/// Billboards are perpendicular to a shared direction vector (used as Z axis, the facing direction) and X, Y axis are determined by a shared up-vector
		BBT_PERPENDICULAR_COMMON,
		/// Billboards are perpendicular to their own direction vector (their own Z axis, the facing direction) and X, Y axis are determined by a shared up-vector
		BBT_PERPENDICULAR_SELF
	};

	//! Stores a billboard target information
	class RENGAPI BillboardTarget{
	public:
		BillboardTarget();
		~BillboardTarget();

		BillboardTarget& operator=(const BillboardTarget& target);

		//! @brief The billboard position target (const) node
		const SceneNode *target;

		//! If null, the billboard up axis follows the target node's up axis
		//! If not, the billboard up axis will be attempted to match this up axis.
		boost::scoped_ptr<Vector3> upAxis;

		//! If null, billboard always "looks at directly" the target node.  
		//! If not,  billboard's look at direction must be perpendicular to this value.
		//! Possible use case: Make the perpendicular axis the "upwards" axis.
		boost::scoped_ptr<Vector3> lookPerpAxis;
	};

	//! @brief The node visitor class base interface
	class RENGAPI NodeVisitor{
	public:
		virtual void visit(SceneNode& node) = 0;
		virtual void visit(GroupNode& node) = 0;
		virtual void visit(RootNode& node) = 0;
		virtual void visit(SwitchGroupNode& node) = 0;
		virtual void visit(LODGroupNode& node) = 0;
		virtual void visit(MeshNode& node) = 0;
		virtual void visit(CameraNode& node) = 0;
		virtual void visit(LightNode& node) = 0;
	};

	/**
	 * @class SceneNode
	 * @brief Abstract class for nodes. The sub-classes define their own data and operations
	 *        on this data associated with the node.
	 * @note You can use SceneNodeType enumeration to learn the type of an actual node object.
	 */
	class RENGAPI SceneNode {
	private:
		//! Parent of this node.
		//! @note  Since only a group-node can hold children, only a group-node type can be a parent.
		//! @note  This node is not the owner of the parent, do not delete parent on destruction
		GroupNode* mParent;

		//! @brief The ID of the current node
		uint mID;

		//! @brief This is used to generate a unique ID for each new scene-node component
		static uint mUniqueNodeIDGen;

		//! @brief This is the data structure which holds ID->SceneNode mapping 
		//! TODO : other types of container/logic?
		static std::vector<SceneNode*> mNodeIDMapping;

		//! @brief Registers the given node (gives it a unique ID and keeps the mapping)
		static void registerNode(SceneNode& node);

		//! @brief UnRegisters the given node (removes the mapping of the scenNode)
		static void unregisterNode(SceneNode& node);

	protected:
		//! The type of the scene-node
		SceneNodeType mNodeType;

		//! Only constructor for the scene-node. (Note that this class has pure virtual methods, so 
		//!    scene-node objects cannot be created directly.)
		//! @param parent Can be 0 if the scene-node will have no parent.
		SceneNode(GroupNode* parent, SceneNodeType type);

		//! Copy constructor is disabled. Use cloning instead
		SceneNode(const SceneNode& node) {(void) node;}
		//! Assignment operator is disabled. Use cloning instead
		SceneNode& operator=(const SceneNode& node) { (void) node; return *this;}

	public:
		//! Destructor.
		virtual ~SceneNode();

		//! @return The type of the node
		SceneNodeType getType() const;

		//! @return The ID of the node
		uint getID() const;

		//! @return the scene node with the given ID
		static SceneNode* getSceneNode(uint id);

		//! @brief Clones this node's basic data to the given node. Basic data includes:
		//!  Inheritance options, Billboarding, Bounding volume and spatial information
		void cloneBasicData(SceneNode& node) const;

		/************************************************************************/
		/* VISITOR SUPPORT                                                      */
		/************************************************************************/
		virtual void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		//! Use this pointer to point to your application specific data, 
		//! to achieve a mapping from a node object to your application specific data
		//! @note This pointer is not used by the engine, yet initialized to null on initialization.
		void* mUserData;

		/************************************************************************/
		/* PARENT ACCESS                                                        */
		/************************************************************************/
	public:
		//! @brief This method allows changing the parent node of the current node after it is created.
		//! @param parent The parent this node will use (pointing to an existing object).
		//! @note  The current node is removed from the child list of the ex-parent-node.
		//! @note  If the parent update causes a cyclic graph, it is not applied and false is returned.
		//! @return True if the parent of this node is successfully updated, false otherwise
		virtual bool setParent(GroupNode& parent);
		//! @return Parent of this node.
		virtual const GroupNode* getParent() const;
		//! @return Parent of this node (non-const variant)
		virtual GroupNode* getParent();
		//! Detaches this node from the parent
		//! @note This node will NOT be visited during tree traversal. Use with precaution
		void detachFromParent();

		/************************************************************************/
		/* INHERITANCE                                                          */
		/************************************************************************/
	private:
		//! Stores the inheritance flags (initially : all-inherited)
		uint mInheritanceFlags;
	public:
		//! @brief Sets an inheritance flag of this node
		void setInheritanceFlag(NodeInheritanceFlag flag);
		//! @brief Un-sets (clears) an inheritance flag of this node
		void unsetInheritanceFlag(NodeInheritanceFlag flag);
		//! @return True if the given inheritance given is set to true in this node. False otherwise.
		bool isInherited(NodeInheritanceFlag flag) const;

		//! @brief Copies/clones the inheritance flags of this node to the given node
		void cloneInheritanceFlags(SceneNode& node) const;
		
		/************************************************************************/
		/* BILLBOARD                                                            */
		/************************************************************************/
	private:
		//! The billboard target of this node
		//! @note This data overwrites the inherited billboard, if any
		//! @note Of the billboard target's node is null, this node does not track any node.
		BillboardTarget mBillboardTarget;
	public:
		//! @brief Sets the billboard target node of this node
		virtual void setBillboardTarget(const BillboardTarget& target);
		//! @brief The billboard target information is cleared.
		void clearBillboardTarget();
		//! @return The billboard target node of this node. 0, if this node is not a billboard node.
		const BillboardTarget& getBillboardTargetNode() const;
		
		//! @brief Copies/clones the billboard target info of this node to the given node
		void cloneBillboardTarget(SceneNode& node) const;
		
		/************************************************************************/
		/* MANAGING DIRTY DATA                                                  */
		/************************************************************************/
	protected:
		//! @brief Stores the dirty flags of the node (packed for smaller space)
		mutable uint mDirtyFlags;

	public:
		//! @brief Types of dirty flags for a generic scene node
		enum DirtyFlag{
			Dirty_World_Translation = 0x01,
			Dirty_World_Rotation    = 0x02,
			Dirty_World_Scale       = 0x04,
			Dirty_World_Transform   = 0x08,
			//! If the bounding volume parameters need to be updated using this node's internal data.
			Dirty_Bounding_Volume   = 0x10
		};

		//! @brief Sets the given flag dirty
		virtual void setDirtyFlag(DirtyFlag flag) const;
		//! @brief Clears the given flag
		void unsetDirtyFlag(DirtyFlag flag) const;
		//! @brief True if the given flag is dirty
		bool isDirtyFlag(DirtyFlag flag) const;

		/************************************************************************/
		/* CULLING AND RENDER QUEUE GROUP                                       */
		/************************************************************************/
	public:

		//! @brief Possible culling modes of a node. Inspired from WildMagic library
		//! @note  The culling mode is used by the FrustumVisibilityVisitor
		enum CullingMode {
			//! The node is checked for culling dynamically.
			CULL_DYNAMIC,
			//! The node is always culled (always invisible)
			CULL_ALWAYS,
			//! The node is never culled (always visible)
			CULL_NEVER,
			//! The node and its children (if any) is never culled
			CULL_NEVER_TREE
		};

		//! The culling mode of this node
		CullingMode mCullingMode;

		//! @remark If this node has children, sets their queue group ID's as well
		virtual void setRenderQueueGroupID(uchar queueID);

		uchar getRenderQueueGroupID() const;

	private:
		//! Default is RenderQueueID_NodeDefault
		uchar mRenderQueueID;

		/************************************************************************/
		/* BOUNDING VOLUME                                                      */
		/************************************************************************/
		// NOTE: no bounding volume setter directly!
	public:
		//! @return The current up-to-date world-space bounding volume of this node
		//!         Null, if this node has no bounding volume
		//! @remark If the bounding volume is dirty, updates it.
		const GeomVolume* getBoundingVolume_WS() const;

		//! @return True if this node has a bounding volume defined, false otherwise.
		bool hasBoundingVolume() const;

		//! @brief If true, scene managers can render the bounding volume of this node, if any.
		bool RenderBoundingVolume;

		//! @brief Copies/clones the bounding volume info of this node to the given node
		void cloneBoundingVolume(SceneNode& node) const;
		
	protected:
		//! A bounding volume can be axis-aligned box, oriented box, sphere, etc. (See geoms)
		//! It can also be null (meaning that no bounding volume for this node is defined)
		mutable GeomVolume* mBoundingVolume_WS;

		//! @note Position offset is activated if the center position of bounding volume is not (0,0,0)
		bool mPosOffsetActive;

		//! @brief Bounding volume for a local mesh, in node-space
		//!        So, node transformations have not been applied to bounding volume geom yet!
		//! @remark Set only by MeshNode
		GeomVolume* mBoundingVolume_NS;

		//! @brief The only method that should be used an update logic for the bounding volume.
		virtual void updateBoundingVolume() const;
		
		//! @brief rests world-space bounding volume to mesh-space volume
		void resetBoundingVolume() const;

		/************************************************************************/
		/* SPATIAL METHODS                                                      */
		/************************************************************************/
	public:
		/*! @brief Updates the translation component of this node wrt current local coordinate system
		 *  @param _trans Specifies the translation to be applied
		 *  @param reset If true, resets the local-space translation to the given _trans value
		 */
		void translate_Local(const Vector3& _trans, bool reset=false);

		/*! @brief Updates the translation component of this node wrt world coordinate system
		 *  @param _trans Specifies the translation to be applied
		 *  @param reset If true, resets the world-space translation to the given _trans value
		 */
		void translate_World(const Vector3& _trans, bool reset=false);

		/*! @brief Updates the translation component of this node wrt parent's coordinate system
		 *  @param _trans Specifies the translation to be applied
		 *  @param reset If true, resets the parent-space translation to the given _trans value
		 */
		void translate_Parent(const Vector3& _trans, bool reset=false);
		
		/*! @brief Updates the rotation component of this node wrt parent-space coordinate system
		 *  @param _rotate Specifies the rotation to be applied
		 *  @param reset If true, resets the local-space rotation to the given _rotate value
		 */
		void rotate_Parent(const Quaternion& _rotate, bool reset=false);
		
		/*! @brief Updates the rotation component of this node wrt world-space coordinate system
		 *  @param _rotate Specifies the rotation to be applied
		 *  @param reset If true, resets the world-space rotation to the given _rotate value
		 */
		void rotate_World(const Quaternion& _rotate, bool reset=false);
		
		/*! @brief Updates the rotation component of this node wrt local-space coordinate system
		 *  @param _rotate Specifies the rotation to be applied
		 *  @param reset If true, resets the world-space rotation to the given _rotate value
		 */
		void rotate_Local(const Quaternion& _rotate, bool reset=false);
		

		/*!
		 *  @brief Updates the local scale component of this node.
		 *  @param _scale Specifies the scaling to be applied
		 *  @param reset If true, resets the scale to the given scale value
		 *  @note Scale is the first transformation operation that is applied to a node.
		 */
		void scale_Parent(const Vector3& _scale, bool reset=false);

		//! @brief A variant of scale-method which scales all axises using the same ratio
		void scale_Parent(float ratio, bool reset=false);
		
		//! @return The translation of the node with respect to parent node
		const Vector3& getTranslation_Parent() const;
		//! @return The rotation of the node with respect to parent node
		const Quaternion& getRotation_Parent() const;
		//! @return The scale of the node with respect to parent node
		const Vector3& getScale_Parent() const;
		
		//! @return The translation of the node in world-space
		const Vector3& getTranslation_World() const;
		//! @return The rotation of the node in world-space
		const Quaternion& getRotation_World() const;
		//! @return The scale of the node in world-space
		const Vector3& getScale_World() const;

		//! @return The world transformation matrix of this node
		const Matrix4& getWorld_Transform() const;

		//! @brief TODO : update implementation (work with no problems currently, needs to be refactored)
		Vector3 getUp() const;

		//! @brief TODO : update implementation (work with no problems currently, needs to be refactored)
		Vector3 getRight() const;

		//! @brief TODO : update implementation (work with no problems currently, needs to be refactored)
		Vector3 getDirection() const;

		//! Copies/clones the spatial relation of this node to te given node
		void cloneSpatialData(SceneNode& node) const;

	private:
		//! The local translation of this node
		//! @note Must only be updated by translateLocal() method
		Vector3 _mParent_Translation;
		
		//! The local rotation of this node
		//! @note Must only be updated by rotateLocal() method
		Quaternion _mParent_Rotation;
		
		//! The local scale of this node with respect to parent node, if exists.
		//! @note Must only be updated by scaleLocal() method
		Vector3 _mParent_Scale;
		
		//! The world-space translation of the node
		//! @note Must only be updated by updateWorld_Translation() method
		mutable Vector3 _mWorld_Translation;
		
		//! The world-space rotation of the node
		//! @note Must only be updated by updateWorld_Rotation() method
		mutable Quaternion _mWorld_Rotation;
		
		//! The world-space scale of the node
		//! @note Must only be updated by updateWorld_Scale() method
		mutable Vector3 _mWorld_Scale;
		
		//! World transformation matrix of this node (derived from world-translation/rotate/scale info)
		//! @note Must only be updated by updateWorld_Transform() method
		mutable Matrix4 _mWorld_Transform;
		
		//! @brief Using local translation and parent's transformation (if any, with inheritance type check), 
		//!        updates the world translation component of this node.
		//! @note Only updates world translation if the translation dirty flag is set.
		//! @return True if the translation is updated
		bool updateWorld_Translation() const;
		
		//! @brief Using local rotation and parent's rotation (if any, with inheritance type check),
		//!        updates the world rotation component of this node.
		//! @note Only updates world rotation if the rotation dirty flag is set.
		//! @return True if the rotation is updated
		bool updateWorld_Rotation() const;
		
		//! @brief Using local scale and parent's scale (if any, with inheritance type check),
		//!        updates the world scale component of this node.
		//! @note Only updates world scale if the scale dirty flag is set.
		//! @return True if the scale is updated
		bool updateWorld_Scale() const;
		
		//! Refreshes the world transformation matrix of this node using world transformation components.
		//! The world transformation components are updated before generating transformation matrix, if dirty.
		//! @return True if the transformation is updated
		bool updateWorld_Transform() const;
	};

	/**
	 * @class GroupNode
	 * @brief The type of node that can hold a list of children nodes of any type.
	 */
	class RENGAPI GroupNode : public SceneNode {
	protected:
		//! @brief Creates a GroupNode node with the given parent.
		GroupNode(GroupNode& parent);

	public:
		//! @brief Creates a GroupNode node with the given parent on the heap and returns the new node.
		static GroupNode& create(GroupNode& parent);

		//! @brief Destroys the children also !
		//! @remark The children are destroyed, because if not, the children's parent is destroyed/invalidated,
		//!         which contradicts with the design choice : Every node is connected to the scene graph.
		~GroupNode();

		//! @brief Clones the current group node to create a new hierarchy
		//! @param parent The parent of the new top group node in the hierarchy
		//! @note  Only group nodes and mesh nodes are cloned
		GroupNode& cloneMeshStruct(GroupNode& parent) const;

		//! @brief Visitor support
		virtual void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		/************************************************************************/
		/* CHILD NODE METHODS                                                   */
		/************************************************************************/
		
		//! @return True, if the given node is a child of this group node.
		bool isChild(const SceneNode& node) const;
		
		//! @brief Adds the given Node to this GroupNode as a child.
		//! @param node Child node to be added to this GroupNode.
		virtual void addChild(SceneNode &node);
		
		//! @brief Removes the specified child node form this GroupNode.
		//! @param node Node to be removed from this GroupNode.
		//! If the given node is not a child-node, this method has no affect
		virtual void removeChild(SceneNode &node);
		
		//! Removes all children nodes from this GroupNode.
		virtual void clearChildren();
		
		//! @return Number of children in this GroupNode.
		size_t getChildCount() const;
		
		//! @return The list of children of this GroupNode.
		SceneNodeList& getChildren();

		//! @return The child at the given index
		//! @param index The index of child. Must be between 0 and childCount-1
		SceneNode* getChild(size_t index);

		//! @copydoc SceneNode::setRenderQueueGroupID()
		void setRenderQueueGroupID(uchar groupID);

		/************************************************************************/
		/* MISC METHODS                                                         */
		/************************************************************************/

		//! @copydoc SceneNode::setBillboardTarget()
		//! @brief   The children's billboards are updated (if inherited)
		void setBillboardTarget(const BillboardTarget& target);

		//! @brief Notifies this group node that a child's bounding box is updated.
		//! @remark The bounding box of this group node is set to dirty as a result.
		void notifyChildBoundUpdate();

		//! @brief If auto bounding volume generation is enabled, the bounding volume of this group node 
		//!        will be computed using its children bounding volume info.
		//!        If a child stores no bounding info, that child will not contribute to final result.
		//!        The starting volume is null volume.
		void generateDynamicBoundingVolume(bool state);

		//! @brief Sets the given flag dirty
		void setDirtyFlag(DirtyFlag flag) const;

		SceneNodeList pickMesh(GeomRay& ray);

	protected:
		//! @brief Generates a group-node with no parent set.
		//! @note  The sub-class RootNode uses this constructor
		GroupNode();

		//! Sets type of the scene-node (the SceneNode data is not visible to sub-types of GroupNode)
		void setNodeType(SceneNodeType type);

		bool mGenDynBoundingVol;

		//! @brief Updates the bounding volume of this group node using the children's bounding boxes.
		void updateBoundingVolume() const;

	 private:
		//! The list of nodes that are children of this group node
		//! @note The nodes can be of any type.
		SceneNodeList mChildNodes;
	};

	/**
	 * @class RootNode
	 * @brief This is a group node which has parent set to null. There can only be one instance of this class
	 *        in the system.
	 * @note  You can get the instance of the root node in the system and make it translate, so your world
	 *        center becomes updated (do you want this hack to be removed? )
	 */
	class RENGAPI RootNode : public GroupNode, public Singleton<RootNode> {
	public:
		~RootNode();
		static RootNode& getSingleton();
		static RootNode* getSingletonPtr();

		//! @brief Visitor support
		void accept(NodeVisitor& visitor) { visitor.visit(*this); }

	private:
		//! The root node can only be created by the render system
		RootNode();

		//! @brief This method has no affect for a root node
		bool setParent(GroupNode& parent) { (void) parent; return false; }

		// allow render system to create an instance of RootNode
		friend class RenderSystem;
	};

	/**
	 * @class SwitchGroupNode
	 * @brief A specialized group node which allows a child to be selected/activated among the list of all children.
	 */
	class RENGAPI SwitchGroupNode : public GroupNode {
	protected:
		//! @brief Creates a SwitchGroupNode node with the given parent.
		SwitchGroupNode(GroupNode& parent);

	public:
		//! @brief Creates a SwitchGroupNode node with the given parent on the heap and returns the new node.
		static SwitchGroupNode& create(GroupNode& parent);

		~SwitchGroupNode();

		//! @brief Visitor support
		virtual void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		/**
		 * Removes the specified child node form this GroupNode.
		 * @param child Child node to be removed from this GroupNode.
		 * @note  If the child is selected, then null becomes the selected child.
		 */
		void removeChild(SceneNode &child);

		//! @brief Sets the active node to point to given node, which is also a child
		//!        If the given node does not match to a child node object memory location, it has no effect.
		virtual void setActiveNode(SceneNode& node);

		//! @return The active child node of this switch node
		//! @note  If the active child is removed from the child-list, this returns 0
		SceneNode* getActiveNode();

		//! @return The active child node of this switch node
		//! @note  If the active child is removed from the child-list, this returns 0
		const SceneNode* getActiveNode() const;

	protected:
		//! Sets type of the scene-node (the SceneNode data is not visible to sub-types of GroupNode)
		void setNodeType(SceneNodeType type);

	private:
		//! A pointer to active child node
		SceneNode* mActiveChildPtr;
	};

	/**
	 * @class LODGroupNode
	 * @brief A special switch group node, where all the children nodes must be MeshNode and the
	 *        active node is selected based on distance of this node to another tracked node, 
	 *        which defines a position in 3D space.. TODO
	 */
	class RENGAPI LODGroupNode : public SwitchGroupNode {
	protected:
		//! @brief Creates a SwitchGroupNode node with the given parent.
		LODGroupNode(GroupNode& parent);

		//! @note You cannot set the active node in an LODGroupNode directly
		void setActiveNode(SceneNode& node);

		//! @brief LoD distances TODO
		std::vector<float> mLoDDistanceValues;

		// ==> The active level is dependent on (ex) a camera node, and the scene may have many cameras
		// ==> Each camera would require a different LoD level, the active object

		//! @brief The node pointer which this group node tracks.
		const SceneNode* mTrackedNode;

	public:
		//! @brief Creates a SwitchGroupNode node with the given parent on the heap and returns the new node.
		static LODGroupNode& create(GroupNode& parent);
		
		~LODGroupNode();
		
		//! @brief Visitor support
		void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		/**
		 * Adds the given Node to this GroupNode as a child.
		 * @param child Child node to be added to this GroupNode.
		 */
		void addChild(SceneNode &child);
		
	protected:
		// TODO: keep the LoD distance metrics that can map to the
		// TODO: The order of the stored meshes is important!
		// TODO: You cannot set an active node directly
	};

	/**
	 * @class MeshNode
	 * @brief The type of node that keeps a (shared) mesh
	 */
	class RENGAPI MeshNode : public SceneNode {
	protected:
		//! @brief Creates a MeshNode node with the given parent.
		MeshNode(GroupNode& parent);
	public:
		//! @brief Creates a MeshNode node with the given parent on the heap and returns the new node.
		static MeshNode& create(GroupNode& parent);

		//! @remark Does not destruct the mesh data.
		~MeshNode();

		//! @brief Visitor support
		void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		//! @brief Sets the shared mesh this node holds
		void setMesh(MeshPtr mesh);

		//! @return Mesh of this MeshNode.
		MeshPtr getMesh();
		const MeshPtr getMesh() const;

		//! @return True if a match is attached to this mesh-node, false otherwise
		bool isMeshAttached() const;

		SceneNodeList pickMesh(GeomRay& ray);

	protected:

		//! @brief The mesh associated with this node
		MeshPtr mMesh;
	};

	/**
	 * @class CameraNode
	 * @brief The type of node that keeps a camera.
	 *        The node defines the location and orientation of the camera in space.
	 *
	 * @note You can attach a camera to a node only through the camera class interface.
	 * @note A camera node may not always have a camera attached.
	 * @note This node does not inherit ... TODO
	 */
	class RENGAPI CameraNode : public SceneNode {
	public:
		//! @brief Creates a CameraNode node with the given parent on the heap and returns the new node.
		static CameraNode& create(GroupNode& parent);
		
		//! If there is a camera attached to this node, this camera is deleted when the node is deleted.
		~CameraNode();

		//! @brief Visitor support
		void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		//! @return The camera this node holds (0 if it does not hold a camera)
		Camera* getCamera();

		//! @return True if this node holds a camera, false otherwise
		bool isCameraAttached() const;

		// **************
		// HELPERS FOR EASY CAMERA CONTROL

		//! @brief Updates the local rotation and translation
		//! @brief All spatial inheritance values are set to false. 
		//! Use translate/rotate/scale for now...
//		void rotateLookAt(const Vector3& eye, const Vector3& target, const Vector3& up);

		//! @brief A helper math method which generates a view matrix 
		//!        given rotation and translation data
		static void calculateViewMatrix(const Quaternion& rotW, const Vector3& transW, Matrix4& result);

	protected:
		//! @brief Creates a CameraNode node with the given parent.
		CameraNode(GroupNode& parent);

		//! @brief The camera this node holds (can be null)
		Camera* mCamera;
		
		//! @brief Returns the view matrix of this camera node
		const Matrix4& getViewMatrix() const;

		//! CameraNode manages the bounding volume differently.
		void updateBoundingVolume() const;

		friend class Camera;
		//! @brief The view matrix of the camera node (is different from translation matrix)
		mutable Matrix4 mViewMatrix;
	};

	/**
	 * @class LightNode
	 * @brief The type of node that keeps a camera
	 *        The node defines the location and orientation of the light in space.
	 *
	 * @note You can attach a light to a node only through the light class interface.
	 * @note A light node may not always have a light attached.
	 * @note This node does not inherit ... TODO
	 */
	class RENGAPI LightNode : public SceneNode {
	public:
		static LightNode& create(GroupNode& parent);

		//! If there is a light attached to this node, this light is deleted when the node is deleted.
		~LightNode();

		//! @brief Visitor support
		void accept(NodeVisitor& visitor) { visitor.visit(*this); }

		//! @return The light this node holds (0 if it does not hold a camera)
		Light_Base* getLight();

		//! @return True if this node holds a light, false otherwise
		bool isLightAttached() const;

		//! @brief Sets the given flag dirty
		//! @note Notifies the light that this data is dirty!
		void setDirtyFlag(DirtyFlag flag) const;

	protected:
		LightNode(GroupNode& parent);

		//! @brief The light this node holds (can be null)
		Light_Base* mLight;

		friend class Light_Base;
	};

} // namespace REng

#endif // _RENG_NODE_H_
