/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MVCOMPOSITOR_H_
#define _RENG_MVCOMPOSITOR_H_

#include "REng/Prerequisites.h"

#include "REng/MultiViewBuffer.h"

namespace REng{

	/*!
	 * @brief It is the extensible, attachable component (interface) that can define
	 *    how to to activate a view target and to merge separately rendered images into the window frame buffer. 
	 *
	 *  - It is expected to create resources for separate views if required.
	 *
	 *  - All overwritten functions are expected to return true if the call did not generate any internal
	 *    errors, otherwise they should return false to notify the error.
	 * @author Adil Yalcin
	 */
	class RENGAPI MultiViewCompositor {
	public:
		//! The multi-view compositor is created with support with "viewCount" ciew counts
		MultiViewCompositor(uchar viewCount);

		//! @return The number of views this compositor supports
		uchar getViewCount() const;

		//! @return True if the compositor is supported in current system configuration.
		bool isSupported() const;

		//! @return True if this compositor has been successfully initialized
		bool isInitialized() const;

		//! This method is called directly when the compositor is registered.
		//! It checks whether this compositor is supported or not. Use isSupported() method to receive this info.
		//! @param The viewport that this compositor is being attached to
		virtual bool init(Viewport& vp) = 0;

		//! This method is called when the compositor is unregistered / render system shuts down.
		virtual bool clear() = 0;

		//! This method is called once for every frame for each multi-view viewport, before a view is rendered.
		//! @return True if compositor did not encounter any problem. False otherwise.
		//! @note Defaults to no-op
		virtual bool beginFrame();

		//! Allows you to roll back the state changes the compositor makes.
		//! Called after all views are activated & rendered, that is, before any other viewport may be processed.
		//! @note Defaults to no-op
		virtual bool endFrame();

		//! @remark The compositor may want to modify surface parameters
		//! @return True if compositor did not encounter any problem. False otherwise.
		//! @note Defaults to no-op
		virtual bool setActiveView(size_t viewIndex);

		//! Called after all the view-buffers are rendered.
		//! @note Defaults to no-op
		virtual bool mergeViews(MultiViewBuffer& mvb);

	protected:
		bool mIsSupported;
		bool mIsInitialized;

	private:
		uchar mViewCount;
	};

	//! A compositor which is practically no-operation.
	class RENGAPI MVC_Null :public MultiViewCompositor {
	public:
		//! The multi-view compositor is created with support with "viewCount" ciew counts
		MVC_Null(uchar viewCount) : MultiViewCompositor(viewCount) { }
		//! No-op, returns true
		bool init(Viewport& vp) { return true; }
		//! No-op, returns true
		bool clear() { return true; }
		//! No-op, returns true
		bool mergeViews(MultiViewBuffer& mvb) { return true; }
	};


} // namespace REng

#endif // _RENG_MVCOMPOSITOR_H_
