/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_CAMERA_H_
#define _RENG_CAMERA_H_

#include "Prerequisites.h"

#include <cml/cml.h>

#include "REng/Node.h"
#include "REng/Geom/GeomRay.h"
#include "REng/Geom/GeomPlaneBoundedVolume.h"
#include "REng/Angle.h"

namespace REng{

	/*!
	 * @brief 
	 * - Camera class stores intrinsic parameters (An abstraction over real-world camera).
	 * - The basic extrinsic parameters (rotation and translation) are set by the camera scene node.
	 * - A camera is always attached to a single node and is always created on the heap.
	 *
	 * @note  You can derive your own camera classes provided that you overload updateProjectionMatrix() and
	 *        generateRay_WS().
	 * 
	 * @author Adil Yalcin
	 */
	class RENGAPI Camera{
	public:
		virtual ~Camera();

		//! @brief Attach the camera to the given camera node (detaches camera from the current attached node)
		void setNode(CameraNode& node);
		//! @return The camera node that this camera is attached to.
		CameraNode& getNode();
		//! @return The camera node that this camera is attached to (const variant)
		const CameraNode& getNode() const;

		//! @return The projection matrix of the camera
		const Matrix4& getProjectionMatrix() const;
		//! @brief If true, swaps the rows of projection matrix so that 
		//! y_nex = 1-x_old , x_new = y_old
		bool mSwapXY;
		//! @return The view matrix of the camera (derived from the camera node)
		//! @remark Multi-view cameras modify the basic camera node's transformation matrix.
		virtual const Matrix4& getViewMatrix() const;

		//! Returns the position of camera in world-space, retrieved from the attached node
		const Vector3& getPosition() const;
		//! Returns the rotation of camera in world-space, retrieved from the attached node
		const Quaternion& getRotation() const;

		//! @see SceneNode::getDirection
		Vector3 getDirection() const;
		//! @see SceneNode::getRight
		Vector3 getRight() const;
		//! @see SceneNode::getUp
		Vector3 getUp() const;
		
		//! @brief Sets the aspect ratio (width/height)
		//! @remark Aspect ratio must be positive.
		void setAspectRatio(float aspectRatio);
		//! If true, camera's aspect ratio is updated to the aspect ratio of the viewport
		//! this camera has been assigned to.
		bool mSynchAspectRatioFromViewport;
		//! @brief Sets near clip plane distance
		void setNearDistance(float _near);
		//! @brief Sets far clip plane distance
		void setFarDistance(float _far);
		//! @brief Sets the y-axis field of view (in radians) (y-axis: up-down)
		void setFieldOfView_y(const Angle& angle);

		//! @return Width/height of the camera's window size.
		float getAspectRatio() const;
		//! @return The near distance of the camera
		float getNearDistance() const;
		//! @return The far distance of the camera
		float getFarDistance() const;
		//! @return The y-axis field of view (in radians) (y-axis: up-down)
		const AngleRadian& getFieldOfView_y() const;
		//! @return The x-axis fielf of view (in radians) (x:axis: left-right)
		AngleRadian getFieldOfView_x() const;

		//! @return The number of views this camera has (1 if camera is not multi-view)
		virtual uchar getViewCount() const;

		//! @brief Sets the active camera view no
		//! @param viewIndex Must be between 0 and ViewCount. If not, defaults to View No 0.
		//! @remark If camera is not multi-view, has no affect
		virtual void setActiveView(uchar viewIndex);

		//! @return The frustum clip-planes of the camera.
		const GeomPlaneBoundedVolume& getFrustum_WS() const;

		//! Invalidates the cached frustum data, when frustum is requested next, it will be re-computed
		void invalidateFrustum();
		
		//! @brief Generates a ray from the camera viewpoint to the image plane.
		//! @param widthRatio Must be between 0(left limit) and 1(right limit).
		//! @param heightRatio Must be between 0(down limit) and 1(right limit).
		//! @param ray the line geometry object that will be updated to store the pick ray.
		virtual void generateRay_WS(float widthRatio, float heightRatio, GeomRay& ray) = 0;

		virtual void getFrustumCorners(Vector3* cornerData) const=0;

	protected:
		//! @brief Creates a camera attached to the given node.
		//! @note  Default parameters: near=0.1f, far: 300.0f, FoV_y = 45.0f, aspect : 1.33f
		Camera(CameraNode& node);
		
		//! @note Camera is not the owner of the node it is inside. Do not delete it!
		CameraNode& mNode;

		//! @brief Specifies the aspect ratio of the camera window
		float mAspectRatio;
		//! @brief The near distance of the camera
		float mNearDistance;
		//! @brief The far distance of the camera
		float mFarDistance;
		//! @brief Y-axis field of view angle (in radians)
		AngleRadian mFoV_y;

		//! @brief The projection matrix of the camera
		mutable Matrix4 mProjectionMatrix_Cache;

		//! @brief True if the projection matrix need to be updated
		mutable bool mProjectionMatrix_Dirty;

		//! @brief The frustum of the camera
		mutable GeomPlaneBoundedVolume mFrustum_Cache;
		//! @brief True if the frustum needs to be updated
		mutable bool mFrustum_Dirty;

		//! @brief Each camera type must define the projection matrix update method
		virtual void updateProjectionMatrix() const = 0;
		//! @brief Each camera type must define the frustum update method
		virtual void updateFrustum() const = 0;

		//! @brief Switches X and Y components in the given projection matrix
		static void swapXY(Matrix4& proj);

		// TODO: define window lower left corner?

	};

	/*!
	 * @brief A symmetric perspective projection camera.
	 * @author Adil Yalcin
	 */
	class RENGAPI CameraPerspective : public Camera {
	public:
		//! @brief Creates a perspective camera attached to the given node
		static CameraPerspective& create(CameraNode& node);

		//! @copydoc Camera::generateRay_WS
		void generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay);

		//! @param cornerData A pointer to Vector3 memory that can hold 8 point-vectors
		//! @note Used for debugging purposes only. The corner data is not cached.
		void getFrustumCorners(Vector3* cornerData) const;
	
	protected:
		CameraPerspective(CameraNode& node);

	private:
		//! @brief Updates the projection matrix using current perspective parameters
		virtual void updateProjectionMatrix() const;
		//! @note Multi-view cameras may handle their frustum differently
		virtual void updateFrustum() const;
	};

	/*!
	 * @brief An orthogonal projection camera.
	 * @author Adil Yalcin
	 */
	class RENGAPI CameraOrthogonal : public Camera {
	public:
		//! @brief Creates an orthographic camera attached to the given node
		static CameraOrthogonal& create(CameraNode& node);

		//! @copydoc Camera::generateRay_WS
		//! @todo
		void generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay);

		//! @todo
		void getFrustumCorners(Vector3* cornerData) const;

	protected:
		//! @brief Creates an orthographic camera attached to the given node
		CameraOrthogonal(CameraNode& node);

	private:
		//! @brief Updates the projection matrix using current orthogonal parameters
		void updateProjectionMatrix() const ;
		//! @todo
		void updateFrustum() const;
	};

	#include "inl/Camera.inl"

} // namespace REng

#endif
