/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_TIMER_H_
#define _RENG_TIMER_H_

#include "REng/Prerequisites.h"

#if RENG_PLATFORM == RENG_PLATFORM_WINDOWS 
#	include <windows.h>
#else
extern "C" {
#	include <sys/time.h>
}
#endif

namespace REng{

	/*!
	 *  @note Uses gettimeofday in UNIX environments, GetTickCount in windows.
	 */
	class RENGAPI Timer {
	public:
		//! Initializes the constructed timer to current time.
		Timer();

		//! Resets the time counting.
		void reset();

		//! @brief Query method to retrieve timing information
		//! @return The seconds that has passed since the timer was reset.
		//! @param _reset If true, resets the timer, else does not reset the timer.
		//! @param threshold The elapsed time is returned only if threshodl is exceeded. If elapsed
		//!        time does not exceed threshold, returns 0.
		float getElapsedTime(bool _reset=false, float threshold=0);

	protected:

#if RENG_PLATFORM == RENG_PLATFORM_WINDOWS 
		DWORD base;
#else
		struct timeval base;
#endif

	};

} // namespace REng

#endif // _RENG_TIMER_H_
