/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_RENDER_SYSTEM_
#define _RENG_RENDER_SYSTEM_

#include <string>

#include "REng/Prerequisites.h"

// is a singleton
#include "REng/Singleton.h"
// manages auto-synch of a given uniform render property
#include "REng/GPU/RenderProperty.h"
// manages a simple FPS timer
#include "REng/Timer.h"
// renders the scene through a camera
#include "REng/Camera.h"
// renders mesh geom's
#include "REng/Mesh.h"
// stores a render queue object...
#include "REng/RenderQueue.h"

#include "REng/Rect.h"

namespace REng {

	//! The call-back type for use in window-context setup phase
	typedef bool (*inputCallback)(OSWindow*);

	/*!
	 * @brief Welcome to the heart of REng, which is responsible to pump up blood to the entire system.
	 *
	 * - You need to initialize RenderSystem as a first step if you will use REng for rendering.
	 * 
	 * @author Adil Yalcin
	 */
	class RENGAPI RenderSystem : public Singleton<RenderSystem> {
	public:
		//! @brief This method also creates all REng singleton instances that will be required.
		RenderSystem(void);
		~RenderSystem(void);

		static RenderSystem& getSingleton(void);
		static RenderSystem* getSingletonPtr(void);

		//! @note The render window should be created first if rendering context is to be initied.
		//!       You can call createWindowAndGLContext method for this purpose.
		bool initSystem(bool loadDefaultMaterial=true);

		//! Returns true if RenderSystem has been inited through initSystem call successfully.
		bool isInited() const;

		/**
		 * @brief Creates an operating-system window and associated an OpenGL context with it
		 *        using the parameters provided
		 * @remark If you want REng to automatically create rendering contexts, call this method
		 *         BEFORE calling initSystem. You can create your window and OpenGL context manually 
		 *         if you prefer.
		 * @param position The position of the window on the display (like a viewport)
		 * @param contextParams The OpenGL context parameter and value pairs 
		 *        - If NULL, default context parameters are used.
		 *        - The array must be terminated by GLCntxtParNull value.
		 *        - @see GLContextParam
		 * @param windowTitle The window title that will be displayed for the app
		 * @param fullscreen If true, a fullscreen display mode will be set using 
		 *        the position width/height as the display resolution.
		 * @return True if a window and an associated OpenGL context is successfully created
		 *
		 * @note Automatically creates a full-screen viewport at index 0, if successfull.
		 * @note Fullscreen only works when video card support given width/height (resolution).
		 */
		bool createWindowAndGLContext(const RectI& position, const int* contextParams=0,
			inputCallback cb=0, const char* windowTitle="OpenREng Window", bool fullscreen=false);

		//! @brief Destroys the window created by the render-system, if any
		//! @brief True if no window is created or a created window is successfully destroyed
		bool shutdownWindowAndGLContext();

		// The functions below return valid data if createWindowAndGLContext has been called

		OSWindow*  getOSWindow();
		GLContext* getGLContext();
		const RenderTarget_Window *getWindowColorTarget() const;
		const RenderTarget_Window *getWindowDepthStencilTarget() const;

	private:
		bool mIsInited;

		OSWindow* mOSWindowHandle;
		GLContext* mGLContext;
		RenderTarget_Window *mColorTarget;
		RenderTarget_Window *mDepthStencilTarget;

		/************************************************************************/
		/* BACKGROUND/SKY RENDERING                                             */
		/************************************************************************/

		//! NOTE: Design will be updated....
	public:
		//! @brief Renders the background of the screen.
		//!        If a sky-box/sky-dome is defined, this image is rendered.
		//!        Else, the framebuffer is cleared to active clear color
		void queueBackground(bool renderSky=false);

		//! @remark The sky mesh has no LoD, so is assigned only one mesh geom.
		void setSkyMeshGeom(MeshGeom&);

		//! @brief This one should be called if you favor to draw your sky mesh 
		//!        after you finish rendering your scene (excluding trans. objects).
		//! @remark If your scene objects cull sky-box mostly, it is better to render 
		//!         it after you finish rendering your objects to reduce the fill-rate problem.
		void queueSkyMesh();

	private:
		//! @brief If not null, a special mesh is rendered as the background (sky)
		MeshPtr mSkyMesh;

		/************************************************************************/
		/* RENDERING                                                            */
		/************************************************************************/

	public:
		//! Renders all the viewports attached to the window, swaps the result and updates frame time
		//! You should use this in your application main loop
		bool renderAll();

		//! @brief Queues the scenegraph, does not clear frame buffer or swap framebuffer
		void queueSG();

		//! @brief Renders the given mesh, uses active view and manages multi-pass techniques
		void queueMesh(MeshPtr mesh, const Matrix4& transformation, uchar groupID=0);

		//! @brief Renders all the queued elements one by one, using the ordering specified
		void processRenderQueues();

		//! @brief Signals the end of the frame operations.
		//!        The multi-views will be composed if required and the screen image will be refreshed.
		//! @return True on success, false otherwise
		//! @param noSwap If true, does not actually swap the frame buffers itself. It increments frame count.
		bool swapFrame(bool noSwap);

		//! Checks if a second has passed internally. If true, updates stats, takes screenshot, etc
		void checkElapsedTime();

		RenderQueue_BVs& getRenderQueue_BVs();

		//! If true, the standard OpenREng renderer will not be called to render the scene graph.
		//! Default value is false
		bool mDisableInternalSGRenderer;

		//! A helper method if you need to set active camera without calling above
		void setActiveCamera(Camera& camera);

	private:
		RenderQueue_BVs* mRenderQueue_BVs;

		/************************************************************************/
		/* VIEWPORT METHODS                                                     */
		/************************************************************************/

	public:
		//! Adds the given viewport to the window target if no viewport is attached to that depth
		//! @return True if no viewport exists in the given depth value, false otherwise.
		bool addViewport(uchar depth, Viewport* vp);

		//! Retrieves the viewport at the given depth value
		//! @return The viewport found at given depth, 0 otherwise
		Viewport* getViewport(uchar depth);

		//! Returns the active viewport.
		Viewport* getActiveViewport(Viewport* vp);

		//! Sets the active viewport to given value;
		void setActiveViewport(Viewport& vp);

		//! @brief  This method specifies the affine transformation of x and y from normalized device 
		//!         coordinates to window coordinates.
		//! @param vpRect The viewport that specifies the following:
		//!           - x, y The lower left corner of the viewport rectangle, in pixels.
		//!           - width, height The size of the viewport
		//! @return False if width and height exceeds configuration limits.
		//! @note The initial values after OpenGL context init are x:0, y:0 width,height = window dimensions
		bool setViewportTrans(const RectI& vpRect);

	private:
		//! Stores the list of viewports available for the window target, sorted by some Z value
		//! @note REng currently only supports a single window target. This function will be moved 
		//!       under a separate Window class later on.
		typedef std::map< uchar, Viewport* > ViewportMapping;
		ViewportMapping mWindowViewports;
		Viewport* mActiveViewport;

		//! Active viewport height and width (for synchronization to uniforms semantics)
		size_t mViewportWidth, mViewportHeight;

		/************************************************************************/
		/* HELPER METHODS                                                       */
		/************************************************************************/
	public:

		//! @brief Updates the uniform data by using the uniform semantic
		//! @param uniform The uniform to be updated. If auto name is None, no update is performed.
		//! @return True if the given uniform has been updated.
		//! @note  Not static, because some semantics require render system instance variables
		bool updateUniformIfSpecical(RenderProp_Uniform& uniform) const;

		//! @brief This method specifies a linear mapping of the normalized depth coordinates
		//!        in this range to window depth coordinates.
		//! @param nearVal  Specifies the mapping of the near clipping plane to window coordinates.
		//! @param farVal Specifies the mapping of the far clipping plane to window coordinates.
		//! @note It is not necessary that nearVal be less than farVal.
		//!       Reverse mappings such as nearVal = 1, and farVal = 0 are acceptable.
		//! @note The initial values after OpenGL context init are nearVal:0, farVal:0 (full utilization of depth buffer values)
		//! @todo This should not be here?
		void setDepthRange(float nearVal, float farVal);

		/*!
		 * @brief The scissor test determines if a generated fragment at window coordinates (x;y) 
		 *        lies within the scissor rectangle de?ned by given four values.
		 *        When disabled, it is as if the scissor test always passes.
		 * @note  Initially, the stencil test is disabled.
		 * @param isEnabled If true, stencil testing for fragments is activated
		 * @param left,width,bottom,height The limits wrt low left corner of the scissor window
		 * @remark Be sure to set all parameters correctly when you enable scissor test.
		 */
		void setScissorTest(bool isEnabled,size_t left=0,size_t bottom=0,size_t width=0,size_t height=0);

		const Camera* getActiveCamera() const;
	
	private:

		//! @brief Timer which is used to auto-generate per-second actions
		Timer mFPSTimer;

		//! @note Set by the queueMesh function...
		uchar mActivePass;

		//! The camera that currently renders the scene
		Camera* mActiveCamera;
	};

} // namespace REng

#endif
