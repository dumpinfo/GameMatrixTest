/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_LIGHT_H_
#define _RENG_LIGHT_H_

#include "REng/Prerequisites.h"

#include "REng/Node.h"
#include "REng/Color.h"
#include "REng/Angle.h"

#include "REng/GPU/GPUStructure.h"

// auto_ptr
#include <memory>
#include <vector>

namespace REng {

	/*!
	 * @class Light_Base
	 * @brief 
	 *  - A light (lamb) object defines a base class for light objects.
	 *  - A light is always attached to a scene node and can be enabled/disabled.
	 *  - Direction and position is set by the node the light is connected to.
	 *  - A light is enabled by default.
	 * 
	 * @note REng defines a standard light sub-class (Light) and its shader variable bindings.
	 * @note You can derive your own light classes, attached them to the scene and 
	 *       access automatically synch'ed light parameters in shaders.
	 *
	 * @author Adil Yalcin
	 */
	class RENGAPI Light_Base : public GPUStructure{
	public:
		virtual ~Light_Base();

		//! @brief Attach the light to the given light node (detaches light from the current attached node)
		void setNode(LightNode& node);
		//! @return The light node that this camera is attached to
		LightNode& getNode();
		//! @return The light node that this camera is attached to (const variant)
		const LightNode& getNode() const;

		//! @brief If val is true, the light source is enabled/lit (can illuminate objects).
		//! Else, the light is not activated during render passes.
		void setLit(bool val=true);
		//! @return True if light is lit, false otherwise
		bool isLit() const;

		//! @return The world-space position of the light (uses attached node's information)
		const Vector3& getPosition() const;
		//! @return The world-space direction of the light (using attached node's information)
		const Vector3 getDirection() const;

		//! The light type is used to sort / synch light objects
		//! @return The unique type ID of the light type, 0 is an invalid ID
		//! @note If you decide to extend the light classes, you must make sure every light type
		//!       that will be treated differently in a shader must return a unique type ID.
		virtual uint getTypeID() const = 0;

		//! @return True if the lighting effect depends on light -node- position
		virtual bool isPositional() const = 0;
		//! @return True if the lighting effect depends on light -node- direction
		virtual bool isDirectional() const = 0;

		//! Controls the behavior of _cullNodes
		bool mLightCullingActive;

		//! @return True if this "lighting" does not illuminate specific nodes in the scene, 
		//!         instead, illuminates all objects (if shader supports it)
//		bool illuminatesAllScene() const;

		//! If mCullingActive is false, does nothing
		//! Else, using the light's bounding box (if any) checks the lighted node
		//! @note This method is called on every frame automatically
		void _cullNodes();

		//! Set this before calling synchWithPass function!
		uint mSynchLightIndex;

		//! @return The bounding volume -in light space- of this light (if applicable)
		//!         0, if not applicable
		//! @remark A light with an attenuation model may be able to define its bounding volume.
		//!         Why not use it?
		virtual GeomVolume* getBoundingVolume() const { return 0; }

		//! This method allows directly setting all the internal data dirty or not
		void setAllDirty(bool _isDirty);

		//! Called by the light node when its rotation or translation becomes dirty
		void setNodeDirty();

	protected:
		//! @brief Creates a light attached to the given node.
		//! @note  Enabled by default
		Light_Base(LightNode& node);

		//! Default attributes of lights provided by the scene node
		enum {
			Dirty_Pos = 1,
			Dirty_Dir = 2
		};

		//! Stores the dirty bits, 
		uint mDirtyFlags;

	private:
		//! The node this light object is attached to
		LightNode& mNode;
		//! If a light is not enabled, it cannot illuminate objects in the scene.
		bool mEnabled;
	};

	//! Default light types
	//! @note If you want to extend with your own types, use other values as your type ID's
	enum LightType{
		LightType_Point = 0,
		LightType_Sun   = 1,
		LightType_Spot  = 2
	};
	
	//////////////////////////////////////////////////////////////////////////
	// Light registration uses some of the ideas in:
	// http://meat.net/2006/03/cpp-runtime-class-registration/
	//////////////////////////////////////////////////////////////////////////

	typedef bool (*LightRegFunc)(void);
	typedef std::vector<LightRegFunc> LightRegFuncList;

	//! To allow automatic registration of derived light classes in a source file to OpenREng
	class RENGAPI LightRegistry {
	public:
		static LightRegistry& getSingleton(void);

		uint getLightTypeCount() const;

		void add(LightRegFunc creatorFunc);
		LightRegFuncList::iterator begin();
		LightRegFuncList::iterator end();
	private:
		// a list of function pointers
		std::vector<LightRegFunc> mRegFuncs;
	};

	//! Helper class for associating function pointers on program start-up
	class RENGAPI LightRegistrer {
	public:
		LightRegistrer(LightRegFunc);
	};

	//! You need to call this using the class name of the light for each light you define
	//! Creates a dummy object in global scope, which automatically runs a function on program start-up
	#define REGISTER_LIGHT(light_type) REng::LightRegistrer __lightreg##light_type(&light_type::registerFunc);
	#define REGISTER_LIGHT_H(light_type) extern REng::LightRegistrer __lightreg##light_type;

	/**
	 * @class Light_Sun
	 * @brief 
	 *  The standard sun light model as used by the REng system.
	 *  - A sun light is directional, is not positional and cannot have any attenuation.
	 *  - The direction specifies the direction of light rays emitted.
	 *  - The sun light has a single color.
	 * @author Adil Yalcin
	 */
	class RENGAPI Light_Sun : public Light_Base {
	public:
		// Creates a new sun light and attaches it to the given light node
		static Light_Sun& create(LightNode& node);

		//! @return False
		bool isPositional() const;
		//! @return True
		bool isDirectional() const;

		//! @copydoc Light_Base::getTypeID
		uint getTypeID() const;

		//! Sets the light color
		void setColor(Color_Real color);
		//! @return The light color
		Color_Real getColor() const;

		const char* getShaderStructCode();
		bool synchWithPass(RenderPass& pass);

		static bool registerFunc();

	private:
		//! @remark You cannot create a light object on the stack
		//! @remark You cannot change the light type after you initialize object.
		//!         You can change the attenuation models.
		Light_Sun(LightNode& node);

		//! The shader structure code
		static const char* mShaderStructCode;
		static const char* mShaderStructCode_ES;
		//! The shader uniform array variable name
		static const char *mUniformArrayName;

		//! The color of the light source 
		//! @note diffuse and specular color is not separated
		Color_Real mColor;

		enum {
			Dirty_Color    = 4,
		};

		//! Synch methods for light parameters
		bool synchColor(RenderPass& pass);
		bool synchDirection(RenderPass& pass);
	};

	REGISTER_LIGHT_H(Light_Sun);

	/**
	 * @brief 
	 *  The standard point light model as used by the REng system.
	 *  - A point light is positional, is not direction and can have positional attenuation.
	 *  - The position specifies the source of light rays emitted.
	 *  - The point light has a single color.
	 * @author Adil Yalcin
	 */
	class RENGAPI Light_Point : public Light_Base {
	public:
		// Creates a new point light and attaches it to the given light node
		static Light_Point& create(LightNode& node);

		//! @return True
		bool isPositional() const;
		//! @return False
		bool isDirectional() const;

		//! @copydoc Light_Base::getTypeID
		uint getTypeID() const;

		//! Sets the light color
		void setColor(Color_Real color);
		//! @return The light color
		Color_Real getColor() const;

		void setAttenPosFactors(float _cons, float _linear, float _quadric);
		void getAttenPosFactors(float& _cons, float& _linear, float& _quadric);

		//! This method allows directly setting all the internal data dirty or not
		void setAllDirty(bool _isDirty);

		const char* getShaderStructCode();
		bool synchWithPass(RenderPass& pass);

		static bool registerFunc();
	private:
		//! @remark You cannot create a light object on the stack
		//! @remark You cannot change the light type after you initialize object.
		//!         You can change the attenuation models.
		Light_Point(LightNode& node);

		//! The shader structure code
		static const char* mShaderStructCode;
		static const char* mShaderStructCode_ES;
		//! The shader uniform array variable name
		static const char *mUniformArrayName;

		//! The color of the light source 
		//! @note diffuse and specular color is not separated
		Color_Real mColor;

		// Attenuation factors that can be used by shaders
		float mAttenPos_Constant;
		float mAttenPos_Linear;
		float mAttenPos_Quadric;

		enum {
			Dirty_Color    = 4,
			Dirty_AttenPos = 8
		};

		//! Synch methods for light parameters
		bool synchColor(RenderPass& pass);
		bool synchPosition(RenderPass& pass);
		bool synchAttenuation(RenderPass& pass);
	};

	REGISTER_LIGHT_H(Light_Point);

	/**
	 * @brief 
	 *  The standard spot light model as used by the REng system.
	 *  -  A spot light is both directional and positional.
	 *  -  It sends light rays in a specific directional region (using the attenuation data as well).
	 *  -  If directional attenuation model does not affect light intensity, it can behave as a point light.
	 * @author Adil Yalcin
	 */
	class RENGAPI Light_Spot : public Light_Base {
	public:
		// Creates a new spot light and attaches it to the given light node
		static Light_Spot& create(LightNode& node);

		//! @return True
		bool isPositional() const;
		//! @return True
		bool isDirectional() const;

		//! @copydoc Light_Base::getTypeID
		uint getTypeID() const;

		//! Sets the light color
		void setColor(Color_Real color);
		//! @return The light color
		Color_Real getColor() const;

		void setAttenPosFactors(float _cons, float _linear, float _quadric);
		void getAttenPosFactors(float& _cons, float& _linear, float& _quadric);

		void setAttenDirFactors(float falloffExp, const Angle& cutoffAngle);
		void getAttenDirFactors(float& falloffExp, Angle& cutoffAngle);

		//! This method allows directly setting all the internal data dirty or not
		void setAllDirty(bool _isDirty);

		const char* getShaderStructCode();
		bool synchWithPass(RenderPass& pass);
		void synchToLightAtIndex(RenderPass& pass, uint _index);

		static bool registerFunc();
	private:
		//! @remark You cannot create a light object on the stack
		//! @remark You cannot change the light type after you initialize object.
		//!         You can change the attenuation models.
		Light_Spot(LightNode& node);

		//! The shader structure code
		static const char* mShaderStructCode;
		static const char* mShaderStructCode_ES;
		//! The shader uniform array variable name
		static const char *mUniformArrayName;

		//! The color of the light source 
		//! @note diffuse and specular color is not separated
		Color_Real mColor;

		//! attenuation factors
		float mAttenPos_Constant;
		float mAttenPos_Linear;
		float mAttenPos_Quadric;

		//! @brief Specifies the intensity distribution of the light
		float mFalloffExponent;
		//! @brief Specifies the maximum spread angle of a light source (in degrees)
		AngleDegree mCutoffAngle;

		enum {
			Dirty_Color    = 4,
			Dirty_AttenPos = 8,
			Dirty_AttenDir = 16
		};

		//! Synch methods for light parameters
		bool synchColor(RenderPass& pass);
		bool synchPosition(RenderPass& pass);
		bool synchDirection(RenderPass& pass);
		bool synchAttenuation(RenderPass& pass);
	};

	REGISTER_LIGHT_H(Light_Spot);

	//! Effective light intensity is attenuated by the cosine of the angle between the
	//! direction of the light and the direction from the light to the vertex being
	//! lighted, raised to the power of the spot exponent.	
	
	//! If the	angle between the direction of the light and the direction from the light 
	//! to the vertex being lighted is greater than the spot cutoff angle, the light is completely masked. 
	//! Otherwise, its intensity is controlled by the spot exponent and the attenuation factors.

} // namespace REng

#endif // _RENG_LIGHT_H_
