/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MESHMANAGER_H_
#define _RENG_MESHMANAGER_H_

#include <map>
#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>

#include "REng/Mesh.h"
#include "REng/Singleton.h"

//tmp
#include "REng/Geom/Geom.h"

namespace REng{

	//! The orientation (handedness) of a mesh
	enum MeshOrient{
		MeshOrientLHS,
		MeshOrientRHS,
	};

	/*!
	 *  @brief Use this loader class if you want to load in mesh resources from files.
	 *  @author Adil Yalcin
	 *
	 *  - Currently supports only 3ds file format
	 *  - Loads the mesh file only once and stores the loaded meshes. Returns loaded mesh in later requests.
	 */
	class RENGAPI MeshManager : public Singleton<MeshManager> {
	public:
		MeshManager(void);
		~MeshManager(void);

		// Singleton access methods
		static MeshManager& getSingleton(void);
		static MeshManager* getSingletonPtr(void);

		//! @brief If the model does not have normals defined, you can set to automatically generate normals
		//! @note  If the format specifies faces separately, the same normal would be used for face vertices.
		//!        (This is the case for 3ds)
		//! @note Default is false
		bool mGenerateNormals;

		float mScaleOnLoad;

		//! @brief If the model has texture 2D coordinates assigned, generates the tangent 
		//! vector per vertex to be used by the shaders...
		//! @note The fourth component of the 4D tangent vector stores the handedness of TBN
		bool mGenerateTangent;

		//! @note Bitangent is both perpendicular to texture tangent and normal of a vertex
		bool mGenerateBitangent;

		//! Swaps the texture S-T values in the loaded models
		bool mSwapTexCoordS_T;

		//! If LHS, converts the handedness of the model to be loaded.
		//! Defaults to RHS (no conversion on model loading)
		MeshOrient mMeshOrient;

		//! @brief Temporary flag, for demo purposes mostly
		//!        Only AAB and OB can be generated for now.
		GeomType mTmpBoundBoxType;
		
		//! @brief Tries to detect the correct file type and load mesh data using that format.
		//! If the load is successful, returns true. Else returns false.
		//! @note A single file can store multiple meshes. The meshes are loaded by mesh names as noted
		//!       in the file format.
		//! @note If a mesh/object with the same name has been previously loaded, does not update previous 
		//!       definition
		//! @note If the file format can only store a single mesh, the name of the file without the extension is
		//!       used as the mesh name.
		//! @note Errors/warnings are logged into rendersystem.log
		bool loadFromFile(const std::string& fileName);

		//! @param meshName The name of the mesh that is requested to be generated.
		//! @return 0 if the meshName is currently in use, else returns the newly created mesh
		//! @remark Mesh names starting with "re_" prefix are used internally.
		//!         Requsting such a mesh name results in error and this method returns 0.
		MeshPtr createMesh(const std::string& meshName);

		//! @brief A retriever for the mesh using meshName.
		//! @return The mesh if meshName is found, else 0
		MeshPtr getMeshByName(const std::string& meshName) const;
	
	private:
		typedef std::map< std::string, MeshPtr > MeshList;
		
		//! @brief Maps file names to loaded meshes.
		MeshList mMeshList;
		
		//! @return The extension of the given filename
		static std::string getExtension(const std::string& filename);

		//! @return The name of the file with the file extension removed (is any)
		static std::string getBaseName(const std::string& filename);

		//! @return The path of the file
		static std::string getPath(const std::string& filename);

		//! @brief A mesh name is a special name if it has a "re_" prefix
		static bool isSpecialName(const std::string& meshName);

		//! @note Uses lib3ds to load mesh data internally.
		//!       Vertex, index and material names are loaded only.
		bool loadFrom3DS(const std::string& fileName);

		//! @note Uses sample code from dhpoware to load mesh data internally.
		bool loadFromOBJ(const std::string& fileName);

		//! @brief Similar to public createMesh method, but this one allow creating meshes
		//!        starting with "re_" prefix.
		//! @brief Creates the mesh using the given name if it does not exists.
		//!        Else, returns the already created mesh
		MeshPtr _getMeshByName(const std::string& meshName);

		//! @brief  Returns a cube-map (can be used for sky-box rendering)
		//! - The cube map has texture coordinates ready for cubemap texture samplers.
		//! @remark Loads/generates the cubemap data automatically on first call
		//! TODO Load from file, do not include mesh data in executable
		MeshPtr getSkyMesh();
	
		friend class RenderSystem;
	};

} // namespace REng

#endif // _RENG_MESHMANAGER_H_
