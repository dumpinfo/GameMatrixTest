/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_INTERP_H_
#define _RENG_INTERP_H_

#include "REng/Prerequisites.h"

namespace REng {
 
	/*!
	 *  @brief Stores basic interpolation routines
	 *  @author Adil Yalcin
	 */
	namespace Interp {

		/************************************************************************/
		/* Linear interpolations                                                */
		/************************************************************************/

		//! Returns the linearly interpolated point between p1 and p2
		template<typename T> 
		T& Lerp(const T& p1, const T& p2, float u, T& result);

		//! Returns the linearly interpolated and normalized quaternion between q1 and q2
		//! @note Does not return "correct" interpolation, but faster than the correct one, SLerp.
		Quaternion& NLerp(const Quaternion& q1, const Quaternion& q2, float u, 
			Quaternion& result, bool shortestPath=true);

		//! Returns correct spherical linear interpolation between q1 and q2
		Quaternion& SLerp(const Quaternion& q1, const Quaternion& q2, float u, 
			Quaternion& result, bool shortestPath=true);

		/************************************************************************/
		/* Cubic Interpolations                                                 */
		/************************************************************************/

		//! Returns a Catmull-Rom approximation between p1 and p2 using offset u.
		//! @param p1_pre The interpolation point that occurs before p1
		//! @param p1 Point 1 that interpolation passes through when u=0
		//! @param p1 Point 2 that interpolation passes through when u=1
		//! @param p2_post The interpolation point that occurs after p2
		//! @param u The interpolation factor
		//! @param result The parameter that gets updated (and returned) by this function call
		template<typename T>
		T& CatmullRom(const T& p1_pre, const T& p1, const T& p2, const T& p2_post, float u, T& result);

		//! A specific Catmull-Rom implementation for quaternions
		Quaternion& CatmullRom(const Quaternion& q1_pre, const Quaternion& q1,
			const Quaternion& q2, const Quaternion& q2_post, float u, Quaternion& result);

		//! Returns a Cardinal approximation between p1 and p2 using offset u.
		//! Note: When tension == 0.5, produces same result as Catmull-Rom
		template<typename T>
		T& Cardinal(const T& p1_pre, const T& p1, const T& p2, const T& p2_post, float u, T& result, float tension);

		//! Performs spherical quadratic interpolation between q1 and q2
		//! @param q1_tang The tangent quaternion at q1
		//! @param q1 The quaternion 1
		//! @param q2 The quaternion 2
		//! @param q2_tang The tangent quaternion at q2
		//! @param result The parameter that gets updated (and returned) by this function call
		Quaternion& Squad(const Quaternion& q1, const Quaternion& q1_tang, 
			const Quaternion& q2, const Quaternion& q2_tang, float u, Quaternion& result);

		//! Given a quaternion q and it neighbors q_pre and q_post, calculates the tangent at q.
		Quaternion& Tangent(const Quaternion& q_pre, const Quaternion& q,
			const Quaternion& q_post, float u, Quaternion& result);
	};

	//////////////////////////////////////////////////////////////////////////
	// Inline methods

	template<typename T>
	inline T& Interp::Lerp(const T& p1, const T& p2, float u, T& result) {
		result = p1 + (p2-p1)*u;
		return result;
	}

	template<typename T>
	inline T& Interp::CatmullRom(const T& p1_pre, const T& p1, const T& p2, const T& p2_post, float u, T& result)
	{
		float u2 = u*u;    // u^2
		float u3 = u2*u;   // u^3
		float _3u3 = 3*u3; // 3u^3
		result = (
			p1_pre  * (-u3+2*u2-u) +
			p1      * (+_3u3-5*u2+2) + 
			p2      * (-_3u3+4*u2+u) + 
			p2_post * (u3-u2) )/2.0f;
		return result;
	}

	template<typename T>
	inline T& Interp::Cardinal(const T& p1_pre, const T& p1, const T& p2, const T& p2_post, float u, 
		T& result, float tension)
	{
		float u2 = u*u;    // u^2
		float u3 = u2*u;   // u^3
		float tmp = 3*u2 - 2*u3;
		result = 
		        ( p1 * (1-tmp) ) +
		        ( p2 * (tmp) ) +
		        ( (p2-p1_pre)  * (u3 - 2*u2 + u) * tension ) +
		        ( (p2_post-p1) * (u3 - u2) * tension );
		return result;
	}

}

#endif

