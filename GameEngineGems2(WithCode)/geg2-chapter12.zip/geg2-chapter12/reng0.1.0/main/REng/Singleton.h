/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SINGLETON_H_
#define _RENG_SINGLETON_H_

#include "assert.h"

namespace REng {

	/*! Template class for creating single-instance global classes. */
	// Based on OGRE's singleton class
	template <typename T> class Singleton
	{
	protected:
		static T* ms_Singleton;

	public:
		Singleton( void ) {
			assert( !ms_Singleton );
			ms_Singleton = static_cast< T* >( this );
		}
		~Singleton( void ) {  
			assert( ms_Singleton );  
			ms_Singleton = 0;
		}
		static T& getSingleton( void ) { 
			assert( ms_Singleton );  
			return ( *ms_Singleton ); 
		}
		static T* const getSingletonPtr( void ) { 
			return ms_Singleton; 
		}
	};

} // namespace REng

#endif // _RENG_SINGLETON_H_
