/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_NODEVISIBILTYVISITOR_H_
#define _RENG_NODEVISIBILTYVISITOR_H_

#include "REng/Node.h"
#include "REng/Geom/GeomPlaneBoundedVolume.h"

#include <vector>

namespace REng {

	//! Scene Graph Visitor that detects visible mesh and group nodes and 
	//! queues the renderables accordingly
	class RENGAPI NodeVisitor_Visibility: public NodeVisitor{
	public:
		NodeVisitor_Visibility();
		//! @note Currently, set to plane bounded volume type for efficiency reasons, 
		//!       but it can also be the generic volume type.
		const GeomPlaneBoundedVolume *mCullVolume;

		void visit(SceneNode& node);
		void visit(GroupNode& node);
		void visit(RootNode& node);
		void visit(SwitchGroupNode& node);
		void visit(LODGroupNode& node);
		void visit(MeshNode& node);
		void visit(CameraNode& node);
		void visit(LightNode& node);
	private:
		bool mTreeNoCull;
		bool isVisible(SceneNode& node);
	};

	//! Scene Graph Visitor that detects visible mesh and group nodes and 
	//! queues the renderables for bounding volume geoms accordingly
	class RENGAPI NodeVisitor_Visibility_BoundVol: public NodeVisitor{
	public:
		NodeVisitor_Visibility_BoundVol();
		//! @note Currently, set to plane bounded volume type for efficiency reasons, 
		//!       but it can also be the generic volume type.
		const GeomPlaneBoundedVolume *mCullVolume;

		void visit(SceneNode& node);
		void visit(GroupNode& node);
		void visit(RootNode& node);
		void visit(SwitchGroupNode& node);
		void visit(LODGroupNode& node);
		void visit(MeshNode& node);
		void visit(CameraNode& node);
		void visit(LightNode& node);
	private:
		bool mTreeNoCull;
		bool isVisible(SceneNode& node);
	};

} // namespace REng

#endif

