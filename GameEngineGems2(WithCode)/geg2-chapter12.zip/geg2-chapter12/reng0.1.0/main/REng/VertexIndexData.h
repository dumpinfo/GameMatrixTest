/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_VERTEXINDEXDATA_H_
#define _RENG_VERTEXINDEXDATA_H_

#include "REng/Prerequisites.h"

#include <list>
#include <map>
#include <string>

// uses shared pointers to vertex/index buffer
#include "REng/GPU/GPUBuffer.h"

#include "REng/VertexAttrib.h"
#include "REng/Util.h"

namespace REng{

	/*!
	 *  @brief Defines a complete vertex data (possibly with many attributes distributed over many buffers)
	 *  @author Adil Yalcin
	 */ 
	class RENGAPI VertexData{
	public:
		VertexData();
		~VertexData();

		//! @brief The range this vertex data occupies in all vertex buffers assigned.
		Range mRange;

		/************************************************************************/
		/* VERTEX DECLARATION (ATTRIBUTE LIST) RELATED METHODS                  */
		/************************************************************************/

		//! @brief Inserts the given attribute to the given list index.
		//! @note  An optimal attribute order is automatically managed.
		void insertAttribute(const VertexAttribute& attrib);

		//! @brief Removes the element from in the given index.
		//! @param index The index must be between 0 and attribute count.
		void removeAttribute(size_t index);

		//! @brief Removes all attributes
		void clearAttributes(void);

		//! @brief The number of attributes this declaration has
		size_t getAttributeCount(void) const;

		//! @brief Returns the specific element at the given index
		//! @param index The index must be between 0 and attribute count.
		const VertexAttribute& getAttribute(unsigned short index) const;

		//! @brief Returns the complete list of attributes that are assigned to the given source
		//! @return Can be 0 if no attribute is assigned to the buffer
		const VertexAttributeList& getAttributeElementsAll() const;

		//! @brief Returns the list of attributes that are assigned to the given source
		//! @param source The source ID
		VertexAttributeList getAttributeElementsBySource(unsigned char source);

		//! @brief Gets the vertex size (using the ordered attributes this declaration has)
		//! @param source The buffer source that holds the vertex attributes
		size_t getVertexSize(unsigned char source) const;

		//! @brief Getter for the maximum buffer source the attributes in this declaration has
		unsigned char getMaxSource(void) const;

		/************************************************************************/
		/* VERTEX DECLARATION (BUFFER LIST) RELATED METHODS                     */
		/************************************************************************/

		//! @brief Maps a hardware vertex buffer to the given index.
		//! @note  If a hardware buffer was already assigned to given index, it is over-written.
		void linkBufferToIndex(unsigned char index, VertexBufferPtr buffer);

		//! @brief If the given index holds a hardware vertex buffer, removes the mapping
		void unsetBufferIndex(unsigned char index);

		//! @brief Removes all bindings
		void clearBufferIndexes(void);

		//! @brief Provides read-only access to all the bindings that are stored
		const VertexBufferBindingMap& getBufferIndexes(void) const;

		//! @brief Returns a specific buffer in the given index
		//! @param index Must point to a valid mapped index. Check bound status using isBufferBound.
		VertexBufferPtr getBuffer(unsigned char index) const;

		//! @return True if a buffer is bound in the given index
		bool isBufferIndexed(unsigned char index) const;

		//! @return The number of mapped buffers
		size_t getIndexedBufferCount(void) const;

		//! @return The next smallest available buffer index
		unsigned char getFreeIndex(void) const;

	private:
		//! @brief Holds a list of vertex attributes.
		//!        Defines a complete per-vertex data description.
		std::list<VertexAttribute> mAttributeList;

		//! @brief A helper method used by std::sort for attribute list.
		static bool attributeOrderBefore(const VertexAttribute& atrib1, const VertexAttribute& atrib2);

		//! @brief Stores buffer logical id -> hardware buffer mapping
		//! @note  Only one hardware buffer may be bound to an index (unsigned char).
		VertexBufferBindingMap mBindingMap;

		//! @brief A cache that stores the smallest index that has no buffer bound.
		unsigned char mFreeIndexCache;

		//! Disabled copy constructor
		VertexData(const VertexData& rhs);

		//! Disabled assignment constructor
		VertexData& operator=(const VertexData& rhs);
	};
	typedef boost::shared_ptr<VertexData> VertexDataPtr;


	/*!
	 *  @brief The meshes can share the same index buffer and yet use different ranges.
	 *         This allows creating/using a bigger index buffer for more than one mesh.
	 *  @author Adil Yalcin
	 *
	 *  @note The hardware index buffer abstraction declares a single shader index data type and index count.
	 */ 
	class RENGAPI IndexData{
	public:
		IndexData();
		~IndexData();

		//! @brief The range this index data occupies in the index buffer assigned.
		Range mRange;

		//! @brief The types of primitives indexed
		PrimitiveType primType;

		//! @brief Setter for the shared hw/sw index buffer
		void setBufferPtr(IndexBufferPtr buf);

		//! @return A pointer to the hw/sw index buffer.
		//! @note  This stores 0 pointer if buffer pointer is not set
		IndexBufferPtr getBufferPtr() const;

	private:
		//! @brief A pointer to the index buffer (can be OpenGL or software buffer).
		//! @note  There is no ownership, index buffer is deleted when it is referenced no more.
		IndexBufferPtr mBufferPtr;
		
		//! Disabled copy constructor
		IndexData(const IndexData& rhs);
		
		//! Disabled assignment constructor
		IndexData& operator=(const IndexData& rhs);

		bool checkRange(size_t start, size_t size);
	};

	typedef RENGAPI boost::shared_ptr<IndexData>  IndexDataPtr;

} // namespace REng

#endif // _RENG_VERTEXINDEXDATA_H_
