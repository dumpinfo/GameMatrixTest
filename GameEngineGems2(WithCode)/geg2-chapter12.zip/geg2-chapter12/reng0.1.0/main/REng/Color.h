/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_COLOR_H_
#define _RENG_COLOR_H_

#include "REng/Prerequisites.h"

#include <iostream>

namespace REng{

	enum ColorType{
		ColorType_None = 0,
		ColorType_Int,
		ColorType_Real,
		ColorType_Packed
	};

	/**
	 * @class Color_Base
	 * @brief Represents a color value.
	 *  - Use one of the following as instances:
	 *    Color_Int, Color_Real, ColorRGBA, ColorARGB, ColorBGRA or ColorABGR types instead.
	 *  - Does not store data/define shared generic methods. 
	 *  - Each color has 4 separate components: Red, Green, Blue and Alpha.
	 *  TODO: Add automatic conversion between all types of color classes.
	 * @author Adil Yalcin
	 */
	class RENGAPI Color_Base { 
	public:
		virtual ColorType getColorType() const { return ColorType_None; }
	};

	// Forward declarations
	class Color_Int;
	class Color_Real;
	class Color_Packed;

	/**
	 * @class Color_Real
	 * @brief Represents a color value, using floating point components.
	 *  - You can set the real color value to single (float) or double type.
	 *  - It can be converted to and from Color_Int values.
	 *
	 *  - Expected range of each component is [0,1].
	 *  - Arithmetic operations/direct access does not prevent the range to be violated.
	 *  - Use compress() method to validate the range.
	 * @author Adil Yalcin
	 */
	class RENGAPI Color_Real : public Color_Base{
	public:

		//! Color channel data type for real-based colors
		typedef float ChType;

		//! The maximum value that a real-based color component should have (1.0)
		static const ChType MAX_VAL;
		//! The minimum value that a real-based color component should have (0.0)
		static const ChType MIN_VAL;

		/************************************************************************/
		/* CONSTRUCTORS                                                         */
		/************************************************************************/

		//! Initializes the color to black
		Color_Real();
		//! Initializes each color component to specified value
		Color_Real(ChType _r, ChType _g, ChType _b, ChType _a=ChType(1.0));
		//! Initializes each color component to values in array
		//! @param val Pointer to an array holding 4 values of type ChType, in order: RGBA
		//! @note val must be valid
		Color_Real(ChType* val);
		//! Sets the components of this color to the given color's components
		Color_Real(const Color_Real& val);

		ColorType getColorType() const { return ColorType_Real; }

		/************************************************************************/
		/* COMPONENT ACCESS                                                     */
		/************************************************************************/

		//! The red component
		ChType r;
		//! The blue component
		ChType g;
		//! The blue component
		ChType b;
		//! The alpha (transparency) component
		//! @remark If a=1.0, color is opaque. If a=0.0, color is transparent completely.
		ChType a;

		//! A helper for setting all components in one call
		void set(ChType _r, ChType _g, ChType _b, ChType _a=ChType(1.0));

		//! A helper for setting all components in one call
		//! @param val Pointer to an array holding 4 values of type ChType, in order RGBA
		void set(ChType* val);

		//! @return Pointer to color component data.
		//! @note No specific order is guaranteed.
		ChType* ptr();

		//! @return Pointer to color component data (const variant).
		//! @note No specific order is guaranteed.
		const ChType* ptr() const;

		/************************************************************************/
		/* COMPARISON                                                           */
		/************************************************************************/

		//! @return True if all components are equal, false otherwise
		bool operator==(const Color_Real& rhs) const;
		//! @return False if all components are equal, true otherwise
		bool operator!=(const Color_Real& rhs) const;

		// Can ordering between colors be defined ?

		/************************************************************************/
		/* CONVERTERS                                                           */
		/************************************************************************/

		//! @return The int-based representation of this color.
		//! @remark If the color component is saturated, the int-based color stores the compressed value.
		Color_Int get_Int() const;
		//! Sets the components of this color from the a color with int-based representation
		void setFrom_Int(const Color_Int& cp);

		/************************************************************************/
		/* ARITHMETIC OPERATORS                                                 */
		/************************************************************************/

		//! @remarks As result of arithmetic operations, component values may be saturated (<0 or >1)
		//!   It is programmers responsibility to call compress() method to limit value ranges.
		//!   This is mainly due to the fact that multiple operations can be applied to a color in one step
		//!   and we don't want to change the values in between.

		Color_Real operator+(const Color_Real& rhs) const;
		Color_Real operator-(const Color_Real& rhs) const;
		Color_Real operator*(const Color_Real& rhs) const;
		Color_Real operator/(const Color_Real& rhs) const;
		Color_Real operator*(ChType scalar  ) const;
		Color_Real operator/(ChType scalar  ) const;

		// Component-wise addition
		Color_Real& operator+=(const Color_Real& rhs);
		// Component-wise subtraction
		Color_Real& operator-=(const Color_Real& rhs);
		// Component-wise multiplication
		Color_Real& operator*=(const Color_Real& rhs);
		// Component-wise division
		Color_Real& operator/=(const Color_Real& rhs);

		/************************************************************************/
		/* HSB Space Conversion                                                 */
		/************************************************************************/

		//! @return Calculates the hue of this color in HSB-space and returns it.
		ChType getHue() const;

		//! @return Calculates the saturation of this color in HSB-space and returns it.
		ChType getSaturation() const;

		//! @return Calculates the brightness of this color in HSB-space and returns it.
		ChType getBrightness() const;

		//! @brief Updates the given parameters to hold tis colors conversion to HSB-space.
		void getHSB(ChType& _h, ChType& _s, ChType & _b) const;

		//! @brief Updates the RGB components to match the given color in HSB space
		//! @param _h Hue component in range: [0,1]. Range maps to [0,360] degrees
		//! @param _s Saturation component, in range: [0,1]
		//! @param _b Brightness component, in range: [0,1]
		//! @remark The alpha component is not affected.
		//! @remark The components are expected to be in the given ranges.
		void setFrom_HSB(ChType _h, ChType _s, ChType _b);

		/************************************************************************/
		/* MISC.                                                                 */
		/************************************************************************/

		//! Clamps all components in range (0,1)
		void compress();

		//! Inverts all components of the color.
		//! @remark The color values are compressed first.
		void invertRGBA();

		//! Inverts R,G and B components of the color.
		//! @remark The color values are compressed first.
		void invertRGB();

		//! @return The string representation of this color "R:_ G:_ B:_"
		std::string toString() const;	
	
		//! @return Appender to ostream
		friend std::ostream& operator<<( std::ostream& o, const Color_Real& c );

		/************************************************************************/
		/* PRE-DEFINED COLOR VALUES                                             */
		/************************************************************************/

		//! All components are zero
		static const Color_Real ZERO;

		static const Color_Real Black;
		static const Color_Real White;
		static const Color_Real Red;
		static const Color_Real Green;
		static const Color_Real Blue;

	protected:

		//! A helper method for color conversion
		//! @param _min Updated to store the minimum color component value
		//! @param _max Updated to store the maximum color component value
		void getMinMax(ChType& _min, ChType& _max) const;
	};
	
	/**
	 * @class Color_Int
	 * @brief Represents a color value, using byte-sized components
	 *  - Each component is a byte. (a color consumes 4*1 bytes in total)
	 *  - Each component value can be between 0 and 255.
	 *  - Can be converted to and from 4-byte packed color values.
	 * @author Adil Yalcin
	 */
	class RENGAPI Color_Int : public Color_Base{
	public:

		//! Color channel data type for integer-based colors (should be uchar, ushort or uint)
		typedef uchar ChType;

		//! The maximum value that an int-based color component may have. (255)
		static const ChType MAX_VAL;
		//! The minimum value that an int-based color component may have. (0)
		static const ChType MIN_VAL;

		/************************************************************************/
		/* CONSTRUCTORS                                                         */
		/************************************************************************/

		//! Initializes the color to black
		Color_Int();
		//! Initializes each color component to specified value
		Color_Int(ChType _r, ChType _g, ChType _b, ChType _a=(ChType(0)-1));
		//! Initializes each color component to values in array
		//! @param val Pointer to an array holding 4 values of type ChType, in order: RGBA
		//! @note val must be valid
		Color_Int(ChType* val);
		//! Sets the components of this color to the given color's components
		Color_Int(const Color_Int& val);

		ColorType getColorType() const { return ColorType_Int; }

		// Note: If you want to initialize from RGBA, ARGB, BGRA or ABGR values, use setFrom* methods.

		/************************************************************************/
		/* COMPONENT ACCESS                                                     */
		/************************************************************************/

		//! The red component
		ChType r;
		//! The blue component
		ChType g;
		//! The blue component
		ChType b;
		//! The alpha (transparency) component
		ChType a;

		//! A helper for setting/updating all components in one call.
		void set(ChType _r, ChType _g, ChType _b, ChType _a=(ChType(0)-1));

		//! A helper for setting/updating all components in one call.
		//! @param val A pointer to an array holding 4 values of type ChType, in order RGBA
		void set(ChType* val);

		//! @return Pointer to color component data.
		//! @note No specific order is guaranteed.
		ChType* ptr();

		//! @return Pointer to color component data (const variant).
		//! @note No specific order is guaranteed.
		const ChType* ptr() const;

		/************************************************************************/
		/* COMPARISON                                                           */
		/************************************************************************/

		//! @return True if all components are equal, false otherwise
		bool operator==(const Color_Int& rhs) const;
		//! @return False if all components are equal, true otherwise
		bool operator!=(const Color_Int& rhs) const;

		// Can ordering between colors be defined ?

		/************************************************************************/
		/* CONVERTERS                                                           */
		/************************************************************************/

		//! @return The real-based representation of this color.
		Color_Real get_Real() const;
		//! Sets the components of this color from the a color with real-based representation
		void setFrom_Real(const Color_Real& cp);

		//! @return A packed color representation
		//! @remark The resolution may be lowered if int per-channel resolution is higher than 8-bits
		Color_Packed get_Packed() const;

		//! Sets the components of this color from the a packed-color value
		void setFrom_Packed(const Color_Packed& val);

		/************************************************************************/
		/* ARITHMETIC OPERATORS                                                 */
		/************************************************************************/

		//! @remarks Arithmetic operators can cause overflows in components.
		//!          If you want to allow overflowed data, use Color_Real class 
		//!          or do your own calculations yourself

		Color_Int operator+(const Color_Int& rhs) const;
		Color_Int operator-(const Color_Int& rhs) const;

		Color_Int& operator+=(const Color_Int& rhs);
		Color_Int& operator-=(const Color_Int& rhs);

		/************************************************************************/
		/* MISC.                                                                 */
		/************************************************************************/

		//! Inverts all components of the color.
		void invertRGBA();

		//! Inverts R,G and B components of the color.
		void invertRGB();

		//! @return The string representation of this color "R:_ G:_ B:_"
		std::string toString() const;

		//! @return Appender to ostream
		friend std::ostream& operator<<( std::ostream& o, const Color_Int& c );

		/************************************************************************/
		/* PRE-DEFINED COLOR VALUES                                             */
		/************************************************************************/

		//! All components are zero
		static const Color_Int ZERO;

		static const Color_Int Black;
		static const Color_Int White;
		static const Color_Int Red;
		static const Color_Int Green;
		static const Color_Int Blue;

	};

	enum Color_Pack_Type{
		Color_Pack_RGBA,
		Color_Pack_ARGB,
		Color_Pack_BGRA,
		Color_Pack_ABGR
	};

	/**
	 * @class Color_Packed
	 * @brief Represents a color value, using a single 32bit component
	 *  - Each component is a byte (8bit).
	 *  - TODO: How to extend with irregular bit distribution (Ex: 10R,10G,10B,2A)
	 * @author Adil Yalcin
	 */
	class RENGAPI Color_Packed: public Color_Base{
	public:

		/************************************************************************/
		/* CONSTRUCTORS                                                         */
		/************************************************************************/

		//! Initializes the color to black, RGBA
		Color_Packed();
		//! Initializes color to specified value, using specified type
		Color_Packed(uint val, Color_Pack_Type _type = Color_Pack_RGBA);
		//! Sets the components of this color to the given color's components
		Color_Packed(const Color_Packed& val);

		ColorType getColorType() const { return ColorType_Packed; }

		/************************************************************************/
		/* TYPE INFO                                                            */
		/************************************************************************/

		//! @return The type of this 32-bit color
		Color_Pack_Type getType() const;
		//! @brief Sets the type of this packed color to given _type
		//! @remark Converts the internal representation of the color as well
		void setType(Color_Pack_Type _type);

		/************************************************************************/
		/* COMPONENT ACCESS                                                     */
		/************************************************************************/

		//! @return The color value (ordered wrt type info of packed color)
		uint get() const;

		//! Updates the given variables to color component values of this packed color
		void get(uchar& _red, uchar& _green, uchar& _blue, uchar& _alpha) const;

		//! Updates the given variables to color component values of this packed color
		//! @param _comp An array holding -at least- 4 uchar values, updated in order RGBA
		void get(uchar* _comp) const;

		// To read specific channel component, you need to first convert 32bit color to int color
		// To write to a spec. channel comp, you need to use an int-color first, than convert it to 32-bit color.

		/************************************************************************/
		/* COMPARISON                                                           */
		/************************************************************************/

		//! @return True if color value is equal, false otherwise
		//! @remark Converts the mType of one side to match other if required.
		bool operator==(const Color_Packed& rhs) const;
		//! @return False if color value is equal, true otherwise
		//! @remark Converts the mType of one side to match other if required.
		bool operator!=(const Color_Packed& rhs) const;

		// Can ordering between colors be defined ?

		/************************************************************************/
		/* CONVERTERS                                                           */
		/************************************************************************/

		//! @return The int-based representation of this color.
		Color_Int get_Int() const;
		//! Sets the components of this color from the a color with int-based representation
		void setFrom_Int(const Color_Int& cp);

		/************************************************************************/
		/* MISC.                                                                 */
		/************************************************************************/

		//! Inverts all components of the color.
		void invertRGBA();

		//! Inverts R,G and B components of the color.
		void invertRGB();

		//! @return The string representation of this color "R:_ G:_ B:_"
		std::string toString() const;

		//! @return Appender to ostream
		friend std::ostream& operator<<( std::ostream& o, const Color_Packed& c );

		/************************************************************************/
		/* PRE-DEFINED COLOR VALUES                                             */
		/************************************************************************/

	private:
		//! The mType of the value stored
		Color_Pack_Type mType;

		//! The 32-bit value of the color
		uint mColor;

		static const uint VAL_0; // 0xFF000000
		static const uint VAL_1; // 0x00FF0000
		static const uint VAL_2; // 0x0000FF00
		static const uint VAL_3; // 0x000000FF

		// arithmetic operators are not allowed 
		Color_Packed  operator+(const Color_Packed& rhs) const;
		Color_Packed  operator-(const Color_Packed& rhs) const;
		Color_Packed  operator*(const Color_Packed& rhs) const;
		Color_Packed  operator/(const Color_Packed& rhs) const;
		Color_Packed& operator+=(const Color_Packed& rhs);
		Color_Packed& operator-=(const Color_Packed& rhs);
		Color_Packed& operator*=(const Color_Packed& rhs);
		Color_Packed& operator/=(const Color_Packed& rhs);
	};

	#include "inl/Color.inl"

} // namespace REng

#endif // _RENG_COLOR_H_
