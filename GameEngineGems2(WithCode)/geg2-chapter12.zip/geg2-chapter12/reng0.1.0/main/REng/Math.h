/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATH_H_
#define _RENG_MATH_H_

#include "REng/Prerequisites.h"

#include <cmath>

namespace REng {

	namespace Math {

		// PI number with high precision
		const float PI = 3.14159265358979323846264338327950288;

		//! Clamps the given value to range minVal - maxVal
		template<typename T> T clamp(T val, T minVal, T maxVal);

		//! Computes the square of the input value
		template<typename T> T sqr(T value);

		//! Returns the absolute of the input value
		template<typename T> T abs(T value);

		//! Returns the minimum of the given values
		template<typename T> T min(T x, T y);
		
		//! Returns the maximum of the given values
		template<typename T> T max(T x, T y);

		//! Computes a fast 1 / sqrtf(v) approximation
		float rsqrtf(float v);

		//! Computes unnormalized sinc function
		float sincf(float x);

		//! Rounds the given floating value
		float roundf(float x);

		uint getClosestPowerOfTwo(unsigned int x);

		uint getUpperPowerOfTwo(unsigned int x);

		uint getLowerPowerOfTwo(unsigned int x);

		int round(float x);

		Vector3 rotateVector(const Quaternion& rot, const Vector3& vec);

		//! Generates a value based on the Gaussian (normal) distribution function
		//! with the given offset and scale parameters.
		float gaussianDistribution(float x, float offset = 0.0f, float scale = 1.0f);
	};


	// From humus' framework...
	inline float Math::rsqrtf(float v){
	// This code supposedly originates from Id-software
/*	inline float rsqrtf(float v){
		float v_half = v * 0.5f;
		int i = *(int *) &v;
		i = 0x5f3759df - (i >> 1);
		v = *(float *) &i;
		return v * (1.5f - v_half * v * v);
	} */
		union {
			float vh;
			int i0;
		};
		union {
			float vr;
			int i1;
		};
		vh = v * 0.5f;
		i1 = 0x5f3759df - (i0 >> 1);
		return vr * (1.5f - vh * vr * vr);
	}

	inline float Math::sincf(float x){
		return (x == 0)? 1 : sinf(x) / x;
	}

	inline float Math::roundf(float x){
		return floorf(x + 0.5f);
	}

	template<typename T> inline T Math::min(T x, T y){
		return ((x < y)? x : y);
	}
	template<typename T> inline T Math::max(T x, T y){
		return ((x > y)? x : y);
	}
	template<typename T> inline T Math::sqr(T v){
		return v*v;
	}
	template<typename T> inline T Math::abs(T x){
		return ((x >= 0)? x : -x);
	}

	template<typename T> inline T Math::clamp(T val, T minVal, T maxVal){
		assert (minVal<maxVal && "Invalid clamp range");
		return Math::max(Math::min(val, maxVal), minVal);
	}


	inline uint getClosestPowerOfTwo(unsigned int x){
		unsigned int i = 1;
		while (i < x) i += i;
		if (4 * x < 3 * i) i >>= 1;
		return i;
	}

	inline uint Math::getUpperPowerOfTwo(unsigned int x){
		unsigned int i = 1;
		while (i < x) i += i;
		return i;
	}

	inline uint Math::getLowerPowerOfTwo(unsigned int x){
		unsigned int i = 1;
		while (i <= x) i += i;
		return i >> 1;
	}

	inline int Math::round(float x){
		if (x > 0){
			return int(x + 0.5f);
		} else {
			return int(x - 0.5f);
		}
	}

	// NOTE: THIS METHOD IS TEMPORARY! ADD CORRECT IMPLEMENTATION TO CML LIBRARY!
	inline Vector3 Math::rotateVector(const Quaternion& rot, const Vector3& vec){
		// http://www.gamedev.net/community/forums/topic.asp?topic_id=264455
		/*
		Quaternion middleTerm(vec[0], vec[1], vec[2], 0);
		Quaternion lastTerm(rot);
		lastTerm.inverse();
		Quaternion toRet = rot * middleTerm * lastTerm;
		return Vector3(toRet[toRet.X],toRet[toRet.Y],toRet[toRet.Z]);
		*/
		//		/*		
		// nVidia SDK implementation
		Vector3 uv, uuv;
		Vector3 qvec(rot[rot.X], rot[rot.Y], rot[rot.Z]);
		uv = cml::cross(qvec, vec);
		uuv = cml::cross(qvec, uv);
		uv *= (2.0f * rot[rot.W]);
		uuv *= 2.0f;
		return vec + uv + uuv;
		//		*/
	}

	inline float Math::gaussianDistribution(float x, float offset, float scale){
		float nom = std::exp(-Math::sqr(x-offset) / (2*Math::sqr(scale)));
		float denom = scale * std::sqrt(2 * Math::PI);
		return nom / denom;
	}

}

#endif
