/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SCREENCAPTURER_H_
#define _RENG_SCREENCAPTURER_H_

#include "REng/Prerequisites.h"
#include "REng/Singleton.h"
#include "REng/GPU/GPUFrameBuffer.h"
#include "REng/Rect.h"

#include <string>

// writes image data to external files
#if IMLOAD_LIB == IMLOAD_DEVIL
	#include <il/il.h>
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
	#include <FreeImage.h>
#endif

namespace REng{

	//! Possible types of image file formats that capturer can write to
	//! @note The actual "supported" file types are dependent on the capabilities of 
	//!       the linked image loader library
	enum ImageFileType{
		IFT_BMP,
		IFT_DDS,
		IFT_GIF,
		IFT_HDR,
		IFT_JPG,
		IFT_PNG,
		IFT_RAW,
		IFT_TGA,
		IFT_TIFF,
	};

	/*!
	 * @brief Allows grabbing the content of a frame buffer to an image file of a requested type
	 * @author Adil Yalcin
	 */
	class RENGAPI ScreenCapturer {
	public:
		ScreenCapturer();
		~ScreenCapturer();

		/*!
		 *  @brief Saves the currently stored screen capture to an image file.
		 *  @param ext The extension of the image file to create (defaults to PNG)
		 *  @param filename File name base string (defaults to "scrCap")
		 *  @param useTimestamp If true, a timestamp info 'YYYYMMDD_HHMMSS' is inserted after filename.
		 *  @param useUniqueID  If true, a unique ID is generated for each saved file. This ID is inserted
		 *                      before the filename
		 *  @note This method does not write over existing files.
		 *  @return True if image as successfully written into an external file, false otherwise
		 */
		bool saveCaptureToFile(
			ImageFileType ext = IFT_PNG, 
			const std::string& filename = "scrCap", 
			bool useTimestamp = false,
			bool useUniqueID = false) const;

		/*!
		 *  @brief Reads the specified components of a frame buffer to internal image, stored on CPU
		 *  @param frameBufObj The buffer object which we would like to read the content of
		 *  @param region The area on the frame buffer, given in absolute integer coordinates
		 *                If set to 0, reads the whole buffer.
		 *  @param format Specifies components that will be read from the given frame buffer object
		 *  @param source Specifies the color buffer that will be used to read color components (RGBA), 
		 *                if format requests such components. Has no effect for ES 2.0 configurations.
		 *  @return False on failure, true otherwise
		 */
		bool captureFrame(
			const GPUFrameBuffer& frameBufObj, 
			RectI region = RectI(0,0,0,0),
			PixelDataFormat format = PixelDataFormat_RGBA,
			FrameBufferColorBufferType source = FrameBufferColorBufferType_Color0);

		/*!
		 *  @brief Reads the specified components of a window buffer to internal DevIL image
		 *  @param format Specifies components that will be read from the given frame buffer object
		 *  @param region The area on the frame buffer, given in absolute integer coordinates
		 *  @param source Specifies the color buffer that will be used to read color components (RGBA), 
		 *                if format requests such components. Has no effect for ES 2.0 configurations.
		 *  @return False on failure, true otherwise
		 */
		bool captureFrame(
			RectI region,
			PixelDataFormat format = PixelDataFormat_RGBA,
			WindowBufferSource source = WindowBufferSource_Back);

	private:
		ushort mWidthCache;
		ushort mHeightCache;

#if IMLOAD_LIB == IMLOAD_DEVIL
		ILuint mScreenShotImage;
#elif IMLOAD_LIB == IMLOAD_FREEIMAGE
		FIBITMAP* mScreenShotImage;
#endif

	};

} // namespace REng

#endif // _RENG_SCREENCAPTURER_H_
