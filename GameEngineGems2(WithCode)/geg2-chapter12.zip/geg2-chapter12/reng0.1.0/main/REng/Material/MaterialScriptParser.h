/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIALSCRIPTPARSER_H_
#define _RENG_MATERIALSCRIPTPARSER_H_

#include "REng/Prerequisites.h"

#include "REng/Singleton.h"

// access render property type
#include "REng/GPU/RenderProperty.h"
#include "REng/GPU/GPUSampler.h"

namespace REng{

	// forward declarations

	/*! 
	 *  \brief parses and creates material data. Does not load materials
	 *  \author Adil Yalcin
	 */
	class RENGAPI MaterialScriptParser : public Singleton<MaterialScriptParser> {

	public:
		//! @brief Opens up the script parser log file
		MaterialScriptParser(void);
		//! @brief Simple Destructor
		~MaterialScriptParser(void);

		//! @brief singleton access
		static MaterialScriptParser& getSingleton(void);
		//! @brief singleton access
		static MaterialScriptParser* getSingletonPtr(void);

		//! @return True if complete file is parsed.
		/*! See parser log for parse details / errors */
		//! @todo Rename to parseFromFile
		bool parseFile(const char* fileName);

		//! @return True if complete file is parsed.
		/*! See parser log for parse details / errors */
		bool parseFromMem(const char* mem, size_t memSize);

		//! @brief conversion helper (str -> GLenum)
		//! @param str string to convert from
		//! @param ret GLenum data that is updated on success
		//! @return true on successful conversion
		bool getGLenum(const char* str, GLenum &ret);

		// file read helpers

		//! @brief simple string tokenizer (with no white-space, etc)
		const char* readString();
		bool readFloat(float& data);
		bool readBool(bool& data);
		bool readUnsignedInt(unsigned int& data);
		bool readInt(int& data);
		bool readUniformType(UniformType& type);
//		bool readAttributeType(VertexAttribShaderType& type);
		bool readGLenum(GLenum& glenum);
		bool readImageFormat(ImageFormat& format);
		bool readOnOff(bool& data);

		// Note: log helpers are public, because certain classes define their own parse routines from FILE's
		
		void logGLConverstionError(const char* token);
		void logUnrecogTokenError(const char* token, const char* state);
		void logWrongTokenError(const char* token, const char * expected);
		void logMultipleDefError(const char * deftype);
		void logUnsignedIntError();
		void logUniformDataError();
		void logDefaultError(const char* token);
		void logDefaultWarning(const char* token);

	protected:

		//! @brief conversion helper (str -> Render State Category)
		//! @param str string to convert from
		//! @param rpt render property type that is updated on success
		//! @return true on successful conversion
		static bool getRPT(const char* str, RenderPropertyType &rpt);

		// BLOCK PARSERS

		//! @brief parses a top-level material shader block
		//! @return True on successful completion
		bool parseShader(const std::string& name);

		bool parseSampler(const std::string& name,
			MaterialTexture* texture, GPUSamplerPtr& fillThisIn);

		//! @brief parses a top-level material texture block
		//! @return True on successful completion
		bool parseTexture(const std::string& name);

		//! @brief parses a top-level material program block
		//! @return True on successful completion
		bool parseProgram(const std::string& name);

		//! @brief parses a top-level material block
		//! @return True on successful completion
		bool parseMaterial(const std::string& name);

		//! @brief parses a technique block
		//! @return True on successful completion
		bool parseTechnique(Material* material);

		//! @brief parses a render pass block
		//! @return True on successful completion
		bool parsePass(RenderPass* pass);

		//! @brief parses a texture binding block
		//! @return True on successful completion
		bool parseTextureBinding(RenderPass* pass);

		//! @brief: returns true is a is a white-space character (space, tab, newline)
		static inline bool isWhiteSpace(char a);

#define MAX_STR_LEN 256

		//! @brief A string cache for file tokenizer
		char str[MAX_STR_LEN];

		//! Holds the content of a material file that is being parsed.
		const char *matText;
		size_t matTextReadPos;
		size_t matTextSize;

		//! @brief stores where we are in the parsed file 
		size_t mScriptLineNo;
		bool mPostLine;
		int mPreLineCount;

		bool noSkipComments;

		friend class RenderProp;
	};

} // namespace REng

#endif // _RENG_MATERIALSCRIPTPARSER_H_
