/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_PVRLOADER_H_
#define _RENG_PVRLOADER_H_

#include "REng/Prerequisites.h"
#include "REng/Defines.h"

#include "REng/Math.h"

// NOTE: Parts of PVRLoader implementation are based on 
// OOLONG engine (http://code.google.com/p/oolongengine/) and PowerVR SDK.

namespace REng{

	//! Meta-data in PVR files, in the order of specifications
	struct PVRHeader {
		khronos_uint32_t headerSize;       ///< size of the structure
		khronos_uint32_t height;           ///< height of surface to be created
		khronos_uint32_t width;            ///< width of input surface
		khronos_uint32_t mipmapCount;      ///< number of MIP-map levels requested
		khronos_uint32_t pixelFormatFlags; ///< pixel format flags
		khronos_uint32_t textureDataSize;  ///< Size of the compress data
		khronos_uint32_t bitsPerPixel;     ///< number of bits per pixel
		khronos_uint32_t bitmaskRed;       ///< mask for red bit
		khronos_uint32_t bitmaskGreen;     ///< mask for green bit
		khronos_uint32_t bitmaskBlue;      ///< mask for blue bit
		khronos_uint32_t bitmaskAlpha;     ///< mask for alpha channel
		khronos_uint32_t pvrID;            ///< "PVR"
		khronos_uint32_t numSurfaces;      ///< number of surfaces for volume textures or skyboxes
	};

	enum PVRPixelFormatTag {
		MGLPT_ARGB_4444    = 0x00, // start MGLPT enum
		MGLPT_ARGB_1555    = 0x01,
		MGLPT_RGB_565      = 0x02,
		MGLPT_RGB_555      = 0x03,
		MGLPT_RGB_888      = 0x04,
		MGLPT_ARGB_8888    = 0x05,
		MGLPT_ARGB_8332    = 0x06,
		MGLPT_I_8          = 0x07,
		MGLPT_AI_88        = 0x08,
		MGLPT_1_BPP        = 0x09,
		MGLPT_VY1UY0       = 0x0A,
		MGLPT_Y1VY0U       = 0x0B,
		MGLPT_PVRTC2       = 0x0C,
		MGLPT_PVRTC4       = 0x0D,
		MGLPT_PVRTC2_2     = 0x0E,
		MGLPT_PVRTC2_4     = 0x0F,

		OGL_RGBA_4444      = 0x10, // start OGL enum
		OGL_RGBA_5551      = 0x11,
		OGL_RGBA_8888      = 0x12,
		OGL_RGB_565        = 0x13,
		OGL_RGB_555        = 0x14,
		OGL_RGB_888        = 0x15,
		OGL_I_8            = 0x16,
		OGL_AI_88          = 0x17,
		OGL_PVRTC2         = 0x18,
		OGL_PVRTC4         = 0x19,
		OGL_BGRA_8888      = 0x1A,
		OGL_A_8            = 0x1B,
		OGL_PVRTCII4       = 0x1C,
		OGL_PVRTCII2       = 0x1D,

		D3D_DXT1           = 0x20, // start D3D enum
		D3D_DXT2           = 0x21,
		D3D_DXT3           = 0x22,
		D3D_DXT4           = 0x23,
		D3D_DXT5           = 0x24,

		D3D_RGB_332        = 0x25,
		D3D_AI_44          = 0x26,
		D3D_LVU_655        = 0x27,
		D3D_XLVU_8888      = 0x28,
		D3D_QWVU_8888      = 0x29,

		//10 bits per channel
		D3D_ABGR_2101010   = 0x2A,
		D3D_ARGB_2101010   = 0x2B,
		D3D_AWVU_2101010   = 0x2C, 

		//16 bits per channel
		D3D_GR_1616        = 0x2D,
		D3D_VU_1616        = 0x2E,
		D3D_ABGR_16161616  = 0x2F,

		//HDR formats
		D3D_R16F           = 0x30,
		D3D_GR_1616F       = 0x31,
		D3D_ABGR_16161616F = 0x32,

		//32 bits per channel
		D3D_R32F           = 0x33,
		D3D_GR_3232F       = 0x34,
		D3D_ABGR_32323232F = 0x35,

		// Ericsson Texture Compression
		ETC_RGB_4BPP          = 0x36,
		ETC_RGBA_EXPLICIT     = 0x37,
		ETC_RGBA_INTERPOLATED = 0x38,

		MGLPT_NOTYPE = 0xff
	};


	//! Load hardware-friendly texture formats from given files / memory blocks
	//! using the PVR container file format
	class PVRLoader{
	public:
		PVRLoader();
		~PVRLoader();

		//! @return True if the pvr file is loaded and the data is stored inside the instance
		bool loadFromFile(const char* fileName);
		//! @return True if the pvr file is loaded and the data is stored inside the instance
		bool loadFromMem(const void* data);

		uint getWidth() const;
		uint getHeight() const;
		ImageFormat getFormat() const;
		PixelDataType getPixelDataType() const;
		PixelDataFormat getPixelDataFormat() const;
		uint getMipmapCount() const;

		//! @return The starting memory address for the given surface no.
		//! @param surfaceNo If it exceeds mNumSurfaces, 0 is returned.
		//! @param mipmapLevel If it exceeds mMipmapCount, 0 is returned.
		const void* getTextureData(uint surfaceNo=0,uint mipmapLevel=0) const;

		//! @note For each surface, the mipmap texture sizes are the same.
		void getTextureSize(uint &width, uint &height, uint mipmapLevel=0) const;

		//! @note For each surface, the mipmap texture sizes are the same.
		uint getTextureDataSize(uint mipmapLevel=0) const;

	private:
		// texture width
		uint mWidth;
		// texture height
		uint mHeight;
		// Internal Image format as requested by OpenGL
		ImageFormat mGLFormat;
		// Pixel data type & format (valid for non-compressed formats only)
		PixelDataType mPixelDataType; 
		PixelDataFormat mPixelDataFormat;
		uint mTextureDataSize;
		uint mMipmapCount;
		uint mBitsPerPixel;
		uint mBitmaskRed;
		uint mBitmaskGreen;
		uint mBitmaskBlue;
		uint mBitmaskAlpha;
		uint mNumSurfaces;

		//! If NULL, no texture has been loaded
		void* mTextureDataPtr;

		//! Holds the list of pointers to mipmapped surface data starting addresses
		void** mTextureSurfaceMipMapDataPtr;
		uint*  mTextureSurfaceMipMapSize;
	};


	inline uint PVRLoader::getWidth() const { 
		return mWidth;
	}
	inline uint PVRLoader::getHeight() const { 
		return mHeight;
	}
	inline ImageFormat PVRLoader::getFormat() const { 
		return mGLFormat; 
	}
	inline PixelDataType PVRLoader::getPixelDataType() const{
		return mPixelDataType;
	}
	inline PixelDataFormat PVRLoader::getPixelDataFormat() const{
		return mPixelDataFormat;
	}
	inline uint PVRLoader::getMipmapCount() const{
		return mMipmapCount;
	}

	inline const void* PVRLoader::getTextureData(uint surfaceNo,uint mipmapLevel) const{
		if(surfaceNo>=mNumSurfaces) return 0;
		if(mipmapLevel>mMipmapCount) return 0;
		return mTextureSurfaceMipMapDataPtr[surfaceNo*mMipmapCount+mipmapLevel];
	}
	inline void PVRLoader::getTextureSize(uint &width, uint &height, uint mipmapLevel) const{
		if(mipmapLevel>mMipmapCount) return;
		width=mWidth;
		height=mHeight;
		for(uint i=0 ; i<mipmapLevel ; ++i){
			width=Math::max(width/2,uint(1));
			height=Math::max(height/2,uint(1));
		}
	}
	inline uint PVRLoader::getTextureDataSize(uint mipmapLevel) const{
		if(mipmapLevel>mMipmapCount) return 0;
		return mTextureSurfaceMipMapSize[mipmapLevel];
	}

}

#endif // _RENG_PVRLOADER_H_

