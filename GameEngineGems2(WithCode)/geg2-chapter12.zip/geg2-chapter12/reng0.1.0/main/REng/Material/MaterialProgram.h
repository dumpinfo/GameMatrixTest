/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIALPROGRAM_H_
#define _RENG_MATERIALPROGRAM_H_

#include "REng/Prerequisites.h"

//! Is a GPUProgram
#include "REng/GPU/GPUProgram.h"
//! Holds material shader pointers
#include "REng/Material/MaterialShader.h"
//! stores uniform property list
#include "REng/GPU/RenderProperty.h"

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

namespace REng{
	
	/**
	 * @brief Material programs are named GPUPrograms and can hold uniform state defaults 
	 *         associated with that program.
	 * @author Adil Yalcin
	 */
	class RENGAPI MaterialProgram : public GPUProgram {
	public:
		~MaterialProgram();

		//! @return The name of the material program 
		const std::string& getName() const;

		void setShaderName1(const std::string& name);
		void setShaderName2(const std::string& name);
		void setShaderPtr1(MaterialShaderPtr shader);
		void setShaderPtr2(MaterialShaderPtr shader);

		//! Resolves vertex and fragment material shader names and attaches them to the GPUProgram
		//! It also loads shader / program defaults after linking is completed.
		//!
		//! @return True if all names are resolved and are correctly attached to the GPUProgram
		//! @remark The vertex and fragment material shader names are cleared if successful.
		bool resolveAttachAndLinkShaders();

		//! Has the shader data attached to this program been resolved by the material system?
		bool isResolved();

		/****************************/
		/* UNIFORM DEFAULT HANDLING */
		/****************************/

		//! @brief adds a default uniform state
		void addUniformDefault(RenderProp_Uniform* prop);

		//! @brief removes all uniform state defaults
		void clearUniformDefaults();

		//! @brief removes a uniform at a specific index
		void removeUniformDefault(size_t index);

		//! @return the number of default uniform states defined for this material shader
		size_t getUniformDefaultsCount() const;

		//! @return the (const) uniform defaults list
		const UniformPropertyList& getUniformDefaults() const;

		//! @param index must be a valid index [0,uniformDefaultCount]
		//! @return the uniform data 
		RenderProp_Uniform* getUniformDefault(size_t index);

		//! @brief searches the uniform with the given name.
		//! @param uniformName the name of GLSL uniform
		//! @return If search is successful, the uniform data. Else, 0
		RenderProp_Uniform* getUniformDefault(const std::string& uniformName);

	private:
		//! @brief each material texture has a unique name.  Cannot modify after object is created.
		/*! Uniqueness is provided by MaterialManager.*/
		std::string mName;

		bool mIsResolved;

		//! The name of the vertex shader this program will link
		std::string mVertMatShaderName;

		//! The name of the fragment shader this program will link
		std::string mFragMatShaderName;

		//! Each program must define one vertex shader (to be valid)
		//! @note Set mVertMatShaderName before calling resolveAttachAndLinkShaders()
		MaterialShaderPtr mVertMatShader;

		//! Each program must define one fragment shader (to be valid)
		//! @note mFragMatShaderName before calling resolveAttachAndLinkShaders()
		MaterialShaderPtr mFragMatShader;

		/*! @brief The uniform default values that will be uploaded to the program after
		 *         successful compilation.
	    *  @remark This list is cleared after synchronization with the program
		 */
		UniformPropertyList mUniformDefaults;

		//! @brief Reads the active uniforms from the program object and 
		//!        updates the defaults as set by vertex or fragment material shaders.
		void updateUniformPropsFromProgram();

		//! @note MaterialManager AND material script parser can create material programs.
		//!       If parser creates it, it should not be referenced again
		MaterialProgram(const std::string& name);

		friend class MaterialManager;
		friend class MaterialScriptParser;
		friend class RenderPass;
	};

	typedef boost::shared_ptr<MaterialProgram> MaterialProgramPtr;

} // namespace REng

#endif // _RENG_MATERIALPROGRAM_H_
