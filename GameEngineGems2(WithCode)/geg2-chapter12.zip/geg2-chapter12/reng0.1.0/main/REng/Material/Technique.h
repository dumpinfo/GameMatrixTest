/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_TECHNIQUE_H_
#define _RENG_TECHNIQUE_H_

#include "REng/Prerequisites.h"

#include <vector>

namespace REng{

	/*! \class Technique
	 *  \brief Techniques are used mainly for two purposes
	 *         - using different shading instructions based on LoD level
	 *         - using different shading instructions based on view count (for multi-view rendering)
	 *  \author Adil Yalcin
	 *
	 * The material system manages which technique of a material to render based on LoD and view no.
	 */

	class RENGAPI Technique {
	public:
		//! @brief Use a material to create an lod'ed technique.
		//!        This is provided to stop compiler complaining 
		//!        ( allow Technique to be defined as a regular LoD data. )
		Technique();

		//! Also deletes the rendering pass information this technique holds
		~Technique(void);

		//! @return The owner material
		const Material *getOwnerMaterial() const;

		//! Clones this techniques render pass data to the given technique
		void clone(Technique& _to) const;
		
		//! @return False if this technique has no render pass
		//! @return False if any render pass is not valid
		bool isValid() const;

		//! @brief creates a new pass for this technique
		//! @return the newly created and appended render pass
		RenderPass* createRenderPass(void);

		//! @return the pass with the given index
		RenderPass* getRenderPass(unsigned char passIndex = 0);

		//! @return The number of passes.
		unsigned char getRenderPassCount(void) const;

		//! Removes the pass with the given index.
		void removeRenderPass(unsigned char passIndex);

		//! Removes all Passes from this technique
		void clearPasses(void);

		//! @brief Swaps a pass index from source index to destination index. 
		//! @return True, if successful.
		bool movePass(const unsigned short sourceIndex, const unsigned short destinationIndex);

		//! @brief a helper method to prepare the pass state at the given index 
		//! @see prepareState::prepareState
		void preparePassState(size_t passIndex);

		//! @brief a helper method for to clear the pass state at the given index 
		//! @see prepareState::clearState
		void clearPassState(size_t passIndex);

		//! @brief Loads all the RenderPasses this technique is composed of
		//! @return True if all render passes could be loaded
		//! Note: call this after creating render passes
		bool load();

	private:
		typedef std::vector<RenderPass*> RenderPassList;

		//! @brief The owner material
		Material *mOwnerMaterial;

		//! @brief Techniques have one or more renderPasses (at most max(unsigned char) = 255)
		RenderPassList mRenderPasses;

		//! @brief A technique can only be constructed from within a Material object
		Technique(Material *ownerMaterial);

		//! @brief disable copy constructor
		Technique(Technique&);
		
		//! @brief disable assignment operator
		Technique&	operator=(Technique&);

		friend class Material;
	};

} // namespace REng

#endif // _RENG_TECHNIQUE_H_
