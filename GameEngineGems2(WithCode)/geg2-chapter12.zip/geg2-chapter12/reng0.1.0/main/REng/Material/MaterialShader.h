/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIALSHADER_H_
#define _RENG_MATERIALSHADER_H_

#include "REng/Prerequisites.h"

// Material shader holds "uniform" render properties.
#include "REng/GPU/RenderProperty.h"
// is a GPUTexture
#include "REng/GPU/GPUShader.h"

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

namespace REng{

	/*!
	 *  \brief Material shaders are named GLSL shaders and can hold uniform state defaults 
	 *         associated with that shader.
	 *  \author Adil Yalcin
	 */
	class RENGAPI MaterialShader : public REng::GPUShader {

	public:
		~MaterialShader();

		//! @note You cannot set source file name after material shader is compiled.
		void setSourceFileName(const std::string& name);

		//! The shader will use the given text as source when you compile it, 
		//! instead of reading from a file.
		//! @note You cannot set source file name after material shader is compiled.
		void setSourceText(const std::string& text);

		//! @note You cannot set source file name after material shader is compiled.
		//! @note If the given version is not supported, has no effect
		void setShaderVersion(ShaderVersion _ver);

		//! @return True if source text will be/is used on compile time, false otherwise
		bool isSourceText() const;

		//! @return material shader name
		const std::string& getName() const;

		//! @return Shader version
		ShaderVersion getShaderVersion() const;

		//! @return source file name
		const std::string& getSourceFileName() const;

		//! @return true if this material shader is successfully compiled, false otherwise
		bool isCompiled() const;

		//! @return true on successful compilation, false otherwise
		/*! This method only compiles the source file. 
		 *  It does not bind uniforms / check for render state validity / etc.
		 *  If already compiled, returns true ( performs no further action )
		 */
		bool compile();

		/****************************/
		/* UNIFORM DEFAULT HANDLING */
		/****************************/

		//! @brief adds a default uniform state
		void addUniformDefault(RenderProp_Uniform* prop);

		//! @brief removes all uniform state defaults
		void clearUniformDefaults();

		//! @brief removes a uniform at a specific index
		void removeUniformDefault(size_t index);

		//! @return the number of default uniform states defined for this material shader
		size_t getUniformDefaultCount() const;
		
		//! @return the (const) uniform defaults list
		const UniformPropertyList& getUniformDefaults() const;

		//! @param index must be a valid index [0,uniformDefaultCount]
		//! @return the uniform data 
		RenderProp_Uniform* getUniformDefault(size_t index);

		//! @brief searches the uniform with the given name.
		//! @param uniformName the name of GLSL uniform
		//! @return If search is successful, the uniform data. Else, 0
		RenderProp_Uniform* getUniformDefault(const std::string& uniformName);

		/**************************/
		/* PRE-PROCESSOR HANDLING */

		//! @brief Adds a new preprocessor define using the given string
		void addPreprocDef(const std::string& name);
		//! @brief Adds a new preprocessor un-define using the given string
		void addPreprocUndef(const std::string& name);
		//! @brief Adds a new preprocessor set (define with a value) using the given string and value
		void addPreprocSet(const std::string& name, const std::string& _val);

		/**************************/
		/* PRE-TEXT HANDLING      */

		//! The given text will be inserted at the beginning of every shader that gets compiled
		//! after you call this method
		static void addPreText(const char* text);

	private:

		//! @brief each material shader has a unique name. 
		/*! Uniqueness is provided by MaterialManager. */
		std::string mName;

		//! @brief after successful compilation, locks the filename of the shader
		bool mIsCompiled;

		//! @brief The GLSL version that this shader is / will be compiled with
		ShaderVersion mShaderVersion;

		//! @brief If true, mSourceFileOrText stores the text source, else stores the filename
		bool mSourceIsText;

		//! @brief The name of the will be / is used as the shader source on compile time.
		std::string mSourceFileOrText;

		//! @brief Stores the preprocessor defines that will be used on shader compile time.
		//!        Each element holds a valid GLSL define/un-define command.
		std::vector<std::string> mPreprocDefines;

		/*! @brief This is aimed to store the default data only, not to manage shader bindings directly. 
		    The program the listed uniforms are bound to change in each bindUniformDefaults call. */
		UniformPropertyList mUniformDefaults;

		//! The predefined text is added to the start of every shader text
		static std::vector<std::string> mPreTextList;

		//! only material system can create material shaders
		MaterialShader(const std::string& name, ShaderType shaderType);

		friend class MaterialManager;
	};

	typedef boost::shared_ptr<MaterialShader> MaterialShaderPtr;

} // namespace REng

#endif // _RENG_MATERIALSHADER_H_
