/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIALMANAGER_H_
#define _RENG_MATERIALMANAGER_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include "REng/Singleton.h"

#include "REng/Material/MaterialProgram.h"
#include "REng/Material/MaterialShader.h"
#include "REng/Material/MaterialTexture.h"
#include "REng/Material/Material.h"

#include <string>
#include <map>
#include <boost/shared_ptr.hpp>

namespace REng{

	/*!
	 *  \class MaterialManager
	 *  \author Adil Yalcin
	 *  \brief MaterialManager is responsible from:
	 *         - creating/defining material structures
	 *         - retrieving created structures using unique name indexing
	 *         - loading /completing material resources from definitions
	 **/
	class RENGAPI MaterialManager : public Singleton<MaterialManager> {
	public:
		typedef std::map<std::string, MaterialPtr>        MaterialList;
		typedef std::map<std::string, MaterialShaderPtr>  MaterialShaderList;
		typedef std::map<std::string, MaterialTexturePtr> MaterialTextureList;
		typedef std::map<std::string, MaterialProgramPtr> MaterialProgramList;
		typedef std::map<std::string, GPUSamplerPtr>      SamplerList;

	public:
		MaterialManager(void);
		~MaterialManager(void);

		static MaterialManager& getSingleton(void);
		static MaterialManager* getSingletonPtr(void);

		//! @brief Returns the number of materials that have been defined
		size_t getMaterialCount() const;

		//! @brief Returns the number of material shaders that have been defined
		size_t getMaterialShaderCount() const;

		//! @brief Returns the number of material textures that have been defined
		size_t getMaterialTextureCount() const;

		//! @brief Returns the number of material textures that have been defined
		size_t getMaterialProgramCount() const;

		/*! @brief The method which creates Material objects.
		 *  @param name The name(string index) of the material. Must be unique for each material
		 *  @param material This parameter is updated to point to the material with given name
		 *  @return true when the material is created. false when the material with the same name existed.
		 *  @note Material is updated to the material with given name in all cases */
		bool createMaterial(const std::string& name, MaterialPtr& material);

		/*! @brief The method which creates Material Shader objects.
		 *  @param name The name(string index) of the material shader. Must be unique for each material
		 *  @param materialShader This parameter is updated to point to the material shader with given name
		 *  @return true when the material shader is created. false when the material with the same name existed.
		 *  @note Material shader is updated to the material with given name in all cases
		 */
		bool createMaterialShader(const std::string& name, ShaderType type, MaterialShaderPtr& materialShader);

		/*! @brief The method which creates Material Texture objects.
		 *  @param name The name(string index) of the material texture. Must be unique for each material
		 *  @param materialtexture This parameter is updated to point to the material texture with given name
		 *  @return true when the material texture is created. false when the material with the same name existed.
		 *  @note Material texture is updated to the material with given name in all cases
		 */
		bool createMaterialTexture(const std::string& name, TextureType type, MaterialTexturePtr& materialtexture);

		/*! @brief The method which creates Material Program objects.
		 *  @param name The name(string index) of the material program. Must be unique for each material
		 *  @param materialProgram This parameter is updated to point to the material program with given name
		 *  @return true when the material program is created. false when the material with the same name existed.
		 *  @note Material program is updated to the material with given name in all cases
		 */
		bool createMaterialProgram(const std::string& name, MaterialProgramPtr& materialProgram);

		bool createSampler(const std::string& name, GPUSamplerPtr& sampler);

		//! @brief Access a material with given name
		//! @param name : the name(string index) of the material. Must be unique for each material
		//! @return If a material with the given name exists, returns a pointer to it. Else returns 0.
		MaterialPtr getMaterial(const char* name);

		//! @brief Access a material shader with given name
		//! @param name : the name(string index) of the material. Must be unique for each material
		//! @return If a material with the given name exists, returns a pointer to it. Else returns 0.
		MaterialShaderPtr getMaterialShader(const char* name);

		//! @brief Access a material texture with given name
		//! @param name : the name(string index) of the material. Must be unique for each material
		//! @return If a material with the given name exists, returns a pointer to it. Else returns 0.
		MaterialTexturePtr getMaterialTexture(const char* name);

		//! @brief Access a material texture with given name
		//! @param name : the name(string index) of the material. Must be unique for each material
		//! @return If a material with the given name exists, returns a pointer to it. Else returns 0.
		MaterialProgramPtr getMaterialProgram(const char* name);

		GPUSamplerPtr getSampler(const char* name);

		//! @brief Using material shader definitions, compiles materials from source files
		//! @return number of materials that failed to compile
		size_t compileMaterialShaders();

		//! @brief Loads (and links) all possible render passes this material has.
		//! @return The number of materials that failed to load
		//! @note  This should be called after compileMaterialShaders
		size_t loadMaterials();

		//! @brief Forces all the defined textures to be load from files, if not unloaded
		//! @note  The textures are loaded from files when they are referenced, this allows a "forced" option.
		void loadTexturesFromFiles();

	protected:

		//! @brief Stores all materials using name indexes
		MaterialList        mMaterials;

		//! @brief Stores all material shaders using name indexes
		MaterialShaderList  mMaterialShaders;

		//! @brief Stores all material textures using name indexes
		MaterialTextureList mMaterialTextures;

		//! @brief Stores all material programs using name indexes
		MaterialProgramList mMaterialPrograms;

		//! @brief Stores all material samplers using name indexes
		SamplerList mSamplers;
	};

} // namespace REng

#endif // _RENG_MATERIALMANAGER_H_ 
