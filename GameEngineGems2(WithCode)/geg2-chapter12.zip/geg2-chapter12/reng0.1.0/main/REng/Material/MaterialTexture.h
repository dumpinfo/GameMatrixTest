/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIALTEXTURE_H_
#define _RENG_MATERIALTEXTURE_H_

#include "REng/Prerequisites.h"

#include <string>
#include <vector>

#include <boost/shared_ptr.hpp>

#include "REng/GPU/GPUTexture.h"

// texture properties are stored as render properties
#include "REng/GPU/RenderProperty.h"

namespace REng{
	
	/**
	 * @brief Material Texture is a GPUTexture that is used by the material system.
	 *        It supports loading external images from files.
	 *        Since it is a GPUTexture itself, you can manage it as a GPUTexture.
	 * @author Adil Yalcin
	 */
	class RENGAPI MaterialTexture : public GPUTexture {
	public:
		~MaterialTexture();

		//! @brief The order that the cubemap faces are defined (used in filename lists)
		static const CubeMapFace cubeMapFaceOrder[];

		//! @return The name of the material texture
		const std::string& getName() const;

		//! @brief Sets the source file name at the given index
		//! @param fileName the name of the file this texture will be loaded from
		//! @param index If texture type is cube map, Index must be in range [0,5]. Else it must be 0.
		void setSourceFileName(const std::string& fileName, unsigned char index = 0);

		//! @brief Gets the source file name at the given index
		//! @param index If texture type is cube map, Index should be in range [0,5]. Else it should be 0.
		//! @return If index is invalid, returns the name at 0th index.
		const std::string& getSourceFileName(unsigned char index = 0);

		/*! @brief Using mSourceFileNames, reads image data and loads the data to hardware.
		 *  @return False <== If type is cubemap and at least one file source is empty.
		 *          False <== If type is 2D/3D and first file name is empty
		 * 
		 *  @note Loads the texture images to 0th layer, if generate mipmap flag is on, 
		 *        generates mipmaps from base textures if format is applicable.
		 *  
		 *  @note It uses DevIL to load images currently. */
		bool loadFromFilesToResource();

	private:
		//! @brief each material texture has a unique name.  Cannot modify after object is created.
		/*! Uniqueness is provided by MaterialManager.*/
		std::string mName;

		//! @brief The name of the will be / is used as the shader source on compile time.
		//! @note if texture type is CubeMap, this must store 6 valid file names, else 1 file name at index 0.
		std::string mSourceFileNames[6];

		//! @brief If true, the material texture will load data using mSourceFileNames.
		//! @note This is true when source file names are updated
		bool mRequestLoadFromFile;

		//! @note Only MaterialManager can create texture resources
		MaterialTexture(const std::string& name, TextureType type);

		friend class MaterialManager;
	};

	typedef boost::shared_ptr<MaterialTexture> MaterialTexturePtr;

} // namespace REng

#endif // _RENG_MATERIALTEXTURE_H_
