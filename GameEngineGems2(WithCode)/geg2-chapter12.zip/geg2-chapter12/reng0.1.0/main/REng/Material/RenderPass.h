/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_RENDERPASS_H_
#define _RENG_RENDERPASS_H_

#include <string>
#include <vector>

#include "REng/GPU/RenderProperty.h"
#include "REng/Material/MaterialTexture.h"
#include "REng/Material/MaterialShader.h"
#include "REng/Material/MaterialProgram.h"

namespace REng{
	
	/*!
	 *  \class RenderPass
	 *  \brief RenderPass is a combination of vertex shader & fragment shader & render state combination.
	 *         A render pass is only used by a single technique.
	 *  \author Adil Yalcin
	 *  \version 1.0
	 *
	 *   It is advised that you define your active render states using this structure.
	 */
	class RENGAPI RenderPass {
	public:
		~RenderPass(void);

		//! @return The owner technique of the pass
		//! @note A render pass always has an owner technique
		Technique& getOwnerTechnique();
		
		//! @return The pass index of this render pass within its owner technique
		uchar getIndex() const;

		//! Sets the render program to given shared program
		//! @note Clears the program reference name
		void setProgram(MaterialProgramPtr prog);

		//! Sets the render program name to be resolved later
		//! @note If a valid render program is assigned, it is de-assigned
		void setProgramName(const std::string& progName);

		//! @return The program used in this pass (may be null / not linked/ etc)
		MaterialProgramPtr getProgram();

		//! Clones this render pass data to the given pass.
		//! @note The cloned render pass DOES NOT SHARE the same shaders and render program, even if available
		//! @note The cloned data is:
		//! - Vertex and fragment shader names
		//! - Render property lists (uniforms and generics)
		//! - Texture bindings
		void clone(RenderPass& _to) const;

		/************************/
		/* GENERIC PROPERTIES   */
		/************************/

		//! @brief adds the given render property (if property is previously defined, updates it render data)
		//! @param prop Property to be added. If 0, nothing is added.
		//! @return True iff the given parameters updated pass render state
		void addGenericProperty(RenderProp_Generic* prop);

		//! @brief removes all generic properties
		void clearGenericProperties();

		/************************/
		/* UNIFORM PROPERTIES   */
		/************************/

		//! @brief The given render property will be activated in each pass activation
		//! @note If a uniform property with same uniform name is already defined, old data is updated.
		void addUniformDefault(RenderProp_Uniform* prop);
		
		//! @brief The uniform defaults 
		void clearUniformDefaults();

		//! @brief removes the uniform property with the given name
		//! @param uniformName The name of the uniform to be removed
		void removeUniformDefault(const std::string& uniformName);

		//! @returns The count of uniform properties this render pass have
		size_t getUniformDefaultsCount() const;

		//! @returns The uniform property with the given name (0 if name not found)
		RenderProp_Uniform* getUniformProperty(const std::string& uniformName);

		//! @brief the pre-render stage to activate this render pass
		void prepareState();

		//! the post-render stage to deactivate this render pass -> only rolls back to default states, if 
		//!  any of them is modified
		void clearState();

		//! @return True if render program is successfully loaded
		bool isLoaded();

		//! @return True on successful shader binding & program loading & binding uniform uniform.
		//! possible error cases: 
		//! - material shader names are not set
		//! - material shader names are not found / shaders not loaded
		bool load();

		//! @note If a texture was already assigned to texUnitID, previous texture binding is updated
		//! @return True on success
		bool setTextureBinding(uchar texUnitID, MaterialTexturePtr matTexturePtr);

		//! @brief Fills in the texture name only (does not search for material texture inside the material system)
		//! @return True on success
		//! @remark You need to call RenderPass::load to be able to link to actual HWTexture
		bool setTextureBinding(uchar texUnitID, const std::string& matTextureName);

		//! @brief Fills in the sampler for the given texture unit
		//! @return True on success
		bool setSamplerState(uchar texUnitID, GPUSamplerPtr sampler);

		//! @brief Fills in the sampler for the given texture unit
		//! @return True on success
		bool setSamplerState(uchar texUnitID, const std::string& samplerName);

		//! @brief  Fills in material texture references using material texture names (if reference is not set)
		//! @return Number of textures that cannot be bound to render pass
		uchar loadTextureBindings();

	private:
		//! pointer to owner technique (not the owner, do not delete it)
		Technique* mOwnerTechnique;

		//! the render index of this pass in its ownerTechnique
		uchar mIndex;

		//! True if render program is successfully linked. 
		//! You cannot change shader names when Render Pass is locked.
		bool mLoaded;

		/******************/
		/* RENDER PROGRAM */
		/******************/

		//! @brief The rendering program used by this pass
		//! @note Can be shared between different passes!
		MaterialProgramPtr mProgram;
		//! The name of the material program to be resolved when this render pass is loading.
		std::string mProgramName;

		//! If true, the program is updated by the lighting system
		bool mUsesLights;

		/******************/
		/* UNIFORM STATES */
		/******************/
		
		//! The default uniform data to be used in this render pass
		//! @note These are synched on every frame, so can override shader/program default uniforms.
		UniformPropertyList mUniformDefaults;
		//! @brief The uniforms properties that has no default, created for easy access to any program uniform,
		//!        thus, both lists are separated and together define complete uniform information 
		//!        of a linked GPUProgram.
		//! @note  The uniforms in this list are synched only if they are dirty, checked every prepare()
		UniformPropertyList mUniformNondefaults;

		//! The uniforms in the default list may update uniforms that are assumed "default" by
		//! lower level and shared programs/shaders. To unroll back to those uniforms, we have
		//! to keep track of them and re-synch those defaults back so that other materials / renderpasses
		//! are unaffected
		UniformPropertyList mUniformDefaultRollBacks;

		//! @brief binds the unbound uniforms to the render pass program
		//! @return Number of unbounded uniforms
		size_t bindUniformsToProgram();
		//! @binds the specific uniform given to the active program
		bool bindUniformToProgram(RenderProp_Uniform* uni);

		//! @return True if a default uniform with the given name exists
		bool isADefaultUniform(const std::string& uniformName);

		//! @return The total number of uniforms, including those with default values and those with no defaults
		size_t getUniformTotalCount() const;

		//! @note Called on every prepare()
		void synchDefaultUniforms();
		//! @brief Synchronizes the non-default and dirty uniform data
		void synchDirtyUniforms();

		//! Deletes all non-default uniforms assigned from 
		void clearUniformNonDefaults();
		//! Deletes all default rollback uniforms assigned from 
		void clearUniformDefaultRollBacks();
		//! @brief removes the uniform property with the given name
		//! @param uniformName The name of the uniform to be removed
		void removeUniformNonDefault(const std::string& uniformName);

		//! Copies the uniform data from the given uniform to the non-default uniform list
		void copydataToNondefaultUniform(const RenderProp_Uniform* uni);

		//! @brief Reads the active uniforms from the program object and 
		//!        updates the defaults as set by vertex or fragment material shaders.
		void updateUniformData();

		/*****************************/
		/* GENERIC RENDER PROPERTIES */
		/*****************************/

		//! @note Some render states may exist more than once (if their some data is different (ex: face for stencil op)
		RenderPropGenericList mRenderProperties;

		/********************/
		/* TEXTURE BINDINGS */
		/********************/

		struct STexturePassBinding{
			uchar texUnitID;
			std::string textureName;
			MaterialTexturePtr materialTexture;
			GPUSamplerPtr sampler;
			std::string samplerName;
		};

		//! @brief It stores a texture unit, material texture, texture name tuples.
		//!        No two elements can have the same texture unit ID's
		std::vector<STexturePassBinding> mTextureBindings;

		/**************/
		/* OTHER STUFF */
		/***************/

		//! RenderPass can only be create by Technique
		RenderPass(Technique* ownerTechnique, uchar index);

		//! index may be updated after pass is created (basically, result of removal of a previous render pass)
		void setIndex(uchar index);

		friend class Technique;

	};

} // namespace REng

#endif // _RENG_RENDERPASS_H_
