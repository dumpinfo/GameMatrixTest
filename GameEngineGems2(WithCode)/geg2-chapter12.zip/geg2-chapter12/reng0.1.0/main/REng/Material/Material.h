/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MATERIAL_H_
#define _RENG_MATERIAL_H_

#include "REng/Prerequisites.h"
//! Material is a LoD'ed technique
#include "REng/Material/Technique.h"
#include "REng/LoD.h"

#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

namespace REng{

	/*!
	 *  \author Adil Yalcin
	 *
	 *  \brief A material is a collection of rendering techniques.
	 *         You can define number of views and number of LoD levels for each view separately and assign
	 *         a rendering technique respectively.
    *
	 * A 6-view material with 3 techniques can be defined simply as the following:
	 * - T0 : technique { viewIndex 0 lodIndex 0  ... }
	 * - T1 : technique { viewIndex 0 lodIndex 2  ... }
	 * - T2 : technique { viewIndex 3 lodIndex 0  ... }
	 *
	 * The configurations that the techniques will be active are:
	 * T0 -> all configurations where 0<=viewIndex<3 and 0<=lodIndex<2
	 * T1 -> all configurations where 0<=viewIndex<3 and 2<=lodIndex
	 * T2 -> all configurations where 3<=viewIndex (since single LoD level is defined, this is used for all requested lod levels)
	 *
	 * If technique does not define viewNo or lodIndex, they are assumed 0. (the default settings are 0)
	 *
	 * If multiple techniques define the same viewIndex and lodIndex, only the first one is processed and used
	 */

	class RENGAPI Material : public LoD<Technique> {

	public:
		~Material(void);

		//! @return The name of the material
		const std::string& getName() const;

		//! @brief A valid material should be composed of valid rendering techniques.
		//! Validity: INVALID : If the material does not defines any rendering technique at view 0, LoD 0.
		//!           INVALID : Any of the techniques is invalid
		//! @return Validity Info
		//! @note: You should call this function after you finish creating / deleting techniques
		bool isValid(void) const;

		//! @brief Loads all techniques this material holds. 
		//! @return The number of techniques that failed to load.
		//! @see Technique::load
		size_t load();

		/*! @brief The method which clones a material definition from one material to another
		 *  @param _to   The pointer to material, which is to be updated.
		 *  @param loadMaterial If true, loads the material after it is cloned
		 *  @note Material is updated to the material with given name in all cases */
		void clone(Material& _to, bool loadMaterial=false) const;

	private:
		//! each material has a unique name. Uniqueness is provided by MaterialManager.
		std::string mName;

		//! A technique is constructed by supplying this material
		Technique* constructLoDData();

		Material(const std::string& name);

		//! disable copy constructor
		Material(Material&);

		//! disable assignment operator
		Material&	operator=(Material&);

		friend class MaterialManager;
	};

	typedef boost::shared_ptr<Material> MaterialPtr;

} // namespace REng

#endif // _RENG_MATERIAL_H_
