/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_STATSCOUNTER_H_
#define _RENG_STATSCOUNTER_H_

#include "REng/Prerequisites.h"

// is a singleton
#include "REng/Singleton.h"

namespace REng{

	/*!
	 * @brief A helper for basic rendering statistics
	 *        All statistics are managed in per second basis.
	 * @author Adil Yalcin
	 */
	class RENGAPI StatsCounter : public Singleton<StatsCounter> {
	public:
		StatsCounter();
		~StatsCounter();

		static StatsCounter& getSingleton(void);
		static StatsCounter* getSingletonPtr(void);

		//! @return The number of frames processed in the last second
		size_t getFrameRate() const;

		//! @return The number of faces processed in the last second
		size_t getFaceCount() const;
		
		//! @return The number of vertices processed in the last second
		size_t getVertexCount() const;

		//! @return The number of draw calls in the last second
		size_t getDrawCallCount() const;

	protected:
		//! @brief Sets all accumulators to zero
		//! @remark You need to call this one per second
		void clearStats();

		//! @brief Increments draw call count (+1)
		void incDrawCall();

		//! @brief Increments frame accumulator (+1)
		void incFrameRate();

		void addFaceCount(size_t count);
		void addVertexCount(size_t count);

	private:
		struct AStat{
			//! @brief Stores the current (accumulated) statistics
			size_t accum;
			//! @brief Stores the accumulated value in the last second
			size_t perSec;
		};

		//! Frame per second statistics
		AStat mFrame_Cur;
		//! NOT USED CURRENTLY
		AStat mFrame_Best;
		//! NOT USED CURRENTLY
		AStat mFrame_Worst;

		//! Number of triangle faces processed per second
		AStat mFaceCountStat;

		//! Number of vertices processed in a second
		AStat mVertexCountStat;

		//! NOT USED CURRENTLY - related to multiple rendering iterations
		AStat mBatchCountStat; 

		//! Number of draw calls
		AStat mDrawCall;

		friend class GPUDrawer;
		friend class RenderSystem;
	};

} // namespace REng

#endif // _RENG_STATSCOUNTER_H_
