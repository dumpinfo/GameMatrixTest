/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_UTIL_H_
#define _RENG_UTIL_H_

#include "REng/Defines.h"

namespace REng{

	/*!
	 *  @class Range
	 *  @brief Represents an integer-range in one dimension
	 *         A range is defined using a starting point and a size.
	 *  @author Adil Yalcin
	 */ 
	class RENGAPI Range{
	public:
		//! @brief Range is initialized to 0 start, 0 size.
		Range();

		//! @copydoc mStart
		size_t getStart() const;
		//! @copydoc mSize
		size_t getSize() const;

		//! @brief Sets the range, using start points and size
		//! @return True if range is updated successfully, false otherwise
		bool set(size_t start, size_t size);

		//! @brief Sets the range, using start points and end point
		//! @return True if range is updated successfully, false otherwise
		//! @remark _end is EXPECTED to be smaller then _start, this is not checked on run-time for efficiency.
		bool setLimits(size_t _start, size_t _end);

	protected:
		//! @brief Range start index
		size_t mStart;

		//! @brief The number of vertices to use from the buffer
		size_t mSize;

		//! @brief Can be overwritten to specify range limitations based on sub-class logic.
		virtual bool checkRange(size_t start, size_t size);
	};

} // namespace REng

#endif // _RENG_UTIL_H_
