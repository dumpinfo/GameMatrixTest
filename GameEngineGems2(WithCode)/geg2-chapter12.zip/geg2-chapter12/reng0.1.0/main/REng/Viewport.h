/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_VIEWPORT_H_
#define _RENG_VIEWPORT_H_

#include "REng/Prerequisites.h"

// you can register/unregister viewport listener
#include "REng/ViewportListener.h"

// you can register/unregister multi view compositors and buffers
#include "REng/MultiViewCompositor.h"
#include "REng/MultiViewBuffer.h"

#include "REng/Rect.h"
#include "REng/Color.h"

#include <memory>

namespace REng{

	/*!
	 *  @brief Viewport defines a region on a render target that will be drawn into,
	 *         so that you can draw your scene into a subset of your render target.
	 *         A viewport links a single camera to a region on a single target.
	 *         It is also the component in which multi-view rendering is set-up.
	 *  @author Adil Yalcin
	 */
	class RENGAPI Viewport {
	public:
		Viewport();

		//! The GPU target this viewport is placed on.
		//! If NULL (default), the viewport target is the default frame buffer
		GPUFrameBuffer* mRenderTarget;

		//! The camera is used as the viewpoint to the scene. If the camera is 
		//! not set, view and projection matrices cannot be updated by the render system 
		//! when rendering the viewport. 
		//! @note Multi-view rendering requires multi-view cameras to be attached to the system
		Camera *mCamera;

		//! Returns the relative position of the viewport on a render target
		//! @note The rectangle's origin is the lower left corner.
		const RectF& getRelRect() const;

		//! Returns the absolute position of the viewport on a render target
		//! @note The rectangle's origin is the lower left corner.
		const RectI& getAbsRect() const;

		//! Returns the aspect ratio of this viewport
		float getAspectRatio() const;

		//! Sets the size of the viewport in absolute coordinates
		void setAbsRect(RectI rect);

		//! Sets the size of the viewport in relative coordinates wrt render target size
		void setRelRect(RectF rect);

	private:
		//! The relative region on the render target
		RectF mRelRect;
		//! The absolute region on the render target
		RectI mAbsRect;

		//! Called when absolute rectangle is updated
		void updateFromRelToAbs();
		//! Called when relative rectangle is updated
		void updateFromAbsToRel();
		//! Called when any rectangle is updated
		void updateCameraAspectRatio();

		/************************************************************************/
		/* ViewPort Listener                                                    */
		/************************************************************************/
	public:
		//! If successful, the listener will be notified in each renderToTarget.
		//! You have to unregister a previous listener if active before.
		bool attachListener(std::auto_ptr<ViewportListener> vpListener);

		//! Active listener is detached & destroyed
		void detachListener();

		//! Returns true if the viewport has a listener
		bool isListenerActive() const;

	private:
		//! Attached external renderer object, null if none
		std::auto_ptr<ViewportListener> mListener;

		/************************************************************************/
		/* RENDERING                                                            */
		/************************************************************************/

	public:
		//! If a buffer type is set to be auto-cleared, it is cleared in the start of every
		//! render operation. Initially, depth-stencil buffers are cleared only.
		void autoClearBuffer(FrameBufferComponent bt, bool isEnabled);

		//! Sets the color that will be used to clear the viewport color
		//! @note Default value : black
		void autoClearColor(Color_Real color);

		//! Sets the depth value that will be used to clear viewport depth
		//! @note Automatically clamped to 0-1 range
		//! @note Default value : 1.0
		void autoClearDepth(float depthVal);

		//! Sets the stencil value that will be used to clear viewport depth
		//! @note The given value is masked with 2^m-1, where mis the number of bits in the stencil buffer.
		//! @note Default value: 0
		void autoClearStencil(uint stencilVal);

		//! Processing a queue with some ID can be enabled/ disabled per viewport.
		//! This function allows retrieving queue process state.
		//! @note Used by the render system on processRenderQueues call
		bool isRenderQueueEnabled(uchar queueid);

		//! Disables processing of a queue with a specific ID while rendering this viewport 
		void disableRenderQueue(uchar queueid);

		//! Disables processing of queue withs ID's less than given ID while rendering this viewport
		void disableRenderQueues_LessThan(uchar queueid);

		//! If true, renderToTarget will return without calling any functions.
		//! @note Use this flag to prevent re-drawing of certain regions on a render target.
		bool mDisableRendering;

		//! Updates the render data on the the target region using the camera specified
		bool renderToTarget();

	private:
		//! The buffers to be cleared on renderToTarget() time
		uint mClearFrameBuffers;

		//! The color that will be used to clear the viewport color
		Color_Real mClearColor;
		//! The value that will be used to clear the viewport depth
		float mClearDepth;
		//! The value that will be used to clear the viewport stencil
		uint mClearStencil;

		void clearBuffers();

		//! Renders queues for a single view
		void renderSingleView();
		//! Renders queues for multiple views
		//! @note Make sure you can render in multi-view before calling this method
		void renderMultiView();

		void mergeViews();

		//! Processes a single view (notifies listener, clears buffers, processes render queues)
		void processView();

		//! Renders a single multi view
		void renderActiveMultiView();

		//! @note Is subject to change...
		std::vector<uchar> mDisabledQueueIDs;
		//! @note Is subject to change...
		uchar mDisabledQueuesLessThan;

		/************************************************************************/
		/* MULTI-VIEW (MV) MANAGEMENT                                           */
		/************************************************************************/
		// Note: Camera is a more generic type, and has no specific attach/detach routines
	public:

		//! Attaches a given multi-view compositor to this viewport.
		//! @note You have to unregister a previous compositor if active before.
		//! @note The ownership of compositor is transfered to Viewport, so 
		//!       you can no longer use the pointer after calling this function
		//! @return False, if cannot initialize the multi-view compositor with given parameters
		bool attachMVCompositor(MultiViewCompositor* mvc);

		//! Attaches a given multi-view buffer to this viewport.
		//! @param params The configuration parameters that will be used to init the MVBuffer
		//! @note You have to unregister a previous buffer if active before.
		//! @note The ownership of compositor is transfered to Viewport, so 
		//!       you can no longer use the pointer after calling this function
		//! @return False, if cannot initialize the multi-view buffer with given parameters
		bool attachMVBuffer(MultiViewBuffer* mvb, MVBuffer_Cfg params);

		//! Retrieves the currently attached MV compositor, 0 if none.
		MultiViewCompositor* getMVCompositor();

		//! Retrieves the currently attached MV buffer, 0 if none.
		MultiViewBuffer* getMVBuffer();

		//! Active MVC is detached.
		void detachMVCompositor();
		//! Active MVB is detached.
		void detachMVBuffer();

		//! @return True if the viewport renders in multi-view mode
		bool isMVActive() const;

		//! @return The multi-view count when multi-view is active, 1 otherwise
		uchar getViewCount() const;

		//! @return The active view no (0 if multi-view is not active)
		uchar getActiveViewNo() const;

		//! Activates MVBuffer and MVCamera views to given viewID.
		//! @note Called by the render system to active a specific view 
		//!       when object-first rendering is active
		void activateView(uchar viewID);

		//! If true, multi-view rendering is disabled even if correct multi-view configuration has been done
		//! The 0th view is used to render the viewport when disabled.
		//! @remark False by default
		bool mDisableMultiView;

		//! If multi-view rendering is disabled, this view is used to render the output
		uchar mSingleViewPref;

		//! If true, each specific view is processed only once and the scene is rendered
		//! If false, each mesh is processed only once and the views are switched
		//! @note Default: True
		//! @todo The "false" option is not implemented yet!
		const bool mViewFirstRendering;

	private:
		//! Attached multi view compositor object, null if none 
		MultiViewCompositor* mMVCompositor;
		//! Attached multi view buffer object, null if none 
		MultiViewBuffer* mMVBuffer;
		//! The active view no, always 0 if multi-view is not active
		uchar mActiveViewNo;
		//! To check whether viewport is ready for render update
		bool isRenderReady();
	};
	
} // namespace REng

#endif // _RENG_VIEWPORT_H_
