/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENDERING_ENGINE_
#define _RENDERING_ENGINE_

#include "Defines.h"

#include "RenderSystem.h"

#include "Camera.h"
#include "Color.h"
#include "Light.h"
#include "LightingManager.h"
#include "Node.h"
#include "RenderMatrixManager.h"
#include "StatsCounter.h"
#include "RenderQueue.h"
#include "Viewport.h"
#include "ViewportListener.h"

/************************************************************************/
/* GEOM                                                                 */
/************************************************************************/
#include "Geom/Geom.h"
#include "GeomRenderer.h"

/************************************************************************/
/* GPU                                                                  */
/************************************************************************/
#include "GPU/GPUDrawer.h"
#include "GPU/GPUBuffer.h"
#include "GPU/GPUConfig.h"
#include "GPU/GPUFrameBuffer.h"
#include "GPU/GPUProgram.h"
#include "GPU/GPUQuery.h"
#include "GPU/GPUSampler.h"
#include "GPU/GPURenderBuffer.h"
#include "GPU/GPUShader.h"
#include "GPU/GPUTexture.h"
#include "GPU/GPUUniform.h"
#include "GPU/RenderProperty.h"
#include "GPU/RenderTarget.h"

/************************************************************************/
/* MATERIAL                                                             */
/************************************************************************/
#include "Material/Material.h"
#include "Material/MaterialManager.h"
#include "Material/MaterialScriptParser.h"
#include "Material/MaterialShader.h"
#include "Material/MaterialTexture.h"
#include "Material/RenderPass.h"
#include "Material/Technique.h"

/************************************************************************/
/* MESH                                                                 */
/************************************************************************/
#include "Mesh.h"
#include "MeshGeomGenerator.h"
#include "MeshManager.h"
#include "MeshGeomGenerator.h"
#include "VertexIndexData.h"
#include "VertexAttrib.h"

/************************************************************************/
/* SYSTEM-ABSTRACTIONS                                                  */
/************************************************************************/
#include "sys/GLContext.h"
#include "sys/OSWindow.h"

/************************************************************************/
/* MULTIVIEW                                                            */
/************************************************************************/
#include "MultiViewCamera.h"
#include "MultiViewCompositor.h"

/************************************************************************/
/* UTIL                                                                 */
/************************************************************************/
#include "Angle.h"
#include "Interp.h"
#include "Math.h"
#include "Rect.h"
#include "ScreenCapturer.h"
#include "Timer.h"
#include "Util.h"



#endif

