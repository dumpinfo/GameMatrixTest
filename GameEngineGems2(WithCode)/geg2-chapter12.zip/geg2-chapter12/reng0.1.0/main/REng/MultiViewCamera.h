/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MULTIVIEW_CAMERA_H_
#define _RENG_MULTIVIEW_CAMERA_H_

#include "REng/Prerequisites.h"

#include "REng/Camera.h"

namespace REng {

	/*!
	 * @brief 
	 * - A multi-view (n-view) camera represents "n" cameras which are attached to the same node.
	 *
	 * - It is an abstract class, so you cannot instantiate it. You have to use specialized cameras,
	 *   either pre-defined or defined by you own inherited classes.
	 * - The number of views a multi-view camera includes is defined on instantiation and it 
	 *   cannot be changed afterwards. Use getViewCount to learn a multi-view camera's supported view count.
	 * - One of the sub-camera (view) of the camera is activate at a time. 
	 * - The active view is used to automatically calculate correct projection and view matrices
	 *   corresponding to view configuration.
	 *
	 * @author Adil Yalcin
	 */
	class RENGAPI CameraMultiView : public CameraPerspective {
	public:
		//! @brief Sets the active camera view no
		//! @param viewIndex Must be between 0 and ViewCount. If not, defaults to View No 0.
		void setActiveView(uchar viewIndex);

	protected:
		//! Creates a multi-view -perspective camera attached to the given node and 
		//! storing viewCount sub-cameras
		CameraMultiView(CameraNode& node);

	protected:
		//! @brief The active view that will be used for rendering.
		uchar mActiveView;
	};

	/*!
	 * @brief A multi-view camera with two views (0->left view, 1->right view).
	 * @remark Applies perspective correction in left-right projection
	 * @remark Uses 2 additional parameters: Eye separation and focal distance.
	 * @author Adil Yalcin
	 */
	class CameraStereoView : public CameraMultiView {
	public:
		//! Possible types of stereo camera management
		enum StereoType{
			TypeParallel,
			TypeOriented,
			TypeSkewed
		};

		//! @brief Creates a stereo-view camera attached to the given node
		//! Focal distance is set to 1, eye separation is set to 0.1
		static CameraStereoView& create(CameraNode& node);

		//! @return Two
		uchar getViewCount() const;

		//! @brief Sets the focal distance of the camera array.
		void setFocalDistance(float distance);
		//! @brief Sets the eye separation between two views. @see mEyeSeparation
		void setEyeSeparation(float distance);

		//! @brief Gets the focal distance of the camera array
		float getFocalDistance() const;
		//! @brief Gets the eye separation of the camera array. @see mEyeSeparatio
		float getEyeSeparation() const;

		//! @brief The basic view matrix is translated to match eye position
		const Matrix4& getViewMatrix() const;

		//! @brief If true, perspective correction is applied, an asymmetric projection is produced.
		//! If false, no perspective correction is applied, a regular symmetric projection is produced.
		//! Default: True
		void setStereoType(StereoType _type);
		StereoType getStereoType() const;

		//! @copydoc Camera::generateRay_WS
		//! @remark Assumes the two-cameras are instead a single perspective camera.
		void generateRay_WS(float widthRatio, float heightRatio, GeomRay& pickRay);

	protected:
		CameraStereoView(CameraNode& node);

		enum {
			LeftView = 0,
			RightView = 1
		};
		
		//! @brief The focus distance is the distance between the focus point and camera scene node position.
		float mFocalDistance;

		//! @brief Eyes are separated along camera right-axis in the length specified by this member.
		//! @remark Denotes the total distance between sub-views.
		//! @remark If you want to sound cooler, call it "intraocular distance".
		//! @remark If you want, you can also call this "offset"
		float mEyeSeparation;

		StereoType mType;

		//! @brief The active view matrix
		mutable Matrix4 mActiveViewMatrix;
		
		//! @brief Updates the projection matrix to store asymmetric projection
		//!        using the current active view (left-right)
		void updateProjectionMatrix() const;
		
		void updateFrustum() const;

		Vector3 getLeftViewPosOffset() const;
		Vector3 getRightViewPosOffset() const;

		Vector3 getLeftViewPos() const;
		Vector3 getRightViewPos() const;
	};

} // namespace REng

#endif // _RENG_MULTIVIEW_CAMERA_H_

