/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_PREREQUISITES_H_
#define _RENG_PREREQUISITES_H_

#include "REng/Platform.h"

#include <cml/cml.h>

#include <assert.h>

#include <cstdlib>
#include <cstring>
#include <cstdio>

namespace REng {

	typedef unsigned int uint;
	typedef unsigned short ushort;
	typedef unsigned long ulong;
	typedef unsigned char uchar;

	// 64 bit signed and unsigned integer variants 
	// @note Platform checking code from glew library

	#if RENG_PLATFORM == RENG_PLATFORM_OMAP
	// 64-bit types are not supported, they fall back to default integer precision
		typedef int int64;
		typedef unsigned int uint64;
	#else
	#if defined(_MSC_VER)
	#	if _MSC_VER < 1400
		typedef __int64 int64;
		typedef unsigned __int64 uint64;
	#	else
		typedef signed long long int64;
		typedef unsigned long long uint64;
	#	endif
	#else
	#  if defined(__MINGW32__) || defined(__CYGWIN__)
	#		include <inttypes.h>
	#  endif
		typedef int64_t int64;
		typedef uint64_t uint64;
	#endif
	#endif

	typedef cml::matrix44f_c Matrix4;
	typedef cml::matrix33f_c Matrix3;
	typedef cml::vector2f Vector2;
	typedef cml::vector3f Vector3;
	typedef cml::vector4f Vector4;
	typedef cml::quaternionf_n Quaternion;

	//////////////////////////////////////////////////////////////////////////
	// FORWARD DECLERATIONS WITHIN RENG LIBRARY

	/*** GPU ******/
	class SWBuffer;
	class VertexBuffer;
	class IndexBuffer;
	class SWVertexBuffer;
	class SWIndexBuffer;
	class GPUBuffer;
	class GPUVertexBuffer;
	class GPUIndexBuffer;
	class GPUConfig;
	class GPUDrawer;
	class GPUFrameBuffer;
	class GPUProgram;
	class GPUQuery;
	class GPUQueryPrim;
	class GPUQueryPrimGenerated;
	class GPUQueryPrimTransFB;
	class GPUQueryOcclusion;
	class GPUQueryTimer;
	class GPUSampler;
	class GPUResource;
	class GPURenderBuffer;
	class GPUShader;
	class GPUStructure;
	class GPUTexture;
	class GPUUniform;
	class RenderTarget;
	class RenderTarget_Window;
	class RenderProp;
	class RenderProp_Generic;
	class RenderProp_Uniform;
	class RenderProp_BlendEq;
	class RenderProp_BlendFunc;
	class RenderProp_StencilFunc;
	class RenderProp_StencilMask;
	class RenderProp_StencilOp;
	class RenderProp_DepthFunc; 
	class RenderProp_DepthMask;
	class RenderProp_ColorMask;
	class RenderProp_FrontFace;
	class RenderProp_CullFace;
	class RenderProp_LineWidth;
	class RenderProp_PolyMode;
	class RenderProp_DepthTest;
	class RenderProp_Blending;
	class RenderProp_StencilTest;
	class SamplerProp;
	class SamplerProp_MinFilter;
	class SamplerProp_MagFilter;
	class SamplerProp_WrapMode;

	/*** Material ******/
	class Material;
	class MaterialManager;
	class MaterialProgram;
	class MaterialShader;
	class MaterialTexture;
	class MaterialScriptParser;
	class RenderPass;
	class Technique;

	/*** Node ******/
	class SceneNode;
	class GroupNode;
	class RootNode;
	class SwitchGroupNode;
	class LODGroupNode;
	class MeshNode;
	class CameraNode;
	class LightNode;

	/*** Mesh ******/
	class VertexData;
	class IndexData;
	class VertexAttribute;
	class Mesh;
	class MeshManager;
	class MeshGeom;
	class MeshGeomGenerator;

	/*** MultiView ******/
	class Camera;
	class CameraPerspective;
	class CameraOrthogonal;
	class CameraMultiView;
	class CameraStereoView;
	class MultiViewCompositor;
	class MultiViewBuffer;

	/*** Geoms ******/
	class GeomVolume;

	/*** Lighting ******/
	class Light_Base;
	class Light_Sun;
	class Light_Point;
	class Light_Spot;
	class LightRegistry;
	class LightRegistrer;

	/*** Generic ******/
	class RenderSystem;
	class Viewport;
	class ViewportListener;
	class RenderMatrixManager;
	
	class RenderQueueMap;
	class Renderable;
	class RenderQueue;
	class RenderQueueMap;
	
	class StatsCounter;
	
	/*** UTIL ******/
	class AngleDegree;
	class AngleRadian;
	class Angle;
	class ScreenCapturer;
	class Timer;

	class OSWindow;
	class GLContext;

} // namespace REng

#endif // _RENG_PREREQUISITES_H_
