/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_VERTEXATTRIB_H_
#define _RENG_VERTEXATTRIB_H_

#include "REng/Prerequisites.h"

#include <boost/shared_ptr.hpp>
#include <list>

#include "REng/Defines.h"

namespace REng{

	/*!
	 *  @brief Provides easy per-vertex attribute definition
	 *  @author Adil Yalcin
	 */ 
	class RENGAPI VertexAttribute{
	public:
		//! @brief The constructor that associates a predefined semantic.
		//! @note  The semantic should not be set to "None". If you assign a custom semantic, use the other
		//!        constructor.
		VertexAttribute(unsigned char source, size_t offset, VertexAttribDataType dataType, 
			VertexAttribDataCount dataCount, VertexAttribSemantic semantic);

		//! @brief The constructor that associates a custom named attribute.
		VertexAttribute(unsigned char source, size_t offset, VertexAttribDataType dataType, 
			VertexAttribDataCount dataCount, const std::string& name);

		//! @brief Destructor
		~VertexAttribute();

		//! @brief Retriever for source buffer index 
		unsigned char getSourceBufferIndex(void) const;

		//! @brief Retriever for attribute offset in the buffer
		size_t getStartOffset(void) const;

		//! @brief Retriever for attribute data type
		VertexAttribDataType getDataType(void) const;

		//! @brief Retriever for attribute data count
		VertexAttribDataCount getDataCount(void) const;

		//! @brief Retriever for attribute semantic
		VertexAttribSemantic getSemantic(void) const;

		//! @brief Retriever for attribute name
		const std::string& getName() const;

		//! @brief The total size of the vertex attribute. Derived from data type and data count.
		//! @note An example: If the attribute is 4 floats, it takes 4*sizeof(float) = 16 bytes = 64 bits
		size_t getSizeInBytes(void) const;

		//! @brief Two vertex attributes are equal iff all their members are equal.
		bool operator==(const VertexAttribute& rhs) const;

		//! @brief This variable indicates that values stored in an integer format are to be 
		//!        mapped to the range [-1,1] (for signed values) or [0,1] (for unsigned values) 
		//!        when they are accessed and converted to floating point. Otherwise, values will
		//!        be converted to floats directly without normalization. TODO check & use?
		//! @note  Default value is "false"
		bool mNormalize;

		//! @see VertexAttribBatch
		VertexAttribBatch mBatchMode;

	protected:
		//! @brief The source vertex buffer, as bound to an index using VertexBufferBinding
		unsigned char mSourceBufferIndex;

		//! @brief The offset in the buffer that this element starts at
		size_t mStartOffset;

		//! @brief The type of attribute
		VertexAttribDataType mDataType;

		//! @brief The count of per-vertex data, can be 1,2,3 or 4.
		VertexAttribDataCount mDataCount;

		//! @brief The meaning of the attribute (used for handling some types automatically)
		//! @note The automated meanings are used in TODO...
		VertexAttribSemantic mSemantic;

		//! @brief The name of the attribute used in shaders.
		//! @note  Semantics can assign predefined values to this name
		std::string mName;
	};

	//! @brief A doubly-linked list implementation
	typedef RENGAPI std::list<VertexAttribute> VertexAttributeList;

} //namespace REng

#endif // _RENG_VERTEXATTRIB_H_
