/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/

#ifndef _RENG_GEOMVOLUME_H_
#define _RENG_GEOMVOLUME_H_

#include "GeomBase.h"

#include <limits>

namespace REng{

	/*!
	 *  @brief Represents a volumetric geometry in 3D space
	 *         It is assumed that every derived class is a "filled and solid" volume (for intersection and other tests).
	 *  @note  Every class must implement a getVolume() method
	 *  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomVolume : public Geom {
	public:
		//! @brief Returns the volume of the volumetric geom
		virtual float getVolume() const=0;

	protected:
		GeomVolume(const Vector3& position = Vector3(0,0,0));
	};

	/*!
	 * An infinite volume, every other geometry is inside this volume
	 * @author Adil Yalcin
	 */
	class GeomInf : public GeomVolume {
	public:
		GeomInf();
		float getVolume();
		GeomType getType() const;

		bool canRotate();
		bool canScale();
		bool canTranslate();

		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec);
	};

	inline GeomInf::GeomInf() {;}
	inline float GeomInf::getVolume() { return std::numeric_limits<float>::infinity(); }
	inline GeomType GeomInf::getType() const { return GeomTypeInf; }

	inline bool GeomInf::canRotate() { return true; }
	inline bool GeomInf::canScale()  { return true; }
	inline bool GeomInf::canTranslate()  { return true; }

	inline void GeomInf::rotate_World(const cml::quaternionf_n& qua) {;}
	inline void GeomInf::scale(const Vector3& vec) {;}
}

#endif // _RENG_GEOMVOLUME_H_
