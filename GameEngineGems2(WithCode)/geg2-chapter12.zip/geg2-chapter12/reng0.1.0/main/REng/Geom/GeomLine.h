/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMLINE_H_
#define _RENG_GEOMLINE_H_

#include "GeomBase.h"
#include "GeomPoint.h"

namespace REng{

	/*!
	 *  @brief Represents an infinite line in space.
	 *  @note  The geom position is an arbitrary/first point on the infinite line.
	 *  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomLine : public Geom {
	public:
		//! Constructs a line on the axis x
		GeomLine();
		//! @see setGeom
		GeomLine(const Vector3& p1, const Vector3& p2, bool funcType=false);

		//! @return True
		bool canRotate();
		//! @return False
		bool canScale();
		//! @return True
		bool canTranslate();
		//! @return GeomTypeLine
		GeomType getType() const;

		//! @return The direction of the line (may not be normalized)
		const Vector3& getDirection() const;

		//! @return The point on the line, assuming line position is the origin
		//! @param u The unit length from the origin (along the direction of the line)
		GeomPoint getPoint(float u) const;

		//! Normalizes the directional component
		void normalize();

		//! @brief if funcType is true, sets to line containing p1 and p2
		//!	else sets to a line from p1 and having direction p2
		void setGeom(const Vector3& p1, const Vector3& p2, bool funcType=false);

		//! Sets the position of the first point on the line
		void setPosition(const Vector3& pos);

		//! @brief if funcType is true, sets to line containing current position and p2
		//!	else sets to a line from current position and having direction p2
		void setDirection(const Vector3& p1, bool funcType=false);

		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec){};
	private:

        //! direction of the line.
		Vector3 mDirection;
	};

}

#endif // _RENG_GEOMLINE_H_
