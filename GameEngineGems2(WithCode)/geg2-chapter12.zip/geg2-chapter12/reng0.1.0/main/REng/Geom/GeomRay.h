/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMRAY_H_
#define _RENG_GEOMRAY_H_

#include "GeomBase.h"
#include "GeomPoint.h"

namespace REng{

	/*!
	 *  @brief Represents a ray in space, infinite on one end, limited on the other
	 *  @note  The geom position is used as the starting position of the line.
	 *  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomRay : public Geom {
	public:
		//! Constructs a ray from center in the direction of +x
		GeomRay();
		//! @see setGeom
		GeomRay(const Vector3& p1, const Vector3& p2, bool funcType=false);

		//! @return True
		bool canRotate();
		//! @return False
		bool canScale();
		//! @return True
		bool canTranslate();
		//! @return GeomTypeLine
		GeomType getType() const;

		//! @return The direction of the line (may not be not normalized)
		const Vector3& getDirection() const;

		//! @return The origin (starting position) of the ray 
		const GeomPoint& getOrigin() const;

		//! Normalizes the directional component
		void normalize();

		//! Reverses the direction of the ray
		void reverse();

		//! @return The point on the line, assuming line position is the origin
		//! @param u The unit length from the origin (along the direction of the line)
		//! @remark if u is negative, returns a point on the negative direction of the ray
		GeomPoint getPoint(float u) const;

		//! @brief if funcType is true, sets to ray from p1 to p2
		//!	else sets to a ray from p1 and having direction p2
		//! @note The direction is not normalized.
		void setGeom(const Vector3& p1, const Vector3& p2, bool funcType=false);

		//! Sets the position of the source point on the line
		void setPosition(const Vector3& pos);

		//! @brief if funcType is true, sets to ray from current position to p2
		//!	else sets to a ray from current position and on direction p2
		//! @note The direction is not normalized.
		void setDirection(const Vector3& p1, bool funcType=false);

		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec){ (void) vec; };
	private:

        //! direction of the ray.
		Vector3 mDirection;
	};
}

#endif // _RENG_GEOMRAY_H_
