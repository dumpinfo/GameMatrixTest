/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMCYLINDER_H_
#define _RENG_GEOMCYLINDER_H_

#include "GeomVolume.h"

namespace REng{

	/*!
	*  @brief Represents a cylinder in 3D world-space.
	*  @note  The local origin is the center of mass of the cylinder.
	*  @remark  The cylinder cannot change orientation! (since it has no orientation quaternion)
	*  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	*/
	class GeomCylinder : public GeomVolume {
	public:
		//! Constructs a cylinder with origin (0,0,0), height 1 and radius 1
		GeomCylinder();
		//! Constructs a cylinder with origin (0,0,0), height h and radius r
		GeomCylinder(float h, float r);
		//! Constructs a cylinder with origin pos, height h and radius r
		GeomCylinder(float h, float r, const Vector3& pos);

		bool canRotate();
		bool canScale();
		bool canTranslate();

		GeomType getType() const { return GeomTypeCyclinder; }

		//! @brief Sets the height of cylinder
		void setHeight(float h);

		//! @brief Sets the radius of cylinder
		void setRadius(float r);

		//! @brief Sets the position of cylinder's origin
		void setPosition(const Vector3& pos);

		//! @return The height of cylinder
		float getHeight() const;

		//! @return The height of radius
		float getRadius() const;

		//! @return The volume of cylinder
		float getVolume() const;

		// TRANSFORMATIONS
		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec);

	private:
		//! The height of the cylinder.
		float mHeight;

		//! The radius of the circular cylinder bases.
		float mRadius;
	};

}

#endif // _RENG_GEOMCYLINDER_H_
