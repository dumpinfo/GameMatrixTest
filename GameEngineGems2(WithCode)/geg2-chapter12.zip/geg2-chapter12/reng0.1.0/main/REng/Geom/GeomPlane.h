/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GEOMPLANE_H_
#define _RENG_GEOMPLANE_H_

#include "GeomBase.h"

namespace REng{

	/*!
	 *  @brief Represents an infinite plane in 3D space, with + and - sides
	 *  @note  The position of the GeomBase is used to store the normal on the plane
	 *         Another variable holds the distance of the plane from origin along that normal
	 *  @note  The plane equation is A*x + B*y + C*z + D = 0, where (A,B,C) is the normalized vector
	 *  @author Adil Yalcin & Isil Doga Yakut
	 */
	class GeomPlane : public Geom {
	public:
		//! Constructs a plane with equation z=0.
		GeomPlane();
		//! @see setGeom
		GeomPlane(const Vector3& _pos, const Vector3& _normal);
		//! @see setGeom
		GeomPlane(const Vector3& p1, const Vector3& p2, const Vector3& p3);
		//! @see setGeom
		GeomPlane(const Vector3& _normal, float distance);

		//! @return True
		bool canRotate();
		//! @return False
		bool canScale();
		//! @return True
		bool canTranslate();
		//! @return GeomTypePlane
		GeomType getType() const;

		//! @return The normalized normal value, in world-space coordinates
		const Vector3& getNormal() const;
		//! @return The distance along the normal of the plane
		float getDistanceFromOrigin() const;

		//! @return The ABC values of the plane equation as described in class info
		//! @note This function is the same as getNormal
		const Vector3& ABC() const;
		//! @return The D value of the plane equation as described in class info
		float D() const;

		//! @return The point on the plane intersecting the ray from origin in the normal direction
		//! @remark Do not try to call this frequently, use ABC() and D() instead
		Vector3 getBasePoint() const;

		//! Updates the plane geometry using given normal and distance. See related constructor for details.
		//! @note The given normal is normalized
		void setGeom(const Vector3& _normal, float _distance);

		//! Sets a plane passing through _pos with the normal vector _normal
		void setGeom(const Vector3& _pos, const Vector3& _normal);
		//! Sets a plane which includes p1, p2 and p3. The normal is calculated in clockwise order.
		//! @note Does not checks whether p1, p2 and p3 are co-linear.
		void setGeom(const Vector3& p1, const Vector3& p2, const Vector3& p3);

		void translate_World(const Vector3& vec);
		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec){};

		void rotateAroundOrigin(const Quaternion& qua);

	private:

		//! The negative distance of the plane from origin along the plane normal
		float mD;
	};

	typedef std::vector<GeomPlane> GeomPlaneList;
}

#endif // _RENG_GEOMPLANE_H_
