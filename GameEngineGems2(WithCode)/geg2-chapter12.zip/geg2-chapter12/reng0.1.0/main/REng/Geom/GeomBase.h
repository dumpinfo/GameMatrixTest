/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMBASE_H_
#define _RENG_GEOMBASE_H_

#include "REng/Prerequisites.h"

#include "REng/Math.h"

#include <vector>

namespace REng {

	//! @brief List of instantiatable geometry objects
	enum GeomType{
		GeomTypePoint,
		GeomTypeLineSegment,
		GeomTypeLine,
		GeomTypeRay,
		GeomTypePlane,
		GeomTypeAABox,
		GeomTypeOBox,
		GeomTypeSphere,
		GeomTypeCyclinder,
		GeomTypeCapsule,
		GeomTypePBV,
		GeomTypeTri,
		GeomTypeInf
	};

    /**
	 * @class Geom
	 * @brief Represents a special parametrized geometry which can be positioned in 3D space.
	 * @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class Geom{
	public:
		virtual ~Geom();

		//! @brief Returns the object type of a geom object
		virtual GeomType getType() const = 0;

		//! @brief Queries whether a geom object can rotate or not.
		//!        Returns true if return option is available for public use.
		//! @remark Can be used for some types of optimizations.
		virtual bool canRotate() = 0;
		//! @brief Queries whether a geom object can scale or not.
		//!        Returns true if return option is available for public use.
		//! @remark Can be used for some types of optimizations.
		virtual bool canScale() = 0;
		//! @brief Queries whether a geom object can translate or not.
		//!        Returns true if return option is available for public use.
		//! @remark Can be used for some types of optimizations.
		virtual bool canTranslate() = 0;

		//! @brief Each geometric entity has a position variable
		const Vector3& getPosition() const;

		//! @brief Translates the geom object wrt world coordinate system
		//! The default translation modifies the position of the object directly
		virtual void translate_World(const Vector3& vec);
		//! @brief Rotates the geom object wrt world coordinate system
		virtual void rotate_World(const Quaternion& qua) = 0;
		//! @brief Scales the geom object
		virtual void scale(const Vector3& vec) = 0;

	protected:
		Geom(const Vector3& pos = Vector3(0,0,0));

		//! Position of a Geom Object. (Mass center, most of the time)
		Vector3 mPosition;
	};
}


#endif // _RENG_GEOMBASE_H_
