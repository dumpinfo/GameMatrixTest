/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/

#ifndef _RENG_GEOM_INTERSECT_H_
#define _RENG_GEOM_INTERSECT_H_

#include "REng/Prerequisites.h"
#include "REng/Geom/Geom.h"
#include "REng/Geom/GeomHelper.h"

#include <cmath>

#include <vector>

namespace REng{

	namespace GeomHelper{

		/************************************************************************/
		/* GEOM INTERSECTION TESTS                                              */
		/************************************************************************/

		//! @subsection Intersections between geom objects.

		//! @note If an object A is inside an object B, then they intersect each other
		//!		    If an object A is partially inside an object B, then they intersect each other
		//!         The intersection tests can be used as isVisible queries.

		//! Intersection between two arbitrary geom objects.
		//! @note Returns true if the collision test is not yet implemented.
		BoolQuery intersects(const Geom& g1, const Geom& g2);
		
		BoolQuery intersects(const GeomAxisAlignedBox& g1     , const Geom& g2);
		BoolQuery intersects(const GeomLineSegment& g1        , const Geom& g2);
		BoolQuery intersects(const GeomLine& g1               , const Geom& g2);
		BoolQuery intersects(const GeomRay& g1                , const Geom& g2);
		BoolQuery intersects(const GeomPlane& g1              , const Geom& g2);
		BoolQuery intersects(const GeomOrientedBox& g1        , const Geom& g2);
		BoolQuery intersects(const GeomSphere& g1             , const Geom& g2);
		BoolQuery intersects(const GeomCylinder& g1           , const Geom& g2);
		BoolQuery intersects(const GeomCapsule& g1            , const Geom& g2);
		BoolQuery intersects(const GeomPlaneBoundedVolume& g1 , const Geom& g2);
		BoolQuery intersects(const GeomTri& g1                , const Geom& g2);

		BoolQuery intersects(const GeomInf& g1                , const Geom& g2);
		BoolQuery intersects(const GeomInf& g1                , const GeomInf& g2);
		BoolQuery intersects(const Geom& g1                   , const GeomInf& g2);

		// Intersection between geoms of same type
		
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomAxisAlignedBox& box2);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomLine& line);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomPlane& plane);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomPlaneBoundedVolume& planeVolume);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomPoint& point);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomRay& ray);
		BoolQuery intersects(const GeomAxisAlignedBox& box , const GeomSphere& sphere);
		BoolQuery intersects(const GeomLine& line , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomLine& line , const GeomPlane& plane);
		BoolQuery intersects(const GeomLine& line , const GeomSphere& sphere);
		BoolQuery intersects(const GeomOrientedBox& box1 , const GeomOrientedBox& box2);
		BoolQuery intersects(const GeomOrientedBox& obox , const GeomRay& ray);
		BoolQuery intersects(const GeomPlane& plane , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomPlane& plane , const GeomLine& line);
		BoolQuery intersects(const GeomPlane& plane , const GeomRay& ray);
		BoolQuery intersects(const GeomPlane& plane , const GeomSphere& sphere);
		BoolQuery intersects(const GeomPlaneBoundedVolume& planeVolume , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomPlaneBoundedVolume& planeVolume , const GeomSphere& sphere);
		BoolQuery intersects(const GeomPlaneBoundedVolume& planeVolume , const GeomPoint& point);
		BoolQuery intersects(const GeomPoint& point , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomPoint& point , const GeomPlaneBoundedVolume& planeVolume);
		BoolQuery intersects(const GeomPoint& point , const GeomSphere& sphere);
		BoolQuery intersects(const GeomRay& ray , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomRay& ray , const GeomOrientedBox& obox);
		BoolQuery intersects(const GeomRay& ray , const GeomPlane& plane);
		BoolQuery intersects(const GeomRay& ray , const GeomSphere& sphere);
		BoolQuery intersects(const GeomSphere& sphere , const GeomAxisAlignedBox& box);
		BoolQuery intersects(const GeomSphere& sphere , const GeomLine& line);
		BoolQuery intersects(const GeomSphere& sphere , const GeomPlane& plane);
		BoolQuery intersects(const GeomSphere& sphere , const GeomPoint& point);
		BoolQuery intersects(const GeomSphere& sphere , const GeomPlaneBoundedVolume& planeVolume);
		BoolQuery intersects(const GeomSphere& sphere , const GeomRay& ray);
		BoolQuery intersects(const GeomSphere& sphere , const GeomSphere& sphere2);

		//! @return intersection region of two axis-aligned-boxes.
		GeomAxisAlignedBox getIntersection(const GeomAxisAlignedBox& box1, const GeomAxisAlignedBox& box2);
	}





	/************************************************************************/
	/* INLINE                                                               */
	/************************************************************************/

	
	//////////////////////////////////////////////////////////////////////////
	// Specializing over base types

	inline GeomHelper::BoolQuery GeomHelper::intersects(const Geom& g1, const Geom& g2){
		switch(g1.getType()){
			// Not actually a geom type (is a typedef for Vector3)
//			case GeomTypePoint:       return intersects((const GeomPoint&)g1,g2);
			case GeomTypeLineSegment: return intersects((const GeomLineSegment&)   g1,g2);
			case GeomTypeLine:        return intersects((const GeomLine&)          g1,g2);
			case GeomTypeRay:         return intersects((const GeomRay&)           g1,g2);
			case GeomTypePlane:       return intersects((const GeomPlane&)         g1,g2);
			case GeomTypeAABox:       return intersects((const GeomAxisAlignedBox&)g1,g2);
			case GeomTypeOBox:        return intersects((const GeomAxisAlignedBox&)g1,g2);
			case GeomTypeSphere:      return intersects((const GeomSphere&)        g1,g2);
			case GeomTypeCyclinder:   return intersects((const GeomCylinder&)      g1,g2);
			case GeomTypeCapsule:     return intersects((const GeomCapsule&)       g1,g2);
			case GeomTypePBV:         return intersects((const GeomPlaneBoundedVolume&)g1,g2);
			case GeomTypeTri:         return intersects((const GeomTri&)           g1,g2);
			case GeomTypeInf:         return intersects((const GeomInf&)           g1,g2);
			default: assert(0); break;
		}
		return GeomHelper::BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomLineSegment& g1, const Geom& g2){
		switch(g2.getType()){
			// lines are infinitely small, assume unsupported
			case GeomTypeLineSegment: case GeomTypeLine: case GeomTypeRay: return BoolQueryU; 
			case GeomTypePlane:       
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomLine& g1, const Geom& g2){
		switch(g2.getType()){
			// lines are infinitely small, assume unsupported
			case GeomTypeLineSegment: case GeomTypeLine: case GeomTypeRay: return BoolQueryU; 
			case GeomTypePlane:       return intersects(g1,(const GeomPlane&)         g2);
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)        g2);
			case GeomTypeOBox:        
			case GeomTypePBV:         
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomRay& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypePlane:       return intersects(g1,(const GeomPlane&)g2);
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypeOBox:        return intersects(g1,(const GeomOrientedBox&)g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)g2);
			// lines are infinitely small, assume unsupported
			case GeomTypeLineSegment: case GeomTypeLine: case GeomTypeRay: return BoolQueryU; 
			case GeomTypePBV:         
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlane& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLine:        return intersects(g1,(const GeomLine&)          g2);
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)        g2);
			case GeomTypePlane:       return intersects(g1,(const GeomPlane&)         g2);
			case GeomTypeRay:         return intersects(g1,(const GeomRay&)           g2);
			case GeomTypeLineSegment: 
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomAxisAlignedBox& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLine:        return intersects(g1,(const GeomLine&)              g2);
			case GeomTypeRay:         return intersects(g1,(const GeomRay&)               g2);
			case GeomTypePlane:       return intersects(g1,(const GeomPlane&)             g2);
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)    g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)            g2);
			case GeomTypePBV:         return intersects(g1,(const GeomPlaneBoundedVolume&)g2);
			case GeomTypeLineSegment: 
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomOrientedBox& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeRay:         return intersects(g1,(const GeomRay&)           g2);
			case GeomTypeOBox:        return intersects(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypePBV:         
			case GeomTypeLine:        
			case GeomTypeLineSegment: 
			case GeomTypePlane:       
			case GeomTypeAABox:       
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLine:        return intersects(g1,(const GeomLine&)              g2);
			case GeomTypeRay:         return intersects(g1,(const GeomRay&)               g2);
			case GeomTypePlane:       return intersects(g1,(const GeomPlane&)             g2);
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)    g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)            g2);
			case GeomTypePBV:         return intersects(g1,(const GeomPlaneBoundedVolume&)g2);
			case GeomTypeLineSegment: 
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomCylinder& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLineSegment: 
			case GeomTypeLine:        
			case GeomTypeRay:         
			case GeomTypePlane:       
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomCapsule& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLineSegment: 
			case GeomTypeLine:        
			case GeomTypeRay:         
			case GeomTypePlane:       
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlaneBoundedVolume& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeAABox:       return intersects(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypeSphere:      return intersects(g1,(const GeomSphere&)        g2);
			case GeomTypeOBox:        
			case GeomTypeLine:        
			case GeomTypeRay:         
			case GeomTypeLineSegment: 
			case GeomTypePlane:       
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomTri& g1, const Geom& g2){
		switch(g2.getType()){
			case GeomTypeLineSegment: 
			case GeomTypeLine:        
			case GeomTypeRay:         
			case GeomTypePlane:       
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}

	// Infinite volumes intersect with all possible geometries
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomInf& g1, const Geom& g2)   {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomInf& g1, const GeomInf& g2){return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const Geom& g1, const GeomInf& g2)   {return BoolQueryT;}

	// reflections for boolean intersect queries
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomLine& line, const GeomAxisAlignedBox& box)  {return intersects(box,line);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPoint& point, const GeomAxisAlignedBox& box){return intersects(box,point);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPoint& point, const GeomPlaneBoundedVolume& planeVolume){return intersects(planeVolume,point);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlane& plane, const GeomAxisAlignedBox& box){return intersects(box,plane);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlane& plane, const GeomLine& line)         {return intersects(line,plane);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomPlaneBoundedVolume& planeVolume, const GeomAxisAlignedBox& box){return intersects(box,planeVolume);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomRay& ray, const GeomAxisAlignedBox& box){return intersects(box,ray);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomRay& ray, const GeomOrientedBox& obox)  {return intersects(obox,ray);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomRay& ray, const GeomPlane& plane)       {return intersects(plane,ray);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere, const GeomAxisAlignedBox& box){return intersects(box,sphere);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere, const GeomLine& line)   {return intersects(line,sphere);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere, const GeomPlane& plane) {return intersects(plane,sphere);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere, const GeomPlaneBoundedVolume& planeVolume){return intersects(planeVolume, sphere);}
	inline GeomHelper::BoolQuery GeomHelper::intersects(const GeomSphere& sphere, const GeomRay& ray)     {return intersects(ray,sphere);}

} // namespace REng

#endif // _RENG_GEOM_INTERSECT_H_
