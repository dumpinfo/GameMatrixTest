/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMTRI_H_
#define _RENG_GEOMTRI_H_

#include "GeomBase.h"
#include "GeomPoint.h"

namespace REng{

	/*!
	 *  @brief Represents a triangle face in space, with a normal using CCW convention
	 *  @note  The geom position is used as the first point of the triangle.
	 *  @author Adil Yalcin
	 */
	class GeomTri : public Geom {
	public:
		//! Constructs a triangle from points (0,0,0), (0,0,1) and (0,1,0)
		GeomTri();
		//! @see setGeom
		GeomTri(const GeomPoint& p1, const GeomPoint& p2, const GeomPoint& p3);

		//! @return True
		bool canRotate();
		//! @return True
		bool canScale();
		//! @return True
		bool canTranslate();
		//! @return GeomTypeTri
		GeomType getType() const;

		//! @return The normal of the triangle (is not normalized)
		Vector3 getNormal() const;

		//! @return Point 1 of the triangle
		const Vector3& getP1() const;
		//! @return Point 2 of the triangle
		const Vector3& getP2() const;
		//! @return Point 3 of the triangle
		const Vector3& getP3() const;

		//! The vertex order is changed so that normal points to other side.
		void rewind();

		//! Sets the points of the triangle
		void setGeom(const GeomPoint& p1, const GeomPoint& p2, const GeomPoint& p3);

		// TODO: translate, scale, rotate
		void rotate_World(const Quaternion& qua) {;}
		void scale(const Vector3& vec) {;}
	private:
		GeomPoint mPoint2;
		GeomPoint mPoint3;
	};
}

#endif // _RENG_GEOMTRI_H_

