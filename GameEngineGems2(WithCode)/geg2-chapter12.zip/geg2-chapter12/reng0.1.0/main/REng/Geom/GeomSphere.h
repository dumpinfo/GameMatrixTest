/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMSPHERE_H_
#define _RENG_GEOMSPHERE_H_

#include "GeomVolume.h"

namespace REng{

	/*!
	*  @brief Represents a sphere in 3D space.
	*         The position denotes the position of the center of the sphere.
	*  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	*/
	class GeomSphere : public GeomVolume {
	public:
		//! @brief Constructs a unit-sphere (position: (0,0,0), radius : 1)
		GeomSphere();

		//! @brief Constructs a sphere at position (0,0,0) and with radius _radius)
		GeomSphere(float _radius);

		//! @brief Constructs a sphere at position _pos and with radius _radius)
		GeomSphere(const Vector3& _pos, float _radius);

		GeomType getType() const;

		//! @brief Sets the position of the sphere
		void setPosition(const Vector3& _pos);

		//! @brief Sets the radius of the sphere
		void setRadius(float _radius);

		//! @brief Updates the complete geometry of the sphere
		void setGeom(const Vector3& _pos, float _radius);

		//! @return The radius of the sphere
		float getRadius() const;

		//! @return The volume of the sphere
		float getVolume() const;

		bool canRotate() {return false;};
		bool canScale() {return true;};
		bool canTranslate() {return true;};

		// TRANSFORMATIONS
		//! @note The largest component of the given vector (vec) is used to as scale factor.
		void scale(const Vector3& vec);
		//! @brief The basic scale method of GeomSphere takes only a single parameter.
		void scale(float ratio);
		void rotate_World(const Quaternion& qua);

	private:
		float mRadius;
	};

}

#endif // _RENG_GEOMSPHERE_H_
