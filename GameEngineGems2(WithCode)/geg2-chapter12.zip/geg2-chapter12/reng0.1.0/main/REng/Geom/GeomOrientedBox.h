/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMORIENTEDBOX_H_
#define _RENG_GEOMORIENTEDBOX_H_

#include "GeomBox.h"

namespace REng{

	/*!
	 *  @brief Represents an oriented box in 3D world-space.
	 *  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomOrientedBox : public GeomBox {
	public:
		//! @brief Constructs a unit axis-aligned box (pos : (0,0,0), halfSize :(0.5,0.5,0.5) )
		GeomOrientedBox();

		//! Constructs an oriented box using the given center, half-size and rotation information
		GeomOrientedBox(const Vector3& v1, const Vector3& v2, const Quaternion& orient);

		//! @return GeomTypeOBox
		GeomType getType() const;

		//! @brief Updates the geometry of oriented box
		//! @param v1 The position of the center of the box
		//! @param v2 Half-size of the box, assume no orientation in axis specification
		//! @param orient The orientation of the target configuration
		void setGeom(const Vector3& v1, const Vector3& v2, const Quaternion& orient);

		//! @return The world-space orientation of this oriented box
		const Quaternion& getWorldOrientation() const;

		//! @return True;
		bool canRotate();
		//! @return True;
		bool canScale();
		//! @return True;
		bool canTranslate();

		// TRANSFORMATIONS
		void translate_World(const Vector3& vec);
		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec);

	private:
		//! the orientation of the bounding box
		Quaternion mWorldOrientation;

		//! oriented boxes calculate corners using the orientation as well.
		void updateCorners() const;
	};

}

#endif // _RENG_GEOMORIENTEDBOX_H_
