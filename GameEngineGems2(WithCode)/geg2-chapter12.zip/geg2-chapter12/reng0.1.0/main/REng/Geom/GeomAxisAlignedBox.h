/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMAXISALIGNEDBOX_H_
#define _RENG_GEOMAXISALIGNEDBOX_H_

#include "GeomBox.h"

namespace REng {

	//! Types of bounding values
	enum BoundTypeAAB {
		BoundAABMinX,
		BoundAABMaxX,
		BoundAABMinY,
		BoundAABMaxY,
		BoundAABMinZ,
		BoundAABMaxZ,
	};

	//! the types are decoded as = m: minimum, M: maximum
	enum CornerTypeAAB {
		Corner_mXmYmZ = 0,
		Corner_mXmYMZ = 1,
		Corner_mXMYmZ = 2,
		Corner_mXMYMZ = 3,
		Corner_MXmYmZ = 4,
		Corner_MXmYMZ = 5,
		Corner_MXMYmZ = 6,
		Corner_MXMYMZ = 7
	};

    /**
	 * @class GeomAxisAlignedBox
	 * @brief Represents an axis-aligned box in 3D world-space
      * @todo  Think: extrude / per-face infinity , etc
	 * @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomAxisAlignedBox : public GeomBox {
	public:
		//! Geom set function options
		enum SetFunc { Set_MinMax, Set_CenterHSize };

		//! Constructs a unit axis-aligned box (pos : (0,0,0), halfSize :(0.5,0.5,0.5) )
		GeomAxisAlignedBox();

		//! @see setGeom
		GeomAxisAlignedBox(const Vector3& v1, const Vector3& v2, SetFunc funcType = Set_CenterHSize);

		//! @return GeomTypeAABox
		GeomType getType() const;
		//! @return true
		bool canRotate();
		//! @return true
		bool canScale();
		//! @return true
		bool canTranslate();

		//////////////////////////////////////////////////////////////////////////
		// SPECIAL BOXES

		//! A box in center position (0,0,0), half size (0.5,0.5,0.5)
		static const GeomAxisAlignedBox BOX_UNIT;
		static const GeomAxisAlignedBox BOX_NULL; // TODO
		static const GeomAxisAlignedBox BOX_INFINITE; // TODO

		//////////////////////////////////////////////////////////////////////////
		// GETTERS

		//! @brief Returns the 3d point at the given corner.
		const GeomPoint& getCorner(CornerTypeAAB corner) const;

		//! @return The bounding value of this aabox of the given type
		float get(BoundTypeAAB b) const;

		//////////////////////////////////////////////////////////////////////////
		// SETTERS

		//! @brief Updates the box geometry according to funcType value.
		//! @param funcType Changes interpretation of v1 and v2
		//! If Set_CenterHSize, v1 is used as the center and v2 as the half-size.
		//!    Each component of v2 vector must be positive.
		//! If Set_MinMax, v1 is used as the minimum-corner and v2 as the maximum-corner.
		//!    Components of v1 must be smaller than components of v2.
		void setGeom(const Vector3& v1, const Vector3& v2, SetFunc funcType = Set_CenterHSize);

		//! @return The bounding value of this aabox of the given type
		void set(BoundTypeAAB b, float val);

		//////////////////////////////////////////////////////////////////////////
		// TRANSFORMATIONS

		//! @todo Translates the AAB according to vec. Simply changes mPosition of the AAB.
		void translate_World(const Vector3& vec);

		//! @remark To apply rotation to AABB, first it is treated as an OB and rotated, then the
		//!         bounding AAB of this new OB is used to as a replacement for this AAB.
		//! @remark If you continually apply rotation, this AAB will expend, so use a local AAB / maintain a
		//!         copy of the original if you need to apply successive rotations.
		//! @remark ts and reset parameters are not used.
		void rotate_World(const Quaternion& qua);

		//! Scales the ABB by multiplying mHalfsize with vec.
		void scale(const Vector3& vec);
		//! Scales the ABB by multiplying mHalfsize components with given value
		void scale(float s);

	protected:
		//! @brief Updates the corners of the bounding box and returns
		void updateCorners() const;
	};
}

#endif // _RENG_GEOMAXISALIGNEDBOX_H_
