/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMBOX_H_
#define _RENG_GEOMBOX_H_

#include "GeomVolume.h"
#include "GeomPoint.h"

namespace REng{

	/*!
	*  @brief Represents a box (rectangular prism) in 3D world-space.
	*  @note  You cannot instantiate a geom-box directly, use axis-aligned or oriented variants
	*  @todo  Think: extrude / per-point infinity / null-infinite boxes, etc
	*  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	*/
	class GeomBox : public GeomVolume {
	public:

		//////////////////////////////////////////////////////////////////////////
		// GETTERS

		//! @return The half-size of this box.
		const Vector3& getHalfSize() const;

		//! @return The size of this box.
		//! @remark The size is generated from half-size every call, prefer getHalfSize method.
		Vector3 getSize() const;

		//! @return The volume of box.
		//! @note The volume depends on half-size only.
		float getVolume() const;

		//! @note returns all the corner points of this box. If box is infinite, returns null.
		const GeomPoint* getCorners() const;

	protected:
		//! @brief Constructs a unit box (pos : (0,0,0), halfSize :(0.5,0.5,0.5) )
		GeomBox();

		//! @brief This stores the half-size of the box (3-component , x-y-z)
		Vector3 mHalfSize;

		//! @brief A cache that stores the corner points of this box.
		mutable GeomPoint mCorners_cache[8];

		//! @brief A flag that is true if the mCorners_cache need to be updated.
		mutable bool mCornersDirty;

		//! @brief Updates the corners of the bounding box and returns
		virtual void updateCorners() const = 0;
	};

}

#endif // _RENG_GEOMBOX_H_
