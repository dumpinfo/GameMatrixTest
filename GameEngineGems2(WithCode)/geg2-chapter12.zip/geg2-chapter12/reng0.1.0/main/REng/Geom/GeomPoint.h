
/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMPOINT_H_
#define _RENG_GEOMPOINT_H_

#include "GeomBase.h"

namespace REng{

	typedef Vector3 GeomPoint;

	/*!
	*  @brief Represents a point in 3D space
	*  @note  The Geom position is used as the the location of the point.
	*  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	*/
	/*
	class GeomPoint : public Geom{
	public:
		GeomPoint(const Vector3& pos);
		//! Constructs a point in (0,0,0)
		GeomPoint();

		//! @return True
		bool canRotate();
		//! @return False
		bool canScale();
		//! @return True
		bool canTranslate();

		//! @return GeomTypePoint
		GeomType getType() const;

		void setPosition(const Vector3& pos);
		void set(const Vector3& pos);

		//! @note no scaling & rotating is possible
		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec){};
	};
	*/

	typedef std::vector<GeomPoint> GeomPointList;
}

#endif // _RENG_GEOMPOINT_H_
