/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMPLANEBOUNDEDVOLUME_H_
#define _RENG_GEOMPLANEBOUNDEDVOLUME_H_

#include "GeomVolume.h"
#include "GeomPlane.h"

namespace REng{

	/*!
	*  @brief A plane bounded volume is composed of a list of planes (with +/- sides) that describes a limited volume
	*  @remark This class will be used to denote the camera frustum (in perspective/orthographic projection)
	*  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	*/
	class GeomPlaneBoundedVolume : public GeomVolume {
	public:
		//! Constructs a unit cube;
		GeomPlaneBoundedVolume();
		//! Constructs a plane which is bounded by given planes.
		//! ASSUMPTION All plane normals should be directed into the volume.
		//! ASSUMPTION All plane positions should be centered.
		GeomPlaneBoundedVolume(const GeomPlaneList& _planeList);
		~GeomPlaneBoundedVolume(){};

		GeomType getType() const;

		//! @todo getVolume should be implemented
		float getVolume() const;

		void clearPlaneList();
		void addPlane(const GeomPlane& plane);

		const GeomPlaneList& getPlaneList() const;
		const Vector3& getPosition() const;

		bool canRotate() {return true;};
		bool canScale() {return true;};
		bool canTranslate() {return true;};

		void translate_World(const Vector3& vec);
		void rotate_World(const Quaternion& qua);
		//! @todo Scale should be implemented
		void scale(const Vector3& vec);
	private:
		//! @brief The list of planes that bound/describe the 3D volume
		GeomPlaneList mPlaneList;
		void recalcPosition();
	};

}

#endif // _RENG_GEOMPLANEBOUNDEDVOLUME_H_
