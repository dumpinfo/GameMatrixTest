
/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOM_HELPER_H_
#define _RENG_GEOM_HELPER_H_

#include "REng/Geom/Geom.h"
#include <cmath>

#include <vector>

namespace REng{

	/*!
	 *  @brief The Geom's themselves do not include any operations
	 *           that compute relationships between two geom objects.
	 *         Use the methods in this namespace to perform such tests / queries.
	 *  @author Adil Yalcin, I.Doga Yakut, and Cansin Yildiz
	 */
	namespace GeomHelper{

		//! The result type of boolean GeomHelper queries
		enum BoolQuery {
			BoolQueryF = 0, ///< False
			BoolQueryT = 1, ///< True
			BoolQueryX = 2, ///< Not implemented
			BoolQueryU = 3  ///< Undefined / invalid query
		};

		/************************************************************************/
		/* DISTANCE QUERIES                                                     */
		/************************************************************************/

		//! @section Base intersection tests on squared variants.

		//! @subsection Squared distance calculations

		float getDistanceSquared(const GeomPoint& p1    , const GeomPoint& p2    );
		float getDistanceSquared(const GeomPoint& point , const GeomLine& line   );
		float getDistanceSquared(const GeomPoint& point , const GeomPlane& plane );
		float getDistanceSquared(const GeomLine& line   , const GeomPoint& point );
		float getDistanceSquared(const GeomPlane& plane , const GeomPoint & point);

       //! @subsection Distance calculations

		float getDistance(const GeomPoint& p1    , const GeomPoint& p2);
		float getDistance(const GeomPoint& point , const GeomLine& line);
		float getDistance(const GeomPoint& point , const GeomPlane& plane);
		float getDistance(const GeomLine& point  , const GeomPoint& line);
		float getDistance(const GeomPlane& plane , GeomPoint & point);

		//! Signed distance between a point and a plane.
		float getSignedDistance(const GeomPoint& point, const GeomPlane& plane);
		float getSignedDistance(const GeomPlane& plane, const GeomPoint& point);

		/************************************************************************/
		/* RAY INTERSECTION TESTS WITH DISTANCE INFORMATION                     */
		/************************************************************************/

		//! Finds the intersection point on the ray given an aab, if any
		//! @param dist The distance of intersection along the ray from origin, 
		//!             Unit length is ray direction length. Updated if function returns true.
		//! @note If the ray is inside the box, intersection distance is 0.
		//! @return Whether ray intersects axis aligned box
		bool getRayIntersect(const GeomRay& ray, const GeomAxisAlignedBox& aab, float& dist);

		//! Finds the intersection point on the ray given a triangle, if any
		//! @param dist The distance of intersection along the ray from origin, 
		//!             Unit length is ray direction length. Updated if function returns true.
		//! @return Whether ray intersects triangle
		bool getRayIntersect(const GeomRay& ray, const GeomTri& tri, float& dist);

		//! Finds the intersection point on the ray given a plane, if any
		//! @param dist The distance of intersection along the ray from origin, 
		//!             Unit length is ray direction length. Updated if function returns true.
		//! @return Whether ray intersects plane
		bool getRayIntersect(const GeomRay& ray, const GeomPlane& plane, float& dist);

		//! Finds the intersection point on the ray given a plane-bounded convex volume, if any
		//! @param dist The distance of intersection along the ray from origin, 
		//!             Unit length is ray direction length. Updated if function returns true.
		//! @return Whether ray intersects plane-bounded convex volume
		//! @note If the ray origin is inside the volume, intersection distance is 0
		bool getRayIntersect(const GeomRay& ray, const GeomPlaneBoundedVolume& convexVol, float& dist);

		/************************************************************************/
		/* CONTAINMENT TESTS                                                    */
		/************************************************************************/

		//! @section Containments between geom objects.
		//! @remark The order of parameters is important. query means: does first object contain second object?

		BoolQuery contains(const GeomVolume& g1 , const Geom& g2);

		// All false (second type is infinite) (except when first type is infinite)
		BoolQuery contains(const GeomVolume& g1 , const GeomLine& g2);
		BoolQuery contains(const GeomVolume& g1 , const GeomRay& g2);
		BoolQuery contains(const GeomVolume& g1 , const GeomPlane& g2);

		BoolQuery contains(const GeomAxisAlignedBox& g1     , const Geom& g2);
		BoolQuery contains(const GeomOrientedBox& g1        , const Geom& g2);
		BoolQuery contains(const GeomSphere& g1             , const Geom& g2);
		BoolQuery contains(const GeomCylinder& g1           , const Geom& g2);
		BoolQuery contains(const GeomCapsule& g1            , const Geom& g2);
		BoolQuery contains(const GeomPlaneBoundedVolume& g1 , const Geom& g2);
		BoolQuery contains(const GeomInf& g1                , const Geom& g2);

		BoolQuery contains(const GeomAxisAlignedBox& box, const GeomAxisAlignedBox& box2);
		BoolQuery contains(const GeomAxisAlignedBox& box, const GeomLineSegment& sphere);
		BoolQuery contains(const GeomAxisAlignedBox& box, const GeomPoint& point);
		BoolQuery contains(const GeomAxisAlignedBox& box, const GeomSphere& sphere);
		BoolQuery contains(const GeomPlaneBoundedVolume& planeVolume, const GeomAxisAlignedBox& box);
		BoolQuery contains(const GeomPlaneBoundedVolume& planeVolume, const GeomLineSegment& lineSeg);
		BoolQuery contains(const GeomPlaneBoundedVolume& planeVolume, const GeomPoint& g2);
		BoolQuery contains(const GeomPlaneBoundedVolume& planeVolume, const GeomSphere& sphere);
		BoolQuery contains(const GeomSphere& sphere, const GeomAxisAlignedBox& box);
		BoolQuery contains(const GeomSphere& sphere, const GeomPoint& point);
		BoolQuery contains(const GeomSphere& sphere, const GeomSphere& sphere2);

		// Note: All "true"
		BoolQuery contains(const GeomInf& g1 , const GeomPoint& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomLineSegment& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomLine& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomRay& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomPlane& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomAxisAlignedBox& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomOrientedBox& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomSphere& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomCylinder& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomCapsule& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomPlaneBoundedVolume& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomTri& g2);
		BoolQuery contains(const GeomInf& g1 , const GeomInf& g2);

		/************************************************************************/
		/* MERGING BOUNDING VOLUMES                                             */
		/************************************************************************/

		//! @section Merge of geom objects.
		//! @remark The order of parameters is important. The second parameter is merged into the geom of the first parameter.

		//! Given box will store bounding box of box + boxExtend
		void mergeBounding(GeomAxisAlignedBox& box, const GeomAxisAlignedBox& boxExtend);

		//! Given box will store bounding box of box + point
		void mergeBounding(GeomAxisAlignedBox& box, const GeomPoint& point);

		//! Given sphere will store bounding GeomSphere of sphere + sphereExtend
		void mergeBounding(GeomSphere& sphere, const GeomSphere& sphereExtend);

		//! Given sphere will store bounding GeomSphere of sphere + box
		void mergeBounding(GeomSphere& sphere, const GeomAxisAlignedBox& box);

		/************************************************************************/
		/* SIDE QUERIES (PLANE-GEOM)                                            */
		/************************************************************************/

		// FROM OGRE
		enum PlaneSide {
			PlaneSide_On,       ///< The given geometry is inside/on the plane
			PlaneSide_Positive, ///< The given geometry is in the half-space in which the normal points to
			PlaneSide_Negative, ///< The given geometry is in the half-space in which the revered normal points to
			PlaneSide_Both      ///< The given geometry spans on the both positive and negative side of the plane
		};

		//! Returns the side of the given point with respect to the plane
		PlaneSide getSide(const GeomPlane& plane, const GeomPoint& point);

		//! Returns the side of the given axis-aligned-box with respect to the plane
		PlaneSide getSide(const GeomPlane& plane, const GeomAxisAlignedBox& aabox);

		/************************************************************************/
		/* MISC                                                                 */
		/************************************************************************/

		//! Updates the axis-aligned box to be the bounding box of the given oriented box
		void generateBoundingBox(GeomAxisAlignedBox& aab, const GeomOrientedBox& ob);

		/** FROM OGRE: Project a point onto the plane.
		@remarks This gives you the element of the input point that is perpendicular
		to the normal of the plane. You can getPosition the element which is parallel
		to the normal of the plane by subtracting the result of this method
		from the original vector, since parallel + perpendicular = original.
		*/
		GeomPoint projectPoint(const GeomPoint& point);
	};

} // namespace REng

#include "REng/Geom/GeomHelperIntersect.h"

namespace REng {

	//////////////////////////////////////////////////////////////////////////
	// INLINE METHODS
	//////////////////////////////////////////////////////////////////////////

	inline float GeomHelper::getDistanceSquared(const GeomPoint& p1, const GeomPoint& p2){
		GeomPoint d(p2-p1);
		return d[0]*d[0]+d[1]*d[1]+d[2]*d[2];
	}

	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomAxisAlignedBox& box, const GeomPoint& point){
		return intersects(box,point);
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomAxisAlignedBox& box, const GeomLineSegment& lineSeg){
		// if one of the end points fall outside the box, false!
		return (intersects(box,lineSeg.getPosition())==BoolQueryF)?BoolQueryF:
			    ((intersects(box,lineSeg.getPoint(1.0))==BoolQueryF)?BoolQueryF:BoolQueryT);
	}


	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomVolume& g1, const Geom& g2){
		switch(g1.getType()){
			case GeomTypeAABox:       return contains((const GeomAxisAlignedBox&)g1     , g2);
			case GeomTypeOBox:        return contains((const GeomOrientedBox&)g1        , g2);
			case GeomTypeSphere:      return contains((const GeomSphere&)g1             , g2);
			case GeomTypeCyclinder:   return contains((const GeomCylinder&)g1           , g2);
			case GeomTypeCapsule:     return contains((const GeomCapsule&)g1            , g2);
			case GeomTypePBV:         return contains((const GeomPlaneBoundedVolume&)g1 , g2);
			case GeomTypeInf:         return contains((const GeomInf&)g1                , g2);
			default: break; //remaining are non-volumetric types
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomAxisAlignedBox& g1 , const Geom& g2){
		switch(g2.getType()){
			case GeomTypeAABox:       return contains(g1, (const GeomAxisAlignedBox&)g2);
			case GeomTypeSphere:      return contains(g1, (const GeomSphere&)g2);
			case GeomTypeLineSegment: return contains(g1, (const GeomLineSegment&)g2);
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomOrientedBox& g1 , const Geom& g2){
		switch(g2.getType()){
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeLineSegment: 
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomSphere& g1 , const Geom& g2){
		switch(g2.getType()){
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeAABox:       return contains(g1, (const GeomAxisAlignedBox&)g2);
			case GeomTypeSphere:      return contains(g1, (const GeomSphere&)g2);
			case GeomTypeLineSegment: 
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomCylinder& g1 , const Geom& g2){
		switch(g2.getType()){
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeLineSegment: 
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomCapsule& g1 , const Geom& g2){
		switch(g2.getType()){
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeLineSegment: 
			case GeomTypeAABox:       
			case GeomTypeOBox:        
			case GeomTypeSphere:      
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomPlaneBoundedVolume& g1 , const Geom& g2){
		switch(g2.getType()){
			// lines, rays and planes are infinite
			case GeomTypeLine: case GeomTypeRay: case GeomTypePlane: return BoolQueryF; 
			case GeomTypeSphere:      return contains(g1,(const GeomSphere&)g2);
			case GeomTypeAABox:       return contains(g1,(const GeomAxisAlignedBox&)g2);
			case GeomTypeLineSegment: return contains(g1,(const GeomLineSegment&)g2);
			case GeomTypeOBox:        
			case GeomTypeCyclinder:   
			case GeomTypeCapsule:     
			case GeomTypePBV:         
			case GeomTypeTri:         return BoolQueryX;
			default: assert(0); break;
		}
		return BoolQueryU;
	}


	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const Geom& g2){
		return BoolQueryT;
	}

	//////////////////////////////////////////////////////////////////////////
	// reflected methods

	inline float GeomHelper::getDistanceSquared(const GeomPoint& point, const GeomLine& line){
		return getDistanceSquared(line, point);
	}
	inline float GeomHelper::getDistanceSquared(const GeomPlane& plane, const GeomPoint & point){
		return getDistanceSquared(point, plane);
	}
	inline float GeomHelper::getDistance(const GeomPoint& p1, const GeomPoint& p2){
		return sqrt(getDistanceSquared(p1,p2));
	}
	inline float GeomHelper::getDistance(const GeomPoint& point, const GeomLine& line){
		return sqrt(getDistanceSquared(point,line));
	}
	inline float GeomHelper::getDistance(const GeomLine& line, const GeomPoint& point){
		return sqrt(getDistanceSquared(point,line));
	}
	inline float GeomHelper::getDistance(const GeomPoint& point, const GeomPlane& plane){
		return sqrt(getDistanceSquared(point,plane));
	}
	inline float GeomHelper::getDistance(const GeomPlane& plane, GeomPoint & point){
		return sqrt(getDistanceSquared(point,plane));
	}
	inline float GeomHelper::getSignedDistance(const GeomPlane& plane, const GeomPoint& point){
	    return getSignedDistance(point,plane);
	}

	/************************************************************************/
	/* CONTAINS                                                             */
	/************************************************************************/

	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomSphere& sphere, const GeomPoint& point){
		return intersects(sphere,point);
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomPlaneBoundedVolume& planeVolume , const GeomPoint& g2){
		return intersects(planeVolume,g2);
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomPlaneBoundedVolume& planeVolume, const GeomLineSegment& lineSeg){
		// plane bounded volumes are convex volumes, so if both ends of a line segment are inside, 
		// the line segment itself is completely inside the volume
		if(intersects(planeVolume,lineSeg.getPosition() )==BoolQueryF) return BoolQueryF;
		if(intersects(planeVolume,lineSeg.getPoint(1.0f))==BoolQueryF) return BoolQueryF;
		return BoolQueryT;
	}

	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomVolume& g1 , const GeomLine& g2){
		return (g1.getType()==GeomTypeInf)?BoolQueryT:BoolQueryF;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomVolume& g1 , const GeomRay& g2){
		return (g1.getType()==GeomTypeInf)?BoolQueryT:BoolQueryF;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomVolume& g1 , const GeomPlane& g2){
		return (g1.getType()==GeomTypeInf)?BoolQueryT:BoolQueryF;
	}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomPoint& g2)         {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomLineSegment& g2)   {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomLine& g2)          {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomRay& g2)           {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomPlane& g2)         {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomAxisAlignedBox& g2){return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomOrientedBox& g2)   {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomSphere& g2)        {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomCylinder& g2)      {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomCapsule& g2)       {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomPlaneBoundedVolume& g2){return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomTri& g2)           {return BoolQueryT;}
	inline GeomHelper::BoolQuery GeomHelper::contains(const GeomInf& g1 , const GeomInf& g2)           {return BoolQueryT;}
}

#endif
