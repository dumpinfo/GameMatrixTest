/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************/
#ifndef _RENG_GEOMLINESEGMENT_H_
#define _RENG_GEOMLINESEGMENT_H_

#include "GeomBase.h"
#include "GeomPoint.h"

namespace REng{

	/*!
	 *  @brief Represents a line segment in 3D space, finite on both ends
	 *  @note  The geom position is used as end point of the segment.
	 *  @author I.Doga Yakut, Adil Yalcin, and Cansin Yildiz
	 */
	class GeomLineSegment : public Geom {
	public:
		//! Constructs a line segment between (0,0,0) and (1,0,0)
		GeomLineSegment();
		//! @see setGeom
		GeomLineSegment(const Vector3& p1, const Vector3& p2);

		//! @return True
		bool canRotate();
		//! @return False
		bool canScale();
		//! @return True
		bool canTranslate();
		//! @return GeomTypeLineSegment
		GeomType getType() const;

		//! @return A point on the line segment between p1 and p2, linearly interploated
		//! @param u The interpolation factor (when u=0, returns p1, when u=1 returns p2)
		GeomPoint getPoint(float u) const;

		//! @return The direction of the segment (from first point to second point)
		//! @remark Result is not normalized.
		Vector3 getDirection() const;

		//! @param p1 The starting point of line segment
		//! @param p2 The ending point of line segment
		void setGeom(const Vector3& p1, const Vector3& p2);

		//! Sets the position of the source point on the line
		void setPosition(const Vector3& pos);

		void rotate_World(const Quaternion& qua);
		void scale(const Vector3& vec){};
	private:

        //! second point of the line segment.
        //! @note first point is stored at Geom::mPosition.
		Vector3 mPoint2;
	};

}

#endif // _RENG_GEOMLINESEGMENT_H_
