/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_RECT_H_
#define _RENG_RECT_H_

#include "REng/Prerequisites.h"

#include "REng/Math.h"

namespace REng{

	/*!
	*  @brief A 2D rectangle object with configurable type. The origin is the lower left corner.
	*  @author Adil Yalcin
	*/
	template<typename T>
	class RENGAPI Rect{
	public:
		Rect();
		Rect(T left, T right, T bottom, T top);
		T getLeft() const;
		T getRight() const;
		T getTop() const;
		T getBottom() const;
		T getWidth() const;
		T getHeight() const;

		void setLeft(T v);
		void setRight(T v);
		void setTop(T v);
		void setBottom(T v);

		void getLimits(T& left, T& right, T& bottom, T& top) const;
		void getSize(T& width, T& height) const;
		void getOrigin(T& left, T& bottom) const;

		void setLimits(T left, T right, T bottom, T top);
		void setSize(T width, T height);
		void setOrigin(T left, T bottom);

		bool operator==(const Rect& rhs) const;
		bool operator!=(const Rect& rhs) const;
	private:
		T mLeft;
		T mRight;
		T mTop;
		T mBottom;
	};

	// A rectangle with floating point limits
	typedef Rect<float> RectF;
	// A rectangle with integer limits
	typedef Rect<int> RectI;

	//////////////////////////////////////////////////////////////////////////
	// implementation
	//////////////////////////////////////////////////////////////////////////

	template<typename T> 
	Rect<T>::Rect(){}
	template<typename T> 
	Rect<T>::Rect(T left, T right, T bottom, T top)
		:mLeft(left), mRight(right), mTop(top), mBottom(bottom) {}

	template<typename T> 
	T Rect<T>::getLeft() const { 
		return mLeft;
	}
	template<typename T> 
	T Rect<T>::getRight() const { 
		return mRight;
	}
	template<typename T>
	T Rect<T>::getTop() const { 
		return mTop; 
	}
	template<typename T>
	T Rect<T>::getBottom() const { 
		return mBottom;
	}
	template<typename T>
	T Rect<T>::getWidth() const { 
		return Math::abs(mRight - mLeft);
	}
	template<typename T>
	T Rect<T>::getHeight() const { 
		return Math::abs(mTop-mBottom);
	}
	template<typename T> void Rect<T>::setLeft  (T v){ mLeft = v;}
	template<typename T> void Rect<T>::setRight (T v){ mRight = v;}
	template<typename T> void Rect<T>::setTop   (T v){ mTop = v;}
	template<typename T> void Rect<T>::setBottom(T v){ mBottom = v;}

	template<typename T>
	void Rect<T>::getLimits(T& left, T& right, T& bottom, T& top) const{
		left   = mLeft;
		right  = mRight;
		bottom = mBottom;
		top    = mTop;
	}
	template<typename T>
	void Rect<T>::getSize(T& width, T& height) const{
		width = getWidth();
		height = getHeight();
	}
	template<typename T>
	void Rect<T>::getOrigin(T& left, T& bottom) const{
		left   = mLeft;
		bottom = mBottom;
	}

	template<typename T>
	void Rect<T>::setLimits(T left, T right, T bottom, T top){
/*		if(left>right){
			T tmp(left);
			left = right;
			right = tmp;
		}
		if(bottom>top){
			T tmp(bottom);
			bottom = top;
			top = tmp;
		}
*/		mLeft   = left;
		mRight  = right;
		mBottom = bottom;
		mTop    = top;
	}
	template<typename T>
	void Rect<T>::setSize(T width, T height){
		mRight = mLeft + width;
		mTop   = mBottom + height;
	}
	template<typename T>
	void Rect<T>::setOrigin(T left, T bottom){
		mLeft   = left;
		mBottom = bottom;
	}

	template<typename T>
	bool Rect<T>::operator==(const Rect& rhs) const{
		if(this->mLeft!=rhs.mLeft) return false;
		if(this->mRight!=rhs.mRight) return false;
		if(this->mBottom!=rhs.mBottom) return false;
		if(this->mTop!=rhs.mTop) return false;
		return true;
	}
	template<typename T>
	bool Rect<T>::operator!=(const Rect& rhs) const{
		return !((*this)==rhs);
	}


} // namespace REng

#endif // _RENG_RECT_H_
