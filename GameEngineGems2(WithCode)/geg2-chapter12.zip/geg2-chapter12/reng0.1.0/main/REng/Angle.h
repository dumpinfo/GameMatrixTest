/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_ANGLE_H_
#define _RENG_ANGLE_H_

#include "REng/Prerequisites.h"

#include <math.h>

namespace REng{

	/**
	 * @brief An angle is the figure formed by two rays sharing a common endpoint, 
	 *        called the vertex of the angle (From Wikipedia :) ) 
	 * @remark There are two valid units for angle representation: Degree and Radian
	 *         The units can be easily converted to each other.
	 *         Arithmetics can be performed easily using both types as well.
	 * @author Adil Yalcin
	 */
	class RENGAPI Angle{
	public:
		//! returns the degree value of the angle
		virtual float getDegree() const = 0;
		//! returns the radian value of the angle
		virtual float getRadian() const = 0;

		//! converts given degree value to radian value
		static float degree2radian(float val);
		//! converts given radian value to degree value
		static float radian2degree(float val);

		//! @return The sine of the angle
		float sin();
		//! @return The cosine of the angle
		float cos();
		//! @return The cosine of the angle
		float tan();

	protected:
		//! Constructor
		Angle(float val);

		//! The value of the angle (with no specific unit)
		float mValue;
	};

	// Check:
	// subtracting degree from radian
	// adding radian to degree

	/**
	 * @brief A specific angle type that uses degree as the unit.
	 * @author Adil Yalcin
	 */
	class RENGAPI AngleDegree : public Angle {
	public:
		// Constructors
		explicit AngleDegree( float val=0 );
		AngleDegree( const Angle& _a );

		// Assignment
		AngleDegree& operator=( const Angle& _a );

		// Getters
		float getDegree() const;
		float getRadian() const;

		// Arithmetic operators
		AngleDegree operator+( const Angle& r ) const;
		AngleDegree operator-( const Angle& r ) const;
		AngleDegree operator*( const Angle& r ) const;
		AngleDegree operator/( const Angle& r ) const;
		AngleDegree operator*( float f ) const;
		AngleDegree operator/( float f ) const;

		AngleDegree& operator+=( const Angle& r );
		AngleDegree& operator-=( const Angle& r );
		AngleDegree& operator*=( const Angle& r );
		AngleDegree& operator/=( const Angle& r );
		AngleDegree& operator*=( float f );
		AngleDegree& operator/=( float f );

		// Comparison
		bool operator< ( const Angle& r ) const;
		bool operator<=( const Angle& r ) const;
		bool operator==( const Angle& r ) const;
		bool operator!=( const Angle& r ) const;
		bool operator>=( const Angle& r ) const;
		bool operator> ( const Angle& r ) const;
	};


	/**
	 * @brief A specific angle type that uses radian as the unit.
	 * @author Adil Yalcin
	 */
	class RENGAPI AngleRadian : public Angle {
	public:
		// Constructors
		explicit AngleRadian( float val=0 );
		AngleRadian( const Angle& _a );

		// Assignment
		AngleRadian& operator=( const Angle& _a );

		// Getters
		float getDegree() const;
		float getRadian() const;

		// Arithmetic operators
		AngleRadian operator+( const Angle& d ) const;
		AngleRadian operator-( const Angle& d ) const;
		AngleRadian operator*( float f ) const;
		AngleRadian operator/( float f ) const;

		AngleRadian& operator+=( const Angle& r );
		AngleRadian& operator-=( const Angle& r );
		AngleRadian& operator*=( float f );
		AngleRadian& operator/=( float f );

		// Comparison
		bool operator< ( const Angle& r ) const;
		bool operator<=( const Angle& r ) const;
		bool operator==( const Angle& r ) const;
		bool operator!=( const Angle& r ) const;
		bool operator>=( const Angle& r ) const;
		bool operator> ( const Angle& r ) const;
	};

} // namespace REng

#endif // _RENG_ANGLE_H_
