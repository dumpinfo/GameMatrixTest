/****************************************************************************
Copyright [2010] [Bilkent University]

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_EXTERNRENDERER_H_
#define _RENG_EXTERNRENDERER_H_

#include "REng/Prerequisites.h"

namespace REng {

	/*!
	 * @brief 
	 * - ViewportListener provides an interface for applications to specify 
	 *   external renderer components and attach them to REng
	 * @author Adil Yalcin
	 */
	class RENGAPI ViewportListener {
	public:
		ViewportListener();

		//! Called when a viewport listener is attached to a viewport
		//! @param The viewport this listener has been attached into
		//! @return True on success, false on error
		virtual bool init(const Viewport& vp);

		//! Called when 
		//! - Multi-view rendering is active and
		//! - View-first processing is used
		//! to signal that a specific view is about to be rendered
		//! setting render targets and camera settings
		virtual void preRenderView(uchar viewIndex);

		//! Called when 
		//! - Multi-view rendering is active and
		//! - View-first processing is used
		//! to signal that a specific view has been rendered
		virtual void postRenderView(uchar viewIndex);

		//! Called in the start of rendering operation of a viewport.
		virtual void preRenderAll();

		//! Called after rendering operation of a viewport is completed.
		virtual void postRenderAll();

		//! @return True on success, false on error
		virtual bool clear();

		//! @return True if this external renderer has been initialized, false otherwise
		bool isInited() const;

	protected:
		bool mIsInited;
	};
	
	//****************************************************
	inline ViewportListener::ViewportListener() : mIsInited(false) { ; }
	inline bool ViewportListener::isInited() const { 
		return mIsInited; 
	}
	inline bool ViewportListener::init(const Viewport& vp){ return true; }
	inline void ViewportListener::preRenderView(uchar viewIndex){ ; }
	inline void ViewportListener::postRenderView(uchar viewIndex){ ; }
	inline void ViewportListener::preRenderAll(){ ; }
	inline void ViewportListener::postRenderAll(){ ; }
	inline bool ViewportListener::clear(){ return true; }


} // namespace REng

#endif // _RENG_EXTERNRENDERER_H_
