/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_LIGHTING_MANAGER_H_
#define _RENG_LIGHTING_MANAGER_H_

#include "REng/Prerequisites.h"

// Is a singleton
#include "REng/Singleton.h"
// Illumination is calculated per node
#include "REng/Node.h"
// We need more lights, this one turns the knob on.
#include "REng/Light.h"
// We synchronize the lighting parameters to render passes
#include "REng/Material/RenderPass.h"

#include <vector>

namespace REng {

	/*!
	 *  @brief This class tries to offer an advanced interface to control the lighting of the scene.
	 *         Currently, it is used internally and should not be used the applications directly.
	 *         This should change when "shadow" related functionalities are added.
	 *  @note Uses abstract Light_Base type for all operations.
	 *  @author Adil Yalcin
	 */
	class RENGAPI LightingManager : public Singleton<LightingManager>, public NodeVisitor {
	public:
		LightingManager(void);
		~LightingManager(void);

		// Singleton access methods
		static LightingManager& getSingleton(void);
		static LightingManager* getSingletonPtr(void);

		//! Adds the given light as a scene light
		//! @note Called automatically on light object construction, DO NOT CALL REGISTER ELSEWHERE
		void registerLightToScene(Light_Base& light);

		//! One of the key methods of the lighting system
		//! Updates lighting parameters of the given mesh node
		//! @note The lights affecting meshes using the same shader can be different.
		//!       That's why we synch light parameters per mesh, not per material, as for render matrices.
		//! @return true if the lighting manager updates lighting parameters of the given pass
		bool uploadLightingParameters(RenderPass& pass);

		//! Updates mesh-light pairs when necessary
		//! @note For internal usage
		void _updateMeshLightPairs();

		//! Uploads the lights that illuminates whole scenes to shader variables
		//! @note For internal usage
		void _uploadLights_AllScene();

		//! Defines the maximum number of lights per type than can be assigned to a shading program
		//! @note 16 by default
		static const uchar MaxNumOfLights_PerType;

		//! The light can light the given node and its descendants
		//! @param node The scene node which will be illuminated by this light
		//! @param maxDepth The descendant of the node of maxDepth depth or larger 
		//!        will not be affected by this light
		//! @todo  Implement maxDepth logic
		void illuminateNode(Light_Base& light, SceneNode& node, uint maxDepth);

		//! Inverse affect of illuminateNode. If the light previously illuminated given node or its children,
		//! it no longer affects them after this call
		//! @param node The scene node which will not be illuminated by this light
		//! @param maxDepth The descendant of the node of depth smaller than maxDepth 
		//!        will not be affected by this light 
		//! @todo  Implement maxDepth logic
		void illuminateNodeNot(Light_Base& light, SceneNode& node, uint maxDepth);

		void visit(SceneNode& node);
		void visit(GroupNode& node);
		void visit(RootNode& node);
		void visit(SwitchGroupNode& node);
		void visit(LODGroupNode& node);
		void visit(MeshNode& node);
		void visit(CameraNode& node);
		void visit(LightNode& node);

		//! All the scene light's dirt bits are cleared after this call
		void clearSceneLightsDirt();

	private:

		//! The lights in these lists can illuminate only some of the meshes in the scene
		std::vector< std::vector<Light_Base*> > mLights_PerMesh;

		//! The lights in these lists can illuminate only some of the meshes in the scene
		std::vector< std::vector<Light_Base*> > mLights_Scene;

		enum VisitMode{
			Visit_Illum,
			Visit_IllumNot,
			Visit_Cull
		};

		struct LightInfo {
			Light_Base* theLight;
			bool illumScene;
		};

		VisitMode mMode;
	};

} // namespace REng 

#endif // _RENG_LIGHTING_MANAGER_H_
