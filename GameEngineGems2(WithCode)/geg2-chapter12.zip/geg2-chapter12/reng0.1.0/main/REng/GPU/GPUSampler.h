/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUSAMPLER_H_
#define _RENG_GPUSAMPLER_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include "REng/GPU/GPUResource.h"
#include "REng/GPU/GPUConfig.h"
#include "REng/GPU/RenderProperty.h"

#include <boost/shared_ptr.hpp>

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	//! Lists possible GPUSampler classes
	enum GPUSamplerType{
		GPUSamplerType_Res, ///! Resource
		GPUSamplerType_Tex  ///! Texture
	};

	/**
	 * @brief GPUSampler holds texture-independent texture sampling parameters.
	 *        It is a part of GPUTexture interface and an OpenGL client-side object
	 *        that can separately be bound/unbound.
	 * @author Adil Yalcin
	 */
	class GPUSampler {
	public:
		virtual ~GPUSampler();

		//! Returns the type information of GPUSampler class
		virtual GPUSamplerType getType() const=0;

		//! Updates state of the sampler object, the OpenGL calls differ wrt target (GPUResource/GPUTexture)
		bool updateState();

		//! Invalidates all state stored with the sampler object
		void invalidateState();

		//! Copies sampling state from the given sampler, specific type of sampler parameter is not important
		void copyState(const GPUSampler& sampler);

		//! The sampler property given as the parameter is updated to the value inside the parameter.
		void setSamplerProperty(const SamplerProp& prop);

		//! Updates the wrap mode sampling state of the sampler, if supported
		//! @note If you want to update an active Sampler resource objects state, call updateState afterwards.
		void setWrapMode(WrapAxis axis,WrapMode mode);

		//! Updates the minification filter sampling state of the sampler, if supported
		//! @note If you want to update an active Sampler resource objects state, call updateState afterwards.
		void setMinFilter(MinFilter filter);

		//! Updates the magnification filter sampling state of the sampler, if supported
		//! @note If you want to update an active Sampler resource objects state, call updateState afterwards.
		void setMagFilter(MagFilter filter);

		WrapMode getWrapMode(WrapAxis axis) const;
		MinFilter getMinFilter() const;
		MagFilter getMagFilter() const;

	protected:
		GPUSampler();

		//! @brief Sampler minification filter.
		SamplerProp_MinFilter mMinFilter;
		//! @brief Sampler magnification filter.
		SamplerProp_MagFilter mMagFilter;
		//! @brief Sampler wrap mode S axis.
		SamplerProp_WrapMode mWrapModeS;
		//! @brief Sampler wrap mode T axis.
		SamplerProp_WrapMode mWrapModeT;
		//! @brief Sampler wrap mode R axis.
		SamplerProp_WrapMode mWrapModeR;

		virtual bool updateMinFilter()=0;
		virtual bool updateMagFilter()=0;
		virtual bool updateWrapModeS()=0;
		virtual bool updateWrapModeT()=0;
		virtual bool updateWrapModeR()=0;
	};
	typedef boost::shared_ptr<GPUSampler> GPUSamplerPtr;

	/**
	 * @brief GPUSamplerResource holds texture-independent texture sampling parameters.
	 *
	 * If a GPUSamplerResource is bound to a texture unit with an attached texture, it 
	 * overwrites the sampler parameters of the attached texture object.
	 *
	 * @note This interface allows you to define a default target texture unit 
	 *       for ease of binding/unbinding operations. You can also specify target unit 
	 *       on bind/unbind time, for example, when you want to bind the same sampler 
	 *       object to multiple targets and manage this state yourself.
	 *
	 * @note Only supported in OpenGL 3.3> or if GL_ARB_sampler_objects is available
	 *       Not a part of OpenGL ES interface
	 * @author Adil Yalcin
	 */
	class GPUSamplerResource : public GPUSampler, public GPUResource {
	public:
		//! @creates a GPUSampler with the given default texture unit target
		GPUSamplerResource(uchar textureUnit);
		~GPUSamplerResource();
		
		GPUSamplerType getType() const;

		//! True if OpenGL version supports GPUSampler objects on server side
		static bool isSupported();

		//! Sets the default target texture unit to be used in no-parameter bind/unbind methods
		void setDefaultTargetUnit(uchar textureUnit);
		//! Gets the default target texture unit used in no-parameter bind/unbind methods
		uchar getDefaultTargetUnit() const;

		//! Binds the sampler to the default target texture unit
		void bindResource() const;
		//! Unbinds the sampler from the default target texture unit
		void unbindResource();

		//! Binds the sampler to the given texture unit. Does not update the default target unit.
		void bindResource(uchar textureUnit) const;
		//! Unbinds any attached sampler from the given texture unit.
		static void unbindResource(uchar textureUnit);

	private:
		void createResource();
		void destroyResource();

		uchar mDefaultTextureUnit;

		//! Checks whether the given texture unit index exceeds maximum number of available texture units.
		//! Logs on error
		static bool checkTextureUnit(uchar textureUnit);
		bool updateMinFilter();
		bool updateMagFilter();
		bool updateWrapModeS();
		bool updateWrapModeT();
		bool updateWrapModeR();
	};
	typedef boost::shared_ptr<GPUSamplerResource> GPUSamplerResourcePtr;

	/**
	 * @brief GPUSamplerTexture is used by GPUTextures to manage texture-object's 
	 *        sampling parameters, the main features of this class are 
	 *        supported by all platforms.
	 * @author Adil Yalcin
	 */
	class GPUSamplerTexture : public GPUSampler {
	public:
		void setTarget(TextureType type);
		TextureType getTarget() const;

		GPUSamplerType getType() const;

	private:
		TextureType mTarget;
		bool updateMinFilter();
		bool updateMagFilter();
		bool updateWrapModeS();
		bool updateWrapModeT();
		bool updateWrapModeR();
	};

	//////////////////////////////////////////////////////////////////////////
	// INLINE METHODS
	//////////////////////////////////////////////////////////////////////////

	inline GPUSampler::GPUSampler() { 
		mMinFilter.setMode(MinFilter_Nearest); // TODO: LINEAR for rectangle textures
		mMagFilter.setMode(MagFilter_Nearest);
		mWrapModeS.setWrapMode(WrapMode_Repeat); // TODO: ClampToEdge for rectangle textures
		mWrapModeT.setWrapMode(WrapMode_Repeat); // TODO: ClampToEdge for rectangle textures
		mWrapModeR.setWrapMode(WrapMode_Repeat); // TODO: ClampToEdge for rectangle textures
	}
	inline GPUSampler::~GPUSampler(){ ; }
	inline void GPUSampler::invalidateState(){
		mMinFilter.invalidate();
		mMagFilter.invalidate();
		mWrapModeS.invalidate();
		mWrapModeT.invalidate();
		mWrapModeR.invalidate();
	}
	inline void GPUSampler::setWrapMode(WrapAxis axis,WrapMode mode){
		switch(axis){
			case WrapAxis_S: mWrapModeS.setWrapMode(mode); break;
			case WrapAxis_T: mWrapModeT.setWrapMode(mode); break;
			case WrapAxis_R: mWrapModeR.setWrapMode(mode); break;
		}
	}
	inline void GPUSampler::setMinFilter(MinFilter filter){
		mMinFilter.setMode(filter);
	}
	inline void GPUSampler::setMagFilter(MagFilter filter){
		mMagFilter.setMode(filter);
	}
	inline WrapMode GPUSampler::getWrapMode(WrapAxis axis) const{
		switch(axis){
			default: // make compiler happy
			case WrapAxis_S: return mWrapModeS.getWrapMode();
			case WrapAxis_T: return mWrapModeT.getWrapMode();
			case WrapAxis_R: return mWrapModeR.getWrapMode();
		}
		return mWrapModeS.getWrapMode(); // make compiler happy, one more time
	}
	inline void GPUSampler::setSamplerProperty(const SamplerProp& prop){
		switch(prop.getType()){
			case RPT_mag_filter:
				setMagFilter(static_cast<const SamplerProp_MagFilter&>(prop).getMode());
				break;
			case RPT_min_filter:
				setMinFilter(static_cast<const SamplerProp_MinFilter&>(prop).getMode());
				break;
			case RPT_wrap_mode:
				setWrapMode(static_cast<const SamplerProp_WrapMode&>(prop).getAxis(), 
				        static_cast<const SamplerProp_WrapMode&>(prop).getWrapMode());
				break;
			default: break;
		}
	}
	inline MinFilter GPUSampler::getMinFilter() const{
		return mMinFilter.getMode();
	}
	inline MagFilter GPUSampler::getMagFilter() const{
		return mMagFilter.getMode();
	}
	inline bool GPUSampler::updateState(){
		if(mMinFilter.isSynchRequired()) if(updateMinFilter()==false) return false;
		if(mMagFilter.isSynchRequired()) if(updateMagFilter()==false) return false;
		if(mWrapModeS.isSynchRequired()) if(updateWrapModeS()==false) return false;
		if(mWrapModeT.isSynchRequired()) if(updateWrapModeT()==false) return false;
		if(mWrapModeR.isSynchRequired()) if(updateWrapModeR()==false) return false;
		return true;
	}
	inline void GPUSampler::copyState(const GPUSampler& sampler){
		setMinFilter(sampler.getMinFilter());
		setMagFilter(sampler.getMagFilter());
		setWrapMode(WrapAxis_S,sampler.getWrapMode(WrapAxis_S));
		setWrapMode(WrapAxis_T,sampler.getWrapMode(WrapAxis_T));
		setWrapMode(WrapAxis_R,sampler.getWrapMode(WrapAxis_R));
	}

	//////////////////////////////////////////////////////////////////////////
	// GPUSamplerResource

	inline bool GPUSamplerResource::isSupported(){
		static int _check(10);
		if(_check==false) return false;
	#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
		_check = false;
		return false;
	#else
//		int maj(GPUConfig::getSingleton().getGLVersionMajor());
//		if(maj>3) { _check = true; return true; }
//		if(maj<3) { _check = false; return false; }
//		int min(GPUConfig::getSingleton().getGLVersionMajor());
//		if(min>2) { _check = true; return true; }
		// should be enough
		return (_check = (GLEW_ARB_sampler_objects!=0));
	#endif
	}
	inline GPUSamplerResource::GPUSamplerResource(uchar textureUnit) { 
		setDefaultTargetUnit(textureUnit); 
		createResource();
	}
	inline GPUSamplerResource::~GPUSamplerResource(){
		destroyResource();
	}
	inline GPUSamplerType GPUSamplerResource::getType() const{
		return GPUSamplerType_Res;
	}

	inline void GPUSamplerResource::createResource(){
		if(!GPUSamplerResource::isSupported()) return;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		if(mResourceID!=0) return;
		glGenSamplers(1,&mResourceID);
		assert(mResourceID!=0);
		#endif
	}
	inline void GPUSamplerResource::destroyResource(){
		if(!GPUSamplerResource::isSupported()) return;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		if(mResourceID!=0) glDeleteProgram(mResourceID);
		#endif
	}

	inline void GPUSamplerResource::setDefaultTargetUnit(uchar textureUnit){
		if(!checkTextureUnit(textureUnit)) return;
		mDefaultTextureUnit = textureUnit;
	}
	inline uchar GPUSamplerResource::getDefaultTargetUnit() const{
		return mDefaultTextureUnit;
	}

	inline bool GPUSamplerResource::checkTextureUnit(uchar textureUnit){
		#ifdef RENG_DEBUG_BUILD
		GLint maxVal(GPUConfig::getSingleton().getGLMaxTextureImageUnits());
		if(textureUnit>maxVal){
			LOG4CPLUS_ERROR(Logger::getInstance("RSys"),"GPUSampler texture unit exceeds maximum texture unit count["<<maxVal<<"]");
			return false;
		}
		#endif
		return true;
	}

	inline void GPUSamplerResource::bindResource() const{
		bindResource(mDefaultTextureUnit);
	}
	inline void GPUSamplerResource::unbindResource(){
		unbindResource(mDefaultTextureUnit);
	}
	inline void GPUSamplerResource::bindResource(uchar textureUnit) const{
		if(!GPUSamplerResource::isSupported()) return;
		if(!checkTextureUnit(textureUnit)) return;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glBindSampler(textureUnit,mResourceID);
		#endif
	}
	inline void GPUSamplerResource::unbindResource(uchar textureUnit){
		if(!GPUSamplerResource::isSupported()) return;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glBindSampler(textureUnit,0);
		#endif
	}

	inline bool GPUSamplerResource::updateMinFilter(){
		if(!GPUSamplerResource::isSupported()) return false;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glSamplerParameteri(mResourceID,GL_TEXTURE_MIN_FILTER,mMinFilter.getMode());
		#endif
		mMinFilter.activate(); return true;
	}
	inline bool GPUSamplerResource::updateMagFilter(){
		if(!GPUSamplerResource::isSupported()) return false;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glSamplerParameteri(mResourceID,GL_TEXTURE_MAG_FILTER,mMagFilter.getMode());
		#endif
		mMagFilter.activate(); return true;
	}
	inline bool GPUSamplerResource::updateWrapModeS(){
		if(!GPUSamplerResource::isSupported()) return false;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glSamplerParameteri(mResourceID,GL_TEXTURE_WRAP_S,mWrapModeS.getWrapMode());
		#endif
		mWrapModeS.activate(); return true;
	}
	inline bool GPUSamplerResource::updateWrapModeT(){
		if(!GPUSamplerResource::isSupported()) return false;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glSamplerParameteri(mResourceID,GL_TEXTURE_WRAP_T,mWrapModeT.getWrapMode());
		#endif
		mWrapModeT.activate(); return true;
	}
	inline bool GPUSamplerResource::updateWrapModeR(){
		if(!GPUSamplerResource::isSupported()) return false;
		#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_DESKTOP
		glSamplerParameteri(mResourceID,GL_TEXTURE_WRAP_R,mWrapModeR.getWrapMode());
		#endif
		mWrapModeR.activate(); return true;
	}

	//////////////////////////////////////////////////////////////////////////
	// GPUSamplerTexture

	inline GPUSamplerType GPUSamplerTexture::getType() const{
		return GPUSamplerType_Tex;
	}
	inline void GPUSamplerTexture::setTarget(TextureType type){
		mTarget = type;
	}
	inline TextureType GPUSamplerTexture::getTarget() const{
		return mTarget;
	}
	inline bool GPUSamplerTexture::updateMinFilter(){
		glTexParameteri(mTarget, GL_TEXTURE_MIN_FILTER, mMinFilter.getMode());
		mMinFilter.activate();
		return true;
	}
	inline bool GPUSamplerTexture::updateMagFilter(){
		glTexParameteri(mTarget, GL_TEXTURE_MAG_FILTER, mMagFilter.getMode());
		mMagFilter.activate();
		return true;
	}
	inline bool GPUSamplerTexture::updateWrapModeS(){
		glTexParameteri(mTarget, GL_TEXTURE_WRAP_S, mWrapModeS.getWrapMode());
		mWrapModeS.activate();
		return true;
	}
	inline bool GPUSamplerTexture::updateWrapModeT(){
		// T Axis is invalid for 1D textures
		if(mTarget==TextureType_1D) return false;
		glTexParameteri(mTarget, GL_TEXTURE_WRAP_T, mWrapModeT.getWrapMode());
		mWrapModeT.activate();
		return true;
	}
	inline bool GPUSamplerTexture::updateWrapModeR(){
		// R Axis is invalid for 1D & 2D textures
		if(mTarget == TextureType_3D || mTarget==TextureType_Cube ){
			#if RENG_GL_PLATFORM == RENG_GL_PLATFORM_ES
				// NOTE: OpenGL ES 2.0 does not support R AXIS!
				// But if OES_texture_3D is supported, we can update the state!
				// TODO:Solve this issue!
				return false;
			#else
				if(mWrapModeR.isSynchRequired()) {
					glTexParameteri(mTarget, GL_TEXTURE_WRAP_R, mWrapModeR.getWrapMode());
					mWrapModeR.activate();
				}
			#endif
		}
		return true;
	}

} // namespace REng

#endif //_RENG_GPUSAMPLER_H_
