/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUSTRUCTURE_H_
#define _RENG_GPUSTRUCTURE_H_

#include "REng/Prerequisites.h"

#include "REng/Material/RenderPass.h"

namespace REng{
	
	//! Represents a custom GPU structure
	//! Instances of this reflect an instance of such a GPU structure.
	//! It allows modifying structure values on the engine-side and then synchronizing this data
	//! To shader programs
	//! @todo Not complete / stable yet!
	class RENGAPI GPUStructure {
	public:
		//! @return The shader code which defines the shader interface of this GPU structure
		virtual const char* getShaderStructCode() = 0;

		//! Synchronizes the GPU structure to the active pass (so the shading program)
		virtual bool synchWithPass(RenderPass& pass) = 0;

	private:
		//

	protected:
		//! To avoid allocation/releasing memory in each synch call, store temp data
		static char _uniformName[20];
		static char _uniformName_Param[30];
	};
} // namespace REng

#endif // _RENG_GPUSTRUCTURE_H_
