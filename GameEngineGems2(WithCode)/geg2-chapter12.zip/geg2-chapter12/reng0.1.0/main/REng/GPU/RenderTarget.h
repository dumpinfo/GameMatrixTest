/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPURENDERTARGET_H_
#define _RENG_GPURENDERTARGET_H_

#include "REng/Defines.h"

namespace REng{

	/*!
	 *  \brief Objects of type render-target can be bound as rendering targets, capturing fragment data.
	 *         There are two instantiatable render target types: GPUTexture and GPURenderBuffer
	 *  \author Adil Yalcin
	 */
	class RENGAPI RenderTarget {
	public:
		//! @return The current width of render-target.
		//! @note For GPUTexture, this denotes to 0th level mipmap's width.
		ushort getWidth() const;

		//! @return The current height of render-target.
		//! @note For GPUTexture, this denotes to 0th level mipmap's height.
		ushort getHeight() const;

		//! @return The current depth of render-target.
		//! @note For GPUTexture, this denotes to 0th level mipmap's depth.
		//! @note Equals to one for all but possibly the 3D-GPUTexture's (which has a 3D size).
		ushort getDepth() const;

		//! @return True if the render target can capture the given component (if getResolution>0)
		//! @remark To check if a render target can be a depth-target, use hasComponent(RTC_Depth)
		bool hasComponent(RenderTargetComp c) const;

		//! @return The bit-size of the given component in this render target.
		uchar getResolution(RenderTargetComp c) const;

		//! @return The internal format of the render buffer
		ImageFormat getInternalFormat() const;

		//! @return The sample count for multi-sampled rendering. 0 if multi-sampling is not enabled
		//! @note Currently, GPUTexture interface does not support native multi-sampling, although recent GL
		//!       versions (3.2 and above) support 2D-3D multi-sampled texture loading
		uchar getSamples() const;

	protected:
		//! @remark You cannot create a render target directly (only sub-classes can)!
		RenderTarget();
		
		//! @brief The current width of the renderable target
		ushort mWidth;

		//! @brief The current height of the renderable target
		ushort mHeight;

		//! @brief The current depth of the renderable target
		ushort mDepth;

		//! @brief Stores the bit-size of 6 individual components
		uchar mBitSize_Comp[6];

		//! @brief The sample count for multi-sampled rendering. 0 if multi-sampling is not enabled
		uchar mSamples;

		//! @brief The OpenGL texture/render buffer format.
		ImageFormat mInternalFormat;

		//! @brief Writes the render target specific parameters to the rendersystem logger.
		void logResourceParameters() const;

		//! @brief Updates resolution of components
		virtual void updateResolutions()=0;
	};

	/*!
	 * @brief Denotes a render target (surface) reserved by the operating system.
	 *        This render target holds what is shown in the application window.
	 * @note No manual attachment to a frame buffer can be done. It is automatically attached to a default frame buffer.
	 * @note You cannot set the storage / content directly. Use window create method in render system to create windows
	 *       which will create window render targets automatically.
	 * @note It is not a GPUResource as GPURenderBuffer or GPUTexture, so it cannot be bound/unbound.
	 * @author Adil Yalcin
	 */
	class RenderTarget_Window : public RenderTarget{
	public:
		~RenderTarget_Window();

	private:
		//! @note Instances can only be created by OS window system wrappers
		RenderTarget_Window();
		//! Updates the resolutions from OS window sizes.
		void updateResolutions();

		friend class RenderSystem;
	};

} // namespace REng

#endif // _RENG_GPURENDERTARGET_H_
