/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUFRAMEBUFFER_H_
#define _RENG_GPUFRAMEBUFFER_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include "REng/GPU/RenderTarget.h"
#include "REng/GPU/GPUResource.h"

#include <vector>

namespace REng{

	/*!
	 *  @brief The OpenGL renders into (and reads values from) a framebuffer.
    *         GL defines two classes of frame-buffers: window system-provided and application-created.
	 *         This class provides an abstraction over "frame-buffer object" operations.
	 *         The framebuffer-attachable images (RenderTarget) are texture images and render-buffer images.
	 *
	 *  @remark By allowing the images of a render-buffer to be attached to a framebuffer, 
	 *         the GL provides a mechanism to support off-screen rendering. Further, by allowing 
	 *         the images of a texture to be attached to a framebuffer, the GL provides 
	 *         a mechanism to support render to texture.
	 *
	 * @remark To attach a render target to frame buffer, use the render-target object interface.
	 * @author Adil Yalcin
	 */
	class RENGAPI GPUFrameBuffer : public GPUResource {
	public:
		//! @brief The default constructor
		//! @note GPU resource ID is created automatically
		GPUFrameBuffer();

		//! @brief The destructor releases HW resources that is assigned to this object
		~GPUFrameBuffer();

		/*! @brief Binds the framebuffer object to given target
		 *  @note  The behavior of this resource is different: A static bind target defines which this
		 *         framebuffer is bound to
		 *
		 * OpenGL ES 2.0 only supports "FrameBufferBindTarget_Default" parameter. 
		 * Any other target does not update the bound frame buffer in hw. 
		 */
		void bindResource() const;

		//! @brief Sets the bind target that will be used in operations listed in FBBindTarget member definition.
		//! @param target The framebuffer target that is requested to be activated.
		//! @return True if the given bind target is supported, false otherwise
		static bool setBindTarget(FrameBufferBindTarget target);

		//! @returns The active framebuffer bind target
		static FrameBufferBindTarget getBindTarget();

		/*! @brief Unbinds any currently bound framebuffer object from given target
		 * 
		 * OpenGL ES 2.0 only supports "FrameBufferBindTarget_Default" parameter. 
		 * Any other target does not update the bound frame buffer in hw.
		 */
		static void unbindResource();

		/*! @brief Binds the framebuffer object and updates the mCompletenessStatus status.
		 *  @param status This is updated to reflect final status. 
		 *                If function returns true, is equal to GL_FRAMEBUFFER_COMPLETE.
		 * 
		 * A framebuffer must be framebuffer complete to effectively be used as the draw or read framebuffer of the GL.
		 * The rules of framebuffer completeness are dependent on the properties of the attached images, 
		 * and on certain implementation-dependent restrictions.
		 */
		bool isComplete(GLenum &status);

		//! @return The width of the GPU frame buffer
		//! @note It is derived from attached render targets
		ushort getWidth() const;
		
		//! @return The height of the GPU frame buffer
		//! @note It is derived from attached render targets
		ushort getHeight() const;

		//! @return The number of color attachments for this frame buffer.
		uchar getColorAttachmentCount() const;

		//! A frame buffer has "multiple render targets" when it has multiple color attachments.
		bool isMultiRenderTarget();

		//! @return The depth image attached to this buffer  
		const RenderTarget* getDepthAttachment()   const;

		//! @return The stencil image attached to this buffer  
		const RenderTarget* getStencilAttachment() const;

		/*! @return The color image attached to this buffer
		 *  @param colorType If colorType is not FrameBufferAttachType_ColorN or
		 *         N exceeds the HW-specific limit, the first color [_Color0] binding is returned.
		 */
		const RenderTarget* getColorAttachment(FrameBufferAttachType colorType = FrameBufferAttachType_Color0)   const;

		//! @return The currently attached frame buffer object, NULL if a window-system buffer is active.
		static GPUFrameBuffer* getActiveFBO();

	private:
		//! @brief This is a global state that is used in functions 
		//!        - GPUFrameBuffer::bind, GPUFrameBuffer::unbind
		//!        - GPUFrameBuffer::isComplete, CRenderBuffer::
		//!        It is initially  FrameBufferBindTarget_Default (GL_FRAMEBUFFER) and supported in ES 2.0 and GL 3.1
		static FrameBufferBindTarget FBBindTarget;

		//! @brief Stores a pointer to active frame buffer object (null if default frame buffer is bound)
		static GPUFrameBuffer* ActiveFBO;

		//! @brief A framebuffer is complete if all of its attached images, and all framebuffer parameters required to 
		//!        utilize the framebuffer for rendering and reading, are consistently defined and meet the additional requirements.
		GLenum mCompletenessStatus;

		//! @brief If true, the completeness of the framebuffer object may have changed.
		bool mUpdated;

		//! @brief The depth attachment of the frame buffer
		const RenderTarget* mDepthAttachment;

		//! @brief The stencil attachment of the frame buffer
		const RenderTarget* mStencilAttachment;

		//! @brief Stores an array of color attachments. The number of elements is the maximum
		//!        number of simultaneous color attachments that a frame buffer object can have
		//! @remark The maximum number of supported color types is received through GPUConfig
		const RenderTarget** mColorAttachments;

		//! @brief Creates the hardware resource for the framebuffer
		void createResource();

		//! @brief Deletes the hardware resource of the framebuffer, if any
		void destroyResource();

		friend class GPURenderBuffer;
		friend class GPUTexture;
	};

} // namespace REng

#endif // _RENG_GPUFRAMEBUFFER_H_
