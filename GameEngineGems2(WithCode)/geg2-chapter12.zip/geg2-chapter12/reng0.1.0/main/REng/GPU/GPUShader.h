/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUSHADER_H_
#define _RENG_GPUSHADER_H_

#include "REng/Prerequisites.h"

#include "REng/GPU/GPUResource.h"
#include "REng/Defines.h"

namespace REng
{
	/*! 
	 *  \brief A convenience class for GLSL shaders.
	 *  \author Adil Yalcin, Attila Barsi (Holografika)
	 */
	class RENGAPI GPUShader : public GPUResource {
	public:
		//! @brief Constructor.
		//! @param shaderType The type of shader to define
		//! @note The HW resource is created when object is created. 
		//!       Before creating GPUShader objects, make sure OpenGL context is open.
		GPUShader(ShaderType shaderType);

		//! @brief Destructor.
		~GPUShader();

		/*! @brief Loads a GLSL shader from an in-memory text. Fills the compilation info log.
		 *  @param count Specifies the number of elements in the string and length arrays.
		 *  @param shaderText Specifies an array of pointers to strings containing the source 
		 *                     code to be loaded into the shader.
		 *  @return Load success/fail. */
		bool compileFromText(size_t count, const char** shaderText);

		/*! @brief Provides access to the shader type.
		 *  @return The shader type. */
		ShaderType getType() const;

	protected:
		//! @brief The shader type.
		ShaderType mShaderType;

		//! @brief Disabled the copy constructor.
		GPUShader(GPUShader&);

		//! @brief Disabled the assignment operator.
		GPUShader& operator=(GPUShader&);

		//! @brief Creates the hardware resource for the GL shader
		void createResource();

		//! @brief Deletes the hardware resource of the GL shader, if any
		void destroyResource();

		friend class GPUProgram;
	};

} // namespace REng

#endif // _RENG_GPUSHADER_H_
