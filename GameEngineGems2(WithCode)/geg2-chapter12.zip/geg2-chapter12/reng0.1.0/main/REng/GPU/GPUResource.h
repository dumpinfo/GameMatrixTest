/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPURESOURCE_H_
#define _RENG_GPURESOURCE_H_

#include "REng/Prerequisites.h"

namespace REng {

	/*!
	 *  @brief The basic abstract class for GPU resources that can be
	 *         created/destroyed by the application.
	 *  @note You cannot copy/assign resource objects, the OpenGL resources cannot be shared between
	 *        multiple objects / wrappers
	 *  @author Adil Yalcin
	 */
	class RENGAPI GPUResource {
	public:
		GPUResource() : mResourceID(0) { ; }

		//! @brief Creates the hardware resource
		virtual void createResource() = 0;

		//! @brief Deletes the hardware resource
		virtual void destroyResource() = 0;

		//! @note some identifiable objects (ex: shaders) are not bindable
		virtual void bindResource() const;

	protected:
		//! OpenGL id of this resource object
		GLuint mResourceID;

	private:
		GPUResource(const GPUResource& res){ (void)res; }
		GPUResource& operator==(const GPUResource& res){ (void)res; return *this;}
	};

	inline void GPUResource::bindResource() const { ; }


} // namespace REng

#endif // _RENG_GPURESOURCE_H_
