/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUBUFFER_H_
#define _RENG_GPUBUFFER_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include "REng/GPU/GPUResource.h"

#include <boost/shared_ptr.hpp>
#include <map>

namespace REng{

	#define BUFFER_OFFSET(i) ((char *)NULL + (i))

	//! Enumerates buffer types (software/hardware)
	enum BufferType{
		BufferType_CPU,
		BufferType_GPU
	};

	/*!
	 *  @brief A system memory buffer abstraction.
	 *  @author Adil Yalcin
	 */
	class RENGAPI SWBuffer{
	public:
		//~ @brief Allocates buffer memory.
		SWBuffer(size_t sizeInBytes);
		//~ @remark Releases buffer memory.
		~SWBuffer();
		//! @return The size of the buffer (in bytes count)
		size_t getSizeInBytes(void) const;
		//! @return The pointer to system buffer
		void* getBuffer();
		//! @brief Updates buffer storage content using an area of system memory.
		//!        Use this variant to update all the framebuffer content in a single simple call.
		//! @param data Must point to a valid memory of at least mSizeInBytes size. 
		void writeData(const void* data);

	protected:
		SWBuffer();
		//! @brief The system memory buffer
		void* mBuffer;
		size_t mSizeInBytes;
		//! @brief Allocates the memory resource for the buffer.
		void allocMem();
	};

	/*!
	 *  @brief GL buffer objects provide a mechanism that clients can use to allocate, initialize, and render from server-side memory.
	 *         The possible options -basically- are GPUVertexBuffer, index GPUIndexBuffer and pixel buffers.
	 *         TODO: add support for pixel buffers, texture buffers, transform feedback buffers, etc
	 *  @author Adil Yalcin
	 */ 
	class RENGAPI GPUBuffer : public GPUResource{
	public:
		//! @param type Defines the standard target type for the new buffer
		//! @param usageFreq, usageNature They are interpreted as a hint in the OpenGL server.
		//! @param useLocalBuffer If true, creates a buffer on the main memmory, and 
		//!        you can use this buffer for updating/accessing buffer content when required.
		GPUBuffer(BufferBindTarget type, BufferUsageFreq usageFreq, BufferUsageNature usageNature, bool useLocalBuffer = false);

		//! @brief The destructor automatically deletes any hardware resource assigned
		virtual ~GPUBuffer();

		//! @return The size of the buffer (in bytes count)
		size_t getSizeInBytes(void) const;

		//! @return The local buffer usage flag
		bool getUseLocalBuffer(void) const;

		//! @brief Binds this buffer resource to target
		//!        If target = None, it uses the current buffer's type, else it uses the provided type
		void bindResource() const;

		//! @brief Unbinds this buffer resource from target, using the provided buffer type (is None type is provided, has no affect)
		static void unbindResource(BufferBindTarget target);
	
		//! @brief Unbinds this buffer resource from target, using the current buffer's type
		void unbindResource() const;

		//! @brief Creates and initializes the GL server resource & its storage
		//!        The contents of the buffer object's data storage is undefined afterwards.
		//! @param bufSize If mSizeInBytes is not set previously, sets it to bufSize. Creates the buffer storage using the mSizeInBytes
		//!                If mSizeInBytes is 0, storage is not created.
		//! @note Use this method if you want to set the size of ae manually created the hardware buffer.
		void initStorage(size_t bufSize);

		//! @brief Updates buffer storage content using an area of system memory.
		//!        Use this variant to update all the opengl buffer content in a single simple call.
		//! @param data Must point to a valid memory of at least mSizeInBytes size. 
		//!             Or it can be 0, if you want to erase previous content (content becomes undefined).
		void writeData(const void* data);

		/*! @brief Updates buffer storage content using an area of system memory.
		    @param data        The source of the data to be written.
		    @param dataSize    The size of the data to write to, in bytes
		    @param rangeOffset The byte offset from the start of the buffer to start writing
		    @param discardWholeBuffer [OGRE] If true, this allows the driver to discard the entire buffer when writing,
					such that DMA stalls can be avoided; use if you can.
		*/
		void writeData(const void* data, size_t dataSize, size_t rangeOffset, bool discardWholeBuffer = true);

		//! @brief You can map the server-side memory to client memory using this function.
		//!        If local memory is used, the local memory is returned.
		void* mapResource(size_t dataSize, size_t rangeOffset, BufferAccessOp access, int accessDetails=0);
		
		//! @brief If the HW resource is currently mapped, call this method after 
		//!          you finish updating/reading the buffer content.
		//!        If local memory has been mapped with write access, 
		//!          the server-side memory is updated from local memory.
		void unmapResource();

	private:
		//! @brief The default bind target of the buffer
		BufferBindTarget mTarget;

		//! @brief The usage frequency of this buffer
		BufferUsageFreq   mUsageFreq;

		size_t mSizeInBytes;

		//! @brief The usage nature of this buffer
		BufferUsageNature mUsageNature;

		//! @brief This is true if this buffer is currently mapped for DMA.
		bool mIsResourceMapped;

		//! @brief Specifies whether a shadow buffer is assigned to this HW buffer. 
		//! @note The info can only be specified on construction time.
		bool mUseLocalBuffer;

		//! @brief Local buffer is a system-memory buffer that holds a copy of HW buffer
		//!        This is mainly used for faster buffer readback (or in platforms that do restrict totally hw readbacks).
		void* mLocalBuffer;

		//! @brief The access operation when the buffer is mapped (the local copy may be mapped also)
		BufferAccessOp mAccessOp;

		//! @brief Converts the  frequency and nature of this buffer to a valid GL type 
		//! @note  One-to-one/in-to/on-to correspondence for each possible pair exists
		GLenum getGLBufUsage();

		//! @brief Creates the hardware resource for the buffer. (No need to call this manually in public)
		void createResource();

		//! @brief Deletes the hardware resource of the buffer, if any. (No need to call this manually in public)
		void destroyResource();

		static void bindResource(BufferBindTarget target, GLuint resID);
	};

	/*!
	 *  @brief A memory buffer which can hold vertex data.
	 *         You cannot instantiate this class, use GPUVertexBuffer or SWVertexBuffer
	 *  @author Adil Yalcin
	 */
	class RENGAPI VertexBuffer{
	public:
		virtual ~VertexBuffer(){}
		//! @return The number of vertices this vertex buffer stores
		size_t getVertexSize(void) const;
		//! @return The number of vertices this vertex buffer stores
		size_t getVertexCount(void) const;
		virtual BufferType getType() const = 0;

	protected:
		VertexBuffer(size_t vertexSize, size_t numVertices);
		//! @brief The number of vertices this vertex buffer stores
		size_t mVertexCount;
		//! @brief The size of a single vertex data
		size_t mVertexSize;
	};
	typedef boost::shared_ptr<VertexBuffer> VertexBufferPtr;

	//! @brief an unsigned char is mapped to a hardware vertex buffer
	typedef std::map< unsigned char, VertexBufferPtr > VertexBufferBindingMap;


	/*!
	 *  @brief A memory buffer which can hold index (element) data.
	 *         You cannot instantiate this class, use GPUIndexBuffer or SWIndexBuffer
	 *  @author Adil Yalcin
	 */
	class RENGAPI IndexBuffer{
	public:
		virtual ~IndexBuffer(){}
		//! @return The data type of indexes stored in this buffer
		IndexDataType getIndexType(void) const;
		//! @return The number of indexes this index buffer stores
		size_t getIndexCount(void) const;
		//! @return The size in bytes of a single index in this buffer (derived from index data type)
		size_t getIndexSize(void) const;
		virtual BufferType getType() const = 0;
	protected:
		IndexBuffer(IndexDataType type, size_t numIndexes);
		//! @brief The data type of indexes stored in this buffer
		IndexDataType mType;
		//! @brief The number of indexes this index buffer stores
		size_t mIndexCount;
	};
	typedef boost::shared_ptr<IndexBuffer> IndexBufferPtr;

	class RENGAPI SWVertexBuffer : public VertexBuffer, public SWBuffer {
	public:
		SWVertexBuffer(size_t vertexSize, size_t numVertices);
		~SWVertexBuffer();
		BufferType getType() const;
	};
	typedef boost::shared_ptr<SWVertexBuffer> SWVertexBufferPtr;

	class RENGAPI SWIndexBuffer : public IndexBuffer, public SWBuffer {
	public:
		SWIndexBuffer(IndexDataType type, size_t numIndexes);
		~SWIndexBuffer();
		BufferType getType() const;
	};
	typedef boost::shared_ptr<SWVertexBuffer> SWVertexBufferPtr;


	/*!
	 *  @brief Use this extended buffer class if you want to additional vertex buffer related support.
	 *  @author Adil Yalcin
	 */ 
	class RENGAPI GPUVertexBuffer : public GPUBuffer, public VertexBuffer {
	public:
		GPUVertexBuffer(size_t vertexSize, size_t numVertices, BufferUsageFreq freq, BufferUsageNature nature, bool useShadowBuffer=false);
		~GPUVertexBuffer();
		BufferType getType() const;
		//! @brief A helper method which unbinds a buffer bound to OpenGL vertex buffer
		static void unbind();
	};
	typedef boost::shared_ptr<GPUVertexBuffer> GPUVertexBufferPtr;


	/*!
	 *  @brief Use this extended buffer class if you want to additional index buffer related support.
	 *  @author Adil Yalcin
	 *
	 *  @note For use by glDrawElements/glDrawRangeElements/glDrawElementsInstanced/glMultiDrawElements calls.
	 */ 
	class RENGAPI GPUIndexBuffer : public GPUBuffer, public IndexBuffer {
	public:
		GPUIndexBuffer(IndexDataType type, size_t numIndexes, BufferUsageFreq freq, BufferUsageNature nature, bool useShadowBuffer=false);
		~GPUIndexBuffer();
		BufferType getType() const;
		//! @brief A helper method which unbinds a buffer bound to OpenGL vertex buffer
		static void unbind();
	};
	typedef boost::shared_ptr<GPUIndexBuffer> GPUIndexBufferPtr;

}

#endif // _RENG_GPUBUFFER_H_

