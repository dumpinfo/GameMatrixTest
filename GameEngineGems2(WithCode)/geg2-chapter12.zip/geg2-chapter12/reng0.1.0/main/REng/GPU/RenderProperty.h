/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_RENDERPROPERTY_H_
#define _RENG_RENDERPROPERTY_H_

#include "REng/Prerequisites.h"
#include "REng/Defines.h"

#include "REng/GPU/GPUProgram.h"
#include "REng/GPU/GPUUniform.h"

#include <string>
#include <vector>

namespace REng{

	//! List of all possible render properties that can be assigned to a shader / render pass
	/*! Note: all render state components hold between 1 and 4 integral values
	 * RPT is ShortHand for "RenderTypeProperty"
	 * This structure provides simple RTTI. */
	enum RenderPropertyType{
		// Uniform type
		RPT_uniform,           ///< type info for RenderProp_Uniform

		// Generic types
		RPT_blending,          ///< type info for RenderProp_Blending
		RPT_blend_equation,    ///< type info for RenderProp_BlendEq
		RPT_blend_function,    ///< type info for RenderProp_BlendFunc

		RPT_stencil_test,      ///< type info for RenderProp_StencilTest
		RPT_stencil_function,  ///< type info for RenderProp_StencilFunc
		RPT_stencil_mask,      ///< type info for RenderProp_StencilMask
		RPT_stencil_operation, ///< type info for RenderProp_StencilOp

		RPT_depth_test,        ///< type info for RenderProp_DepthTest
		RPT_depth_mask,        ///< type info for RenderProp_DepthMask
		RPT_depth_function,    ///< type info for RenderProp_DepthFunc

		RPT_front_face,        ///< type info for RenderProp_FrontFace
		RPT_cull_face,         ///< type info for RenderProp_CullFace

		RPT_color_mask,        ///< type info for RenderProp_ColorMask
		
		RPT_poly_mode,         ///< type info for RenderProp_PolyMode

		RPT_line_width,        ///< type info for RenderProp_LineWidth

		// Texture types
		RPT_min_filter,        ///< type info for SamplerProp_MinFilter
		RPT_mag_filter,        ///< type info for SamplerProp_MagFilter
		RPT_wrap_mode,         ///< type info for SamplerProp_WrapMode

		RPT_none               /*!< this is also a marker for largest possible render property type */
	};


	/*!
	 *  \brief This class provides a common interface for render states.
	 *         The class defines activate/deactivate/parse/RTTI operations
	 *  \author Adil Yalcin
	 *
	 *  You cannot change render property type after construction
	 */
	class RENGAPI RenderProp{
	public :
		//! destructor
		virtual ~RenderProp() {}

		//! Default : Render states cannot be cloned
		virtual RenderProp * clone() const;

		//! each render state must define a begin procedure.
		virtual void activate() = 0;

		//! if render state must be rolled back after execution, fill in this function in derived classes
		virtual void deactivate() {}

		//! RTTI access
		RenderPropertyType getType() const;

		//! @brief: Using the MaterialScriptParser methods and active parse file, parses the next data
		//! @return True on successful parse operation 
		/*! for parsing (derived types should overwrite this function to be able to easily read from files) */
		virtual bool parseFromFile() { return true; }
	protected:
		RenderProp(RenderPropertyType type = RPT_none);
	private:
		RenderPropertyType mType; ///< RTTI
	};

	/*!
	 *  \brief Allows easily separation of generic properties from texture properties.
	 *         The class defines activate/deactivate/parse/RTTI operations
	 *  \author Adil Yalcin
	 *
	 *  Uniform property has already its own -single- type
	 */
	class RENGAPI RenderProp_Generic :public RenderProp{
	protected:
		//! @brief The only constructor for generic render property.
		RenderProp_Generic(RenderPropertyType t);
	public:
		//! @brief To provide a common base for getting tracking option.
		//!        If not overwritten, it returns false.
		virtual bool isTracked() const;

		//! @brief To provide a common base for setting tracking option.
		//!        If not overwritten, has no effect.
		virtual void setTracked(bool flag);
	};

	//! @remark Pointer is used, because the data is an abstract class.
	typedef std::vector<RenderProp_Generic*> RenderPropGenericList;

	//! lists all possible uniform types in hardware
	enum UniformType {
		UniformType_Float_1,   ///< Float value 1 component
		UniformType_Float_2,   ///< Float value 2 component
		UniformType_Float_3,   ///< Float value 3 component
		UniformType_Float_4,   ///< Float value 4 component
		UniformType_Int_1,     ///< Int value 1 component
		UniformType_Int_2,     ///< Int value 2 component
		UniformType_Int_3,     ///< Int value 3 component
		UniformType_Int_4,     ///< Int value 4 component
		UniformType_Matrix_22, ///< Matrix value [2x2]=4 component
		UniformType_Matrix_33, ///< Matrix value [3x3]=9 component
		UniformType_Matrix_44, ///< Matrix value [4x4]=16 component
		UniformType_None       ///< This is also a marker for largest possible uniformType
	};

	enum UniformAutoName{
		// UniformType_Matrix_44
		UAN_ModelMatrix = 0,
		UAN_ModelMatrixInverse,
		UAN_ModelMatrixTranspose,
		UAN_ModelMatrixInverseTranspose,
		UAN_ViewMatrix,
		UAN_ViewMatrixInverse,
		UAN_ViewMatrixTranspose,
		UAN_ViewMatrixInverseTranspose,
		UAN_ProjectionMatrix,
		UAN_ProjectionMatrixInverse,
		UAN_ProjectionMatrixTranspose,
		UAN_ProjectionMatrixInverseTranspose,
		UAN_ModelViewMatrix,
		UAN_ModelViewMatrixInverse,
		UAN_ModelViewMatrixTranspose,
		UAN_ModelViewMatrixInverseTranspose,
		UAN_ViewProjectionMatrix,
		UAN_ViewProjectionMatrixInverse,
		UAN_ViewProjectionMatrixTranspose,
		UAN_ViewProjectionMatrixInverseTranspose,
		UAN_ModelViewProjectionMatrix,
		UAN_ModelViewProjectionMatrixInverse,
		UAN_ModelViewProjectionMatrixTranspose,
		UAN_ModelViewProjectionMatrixInverseTranspose,
		UAN_Max_Matrix_44_Type, ///< an ending marker for auto-names of type matrix 44

		UAN_NormalMatrix,       ///< The 3x3 matrix uniform that can correctly transform a normal vector
		UAN_Max_Matrix_33_Type, ///< an ending marker for auto-names of type matrix 33

		// UniformType_Int_1
		UAN_FPS,                ///< The current FPS of the application (updated once per sec)
		UAN_ViewportWidth,      ///< The rendered viewport width
		UAN_ViewportHeight,     ///< The rendered viewport height
		UAN_ViewportDimensions, ///< The rendered viewport dimension (width,height)
		UAN_MultiViewNo,        ///< For multi-view techniques, stores the active rendering view
		UAN_RenderPassIndex,    ///< For multi-pass techniques, stores the active rendering pass
		UAN_Max_Int_1_Type,     ///< an ending marker for auto-names of type int 1

		UAN_InvViewportWidth,      ///< 1/UAN_ViewportWidth
		UAN_InvViewportHeight,     ///< 1/UAN_ViewportHeight
		UAN_InvViewportDimensions, ///< 1/UAN_ViewportDimensions
		UAN_Time,                  ///< TODO
		UAN_Max_Float_1_Type,      ///< an ending marker for auto-names of type 1
		
		UAN_ViewPosition,     ///< World-space position of camera
		UAN_ViewDirection,    ///< World-space direction vector of camera
		UAN_ViewRight,        ///< World-space right vector of camera
		UAN_ViewUp,           ///< World-space up vector of camera
		UAN_Max_Float_3_Type, ///< an ending marker for auto-names of type 1

		UAN_None              ///< also an ending marker for autoname count
	};

	//! @brief A helper function that transforms the uniform auto name to a uniform type
	UniformType getUniTypeFromUniAutoName(UniformAutoName name);

	//! @brief A helper function that gets the component count of given uniform type
	unsigned char getComponentCount(UniformType utype);

	//! @brief Conversion helper (str ---> Uniform Auto Name)
	//! @param str string to convert from
	//! @param uan render property type that is updated on success
	//! @return true on successful conversion
	bool convertStrToUAN(const char* str, UniformAutoName &uan);

	/*!
	 *  \brief One very important specialized render state is the uniform state!
	 *         This one is for material shaders and render passes
	 *  \author Adil Yalcin
	 */
	class RENGAPI RenderProp_Uniform : public RenderProp{
	public:
		//! @note You cannot change data type or uniform name after you create the object
		//! @note If a autonName other than None is supplied, the type is automatically derived from autoname
		RenderProp_Uniform(const std::string& name, UniformType type, UniformAutoName autoname = UAN_None);
		~RenderProp_Uniform();
		
		//! Clones the current uniform property
		//! The uniform property that is returned is NOT bound to a program
		RenderProp* clone() const;

		//! @brief getter for name
		const std::string& getName(void) const;

		//! @brief getter for type
		UniformType getType(void) const;

		//! @return The autoname of this uniform
		UniformAutoName getAutoName() const;

		//! @brief gets the uniform shader location. Valid only if \see isBound
		//! @return Uniform shader location if \see isBound, else -1.
		GLint getLocation() const;

		//! @brief Uploads current uniform data to GPU
		/*! Note: activate only when uniform property requires synchronization to server. 
		    @see requiresSynch */
		void activate();

		//! @brief Fills in uniform data ( memory space and content)
		/*! Note: GLSLUniform creation is delayed (@see bindToProgram ) */
		bool parseFromFile();

		//! @return True if the OpenGL uniform is out-of-date (you have updated your uniform)
		bool requiresSynch() const;

		//! @brief Use this method to set float types
		/*! if the specified format does not have the given index data or types do not match, 
		    function call will have no affect. */
		void setDataAtIndex(uchar index, GLfloat data);

		//! @brief Use this method to set integer types
		//! if the specified format does not have the given index data or types do not match, 
		//! function call will have no affect.
		void setDataAtIndex(uchar index, GLint data);

		//! @brief Use this method to directly set the internal uniform data storage (copy from given storage).
		//! @param storage The pointer to memory space where the uniform parameters are stored.
		//! @param storageSize The size of storage (in bytes)
		//! 
		//! If storage is 0, no update is done. 
		//! You have to make sure that storageSize does not exceed the result of getDataSize.
		void setData(const void* storage, size_t storageSize);

		//! @brief Allows copying of data from this uniform to the uniform given.
		//! @note : The uniforms must have the same type (same data size)
		void copyData(RenderProp_Uniform& copyTo) const;

		//! @brief Using the given program object, binds OpenGL uniform data to mapping.
		//! @return True if operation is successful.
		bool bindToProgram(const GPUProgram& program);

		//! @return True if this uniform is bound to a program
		bool isBoundToProgram() const;

		//! @return The size of data storage allocated (in bytes)
		size_t getDataSize() const;

	private:
		//! @brief Name of the hardware shader uniform
		/*! Note: GLUniform holds this information too, but GLUniform is only created shaders are compiled*/
		std::string  mUniformName;

		//! @brief Type of uniform
		UniformType  mUniformType;

		//! @brief Stores the uniform data that is to be uploaded to HW
		/*! uniform data type and size is dependent on UniformType. A generic void pointer is used here. */
		void *mUniformData;

		//! @brief If mAutoName is not None, this uniform is automatically updated in each frame 
		//!        by the rendering engine to match the auto-name semantic
		UniformAutoName mAutoName;

		//! @brief A pointer to Hardware Uniform interface
		/*! The object is created when @see bindToProgram is called.
		    If the render property is not bound to a GL uniform data, this is 0. 
		    You cannot access GLUniform publicly. This is on purpose.*/
		GPUUniform  *mGLUniform;

		//! Set to true if uniform data is updated and requires synch with hardware
		/*! This is set to false when current data is uploaded to HW */
		bool mSynchRequired;

		//! disable copy constructor
		RenderProp_Uniform(const RenderProp_Uniform&);

		//! disable assignment operator
		RenderProp_Uniform& operator=(RenderProp_Uniform&);
	};
	typedef std::vector<RenderProp_Uniform*> UniformPropertyList;

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glBlendEquationSeparate
	 */
	class RENGAPI RenderProp_BlendEq : public RenderProp_Generic{
	public:
		RenderProp_BlendEq(BlendEqMode rgbMode=BlendEqMode_Func_Add, BlendEqMode alphaMode=BlendEqMode_Func_Add);
		~RenderProp_BlendEq();

		RenderProp * clone() const;

		void activate();
		bool parseFromFile();

		void setModes(BlendEqMode  rgbMode, BlendEqMode  alphaMode);
		void getModes(BlendEqMode& rgbMode, BlendEqMode& alphaMode) const;
	private:
		BlendEqMode mRGBMode;   ///< Default : BlendEqMode_Func_Add
		BlendEqMode mAlphaMode; ///< Default : BlendEqMode_Func_Add
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glBlendFuncSeparate
	 */
	class RENGAPI RenderProp_BlendFunc : public RenderProp_Generic{
	public:
		RenderProp_BlendFunc(
			BlendFuncMode srcRGB  =BlendFuncMode_Zero, 
			BlendFuncMode dstRGB  =BlendFuncMode_Zero,
			BlendFuncMode srcAlpha=BlendFuncMode_Zero,
			BlendFuncMode dstAlpha=BlendFuncMode_Zero);
		~RenderProp_BlendFunc();

		RenderProp * clone() const;

		void activate();
		bool parseFromFile();

		void setModes(BlendFuncMode  srcRGB, BlendFuncMode  dstRGB, 
			BlendFuncMode  srcAlpha, BlendFuncMode  dstAlpha);
		void getModes(BlendFuncMode &srcRGB, BlendFuncMode &dstRGB, 
			BlendFuncMode &srcAlpha, BlendFuncMode &dstAlpha) const;
	private:
		//! Defaults (all) : BlendFuncMode_Zero
		BlendFuncMode mSrcRGB, mDstRGB, mSrcAlpha, mDstAlpha;
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glStencilFuncSeparate
	 */
	class RENGAPI RenderProp_StencilFunc : public RenderProp_Generic{
	public:
		RenderProp_StencilFunc(FaceType face=FaceType_Front, 
			CompareFunc func=CompareFunc_Always, GLint reference=0, GLuint mask=GLuint(-1));
		~RenderProp_StencilFunc();

		RenderProp * clone() const;

		void activate();
		bool parseFromFile();

		void setProperty(FaceType  face, CompareFunc  func, GLint  reference, GLuint  mask);
		void getProperty(FaceType& face, CompareFunc& func, GLint& reference, GLuint& mask) const;
		
		FaceType getFace() const;
		CompareFunc getFunction() const;
		GLint  getReference() const;
		GLuint getMask() const;

	private:
		FaceType mFace;        ///< Default : FaceMode_Front
		CompareFunc mFunction; ///< Default : FunctionMode_Always
		GLint  mReference;     ///< Default : 0
		GLuint mMask;          ///< Default : -1 (all bits set to 1)
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glStencilMaskSeparate
	 */
	class RENGAPI RenderProp_StencilMask : public RenderProp_Generic{
	public:
		RenderProp_StencilMask(FaceType face=FaceType_Front, GLuint mask=GLuint(-1));
		~RenderProp_StencilMask();

		RenderProp * clone() const;
		
		void activate();
		bool parseFromFile();
		
		void setProperty(FaceType  face, GLuint  mask);
		void getProperty(FaceType& face, GLuint& mask) const;
		
		FaceType getFace() const;
		GLuint   getMask() const;
		
		void setFace(FaceType face);
		void setMask(GLuint mask);

	private:
		FaceType mFace; ///< Default : FaceMode_Front
		GLuint mMask;   ///< Default : -1 (all bits set to 1)
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glStencilOpSeparate
	 *
	 *  Note: Deactivate defaults to ops of mFace to KEEP
	 */
	class RENGAPI RenderProp_StencilOp : public RenderProp_Generic{
	public:
		RenderProp_StencilOp(
			FaceType face=FaceType_Front, 
			OperationMode stencilFail=OperationMode_Keep, 
			OperationMode depthFail  =OperationMode_Keep, 
			OperationMode depthPass  =OperationMode_Keep);
		~RenderProp_StencilOp();

		RenderProp * clone() const;

		void activate();
		void deactivate(); ///< Default : KEEP
		bool parseFromFile();

		void setProperty(FaceType  face, OperationMode  stencilFail, 
			OperationMode  depthFail, OperationMode  depthPass );
		void getProperty(FaceType& face, OperationMode& stencilFail, 
			OperationMode& depthFail, OperationMode& depthPass ) const;
		
		FaceType getFace() const;
		OperationMode getStencilFail() const;
		OperationMode getDepthFail() const;
		OperationMode getDepthPass() const;
	private:
		FaceType mFace;             ///< Default : FaceMode_Front
		OperationMode mStencilFail; ///< Default : OperationMode_Keep
		OperationMode mDepthFail;   ///< Default : OperationMode_Keep
		OperationMode mDepthPass;   ///< Default : OperationMode_Keep
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glDepthFunc
	 *
	 *  Note: Deactivate defaults to LEQUAL
	 */
	class RENGAPI RenderProp_DepthFunc : public RenderProp_Generic{
	public:
		RenderProp_DepthFunc(CompareFunc func=CompareFunc_Less);
		~RenderProp_DepthFunc();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate();  ///< defaults to LEQUAL
		bool parseFromFile();

		void setFunction(CompareFunc func);
		CompareFunc getFunction(void) const;

	#ifndef _DO_NOT_TRACK_DEPTHFUNC
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif
	private:
		CompareFunc mFunction; ///< Default : FunctionMode_Less
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glDepthMask
	 *
	 *  Note: Deactivate defaults to enabled
	 */
	class RENGAPI RenderProp_DepthMask : public RenderProp_Generic{
	public:
		RenderProp_DepthMask(bool flag=true);
		~RenderProp_DepthMask();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate();
		bool parseFromFile();
		void setFlag(bool flag);
		bool getFlag() const;

	#ifndef _DO_NOT_TRACK_DEPTHMASK
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		GLboolean mFlag; ///< Default : True
	};

	/*!
	*  \author Adil Yalcin
	*  \brief wraps over glColorMask
	*
	*  Note: Deactivate defaults all RGBA values to enabled
	*/
	class RENGAPI RenderProp_ColorMask : public RenderProp_Generic{
	public:
		RenderProp_ColorMask(bool red=true, bool green=true, bool blue=true, bool alpha=true);
		~RenderProp_ColorMask();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate();
		bool parseFromFile();
		void setFlags(bool  red, bool  green, bool  blue, bool  alpha);
		void getFlags(bool& red, bool& green, bool& blue, bool& alpha) const;

	#ifndef _DO_NOT_TRACK_COLORMASK
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		enum ColorFlags{
			ColorFlagRed   = 0x01,
			ColorFlagGreen = 0x02,
			ColorFlagBlue  = 0x04,
			ColorFlagAlpha = 0x08
		};
		uchar mFlags; ///< Default : True
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glFrontFace
	 *
	 *  Note: Deactivate defaults to CCW
	 */
	class RENGAPI RenderProp_FrontFace : public RenderProp_Generic{
	public:
		RenderProp_FrontFace(FaceOrientation mode=FaceOrientation_CCW);
		~RenderProp_FrontFace();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to CCW
		bool parseFromFile();

		void setMode(FaceOrientation mode);
		FaceOrientation getMode(void) const;

	#ifndef _DO_NOT_TRACK_FRONTFACE
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		FaceOrientation mMode; ///< Default : FaceOrientation_CCW
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glCullFace
	 *
	 *  Note: Deactivate defaults to BACK
	 */
	class RENGAPI RenderProp_CullFace : public RenderProp_Generic{
	public:
		RenderProp_CullFace(FaceType mode=FaceType_Back);
		~RenderProp_CullFace();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to FaceType_Back
		bool parseFromFile();

		void setMode(FaceType mode);
		FaceType getMode(void) const;

	#ifndef _DO_NOT_TRACK_CULLFACE
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		FaceType mMode; ///< Default to FaceType_Back
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glLineWidth.
	 *
	 *  Note: Deactivate defaults to line width 1.0
	 */
	class RENGAPI RenderProp_LineWidth : public RenderProp_Generic{
	public:
		RenderProp_LineWidth(float width=1.0f);
		~RenderProp_LineWidth();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to 1.0
		
		bool parseFromFile();

		void setWidth(float width);
		float getWidth() const;
	
	#ifndef _DO_NOT_TRACK_LINEWIDTH
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		GLfloat mWidth; ///< Default : 1.0
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glPolygonMode. ( HAS NO EFFECT ON ES 2.0 CONFIGURATIONS)
	 *
	 *  Note: Deactivate defaults to BACK
	 */
	class RENGAPI RenderProp_PolyMode : public RenderProp_Generic{
	public:
		RenderProp_PolyMode();
		~RenderProp_PolyMode();

		RenderProp * clone() const;

		static void setDefault();

		//! HAS NO EFFECT ON ES 2.0 CONFIGURATIONS
		void activate();

		//! HAS NO EFFECT ON ES 2.0 CONFIGURATIONS
		void deactivate(); ///< defaults to Fill
		
		bool parseFromFile();

		void setFaceMode(FaceType mode);
		void setPolyMode(PolygonMode mode);

		FaceType getFaceMode() const;
		PolygonMode getPolyMode() const;

	#ifndef _DO_NOT_TRACK_POLYMODE
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		FaceType    mFaceMode; ///< Default : FaceMode_Front
		PolygonMode mPolyMode; ///< Default : PolygonMode_Fill
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glEnable / glDisable with GL_DEPTH_TEST
	 */
	class RENGAPI RenderProp_DepthTest : public RenderProp_Generic{
	public:
		RenderProp_DepthTest(bool flag=true);
		~RenderProp_DepthTest();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to enabled

		bool parseFromFile();

		void setEnabled(bool flag);
		bool getEnabled() const;

	#ifndef _DO_NOT_TRACK_DEPTHTEST
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		bool mEnabled;    ///< Default : enabled
	};

	/*!
	 *  \author Adil Yalcin
	 *  \brief wraps over glEnable / glDisable with GL_BLEND
	 */
	class RENGAPI RenderProp_Blending : public RenderProp_Generic{
	private:
		bool mEnabled;    ///< Default : disabled
	public:
		RenderProp_Blending(bool flag=false);
		~RenderProp_Blending();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to disabled

		bool parseFromFile();

		void setEnabled(bool flag);
		bool getEnabled() const;

	#ifndef _DO_NOT_TRACK_BLENDING
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif
	};

	/*!
	 *  \brief wraps over glEnable / glDisable with GL_BLEND
	 *  \author Adil Yalcin
	 */
	class RENGAPI RenderProp_StencilTest : public RenderProp_Generic{
	public:
		RenderProp_StencilTest(bool flag=false);
		~RenderProp_StencilTest();

		RenderProp * clone() const;

		static void setDefault();

		void activate();
		void deactivate(); ///< defaults to disabled

		bool parseFromFile();

		void setEnabled(bool flag);
		bool getEnabled() const;

	#ifndef _DO_NOT_TRACK_STENCILTEST
	private:
		static bool mIsTracked;
	public:
		bool isTracked() const;
		void setTracked(bool flag);
	#endif

	private:
		bool mEnabled;    ///< Default : disabled
	};

	/************************************************************************/
	/* SAMPLER PROPERTIS                                                    */
	/************************************************************************/

	/*!
	 *  @brief Allows easy separation of texture sampler properties from generic properties.
	 *  @note  They do not modify GL state directly, activate() methods map to no-op.
	 *         GPUSampler abstraction is responsible from updating GL state 
	 *         GPUSampler can map to different targets for the same render property.
	 *  @author Adil Yalcin
	 */
	class RENGAPI SamplerProp : public RenderProp {
	public:
		//! for optimal performance, check if synchronization is required before activating the property.
		bool isSynchRequired() const;
		//! Turns synch requirement on
		void invalidate();
		//! Clears synch request, does nothing more
		void activate();
	protected:
		//! the synchronization is not global, it tracks only a single texture's state.
		bool mRequiresSycnh;
		//! Cannot directly construct a texture render property. Use one of the sub-classes.
		SamplerProp(RenderPropertyType t);
	};

	class RENGAPI SamplerProp_MinFilter : public SamplerProp{
	public:
		SamplerProp_MinFilter();
		~SamplerProp_MinFilter();

		bool parseFromFile();

		void setMode(MinFilter mode);
		MinFilter getMode() const;
	private:
		//! Default : TextureMinificationFilter_Nearest
		MinFilter mMode;
	};

	class RENGAPI SamplerProp_MagFilter : public SamplerProp{
	public:
		SamplerProp_MagFilter();
		~SamplerProp_MagFilter();

		bool parseFromFile();

		void setMode(MagFilter mode);
		MagFilter getMode() const;
	private:
		//! Default : TextureMagnificationFilter_Nearest
		MagFilter mMode;
	};

	/*!
	 *  \note WrapMode_ClampToBorder is not supported in OpenGL ES 2.0
	 */
	class RENGAPI SamplerProp_WrapMode : public SamplerProp{
	private:
		//! Default : WrapMode_ClampToEdge
		WrapAxis mAxis;
		//! Default : TextureWrapAxis_S
		WrapMode mWrapMode;
	public:
		SamplerProp_WrapMode();
		~SamplerProp_WrapMode();

		bool parseFromFile();

		void setWrapMode(WrapMode mode);
		void setAxis(WrapAxis mode);

		WrapMode getWrapMode() const;
		WrapAxis getAxis() const;
	};
} // namespace REng

#endif // _RENG_RENDERPROPERTY_H_
