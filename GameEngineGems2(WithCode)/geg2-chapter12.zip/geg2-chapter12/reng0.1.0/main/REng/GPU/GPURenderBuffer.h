/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPURENDERBUFFER_H_
#define _RENG_GPURENDERBUFFER_H_

#include "REng/Prerequisites.h"

// GPURenderBuffer is a render target
#include "REng/GPU/RenderTarget.h"
#include "REng/GPU/GPUResource.h"

#include "REng/Defines.h"

namespace REng {

	/*!
	 *  \brief A render buffer is data storage object containing a single image 
	 *         of a renderable internal format.
	 *  \author Adil Yalcin
	 */
	class RENGAPI GPURenderBuffer : public RenderTarget, public GPUResource {
	public:
		//! @brief Creates a renderbuffer (hw resource is not created)
		GPURenderBuffer();
		
		//! @brief The destructor (deletes the hw resource)
		~GPURenderBuffer();

		//! @brief Binds the render buffer.
		//! @note If there exists no hardware resource, this has no affect.
		void bindResource() const;

		//! @brief Unbinds the render buffer (static variant)
		static void unbindResource();

		//! @return True, if the queried renderbuffer object is currently bounded as the active renderbuffer object.
		bool isBound();

		//! @brief You can check if a hw renderbuffer is currently binded in GL server?
		static bool isHWBindingNull();

		/*! @brief establishes the data storage, format, and dimensions of a renderbuffer object’s image.
		 *  \param internalFormat age. Must be one of the color-renderable, depth-renderable, or stencil-renderable formats.
		 *  \param width  The width dimension in pixels of the renderbuffer
		 *  \param height The height dimension in pixels of the renderbuffer
		 *  \param samples The multi-sample property of the renderbuffer (ignored in ES 2.0 configurations)
		 *                 For a "regular" storage allocation call, it should be set to 0.
		 *  \return True, if the hardware render buffer is successfully updated. False, otherwise.
		 *  \todo   Multi-sample storage for OpenGL 3.1
		 *
		 *  \return False, if the internal format cannot be used as a renderbuffer internal format TODO
		 */
		bool storage(ImageFormat internalFormat,unsigned short width, unsigned short height, unsigned char samples=0);

		//! @brief Use this if you want to attach the render buffer to a specific attachment (ex: color, in configurations supporting MRT)
		//! @param attachType The type of attachment you would like to use the renderbuffer for.
		//! @return False, if the render buffer could not be bound
		//! @note Uses the CHWFrameBuffer::getBindTarget() setting to retrieve the framebuffer bind target
		bool attachToActiveFBO(FrameBufferAttachType attachType);

		/*! @brief A helper function which tries to find a suitable attachment type.
		 *         It uses color0 as the default color attachment target
		 *  @return True, if a suitable attachment type could be detected and the render buffer is bound
		 */
		bool attachToActiveFBO();

		//! @brief Tries to bind this render buffer to active FBO depth target
		//! @return False, if internal type has no depth component
		bool attachToActiveFBODepth();

		//! @brief Tries to bind this render buffer to active FBO stencil target
		//! @return False, if internal type has no stencil component
		bool attachToActiveFBOStencil();

		//! @brief YOU SHOULD NOT CALL THIS METHOD. ONLY RPOVIDED FOR DEBUGGING PURPOSES.
		//! @remark If available functionality does not offer what you need, update 
		//!         (or request an update to) this wrapper.
		GLuint getResourceID() const;

	protected:
		//! @brief The active RenderBuffer in the program OpenGL context
		static GLuint ActiveRenderBufferID;

		//! @brief Creates a hardware resource for this renderbuffer
		void createResource();

		//! @brief Deletes the hardware resource of this renderbuffer, if any
		void destroyResource();

		void updateResolutions();

		friend class GPUFrameBuffer;
	};

} // namespace REng

#endif // _RENG_GPURENDERBUFFER_H_
