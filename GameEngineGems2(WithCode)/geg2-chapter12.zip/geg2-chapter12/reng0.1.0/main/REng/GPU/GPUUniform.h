/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUUNIFORM_H_
#define _RENG_GPUUNIFORM_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include <string>

namespace REng {

	/*!
	 *  \brief Convenience class for OpenGL GLSL uniform variables.
	 *  \author Attila Barsi (Holografika), Adil Yalcin
	 */
	class RENGAPI GPUUniform {
	public:
		/*! @brief Constructor
		 *  @param glslProgram The GLSL program to get the unifrom from.
		 *  @param uniformName The name of the GLSL unifrom parameter.
		 */
		GPUUniform(const GPUProgram& glslProgram,const char* uniformName);

		//! @brief Destructor.
		~GPUUniform();

		/*! @brief Sets an integer value (usually a texture unit index).
		 *  @param textureUnit The texture unit index to set. */
		void setInteger(GLint textureUnit);

		/*! @brief Sets a float value.
		 *  @param value The float value to set. */
		void setFloat(GLfloat value);

		/*! @brief Sets a vec2 value.
		 *  @param value0 The vec2's 0th value to set.
		 *  @param value1 The vec2's 1st value to set. */
		void setVector2(GLfloat value0,GLfloat value1);

		/*! @brief Sets a vec3 value.
		 *  @param value0 The vec3's 0th value to set.
		 *  @param value1 The vec3's 1st value to set.
		 *  @param value2 The vec3's 2nd value to set. */
		void setVector3(GLfloat value0,GLfloat value1,GLfloat value2);

		/*! @brief Sets a vec4 value.
		 *  @param value0 The vec4's 0th value to set.
		 *  @param value1 The vec4's 1st value to set.
		 *  @param value2 The vec4's 2nd value to set.
		 *  @param value3 The vec4's 3rd value to set. */
		void setVector4(GLfloat value0,GLfloat value1,GLfloat value2,GLfloat value3);

		/*! @brief Sets a ivec2 value.
		 *  @param value0 The ivec2's 0th value to set.
		 *  @param value1 The ivec2's 1st value to set. */
		void setVector2i(GLint value0,GLint value1);

		/*! @brief Sets a ivec3 value.
		 *  @param value0 The ivec3's 0th value to set.
		 *  @param value1 The ivec3's 1st value to set.
		 *  @param value2 The ivec3's 2nd value to set. */
		void setVector3i(GLint value0,GLint value1,GLint value2);

		/*! @brief Sets a ivec4 value.
		 *  @param value0 The ivec4's 0th value to set.
		 *  @param value1 The ivec4's 1st value to set.
		 *  @param value2 The ivec4's 2nd value to set.
		 *  @param value3 The ivec4's 3rd value to set. */
		void setVector4i(GLint value0,GLint value1,GLint value2,GLint value3);

		/*! @brief Sets an array of floats.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setFloatArray(GLsizei elementCount,const GLfloat* array);

		/*! @brief Sets an array of ints.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setIntArray(GLsizei elementCount,const GLint* array);

		/*! @brief Sets an array of vec2s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector2Array(GLsizei elementCount,const GLfloat* array);

		/*! @brief Sets an array of vec3s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector3Array(GLsizei elementCount,const GLfloat* array);

		/*! @brief Sets an array of vec4s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector4Array(GLsizei elementCount,const GLfloat* array);

		/*! @brief Sets an array of ivec2s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector2iArray(GLsizei elementCount,const GLint* array);

		/*! @brief Sets an array of ivec3s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector3iArray(GLsizei elementCount,const GLint* array);

		/*! @brief Sets an array of ivec4s.
		 *  @param elementCount The number of elements in the array to set from index 0.
		 *  @param array The array to set. */
		void setVector4iArray(GLsizei elementCount,const GLint* array);

		/*! @brief Sets an array of mat2s.
		 *  @param matrix The array to set.
		 *  @param count The number of matrices in the array.
		 *  @param transpose Flag for transpose matrices. */
		void setMatrix22(const GLfloat* matrix,GLsizei count=1,bool transpose=false);

		/*! @brief Sets an array of mat3s.
		 *  @param matrix The array to set.
		 *  @param count The number of matrices in the array.
		 *  @param transpose Flag for transpose matrices. */
		void setMatrix33(const GLfloat* matrix,GLsizei count=1,bool transpose=false);

		/*! @brief Sets an array of mat4s.
		 *  @param matrix The array to set.
		 *  @param count The number of matrices in the array.
		 *  @param transpose Flag for transpose matrices. */
		void setMatrix44(const GLfloat* matrix,GLsizei count=1,bool transpose=false);

		/*! @brief Accessor for the uniform's name.
		 *  @return The uniform's name. */
		const std::string& getName() const;

		/*! @brief Accessor for the uniform's location.
		 *  @return The uniform's name. */
		GLint getResourceLocation() const;

		/*! @brief Accessor for the glsl program, this uniform belongs to.
		 *  @return The glsl program. */
		const GPUProgram& getGLSLProgram() const;

		/*! @brief Checks uniform validity.
		 *  @return Uniform validity. */
		bool isValid() const;

	private:
		//! @brief The OpenGL index of the uniform locations.
		GLint mResourceLocation;

		//! @brief GLSL program this uniform belongs to.
		const GPUProgram& mOwnerProgram;

		//! @brief The name of the uniform.
		std::string mResourceName;

		//! @brief Copy constructor disabled.
		GPUUniform(GPUUniform&);

		//! @brief Equals operator disabled.
		GPUUniform& operator=(GPUUniform&);
	};

} // namespace REng

#endif // _RENG_GPUUNIFORM_H_
