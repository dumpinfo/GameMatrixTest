/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUPROGRAM_H_
#define _RENG_GPUPROGRAM_H_

#include "REng/Prerequisites.h"

#include "REng/Defines.h"
#include "REng/GPU/GPUShader.h"
#include "REng/GPU/GPUResource.h"

#include <string>
#include <vector>

namespace REng {

	/*!
	 *  \brief This class encapsulates the functionalities of OpenGL Shading Language programs.
	 *  \author Adil Yalcin, Attila Barsi (Holografika)
	 */
	class RENGAPI GPUProgram : public GPUResource {
	public:
		//! @brief Constructor.
		GPUProgram();

		//! @brief Destructor.
		~GPUProgram();

		//! @brief Use the program for rendering.
		void bindResource() const;

		//! @brief After this call, the rendering state refers to an invalid program object
		static void unbindResource();
		
		/*! @brief Attaches a GLSL shader to the program.
		 *  @param shader The GLSL shader to attach.
		 *  @return False, if the shader is attached to program already or in ES 2.0 configuration, a
		 *          shader of the same type has already been attached. True, otherwise
		 */
		bool attachShader(const GPUShader& shader);
		
		/*! @brief Detaches a GLSL shader from the program.
		 *  This command can be used to undo the effect of the command glAttachShader.
		 *  @param shader The GLSL shader to detach.
		 */
		bool detachShader(const GPUShader& shader);

		/*! @brief Links the program. Generates the program info log. 
		 *  @see GPUProgram::getProgramInfoLog();
		 *  @return True if link is successful, false otherwise.
		 */
		bool link();

		//! @return True if program is successfully linked using the current shaders
		bool isLinked() const;
		
		/*! @brief checks whether the executables contained in program can execute given the current rendering state.
		 *         the information log is updated.
		 *  @see GPUProgram::getProgramInfoLog(); and glValidateProgram();
		 *  @return True if validation is successful, false otherwise.
		 */
		bool validate();

		//! @return The currently active GPUProgram. 0 is none is active
		static const GPUProgram* getActiveProgram();

		//! @brief Retrieves generic attribute index using custom uniform name
		//! @param name  The string name of the uniform
		//! @param index Updated to reflect correct generic index, if semantic is bound in this program.
		//! @return false, if the given name is not bound to a generic active attribute index, true otherwise
		//! @remark Does not check semantically mapped attribute names!
		bool getGenericIndex(const char* name, GLuint& index) const;

		//! @brief Retrieves generic attribute index using custom uniform name
		//! @param sem  The semantic of requested generic attribute index
		//! @param index Updated to reflect correct generic index, if semantic is bound in this program.
		//! @return false, if the given semantic is not bound to a generic active attribute index, true otherwise
		bool getGenericIndex(VertexAttribSemantic sem, GLuint& index) const;

		//! @brief This reflects active uniform count after a successful link
		size_t getActiveUniformCount() const;

		//! @brief The length of the longest uniform name in program.
		size_t getActiveUniformMaxLength() const;

		/*! @brief Returns information about an active uniform variable in the program object 
		 *  @param index The index of the active uniform that you want to retrieve info about.
		 *  @param length Returns the number of characters actually written by OpenGL in the string 
		 *                indicated by name (excluding the null terminator) if a value other than
		 *                NULL is passed.
		 *  @param size Returns the size of the uniform variable.
		 *  @param type Returns the data type of the uniform variable.
		 *  @param name Returns a null terminated string containing the name of the uniform variable.
		 *              Must be able to hold at least getActiveUniformMaxLength characters. */
		void getActiveUniform(size_t index, size_t* length, int* size, GLenum* type, char* name);

		void bindAttribLocation(uint attribIndex, const char* attribName);

		//! @note Only valid for OpenGL 3.0 and above contexts.
		//! @note Affective only before linking the program object. (Different from OpenGL spec)
		//! @return false on error (color index accedes max draw buffer count or program is linked.
		bool bindFragDataLocation(uint colorIndex, const char* outName);

		/*! @brief If the program is attached a fragment shader and is linked, queries fragment data location.
		 *  @note  Only valid for OpenGL 3.0 and above contexts.
		 *  @param outName The string name of the fragment shader output. Must be a null-terminated string.
		 *  @return The number of the fragment color to which the varying out variable name was bound when 
		 *         the program object program was last linked. 
		 *  @note  If outName is not a varying out variable, or if an error occurs, -1 will be returned.
		 */
		int getFragDataLocation(const char* outName);

	protected:
		//! @brief The list of vertex shaders that are attached
		std::vector< const GPUShader* > mAttachedVertexShaders;

		//! @brief The list of fragment shaders that are attached
		std::vector< const GPUShader* > mAttachedFragmentShaders;

		//! @brief The list of geometry shaders that are attached
		std::vector< const GPUShader* > mAttachedGeometryShaders;

		//! @brief True, if the program could be linked successfully, false otherwise
		bool mIsLinked;
		
		struct SShaderAttrib{
			GLint  size;
			GLenum type;
			char   *name;
			GLint  location;
			VertexAttribSemantic semantic;
		};

		//! @brief Stores the active attribute information of this program object.
		//!        This list is updated after a successful link.
		std::vector<SShaderAttrib> mActiveAttributeList;

		//! @brief This reflects active uniform count after a successful link
		GLint mActiveUniformCount;

		//! @brief The length of the longest uniform name in program.
		GLint mActiveUniformMaxLength;

		//! @brief Disabled the copy constructor.
		GPUProgram(GPUProgram&);

		//! @brief Disabled the operator equals.
		GPUProgram& operator=(GPUProgram&);

		//! @brief The currently active GPUProgram. Is 0 is none is active
		static const GPUProgram *mActiveProgram;

		//! @brief updates mAttributeMapping by retrieving active attributes from GL program object
		void updateActiveAttributeList();

		//! @brief Creates the hardware resource for the GL program
		void createResource();

		//! @brief Deletes the hardware resource of the GL program, if any
		void destroyResource();

		friend class RenderSystem;
		friend class GPUUniform;
	};

}  // namespace REng

#endif // _RENG_GPUPROGRAM_H_
