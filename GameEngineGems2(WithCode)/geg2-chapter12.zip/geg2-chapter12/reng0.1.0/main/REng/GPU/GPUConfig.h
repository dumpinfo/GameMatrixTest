/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUCONFIG_H_
#define _RENG_GPUCONFIG_H_

#include "REng/Prerequisites.h"
#include "REng/Defines.h"
#include "REng/Singleton.h"

#include <string>

namespace REng {
	/*!
	 * @brief A helper which reads available OpenGL information and logs it on request.
	 &        Getters are available for each configuration variable.
	 * @author Adil Yalcin
	 */
	class RENGAPI GPUConfig : public Singleton<GPUConfig> {
	public:
		~GPUConfig();
		
		static GPUConfig& getSingleton(void);
		static GPUConfig* getSingletonPtr(void);

		//! @brief Reads available OpenGL info from the driver
		void update();

		//! logs the machine info to render system logger
		void log();

		const char *getGLVersion() const;
		const char *getGLSLVersion() const;
		const char *getRendererName() const;
		const char *getVendorName() const;
		int getGLVersionMajor() const;
		int getGLVersionMinor() const;
		int getGLSLVersionMajor() const;
		int getGLSLVersionMinor() const;

		const GLfloat* getGLAliasedLineWidthRange() const;
		const GLfloat* getGLAliasedPointSizeRange() const;
		GLint getGLNumCompressedTextureFormats() const;
		const GLint* getGLCompressedTextureFormats() const;
		GLint getGLMaxCombinedTextureImageUnits() const;
		GLint getGLMaxCubeMapTextureSize() const;
		GLint getGLMaxDrawBuffers() const;
		GLint getGLMaxFragmentUniformVectors() const;
		GLint getGLMaxRenderbufferSize() const;
		GLint getGLMaxTextureImageUnits() const;
		GLint getGLMaxTextureSize() const;
		GLint getGLMaxVaryingVectors() const;
		GLint getGLMaxVertexAttrib() const;
		GLint getGLMaxVertexTextureImageUnits() const;
		GLint getGLMaxVertexUniformVectors() const;
		const GLint* getGLMaxViewportDims() const;
		GLint getGLNumShaderBinaryFormats() const;
		const GLint* getGLShaderBinaryFormats() const;
		GLboolean getGLShaderCompiler() const;
		GLboolean getGLStereo() const;
		GLint getGLSubpixelBits() const;
		GLint getGLMaxColorAttachments() const;

		GLint getGLMaxSamples() const;

		//! @return True if the given format is a compressed format AND 
		//!         is supported by the current GPU hardware/driver
		bool isCompressedImageFormatSupported(ImageFormat format) const;

		//! Returns the current synchronized time of GL (after all previous commands have 
		//! reached the GL server but have not yet necessarily executed.
		//! @note Only works if ARB_timer_query extension is available or 
		//!       OpenGL Version is greater or equal to 3.3
		//! @todo Add 64 bit variant
		GLint getSynchTime() const;

	private:
		// OpenGL Info
		const char *mGLVersion;
		const char *mGLSLVersion;
		const char *mRendererName;
		const char *mVendorName;

		int mGLVersionMajor, mGLVersionMinor;
		int mGLSLVersionMajor, mGLSLVersionMinor;

		//! @brief The smallest and largest supported widths for aliased lines. The range must include width 1.
		GLfloat mGLAliasedLineWidthRange[2];

		//! @brief The smallest and largest supported widths for aliased points. The range must include width 1.
		GLfloat mGLAliasedPointSizeRange[2];

		//! @brief Indicates the number of available compressed texture formats. The minimum value is 0. See glCompressedTexImage2D.
		GLint   mGLNumCompressedTextureFormats;

		//! @brief A list of symbolic constants of length mGLNumCompressedTextureFormats indicating which compressed texture formats are available.
		GLint*  mGLCompressedTextureFormats;
		
		//! @brief The maximum supported texture image units that can be used to access texture maps from 
		//!        the vertex shader and the fragment processor combined. 
		/*! If both the vertex shader and the fragment processing stage access the same texture image
		 *  unit, then that counts as using two texture image units against this limit.
		 *  The value must be at least 8. See glActiveTexture. */
		GLint mGLMaxCombinedTextureImageUnits;

		//! @brief The value gives a rough estimate of the largest cube-map texture thatthe GL can handle. 
		/*! The value must be at least 16. See glTexImage2D. */
		GLint mGLMaxCubeMapTextureSize;

		//! @brief The maximum number of four-element floating-point, integer, or boolean vectors that can be 
		//!        held in uniform variable storage for a fragment shader. 
		/*! The value must be at least 16. See glUniform. */
		GLint mGLMaxFragmentUniformVectors;

		//! @brief The value indicates the largest renderbuffer width and height that the GL can handle. 
		/*! The value must be at least 1. See glRenderbufferStorage. */
		GLint mGLMaxRenderbufferSize;

		//! @brief The maximum supported texture image units that can be used to access texture maps from the fragment shader. 
		/*! The value must be at least 8. See glActiveTexture. */
		GLint mGLMaxTextureImageUnits;

		//! @brief The value gives a rough estimate of the largest texture that the GL can handle. 
		/*! The value must be at least 64(in ES 2.0) or 1024(in 3.1) . See glTexImage2D. */
		GLint mGLMaxTextureSize;

		//! @brief The maximum number four-element floating-point vectors available for interpolating varying variables 
		//!        used by vertex and fragment shaders. 
		/*! Varying variables declared as matrices or arrays will consume multiple interpolators. The value must be at least 8. */
		GLint mGLMaxVaryingVectors;

		//! @brief The maximum number of 4-component generic vertex attributes accessible to a vertex shader. 
		/*! The value must be at least 8. See glVertexAttrib. */
		GLint mGLMaxVertexAttrib;

		//! @brief The maximum supported texture image units that can be used to access texture maps from the vertex shader. 
		/*! The value may be 0. See glActiveTexture. */
		GLint mGLMaxVertexTextureImageUnits;

		//! @brief The maximum number of four-element floating-point, integer, or boolean vectors 
		//!       that can be held in uniform variable storage for a vertex shader. 
		/*! The value must be at least 128. See glUniform. */
		GLint mGLMaxVertexUniformVectors;

		//! @brief The maximum supported width and height of the viewport. 
		/*! These must be at least as large as the visible dimensions of the display being rendered to. See glViewport. */
		GLint mGLMaxViewportDims[2];

		//! @brief The number of available shader binary formats. 
		/*! The minimum value is 0. See glShaderBinary. */
		GLint mGLNumShaderBinaryFormats;

		//! @brief A list of symbolic constants of length mGLNumShaderBinaryFormats indicating 
		//!        which shader binary formats are available. 
		/*! See glShaderBinary. */
		GLint* mGLShaderBinaryFormats;

		//! @brief Indicates whether a shader compiler is supported.
		/*! GL_FALSE indicates that any call to glShaderSource,  glCompileShader, or 
		    glReleaseShaderCompiler will result in a GL_INVALID_OPERATION error being generated. */
		GLboolean mGLShaderCompiler;

		//! @brief Indicates whether stereo buffers (left and right) are supported.
		GLboolean mGLStereo;

		//! @brief Number of bits of sub-pixel precision in screen xw and yw
		/*! Minimum value: 4*/
		GLint mGLSubpixelBits;

		//! @brief Maximum number of FBO attachment points for color buffers.
		/*! Set to 1 automatically in OpenGL ES 2.0 configs.*/
		GLint mGLMaxColorAttachments;

		//! @brief Maximum number of samples supported for multi-sampling (FBO)
		/*! Set to 1 automatically in OpenGL ES 2.0 configs.*/
		GLint mGLMaxSamples;

		// NOTE: The rest is not supported in OpenGL ES 2.0

		//! @brief Maximum number of user clipping planes
		/*! Minimum value: 6*/
		GLint mGLMaxClipDistances;

		//! @brief Maximum 3D texture image dimension
		/*! Minimum value: 256*/
		GLint mGLMax3DTextureSize;

		//! Maximum number of active draw buffers
		/*! Set to 1 automatically in OpenGL ES 2.0 configs.*/
		GLint mGLMaxDrawBuffers;

		/************************************************************************/
		/* EXTENSION STRING INFO                                                */
		/************************************************************************/

		//! Stores the extension string list
		char **mExtentionInfoList;
		//! The total number of extensions in info list
		size_t mExtentionCount;

		//! Reads the available OpenGL extensions from the driver
		void readExtensions();

		//! Prints out the extension information to log file
		void logExtensions();

		// An instance can only be created by the render system
		GPUConfig();
		friend class RenderSystem;
	};

} // namespace REng

#endif // _RENG_GPUCONFIG_H_
