/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUDRAWER_H_
#define _RENG_GPUDRAWER_H_

#include "REng/Prerequisites.h"

// is a singleton
#include "REng/Singleton.h"
// draws mesh geoms
#include "REng/Mesh.h"

namespace REng {

	/*!
	 * @brief The instance which is aimed for sending draw command to OpenGL.
	 * @note  You should not call draw commands, such as glDrawElements / glDrawArrays in another place
	 * @author Adil Yalcin
	 */
	class RENGAPI GPUDrawer : public Singleton<GPUDrawer> {
	public:
		//! @brief This method also creates all REng singleton instances that will be required.
		GPUDrawer(void);
		~GPUDrawer(void);

		static GPUDrawer& getSingleton(void);
		static GPUDrawer* getSingletonPtr(void);

		//! @brief This method updates buffers as necessary and calls a single OpenGL draw command
		//! @remark Heavily uses batching options when set, so check out those as well...
		void drawMeshGeom(const MeshGeom& index_vertex_data);

		/************************************************************************/
		/* BATCHING OPTIONS                                                     */
		/************************************************************************/
		// batching basically controls which sections of a render call are skipped.

		//! @brief If attrib batch is on, the vertex attributes are processed 
		//!        as specified in their batching type
		void setAttribBatchOn();

		//! @brief Clears attribute batching mode and clears related states
		void setAttribBatchOff();

		//! @brief If a draw call is made while multi draw batch is on
		//!        the final draw command is not send, but the index data is buffered.
		//!        - If it is the first call, vertex attributes are set as usual
		//!        - Else, only the index information is cached inside the render system
		//! @remark All the render command send during MultiDrawBatch is expected to
		//!         - share the same vertex attribute information/buffers
		//!         - share the same indexing mode (sequential/specified in an array)
		//!         - if index information is read from a GPU/CPU buffer, share the same index buffer
		//! @note Has no affect in OpenGL ES 2.0 configurations
		//! @note For details, see the specifications of glMultiDrawArrays and glMultiDrawElements
		void setMultiDrawBatchOn();
	
		//! @brief Clears the multi-draw batching mode and sends required finalizing commands
		void setMultiDrawBatchOff();

	private:
		//! @brief True if attribute batch mode is activated
		bool mAttribBatchMode;

		//! @brief True if multi-draw batch mode is enabled
		bool mMultiDrawBatchMode;

		//! @brief True if a batch mode is currently initialized and active
		bool mBatchInitialized;

		//! @brief Stores the attributes bound in a batch mode, to be released on disabling batching
		std::vector<GLuint> mBatchAttribsBound;

		//! @brief Unbinds the attributes bound in a batch mode
		void unbindBatchAttribs();

	};

} // namespace REng

#endif // _RENG_GPUDRAWER_H_
