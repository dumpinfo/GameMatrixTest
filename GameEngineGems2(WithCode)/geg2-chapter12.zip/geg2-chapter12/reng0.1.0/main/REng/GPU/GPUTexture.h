/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_GPUTEXTURE_H_
#define _RENG_GPUTEXTURE_H_

#include "REng/Prerequisites.h"

// GPUTexture is a render target
#include "REng/GPU/RenderTarget.h"
// texture properties are stored as render properties
#include "REng/GPU/RenderProperty.h"
#include "REng/GPU/GPUSampler.h"

#include <string>
#include <vector>

namespace REng{

	/*!
	 * @brief Textures are 1D, 2D or 3D images that can be loaded to HW and be used as texturing resources.
	 *        This class is a wrapper over most OpenGL texture related operations.
	 * @note
	 *   @par Cube-maps can store depth component textures. (ex:rendering shadows for a point light)
	 *   @par To be able to successfully load and use a cubemap texture, 
	 *        - The level zero arrays of each of the six texture images making up the cube
	 *          map must have identical, positive, and square dimensions.
	 *   @par Render target width and height is level 0's dimensions (in LoDed textures as well)
	 *   @par Supports compressed internal file formats and compressed data loading.
	 */ 
	class RENGAPI GPUTexture : public RenderTarget, public GPUResource {
	public:
		GPUTexture(TextureType type);

		~GPUTexture();

		//! @brief Selects which texture unit subsequent texture state calls will affect.
		//! @param Specifies which texture unit to make active. The number of texture 
		//!        units is implementation dependent, but must be at least two. 
		//!        Valid range is from 0 to getGLMaxCombinedTextureImageUnits
		static void setActiveTextureUnit(uchar unitID);

		//! @brief Binds the source to currently active texture unit. If a resource is already assigned, does nothing.
		//! @note If there exists no hardware resource, this has no affect.
		void bindResource() const;

		//! @brief Unbinds the texture (in mType) bound to currently active texture unit
		void unbindResource();

		//! @return The type of the texture
		TextureType getType() const;

		//! @return The magnification filter render property of the texture
		MagFilter getMagFilter() const;

		//! @return The minification filter render property of the texture
		MinFilter getMinFilter() const;

		//! @return The wrap mode S property of the texture
		WrapMode getWrapModeS() const;

		//! @return The wrap mode T property of the texture
		WrapMode getWrapModeT() const;

		//! @return The wrap mode R property of the texture
		WrapMode getWrapModeR() const;

		//! @return Mipmap auto-generation flag
		bool getGenMipmaps() const;

		//! @brief Setter for mipmap auto-generation flag
		//!   If true, computes a complete set of mipmap arrays derived from the zero level array
		//!    when a new a new data is uploaded.
		//! @see glGenerateMipmaps
		void setGenMipmaps(bool flag);

		//! Copies all sampling properties from given sampler to texture's own sampler state.
		void setSamplerProperties(const GPUSampler& sampler);

		//! @brief Updates the corresponding texture render property to given prop.
		void setSamplerProperty(const SamplerProp& prop);

		//! @brief shorthand for setting minification filter
		void setMinFilter(MinFilter filter);

		//! @brief shorthand for setting magnification filter
		void setMagFilter(MagFilter filter);

		//! @brief shorthand for setting wrap state
		void setWrap(WrapAxis axis, WrapMode mode );

		//! @see GPUSampler::invalidateState
		void invalidateSamplerState();

		//! @brief The internal format is used when uploading data to hardware.
		void setInternalFormat(ImageFormat format);

		//! @return True if texture is complete
		bool isComplete() const;

		//! @return True, if the current texture type is supported by the platform
		bool isSupported() const;

		//! @return True if the internal format of the render target is compressed.
		bool isCompressed() const;

		//! @brief The texture state is composed of min filter, mag filter and wrap modes.
		//! @note  Only updates the states that need synch (/updated until last synch)
		void updateSamplerState();

		/*! @brief Loads the given data to the texture resource in HW.
		 *         It automatically tries to manage different types of textures.
		 *         For loading data to compressed internal formats, use loadComprFromMemToResource.
		 *  @par MipMapping
		 *     If mGenMipmaps is true and lod=0, generates the mipmaps automatically after load operation.
		 *     If texture type is cubemap, this is not done (you should call generateMipmaps after you load all faces)
		 *  @par To clear / reset texture content, call this function with data parameter set to zero pointer.
		 *  @param width The width of the image data
		 *  @param height The height of the image data (not used if mType = 1D )
		 *  @param dataType The type of the color components provided in data (ex: unsigned short)
		 *  @param dataFormat The format of the color components provided in data (ex: unsigned short)
		 *  @param data The image data in memory
		 *  @param lod The mipmap level to update (base level is 0)
		 *  @param face (Used only if mType = Cube) The face of the cubemap to update to
		 *  @param depth (Used only if mType = 3D) The depth of the image data
		 *  @return True if texture is loaded to resource without errors (check material.log for error information) 
		 */
		bool loadFromMemToResource( 
			uint width, uint height, 
			PixelDataType dataType, PixelDataFormat dataFormat, const GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X, uint depth=1);

		/*! @brief Loads the given sub-image (specific region) image data to the texture resource in HW.
		 *         It automatically tries to manage different types of textures.
		 *         For loading data to compressed internal formats, use loadComprFromMemSubImg.
		 *
		 *  @par MipMapping
		 *     If mGenMipmaps is true and lod=0, generates the mipmaps automatically after load operation.
		 *     If texture type is cubemap, this is not done (you should call generateMipmaps after you load all faces)
		 * 
		 *  @par To clear / reset texture content, call this function with data parameter set to zero pointer.
		 *  
		 *  @param xoffset Texel offset in the x direction
		 *  @param yoffset Texel offset in the y direction
		 *  @param width The width of the image data
		 *  @param height The height of the image data (not used if mType = 1D )
		 *  @param dataType The type of the color components provided in data (ex: unsigned short)
		 *  @param dataFormat The format of the color components provided in data (ex: unsigned short)
		 *  @param data The image data in memory
		 *  @param lod The mipmap level to update (base level is 0)
		 *  @param zoffset Texel offset in the z direction
		 *  @param face (Used only if mType = Cube) The face of the cubemap to update to
		 *  @param depth (Used only if mType = 3D) The depth of the image data
		 * 
		 *  @return True if texture is loaded to resource without errors (check material.log for error information) */
		bool loadSubImgFromMem(
			uint xoffset, uint yoffset, uint width, uint height, 
			PixelDataType dataType, PixelDataFormat dataFormat, const GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X, uint zoffset=0, uint depth=1);

		//! The variant of loader which is for loading compressed texture data
		//! All parameter usage is the same. 
		//! @note The difference is:
		//!       - Instead of dataType and dataFormat parameters, dataSize parameter is used.
		bool loadComprFromMemToResource(
			uint width, uint height, 
			uint dataSize, const GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X, uint depth=1);

		//! The variant of loader which is for loading compressed texture data
		//! All parameter usage is the same. 
		//! @note The difference is:
		//!       - Instead of dataType and dataFormat parameters, dataSize parameter is used.
		bool loadComprSubImgFromMem(
			uint xoffset, uint yoffset, uint width, uint height, 
			uint dataSize, const GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X, uint zoffset=0, uint depth=1);

		//! Allows reading back uncompressed GPUTexture data to the main memory.
		//! @note OpenGL ES does not support reading back texture data.
		//! @note You have to make sure that the given pointer points to a memory large enough 
		//!      (can store the requested texture completely)
		//! @return True if the texture data can be copied to given data pointer (and platform is GL desktop)
		bool readFromResourceToMem(PixelDataType dataType, PixelDataFormat dataFormat, GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X);
		
		//! Allows reading back compressed GPUTexture data to the main memory (in compressed form).
		//! @note OpenGL ES does not support reading back texture data.
		//! @note You have to make sure that the given pointer points to a memory large enough 
		//!      (can store the requested texture completely)
		//! @return True if the texture data can be copied to given data pointer (and platform is GL desktop)
		bool readComprFromResourceToMem(GLvoid * data, 
			uint lod=0, CubeMapFace face=CubeMapFace_Negative_X);

		//! If texture stores depth or stencil values, does nothing (see OES_depth_texture and like )
		void generateMipmaps();

		/*! @brief A helper function which tries to find a suitable attachment type.
		 *         It uses color0 as the default color attachment target
		 *  @param level The mipmap level of the texture image to be attached to the framebuffer
		 *  @param face (Used only if mType = Cube) The face of the cubemap to bind to active FBO
		 *  @return True, if a suitable attachment type could be detected and bound
		 *  @note 3D and 1D texture types are not supported for attachment in ES 2
		 */
		bool attachToActiveFBO(uint level=0, CubeMapFace face = CubeMapFace_Positive_X) const;

		//! @brief Tries to bind this texture to active FBO depth target
		//! @return False, if internal type has no depth component
		bool attachToActiveFBODepth(uint level=0, CubeMapFace face = CubeMapFace_Positive_X) const;

		//! @brief Tries to bind this texture to active FBO stencil target
		//! @return False, if internal type has no stencil component
		bool attachToActiveFBOStencil(uint level=0, CubeMapFace face = CubeMapFace_Positive_X) const;

		//! @brief Use this if you want to attach the texture to a specific attachment (ex: color, in configurations supporting MRT)
		bool attachToActiveFBO(FrameBufferAttachType attachType, uint level=0, CubeMapFace face = CubeMapFace_Positive_X) const;

	protected:
		//! @brief The OpenGL texture type. You cannot modify it after object is created.
		TextureType mType;

		//! @brief True if texture is complete wrt. OpenGL spec
		bool mIsComplete;

		//! @brief True if automated HW mipmap generation is required on data upload time (glGenerateMipmaps)
		bool mGenMipmaps;

		//! The sampler state stored with this texture
		GPUSamplerTexture mSampler;

		//! A helper function that tries to detect texture data format conformity problems
		//! @return True if the data parameters are compatible, false otherwise
		bool checkLoadParameters(PixelDataFormat format, PixelDataType type);

		//! A helper function that checks maximum supported texture size of GPU config 
		//! with given parameters
		//! @return True if given values are within the supported range
		bool checkTextureSize(uint width, uint height) const;

		//! A helper function that checks if given parameters create a valid subimg for current texture
		//! @return True if given values are within the supported range
		bool checkSubImgSize(uint xoffset, uint yoffset, uint zoffset, uint width, uint height, uint depth) const;

		//! @return True, if the level of texture is suitable for attachment
		//!         False, if level is negative
		//!         False, if ES config is active and lod is not 0
		bool checkAttachmentLevel(uint level) const;

		void updateResolutions();

		//! @brief Creates a hardware resource for this texture
		void createResource();

		//! @brief Deletes the hardware resource for this texture, if any
		void destroyResource();

		friend class GPUFrameBuffer;
	};



} // namespace REng

#endif // _RENG_GPUTEXTURE_H_
