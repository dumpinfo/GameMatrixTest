/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MESH_H_
#define _RENG_MESH_H_

#include "REng/Prerequisites.h"

#include <map>
#include <string>

#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>

// Mesh stores vertex/index data
#include "REng/VertexIndexData.h"
// Mesh stores material
#include "REng/Material/Material.h"
// Mesh is an LoD'ed structure
#include "REng/LoD.h"
// Bounding volumes use Geom component
#include "REng/Geom/GeomVolume.h"

namespace REng{

	/*!
	 *  @brief The geometry (per-vertex and index) data of a mesh.
	 *         It is used by Mesh class as an LoDed data
	 *  @author Adil Yalcin
	 */
	class RENGAPI MeshGeom{
	public:
		//! @remark The pointers are initialized as null pointers
		MeshGeom();

		~MeshGeom();

		//! Can be shared between different LoD levels, expected not to be null
		IndexDataPtr mIndexDataPtr;

		//! Can be shared between different LoD levels, expected not to be null
		VertexDataPtr mVertexDataPtr;

		//! @brief Returns the vertex count of this mesh geometry.
		//! @remark Can be used to specify complexity of this mesh Geom.
		//! @return The number of vertices used by this mesh
		size_t getVertexCount() const;

		//! @brief Direct setter for mesh geom bounding volume
		//! @remark use this if data is already available / customized volume generation is used.
		void setBoundingVolume(GeomVolume* volume);

		//! @return The bounding volume of the mesh geom, NULL if not available
		const GeomVolume* getBoundingVolume() const;

		//! @brief Generates bounding volume info from index and vertex data
		//! @remark
		//! - Only works if the vertex data does not hold an attribute of semantic POSITION and data-count 3.
		//! - If index buffer is specified, only the vertices indexed are used in generation.
		void generateBoundingVolume(GeomType type);

		GeomVolume* mBoundingVolume;

	private:
		//! The bounding volume of the mesh geometry
		//! The vertex attribute with semantic POSITION is used
		//! @remark Which mesh geom is used to calculate the bounds? 
		//!         (All can be used, only lowest detailed one can be used, etc)
		//! TODO

	};

	/*!
	 *  @brief A mesh is a collection of vertices (and possibly indexes) which can be rendered 
	 *         in a single draw call
	 *         - Each mesh LoD level can define its own -shared- vertex or -shared- index data
	 *         - Use MeshManager to create a mesh object
	 *  @details On instantiation, NO default geometry is created.
	 *  @author Adil Yalcin
	 */
	class RENGAPI Mesh : public LoD<MeshGeom> {
	public:
		~Mesh();

		//! @return The name of the mesh
		const std::string& getName() const;

		//! @brief Stores the material associated with this mesh
		//! @note  The material properties is applied to all vertices of the mesh.
		MaterialPtr mMaterial;

		/************************************************************************/
		/* Specialized LoD geom creation                                        */
		/* createLoDData does not create vertex and index data (THEY ARE NULL!) */
		/************************************************************************/

		//! @brief New vertex and index data is instantiated for the new geom
		//! @return 0 if given LoD configuration existed, else valid data
		//! @remark Use this to create new separate and clean index and vertex data.
		//!         Yet, remember that vertex and index buffers can be internally using different ranges!
		MeshGeom* createLoDGeom(uchar viewIndex = 0, uchar distanceIndex = 0);

		//! @brief New geom's vertex data is assigned to given vertex data, index data is instantiated
		//! @return 0 if given LoD configuration existed, else valid data
		//! @remark Use this to specify different index data for the same shared vertex data
		MeshGeom* createLoDGeom(VertexDataPtr vertexData, uchar viewIndex = 0, uchar distanceIndex = 0);

		//! @brief New geom's internal data is set to given parameters
		//! @return 0 if given LoD configuration existed, else valid data
		//! @remark Use this to share index and vertex data of another mesh
		//!   \code
		//!     MeshPtr mesh1, mesh2; // ....
		//!     mesh2->createLoDGeom(mesh1->getSuitableData(0,0));
		//!   \endcode
		MeshGeom* createLoDGeom(MeshGeom meshGeom, uchar viewIndex = 0, uchar distanceIndex = 0);

	private:
		//! each mesh has a unique name. Uniqueness is provided by MeshManager.
		std::string mName;

		//! Creates a new vertex data for use by this mesh
		static VertexDataPtr createVertexData();

		//! Creates a new index data for use by this mesh
		static IndexDataPtr createIndexData();

		//! A mesh can only be constructed by MeshManager
		Mesh(const std::string& name);
		//! disable copy constructor
		Mesh(Mesh&);
		//! disable assignment operator
		Mesh&	operator=(Mesh&);

		friend class MeshManager;
	};
	typedef boost::shared_ptr<Mesh> MeshPtr;

} // namespace REng

#endif // _RENG_MESH_H_
