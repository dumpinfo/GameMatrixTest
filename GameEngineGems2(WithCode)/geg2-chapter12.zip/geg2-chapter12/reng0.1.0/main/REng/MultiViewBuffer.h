/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_MULTIVIEWBUFFER_H_
#define _RENG_MULTIVIEWBUFFER_H_

#include "REng/Prerequisites.h"
#include "REng/Defines.h"
#include "REng/Rect.h"

#include <vector>

namespace REng{

	//! Basic types of multi-view buffers
	//! @note The OpenGL Quad-Buffer supported render surfaces are 
	//!       automatically managed when mv buffer type is Ontarget.
	enum MVBufferType {
		MVBufferType_Offtarget,   ///< Buffer renders to its own target resources
		MVBufferType_Ontarget     ///< Buffer renders to viewport target
	};

	//! Configuration parameters you can set when creating on-target multi-view buffers
	struct MVBuffer_Cfg_Ontarget {
		//! Stores a list of different view rectangles on target for each view
		//! @note Must be empty or the size must match the viewcount
		std::vector<RectF> viewRects;
	};

	//! Configuration parameters for LoD settings in offtarget multi-view bufers
	struct MVBuffer_Cfg_Offtarget_LoD {
		//! Requests using half resolution buffer for secondary view color targets
		//! @todo Not stable API
		bool halfResBuffer;
	};

	//! Configuration parameters you can set when creating off-target multi-view buffers
	struct MVBuffer_Cfg_Offtarget {
		//! Creates a default configuration
		MVBuffer_Cfg_Offtarget();

		//! The image formats for use as color channel targets,
		//! @note This must have at least one element.
		//! 
		//! @remark You can specify multiple color formats for multiple color render targets, ex. for use in deferred shading.
		//!         The view buffers are attached to color targets in the order specified.
		//!         Each color format corresponds to a new internal GPU texture.
		//! @todo Design  is incomplete, currently supports a single image format for all targets
		ImageFormat colorFormat;

		//! The image format for use as depth channel target
		ImageFormat depthFormat;

		//! The image format for use as stencil channel target
		//! @note   If set to ImageFormat_None, no off-screen stencil buffer will be created
		//! @remark If you want to use a depth-stencil target, specify the same depth-stencil target format as both depth and stencil format.
		ImageFormat stencilFormat;

		//! If true, the depth buffer will be shared between different views.
		//! @remark Only applicable with view-first rendering. 
		//!         The multi-view compositor cannot render views in mesh-first order if true.
		bool sharedDepthStencilTargets;

		//! If true, the viewport will have a single frame buffer object. 
		//! @note This does not affect behavior, but can affect performance.
		bool sharedFrameBuffer;

		//! The vertical resolution will be lowered to half of viewport resolution.
		//! @remark For use by parallax-based compositors
		bool halfResHeight;

		//! The horizontal resolution will be lowered to half of viewport resolution.
		//! @remark For use by parallax-based compositors
		bool halfResWidth;
		
		//! The LoD configurations
		MVBuffer_Cfg_Offtarget_LoD lod;
	};

	//! Encapsulates all configuration parameters for initializing a multi-view buffer
	struct MVBuffer_Cfg {
		//! Creates a default configuration
		MVBuffer_Cfg();

		//! The number of views to be supported (must be at least 2)
		//! @note Default : 2
		uchar viewCount;

		//! The type of the buffer you want to create
		MVBufferType type;

		//! The off-target configurations
		MVBuffer_Cfg_Offtarget offtarget;

		//! The on-target configurations
		MVBuffer_Cfg_Ontarget ontarget;

		//! @return True if buffer has conflicting properties
		bool isValid() const;
	};

	//! @todo Add documentation
	class RENGAPI MultiViewBuffer{
	public:
		//! Creates a non-initialized multi-view buffer with no resources
		MultiViewBuffer();

		//! Destructor, clears all view-specific resource data
		~MultiViewBuffer();

		//! @return The buffer type
		MVBufferType getType() const;

		//! Given the parameter list, initializes multi-view buffer
		//! @return true on successful completion, false otherwise
		//! @note If buffer is initialized, has no affect, returns false
		bool init(Viewport& vp, const MVBuffer_Cfg& cfg);

		//! @return True if multi-view buffer resources are created and initialized.
		bool isInitialized() const;

		//! Clears all buffers that store view information
		void clear();

		//! @return The number of views this multi-view camera defines.
		uchar getViewCount() const;

		//! @brief Sets the active camera view no
		//! @param viewIndex Must be between 0 and ViewCount. If not, defaults to View No 0.
		bool setActiveView(size_t viewIndex);

		//! Retrieves the texture that is used for rendering a specific view
		//! @note Used by multi-view compositors, only valid if buffer is of type offtarget
		GPUTexture* getColorTarget(uchar viewIndex);
		GPUFrameBuffer*  getFrameBuffer(uchar viewIndex);

		//! If false, all views renders to same location on the viewport target.
		bool hasOwnViewRects();

		//! Loads all red/green/blue content to all view buffer color data.
		//! @note For debugging purposes only
		void _loadDebugTextureData();

	protected:
		//! The number of views this view buffer supports
		uchar mViewCount;

		//! The active view that is being rendered onto.
		uchar mActiveView;

		//! True if multi-view buffer resources are created and initialized.
		bool mIsInitialized;

		//! The viewport which this view buffer will be merged into
		//! @note To get width-height information, use this pointer
		Viewport* mTargetViewport;

		//! The basic type of this multi-view buffer
		MVBufferType mType;

		std::vector<RectF> mViewRects;

		//! Returns the size of the buffer used for rendering a specific view
		void getBufferSize(uchar viewIndex, ushort& width, ushort& height);

		//////////////////////////////////
		// CONFIG-RESOUCE DATA

		//! The frame-buffer assigned to this view-buffer.
		//! @note Only a single view buffer is used if sharedFrameBuffer is set on initialization
		std::vector<GPUFrameBuffer*> mFrameBufferList;

		//! The texture color-targets
		std::vector<GPUTexture*> mColorTargets;

		//! The depth targets (also depth-stencil targets)
		std::vector<GPURenderBuffer*> mDepthTargets;
		//! The stencil targets
		std::vector<GPURenderBuffer*> mStencilTargets;
		//! The depth-stencil targets
		std::vector<GPURenderBuffer*> mDepthStencilTargets;
		bool mSharedDepthStencilTargets;

		GPURenderBuffer* getDepthTarget(uchar viewIndex);
		GPURenderBuffer* getStencilTarget(uchar viewIndex);

		bool attachDepthTarget(uchar viewIndex);
		bool attachStencilTarget(uchar viewIndex);
		bool attachColorTargets(uchar viewIndex);

		//! True if the depth-stencil buffers need to be attached for each view
		bool isDepthStencilDynamic() const;
		//! True if the color buffers need to be attached for each view
		bool isColorDynamic() const;

		bool setView_Ontarget();
		bool setView_Offtarget();

		bool init_Quadbuffer();
		bool init_Ontarget(const MVBuffer_Cfg_Ontarget& cfg);
		bool init_Offtarget(const MVBuffer_Cfg_Offtarget& cfg);

		//! @param width The width of target viewport, updated by the function
		//! @param height The height of target viewport, updated by the function
		//! @param viewId The requesting view
		//! @param cfg Obvious.
		void updateBufferSizeUsingCfg(int& width, int& height, uchar viewId, 
			const MVBuffer_Cfg_Offtarget_LoD& cfg);
	};

	inline bool MultiViewBuffer::hasOwnViewRects(){ 
		return mViewRects.size()>0; 
	}
} // namespace REng

#endif // _RENG_MULTIVIEWBUFFER_H_
