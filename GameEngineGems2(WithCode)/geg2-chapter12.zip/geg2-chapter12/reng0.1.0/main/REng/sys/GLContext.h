/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_GLCONTEXT_H__
#define _RENG_SYS_GLCONTEXT_H__

#include "REng/Platform.h"

// RenderTargetComp enum
#include "REng/Defines.h"
// Receives an OSWindow as initialization parameter
#include "REng/sys/OSWindow.h"

#include <log4cplus/logger.h>
using namespace log4cplus;

namespace REng{

	enum GLContextParamVal{
		GLCntxtParFalse    = 0x00,
		GLCntxtParTrue     = 0x01,
		GLCntxtParDontCare = 0xAA ///< Some large arbitrary number
	};

	#ifndef WGL_CONTEXT_ES2_PROFILE_BIT_EXT		
	#define WGL_CONTEXT_ES2_PROFILE_BIT_EXT 0x00000004
	#endif

	//! The list of recognized OpenGL Context profiles
	enum GLContextProfile{
		GLContextProfile_ES            = WGL_CONTEXT_ES2_PROFILE_BIT_EXT,      ///< ES Profile
		GLContextProfile_Core          = GL_CONTEXT_CORE_PROFILE_BIT,          ///< Core Profile
		GLContextProfile_Compatibility = GL_CONTEXT_COMPATIBILITY_PROFILE_BIT, ///< Compability profile
		GLContextProfile_DontCare      = 0xF0                                  ///< No specific profile
	};

	// TODO:
	// - Add debug context setup

	//! The list of recognized values for context parameters
	enum GLContextParam{
		//! Marks end of context parameters
		GLCntxtParNull         = 0x00,

		//! Denotes the OpenGL profile to be used
		//! @note Allowed values: GLContextProfile enumerations
		//! @note Default: GLContextProfile_DontCare
		GLCntxtParProfile      = 0x01,

		//! If 0, multi-sampling not used. Else, stores the requested number of samples per pixel
		//! @note If non-zero, double-buffering will be automatically requested.
		//! @note Default: 0 (No multi-sampling)
		GLCntxtParSampleCount  = 0x02,

		//! Use this to request a specific OpenGL version
		//! @note Allowed values: GLCntxtParDontCare, 2 (OpenGL ES configs), >=3 (OpenGL Desktop configs)
		//! @note Default: GLCntxtParDontCare
		GLCntxtParGLVersionMaj = 0x03, 
		//! Use this to request a specific OpenGL version
		//! @note Default: GLCntxtParDontCare
		GLCntxtParGLVersionMin = 0x04,

		//! If true, double buffering will be enabled, scene is drawn to back buffer and then swapped
		//! @note Allowed values: GLCntxtParFalse, GLCntxtParTrue, GLCntxtParDontCare
		//! @note Default: GLCntxtParTrue
		GLCntxtParDoubleBuffer = 0x05, 

		//! If true, double buffering will be enabled, scene is drawn to back buffer and then swapped
		//! @note Allowed values: GLCntxtParFalse, GLCntxtParTrue, GLCntxtParDontCare
		//! @note Default: GLCntxtParFalse
		//! @remark Not supported by EGL OpenGL ES 2.0 contexts
		GLCntxtParStereoBuffer = 0x06, 
	
		//! Denotes the minimum requested resolution of depth buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested (pref. 16/24/32 bits)
		//! @note Default: 24
		GLCntxtParDepthRes     = 0x07, 
		//! Denotes the minimum requested resolution of stencil buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested (pref. 1/2/4/8 bits)
		//! @note Default: 0 (no stencil buffer requested)
		GLCntxtParStencilRes   = 0x08,
		//! Denotes the minimum requested resolution of red color buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested
		//! @note Default: 8
		GLCntxtParRedRes       = 0x09,
		//! Denotes the minimum requested resolution of green color buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested
		//! @note Default: 8
		GLCntxtParGreenRes     = 0x0A,
		//! Denotes the minimum requested resolution of blue color buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested
		//! @note Default: 8
		GLCntxtParBlueRes      = 0x0B,
		//! Denotes the minimum requested resolution of alpha color buffer
		//! @note Allowed values: GLCntxtParDontCare or the number of bits requested
		//! @note Default: 8
		GLCntxtParAlphaRes     = 0x0C,
	
		//! Option to set vertical-synch option
		//! @note If GLCntxtParTrue, double-buffering will be automatically requested.
		//! @note Allowed values: GLCntxtParFalse, GLCntxtParTrue, GLCntxtParDontCare
		//! @note Default: GLCntxtParFalse
		//! @remark You can change this setting after context is set up. @see GLContext
		//! @remark If graphics driver setting is forced by user, it can no effect.
		GLCntxtParVSynch       = 0x0D, 

		//! Maximum reserved enumeration ID
		GLCntxtPar_MAX         = 0x0E
	};

	/**
	 * The OpenGL Context abstraction.
	 * @author Adil Yalcin
	 */
	class GLContext {
	public:
		~GLContext();

		//! True iff the context has been init'ed and not released yet.
		bool isInited() const;
	
		//! Expands the param list into the mParamList member
		void setContextParams(const int* paramList);

		//! Creates and initializes an OpenGL context
		//! @param windowHandl A valid pointer to a OS window handle instance that has been initialized
		//! @param params Stores a list of null-terminated integers which hold configuration data.
		//! @note forwardOnly parameter has no effect for EGL contexts currently.
		virtual bool init(OSWindow* windowHandle) = 0;

		//! Releases the OpenGL Context
		virtual bool release() = 0;

		//! Swaps back buffer content to front buffer content, if using double-buffers.
		virtual bool swapBuffers() = 0;

		//! GLContext config logging is automatically called by the render system. Do whatever config logging you need here.
		virtual void logConfig();

		//! Forces vertical-synchronization setting
		virtual void setVSyncEnabled(bool flag) = 0;
		//! Retrieves vertical-synchronization setting, false if cannot be retrieved
		virtual bool isVSyncEnabled() const = 0;

		//! Returns if the context links to a double-buffered surface
		bool isDoubleBuffered() const;

		//! @return The sample count for multi-sampled rendering. 0 if multi-sampling is not enabled
		uchar getSamples() const;

		//! @return True if the render target can capture the given component (if getResolution>0)
		//! @remark To check if a render target can be a depth-target, use hasComponent(RTC_Depth)
		bool hasComponent(RenderTargetComp c) const;

		//! @return The bit-size of the given component in this render target.
		uchar getResolution(RenderTargetComp c) const;

	protected:
		//! Hidden constructor
		GLContext();

		bool mIsInited;
		bool mDoubleBuffered;

		//! The window handle which this context was created for
		OSWindow* mWindowHandle;

		uchar mSamples;

		//! @brief Stores the bit-size of 6 individual components
		uchar mBitSize_Comp[6];

		//! Checks if the pointer is a valid and initialized window handle
		static bool checkWindowHandle(OSWindow* windowHandle);

		void initParamList();
		uint* mParamList;
		uint getParamTotalColorRes() const;
		uint getParamTotalColorAlphaRes() const;
	};

	//////////////////////////////////////////////////////////////////////////
	// INLINE METHODS

	inline GLContext::GLContext() 
		:mIsInited(false)
		,mDoubleBuffered(true) 
		,mWindowHandle(0)
		,mSamples(0)
	{ 
		mParamList = new uint[GLCntxtPar_MAX];
		mBitSize_Comp[0] = 0;
		mBitSize_Comp[1] = 0;
		mBitSize_Comp[2] = 0;
		mBitSize_Comp[3] = 0;
		mBitSize_Comp[4] = 0;
		mBitSize_Comp[5] = 0;
	}
	inline GLContext::~GLContext() { 
		delete[] mParamList;
	}
	inline bool GLContext::checkWindowHandle(OSWindow* windowHandle){
		if(windowHandle==0) return false;
		return windowHandle->isValid();
	}
	inline bool GLContext::isInited() const{ 
		return mIsInited;
	}
	inline bool GLContext::isDoubleBuffered() const{
		return mDoubleBuffered;
	}
	inline void GLContext::logConfig() { 
		Logger logger = Logger::getInstance("RSys");
		LOG4CPLUS_INFO(logger,"GLContext: No config log is available.");
	}
	inline uchar GLContext::getSamples() const{
		return mSamples;
	}
	inline bool GLContext::hasComponent(RenderTargetComp c) const{
		return (mBitSize_Comp[c]>0);
	}
	inline uchar GLContext::getResolution(RenderTargetComp c) const{
		return mBitSize_Comp[c];
	}
	inline void GLContext::setContextParams(const int* paramList){
		initParamList();
		if(paramList==0) return;
		Logger logger = Logger::getInstance("RSys");
//		LOG4CPLUS_INFO(logger,"setContextParams..........*********");

//		LOG4CPLUS_INFO(logger,"After init...");
//		for(size_t i=1;i<GLCntxtPar_MAX;++i) LOG4CPLUS_INFO(logger,"mParamList["<<i<<"]:"<<int(mParamList[i]));

		for(size_t i=0 ; paramList[i]!=GLCntxtParNull ; i+=2) {
			// checking index validty removed, it behaved strangely on Linux platform... (?)
			mParamList[paramList[i]] = paramList[i+1];
		}
		
//		LOG4CPLUS_INFO(logger,"After updates...");
//		for(size_t i=1;i<GLCntxtPar_MAX;++i) LOG4CPLUS_INFO(logger,"mParamList["<<i<<"]:"<<int(mParamList[i]));

		// correct some ill-parameters

		if(mParamList[GLCntxtParSampleCount]!=0)
			mParamList[GLCntxtParDoubleBuffer] = GLCntxtParTrue;
		if(mParamList[GLCntxtParVSynch]==GLCntxtParTrue)
			mParamList[GLCntxtParDoubleBuffer] = GLCntxtParTrue;

		if(mParamList[GLCntxtParProfile] != GLContextProfile_ES){
		if(mParamList[GLCntxtParProfile] != GLContextProfile_Core){
		if(mParamList[GLCntxtParProfile] != GLContextProfile_Compatibility){
		if(mParamList[GLCntxtParProfile] != GLContextProfile_DontCare){
			mParamList[GLCntxtParProfile] = GLContextProfile_DontCare;
		}}}}

		// GLVersion_Major must be don't care OR at least 3
		if(mParamList[GLCntxtParGLVersionMaj]<3)
			mParamList[GLCntxtParGLVersionMaj] = GLCntxtParDontCare;

//		LOG4CPLUS_INFO(logger,"After checks...");
//		for(size_t i=1;i<GLCntxtPar_MAX;++i) LOG4CPLUS_INFO(logger,"mParamList["<<i<<"]:"<<int(mParamList[i]));

	}
	inline uint GLContext::getParamTotalColorRes() const{
		int r = mParamList[GLCntxtParRedRes];
		int g = mParamList[GLCntxtParGreenRes];
		int b = mParamList[GLCntxtParBlueRes];
		return r+b+g;
	}
	inline uint GLContext::getParamTotalColorAlphaRes() const{
		int r = mParamList[GLCntxtParRedRes];
		int g = mParamList[GLCntxtParGreenRes];
		int b = mParamList[GLCntxtParBlueRes];
		int a = mParamList[GLCntxtParAlphaRes];
		return r+b+g+a;
	}
	inline void GLContext::initParamList(){
		mParamList[GLCntxtParNull]         = 0;
		mParamList[GLCntxtParProfile]      = GLContextProfile_DontCare;
		mParamList[GLCntxtParSampleCount]  = 0;
		mParamList[GLCntxtParGLVersionMaj] = GLCntxtParDontCare;
		mParamList[GLCntxtParGLVersionMin] = GLCntxtParDontCare;
		mParamList[GLCntxtParDoubleBuffer] = GLCntxtParTrue;
		mParamList[GLCntxtParStereoBuffer] = GLCntxtParFalse;
		mParamList[GLCntxtParDepthRes]     = 24;
		mParamList[GLCntxtParStencilRes]   = 0;
		mParamList[GLCntxtParRedRes]       = 8;
		mParamList[GLCntxtParGreenRes]     = 8;
		mParamList[GLCntxtParBlueRes]      = 8;
		mParamList[GLCntxtParAlphaRes]     = 8;
		mParamList[GLCntxtParVSynch]       = GLCntxtParFalse;
	}

} // namespace REng

#endif // _RENG_SYS_GLCONTEXT_H__
