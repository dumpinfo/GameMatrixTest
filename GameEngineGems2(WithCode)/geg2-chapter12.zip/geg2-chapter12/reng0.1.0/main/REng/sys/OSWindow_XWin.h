/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_OSWINDOW_XWIN_H__
#define _RENG_SYS_OSWINDOW_XWIN_H__

#include "REng/sys/OSWindow.h"

//////////////////////////////////////////////////////////////////////////
#ifdef USING_XLIB
//////////////////////////////////////////////////////////////////////////

#include <X11/Xlib.h>
#include <X11/Xutil.h>

namespace REng {

	//! createWindow requires a GLX instance to create a visual info. wtf?
	class GLContext_GLX;

	/*
	 * OSWindow abstraction for X-Window System (Linux)
	 * @note You can extend this class in your applications if you want to specialize some of the basic calls
	 * @author Adil Yalcin
	 */
	class RENGAPI OSWindow_X : public OSWindow {
	public:
		OSWindow_X();
		~OSWindow_X();
		virtual bool createWindow(const RectI& position, bool fullscreen=false, const char* windowTitle=0);
		bool destroyWindow();

		//! @brief Retrieve the X window
		//! @return 0 if no window is active, otherwise the window
		Window getWindow();
		//! @brief Retrieve the X display
		Display* getDisplay();
		//! @brief Retrieve the X Screen
		long getScreen();
		//! @brief Retrive the ColorMap used to create window
		Colormap getColormap();

		GLContext_GLX* mGLX;
		
		void testColormapStuff();

	protected:
		//! X11 related stuff
		Display* x11Display;
		Window x11Window;
		Colormap x11Colormap;
		long x11Screen;
		int xScreenDepth;
	};
} // namespace REng

//////////////////////////////////////////////////////////////////////////
#elif defined USING_WINCLS
//////////////////////////////////////////////////////////////////////////

#include <Windows.h>
#include <WinGDI.h>

namespace REng {

	/*
	 * OSWindow abstraction for WinClass System (Windows)
	 * @note You can extend this class in your applications if you want to specialize some of the basic calls
	 * @author Adil Yalcin
	 */
	class RENGAPI OSWindow_Win : public OSWindow {
	public:
		OSWindow_Win();
		~OSWindow_Win();
		virtual bool createWindow(const RectI& position, bool fullscreen=false, const char* windowTitle=0);
		bool destroyWindow();
		bool destroyWindow_KeepRegistry();
		
		//! WndProc Message Handler
		static LRESULT CALLBACK WndProcHandler(HWND, UINT, WPARAM, LPARAM);
		
		HDC getDeviceContext() const;
		HWND getWindowHandle() const;
		bool releaseDeviceContext();

	protected:
		HDC       hDC;       ///< Private GDI Device Context
		HWND      hWnd;      ///< Holds Our Window Handle
		HINSTANCE hInstance; ///< Holds The Instance Of The Application

		const char *mClassName;
		bool mIsClassRegistered;
		virtual bool registerClass();
		bool unregisterClass();

		void logPossibleVideoSettings();
	};
} // namespace REng

//////////////////////////////////////////////////////////////////////////
#endif // USING_WINCLS
//////////////////////////////////////////////////////////////////////////

#endif // _RENG_SYS_OSWINDOW_XWIN_H__
