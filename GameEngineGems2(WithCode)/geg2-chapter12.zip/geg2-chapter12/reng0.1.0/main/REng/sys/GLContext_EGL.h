/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_EGL_H_
#define _RENG_SYS_EGL_H_

#include "REng/Platform.h"

#ifdef USING_EGL // second guard

#include "REng/Singleton.h"
#include "REng/sys/GLContext.h"

#include <EGL/egl.h>

namespace REng {

	class OSWindow;

	/*
	 * @brief EGL Context manager for OpenGL ES 2.0 Client API
	 * @author Adil Yalcin
	 */
	class GLContext_EGL : public GLContext {
	public:
		GLContext_EGL();
		~GLContext_EGL();
		
		bool init(OSWindow* windowHandle);
		bool release();
		bool swapBuffers();
		void logConfig();

		void setVSyncEnabled(bool flag);
		bool isVSyncEnabled() const;

		//////////////////////////////////////////////////////////////////////////
		// EGL-specific stuff

		EGLint getVersion_Major() const;
		EGLint getVersion_Minor() const;
		const char *getClientAPIs() const;
		const char *getExtensions() const;
		const char *getVendor() const;
		const char *getVersion() const;

	private:
		// EGL variables
		EGLDisplay mDisplay;
		EGLSurface mSurface;
		EGLConfig mSelectedConfig;
		EGLContext mGLContext;

		bool mVSynchEnabled;

		// EGL info
		EGLint      mVersion_Major;
		EGLint      mVersion_Minor;
		const char *mClientAPIs;
		const char *mExtensions;
		const char *mVendor;
		const char *mVersion;

		//! Logs given EGLCongig data
		void logEGLConfigAttribs(EGLConfig cfg);
		void updateResolutions();

		//! @brief Transforms the EGL error into string representation (is error holds a valid EGL error code)
		static const char* getErrorStr(EGLint errCode);
		//! Logs EGL error if any, and returns if there is any EGL erros
		static bool testEGLError();
	};

	inline EGLint GLContext_EGL::getVersion_Major() const   { return mVersion_Major; }
	inline EGLint GLContext_EGL::getVersion_Minor() const   { return mVersion_Minor; }
	inline const char *GLContext_EGL::getClientAPIs() const { return mClientAPIs;    }
	inline const char *GLContext_EGL::getExtensions() const { return mExtensions;    }
	inline const char *GLContext_EGL::getVendor() const     { return mVendor;        }
	inline const char *GLContext_EGL::getVersion() const    { return mVersion;       }

} // namespace REng

#endif // USING_XLIB

#endif // _RENG_SYS_EGL_H_
