/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_GLX_H_
#define _RENG_SYS_GLX_H_

#include "REng/Platform.h"

#ifdef USING_GLX // second guard

#include "REng/Singleton.h"
#include "REng/sys/GLContext.h"

#include <GL/glx.h>

namespace REng {

	class OSWindow;
	class OSWindow_X;

	typedef GLXContext (*glXCreateContextAttribsARBProc)(Display*,GLXFBConfig,GLXContext,Bool,const int*);
	typedef void       (*glXSwapIntervalEXTProc)(Display*,GLXDrawable,int);
	typedef void       (*glXSwapIntervalSGIProc)(int);

	/*
	 * @brief GLX Context manager for OpenGL Desktop Client API
	 * @author Adil Yalcin
	 */
	class GLContext_GLX : public GLContext {
	public:
		GLContext_GLX();
		~GLContext_GLX();
		
		bool init(OSWindow* windowHandle);
		bool release();
		bool swapBuffers();
		void logConfig();

		void setVSyncEnabled(bool flag);
		bool isVSyncEnabled() const;

		//////////////////////////////////////////////////////////////////////////
		// GLX-specific stuff

		//! @return True on success
		bool updateVisInfo(OSWindow_X* windowHandle);
		XVisualInfo *getVisInfo();

		//! Before init() is called, X-Window wants GLContext_GLX to create
		//! a window surface, which requires GLContext initialization attributes and values.
		//! So, RenderSystem is expected to assign this to a valid memory before creating a window.
		const int* mParamsHack;

		int getVersion_Major() const;
		int getVersion_Minor() const;
		const char *getClientAPIs() const;
		const char *getExtensions() const;
		const char *getVendor() const;
		const char *getVersion() const;

	private:
		GLXContext mContext;
		XVisualInfo *mVisInfo;
		GLXFBConfig *mFrameBufConfigs;
		int mSelectedFrameBufConfig;

		int mVersion_Major;
		int mVersion_Minor;
		const char* mExtensions;
		const char* mVendor;
		const char* mVersion;

		//! Brand new context attribute setup
		void setContextAttribs(int* contextAttribs);

		//! Call after a WGL context is setup
		void readExtensions();
		//! @note call after readExtensions is called
		bool isExtensionSupported(const char *extension);
		glXCreateContextAttribsARBProc glXCreateContextAttribsARB;
		glXSwapIntervalEXTProc glXSwapIntervalEXT;
		glXSwapIntervalSGIProc glXSwapIntervalSGI;

		//! Stores the extension string list
		char **mExtentionInfoList;
		//! The total number of extensions in info list
		size_t mExtentionCount;

		void logFBConfigAttribs(GLXFBConfig cfg);
	};

	inline XVisualInfo *GLContext_GLX::getVisInfo()         { return mVisInfo;       }
	inline int GLContext_GLX::getVersion_Major() const      { return mVersion_Major; }
	inline int GLContext_GLX::getVersion_Minor() const      { return mVersion_Minor; }
	inline const char *GLContext_GLX::getExtensions() const { return mExtensions;    }
	inline const char *GLContext_GLX::getVendor() const     { return mVendor;        }
	inline const char *GLContext_GLX::getVersion() const    { return mVersion;       }

} // namespace REng

#endif // USING_GLX

#endif // _RENG_SYS_GLX_H_
