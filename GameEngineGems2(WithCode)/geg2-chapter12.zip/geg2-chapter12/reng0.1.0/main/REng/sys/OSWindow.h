/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_OSWINDOW_H__
#define _RENG_SYS_OSWINDOW_H__

#include "REng/Platform.h"
#include "REng/Rect.h"

namespace REng {

	/*
	 * OSWindow abstraction
	 * @author Adil Yalcin
	 */
	class RENGAPI OSWindow {
	public:
		//! @return True if this OSWindow is successfully created.
		bool isValid() const;
		//! @return The position of the window on OS target display
		const RectI& getPosition() const;
		//! @return Is this window in full-screen mode?
		bool isFullscreen() const;
		const char* getWindowTitle() const;

		//! @note The width/height stored in position is used as the resolution when fullscreen mode is enabled
		//! @return True if window is successfully created
		virtual bool createWindow(const RectI& position, bool fullscreen=false, const char* windowTitle=0) = 0;
		//! @return True if window is successfully destroyed
		virtual bool destroyWindow() = 0;

	protected:
		OSWindow();

		bool mIsValid;
		RectI mPosition;
		bool mFullScreen;
		char *mWindowTitle;
	};

	inline OSWindow::OSWindow() : mIsValid(false),mFullScreen(false),mWindowTitle(0) { ; }
	inline bool OSWindow::isValid() const{ return mIsValid; }
	inline const RectI& OSWindow::getPosition() const{ return mPosition; }
	inline bool OSWindow::isFullscreen() const{ return mFullScreen; }
	inline const char* OSWindow::getWindowTitle() const { return mWindowTitle; }

} // namespace REng

#endif // _RENG_SYS_OSWINDOW_H__
