/****************************************************************************
Copyright 2010 Bilkent University

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. 
You may obtain a copy of the License at 
http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, software 
distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and 
limitations under the License. 
****************************************************************************/
#ifndef _RENG_SYS_WGL_H_
#define _RENG_SYS_WGL_H_

#include "REng/Platform.h"

#ifdef USING_WGL // second guard

#include "REng/sys/GLContext.h"

#include "GL/wglew.h"

#include <windows.h>
#include <WinGDI.h>

namespace REng{

	class OSWindow;

	/*
	 * @brief WGL Context manager for OpenGL Desktop Client API
	 * @author Adil Yalcin
	 */
	class GLContext_WGL : public GLContext{
	public:
		GLContext_WGL();
		
		bool init(OSWindow* windowHandle);
		bool release();
		bool swapBuffers();
		void logConfig();

		void setVSyncEnabled(bool flag);
		bool isVSyncEnabled() const;
		bool isDoubleBuffered() const;

	private:
		HGLRC mGLContext;
		int mSelectedPixelFormat;

		//! Old-fashioned pixel format descriptor setup
		void setPixelFormatFlags(PIXELFORMATDESCRIPTOR& pfd);
		//! Brand new context attribute setup
		void setContextAttribs(int* contextAttribs);
		//! Brand new pixel format descriptor setup
		void setPixelFormatAttribs(int* pfAttrib);

		//! Old-fashioned pixel format selection
		bool choosePixelFormat(PIXELFORMATDESCRIPTOR& pfd, int& pixFormatIndex);
		bool setPixelFormat(PIXELFORMATDESCRIPTOR& pfd, int& pixFormatIndex);
		bool createGLContext(HGLRC& context);
		bool setGLContextCurrent(HGLRC& context);

		void logAllSupportedPixelFormats();
		void logPixelFormat(int pixelFormat);
		void updateResolutions();
		
		//////////////////////////////////////////////////////////////////////////
		// EXTENSION MANAGEMENT

		//! Call after a WGL context is setup
		void readExtensions();
		//! @note call after readExtensions is called
		bool isExtensionSupported(const char *extension);

		//! Stores the extension string list
		char **mExtentionInfoList;
		//! The total number of extensions in info list
		size_t mExtentionCount;

		void updateFuncPointers();
		// function extension pointers (ARB/EXT suffixes are removed)
		PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribs;
		PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtString;
		PFNWGLGETPIXELFORMATATTRIBIVARBPROC wglGetPixelFormatAttribiv;
		PFNWGLGETPIXELFORMATATTRIBFVARBPROC wglGetPixelFormatAttribfv;
		PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormat;
		PFNWGLSWAPINTERVALEXTPROC wglSwapInterval;
		PFNWGLGETSWAPINTERVALEXTPROC wglGetSwapInterval;

		//! @brief Transforms the WGL error into string representation
		static const char* getErrorStr(DWORD errCode);
		//! Logs EGL error if any, and returns if there is any WGL errors
		static bool testWGLError();
	};

} // namespace REng

#endif // USING_WGL

#endif // _RENG_SYS_WGL_H_
