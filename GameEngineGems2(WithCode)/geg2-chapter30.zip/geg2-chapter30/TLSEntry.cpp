#include "stdafx.h"
#include "TLSEntry.h"

namespace ThreadingFx
{

CTLSEntry::CTLSEntry()
{
#if defined(PLATFORM_WINDOWS)
	// aquire TLS
	m_TLSId = TlsAlloc();
	CHECK_EXPR(m_TLSId != TLS_OUT_OF_INDEXES);
#elif defined(PLATFORM_UNIX)
	CHECK_EXPR(pthread_key_create(&m_TLSKey, NULL) == 0);
#endif
}

CTLSEntry::~CTLSEntry()
{
#if defined(PLATFORM_WINDOWS)
	// free TLS
	TlsFree(m_TLSId);
#elif defined(PLATFORM_UNIX)
	pthread_key_delete(m_TLSKey);
#endif
}

void CTLSEntry::Set(const PVOID p_Value)
{
#if defined(PLATFORM_WINDOWS)
	TlsSetValue(m_TLSId, p_Value);
#elif defined(PLATFORM_UNIX)
	pthread_setspecific(m_TLSKey, p_Value);
#endif
}

PVOID CTLSEntry::Get() const
{
	PVOID ptr;
#if defined(PLATFORM_WINDOWS)
	ptr = (PVOID)TlsGetValue(m_TLSId);
#elif defined(PLATFORM_UNIX)
	ptr = (PVOID)pthread_getspecific(m_TLSKey);
#endif
	return ptr;
}

} // namespace ThreadingFx
