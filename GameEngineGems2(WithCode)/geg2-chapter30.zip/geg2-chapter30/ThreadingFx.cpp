// ThreadingFx.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ThreadingFx.h"

class TestFailedException : std::exception
{
    public:
		// printf will only work for non-unicode builds - just a dirty hack for the unit test cases below
        TestFailedException(LPCTSTR p_Expr, LPCTSTR p_File, int p_Line) { printf("Test failed: %s (%s:%d)\n", p_Expr, p_File, p_Line); }
};


typedef bool (*TESTFUNC)(void);
#define TEST_ISTRUE(expr) if(!(expr)) throw TestFailedException(_T(#expr), TFILE__, __LINE__)

static const intx MAXResCnt = 10;
volatile intx g_ResourceCnt = 0;

struct MyThreadInfo
{
	int* m_ThreadInstanceCount;
	ThreadingFx::WaitEvent m_hThreadStart;
	ThreadingFx::WaitEvent m_hThreadStop;

	MyThreadInfo(int* p_InstanceCount) : m_ThreadInstanceCount(p_InstanceCount), m_hThreadStart(_T("Thread Start"), true), m_hThreadStop(_T("Thread Stop"), true) {}
};

static void ThreadFunc1(PVOID p_pParam)
{
	using namespace ThreadingFx;

	MyThreadInfo* pInfo = (MyThreadInfo*)p_pParam;
	pInfo->m_ThreadInstanceCount++;
	pInfo->m_hThreadStart.Set();
	pInfo->m_hThreadStop.Wait();
	pInfo->m_ThreadInstanceCount--;
}

void TestStartStopThread()
{
	using namespace ThreadingFx;
	int InstanceCount = 0;
	MyThreadInfo* pInfo = new MyThreadInfo(&InstanceCount);
	ThreadInfoPtr pThread = ThreadManager::Get()->BeginThread(_T("Test Thread"), THREAD_START_PROCEDURE(ThreadFunc1), pInfo);
	TEST_ISTRUE(pInfo->m_hThreadStart.Wait(1000));
	pInfo->m_hThreadStop.Set();
	TEST_ISTRUE(pThread->WaitForThreadStop(1000));
	delete pInfo;
	TEST_ISTRUE(InstanceCount == 0);
}

void TestStartStopThread500()
{
	using namespace ThreadingFx;
	int InstanceCount = 0;
	for(int i = 0; i < 500; ++i)
	{
		MyThreadInfo* pInfo = new MyThreadInfo(&InstanceCount);
		ThreadInfoPtr pThread = ThreadingFx::ThreadManager::Get()->BeginThread(_T("Test Thread"), THREAD_START_PROCEDURE(ThreadFunc1), pInfo);
		TEST_ISTRUE(pInfo->m_hThreadStart.Wait(1000));
		pInfo->m_hThreadStop.Set();
		TEST_ISTRUE(pThread->WaitForThreadStop(1000));
		delete pInfo;
	}
	TEST_ISTRUE(InstanceCount == 0);
}

//////////////////////////////////////////////////////////////////////////
// This scenario tests named events and their manual-/auto-reset features.
//   Three threads are started that all wait for a named, auto-reset event to trigger.
//   If the event triggers the thread increments a (per-thread) counter.
//   The event is triggered 100 times, then the main thread stops each
//   thread by setting the (per-thread) stop-event.
//////////////////////////////////////////////////////////////////////////
struct NamedEventsThreadInfo
{
	ThreadingFx::WaitEvent m_hThreadWork;
	ThreadingFx::WaitEvent m_hThreadStop;
	int					 m_WorkSteps;

	NamedEventsThreadInfo() : m_hThreadWork(_T("Thread Work"), false, false, true), m_hThreadStop(_T("Thread Stop"), true, false, true) {}
};

static void NamedEventsThreadFunc(PVOID p_pParam)
{
	NamedEventsThreadInfo* pInfo = (NamedEventsThreadInfo*)p_pParam;
	pInfo->m_WorkSteps = 0;

	while(!pInfo->m_hThreadStop.Wait(0))
	{
		if(pInfo->m_hThreadWork.Wait(1000))
		{
			pInfo->m_WorkSteps++;
			InteropSleep(100);
		}
	}
}

void TestNamedEvents()
{
	using namespace ThreadingFx;

	NamedEventsThreadInfo* pInfo1 = new NamedEventsThreadInfo();
	NamedEventsThreadInfo* pInfo2 = new NamedEventsThreadInfo();
	NamedEventsThreadInfo* pInfo3 = new NamedEventsThreadInfo();

	ThreadInfoPtr pThread1 = ThreadManager::Get()->BeginThread(_T("Test Event Thread 1"), THREAD_START_PROCEDURE(NamedEventsThreadFunc), pInfo1);
	ThreadInfoPtr pThread2 = ThreadManager::Get()->BeginThread(_T("Test Event Thread 2"), THREAD_START_PROCEDURE(NamedEventsThreadFunc), pInfo2);
	ThreadInfoPtr pThread3 = ThreadManager::Get()->BeginThread(_T("Test Event Thread 3"), THREAD_START_PROCEDURE(NamedEventsThreadFunc), pInfo3);

	// trigger the shared work event every 50 ms, 100 times
	int workSteps = 100;
	do
	{
		InteropSleep(50);
		pInfo1->m_hThreadWork.Set();
		workSteps--;
	}
	while(workSteps > 0);

	pInfo1->m_hThreadStop.Set();
	pInfo2->m_hThreadStop.Set();
	pInfo3->m_hThreadStop.Set();

	// we call WaitForThreadStop 2 times for thread1 as an additional test
	TEST_ISTRUE(pThread1->WaitForThreadStop(2000));
	TEST_ISTRUE(pThread1->WaitForThreadStop(2000));
	TEST_ISTRUE(pThread2->WaitForThreadStop(2000));
	TEST_ISTRUE(pThread3->WaitForThreadStop(2000));

	printf(("Thread 1 did %d worksteps.\n"), pInfo1->m_WorkSteps);
	printf(("Thread 2 did %d worksteps.\n"), pInfo2->m_WorkSteps);
	printf(("Thread 3 did %d worksteps.\n"), pInfo3->m_WorkSteps);

	delete pInfo1;
	delete pInfo2;
	delete pInfo3;
}

//////////////////////////////////////////////////////////////////////////
// This test checks the Wait(INFINITE) operation on named events and
// evaluates if the event can handle multiple calls to Set/Reset functions
//////////////////////////////////////////////////////////////////////////
static void NamedEventsThreadFunc2(PVOID p_pParam)
{
	using namespace ThreadingFx;
	WaitEvent* stopEvent = (WaitEvent*)p_pParam;
	stopEvent->Wait(INFINITE);
}

void TestNamedEvents2()
{	
	using namespace ThreadingFx;

	WaitEvent stopEvent(_T("TestEvent"), true, false, true);

	// multiple sets must be ignored
	stopEvent.Set();
	stopEvent.Set();
	stopEvent.Set();

	// multiple resets must be ignored as well
	stopEvent.Reset();
	stopEvent.Reset();

	// start the thread - wait a bit and set the stop event
	ThreadInfoPtr pThread = ThreadingFx::ThreadManager::Get()->BeginThread(_T("Test Event Thread"), THREAD_START_PROCEDURE(NamedEventsThreadFunc2), &stopEvent);
	InteropSleep(1000);
	stopEvent.Set();

	TEST_ISTRUE(pThread->WaitForThreadStop(2000));
}

//////////////////////////////////////////////////////////////////////////
// This test evaluates the event and semaphore wait objects. There are two
// types of thread. One (CheckValueThread1) checks the content of m_Value
// for 1, the other checks m_Value's value for 2. CheckValueThread2s are
// blocked by the semaphore until all Thread1's are done checking the value
// for 2 and the ChangedEvent is set.
//////////////////////////////////////////////////////////////////////////

// set the amount of check threads (a value of 2 i.e. would start 2 CheckValueThread1 and 2 CheckValueThread2 threads)
#define NUM_SEMEVENTTEST_THREADS 2

// shared events and counters
struct SemEventTestStruct
{
	int	m_Value;
	volatile int m_ThreadCnt;
	ThreadingFx::WaitEvent m_ChangedEvent;
	ThreadingFx::WaitSemaphore m_Semaphore;

	SemEventTestStruct() : m_Value(1), m_ThreadCnt(0), m_ChangedEvent(_T("ChangedEvent"), true, false, false), m_Semaphore(_T("CheckSemaphore"), NUM_SEMEVENTTEST_THREADS) { }
};

static void CheckValueThread1(PVOID p_pParam)
{
	SemEventTestStruct* info = (SemEventTestStruct*)p_pParam;
	TEST_ISTRUE(info->m_Value == 1);

	// lock the semaphore and keep it locked until m_Value changed
	info->m_Semaphore.Lock();
	TEST_ISTRUE(info->m_Value == 1);

	// signal that this thread has started
	InteropInterlockedIncrement(info->m_ThreadCnt);

	// wait for value to be changed to 2
	info->m_ChangedEvent.Wait();

	// let other threads check
	info->m_Semaphore.Unlock();
}

static void CheckValueThread2(PVOID p_pParam)
{
	SemEventTestStruct* info = (SemEventTestStruct*)p_pParam;
	TEST_ISTRUE(info->m_Value == 1);

	// signal that this thread has started
	InteropInterlockedIncrement(info->m_ThreadCnt);

	// lock the semaphore, check if m_Value is 2 and exit
	info->m_Semaphore.Lock();
	TEST_ISTRUE(info->m_Value == 2);
	info->m_Semaphore.Unlock();
}

void TestSemEvent()
{
	using namespace ThreadingFx;

	SemEventTestStruct* info = new SemEventTestStruct();
	ThreadInfoPtr pThreads[NUM_SEMEVENTTEST_THREADS * 2];

	// start check1 threads
	for(uint i = 0; i < NUM_SEMEVENTTEST_THREADS; ++i)
	{
		tostringstream name;
		name << _T("Check1Thread") << i;
		pThreads[i] = ThreadManager::Get()->BeginThread(name.str().c_str(), THREAD_START_PROCEDURE(CheckValueThread1), info);
	}

	// wait until all check1 threads have started and checked value for 1
	while(info->m_ThreadCnt != NUM_SEMEVENTTEST_THREADS)
		InteropSleep(100);

	// start check2 threads
	for(uint i = 0; i < NUM_SEMEVENTTEST_THREADS; ++i)
	{
		tostringstream name;
		name << _T("Check2Thread") << i;
		pThreads[NUM_SEMEVENTTEST_THREADS + i] = ThreadManager::Get()->BeginThread(name.str().c_str(), THREAD_START_PROCEDURE(CheckValueThread2), info);
	}

	// wait until check2 threads started
	while(info->m_ThreadCnt != NUM_SEMEVENTTEST_THREADS * 2)
		InteropSleep(100);

	// change value and signal that we changed it
	info->m_Value = 2;
	info->m_ChangedEvent.Set();

	// check if all threads stopped
	for(uint i = 0; i < NUM_SEMEVENTTEST_THREADS * 2; ++i)
		TEST_ISTRUE(pThreads[i]->WaitForThreadStop(2000));

	delete info;
}

//////////////////////////////////////////////////////////////////////////
// Simple WaitForMultipleObjects test
//////////////////////////////////////////////////////////////////////////

// shared events and counters
struct WaitForMultipleObjectsTestStruct
{
	ThreadingFx::WaitEvent m_WaitEvent;
	ThreadingFx::WaitMutex m_WaitMutex;
	ThreadingFx::WaitEvent m_StartEvent;
	ThreadingFx::WaitEvent m_ContinueEvent;
	WaitForMultipleObjectsTestStruct() :	m_WaitEvent(_T("WaitEvent"), true, false, false),
											m_WaitMutex(_T("WaitMutex"), false, false),
											m_StartEvent(_T("StartEvent"), false, false, false),
											m_ContinueEvent(_T("ContinueEvent"), false, false, false) { }
};

static void WaitThread(PVOID p_pParam)
{
	using namespace ThreadingFx;

	WaitForMultipleObjectsTestStruct* info = (WaitForMultipleObjectsTestStruct*)p_pParam;
	WaitList waitList(info->m_WaitEvent, info->m_WaitMutex);

	info->m_StartEvent.Wait();
	TEST_ISTRUE(waitList.WaitForMultipleObjects() == WAIT_OBJECT_0);
	info->m_WaitEvent.Reset();
	info->m_ContinueEvent.Set();
	TEST_ISTRUE(waitList.WaitForMultipleObjects() == (WAIT_OBJECT_0 + 1));
	info->m_WaitMutex.Unlock();
}


void TestWaitForMultipleObjects()
{
	using namespace ThreadingFx;

	WaitForMultipleObjectsTestStruct* info = new WaitForMultipleObjectsTestStruct();
	info->m_WaitMutex.Lock();

	// start wait thread
	ThreadInfoPtr pThread = ThreadManager::Get()->BeginThread(_T("WaitThread"), THREAD_START_PROCEDURE(WaitThread), info);

	// continue and signal the wait event
	info->m_StartEvent.Set();
	InteropSleep(500);
	info->m_WaitEvent.Set();

	// wait for the continue event
	info->m_ContinueEvent.Wait();

	// now unlock the mutex and check if the tread is ending
	info->m_WaitMutex.Unlock();
	TEST_ISTRUE(pThread->WaitForThreadStop(5000));

	delete info;
}

void TestWaitForMultipleObjectsTestSingleThreadInfinite()
{
	using namespace ThreadingFx;

	WaitMutex waitMutex(_T("TestMutex"));
	WaitList waitList(waitMutex);

	// now unlock the mutex and check if the tread is ending
	TEST_ISTRUE(waitList.WaitForMultipleObjects() == WAIT_OBJECT_0);
}

void TestWaitForMultipleObjectsTestSingleThreadPoll()
{
	using namespace ThreadingFx;

	WaitMutex waitMutex(_T("TestMutex"));
	WaitList waitList(waitMutex);

	// now unlock the mutex and check if the tread is ending
	TEST_ISTRUE(waitList.WaitForMultipleObjects(0) == WAIT_OBJECT_0);
}

void TestWaitForMultipleObjectsSingleThreadTimeout()
{
	using namespace ThreadingFx;

	WaitMutex waitMutex(_T("TestMutex"));
	WaitList waitList(waitMutex);

	// now unlock the mutex and check if the tread is ending
	TEST_ISTRUE(waitList.WaitForMultipleObjects(100) == WAIT_OBJECT_0);
}


struct InterlockedThreadInfo
{
	volatile int32 Counter;
};

static void InterlockThreadFunc(PVOID p_pParam)
{
	InterlockedThreadInfo* pInfo = (InterlockedThreadInfo*)p_pParam;

	for(intx i = 0; i < 10000; ++i)
	{
		InteropInterlockedIncrement32(pInfo->Counter);
		InteropSleep(0);
		InteropInterlockedDecrement32(pInfo->Counter);
		InteropSleep(0);
	}
}

void TestInterlockedFunctions()
{
	using namespace ThreadingFx;
	using namespace std;

	InterlockedThreadInfo* pInfo = new InterlockedThreadInfo;
	pInfo->Counter = 0;

	vector<ThreadInfoPtr> Threads;
	for(intx i = 0; i < 100; ++i)
	{
		tostringstream name;
		name << _T("Test Interlock Thread ") << i;
		Threads.push_back(ThreadManager::Get()->BeginThread(name.str().c_str(), THREAD_START_PROCEDURE(InterlockThreadFunc), pInfo));
    }

	for(intx i = 0; i < 100; ++i)
	{
		Threads[i]->WaitForThreadStop();
    }

    TEST_ISTRUE(pInfo->Counter == 0);

    delete pInfo;
}

void TestOpenCloseMutex()
{
	using namespace ThreadingFx;

	// create unnamed bool semaphore
	WaitMutex MutualEx(_T("OpenCloseMutex"), false, false);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.IsLocked() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 1);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 2);
	MutualEx.Unlock();
	TEST_ISTRUE(MutualEx.GetLockCount() == 1);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 2);
	MutualEx.Unlock();
	MutualEx.Unlock();
	TEST_ISTRUE(MutualEx.IsLocked() == false);
}

void TestOpenCloseMutexMax()
{
	bool bError = false;
	intx Cnt = 0;
	do
	{
		try
		{
			TestOpenCloseMutex();
			Cnt++;
		}
		catch(...)
		{
			bError = true;
		}
	}
	while((bError == false) && (Cnt < 1000000));

	TEST_ISTRUE(bError == false);
}

void TestOpenCloseNamedMutex()
{
	using namespace ThreadingFx;

	// create named bool semaphore with initial lock
	WaitMutex MutualEx(_T("OpenCloseNamedMutex"), false, true);
	TEST_ISTRUE(MutualEx.WasOpened() == false);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.IsLocked() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 1);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 2);
	MutualEx.Unlock();
	TEST_ISTRUE(MutualEx.GetLockCount() == 1);
	TEST_ISTRUE(MutualEx.Lock() == true);
	TEST_ISTRUE(MutualEx.GetLockCount() == 2);
	MutualEx.Unlock();
	MutualEx.Unlock();
	TEST_ISTRUE(MutualEx.IsLocked() == false);
}

void TestOpenCloseNamedMutexMax()
{
	bool bError = false;
	intx Cnt = 0;
	do
	{
		try
		{
			TestOpenCloseNamedMutex();
			Cnt++;
		}
		catch(...)
		{
			bError = true;
		}
	}
	while((bError == false) && (Cnt < 1000000));

	TEST_ISTRUE(bError == false);
}

void TestScopeNamedMutex()
{
	using namespace ThreadingFx;
	using namespace std;

	for(intx i = 0; i < 3; ++i)
	{
		vector<WaitMutexPtr> pMxArray;
		for(intx i = 0; i < 100; ++i)
		{
			tostringstream name;
			name << _T("ScopeNamedMutex") << i;
			WaitMutexPtr pMx(new WaitMutex(name.str().c_str(), false, true));
			TEST_ISTRUE(pMx->WasOpened() == false);
			pMxArray.push_back(pMx);
		}

		vector<WaitMutexPtr> pMxArrayVerify;
		for(intx i = 0; i < 100; ++i)
		{
			tostringstream name;
			name << _T("ScopeNamedMutex") << i;
			WaitMutexPtr pMx(new WaitMutex(name.str().c_str(), false, true));
			TEST_ISTRUE(pMx->WasOpened() == true);
			pMxArray.push_back(pMx);
		}
	}
}

static void CountedSemaphoreThread(PVOID p_pData)
{
	using namespace ThreadingFx;
	UNREFERENCED_PARAMETER(p_pData);

	try
	{
		WaitSemaphore ResourceLock(_T("Counted_Semaphore"), MAXResCnt, true);
		WaitLock Lock(&ResourceLock);

		InteropInterlockedIncrement(g_ResourceCnt);
		TEST_ISTRUE(g_ResourceCnt <= MAXResCnt);
		InteropSleep(500);
		InteropInterlockedDecrement(g_ResourceCnt);
	}
	catch(...)
	{
		// we could store error information in this thread's ThreadInfo like this:
		// ThreadManager::Get()->GetCurrentThreadInfo()->SetThreadError(p_Exception);
	}
}

void TestCountedSemaphore()
{
	using namespace ThreadingFx;
	typedef std::vector<ThreadInfoPtr> ThreadInfoPtrArray;
	ThreadInfoPtrArray Threads;

    // we have to be careful here as some Unix distributions don't allow that many threads in a single process
	// start threads
	for(intx i = 1; i < 60; ++i)
	{
		tostringstream name;
		name << _T("TestCountedSemaphore") << i;
		Threads.push_back(ThreadManager::Get()->BeginThread(name.str().c_str(), THREAD_START_PROCEDURE(CountedSemaphoreThread), NULL));
	}

	// wait until all threads have stopped
	for(ThreadInfoPtrArray::iterator i = Threads.begin(); i != Threads.end(); ++i)
		(*i)->WaitForThreadStop();

	// check if a thread error occurred
	for(ThreadInfoPtrArray::iterator i = Threads.begin(); i != Threads.end(); ++i)
	{
		// here we can check whether an error occured in one of our threads using the thread info:
		//	if((*i)->IsThreadError())
		//	{
		//		Handle error ...
		//	}
	}
}


#define RUN_TEST(func) \
	printf("Running test " #func "\n"); \
	try \
	{ \
		func(); \
		printf("Test " #func " successful!\n"); \
	} \
	catch(...) \
	{ \
		printf("Test " #func " failed!\n"); \
	}

#if defined(PLATFORM_WINDOWS)
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char* argv[])
#endif
{
	RUN_TEST(TestStartStopThread);
	RUN_TEST(TestStartStopThread500);
	RUN_TEST(TestNamedEvents);
	RUN_TEST(TestNamedEvents2);
	RUN_TEST(TestSemEvent);
	RUN_TEST(TestWaitForMultipleObjects);
	RUN_TEST(TestWaitForMultipleObjectsTestSingleThreadInfinite);
	RUN_TEST(TestWaitForMultipleObjectsTestSingleThreadPoll);
	RUN_TEST(TestWaitForMultipleObjectsSingleThreadTimeout);
	RUN_TEST(TestInterlockedFunctions);
	RUN_TEST(TestOpenCloseMutex);
	RUN_TEST(TestOpenCloseMutexMax);
#if defined(PLATFORM_WINDOWS)
	RUN_TEST(TestOpenCloseNamedMutex);
	RUN_TEST(TestOpenCloseNamedMutexMax);
#endif 
	RUN_TEST(TestScopeNamedMutex);
	RUN_TEST(TestCountedSemaphore);


	return 0;
}

