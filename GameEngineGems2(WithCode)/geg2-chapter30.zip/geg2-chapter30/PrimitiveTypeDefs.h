//*****************************************************************************
// Description:  primitive library type definitions
//*****************************************************************************

#ifndef TREADINGFX_PRIMITIVETYPEDEFS_H
#define TREADINGFX_PRIMITIVETYPEDEFS_H



//*****************************************************************************
//** data type definitions
//*****************************************************************************

// in MSVC we have no C99 stdint.h file ...
#if defined(_MSC_VER)

typedef __int8           int8_t;
typedef unsigned __int8  uint8_t;

typedef __int16          int16_t;
typedef unsigned __int16 uint16_t;

typedef __int32          int32_t;
typedef unsigned __int32 uint32_t;

typedef __int64          int64_t;
typedef unsigned __int64 uint64_t;

#else

// define to have the C99 limit macros available when compiling C++ code
#ifndef __STDC_LIMIT_MACROS
	#define __STDC_LIMIT_MACROS
#endif

#include <stdint.h>
#endif

// explicit numerical types with size
typedef int8_t		int8;
typedef uint8_t		uint8;

typedef int16_t		int16;
typedef uint16_t	uint16;

typedef int32_t		int32;
typedef uint32_t	uint32;

typedef int64_t		int64;
typedef uint64_t	uint64;


// byte type
typedef uint8 byte;


// short named unsigned types
typedef uint8 uchar;
typedef uint16 ushort;
typedef uint32 uint;
typedef uint64 ulonglong;


// 32/64 bit platform dependent types
#if defined(API_32BIT)
	typedef int32 intx;
	typedef uint32 uintx;
	#define sizeof_intx (4)
	#define digits_intx (8)
#else
	typedef int64 intx;
	typedef uint64 uintx;
	#define sizeof_intx (8)
	#define digits_intx (16)
#endif


// special index type, used to convert 64 bit indices to access managed arrays without compiler warning
#if defined(PLATFORM_NATIVE)
	typedef intx size_idx;
#else
	typedef int size_idx;
#endif


#endif // #ifndef TREADINGFX_PRIMITIVETYPEDEFS_H
