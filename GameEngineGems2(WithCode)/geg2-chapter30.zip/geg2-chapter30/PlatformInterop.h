//*****************************************************************************
// Description:  platform interop includes and definitions
//*****************************************************************************

#ifndef TREADINGFX_PLATFORMINTEROP_H
#define TREADINGFX_PLATFORMINTEROP_H


//*****************************************************************************
//** Platform and sub-platform (API) definitions
//*****************************************************************************

// API definitions
#if defined(_WIN32) || defined(_WIN64)
	#define API_WINDOWS
#elif defined(__APPLE_CC__)
	#define API_APPLE
#elif defined(__linux) || defined(__linux__) || defined(__gnu_linux__)
	#define API_LINUX
#else
	#define API_UNIX
#endif


// platform definitions
#if !defined(PLATFORM_WINDOWS) && !defined(PLATFORM_UNIX)
	#if defined(API_WINDOWS)
		#define PLATFORM_WINDOWS
		#define PLATFORM_NATIVE
	#elif defined(API_UNIX) || defined(API_LINUX) || defined(API_APPLE)
		#define PLATFORM_UNIX
		#define PLATFORM_NATIVE
	#endif
#endif

//*****************************************************************************
//** Target specific definitions
//*****************************************************************************

// 64 bit environment
#if !defined(API_32BIT) && !defined(API_64BIT)
	#if defined(_WIN64) || defined(__LP64__) || defined(__LP64)
		#define API_64BIT
	#else
		#define API_32BIT
	#endif
#endif

// character default encoding type
#if !defined(API_CHAR_UNICODE) && !defined(API_CHAR_ANSI)
	#if defined(_UNICODE)
		#define API_CHAR_UNICODE
	#else
		#define API_CHAR_ANSI
	#endif
#endif


//*****************************************************************************
//** Verify compile configuration settings
//*****************************************************************************

#if !defined(PLATFORM_WINDOWS) && !defined(PLATFORM_UNIX)
	#error ThreadingFx: Invalid Platform definition.
#endif

#if (defined(API_32BIT) && defined(API_64BIT)) || (!defined(API_32BIT) && !defined(API_64BIT))
	#error ThreadingFx: Invalid Architecture definition.
#endif

#if (defined(API_CHAR_UNICODE) && defined(API_CHAR_ANSI)) || (!defined(API_CHAR_UNICODE) && !defined(API_CHAR_ANSI))
	#error ThreadingFx: Invalid Character Encoding definition.
#endif

//*****************************************************************************
//** include platform specific definitions
//*****************************************************************************

// library base macros
#include "BaseMacro.h"

// define primitive types
#include "PrimitiveTypeDefs.h"


// win32 native api
#if defined(PLATFORM_WINDOWS)
#include "InteropWin.h"

// unix api
#elif defined(PLATFORM_UNIX)
#include "InteropUnix.h"

#endif

// error handling/exceptions
#include "Error.h"

#endif // #ifndef TREADINGFX_PLATFORMINTEROP_H
