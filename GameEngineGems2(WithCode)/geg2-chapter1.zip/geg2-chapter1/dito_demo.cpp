/*
Supplemental C/C++ implementation of the DiTO OBB construction method described in the
chapter "Fast Computation of Tight-Fitting Oriented Bounding Boxes" of the book "Game 
Engine Gems 2".
*/

/*
This source file is distributed under the following BSD license:

Copyright 2011 Thomas Larsson and Linus Kallberg. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THOMAS LARSSON AND LINUS KALLBERG ``AS IS'' AND ANY EXPRESS
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THOMAS LARSSON, LINUS 
KALLBERG, OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
Example file showing how to use the DiTO-14 implementation.
Version: 1.0

In this simple case, an optimal enclosing OBB is found for a set of 12 points. 
To demonstrate how to use other vertex representations than the DiTO::Vector 
structure, the points are stored in a primitive array with their components 
interleaved as { x0, y0, z0, x1, ... }.
*/

#include "dito.h"
#include <iostream>

std::ostream& operator <<(std::ostream& o, DiTO::Vector<float>& u)
{ return o << '(' << u.x << ',' << u.y << ',' << u.z << ')'; }

int main()
{	float points[] =
	{	-1, -1, 1,
		1, -1, 1,
		1, 1, 1,
		-1, 1, 1,
		-1, -1, -1,
		1, -1, -1,
		1, 1, -1,
		-1, 1, -1,		
		-0.5, -0.5, 1,
		1, 0.5, -0.5,
		0.5, 0.5, -1,
		-1, -0.5, 0.5,
	};
	
	DiTO::OBB<float> obb;
	DiTO::DiTO_14<float>((DiTO::Vector<float>*) points, 12, obb);

	std::cout << "Computed OBB:\n";
	std::cout << "\tMidpoint:" << obb.mid;
	std::cout << "\n\tv0: " << obb.v0;
	std::cout << "\n\tv1: " << obb.v1;
	std::cout << "\n\tv2: " << obb.v2;
	std::cout << "\n\text: " << obb.ext;
	std::cout << "\n\tArea: " << 2*(obb.ext.x*obb.ext.y + obb.ext.x*obb.ext.z + obb.ext.y*obb.ext.z);
}
