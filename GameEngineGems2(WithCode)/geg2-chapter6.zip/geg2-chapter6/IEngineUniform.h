#pragma once

class State;

class IEngineUniform
{
public:
    virtual ~IEngineUniform() {}
    virtual void Set(const State& state) = 0;
};