#pragma once

#include "IEngineUniform.h"
#include "State.h"

class ModelViewMatrixUniform : public IEngineUniform
{
public:
    ModelViewMatrixUniform(Uniform *uniform)
        : m_uniform(uniform)
    {
    }

    virtual void Set(const State& state)
    {
        m_uniform->SetValue(state.GetModelView());
    }

private:
    Uniform *m_uniform;
};