#pragma once

#include "ShaderProgram.h"

class State;

class Context
{
public:
    void Draw(ShaderProgram &shaderProgram, const State& state)
    {
        // glUseProgram
        shaderProgram.Clean(state);

        // glDrawArrays, glDrawElements, etc
    }
};