#pragma once

#include <string>
#include <vector>
#include <map>
#include <algorithm>

#include "GLStubs.h"
#include "ICleanable.h"
#include "ICleanableObserver.h"
#include "Uniform.h"
#include "IEngineUniform.h"
#include "IEngineUniformFactory.h"
#include "ModelViewMatrixFactory.h"
#include "State.h"

class ShaderProgram : public ICleanableObserver
{
public:
    static void InitializeEngineUniforms()
    {
        m_engineUniformFactories["u_modelViewMatrix"] = new EngineUniformFactory<ModelViewMatrixUniform>;
    }

    static void DestroyEngineUniforms()
    {
        std::map<std::string, IEngineUniformFactory *>::iterator i;
        for (i = m_engineUniformFactories.begin(); i != m_engineUniformFactories.end(); ++i)
        {
            delete i->second;
        }
        m_engineUniformFactories.clear();
    }

    ShaderProgram(const std::string& vertexSource, const std::string& fragmentSource)
    {
        m_handle = glCreateProgram();
        // ... Create, compile, and link shader objects

        // TODO: populate
        m_uniformMap["u_anotherMatrix"] = new Uniform(0, this);
        m_uniformMap["u_modelViewMatrix"] = new Uniform(1, this);

        std::map<std::string, Uniform *>::iterator i;
        for (i =m_uniformMap.begin(); i != m_uniformMap.end(); ++i)
        {
            std::map<std::string, IEngineUniformFactory *>::iterator j =
                m_engineUniformFactories.find(i->first);

            if (j != m_engineUniformFactories.end())
            {
                m_engineUniformList.push_back(j->second->Create(i->second));
            }
        }
    }

    virtual ~ShaderProgram()
    {
        // Delete shader objects, shader program, and uniforms allocated in the constructor

        // ... Delete shader objects, etc 
        glDeleteProgram(m_handle);

        for (std::map<std::string, Uniform *>::iterator i = m_uniformMap.begin(); i != m_uniformMap.end(); ++i)
        {
            delete i->second;
        }
    }

    Uniform *GetUniformByName(const std::string name)
    {
        std::map<std::string, Uniform *>::iterator i = m_uniformMap.find(name);
        
        return (i != m_uniformMap.end()) ? i->second : 0;
    }

    void Clean(const State& state)
    {
        std::vector<IEngineUniform *>::iterator i;
        for (i = m_engineUniformList.begin(); i != m_engineUniformList.end(); ++i)
        {
            (*i)->Set(state);
        }

        std::for_each(m_dirtyUniforms.begin(), m_dirtyUniforms.end(), 
            std::mem_fun(&ICleanable::Clean));

        m_dirtyUniforms.clear();
    }

    // ICleanableObserver Implementation
    virtual void NotifyDirty(ICleanable *value)
    {
        m_dirtyUniforms.push_back(value);
    }

private:
    GLuint m_handle;
    std::vector<ICleanable *> m_dirtyUniforms;
    std::map<std::string, Uniform *> m_uniformMap;

    std::vector<IEngineUniform *> m_engineUniformList;
    static std::map<std::string, IEngineUniformFactory *> m_engineUniformFactories;
};
