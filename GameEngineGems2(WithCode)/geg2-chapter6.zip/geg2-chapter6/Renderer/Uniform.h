#pragma once

#include "GLStubs.h"
#include "Matrix44.h"
#include "ICleanable.h"
#include "ICleanableObserver.h"

class Uniform : public ICleanable
{
public:
    Uniform(GLint location, ICleanableObserver *observer)
        : m_location(location),
          m_currentValue(),
          m_dirty(true),
          m_observer(observer)
    {
        m_observer->NotifyDirty(this);
    }

    const Matrix44& GetValue() const
    {
        return m_currentValue;
    }

    void SetValue(const Matrix44& value)
    {
        if (!m_dirty && (m_currentValue != value))
        {
            m_dirty = true;
            m_observer->NotifyDirty(this);
        }

        m_currentValue = value;
    }

    // ICleanable Implementation
    virtual void Clean()
    {
        glUniformMatrix4fv(m_location, 0, GL_FALSE, m_currentValue.Pointer());
        m_dirty = false;
    }

private:
    GLint m_location;
    Matrix44 m_currentValue;
    bool m_dirty;
    ICleanableObserver *m_observer;
};
