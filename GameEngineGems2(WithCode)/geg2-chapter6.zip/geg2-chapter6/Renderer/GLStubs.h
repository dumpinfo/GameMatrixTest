#pragma once

typedef unsigned char GLboolean;
typedef int GLint;
typedef int GLsizei;
typedef unsigned int GLuint;
typedef float GLfloat;

#define GL_FALSE 0
#define GL_TRUE 1


inline GLuint glCreateProgram(void)
{
    return 0;
}

inline void glDeleteProgram(GLuint program)
{
}

inline void glUniformMatrix4fv(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value)
{
}