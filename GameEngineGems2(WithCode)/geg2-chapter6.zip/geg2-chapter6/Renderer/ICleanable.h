#pragma once

class ICleanable
{
public:
    virtual ~ICleanable() {}
    virtual void Clean() = 0;
};