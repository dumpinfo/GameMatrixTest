#pragma once

#include "Matrix44.h"

/*
class State
{
public:

    const Matrix44& GetModel() const { return m_model; }
    void SetModel(const Matrix44& value) { m_model = value; }

    const Matrix44& GetView() const { return m_view; }
    void SetView(const Matrix44& value) { m_view = value; }

    const Matrix44& GetProjection() const { return m_projection; }
    void SetProjection(const Matrix44& value) { m_projection = value; }

    const Matrix44& GetModelView() const { return m_view * m_model; }
    const Matrix44& GetModelViewProjection() const { return m_projection * ModelView(); }

private:
    Matrix44 m_model;
    Matrix44 m_view;
    Matrix44 m_projection;
};
*/

class State
{
public:
    State()
        : m_modelViewDirty(true),
          m_modelViewProjectionDirty(true)
    {
    }

    const Matrix44& GetModel() const { return m_model; }
    void SetModel(const Matrix44& value)
    { 
        m_model = value; 
        m_modelViewDirty = true;
        m_modelViewProjectionDirty = true;
    }

    const Matrix44& GetView() const { return m_view; }
    void SetView(const Matrix44& value)
    { 
        m_view = value;
        m_modelViewDirty = true;
        m_modelViewProjectionDirty = true;
    }

    const Matrix44& GetProjection() const { return m_projection; }
    void SetProjection(const Matrix44& value)
    { 
        m_projection = value; 
        m_modelViewProjectionDirty = true;
    }

    const Matrix44& GetModelView() const
    { 
        if (m_modelViewDirty)
        {
            m_modelView = m_view * m_model;
            m_modelViewDirty = false;
        }

        return m_modelView; 
    }

    const Matrix44& GetModelViewProjection() const
    { 
        if (m_modelViewProjectionDirty)
        {
            m_modelViewProjection = m_projection * GetModelView();
            m_modelViewProjectionDirty = true;
        }

        return m_modelViewProjection;
    }

private:
    Matrix44 m_model;
    Matrix44 m_view;
    Matrix44 m_projection;

    mutable Matrix44 m_modelView;
    mutable Matrix44 m_modelViewProjection;

    mutable bool m_modelViewDirty;
    mutable bool m_modelViewProjectionDirty;
};