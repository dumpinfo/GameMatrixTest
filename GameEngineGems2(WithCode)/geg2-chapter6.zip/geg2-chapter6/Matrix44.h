#pragma once

#include "GLStubs.h"

class Matrix44
{
public:
    Matrix44 operator*(const Matrix44& other) const
    {
        return Matrix44();
    }

	Matrix44& operator=(const Matrix44& other)
    {
        return *this;
    }

	bool operator==(const Matrix44& other) const
    {
        return false;
    }

	bool operator!=(const Matrix44& other) const
    {
        return !(*this == other);
    }

    const GLfloat *Pointer() const
    {
        return 0;
    }
};
