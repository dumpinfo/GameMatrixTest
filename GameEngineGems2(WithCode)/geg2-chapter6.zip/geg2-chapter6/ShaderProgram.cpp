#include "ShaderProgram.h"

std::map<std::string, IEngineUniformFactory *> ShaderProgram::m_engineUniformFactories;
