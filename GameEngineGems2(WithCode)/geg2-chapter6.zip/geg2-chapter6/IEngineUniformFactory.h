#pragma once

#include <string>

class Uniform;

class IEngineUniformFactory
{
public:
    virtual ~IEngineUniformFactory() {}
    virtual IEngineUniform *Create(Uniform *uniform) = 0;
};