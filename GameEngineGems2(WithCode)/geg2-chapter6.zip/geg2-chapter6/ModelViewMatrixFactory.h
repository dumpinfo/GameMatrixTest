#pragma once

#include "IEngineUniformFactory.h"
#include "ModelViewMatrixUniform.h"

//class ModelViewMatrixFactory : public IEngineUniformFactory
//{
//public:
//    virtual IEngineUniform *Create(Uniform *uniform)
//    { 
//        return new ModelViewMatrixUniform(uniform);
//    }
//};

template<typename T>
class EngineUniformFactory : public IEngineUniformFactory
{
public:
    virtual IEngineUniform *Create(Uniform *uniform)
    { 
        return new T(uniform);
    }
};