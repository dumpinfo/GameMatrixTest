#include "stdafx.h"

#include "Context.h"
#include "Uniform.h"
#include "ShaderProgram.h"
#include "State.h"

int _tmain(int argc, _TCHAR* argv[])
{
    ShaderProgram::InitializeEngineUniforms();

    Context context;

    std::string vertexSource = ""; // ...
    std::string fragmentSource = ""; // ...

    ShaderProgram program(vertexSource, fragmentSource);

    State state;

    state.SetModel(Matrix44());
    state.SetView(Matrix44());
    state.SetProjection(Matrix44());

    context.Draw(program, state);

    state.SetModel(Matrix44());

    context.Draw(program, state);
    context.Draw(program, state);

    ShaderProgram::DestroyEngineUniforms();

	return 0;
}

