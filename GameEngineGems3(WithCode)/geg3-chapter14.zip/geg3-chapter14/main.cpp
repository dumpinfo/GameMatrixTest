
#include "StringHash.h"


void WhoAmI(StringHash hash)
{
	switch (hash.GetHash())
	{
		case GenerateHash("first"):
			printf("I am first\n");
			break;

		case GenerateHash("second"):
			printf("I am second\n");
			break;

		case GenerateHash(""):
			printf("I am empty\n");
			break;
	}
}


int main(void)
{
	WhoAmI("first");
	char second[] = "second";
	WhoAmI(second);
	WhoAmI("");

	return 0;
}
