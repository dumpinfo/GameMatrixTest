#include "Obj.h"
const float EPSILON = 0.0001f;

inline glm::vec3 GetNormal(glm::vec3 v0, glm::vec3 v1, glm::vec3 v2) {
	glm::vec3 e1 = v0-v1;
	glm::vec3 e2 = v2-v1;
	return glm::cross(e1,e2);  
}

 
void Mesh::CalcNormals() {
	const size_t total = vertices.size(); 
	size_t i=0;
    

	// Resetting normals to zero
    memset(&normals[0],0, sizeof(glm::vec3)*total); 
     
	for(i=0;i<faces.size();i++) {
		glm::vec3 v1 = vertices[faces[i].a];
        glm::vec3 v2 = vertices[faces[i].b];
		glm::vec3 v3 = vertices[faces[i].c];
  
        // Polygon normal calculation		
		glm::vec3 n = GetNormal(v1,v2,v3); 
	
		normals[faces[i].a] += n;
		normals[faces[i].b] += n;
		normals[faces[i].c] += n;
	}

	for(i=0;i<total;i++)  {
		if(glm::dot(normals[i], normals[i])>0)
			normals[i] = glm::normalize(normals[i]);  
	}
}

Mesh::Mesh() {}
Mesh::~Mesh() {
	vertices.clear();
	faces.clear();
	uvs.clear();
	normals.clear();
}
float*			Mesh::GetVertexPointer()	{ return &(vertices[0].x);	}
glm::vec3*		Mesh::GetPositionPointer()	{ return &(vertices[0]);	}
glm::vec3*		Mesh::GetNormalPointer()	{ return &(normals[0]);		}
unsigned int*	Mesh::GetIndexPointer()		{ return &(faces[0].a);		}
float*			Mesh::GetTexCoordPointer()	{ return &(uvs[0].s);		}
unsigned int	Mesh::GetFacesSize()		{ return faces.size();		}
unsigned int	Mesh::GetVerticesSize()		{ return vertices.size();	}
unsigned int	Mesh::GetUVSize()			{ return uvs.size();		}
unsigned int	Mesh::GetNormalsSize()		{ return normals.size();	}
glm::vec3		Mesh::GetMin()				{ return min;				}
glm::vec3		Mesh::GetMax()				{ return max;				}

void			Mesh::SetBounds(float* mn, float* mx) {
	min.x = mn[0];	min.y = mn[1];	min.z = mn[2];
	max.x = mx[0];	max.y = mx[1];	max.z = mx[2];
}
ObjLoader::ObjLoader() {

}

ObjLoader::~ObjLoader() {

}

#include <fstream>
#include <sstream>

bool ObjLoader::Load(const string filename, Mesh& mesh) {
	ifstream fp(filename.c_str(),ios::binary);
	if(!fp)
		return false;
    string tmp(std::istreambuf_iterator<char>(fp), (std::istreambuf_iterator<char>()));
	istringstream buffer(tmp);
	fp.close();

	float min[3]={1000,1000,1000}, max[3]={-1000, -1000, -1000};

	string line;
	int count=0;
	while(getline(buffer, line)) {
		line.erase(line.find_last_not_of(" \n\r\t")+1);
		if(line.find_first_of("#") != -1) //its a comment leave it
			continue;

        string prefix = line.substr(0, line.find_first_of(" "));

		if(prefix.compare("vt")==0) //if we have a texture coord
		{
			line = line.substr(line.find_first_of("vt")+2);
			UV uv;

			istringstream s(line);
			s>>uv.s;
			s>>uv.t;

			mesh.uvs.push_back(uv);
		}

		if(prefix.compare("v")==0) //if we have a vertex
		{
			line = line.substr(line.find_first_of("v")+2);
			glm::vec3 v;

			istringstream s(line);
			s>>v.x;
			s>>v.y;
			s>>v.z;
			if(v.x<min[0])
				min[0] = v.x;
			if(v.y<min[1])
				min[1] = v.y;
			if(v.z<min[2])
				min[2] = v.z;

			if(v.x>max[0])
				max[0] = v.x;
			if(v.y>max[1])
				max[1] = v.y;
			if(v.z>max[2])
				max[2] = v.z;
			mesh.vertices.push_back(v);
		}
		//if we have a vertex normal
		if(prefix.compare("vn")==0) //if we have a vertex normal
		{
			line = line.substr(line.find_first_of("vn")+2);
			glm::vec3 n;

			istringstream s(line);
			s>>n.x;
			s>>n.y;
			s>>n.z;
			 
			mesh.normals.push_back(n);
		}


		if(prefix.compare("f")==0)
		{
			line = line.substr(line.find_first_of("f")+2);

			//remove whitespaces
			string first, mid, last;
			
			int first_space = line.find_first_of(" ");
			first = line.substr(0, first_space); 
			mid = line.substr(first_space+1, line.find_last_of(" ")-first_space-1); 
			last = line.substr(line.find_last_of(" ")+1); 

			string face_data;
			face_data.append(first.substr(0, first.find("/")));
			face_data.append(" ");
			face_data.append(mid.substr(0, mid.find("/")));
			face_data.append(" ");
			face_data.append(last.substr(0, last.find("/")));

			Face f;
			f.a = 10000;
			f.b = 10000;
			f.c = 10000;
			/*
			int index  = line.find_first_of(" ");
			int start=0;
			string face_data;
			string l2="";
			int space_index = line.find_first_of(" ", start+1);
			while(space_index!= -1) {
				l2 = line.substr(start, space_index-start);

				face_data.append(l2.substr(0, l2.find("/")));
				face_data.append(" ");
				start += space_index;
				space_index = line.find(" ", start + l2.length());
			}
			l2 = line.substr(line.find_last_of(" "));
			face_data.append(l2.substr(0, l2.find("/")));
			*/
			istringstream s(face_data);
			s>>f.a;
			s>>f.b;
			s>>f.c;

			f.a-=1;
			f.b-=1;
			f.c-=1; 
			mesh.faces.push_back(f);
		}
	}

	if(mesh.normals.size() == 0) {
		mesh.normals.resize(mesh.vertices.size()); 
		mesh.CalcNormals();
	}

	mesh.SetBounds(min, max);

	//now do centering
	/*for(size_t i=0;i<mesh.vertices.size();i++) {
		mesh.vertices[i].x -= min[0];
		mesh.vertices[i].y -= min[1];
		mesh.vertices[i].z -= min[2];

		mesh.vertices[i].x = (mesh.vertices[i].x/(max[0]-min[0])) -0.5f;
		mesh.vertices[i].y = (mesh.vertices[i].y/(max[1]-min[1])) -0.5f;
		mesh.vertices[i].z = (mesh.vertices[i].z/(max[2]-min[2])) -0.5f;
	}*/	 
	return true;
}


