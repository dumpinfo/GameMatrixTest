#ifndef OBJ_INC
#define OBJ_INC
#pragma once

#include <string>
#include <vector>
#include <glm/glm.hpp>

using namespace std;


struct UV		{ float s,t; }; 
struct Face		{ unsigned int a, b, c; };

inline glm::vec3 GetNormal(glm::vec3 v0, glm::vec3 v1, glm::vec3 v2);
class  Mesh {
	friend class ObjLoader;
	public:
		Mesh();
		~Mesh();
		float*			GetVertexPointer();
		glm::vec3*		GetPositionPointer();
		glm::vec3*		GetNormalPointer();
		float*			GetTexCoordPointer();
		unsigned int*	GetIndexPointer();
		unsigned int	GetFacesSize();
		unsigned int	GetVerticesSize();
		unsigned int	GetUVSize();
		unsigned int	GetNormalsSize();
		void			CalcNormals();
		void			SetBounds(float* mn, float* mx);
		glm::vec3		GetMin();
		glm::vec3		GetMax();
	private:
		
		string			name;
		vector<glm::vec3>	vertices;
		vector<glm::vec3>	normals;
		vector<UV>		uvs;
		vector<Face>	faces;		 
		glm::vec3 max, min;
};

class ObjLoader {
	public :
		ObjLoader();
		~ObjLoader();

	bool Load(const string filename, Mesh& mesh);


};
#endif
