/*
Copyright (c) 2015, Movania Muhammad Mobeen
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this list
of conditions and the following disclaimer in the documentation and/or other
materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.
*/

//Demo source code for Game Engine Gems 3 chapter "Simulating Soft Bodies using Strain
//Based Dynamics" by Dr. Muhammad Mobeen Movania. For details about the method,
//please refer to the book chapter. 

//This project implements soft body based on tetrahedral mesh using strain based dynamics 
//as detailed in the paper by Mueller et. al.
//http://matthias-mueller-fischer.ch/publications/strainBasedDynamics.pdf using 
//GLUT,GLEW and GLM libraries. This code is intended for beginners so that they may 
//understand what is required to implement strain based dynamics for soft body simulation.
//
//This code is under BSD license. If you make some improvements, or are using this in your 
//research, do let me know and I would appreciate if you acknowledge this in your code or 
//in your publication.
//
//Controls:
//Mouse: 
// - left click on any empty region to rotate, middle click to zoom 
// - left click and drag any point to drag it.
// - right click to pan camera
//
//Keyboard:
// - q/e keys to decrement/increment kStretchXX value  
// - a/d keys to decrement/increment kStretchYY value  
// - z/c keys to decrement/increment kStretchZZ value   
// - w/r keys to decrement/increment kShearXY value   
// - s/f keys to decrement/increment kShearYZ value   
// - x/v keys to decrement/increment kShearXZ value   
// - p key to show/hide points 
// - t key to show/hide tetrahedra 
// - spacebar to pause/resume simulation
//
//Author: Dr. Muhammad Mobeen Movania
//        Assistant Professor 
//        Department of Computer Science
//        DHA Suffa University
//        Karachi, PAKISTAN
//
//Email: mova0002@e.ntu.edu.sg;mobeen.movania@dsu.edu.pk
//Last Modified: 20 September 2015

#include <GL/glew.h>
#include <GL/wglew.h>
#include <GL/freeglut.h>
#include <vector>

#define GLM_FORCE_RADIANS 
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp> //for matrices
#include <glm/gtc/type_ptr.hpp>

#include <cassert>
#include <iostream>


#define GL_CHECK_ERROR (glGetError() == GL_NO_ERROR);
 
#pragma comment(lib, "glew32.lib")

using namespace std;  
const int width = 1024, height = 1024;

#define PI 3.1415926536f
#define EPSILON  0.0000001f


//std::string tetraFilename = "../media/meshes/bunny3_SB.tet";
//std::string objFilename   = "../media/meshes/bunny3_SB.obj";

std::string tetraFilename = "../media/meshes/froggy.tet";
std::string objFilename   = "../media/meshes/froggy.obj";
 
//std::string tetraFilename = "../media/meshes/torus_scaled.tet";
//std::string objFilename   = "../media/meshes/torus_scaled.obj";
  


char info[MAX_PATH]={0};

float timeStep = 1.0f/120.0f;  
float currentTime = 0;
double accumulator = timeStep;
int selected_index = -1;
float global_dampening = 0.98f; //DevO: 24.07.2011  //global velocity dampening !!!

struct DistanceConstraint {	int p1, p2;	float rest_length, k_prime; };
 
struct BendingConstraint {	int p1, p2, p3, p4;	float rest_length1, rest_length2, w1, w2; float k_prime;};
 

struct TriangleConstraint {	int p1, p2, p3;	float w, k_prime;};

struct TetrahedralConstraint { int p0, p1, p2, p3; glm::vec3 c1, c2, c3; }; 

vector<GLushort> tetraIndices; 

vector<DistanceConstraint> d_constraints;

DistanceConstraint mouse_constraint;
glm::vec3 mouse_position;

vector<BendingConstraint> b_constraints;
vector<float> phi0;			//initial dihedral angle between adjacent triangles

vector<TetrahedralConstraint> t_constraints;

//particle system 
vector<glm::vec3> dp;		//positional corrections 
vector<glm::mat3> Q;		//material coordinates
vector<glm::vec3> X;		//position (P in paper) 
vector<glm::vec3> tmp_X;	//predicted position
vector<glm::vec3> V;		//velocity
vector<glm::vec3> F;		//forces
vector<float> W;			//inverse particle mass 
vector<glm::vec3> Ri;		//Ri = Xi-Xcm 

float tx, ty, tz = -10;
int oldX=0, oldY=0;
float rX=15, rY=0;
int state =1 ; 
const int GRID_SIZE=10;

const size_t solver_iterations = 10; //number of Gauss Seidel solver iterations per step. PBD  
 
float kBend = 0.5f;  
float kStretchXX = 0.75f;
float kStretchYY = 0.75f;
float kStretchZZ = 0.75f;
 
float kShearXY = 0.75f;
float kShearXZ = 0.75f;
float kShearYZ = 0.75f;

float kDamp = 0.000125f;
glm::vec3 gravity=glm::vec3(0.0f,-9.81f,0.0f);  

float mass = 10; //10 for suzanne

 
bool bShowTetrahedra = false, bShowPoints=false;

GLint viewport[4];
GLdouble MV[16];
GLdouble P[16];

LARGE_INTEGER frequency;        // ticks per second
LARGE_INTEGER t1, t2;           // ticks
LARGE_INTEGER start, stop;

double frameTimeQP=0;
float frameTime =0 ;

glm::mat3 I(1);
glm::vec3 Up=glm::vec3(0,1,0), Right, viewDir;
float startTime =0, fps=0;
int totalFrames=0;
int total_points = 0;

glm::mat4 ellipsoid, inverse_ellipsoid;
int iStacks = 30;
int iSlices = 30;
float fRadius = 1;

// Resolve constraint in object space
glm::vec3 center = glm::vec3(0,0,0); //object space center of ellipsoid
float radius = 1;					 //object space radius of ellipsoid


float winZ=0; 

#include "Obj.h"
ObjLoader objLoader;
Mesh mesh; 

struct TetraMap {
	glm::vec3 barycentricCoords;
	int tetraIndex;
};
vector<TetraMap> mapping; 

//calculate barycentric coordinates
glm::vec3 ComputeBarycentricCoordinates(glm::vec3 vertex, glm::vec3 p0, glm::vec3 p1, glm::vec3 p2, glm::vec3 p3) {
	glm::vec3 baryCoords;

	glm::vec3 q  = vertex-p3;
	glm::vec3 q0 = p0-p3;
	glm::vec3 q1 = p1-p3;
	glm::vec3 q2 = p2-p3;

	glm::mat3 m(q0,q1,q2);
	float det = glm::determinant(m);

	m[0]=q;
	baryCoords.x = glm::determinant(m);

	m[0]=q0; 
	m[1]=q;
	baryCoords.y = glm::determinant(m);

	m[1]=q1; 
	m[2]=q;
	baryCoords.z = glm::determinant(m);

	if (det != 0.0f)
		baryCoords /= det;

	return baryCoords;
}

void FindBarycentricMapping() {
	glm::vec3* pVertices = mesh.GetPositionPointer();

	for(size_t j=0;j<mesh.GetVerticesSize();++j) {
		float minDist = 0.0f;
		TetraMap tmap;

		for(size_t i=0;i<tetraIndices.size();i+=4) {
			int i0 = tetraIndices[i];
			int i1 = tetraIndices[i+1];
			int i2 = tetraIndices[i+2];
			int i3 = tetraIndices[i+3];

			glm::vec3 p0 = X[i0];
			glm::vec3 p1 = X[i1];
			glm::vec3 p2 = X[i2];
			glm::vec3 p3 = X[i3];

			glm::vec3 b = ComputeBarycentricCoordinates(pVertices[j], p0, p1, p2, p3);
			

			// If the given vertex is inside the tetrahedron, we take it
			if (b.x >= 0.0f && b.y >= 0.0f && b.z >= 0.0f && (b.x + b.y + b.z) <= 1.0f) {
				tmap.tetraIndex = i;
				tmap.barycentricCoords=b;
				break;
			}

			// otherwise, if we are not in any tetrahedron we take the closest one
			float dist = 0.0f;
			if (b.x + b.y + b.z > 1.0f) dist = b.x + b.y + b.z - 1.0f;
			if (b.x < 0.0f) dist = (-b.x < dist) ? dist : -b.x;
			if (b.y < 0.0f) dist = (-b.y < dist) ? dist : -b.y;
			if (b.z < 0.0f) dist = (-b.z < dist) ? dist : -b.z;

			if (i == 0 || dist < minDist) {
				minDist = dist; 
				tmap.tetraIndex = i;
				tmap.barycentricCoords=b;
			}
		}
		
		mapping.push_back(tmap);
	}
}

void StepPhysics(float dt);

float GetArea(int a, int b, int c) {
	glm::vec3 e1 = X[b]-X[a];
	glm::vec3 e2 = X[c]-X[a];
	return 0.5f * glm::length(glm::cross(e1,e2));
}
void AddDistanceConstraint(int a, int b, float k) {
	DistanceConstraint c;
	c.p1=a;
	c.p2=b; 
	c.k_prime = 1.0f-pow((1.0f-k), 1.0f/solver_iterations);  //1.0f-pow((1.0f-c.k), 1.0f/ns);

	if(c.k_prime>1.0) 
		c.k_prime = 1.0;

	glm::vec3 deltaP = X[c.p1]-X[c.p2];
	c.rest_length = glm::length(deltaP);

	d_constraints.push_back(c);
}
 
void AddBendingConstraint(int pa, int pb, int pc,int pd, float k) {
	BendingConstraint c;
	c.p1=pa;
	c.p2=pb;
	c.p3=pc; 
	c.p4=pd; 
	c.w1 = W[pa] + W[pc] + 2*W[pb];
	c.w2 = W[pa] + W[pd] + 2*W[pb]; 
	glm::vec3 center1 = 0.3333f * (X[pa] + X[pb] + X[pc]);
	glm::vec3 center2 = 0.3333f * (X[pa] + X[pb] + X[pd]); 
 

	c.k_prime = 1.0f-pow((1.0f-k), 1.0f/solver_iterations);  //1.0f-pow((1.0f-c.k), 1.0f/ns);
	if(c.k_prime>1.0) 
		c.k_prime = 1.0;
	b_constraints.push_back(c);
} 
 
void OnMouseDown(int button, int s, int x, int y)
{
	if (s == GLUT_DOWN) 
	{
		oldX = x; 
		oldY = y;  

		if( button == GLUT_LEFT_BUTTON) {
			int window_y = (viewport[3] - y);  
			glReadPixels( x, window_y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &winZ );


			double objX=0, objY=0, objZ=0;
			gluUnProject(x,window_y, winZ,  MV,  P, viewport, &objX, &objY, &objZ);
			glm::vec3 pt(objX,objY, objZ); 
			size_t i=0;
			for(i=0;i<X.size();i++) {			 
				if( glm::distance(X[i],pt)<0.1) {
					selected_index = i;
					printf("Intersected at %d\n",i);

					mouse_constraint.p1 = i; 
					mouse_constraint.p2 = -1;  

					mouse_position.x = (float)objX;
					mouse_position.y = (float)objY;
					mouse_position.z = (float)objZ;
					break;
				}
			}
		}
	}	

	if(button == GLUT_MIDDLE_BUTTON)
		state = 0;
	else if(button == GLUT_RIGHT_BUTTON)
		state = 2;
	else
		state = 1;

	if(s==GLUT_UP) { 
		selected_index= -1; 
		mouse_constraint.p1 = -1; 
		glutSetCursor(GLUT_CURSOR_INHERIT);
	}
}

void RenderMeshImmediateMode() {
	glm::vec3* pVertices = mesh.GetPositionPointer();  
	glm::vec3* pNormals  = mesh.GetNormalPointer();
	GLuint*    pIndices  = mesh.GetIndexPointer();

	glBegin(GL_TRIANGLES);
	for (size_t i = 0; i < mesh.GetFacesSize(); i++) {
		unsigned int i0 = *(pIndices++);
		unsigned int i1 = *(pIndices++);
		unsigned int i2 = *(pIndices++); 
		glNormal3fv(&pNormals[i0].x);		glVertex3fv(&pVertices[i0].x);  
		glNormal3fv(&pNormals[i1].x);		glVertex3fv(&pVertices[i1].x);  
		glNormal3fv(&pNormals[i2].x);		glVertex3fv(&pVertices[i2].x);   
	}
	glEnd();
}

void RenderMesh() {
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	//glEnableClientState(GL_TEXTURE_COORD_ARRAY);

//	glEnable(GL_TEXTURE_2D);
	 
	glVertexPointer(3, GL_FLOAT, 0, (mesh.GetVertexPointer()));
	glNormalPointer(GL_FLOAT, 0, (mesh.GetNormalPointer()));
	//glTexCoordPointer(2,GL_FLOAT, sizeof(float)*2, (mesh.GetTexCoordPointer()));

	glDrawElements(GL_TRIANGLES, mesh.GetFacesSize()*3, GL_UNSIGNED_INT, mesh.GetIndexPointer());

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	//glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	 
//	glDisable(GL_TEXTURE_2D); 
}
void OnMouseMove(int x, int y)
{
	if(selected_index == -1) {
		if (state == 0)
			tz *= (1 + (y - oldY)/60.0f); 
		else if (state == 2) {
			tx -= (x - oldX)/50.0f; 
			ty += (y - oldY)/50.0f; 
		} else {
			rY += (x - oldX)/5.0f; 
			rX += (y - oldY)/5.0f; 
		} 
	} else { 
		double objX=0, objY=0, objZ=0; 
		int window_y = (viewport[3] - y); 
		gluUnProject(x, window_y, winZ,  MV,  P, viewport, &objX, &objY, &objZ);
		mouse_position.x = (float)objX;
		mouse_position.y = (float)objY;
		mouse_position.z = (float)objZ;
	}
	oldX = x; 
	oldY = y; 

	glutPostRedisplay(); 
}


void DrawGrid()
{
	glBegin(GL_LINES);
	glColor3f(0.5f, 0.5f, 0.5f);
	for(int i=-GRID_SIZE;i<=GRID_SIZE;i++)
	{
		glVertex3f((float)i,0,(float)-GRID_SIZE);
		glVertex3f((float)i,0,(float)GRID_SIZE);

		glVertex3f((float)-GRID_SIZE,0,(float)i);
		glVertex3f((float)GRID_SIZE,0,(float)i);
	}
	glEnd();
}

inline glm::vec3 GetNormal(int ind0, int ind1, int ind2) {
	glm::vec3 e1 = X[ind0]-X[ind1];
	glm::vec3 e2 = X[ind2]-X[ind1];
	return glm::normalize(glm::cross(e1,e2));
}
 
inline float GetDihedralAngle(BendingConstraint c, float& d, glm::vec3& n1, glm::vec3& n2) {	 
	n1 = GetNormal(c.p1, c.p2, c.p3);
	n2 = GetNormal(c.p1, c.p2, c.p4); 
	d = glm::dot(n1, n2);
	return acos(d);
} 
void LoadTetrahedraFromTetFile(const char* filename) {
	static const int MESH_STRING_LEN = 256;
	char s[MESH_STRING_LEN]={'\0'};
	int i0=0,i1=0,i2=0,i3=0;
	glm::vec3 v;

	FILE *f;
	fopen_s(&f, filename, "r");
	if (!f) 
		return;
	 
	while (!feof(f)) {
		if (fgets(s, MESH_STRING_LEN, f) == NULL) break;

		if (strncmp(s, "v ", 2) == 0) {	// vertex
			sscanf_s(s, "v %f %f %f", &v.x, &v.y, &v.z); 
			X.push_back(v);  
		}
		else if (strncmp(s, "t ", 2) == 0) {	// tetra
			sscanf_s(s, "t %i %i %i %i", &i0,&i1,&i2,&i3);
			tetraIndices.push_back(i0);
			tetraIndices.push_back(i1);
			tetraIndices.push_back(i2);
			tetraIndices.push_back(i3);
		}
	}
	fclose(f);

	total_points = X.size();
	W.resize(total_points); 
	V.resize(total_points);
	F.resize(total_points);
	Ri.resize(total_points);
	tmp_X.resize(total_points);
	dp.resize(total_points);

	std::fill(V.begin(), V.end(), glm::vec3(0));
	std::fill(F.begin(), F.end(), glm::vec3(0));
	std::fill(W.begin(), W.end(), 1.0f/mass);
	  

	//construct tetrahedral constraints
	for(size_t i=0;i<tetraIndices.size();i+=4) {
		int i0 = tetraIndices[i];
		int i1 = tetraIndices[i+1];
		int i2 = tetraIndices[i+2];
		int i3 = tetraIndices[i+3];

		glm::vec3 p0 = X[i0];
		glm::vec3 p1 = X[i1];
		glm::vec3 p2 = X[i2];
		glm::vec3 p3 = X[i3];

		glm::mat3 Q(p1-p0,p2-p0,p3-p0); 
		glm::mat3 Qinv = glm::inverse(Q);

		glm::vec3 c1(Qinv[0]);
		glm::vec3 c2(Qinv[1]);
		glm::vec3 c3(Qinv[2]);

		TetrahedralConstraint t;
		t.c1 = c1;
		t.c2 = c2;
		t.c3 = c3;
		t.p0 = i0;
		t.p1 = i1;
		t.p2 = i2;
		t.p3 = i3;		
		t_constraints.push_back(t); 
	} 
}

void LoadTetrahedraFromMshFile(const char* filename) {
	static const int MESH_STRING_LEN = 256;
	char s[MESH_STRING_LEN]={'\0'};
	int i0=0,i1=0,i2=0,i3=0;
	glm::vec3 v;
	int i=0;
	int total_vertices = 0, total_tetras=0;

	FILE *f;
	fopen_s(&f, filename, "r");
	
	if (!f) 
		return;
	
	fscanf_s(f, "%d %d", &total_vertices, &total_tetras);

	for(i=0;i<total_vertices;++i) {		 
		fscanf_s(f, "%f %f %f", &v.x, &v.y, &v.z); 
		v = v*0.1f;
		X.push_back(v);  
	}

	for(i=0;i<total_tetras;++i) {		 // tetra
		fscanf_s(f, "%i %i %i %i", &i0,&i1,&i2,&i3);
		tetraIndices.push_back(i0);
		tetraIndices.push_back(i1);
		tetraIndices.push_back(i2);
		tetraIndices.push_back(i3);		
	}
	fclose(f);

	total_points = X.size();
	W.resize(total_points); 
	V.resize(total_points);
	F.resize(total_points);
	Ri.resize(total_points);
	tmp_X.resize(total_points);
	dp.resize(total_points);

	std::fill(V.begin(), V.end(), glm::vec3(0));
	std::fill(F.begin(), F.end(), glm::vec3(0));
	std::fill(W.begin(), W.end(), 1.0f/mass);
	  

	//construct tetrahedral constraints
	for(size_t i=0;i<tetraIndices.size();i+=4) {
		int i0 = tetraIndices[i];
		int i1 = tetraIndices[i+1];
		int i2 = tetraIndices[i+2];
		int i3 = tetraIndices[i+3];

		glm::vec3 p0 = X[i0];
		glm::vec3 p1 = X[i1];
		glm::vec3 p2 = X[i2];
		glm::vec3 p3 = X[i3];

		glm::mat3 Q(p1-p0,p2-p0,p3-p0); 
		glm::mat3 Qinv = glm::inverse(Q);

		glm::vec3 c1(Qinv[0]);
		glm::vec3 c2(Qinv[1]);
		glm::vec3 c3(Qinv[2]);

		TetrahedralConstraint t;
		t.c1 = c1;
		t.c2 = c2;
		t.c3 = c3;
		t.p0 = i0;
		t.p1 = i1;
		t.p2 = i2;
		t.p3 = i3;		
		t_constraints.push_back(t); 
	} 
}

void InitLighting() {
	
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST); 

	GLfloat black[4]={0.0f,0.0f,0.0f,1.f};
	GLfloat white[4]={1,1,1,1};

	GLfloat key[4]={1,0.9f,0.5f,1};
	GLfloat fill[4]={0.7f,0.7f,0.9f,1};

	GLfloat mat_diffuse[4]={1.0,1,1.0,1};
	GLfloat light_position_key[]={-1,-1,-1,0};  
	GLfloat light_position_fill[]={1,1,1,0};  
	glLightfv(GL_LIGHT0, GL_AMBIENT, black);
	glLightfv(GL_LIGHT1, GL_AMBIENT, black);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, key);	
	glLightfv(GL_LIGHT1, GL_DIFFUSE, fill);	
	 
	//This is to ensure that we have a head light
	//OpenGL requires that the modelview be set to
	//identity otherwise the current modelview 
	//transform is applied to the light position 
	//as written in OpenGL FAQ.
	//https://www.opengl.org/archives/resources/faq/technical/lights.htm 
	glMatrixMode(GL_MODELVIEW); 
	glLoadIdentity();
	glLightfv(GL_LIGHT0, GL_POSITION, light_position_key); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_position_fill);
	glMaterialfv(GL_FRONT, GL_AMBIENT, black);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	  
	glDisable(GL_LIGHTING);
}

void MoveSoftbody(float tx=0, float ty=0, float tz=0) {
	for(int i=0;i<total_points;++i)
		X[i] += glm::vec3(tx,ty,tz);
		 
}

bool endsWith (std::string const &fullString, std::string const &ending) {
    if (fullString.length() >= ending.length()) {
        return (0 == fullString.compare (fullString.length() - ending.length(), ending.length(), ending));
    } else {
        return false;
    }
}


void InitGL() { 
	InitLighting();
	mouse_constraint.p1 = -1;
	float k = 0.25;
	mouse_constraint.k_prime = 1.0f-pow((1.0f- k), 1.0f/solver_iterations);  //1.0f-pow((1.0f-c.k), 1.0f/ns);

	if(mouse_constraint.k_prime>1.0) 
		mouse_constraint.k_prime = 1.0;

	mouse_constraint.rest_length = 0.001f;
	 

	startTime = (float)glutGet(GLUT_ELAPSED_TIME);
	currentTime = startTime;

	// get ticks per second
	QueryPerformanceFrequency(&frequency);

	// start timer
	QueryPerformanceCounter(&t1);

	 
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE); 
	glPointSize(5);

	size_t i=0, j=0, count=0;
	int l1=0, l2=0;
	float ypos = 7.0f;
	 
	 
	//fill in indices 
	count = 0;
	 

	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	//glPolygonMode(GL_BACK, GL_LINE);
	//glPointSize(5);

	wglSwapIntervalEXT(0);

	//check the damping values
	//if(kStretch>1)		kStretch=1;
	//if(kStretch<0)		kStretch=0;
	if(kBend>1)			kBend=1;
	if(kBend<0)			kBend=0;
	if(kDamp>1)			kDamp=1;
	if(kDamp<0)			kDamp=0;
	if(global_dampening>1)		global_dampening = 1;

	  
	//create a basic ellipsoid collidor
	ellipsoid = glm::translate(glm::mat4(1),glm::vec3(0,2,0));
	ellipsoid = glm::rotate(ellipsoid, 45.0f ,glm::vec3(1,0,0));
	ellipsoid = glm::scale(ellipsoid, glm::vec3(fRadius,fRadius,fRadius/2));
	inverse_ellipsoid = glm::inverse(ellipsoid);

	if(endsWith(tetraFilename, ".tet"))
		LoadTetrahedraFromTetFile(tetraFilename.c_str());
	else
		LoadTetrahedraFromMshFile(tetraFilename.c_str());

	if(objLoader.Load(objFilename, mesh))
		cout<<"Obj mesh loaded\nTotal vertices: "<<mesh.GetVerticesSize()<<", faces: "<<mesh.GetFacesSize()<<", uvs: "<<mesh.GetUVSize()<<endl;
	else {
		cout << "Failed to load obj file" << endl;
		exit(EXIT_FAILURE);
    } 

	cout << "Finding barycentric mapping" << endl;
	QueryPerformanceCounter(&start);
		FindBarycentricMapping();
	QueryPerformanceCounter(&stop);
	double delta = (stop.QuadPart - start.QuadPart) * 1000.0 / frequency.QuadPart;
	cout << "Mapping done in " << delta << " msecs." << endl;
	MoveSoftbody(0,5,0);
}

void UpdateMesh() {
	glm::vec3* pVertices = mesh.GetPositionPointer();  

	for(size_t i=0;i<mapping.size();++i) {
		TetraMap tmap = mapping[i];
		int index = tmap.tetraIndex;
		int i0 = tetraIndices[index];			
		int i1 = tetraIndices[index+1];
		int i2 = tetraIndices[index+2];			
		int i3 = tetraIndices[index+3];
		glm::vec3 p0 = X[i0];	
		glm::vec3 p1 = X[i1];	
		glm::vec3 p2 = X[i2];	
		glm::vec3 p3 = X[i3];

		glm::vec3 b = tmap.barycentricCoords;
		glm::vec3 temp = p0 * b.x + p1 * b.y + p2 * b.z + p3 * (1.0f - b.x - b.y - b.z);
		pVertices[i].x = temp.x;
		pVertices[i].y = temp.y;
		pVertices[i].z = temp.z;  
	}
	mesh.CalcNormals();
}

void OnReshape(int nw, int nh) {
	glViewport(0,0,nw, nh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, (GLfloat)nw / (GLfloat)nh, 1.f, 100.0f);

	glGetIntegerv(GL_VIEWPORT, viewport); 
	glGetDoublev(GL_PROJECTION_MATRIX, P);

	glMatrixMode(GL_MODELVIEW); 
}

void OnRender() {		
	GL_CHECK_ERROR

	size_t i=0;
	float newTime = (float) glutGet(GLUT_ELAPSED_TIME);
	frameTime = newTime-currentTime;
	currentTime = newTime;
	//accumulator += frameTime;

	//Using high res. counter
	QueryPerformanceCounter(&t2);
	// compute and print the elapsed time in millisec
	frameTimeQP = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
	t1=t2;
	accumulator += frameTimeQP;

	++totalFrames;
	if((newTime-startTime)>1000)
	{		
		float elapsedTime = (newTime-startTime);
		fps = (totalFrames/ elapsedTime)*1000 ;
		startTime = newTime;
		totalFrames=0;
	}

	sprintf_s(info, "FPS: %3.2f, Frame time (GLUT): %3.4f msecs, Frame time (QP): %3.3f", fps, frameTime, frameTimeQP);
	glutSetWindowTitle(info);

	glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	//set viewing transformation
	glTranslatef(tx,ty,tz);
	glRotatef(rX,1,0,0);
	glRotatef(rY,0,1,0);

	glGetDoublev(GL_MODELVIEW_MATRIX, MV);
	viewDir.x = (float)-MV[2];
	viewDir.y = (float)-MV[6];
	viewDir.z = (float)-MV[10];
	Right = glm::cross(viewDir, Up);

	//draw grid
	DrawGrid();

	//draw ellipsoid
	glColor3f(0,1,0);
	glPushMatrix();
	glMultMatrixf(glm::value_ptr(ellipsoid));
	glutWireSphere(fRadius, iSlices, iStacks);
	glPopMatrix();


	//draw tetrahedra 
	if(bShowTetrahedra) {
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	
		glBegin(GL_TRIANGLES);
			glColor3f(0,0,1);
			int count = 0;
			for(i=0;i<tetraIndices.size();i+=4) {
				int i0 = tetraIndices[i];			int i1 = tetraIndices[i+1];
				int i2 = tetraIndices[i+2];			int i3 = tetraIndices[i+3];

				glm::vec3 p1 = X[i0];	glm::vec3 p2 = X[i1];	
				glm::vec3 p3 = X[i2];	glm::vec3 p4 = X[i3];
		  
				glVertex3f(p1.x,p1.y,p1.z);	glVertex3f(p2.x,p2.y,p2.z);	glVertex3f(p3.x,p3.y,p3.z);

				glVertex3f(p1.x,p1.y,p1.z);	glVertex3f(p3.x,p3.y,p3.z);	glVertex3f(p4.x,p4.y,p4.z);
		
				glVertex3f(p1.x,p1.y,p1.z);	glVertex3f(p4.x,p4.y,p4.z);	glVertex3f(p2.x,p2.y,p2.z);

				glVertex3f(p2.x,p2.y,p2.z);	glVertex3f(p3.x,p3.y,p3.z);	glVertex3f(p4.x,p4.y,p4.z); 
			}
		glEnd();	 
	}

	//draw tetrahedra vertices	
	if(bShowPoints) {
		glBegin(GL_POINTS);
		for(int i=0;i<total_points;i++) {
			glm::vec3 p = X[i];
			int is = (i==selected_index);
			glColor3f((float)!is,(float)is,(float)is);
			glVertex3f(p.x,p.y,p.z);
		} 
		glEnd();
	}
	
	//draw mouse line
	if(mouse_constraint.p1 != -1) {
		glBegin(GL_LINES);
			glVertex3fv(&X[mouse_constraint.p1].x);
			glVertex3f(mouse_position.x, mouse_position.y, mouse_position.z);
		glEnd();
	}

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_LIGHTING); 
		RenderMesh(); 
	glDisable(GL_LIGHTING);

 
	glutSwapBuffers();
}

void OnShutdown() {	
	d_constraints.clear();
	b_constraints.clear();
	t_constraints.clear();
	tetraIndices.clear();
	X.clear();
	F.clear();
	V.clear();
	phi0.clear();
	W.clear();
	tmp_X.clear();
	dp.clear();
	Ri.clear();
}

void ComputeForces( ) {
	int i=0;

	for(i=0;i<total_points;i++) {
		F[i] = glm::vec3(0); 

		//add gravity force
		if(W[i]>0)		 
			F[i] += gravity/W[i] ; 
	}	
} 
void IntegrateExplicitWithDamping(float deltaTime) {
	float deltaTimeMass = deltaTime;
	int i=0;

	glm::vec3 Xcm = glm::vec3(0);
	glm::vec3 Vcm = glm::vec3(0);
	float sumM = 0;
	for(i=0;i<total_points;i++) {

		V[i] *= global_dampening; //global velocity dampening !!!		
		V[i] = V[i] + (F[i]*deltaTime)*W[i]; 	 					

		//calculate the center of mass's position 
		//and velocity for damping calc
		Xcm += (X[i]*mass);
		Vcm += (V[i]*mass);
		sumM += mass;
	}
	Xcm /= sumM; 
	Vcm /= sumM; 

	glm::mat3 I = glm::mat3(1);
	glm::vec3 L = glm::vec3(0);
	glm::vec3 w = glm::vec3(0);//angular velocity


	for(i=0;i<total_points;i++) { 
		Ri[i] = (X[i] - Xcm);	

		L += glm::cross(Ri[i],mass*V[i]); 

		//thanks to DevO for pointing this and these notes really helped.
		//http://www.sccg.sk/~onderik/phd/ca2010/ca10_lesson11.pdf

		glm::mat3 tmp = glm::mat3(0,-Ri[i].z,  Ri[i].y, 
			Ri[i].z,       0,-Ri[i].x,
			-Ri[i].y,Ri[i].x,        0);
		I +=(tmp*glm::transpose(tmp))*mass;
	} 

	w = glm::inverse(I)*L;

	//apply center of mass damping
	for(i=0;i<total_points;i++) {
		glm::vec3 delVi = Vcm + glm::cross(w,Ri[i])-V[i];		
		V[i] += kDamp*delVi;
	}

	//calculate predicted position
	for(i=0;i<total_points;i++) {
		if(W[i] <= 0.0) { 
			tmp_X[i] = X[i]; //fixed points
		} else {
			tmp_X[i] = X[i] + (V[i]*deltaTime);				 
		}
	} 
}

void IntegrateExplicitWithDampingSBD(float deltaTime) {
	int i=0; 
	float sumVN=0;

	for(i=0;i<total_points;i++) {
		V[i] *= global_dampening; //global velocity dampening !!!		
		V[i] = V[i] + (F[i]*deltaTime)*W[i];
		float lenDP = glm::length(dp[i]);
		if(lenDP > EPSILON)
			sumVN = sumVN + glm::dot(V[i], dp[i]/lenDP);
	}
	   
	for(i=0;i<total_points;i++) {
		float lenDP = glm::length(dp[i]);
		if(lenDP > EPSILON)
			V[i] = V[i] - kDamp*sumVN* dp[i]/lenDP;
	}

	//calculate predicted position
	for(i=0;i<total_points;i++) {
		if(W[i] <= 0.0) { 
			tmp_X[i] = X[i]; //fixed points
		} else {
			tmp_X[i] = X[i] + (V[i]*deltaTime);				 
		}
	} 
}

void Integrate(float deltaTime) {	
	float inv_dt = 1.0f/deltaTime;
	int i=0; 

	for(i=0;i<total_points;i++) {	
		V[i] = (tmp_X[i] - X[i])*inv_dt;		
		X[i] = tmp_X[i];		 
	}
}

void UpdateDistanceConstraint(int i) {

	DistanceConstraint c = d_constraints[i];
	glm::vec3 dir = tmp_X[c.p1] - tmp_X[c.p2];

	float len = glm::length(dir); 
	if(len <= EPSILON) 
		return;

	float w1 = W[c.p1];
	float w2 = W[c.p2];
	float invMass = w1+ w2; 
	if(invMass <= EPSILON) 
		return;

	glm::vec3 dP = (1.0f/invMass) * (len-c.rest_length ) * (dir/len)* c.k_prime;
	if(w1 > 0.0)
		tmp_X[c.p1] -= dP*w1;

	if(w2 > 0.0)
		tmp_X[c.p2] += dP*w2;	
}

void UpdateBendingConstraint(int index) {
	size_t i=0;
	BendingConstraint c = b_constraints[index];  

	//Using the dihedral angle approach of the position based dynamics		
	float d = 0, phi=0,i_d=0;
	
	glm::vec3 p1 = tmp_X[c.p1];
	glm::vec3 p2 = tmp_X[c.p2]-p1;
	glm::vec3 p3 = tmp_X[c.p3]-p1;
	glm::vec3 p4 = tmp_X[c.p4]-p1;
	
	glm::vec3 p3p1 = p3-p1;
	glm::vec3 p4p1 = p4-p1;
	glm::vec3 p3p2 = p3-p2;
	glm::vec3 p4p2 = p4-p2;

	//prepare e, n1 and n2 using Eqs. 44, 45, 46
	glm::vec3 e  = p4-p3;		
	glm::vec3 n1 = glm::cross(p3p1,p4p1);
	float  denN1 = glm::dot(n1, n1);		//glm::length(n1)*glm::length(n1);
	
	if(denN1 <= EPSILON) { return; } //need to handle this case.

	n1 = n1/denN1;

	glm::vec3 n2 = glm::cross(p4p2,p3p2);
	float  denN2 = glm::dot(n2,n2);
	if(denN2 <= EPSILON) { return; } //need to handle this case.

	n2 = n2/denN2;
	 
	d	= glm::dot(n1,n2);
	phi = acos(d);

	float sign = (glm::dot(glm::cross(n1,n2),e) > 0.0f)?-1.0f:1.0f;

	//try to catch invalid values that will return NaN.
	// sqrt(1 - (1.0001*1.0001)) = NaN 
	// sqrt(1 - (-1.0001*-1.0001)) = NaN 
	if(d<-1.0) 
		d = -1.0; 
	else if(d>1.0) 
		d=1.0; //d = clamp(d,-1.0,1.0);

	//in both case sqrt(1-d*d) will be zero and nothing will be done.
	//0� case, the triangles are facing in the opposite direction, folded together.
	if(d == -1.0){ 
		phi = PI;  //acos(-1.0) == PI
		if(phi == phi0[index]) 
			return; //nothing to do 

		//in this case one just need to push 
		//vertices 1 and 2 in n1 and n2 directions, 
		//so the constrain will do the work in second iterations.
		//if(c.p1!=0 && c.p1!=numX)
		//	tmp_X[c.p1] += sign*n1/1000.0f;

		//if(c.p2!=0 && c.p2!=numX)
		//	tmp_X[c.p4] += sign*n2/1000.0f;

		return;
	}
	if(d == 1.0){ //180� case, the triangles are planar
		phi = 0.0;  //acos(1.0) == 0.0
		if(phi == phi0[index]) 
			return; //nothing to do 
	}
	
	
	i_d = sqrt(1-(d*d))*(phi-phi0[index]) ;
	 
	float lenE = glm::length(e);
	if(lenE <= EPSILON)
		return;

	glm::vec3 p1p4 = -p4p1;
	glm::vec3 p2p4 = -p4p2; 

	glm::vec3 q1 = lenE*n1*sign;
	glm::vec3 q2 = lenE*n2*sign;
	glm::vec3 q3 = ((glm::dot(p1p4, e)/lenE)*n1 + (glm::dot(p2p4, e)/lenE)*n2)*sign;
	glm::vec3 q4 = ((glm::dot(p3p1, e)/lenE)*n1 + (glm::dot(p3p2, e)/lenE)*n2)*sign;

	float q1_len2 = glm::dot(q1,q1); 
	float q2_len2 = glm::dot(q2,q2); 
	float q3_len2 = glm::dot(q3,q3); 
	float q4_len2 = glm::dot(q4,q4); 

	float sum = W[c.p1]*(q1_len2) + W[c.p2]*(q2_len2) +	W[c.p3]*(q3_len2) +	W[c.p4]*(q4_len2);	
	if(sum <= EPSILON)
		return;
	glm::vec3 dP1 = -( (W[c.p1] * i_d) /sum)*q1;
	glm::vec3 dP2 = -( (W[c.p2] * i_d) /sum)*q2;
	glm::vec3 dP3 = -( (W[c.p3] * i_d) /sum)*q3;
	glm::vec3 dP4 = -( (W[c.p4] * i_d) /sum)*q4;

	if(W[c.p1] > 0.0) {
		tmp_X[c.p1] += dP1*c.k_prime;
	}
	if(W[c.p2] > 0.0) {
		tmp_X[c.p2] += dP2*c.k_prime;
	}
	if(W[c.p3] > 0.0) {
		tmp_X[c.p3] += dP3*c.k_prime;
	}	
	if(W[c.p4] > 0.0) {
		tmp_X[c.p4] += dP4*c.k_prime;
	}   
}

glm::mat2x3 outerProduct(glm::vec3 P, glm::vec2 C) {
	glm::mat2x3 t;

	t[0][0] = P.x * C.x;
	t[0][1] = P.y * C.x;
	t[0][2] = P.z * C.x;

	t[1][0] = P.x * C.y;
	t[1][1] = P.y * C.y;
	t[1][2] = P.z * C.y;

	return t;
}

void UpdateTetrahedralConstraint(int index) {
	TetrahedralConstraint t = t_constraints[index];
	int i0 = t.p0;
	int i1 = t.p1;
	int i2 = t.p2;
	int i3 = t.p3;

	glm::vec3 p0 = tmp_X[i0];
	glm::vec3 p1 = tmp_X[i1];
	glm::vec3 p2 = tmp_X[i2];
	glm::vec3 p3 = tmp_X[i3];

	float w0 = W[i0];
	float w1 = W[i1];
	float w2 = W[i2];
	float w3 = W[i3];

	glm::vec3 c1 = t.c1;
	glm::vec3 c2 = t.c2;
	glm::vec3 c3 = t.c3;

	glm::mat3 P(p1-p0,p2-p0,p3-p0); 
	glm::vec3 f1 = P*c1;
	glm::vec3 f2 = P*c2;
	glm::vec3 f3 = P*c3;

	float S11 = glm::dot(f1, f1);
	float S12 = glm::dot(f1, f2);
	float S13 = glm::dot(f1, f3);

	float S22 = glm::dot(f2, f2);
	float S23 = glm::dot(f2, f3);

	float S33 = glm::dot(f3, f3);

	glm::mat3 mat11 = (2.0f*glm::outerProduct(f1, c1));
	glm::mat3 mat12 = (glm::outerProduct(f2, c1) + glm::outerProduct(f1, c2)); 
	glm::mat3 mat13 = (glm::outerProduct(f3, c1) + glm::outerProduct(f1, c3)); 

	glm::mat3 mat22 = (2.0f*glm::outerProduct(f2, c2));
	glm::mat3 mat23 = (glm::outerProduct(f2, c3)+glm::outerProduct(f3, c2));

	glm::mat3 mat33 = (2.0f*glm::outerProduct(f3, c3));
	
	//stretch constraints
	glm::vec3 ds1_dp1 = mat11[0];
	glm::vec3 ds1_dp2 = mat11[1];
	glm::vec3 ds1_dp3 = mat11[2];
	glm::vec3 ds1_dp0 = -(ds1_dp1+ds1_dp2+ds1_dp3);

	glm::vec3 ds2_dp1 = mat22[0];
	glm::vec3 ds2_dp2 = mat22[1];
	glm::vec3 ds2_dp3 = mat22[2];
	glm::vec3 ds2_dp0 = -(ds2_dp1+ds2_dp2+ds2_dp3);

	glm::vec3 ds3_dp1 = mat33[0];
	glm::vec3 ds3_dp2 = mat33[1];
	glm::vec3 ds3_dp3 = mat33[2];
	glm::vec3 ds3_dp0 = -(ds3_dp1+ds3_dp2+ds3_dp3);

	//shear constraints
	glm::vec3 ds12_dp1 = mat12[0];
	glm::vec3 ds12_dp2 = mat12[1];
	glm::vec3 ds12_dp3 = mat12[2];
	glm::vec3 ds12_dp0 = -(ds12_dp1+ds12_dp2+ds12_dp3);

	glm::vec3 ds13_dp1 = mat13[0];
	glm::vec3 ds13_dp2 = mat13[1];
	glm::vec3 ds13_dp3 = mat13[2];
	glm::vec3 ds13_dp0 = -(ds13_dp1+ds13_dp2+ds13_dp3);

	glm::vec3 ds23_dp1 = mat23[0];
	glm::vec3 ds23_dp2 = mat23[1];
	glm::vec3 ds23_dp3 = mat23[2];
	glm::vec3 ds23_dp0 = -(ds23_dp1+ds23_dp2+ds23_dp3);
	 
	if(w0>EPSILON && w1>EPSILON && w2>EPSILON && w3>EPSILON) {
		glm::vec3 dp0(0,0,0);
		glm::vec3 dp1(0,0,0);
		glm::vec3 dp2(0,0,0);
		glm::vec3 dp3(0,0,0);

		float weightSum11 = w0*glm::dot(ds1_dp0, ds1_dp0) + 
							w1*glm::dot(ds1_dp1, ds1_dp1) + 
							w2*glm::dot(ds1_dp2, ds1_dp2) + 
							w3*glm::dot(ds1_dp3, ds1_dp3);  

		float lambda11 = (S11 - 1.0f)/weightSum11;
		float S11 = -kStretchXX * lambda11;

		dp0 += w0*S11*ds1_dp0; 
		dp1 += w1*S11*ds1_dp1; 
		dp2 += w2*S11*ds1_dp2; 
		dp3 += w3*S11*ds1_dp3;

		// = 2) stretch - S22
		float weightSum22 = w0 * glm::dot(ds2_dp0, ds2_dp0) + 
							w1 * glm::dot(ds2_dp1, ds2_dp1) + 
							w2 * glm::dot(ds2_dp2, ds2_dp2) + 
							w3 * glm::dot(ds2_dp3, ds2_dp3);

		float lambda22 = (S22 - 1.0f)/weightSum22;
		float S22 = -kStretchYY * lambda22; 

		dp0 += w0*S22*ds2_dp0; 
		dp1 += w1*S22*ds2_dp1; 
		dp2 += w2*S22*ds2_dp2; 
		dp3 += w3*S22*ds2_dp3;

		// = 3) stretch - S33
		float weightSum33 = w0 * glm::dot(ds3_dp0, ds3_dp0) + 
							w1 * glm::dot(ds3_dp1, ds3_dp1) + 
							w2 * glm::dot(ds3_dp2, ds3_dp2) + 
							w3 * glm::dot(ds3_dp3, ds3_dp3);
		float lambda33 = (S33 - 1.0f)/weightSum33;
		float S33 = -kStretchZZ * lambda33; 

		dp0 += w0*S33*ds3_dp0; 
		dp1 += w1*S33*ds3_dp1; 
		dp2 += w2*S33*ds3_dp2; 
		dp3 += w3*S33*ds3_dp3;
		 
		// = 4) Shear - S12
		float weightSum12 = w0 * glm::dot(ds12_dp0, ds12_dp0) + 
							w1 * glm::dot(ds12_dp1, ds12_dp1) + 
							w2 * glm::dot(ds12_dp2, ds12_dp2) + 
							w3 * glm::dot(ds12_dp3, ds12_dp3);
		float lambda12 = S12/weightSum12;
		float S12 = -kShearXY * lambda12; 

		dp0 += w0*S12*ds12_dp0; 
		dp1 += w1*S12*ds12_dp1; 
		dp2 += w2*S12*ds12_dp2; 
		dp3 += w3*S12*ds12_dp3;
		
		// = 5) Shear - S13
		float weightSum13 = w0 * glm::dot(ds13_dp0, ds13_dp0) + 
							w1 * glm::dot(ds13_dp1, ds13_dp1) + 
							w2 * glm::dot(ds13_dp2, ds13_dp2) + 
							w3 * glm::dot(ds13_dp3, ds13_dp3);
		float lambda13 = S13/weightSum13;
		float S13 = -kShearXZ * lambda13; 

		dp0 += w0*S13*ds13_dp0; 
		dp1 += w1*S13*ds13_dp1; 
		dp2 += w2*S13*ds13_dp2; 
		dp3 += w3*S13*ds13_dp3;
		
		// = 6) Shear - S23
		float weightSum23 = w0 * glm::dot(ds23_dp0, ds23_dp0) + 
							w1 * glm::dot(ds23_dp1, ds23_dp1) + 
							w2 * glm::dot(ds23_dp2, ds23_dp2) + 
							w3 * glm::dot(ds23_dp3, ds23_dp3);
		float lambda23 = S23/weightSum23;
		float S23 = -kShearYZ * lambda23; 

		dp0 += w0*S23*ds23_dp0; 
		dp1 += w1*S23*ds23_dp1; 
		dp2 += w2*S23*ds23_dp2; 
		dp3 += w3*S23*ds23_dp3;
		 
		// project to new positions
		tmp_X[i0] += dp0;  		dp[i0] += dp0;
		tmp_X[i1] += dp1;		dp[i1] += dp1;
		tmp_X[i2] += dp2;		dp[i2] += dp2;
		tmp_X[i3] += dp3;		dp[i3] += dp3;
	}
}
 

//----------------------------------------------------------------------------------------------------
void GroundCollision() //DevO: 24.07.2011
{
	for(size_t i=0;i<X.size();i++) {	
		if(tmp_X[i].y<0) //collision with ground
			tmp_X[i].y=0;
	}
}
void EllipsoidCollision() {
	for(size_t i=0;i<X.size();i++) {
		glm::vec4 X_0 = (inverse_ellipsoid*glm::vec4(tmp_X[i],1));
		glm::vec3 delta0 = glm::vec3(X_0.x, X_0.y, X_0.z) - center;
		float distance = glm::length(delta0);
		if (distance < 1.0f) {
			delta0 = (radius - distance) * delta0 / distance;
			// Transform the delta back to original space
			glm::vec4 delta = ellipsoid * glm::vec4(delta0, 0);

			tmp_X[i].x +=  delta.x ;
			tmp_X[i].y +=  delta.y ;
			tmp_X[i].z +=  delta.z ;
			V[i] = glm::vec3(0);
		} 
	}
}
void UpdateExternalConstraints() {
	EllipsoidCollision();
	GroundCollision();
}
//----------------------------------------------------------------------------------------------------
void UpdateInternalConstraints() {
	size_t i=0; 
	memset(&dp[0].x, 0, sizeof(glm::vec3)*total_points);


	//printf(" UpdateInternalConstraints \n ");
	for (size_t si=0;si<solver_iterations;++si) {
		/*
		for(i=0;i<d_constraints.size();i++) {
			UpdateDistanceConstraint(i);
		} 
		*/
		
		//will be used instead of distance constraint
		
		for(i=0;i<t_constraints.size();++i) {
			UpdateTetrahedralConstraint(i);
		}

		 
		for(i=0;i<b_constraints.size();i++) {
			UpdateBendingConstraint(i);
		}
		

		
		//update mouse spring		
		if(mouse_constraint.p1 !=-1) {
			DistanceConstraint c = mouse_constraint;

			glm::vec3 dir = tmp_X[c.p1] - mouse_position;
			float len = glm::length(dir); 
			if(len <= EPSILON) 
				return;
			float w1 = W[c.p1]; 
			
			glm::vec3 dP = (1.0f/w1) * (len-c.rest_length ) * (dir/len)* c.k_prime;
			tmp_X[c.p1] -= dP;
			 
		} 
	}
}

void OnIdle() {	

	/*
	//Semi-fixed time stepping
	if ( frameTime > 0.0 )
	{
	const float deltaTime = min( frameTime, timeStep );
	StepPhysics(deltaTime );
	frameTime -= deltaTime;    		
	}
	*/

	//printf(" ### OnIdle %f ### \n",accumulator);
	//Fixed time stepping + rendering at different fps	
	if ( accumulator >= timeStep )
	{	 
		StepPhysics(timeStep );		
		accumulator -= timeStep;
	}

	glutPostRedisplay(); 
	Sleep(5); //TODO
}


void StepPhysics(float dt ) {
	ComputeForces();	
	//IntegrateExplicitWithDamping(dt);	//for PBD
	IntegrateExplicitWithDampingSBD(dt); //for strain based dynamics
	
	// for collision constraints	
	UpdateInternalConstraints();	
	UpdateExternalConstraints();
	
	Integrate(dt);

	UpdateMesh();
} 

void OnKey(unsigned char key, int, int) {
	switch(key) {
		//stretch constants
		case 'q': kStretchXX -= 0.1f; break;
		case 'e': kStretchXX += 0.1f; break;

		case 'a': kStretchYY -= 0.1f; break;
		case 'd': kStretchYY += 0.1f; break;

		case 'z': kStretchZZ -= 0.1f; break;
		case 'c': kStretchZZ += 0.1f; break;

		//shear constants			
		case 'w': kShearXY -= 0.1f; break;
		case 'r': kShearXY += 0.1f; break;

		case 's': kShearYZ -= 0.1f; break;
		case 'f': kShearYZ += 0.1f; break;

		case 'x': kShearXZ -= 0.1f; break;
		case 'v': kShearXZ += 0.1f; break;
		
		case 't':
			bShowTetrahedra=!bShowTetrahedra;
		break;
	
		case 'p':
			bShowPoints=!bShowPoints;
		break;
	}
	kStretchXX = max(0.1f, min(kStretchXX, 1.0f));
	kStretchYY = max(0.1f, min(kStretchYY, 1.0f));
	kStretchZZ = max(0.1f, min(kStretchZZ, 1.0f));
	kShearXY = max(0.1f, min(kShearXY, 1.0f));
	kShearXZ = max(0.1f, min(kShearXZ, 1.0f));
	kShearYZ = max(0.1f, min(kShearYZ, 1.0f));

	printf("kStretchXX: %3.2f, kStretchYY: %3.2f, kStretchZZ: %3.2f\n", kStretchXX, kStretchYY, kStretchZZ);
	printf("\tkShearXY: %3.2f, kShearXZ: %3.2f, kShearYZ: %3.2f\n", kShearXY, kShearXZ, kShearYZ);

	glutPostRedisplay();
}

void main(int argc, char** argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutCreateWindow("GLUT Cloth Demo [Strain based Dynamics]");

	glutDisplayFunc(OnRender);
	glutReshapeFunc(OnReshape);
	glutIdleFunc(OnIdle);

	glutMouseFunc(OnMouseDown);
	glutMotionFunc(OnMouseMove);
	glutKeyboardFunc(OnKey);

	glutCloseFunc(OnShutdown);

	glewInit();
	InitGL();

	glutMainLoop();		
}