// This code accompanies Chapter 5 in Game Engine Gems 3.
// It generates the cube map shown in Figure 5.5, called "factorCube" in Listing 5.1.

enum
{
	// This is the width and height of each face of the cube texture.
	kHorizonCubeSize = 16
};

struct Color4
{
	unsigned char	red;
	unsigned char	green;
	unsigned char	blue;
	unsigned char	alpha;
};

// This following function generates the six faces of the cube lookup texture
// and returns a pointer to the memory allocated to hold the resulting image.

Color4 *GenerateHorizonLookupCube(void)
{
	unsigned long imageSize = kHorizonCubeSize * kHorizonCubeSize * 6;
	Color4 *storage = new Color4[imageSize];
	Color4 *image = storage;

	float f = 2.0F / (float) kHorizonCubeSize;

	for (machine face = 0; face < 6; face++)
	{
		for (machine j = 0; j < kHorizonCubeSize; j++)
		{
			float y = ((float) j + 0.5F) * f - 1.0F;

			for (machine i = 0; i < kHorizonCubeSize; i++)
			{
				float	t;

				float x = ((float) i + 0.5F) * f - 1.0F;

				switch (face)
				{
					case 0:		// Positive x

						t = atan2(-y, 1.0F);
						break;

					case 1:		// Negative x

						t = atan2(-y, -1.0F);
						break;

					case 2:		// Positive y

						t = atan2(1.0F, x);
						break;

					case 3:		// Negative y

						t = atan2(-1.0F, x);
						break;

					case 4:		// Positive z

						t = atan2(-y, x);
						break;

					case 5:		// Negative z

						t = atan2(-y, -x);
						break;
				}

				t *= 1.2732395447F;		// 4/pi

				float red = 0.0F;
				float green = 0.0F;
				float blue = 0.0F;
				float alpha = 0.0F;

				if (t < -3.0F)
				{
					red = t + 3.0F;
					green = -4.0F - t;
				}
				else if (t < -2.0F)
				{
					green = t + 2.0F;
					blue = -3.0F - t;
				}
				else if (t < -1.0F)
				{
					blue = t + 1.0F;
					alpha = -2.0F - t;
				}
				else if (t < 0.0F)
				{
					alpha = t;
					red = t + 1.0F;
				}
				else if (t < 1.0F)
				{
					red = 1.0F - t;
					green = t;
				}
				else if (t < 2.0F)
				{
					green = 2.0F - t;
					blue = t - 1.0F;
				}
				else if (t < 3.0F)
				{
					blue = 3.0F - t;
					alpha = t - 2.0F;
				}
				else
				{
					alpha = 4.0F - t;
					red = 3.0F - t;
				}

				// Transform [-1,1] to [0,255].

				image->red = (unsigned char) ((int) (red * 127.0F) + 128);
				image->green = (unsigned char) ((int) (green * 127.0F) + 128);
				image->blue = (unsigned char) ((int) (blue * 127.0F) + 128);
				image->alpha = (unsigned char) ((int) (alpha * 127.0F) + 128);
				image++;
			}
		}
	}

	return (storage);
}
