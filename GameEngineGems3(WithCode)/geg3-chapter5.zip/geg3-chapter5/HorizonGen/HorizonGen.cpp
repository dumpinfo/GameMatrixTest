// This code accompanies Chapter 5 in Game Engine Gems 3.
// It generates a horizon map from a height map.

enum
{
	// This is the number of directions for which we store
	// the maximum squared tangent from Equation 5.1.

	kHorizonMapAngleCount	= 32,

	// This is the radius of the neighborhood about each texel
	// where we look for higher values in the height map.

	kHorizonMapRadius		= 16
};

// The value of min_float represents the smallest floating-point
// number having a reciprocal that is not infinity.

unsigned_int32 hex_00800000 = 0x00800000;
const float min_float = *(float *) &hex_00800000;

struct Color4
{
	unsigned char	red;
	unsigned char	green;
	unsigned char	blue;
	unsigned char	alpha;
};

inline int32 MaxZero(int32 x)
{
	return (x & ~(x >> 31));
}

inline int32 Min(int32 x, int32 y)
{
	int32 a = x - y;
	return (x - (a & ~(a >> 31)));
}

inline float Fmax(float x, float y)
{
	return ((x < y) ? y : x);
}

// layer -- The layer number of the horizon map. Must be 0 or 1, and determines which four directions are considered.
// width, height -- The width and height of the horizon map.
// source -- A pointer to the input height map. The height is taken from the red channel.
// destin -- The output horizon map. All four channels are written.
// scale -- A scale value by which all heights are multiplied.
// swrap, twrap -- Boolean values indicating whether the horizon map repeats in the s and/or t directions.

void CalculateHorizonMap(int layer, int width, int height, const Color4 *source, Color4 *destin, float scale, bool swrap, bool twrap)
{
	int widthMinus1 = width - 1;
	int heightMinus1 = height - 1;
	unsigned int xmask = widthMinus1 & -int(swrap);
	unsigned int ymask = heightMinus1 & -int(twrap);

	scale *= 1.0F / 255.0F;

	// x and y loop over the entire input height map.

	for (int y = 0; y < height; y++)
	{
		const Color4 *centerRow = source + y * width;
		for (int x = 0; x < width; x++)
		{
			float	maxSquaredTangent[kHorizonMapAngleCount];

			for (int a = 0; a < kHorizonMapAngleCount; a++)
			{
				maxSquaredTangent[a] = 0.0F;
			}

			float h0 = float(centerRow[x].red) * scale;

			// i and j loop over a neighborhood about the texel being considered.

			for (int j = -kHorizonMapRadius; j <= kHorizonMapRadius; j++)
			{
				int k = (j + kHorizonMapRadius) * (kHorizonMapRadius * 2 + 1) + kHorizonMapRadius;

				int ypj = y + j;
				ypj = (ypj & ymask) | (MaxZero(Min(ypj, heightMinus1)) & ~ymask);
				const Color4 *row = source + ypj * width;

				for (int i = -kHorizonMapRadius; i <= kHorizonMapRadius; i++)
				{
					int r2 = i * i + j * j;
					if ((r2 < kHorizonMapRadius * kHorizonMapRadius) && (r2 != 0))
					{
						float inverseR2 = 1.0F / float(r2);

						int xpi = x + i;
						xpi = (xpi & xmask) | (MaxZero(Min(xpi, widthMinus1)) & ~xmask);

						float h = float(row[xpi].red) * scale;
						if (h > h0)
						{
							h -= h0;
							float t = h * h * inverseR2;	// Equation 5.1

							const int8 *range = horizonAngleRange[k + i];
							int minAngle = range[0];
							int maxAngle = range[1];

							const float *centerDelta = horizonDeltaAngle[k + i];
							float centerAngle = centerDelta[0];
							float deltaAngle = centerDelta[1];

							for (int n = minAngle; n <= maxAngle; n++)
							{
								float angle = float(n) * (6.2831853F / float(kHorizonMapAngleCount));
								float f = Fmax(1.0F - fabs(angle - centerAngle) / deltaAngle, 0.0F);

								int m = n & (kHorizonMapAngleCount - 1);
								maxSquaredTangent[m] = Fmax(maxSquaredTangent[m], t * f);
							}
						}
					}
				}
			}

			float red = 0.0F;
			float green = 0.0F;
			float blue = 0.0F;
			float alpha = 0.0F;

			int start = kHorizonMapAngleCount / 8 - kHorizonMapAngleCount / 16 + layer * kHorizonMapAngleCount / 2;
			int finish = start + kHorizonMapAngleCount / 8;

			for (int a = start; a <= finish; a++)
			{
				float t = maxSquaredTangent[(a - kHorizonMapAngleCount / 8) & (kHorizonMapAngleCount - 1)];
				if (t > min_float)
				{
					red += rsqrt(1.0F / t + 1.0F);	// Equation 5.2
				}

				t = maxSquaredTangent[a];
				if (t > min_float)
				{
					green += rsqrt(1.0F / t + 1.0F);
				}

				t = maxSquaredTangent[a + kHorizonMapAngleCount / 8];
				if (t > min_float)
				{
					blue += rsqrt(1.0F / t + 1.0F);
				}

				t = maxSquaredTangent[(a + kHorizonMapAngleCount / 4) & (kHorizonMapAngleCount - 1)];
				if (t > min_float)
				{
					alpha += rsqrt(1.0F / t + 1.0F);
				}
			}

			float f = 255.0F / float(kHorizonMapAngleCount / 8 + 1);
			int z = y * width + x;

			destin[z].red = (unsigned char) (red * f);
			destin[z].green = (unsigned char) (green * f);
			destin[z].blue = (unsigned char) (blue * f);
			destin[z].alpha = (unsigned char) (alpha * f);
		}
	}
}
