
// pre-C++11 version
//#include "Delegate.h"

// C++11 version
#include "Delegate11.h"


void Func0(void)
{
}

int Func1(int a)
{
	return a + 10;
}

float Func2(float a, float b)
{
	return a + b;
}


struct Test
{
	void Func0(void)
	{
	}

	void Func0(void) const
	{
	}

	int Func1(int a)
	{
		return a + 20;
	}

	int Func1(int a) const
	{
		return a + 20;
	}

	float Func2(float a, float b)
	{
		return a + b;
	}

	float Func2(float a, float b) const
	{
		return a + b;
	}
};


int main(void)
{
	// delegate with zero arguments
	{
		typedef Delegate<void(void)> TestDelegate;
		TestDelegate d;
		d.Bind<&Func0>();
		d.Invoke();
	}

	// delegate with one argument
	{
		typedef Delegate<int (int)> TestDelegate;
		TestDelegate d;
		d.Bind<&Func1>();
		d.Invoke(10);

		Test t;
		d.Bind<Test, &Test::Func1>(&t);
		d.Invoke(10);

		const Test ct;
		d.Bind<Test, &Test::Func1>(&ct);
		d.Invoke(10);
	}

	// delegate with two arguments
	{
		typedef Delegate<float (float, float)> TestDelegate;
		TestDelegate d;
		d.Bind<&Func2>();
		d.Invoke(10.0f, 20.0f);

		Test t;
		d.Bind<Test, &Test::Func2>(&t);
		d.Invoke(10.0f, 20.0f);

		const Test ct;
		d.Bind<Test, &Test::Func2>(&ct);
		d.Invoke(10.0f, 20.0f);
	}
}
