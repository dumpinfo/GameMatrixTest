
Updated September 30, 2015.

README file of companion code of article
"Edge-preserving smoothing filter for particle-based rendering"
in Game Engine Gems Vol. 3

How to build
============

Complete source code is available inside the 'source' folder.

You will need CMake to create build files and a CMakeLists.txt file is included.
Everything has been tested with VS 2013 and OpenGL 4.3 or above driver is required.

Two 3rd-party libraries 'freeglut' and 'glew' are required to build.
We have used the following version in our test:

freeglut 3.0.0
glew-1.12.0

Please edit CMakeLists.txt accordingly to reflect your source locations.

Remember to copy the 'shader' folder to the built executable folder as the program
expects the shader folder available immediately in the same folder.


Citation
========

If you use any part of the code in our source, please cite our article as follows:

Authors:
Kin-Ming Wong and Tien-Tsin Wong

Article:
Edge-preserving smoothing filter for particle-based rendering
Game Engine Gems Vol.3


License
=======

We made our code available under BSD license

Copyright (c) 2015, Kin-Ming Wong and Tien-Tsin Wong
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
OF THE POSSIBILITY OF SUCH DAMAGE.
