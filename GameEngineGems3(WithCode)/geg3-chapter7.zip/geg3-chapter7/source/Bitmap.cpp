#include "Bitmap.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#define safeFREE(p)  { if(p) { free(p); p = NULL; } }

Bitmap::Bitmap() {
	memset(this, 0, sizeof(Bitmap));
}

Bitmap::Bitmap(const char *path) {
	memset(this, 0, sizeof(Bitmap));
	create(path);
}

Bitmap::~Bitmap() {
	safeFREE(_data);
	safeFREE(_pData);
}

bool Bitmap::init(int width, int height) {

	safeFREE(_data);
	safeFREE(_pData);

	_w = width;
	_h = height;

	_data = (Pixel *)malloc(_w * _h * sizeof(Pixel));
	if (_data == NULL) return false;
	memset(_data, 0, _w * _h * sizeof(Pixel)); 

	_pData = (Pixel **)malloc(_h * sizeof(Pixel *));
	if (_pData == NULL) return false;

	for (int j = 0; j < _h; j++) _pData[j] = &_data[j * _w];

	return true;

}

bool Bitmap::create(const char *path) {

	BmpHeaderInfo header;

	{
		FILE *fp = fopen(path, "rb");
		if (fp == NULL) return false;

		fread( &header, sizeof(BmpHeaderInfo), 1, fp );
		fclose(fp);
	}

	if ( header.bfType != 'MB' ) return false;
	if ( header.biCompression != 0 ) return false;
	if ( header.biBitCount != 24 ) return false;

	if (!init( header.biWidth, header.biHeight )) return false;

	{
		FILE *fp = fopen(path, "rb");
		fseek(fp, header.bfOffBits, SEEK_SET);

		for (int i = _h - 1; i >= 0; i--) {
			fread(_pData[i], sizeof(Pixel), _w, fp);
			fseek(fp, (4 - _w * 3 % 4) % 4, SEEK_CUR);
		}

		fclose(fp);
	}

	return true;

}
