#ifndef _BITMAP_H_
#define _BITMAP_H_

struct Pixel {
	unsigned char p1, p2, p3;
};

class Bitmap {

public:
	Bitmap();
	Bitmap(const char *path);

	~Bitmap();

	bool create(const char *path);
	bool init(int width, int height);

	inline int getWidth();
	inline int getHeight();

	inline unsigned char getR(int x, int y);
	inline unsigned char getG(int x, int y);
	inline unsigned char getB(int x, int y);

protected:

//	Instructs compiler to use tight packing
#pragma pack(push, 1)
	struct BmpHeaderInfo {

		unsigned short	bfType;
		unsigned int	bfSize;
		unsigned short	bfReserved1;
		unsigned short	bfReserved2;
		unsigned int	bfOffBits;

		unsigned int	biSize;
		int				biWidth;
		int				biHeight;
		unsigned short	biPlanes;
		unsigned short	biBitCount;
		unsigned int	biCompression;
		unsigned int	biSizeImage;
		int				biXpelsPerMeter;
		int				biYpelsPerMeter;
		unsigned int	biClrUsed;
		unsigned int	biClrImportant;

	};
#pragma pack(pop)

	int		_w,	_h;
	Pixel	*_data;
	Pixel	**_pData;

};


int Bitmap::getWidth() {
	return _w;
}

int Bitmap::getHeight() {
	return _h;
}

unsigned char Bitmap::getR(int x, int y) {
	return _data[x + _w * y].p3;
}

unsigned char Bitmap::getG(int x, int y) {
	return _data[x + _w * y].p2;
}

unsigned char Bitmap::getB(int x, int y) {
	return _data[x + _w * y].p1;
}

#endif
