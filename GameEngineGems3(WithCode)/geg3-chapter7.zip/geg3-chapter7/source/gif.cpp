//
//	gif.cpp
//
//	Guided Image Filter implemented in GLSL
//
//	Copyright (c) 2015, Kin-Ming Wong and Tien-Tsin Wong
//  All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without modification,
//	are permitted provided that the following conditions are met:
//
//	Redistributions of source code must retain the above copyright notice,
//	this list of conditions and the following disclaimer.
//
//	Redistributions in binary form must reproduce the above copyright notice,
//	this list of conditions and the following disclaimer in the documentation
//	and/or other materials provided with the distribution.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
//	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
//	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//	IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
//	INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
//	BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//	DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//	LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
//	OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
//	OF THE POSSIBILITY OF SUCH DAMAGE.
//
//	Please cite our original article in Game Engine sGems 3 if you use any part of
//	the following code.
//

#include "GL/glew.h"
#include "GL/freeglut.h"
#include "stdio.h"
#include "Bitmap.h"
#include "string.h"
#include <string>

using namespace std;

int	frameCount = 0;
int previousTime = 0;
int currentTime = 0;
float fps = 0;

int		winWidth, winHeight;
float	*inputImage;

//	GL textures
GLuint texImage[6];

//	Framebuffer Object
GLuint fbo;

//	Compiled shader objects
GLuint satShaderObj;		//	SAT shader source texts
GLuint sqShaderObj;			//	SAT shader source texts

//GLuint AkBkShaderObj;

struct {
	GLuint	vs;
	GLuint	fs;
} renderShaderObj;	//	Render shader source texts

struct {
	GLuint	vs;
	GLuint	fs;
} AkBkShaderObj;	//	Render shader source texts


//	Shader Program handles
GLuint	satShader;			//	SAT shader
GLuint	sqShader;			//	SAT shader
GLuint	renderShader;		//	Render shader
GLuint	AkBkShader;			//	Render shader

GLuint	dummy_vao;

int		radius;
float	epsilon;

#define TEX_SIZE		1024
#define	SHADER_LENGTH	4096


//	uses sqShader (i.e. sq.glsl)
//
void squaredIntensity(GLuint input, GLuint output) {

	glUseProgram(sqShader);

	glBindImageTexture(0, input, 0, GL_FALSE, 0, GL_READ_ONLY, GL_RGBA32F);
	glBindImageTexture(1, output, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA32F);
	glDispatchCompute(TEX_SIZE, 1, 1);
	glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);

}


//	uses satShader (i.e. prefixSum_T.glsl)
//
void genSAT(GLuint input, GLuint work, GLuint output)
{

	glUseProgram( satShader );

	glBindImageTexture(0, input, 0, GL_FALSE, 0, GL_READ_ONLY, GL_RGBA32F);
	glBindImageTexture(1, work, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA32F);
	glDispatchCompute(TEX_SIZE, 1, 1);
	glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);

	glBindImageTexture(0, work, 0, GL_FALSE, 0, GL_READ_ONLY, GL_RGBA32F);
	glBindImageTexture(1, output, 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA32F);
	glDispatchCompute(TEX_SIZE, 1, 1);
	glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);

}


//	Uses AkBkShader (i.e. AkBk.vs.glsl and AkBk.fs.glsl)
//
void AkBk(GLuint sat2, GLuint sat, GLuint Ak, GLuint Bk)
{

	glUseProgram(AkBkShader);

	GLuint fb = 0;
	glGenFramebuffers(1, &fb);
	glBindFramebuffer( GL_FRAMEBUFFER, fb );
	glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, Ak, 0);
	glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT1, Bk, 0);

	GLenum buffers[2] = { GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1 };
	glDrawBuffers(2, buffers);		//	Render to texture

	glBindFramebuffer(GL_FRAMEBUFFER, fb);
	glViewport(0, 0, TEX_SIZE, TEX_SIZE);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, sat2);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, sat);

	glBindVertexArray(dummy_vao);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

	glBindFramebuffer(GL_FRAMEBUFFER, 0);

}


//	Uses renderShader (i.e. render.vs.glsl and render.fs.glsl)
//
void render(GLuint input, GLuint A_K, GLuint B_K)
{

	glUseProgram( renderShader );

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, input);

	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, A_K);

	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, B_K);

	glBindVertexArray(dummy_vao);
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

}


//	Main filtering happens here
//
void displayFunc()
{

	glClearColor( 0, 0, 0, 0 );
	glClear( GL_COLOR_BUFFER_BIT );

	//	Per-patch Ak abd Bk computation
	squaredIntensity(texImage[0], texImage[2]);			//	Squared intensity
	genSAT(texImage[2], texImage[1], texImage[2]);		//	genSAT for input image, texImage[2] = SAT(input^2)
	genSAT(texImage[0], texImage[1], texImage[3]);		//	genSAT for input image, texImage[3] = SAT(input)
	AkBk(texImage[2], texImage[3], texImage[4], texImage[5]);		//	Per-patch Ak = texImage[4], Bk = texImage[5]

	//	Per-pixel filter
	genSAT(texImage[4], texImage[1], texImage[2]);		//	SAT of Ak == texImage(2)
	genSAT(texImage[5], texImage[1], texImage[3]);		//	SAT of Bk == texImage(3)
	render(texImage[0], texImage[2], texImage[3]);		//	Use original and SAT(Ak) and SAT(Bk)

	//	swap buffers and then redisplay
	glutSwapBuffers();
	glutPostRedisplay();

}


void reshapeFunc(int width, int height)
{

	//set view port
	glViewport(0, 0, TEX_SIZE, TEX_SIZE);
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	//set parallel projection
	glOrtho(-TEX_SIZE / 2, TEX_SIZE / 2, -TEX_SIZE / 2, TEX_SIZE / 2, -1, 1);
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

}


void calculateFPS()
{
	//  Increase frame count
	frameCount++;

	//  Get the number of milliseconds since glutInit called
	//  (or first call to glutGet(GLUT ELAPSED TIME)).
	currentTime = glutGet(GLUT_ELAPSED_TIME);

	//  Calculate time passed
	int timeInterval = currentTime - previousTime;

	if (timeInterval > 1000)
	{
		//  calculate the number of frames per second
		fps = frameCount / (timeInterval / 1000.0f);

		//  Set time
		previousTime = currentTime;

		//  Reset frame count
		frameCount = 0;
	}
}


void idleFunc(void)
{
	//  Calculate FPS
	calculateFPS();

	char title[20];
	sprintf(title, "%f fps", fps);
	glutSetWindowTitle(title);

	//  Call display function (draw the current frame)
	glutPostRedisplay();
}


//	load shader source files
//
GLuint compileShader(char *path, GLenum shaderType) {

	#define BUFFER_SIZE		512
	#define BUFFER_SIZE_1	513

	char buffer[ BUFFER_SIZE_1 ];

	printf("Compiling %s shader\n", path);

	FILE *fp = fopen( path, "r+t" );
	if (fp == NULL) {
		printf("FAILED to read %s\n", path);
		return false;
	}


	//	Load texts from shader source file
	//
	std::string		text;
	text.clear();
	memset( buffer, 0, sizeof(char) * BUFFER_SIZE_1 );

	size_t	byteRead = 0;
	while ( (byteRead = fread( buffer, sizeof(char), BUFFER_SIZE, fp) ) == BUFFER_SIZE ) {
		buffer[byteRead] = 0;
		text += buffer;
		memset( buffer, 0, sizeof(char) * BUFFER_SIZE_1 );
	}
	text += buffer;
	fclose(fp);

	GLchar *sourceText = &text[0];
	const GLchar *source = sourceText;
	GLuint shaderHandle = glCreateShader( shaderType );

	if ( shaderHandle == 0 ) return false;
	glShaderSource( shaderHandle, 1, &source, NULL );
	glCompileShader( shaderHandle );

	GLint status;
	glGetShaderiv( shaderHandle, GL_COMPILE_STATUS, &status );
	if (status != GL_TRUE) {
		printf("%s shader compilation FAILED\n", path);
		return 0;
	}

	printf("%s shader compilation OK\n", path);
	return shaderHandle;

}


bool loadImageAndShaders(const char* fileName) {

	Bitmap	inputBMP;

	if (!inputBMP.create(fileName)) {
		printf("Unable to read image!\n");
		return false;
	}

	winWidth = inputBMP.getWidth();
	winHeight = inputBMP.getHeight();

	inputImage = new float[TEX_SIZE * TEX_SIZE * 4];
	if (!inputImage) {
		printf("Unable to allocate memory!\n");
		return false;
	}

	int offsetX = (TEX_SIZE - winWidth) / 2;
	int offsetY = (TEX_SIZE - winHeight) / 2;

	int index = 0;
	for (int y = 0; y < winHeight; y++) {
		for (int x = 0; x < winWidth; x++) {
			index = ((TEX_SIZE - 1 - y - offsetY) * TEX_SIZE + x + offsetX) * 4;
			inputImage[index] = inputBMP.getR(x, y) / 255.0;
			inputImage[index + 1] = inputBMP.getG(x, y) / 255.0;
			inputImage[index + 2] = inputBMP.getB(x, y) / 255.0;
			inputImage[index + 3] = 1.0;
		}
	}

	winWidth = TEX_SIZE;
	winHeight = TEX_SIZE;

	glGenTextures(6, texImage);

	glActiveTexture(GL_TEXTURE0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texImage[0]);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, TEX_SIZE, TEX_SIZE, 0, GL_RGBA, GL_FLOAT, inputImage);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	for (int i = 1; i < 6; i++) {
		glBindTexture(GL_TEXTURE_2D, texImage[i]);
		glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA32F, TEX_SIZE, TEX_SIZE);
	}

	printf("\nCompiling Shaders\n");

	//	load shader sources
	if ((satShaderObj = compileShader("./shader/prefixSum_T.glsl", GL_COMPUTE_SHADER)) == 0 ) return false;
	if ((sqShaderObj  = compileShader("./shader/sq.glsl", GL_COMPUTE_SHADER)) == 0) return false;

	if ((AkBkShaderObj.vs = compileShader("./shader/AkBk.vs.glsl", GL_VERTEX_SHADER)) == 0) return false;
	if ((AkBkShaderObj.fs = compileShader("./shader/AkBk.fs.glsl", GL_FRAGMENT_SHADER)) == 0) return false;

	if ((renderShaderObj.vs = compileShader("./shader/render.vs.glsl", GL_VERTEX_SHADER)) == 0) return false;
	if ((renderShaderObj.fs = compileShader("./shader/render.fs.glsl", GL_FRAGMENT_SHADER)) == 0) return false;

	printf("Shader compilation done\n");

	GLint status;

	if ((satShader = glCreateProgram()) == 0) return 0;
	glAttachShader( satShader, satShaderObj );
	glLinkProgram(satShader);

	if ((sqShader = glCreateProgram()) == 0) return 0;
	glAttachShader(sqShader, sqShaderObj);
	glLinkProgram(sqShader);

	if ((AkBkShader = glCreateProgram()) == 0) return 0;
	glAttachShader(AkBkShader, AkBkShaderObj.vs);
	glAttachShader(AkBkShader, AkBkShaderObj.fs);
	glLinkProgram(AkBkShader);

	glGetProgramiv(AkBkShader, GL_LINK_STATUS, &status);

	if (status == GL_FALSE) {
		char buffer[SHADER_LENGTH];
		glGetProgramInfoLog(AkBkShader, SHADER_LENGTH, NULL, buffer);
		printf("ERROR: %s\n", buffer);
		glDeleteProgram(AkBkShader);
		return 0;
	}

	GLuint	id;

	glUseProgram(AkBkShader);
	id = glGetUniformLocation(AkBkShader, "r");
	glUniform1i(id, radius);
	id = glGetUniformLocation(AkBkShader, "epsilon");
	glUniform1f(id, epsilon);


	if ((renderShader = glCreateProgram()) == 0) return 0;
	glAttachShader(renderShader, renderShaderObj.vs );
	glAttachShader(renderShader, renderShaderObj.fs );
	glLinkProgram(renderShader);

	glGetProgramiv(renderShader, GL_LINK_STATUS, &status);

	if (status == GL_FALSE) {
		char buffer[SHADER_LENGTH];
		glGetProgramInfoLog(renderShader, SHADER_LENGTH, NULL, buffer);
		printf("ERROR: %s\n", buffer);
		glDeleteProgram(renderShader);
		return 0;
	}

	glUseProgram(renderShader);
	id = glGetUniformLocation(renderShader, "r");
	glUniform1i(id, radius);

	glGenVertexArrays(1, &dummy_vao);
	glBindVertexArray(dummy_vao);

	return true;

}


void shutDown() {
	printf("Program terminated\n");
}


bool main(int argc, char* argv[])
{

	if (argc != 4) {
		printf("usage: %s <bitmap> <radius> <epsilon>\n", argv[0]);
		return false;
	}

	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );
	glutCreateWindow("Guided Image Filter via GLSL");

	printf( "\nDriver's OpenGL version: %s\n", (const unsigned char *)glGetString(GL_VERSION) );

	glewInit();

	if (glewIsSupported("GL_VERSION_4_3"))
		printf("glew: Ready for OpenGL 4.3\n\n");
	else {
		printf("glew: OpenGL 4.3 not supported\n");
		return false;
	}

	radius	= atoi(argv[2]);
	epsilon = atof(argv[3]);

	//	Compute shaders information
	int	xSize, ySize, zSize, localSize;
	glGetIntegeri_v( GL_MAX_COMPUTE_WORK_GROUP_SIZE, 0, &xSize );
	glGetIntegeri_v( GL_MAX_COMPUTE_WORK_GROUP_SIZE, 1, &ySize );
	glGetIntegeri_v( GL_MAX_COMPUTE_WORK_GROUP_SIZE, 2, &zSize );
	printf( "Max Compute Work Group Size %d, %d, %d\n", xSize, ySize, zSize );
	glGetIntegerv( GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS, &localSize );
	printf( "Max Invocation Size %d\n", localSize );

	int	shMemSize;
	glGetIntegerv( GL_MAX_COMPUTE_SHARED_MEMORY_SIZE, &shMemSize );
	printf("Max Shared Mem Size %d (%dK)\n", shMemSize, shMemSize/1024 );

	int	texUnits;
	glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &texUnits);
	printf("Max Texture Units: %d\n", texUnits );

	glutDisplayFunc( displayFunc );
	glutReshapeFunc( reshapeFunc );
	glutIdleFunc( idleFunc );

	glEnable( GL_TEXTURE_2D );
	glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );

	if (!loadImageAndShaders(argv[1])) return false;

	glutReshapeWindow(TEX_SIZE, TEX_SIZE);

	atexit( shutDown );

	glutMainLoop();
	return true;

}
